# Pixel War 0.4.7 source (Tough & J's Arcade 2.7.70) — GPL-3.0
- game/pixel-war-0.4.7.html: the whole game is this one file (no build step). The AI always plays at full smart (the difficulty picker is hidden). Branch streams fill their full lane width. Past the end of a path or a branch, pixels keep going in that last direction as one loose, wide group, then fade. Save keys `pixelwar.v47*` (prefs/forms/custom/AI memory fall back from v46/v45/v44/v43). Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.6.html: kept as `pixelwar:v046`; 0.4.5 as `v045`; 0.4.4 as `v044`; 0.4.3 as `v043`; 0.4.2 as `v042`; 0.4.1 as `v041`; 0.3 as `v03`.
- arcade-2.7.70/: assemble-2770.mjs and verify-2770.cjs (checks the signed APK against 2.7.69).
- tests/ were not re-run for 0.4.7. No signing keys and no Latch code are included.
