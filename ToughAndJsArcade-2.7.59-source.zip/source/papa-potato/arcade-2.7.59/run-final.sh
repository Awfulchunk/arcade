#!/bin/bash
# Sequential final run on the APK-extracted html. One heavy job at a time. (The WebView-83 emulator is run separately, ALONE, last.)
cd /workspace/game/build-potato3
F=/workspace/game/build-potato3/out/final; rm -rf $F; mkdir -p $F
H=file:///workspace/game/build-potato3/test/papa-potato-from-apk.html
step(){ n=$1; shift; echo "== $(date +%H:%M:%S) $n" | tee -a $F/steps.log; pkill -f google-chrome || true; "$@" > $F/$n.log 2>&1; echo "   exit $? $(tail -1 $F/$n.log | cut -c1-160)" | tee -a $F/steps.log; }
step build bash build-2759.sh
step verify env PATH=/workspace/tools/jdk/bin:$PATH node verify-2759.cjs
cd test
export PP_HTML=$H
rm -rf out/p1 out/p2-* out/p3-* out/buff out/perf-a03s out/stress out/shots03
step pass1-mech timeout 900 node t-mech03.cjs out/p1
step pass2-gui-360x800 timeout 600 node t-gui03.cjs 360x800 out/p2
step pass2-gui-320x568 timeout 600 node t-gui03.cjs 320x568 out/p2
step pass2-gui-720x1600 timeout 600 node t-gui03.cjs 720x1600 out/p2 1
step pass3-cmd-360x800 timeout 600 node t-cmd03.cjs 360x800 out/p3
step pass3-cmd-320x568 timeout 600 node t-cmd03.cjs 320x568 out/p3
cd ..
step pass4-arcade-reg timeout 600 node arcade-reg-2759.cjs
cd test
step buff timeout 1500 node t-buff03.cjs out/buff
step perf-a03s timeout 900 node t-perf03.cjs 6 out/perf-a03s
step stress timeout 1500 node t-stress03.cjs 90 90 out/stress
step shots-360x800 timeout 900 node t-shots03.cjs 360x800 out/shots03
step shots-320x568 timeout 900 node t-shots03.cjs 320x568 out/shots03
echo "== $(date +%H:%M:%S) ALL DONE" | tee -a $F/steps.log
