#!/bin/bash
# Stage finished-ship/papa-potato-0.3-arcade-2.7.59 (NOT published). Never copies keys; prints no secrets.
set -euo pipefail
D=/workspace/game/requests/finished-ship/papa-potato-0.3-arcade-2.7.59
B=/workspace/game/build-potato3; B2=/workspace/game/build-potato2; P=$B/package-2.7.59; OLD=/workspace/game/requests/finished-ship/latch-manual-arcade-2.7.56
PREV=/workspace/game/requests/finished-ship/papa-potato-0.2-arcade-2.7.58
mkdir -p $D/screenshots $D/test-evidence $D/licenses
cp $P/out/ToughAndJsArcade-2.7.59.apk $D/
# ---- Papa Potato 0.3 source zip ----
Z=/tmp/pp03src; rm -rf $Z; R=$Z/PapaPotato-0.3-source; mkdir -p $R/{game,arcade-2.7.59,tests/fixtures,android-app,old-webview}
cp $B/src/head.html $B/src/sim.js $B/src/game.js $B/build.sh $R/game/
cp $B/out/papa-potato-0.3.html $R/game/papa-potato-0.3.html
cp $B2/out/papa-potato-0.2.html $R/game/papa-potato-0.2.html
cp $B2/out/papa-potato-0.1-frozen.html $R/game/papa-potato-0.1-frozen.html
cp /workspace/game/requests/future/potato-peeler/mock/mock-0.1b-zoom15.html $R/game/mock-0.1b-approved.html
cp $B/assemble-2759.mjs $B/build-2759.sh $B/verify-2759.cjs $B/arcade-reg-2759.cjs $B/emu-2759.cjs $B/package-2759.sh $B/run-final.sh $R/arcade-2.7.59/
cp $B/test/lib.cjs $B/test/t-mech03.cjs $B/test/t-gui03.cjs $B/test/t-cmd03.cjs $B/test/t-buff03.cjs $B/test/t-perf03.cjs $B/test/t-stress03.cjs $B/test/t-shots03.cjs $B/test/mkfix.cjs $R/tests/
cp $B/test/fixtures/v1-save.json $B/test/fixtures/v2-save.json $R/tests/fixtures/
cp $P/app/AndroidManifest.xml $P/build-apk.sh $R/android-app/; cp -r $P/app/src $R/android-app/src
cp /workspace/game/build-latch/fix/legacy-css.mjs /workspace/game/build-latch/fix/legacy-html.mjs /workspace/game/build-latch/fix/legacy-prelude.js /workspace/game/build-latch/fix/cdp.cjs $R/old-webview/
cat > $R/README.md <<'MD'
# Papa Potato 0.3 source (Tough & J's Arcade 2.7.59) — GPL-3.0
- game/: the cartridge. `build.sh` joins head.html + sim.js (DOM-free simulation: pathing router, spill schedule, shop, upgrades, save v3 with v2/v1 migration) + game.js (renderer, HUD, scroll-safe command panel, shop, handbook booklet, objects table) into papa-potato-0.3.html. papa-potato-0.2.html and papa-potato-0.1-frozen.html are the untouched older versions (slots papa-potato:v02 / papa-potato:v01).
- arcade-2.7.59/: assemble the new cartridge into the live 2.7.58 bundle (every other cartridge byte-identical; `papa-potato:latest` replaced, `papa-potato:v02` added), verify, arcade regression, WebView-83 emulator script, run-final.sh (the sequential test pipeline).
- tests/: pass 1 mechanics (t-mech03: pathing proof, spill, peels, shop, migration), pass 2 GUI (t-gui03), pass 3 commands (t-cmd03), BUFF break/stress tests (t-buff03), A03s perf (t-perf03), long stress (t-stress03), screenshot script (t-shots03), real 0.1/0.2 save fixtures.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.56).
- No signing keys are included. Papa Potato has no secrets and no Latch code.
MD
rm -f $D/PapaPotato-0.3-source.zip; (cd $Z && python3 -c "import shutil; shutil.make_archive('$D/PapaPotato-0.3-source','zip','.','PapaPotato-0.3-source')")
# ---- whole-arcade source zip: the 2.7.58 one (Latch unlock value already placeholdered) with the Papa Potato folder + manifest swapped ----
A=/tmp/arc59src; rm -rf $A; mkdir -p $A; (cd $A && unzip -q $PREV/ToughAndJsArcade-2.7.58-source.zip)
rm -rf $A/source/papa-potato; mkdir -p $A/source/papa-potato; cp -r $R/* $A/source/papa-potato/
cp $P/app/AndroidManifest.xml $P/build-apk.sh $A/source/android-app/
cat > $A/README.md <<'MD'
# Tough & J's Arcade 2.7.59 (versionCode 97) — source (GPL-3.0)

2.7.59 is cumulative over 2.7.58 (Papa Potato 0.2 stays playable as slot papa-potato:v02, 0.1 as papa-potato:v01):
- NEW: Papa Potato 0.3 (latest) — source/papa-potato/ (game src, frozen 0.1 + 0.2 html, assembler/verify/tests, WebView-83 emulator scripts, README).
- Unchanged from 2.7.58: Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms: source/latch-ui, latch-manual, latch-build, funmotion-0.2.5, swarm-1.6.14, needle-ui, engine, android-app, old-webview.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
MD
grep -q 'REPLACE-WITH-UNLOCK-CODE' $A/source/latch-ui/src/lib/bench/model.ts && echo "placeholder present in model.ts"
rm -f $D/ToughAndJsArcade-2.7.59-source.zip; (cd $A && python3 -c "
import zipfile,os
z=zipfile.ZipFile('$D/ToughAndJsArcade-2.7.59-source.zip','w',zipfile.ZIP_DEFLATED)
for r,ds,fs in os.walk('.'):
    ds.sort()
    for f in sorted(fs):
        p=os.path.join(r,f); z.write(p,os.path.relpath(p,'.'))
z.close()")
cp -r $OLD/licenses/* $D/licenses/
echo staged
