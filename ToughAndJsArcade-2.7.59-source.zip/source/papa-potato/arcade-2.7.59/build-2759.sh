#!/bin/bash
# Full 2.7.59 build: game html -> arcade bundle (on top of the live 2.7.58 bundle) -> signed APK -> extract for tests.
set -euo pipefail
export PATH=/workspace/tools/jdk/bin:$PATH
B=/workspace/game/build-potato3; P=$B/package-2.7.59; B2=/workspace/game/build-potato2
bash $B/build.sh
node $B/assemble-2759.mjs $B/out/index.html > $B/out/assemble.log
cp $B/out/index.html $P/tough-and-js-arcade.html
rm -f $P/out/ToughAndJsArcade-2.7.59.apk $P/out/ToughAndJsArcade-2.7.59.apk.idsig
(cd $P && ./build-apk.sh) > $B/out/build-apk.log 2>&1
rm -rf /tmp/a59 && mkdir /tmp/a59 && (cd /tmp/a59 && unzip -q $P/out/ToughAndJsArcade-2.7.59.apk assets/index.html)
cp /tmp/a59/assets/index.html $B/test/index-from-apk.html
node -e 'const fs=require("fs"),vm=require("vm");const t=fs.readFileSync(process.argv[1],"utf8");const i=t.indexOf("const GAME_SRC="),j=t.indexOf("// END_PACKED_GAME_SRC");const G=vm.runInNewContext(t.slice(i,j)+"\nGAME_SRC;");fs.writeFileSync(process.argv[2],G["papa-potato:latest"]);fs.writeFileSync(process.argv[3],G["papa-potato:v02"]);fs.writeFileSync(process.argv[4],G["papa-potato:v01"])' $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v02-from-apk.html $B/test/papa-potato-v01-from-apk.html
cmp $B/test/papa-potato-from-apk.html $B/out/papa-potato-0.3.html
cmp $B/test/papa-potato-v02-from-apk.html $B2/out/papa-potato-0.2.html
cmp $B/test/papa-potato-v01-from-apk.html $B2/out/papa-potato-0.1-frozen.html
cmp $B/test/index-from-apk.html $B/out/index.html
mkdir -p $B/evidence
sha256sum $P/out/ToughAndJsArcade-2.7.59.apk $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v02-from-apk.html $B/test/papa-potato-v01-from-apk.html | tee $B/evidence/tested-artifacts.sha256
