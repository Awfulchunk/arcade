// Arcade 2.7.59 bundle (taken out of the APK): Papa Potato 0.3 (latest) + 0.2 (v02) + 0.1 (v01) + every 2.7.56 cartridge (FunMotion, Needle, Latch 2.1/2.0/1.1/1, Swarm 1.6.14/1.6.13). 0 JS errors.
const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy-no-user-gesture-required", "--autoplay-policy=no-user-gesture-required", "--allow-file-access-from-files"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, d); };
  const page = async () => {
    const p = await b.newPage(); const errs = [];
    p.on("pageerror", (e) => errs.push("shell: " + e.message));
    await p.setViewport({ width: 360, height: 800, isMobile: true, hasTouch: true });
    await p.evaluateOnNewDocument(() => {
      const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc");
      Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } });
    });
    await p.goto("file:///workspace/game/build-potato3/test/index-from-apk.html"); await sleep(1500);
    return { p, errs };
  };
  const { p, errs } = await page();
  await p.screenshot({ path: "/workspace/game/build-potato3/test/out/arcade-reg/00-menu.png" });
  const info = await p.evaluate(() => {
    const latch = GAMES.find((x) => x.id === "latch");
    const sw = GAMES.find((x) => x.id === "swarm");
    const fm = GAMES.find((x) => x.id === "funmotion");
    return {
      latch: latch.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      swarm: sw.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      funmotion: fm.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      has: ["funmotion", "needle", "latch", "swarm"].map((id) => GAMES.findIndex((x) => x.id === id))
    };
  });
  ok("GAMES has funmotion, needle, latch, swarm (2.7.56 cartridges still there)", info.has.every((i) => i >= 0), JSON.stringify(info.has));
  ok("Latch picker v1 / v1.1 / v2.0 kept / v2.1 default", info.latch.length === 4 && /^latest=v2\.1.*\(default\)/.test(info.latch[3]) && /^v20=v2\.0/.test(info.latch[2]) && !/default/.test(info.latch[2]) && /^v11=v1\.1/.test(info.latch[1]) && /^v1=/.test(info.latch[0]), info.latch.join(" | "));
  ok("FunMotion picker v0.2.5 latest (default) + v024 kept", info.funmotion.some((s) => /^latest=v0\.2\.5.*\(default\)/.test(s)) && info.funmotion.some((s) => /^v024=v0\.2\.4/.test(s)), info.funmotion.join(" | "));
  ok("Swarm picker v1.6.14 latest (default) + v1613 kept", info.swarm.some((s) => /^latest=v1\.6\.14.*\(default\)/.test(s)) && info.swarm.some((s) => /^v1613=v1\.6\.13/.test(s)), info.swarm.slice(-4).join(" | "));
  const run = async (id, verId, check, shot) => {
    await p.evaluate((id, verId) => { const i = GAMES.findIndex((g) => g.id === id); const G = GAMES[i]; if (verId) ARCADE.launch(i, verId); else ARCADE.launchCard(i); }, id, verId);
    await sleep(3500);
    const fr = p.frames().find((f) => f !== p.mainFrame());
    let res = { loaded: false };
    if (fr) res = await fr.evaluate(check).catch((e) => ({ loaded: false, err: e.message }));
    const ferrs = fr ? await fr.evaluate(() => window.__errs || ["no capture"]).catch(() => ["eval failed"]) : ["no frame"];
    await p.screenshot({ path: `/workspace/game/build-potato3/test/out/arcade-reg/${shot}.png` });
    ok(`${id}${verId ? ":" + verId : ""} launches, 0 JS errors`, res.loaded && ferrs.length === 0, JSON.stringify({ ...res, errs: ferrs }).slice(0, 400));
    await p.evaluate(() => ARCADE.back()); await sleep(800);
    return fr;
  };
  await run("funmotion", null, () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, ver: (document.documentElement.innerHTML.match(/0\.2\.\d/) || [])[0], tutorial: /Tutorial/i.test(document.body.innerText) || !!document.querySelector("[data-tutorial],#tutorial,button") && [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01-funmotion");
  await run("funmotion", "v024", () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, tutorial: [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01b-funmotion-v024");
  await run("needle", null, () => ({ loaded: document.body.innerText.length > 20, text: document.body.innerText.slice(0, 60) }), "02-needle");
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "latch"); ARCADE.launchCard(i); }); await sleep(2500);
  let fr = p.frames().find((f) => f !== p.mainFrame());
  const v2 = await fr.evaluate(async () => { const vtr = !!document.querySelector("main.vtr"); const book = !!document.querySelector("[data-manual-open]") || /Owner/.test(document.documentElement.innerHTML); const qm = document.querySelectorAll(".qm").length; const s = document.querySelector("[data-sample]"); if (s) s.click(); await new Promise((r) => setTimeout(r, 1800)); return { vtr, qm, pic: !!document.querySelector(".vf canvas.pic"), osd: document.querySelector(".osd.obl") && document.querySelector(".osd.obl").textContent, ver: document.body.innerText.includes("VTR"), book }; });
  const e2 = await fr.evaluate(() => window.__errs);
  await p.screenshot({ path: "/workspace/game/build-potato3/test/out/arcade-reg/03-latch-v2.1.png" });
  ok("latch v2.1 (default) = VTR-1 UI with the Owner's Manual, no ? badges, 0 errors", v2.vtr && v2.book && v2.qm === 0 && e2.length === 0, JSON.stringify({ ...v2, errs: e2 }));
  // open the book inside the real arcade frame: MENU > MANUAL, turn a page, close
  const bk = await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); document.querySelector(".bar [aria-label=Menu]").click(); await w(300); const t = document.querySelector("[data-manual-open]"); if (!t) return { opened: false }; t.click(); await w(400); const m = document.querySelector(".lman"); const p1 = m && m.dataset.page; document.querySelector("[data-manual-next]").click(); await w(300); const p2 = m && m.dataset.page; document.querySelector("[data-manual-close]").click(); await w(300); return { opened: !!m, p1, p2, closed: !document.querySelector(".lman"), ver: /Latch 2\.1/.test(document.documentElement.innerHTML) }; });
  await p.screenshot({ path: "/workspace/game/build-potato3/test/out/arcade-reg/03b-latch-v2.1-after-book.png" });
  ok("latch v2.1 in the arcade: MENU › MANUAL opens p.1, Next → p.2, CLOSE closes", bk.opened && bk.p1 === "1" && bk.p2 === "2" && bk.closed, JSON.stringify(bk));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await run("latch", "v20", () => ({ loaded: !!document.querySelector("main.vtr") && document.querySelectorAll(".qm").length === 0 && !/data-manual-open|lman/.test(document.documentElement.innerHTML), vtr: !!document.querySelector("main.vtr") }), "03c-latch-v2.0-kept");
  await run("latch", "v11", () => ({ loaded: document.querySelectorAll(".qm").length > 5 && !document.querySelector("main.vtr"), qm: document.querySelectorAll(".qm").length }), "04-latch-v1.1");
  await run("latch", "v1", () => ({ loaded: document.body.innerText.length > 20 && !document.querySelector("main.vtr") }), "05-latch-v1");
  const swc = () => ({ loaded: !!document.querySelector("canvas"), ver: (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1] });
  await run("swarm", null, swc, "07-swarm-latest");
  await run("swarm", "v1613", swc, "08-swarm-v1613");
  // confirm versions from last two runs by a dedicated eval
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launchCard(i); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const latestVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const lerr = await fr.evaluate(() => window.__errs);
  ok("swarm latest is 1.6.14", latestVer === "1.6.14" && lerr.length === 0, JSON.stringify({ latestVer, errs: lerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launch(i, "v1613"); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const oldVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const oerr = await fr.evaluate(() => window.__errs);
  ok("swarm v1613 is 1.6.13", oldVer === "1.6.13" && oerr.length === 0, JSON.stringify({ oldVer, errs: oerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);

  // ===== Papa Potato 0.3 (latest) + 0.2 (v02) + 0.1 (v01) =====
  const B3 = "/workspace/game/build-potato3/test/out/arcade-reg/";
  const pi = await p.evaluate(() => GAMES.findIndex((g) => g.id === "papa-potato"));
  const card = await p.evaluate((pi) => { ARCADE.go(pi); const G = GAMES[pi]; return { title: G.title, prev: GAMES[pi - 1].id, n: GAMES.length, vers: G.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")) }; }, pi); await sleep(1200);
  const cardDom = await p.evaluate((pi) => { const els = [...document.querySelectorAll(".card")]; const el = els[pi]; if (!el) return null; const r = el.getBoundingClientRect(); return { text: el.innerText.slice(0, 160), visible: r.left > -10 && r.right < innerWidth + 10, idx: ARCADE.idx }; }, pi);
  await p.screenshot({ path: B3 + "10-menu-papa-potato-card.png" });
  ok("Papa Potato card in the menu (after Swarm): picker v0.1 + v0.2 (both kept, not default) + v0.3 default, centered when selected", pi >= 0 && card.title === "PAPA POTATO" && card.prev === "swarm" && card.vers.length === 3 && /^v01=v0\.1/.test(card.vers[0]) && /^v02=v0\.2/.test(card.vers[1]) && !/default/.test(card.vers[0] + card.vers[1]) && /^latest=v0\.3.*\(default\)/.test(card.vers[2]) && cardDom && /PAPA POTATO/.test(cardDom.text) && cardDom.visible && cardDom.idx === pi, JSON.stringify({ card, cardDom }));
  const fget = () => p.frames().find((f) => f !== p.mainFrame());
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3500);
  fr = fget();
  const pp3 = fr ? await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const t0 = PP.sim.s.t; await w(4000); return { ready: window.__PP_READY === true, ver: PP.version, brand: document.querySelector("#hud .brand b").innerText.replace(/\s+/g, " "), title: document.title, tags: [...document.querySelectorAll(".tag")].map((e) => e.textContent), boxes: document.querySelectorAll("#cmd .box").length, shop: !!document.getElementById("shopBtn"), help: !!document.getElementById("helpBtn"), ran: +(PP.sim.s.t - t0).toFixed(1), errs: window.__errs }; }) : { ready: false };
  await p.screenshot({ path: B3 + "11-papa-potato-0.3-in-arcade.png" });
  ok("Papa Potato 0.3 launches inside the arcade (default): HUD, 7 object labels, 8 boxes, SHOP + HELP buttons, clock runs, 0 JS errors", pp3.ready && pp3.ver === "0.3" && pp3.brand === "PAPA POTATO" && pp3.title === "Papa Potato 0.3" && pp3.tags.length === 7 && pp3.boxes === 8 && pp3.shop && pp3.help && pp3.ran > 3 && pp3.errs && pp3.errs.length === 0, JSON.stringify(pp3));
  // shop + booklet inside the arcade frame, by real taps in the page
  const sb = await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); PP.sim.s.coins = 50; document.getElementById("shopBtn").dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, pointerId: 1, clientX: 50, clientY: 50 })); document.getElementById("shopBtn").dispatchEvent(new PointerEvent("pointerup", { bubbles: true, pointerId: 1, clientX: 50, clientY: 50 })); await w(400); const s1 = PP.ovl(); PP.close(); await w(200); document.getElementById("helpBtn").dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, pointerId: 2, clientX: 60, clientY: 60 })); document.getElementById("helpBtn").dispatchEvent(new PointerEvent("pointerup", { bubbles: true, pointerId: 2, clientX: 60, clientY: 60 })); await w(400); const h1 = PP.ovl(); PP.flip(1); PP.flip(1); await w(500); const pg = PP.book().page; PP.close(); return { s1, h1, pg, errs: window.__errs }; });
  ok("0.3 in the arcade: SHOP and HELP booklet open from their buttons, the booklet flips, both close, 0 JS errors", sb.s1 === "shop" && sb.h1 === "help" && sb.pg === 2 && sb.errs.length === 0, JSON.stringify(sb));
  await fr.evaluate(() => { PP.sim.s.coins = 90; PP.sim.setBox("eat", 40); PP.sim.setBox("nap", 30); PP.sim.setBox("style", 2); PP.sim.buyFood(); PP.sim.buyUp("boots"); PP.sim.buyPotatoes(); PP.save(); });
  const before = await fr.evaluate(() => ({ eat: PP.sim.s.box.eat, nap: PP.sim.s.box.nap, style: PP.sim.s.box.style, food: PP.sim.s.food, coins: PP.sim.s.coins, boots: PP.sim.s.up.boots, cap: PP.sim.s.potCap }));
  await p.evaluate(() => ARCADE.peekBack(3000)); await sleep(200);
  await p.click("#back"); await sleep(250); await p.click("#back"); await sleep(1200);
  const exited = await p.evaluate(() => ({ inGame: ARCADE.inGame, frames: document.querySelectorAll("#game iframe").length, menuBack: !document.getElementById("menu").classList.contains("away") }));
  await p.screenshot({ path: B3 + "12-back-in-menu.png" });
  ok("Papa Potato exits cleanly with the ◀ Arcade button (frame removed, menu back)", !exited.inGame && exited.frames === 0 && exited.menuBack, JSON.stringify(exited));
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000); fr = fget();
  const back2 = await fr.evaluate(() => ({ eat: PP.sim.s.box.eat, nap: PP.sim.s.box.nap, style: PP.sim.s.box.style, food: PP.sim.s.food, coins: PP.sim.s.coins, boots: PP.sim.s.up.boots, cap: PP.sim.s.potCap, ui: [...document.querySelectorAll(".box .val")].map((e) => e.textContent), errs: window.__errs }));
  ok("relaunch from the menu: the 0.3 save came back (boxes, food, coins, upgrade, potato limit)", back2.eat === before.eat && back2.nap === before.nap && back2.style === 2 && back2.boots === 1 && back2.cap === before.cap && back2.food >= before.food - 1 && back2.coins >= before.coins && back2.errs.length === 0, JSON.stringify({ before, back2 }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  const lsRead = (k) => p.evaluate((k) => { const v = localStorage.getItem(k); return v === null ? null : v.length + ":" + v.slice(0, 40) + v.slice(-40); }, k);
  const k3before = await lsRead("papaPotato.save.v3"), k2start = await lsRead("papaPotato.save.v2");
  ok("0.3 wrote its own key (v3) and no v2/v1 key (fresh profile)", !!k3before && k2start === null && (await lsRead("papaPotato.save.v1")) === null, JSON.stringify({ v3: !!k3before, v2: k2start }));
  // ----- v02 slot: the real 0.2 -----
  await p.evaluate((pi) => ARCADE.launch(pi, "v02"), pi); await sleep(3500); fr = fget();
  const v02 = fr ? await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const t0 = PP.sim.s.t; await w(3000); PP.sim.s.coins = 23; PP.sim.setBox("eat", 25); PP.save(); return { ready: window.__PP_READY === true, ver: PP.version, title: document.title, boxes: document.querySelectorAll("#cmd .box").length, ran: +(PP.sim.s.t - t0).toFixed(1), errs: window.__errs }; }) : { ready: false };
  await p.screenshot({ path: B3 + "14-papa-potato-v02-in-arcade.png" });
  ok("v02 slot: the real Papa Potato 0.2 launches in the arcade (5 boxes, clock runs, 0 JS errors)", v02.ready && v02.ver === "0.2" && v02.title === "Papa Potato 0.2" && v02.boxes === 5 && v02.ran > 2 && v02.errs.length === 0, JSON.stringify(v02));
  const k3after = await lsRead("papaPotato.save.v3"), k2after = await lsRead("papaPotato.save.v2");
  ok("0.2 wrote only its own key (v2 now exists); the 0.3 save (v3) is byte-identical", !!k2after && k3after === k3before, JSON.stringify({ v2: !!k2after, v3same: k3after === k3before }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000); fr = fget();
  const back3 = await fr.evaluate(() => ({ ver: PP.version, eat: PP.sim.s.box.eat, migrated: PP.migrated, boots: PP.sim.s.up.boots, errs: window.__errs }));
  ok("back on 0.3: its own save wins over the 0.2 save (eat 40, boots lv1, not re-migrated)", back3.ver === "0.3" && back3.eat === 40 && back3.boots === 1 && !back3.migrated && back3.errs.length === 0, JSON.stringify(back3));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // ----- v01 slot -----
  const k2b = await lsRead("papaPotato.save.v2"), k3b = await lsRead("papaPotato.save.v3");
  await p.evaluate((pi) => ARCADE.launch(pi, "v01"), pi); await sleep(3500); fr = fget();
  const v01 = fr ? await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const t0 = PP.sim.s.t; await w(3000); PP.sim.s.coins = 17; PP.save(); return { ready: window.__PP_READY === true, ver: PP.version, title: document.title, boxes: document.querySelectorAll("#cmd .box").length, ran: +(PP.sim.s.t - t0).toFixed(1), errs: window.__errs }; }) : { ready: false };
  await p.screenshot({ path: B3 + "14b-papa-potato-v01-in-arcade.png" });
  ok("v01 slot: Papa Potato 0.1 still launches in the arcade (3 boxes, clock runs, 0 JS errors)", v01.ready && v01.ver === "0.1" && v01.title === "Papa Potato 0.1" && v01.boxes === 3 && v01.ran > 2 && v01.errs.length === 0, JSON.stringify(v01));
  ok("0.1 wrote only its own key (v1 exists); the 0.2 save (v2) and 0.3 save (v3) are byte-identical", !!(await lsRead("papaPotato.save.v1")) && (await lsRead("papaPotato.save.v2")) === k2b && (await lsRead("papaPotato.save.v3")) === k3b, "");
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // ----- migrations in the arcade -----
  const fx2 = fs.readFileSync("/workspace/game/build-potato3/test/fixtures/v2-save.json", "utf8");
  await p.evaluate((fx) => { localStorage.removeItem("papaPotato.save.v3"); localStorage.setItem("papaPotato.save.v2", fx); }, fx2);
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000); fr = fget();
  const mig2 = await fr.evaluate(() => ({ migrated: PP.migrated, ver: PP.sim.s.v, coins: PP.sim.s.coins, total: PP.sim.total(), errs: window.__errs }));
  const k2mig = await p.evaluate(() => localStorage.getItem("papaPotato.save.v2"));
  await p.screenshot({ path: B3 + "15-migrated-from-0.2.png" });
  ok("a real 0.2 save in the arcade: 0.3 migrates it (v3 state, coins kept, no potato lost/duplicated) and leaves the 0.2 key byte-identical", mig2.migrated === "0.2" && mig2.ver === 3 && mig2.coins >= 77 && mig2.errs.length === 0 && k2mig === fx2, JSON.stringify(mig2));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  const fx1 = fs.readFileSync("/workspace/game/build-potato3/test/fixtures/v1-save.json", "utf8");
  await p.evaluate((fx) => { localStorage.removeItem("papaPotato.save.v3"); localStorage.removeItem("papaPotato.save.v2"); localStorage.setItem("papaPotato.save.v1", fx); }, fx1);
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000); fr = fget();
  const mig1 = await fr.evaluate(() => ({ migrated: PP.migrated, ver: PP.sim.s.v, total: PP.sim.total(), errs: window.__errs }));
  const k1mig = await p.evaluate(() => localStorage.getItem("papaPotato.save.v1"));
  ok("a real 0.1 save only: 0.3 migrates it (v3 state) and leaves the 0.1 key byte-identical", mig1.migrated === "0.1" && mig1.ver === 3 && mig1.errs.length === 0 && k1mig === fx1, JSON.stringify(mig1));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // ----- old-WebView (legacy) path: force arcade.legacy=1 -----
  const p2 = await b.newPage(); const errs2 = []; p2.on("pageerror", (e) => errs2.push(e.message));
  await p2.setViewport({ width: 320, height: 568, isMobile: true, hasTouch: true });
  await p2.evaluateOnNewDocument(() => { try { localStorage.setItem("arcade.legacy", "1"); } catch (e) {} const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc"); Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get: d.get }); });
  await p2.goto("file:///workspace/game/build-potato3/test/index-from-apk.html"); await sleep(1500);
  const leg = async (ver, shot, want) => { await p2.evaluate((pi, ver) => { localStorage.removeItem("papaPotato.save.v3"); localStorage.removeItem("papaPotato.save.v2"); if (ver) ARCADE.launch(pi, ver); else ARCADE.launchCard(pi); }, pi, ver); await sleep(3500); const f = p2.frames().find((q) => q !== p2.mainFrame()); const r = await f.evaluate(() => ({ ready: window.__PP_READY === true, prelude: /TJ legacy prelude/.test(document.head.innerHTML), ver: PP.version, boxes: document.querySelectorAll("#cmd .box").length, errs: window.__errs, t: PP.sim.s.t })); await p2.screenshot({ path: B3 + shot }); ok(`legacy (old-WebView) variant ${want.name} launches at 320x568: prelude present, ${want.boxes} boxes, 0 JS errors`, r.ready && r.prelude && r.ver === want.ver && r.boxes === want.boxes && r.errs.length === 0 && errs2.length === 0, JSON.stringify({ r, errs2 })); await p2.evaluate(() => ARCADE.back()); await sleep(800); return f; };
  await leg(null, "13-papa-potato-0.3-legacy-320x568.png", { name: "0.3", ver: "0.3", boxes: 8 });
  await leg("v02", "16-papa-potato-v02-legacy-320x568.png", { name: "v02 (0.2)", ver: "0.2", boxes: 5 });
  await leg("v01", "16b-papa-potato-v01-legacy-320x568.png", { name: "v01 (0.1)", ver: "0.1", boxes: 3 });
  await p2.close();
  ok("arcade shell 0 JS errors", errs.length === 0, errs.join("; "));
  fs.writeFileSync(B3 + "arcade.json", JSON.stringify(R, null, 1));
  console.log(`arcade: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close();
  process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
