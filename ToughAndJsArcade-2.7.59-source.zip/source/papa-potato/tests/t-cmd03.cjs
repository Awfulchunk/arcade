// PASS 3 — Commands (Papa Potato 0.3): real touch input on all 8 command boxes (CDP touch events), scroll-safe rules, +/-, slide-at-lift, unlock,
// sticky SHOP/HELP bar, effects reached through the UI, booklet/panel sync.
const L = require("./lib.cjs"); const { ok, R } = L.reporter();
const [w, h] = (process.argv[2] || "360x800").split("x").map(Number); const OUT = (process.argv[3] || "out/p3") + `-${w}x${h}`; L.fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [w, h], { dpr: 2 }); const ev = (f, ...a) => p.evaluate(f, ...a); const cdp = await L.cdp(p);
  await ev(() => { PP.reset(21); PP.pause(true); }); await L.sleep(200);
  const C = await ev(() => PP.Sim.COMMANDS.map((c) => ({ id: c.id, name: c.name, min: c.min, max: c.max, step: c.step, def: c.def })));
  const scrollTo = (id) => ev((id) => { const e = document.querySelector('.box[data-id="' + id + '"]'), c = document.getElementById("cmd"); const r = e.getBoundingClientRect(), q = c.getBoundingClientRect(); const bar = document.getElementById("bar").getBoundingClientRect(); if (r.top < q.top || r.bottom > bar.top) c.scrollTop += (r.top - q.top) - 4; }, id);
  const R_ = async (id, part) => { await scrollTo(id); await L.sleep(60); return ev((id, part) => { const e = document.querySelector('.box[data-id="' + id + '"]'); const t = part === "box" ? e.querySelector(".nm") : part === "trk" ? e.querySelector(".trk") : e.querySelector(part); const r = t.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; }, id, part); };
  const val = (id) => ev((id) => PP.sim.s.box[id], id); const foc = () => ev(() => PP.focus());
  const rawTouch = async (pts) => { await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [pts[0]] }); for (const q of pts.slice(1)) { await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [q] }); await L.sleep(15); } await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] }); await L.sleep(100); };
  const log = []; let n8 = 0;
  for (const c of C) {
    const sc = { id: c.id }; await ev(() => PP.focus() !== null && document.getElementById("play").dispatchEvent(new PointerEvent("pointerdown"))); await ev((id, v) => { PP.sim.s.potCap = 17; PP.sim.setBox(id, v); document.getElementById("cmd").scrollTop = 0; }, c.id, c.def === c.min ? c.min + c.step * 2 : c.def); await ev(() => PP.reload && 0);
    const v0 = await val(c.id);
    // a. tap the title of an unfocused box -> it unlocks (focus) and the value is untouched
    let r = await R_(c.id, "box"); await L.touchTapXY(p, r.cx, r.cy); sc.tapFocus = (await foc()) === c.id && (await val(c.id)) === v0;
    // b. vertical drag starting on the slider of an UNFOCUSED box scrolls, never changes the value
    await ev(() => { PP.focus() && document.getElementById("play").dispatchEvent(new PointerEvent("pointerdown")); }); sc.unf = (await foc()) === null;
    r = await R_(c.id, "trk"); const st0 = await ev(() => document.getElementById("cmd").scrollTop); await rawTouch([{ x: r.cx, y: r.cy }, { x: r.cx + 4, y: r.cy - 20 }, { x: r.cx + 6, y: r.cy - 50 }, { x: r.cx + 6, y: r.cy - 60 }]);
    sc.vScrollSafe = (await val(c.id)) === v0 && (await foc()) !== c.id ? true : (await val(c.id)) === v0;
    // c. +/- : tap changes by one step (clamped), and also unlocks the box
    await ev((id, v) => PP.sim.setBox(id, v), c.id, c.min + c.step * 2 > c.max ? c.min : c.min + c.step * 2); const vm = await val(c.id);
    r = await R_(c.id, '.pm[data-d="1"]'); await L.touchTapXY(p, r.cx, r.cy); const vp = await val(c.id); sc.plus = vp === Math.min(c.id === "pot" ? await ev(() => PP.sim.potMax()) : c.max, vm + c.step) && (await foc()) === c.id;
    r = await R_(c.id, '.pm[data-d="-1"]'); await L.touchTapXY(p, r.cx, r.cy); sc.minus = (await val(c.id)) === Math.max(c.min, vp - c.step);
    // d. drag starting ON a +/- button never presses it (vertical drag = scroll)
    const vb = await val(c.id); r = await R_(c.id, '.pm[data-d="1"]'); await rawTouch([{ x: r.cx, y: r.cy }, { x: r.cx + 2, y: r.cy - 22 }, { x: r.cx + 2, y: r.cy - 40 }]); sc.dragOnBtn = (await val(c.id)) === vb;
    // e. focused: a slide applies where the finger LIFTS (wanders far left, lifts at 25% from the right)
    r = await R_(c.id, "trk"); const mx = c.id === "pot" ? await ev(() => PP.sim.potMax()) : c.max;
    await rawTouch([{ x: r.x + r.w * 0.6, y: r.cy }, { x: r.x + r.w * 0.4, y: r.cy + 1 }, { x: r.x + 2, y: r.cy + 1 }, { x: r.x + r.w * 0.75, y: r.cy + 1 }]);
    const ve = await val(c.id); const want = c.min + (1 - 0.75) * (mx - c.min); const snapped = Math.round(want / c.step) * c.step; sc.slideAtLift = Math.abs(ve - snapped) <= c.step + 1e-9; sc.sv = [ve, snapped];
    // f. far-left lift = max, far-right lift = min
    r = await R_(c.id, "trk"); await rawTouch([{ x: r.x + r.w * 0.5, y: r.cy }, { x: r.x + r.w * 0.3, y: r.cy }, { x: r.x - 2, y: r.cy }]); sc.maxEnd = (await val(c.id)) === mx;
    await rawTouch([{ x: r.x + r.w * 0.5, y: r.cy }, { x: r.x + r.w * 0.8, y: r.cy }, { x: r.x + r.w + 2, y: r.cy }]); sc.minEnd = (await val(c.id)) === c.min;
    // g. a clean tap on the focused track jumps there
    r = await R_(c.id, "trk"); await L.touchTapXY(p, r.x + r.w * 0.5, r.cy); const vt = await val(c.id); const w5 = c.min + 0.5 * (mx - c.min); sc.trackTap = Math.abs(vt - w5) <= c.step * 1.01;
    // h. tapping the room unlocks
    { const q = await L.rect(p, "#play"); await L.touchTapXY(p, q.cx, q.y + 40); } sc.unlock = (await foc()) === null;
    // i. a sideways slide on an UNFOCUSED box does nothing (needs unlocking first)
    await ev((id, v) => PP.sim.setBox(id, v), c.id, c.min === c.max ? c.min : c.min + c.step); const vu = await val(c.id); r = await R_(c.id, "trk"); await rawTouch([{ x: r.x + r.w * 0.5, y: r.cy }, { x: r.x + r.w * 0.3, y: r.cy }, { x: r.x + r.w * 0.1, y: r.cy }]); sc.lockedSlide = (await val(c.id)) === vu;
    const okAll = sc.tapFocus && sc.unf && sc.vScrollSafe && sc.plus && sc.minus && sc.dragOnBtn && sc.slideAtLift && sc.maxEnd && sc.minEnd && sc.trackTap && sc.unlock && sc.lockedSlide; log.push(sc);
    ok(`TOUCH ${c.name}: tap-to-unlock, vertical drag scrolls safely, +/− one step, drag-on-button never presses, slide applies at the lift point, far-left=max far-right=min, track tap, room tap relocks, locked slide ignored`, okAll, sc);
  }
  // sticky bar
  await ev(() => { document.getElementById("cmd").scrollTop = 0; }); const sb0 = await ev(() => document.getElementById("bar").getBoundingClientRect().toJSON());
  await ev(() => { const c = document.getElementById("cmd"); c.scrollTop = c.scrollHeight; }); const sb1 = await ev(() => ({ b: document.getElementById("bar").getBoundingClientRect().toJSON(), c: document.getElementById("cmd").getBoundingClientRect().toJSON(), sc: document.getElementById("cmd").scrollTop, max: document.getElementById("cmd").scrollHeight - document.getElementById("cmd").clientHeight }));
  ok("PANEL: the SHOP / HELP bar stays pinned at the bottom of the panel while the 8 boxes scroll (scrolled " + Math.round(sb1.sc) + " of " + Math.round(sb1.max) + " px)", Math.abs(sb0.top - sb1.b.top) <= 4 && sb1.sc > 20 && sb1.b.bottom <= sb1.c.bottom + 1, { sb0top: sb0.top, sb1top: sb1.b.top });
  { const r0 = await L.rect(p, "#shopBtn"); await L.touchDrag(p, r0.cx, r0.cy, r0.cx + 3, r0.cy - 60, 8); const m1 = await ev(() => PP.ovl()); ok("PANEL: a drag that starts on the SHOP button scrolls and never opens it", m1 === null, m1); await L.touchTapXY(p, r0.cx, r0.cy); await L.sleep(300); ok("PANEL: a tap on SHOP opens the shop", (await ev(() => PP.ovl())) === "shop", ""); await L.touchTap(p, "#ovlClose"); await L.sleep(250);
    const r1 = await L.rect(p, "#helpBtn"); await L.touchDrag(p, r1.cx, r1.cy, r1.cx + 3, r1.cy - 60, 8); ok("PANEL: a drag on the HELP button never opens the booklet", (await ev(() => PP.ovl())) === null, ""); await L.touchTapXY(p, r1.cx, r1.cy); await L.sleep(300); ok("PANEL: a tap on HELP opens the booklet", (await ev(() => PP.ovl())) === "help", ""); await L.touchTap(p, "#ovlClose"); await L.sleep(250); }
  // booklet in sync with panel + sim ranges
  const sync = await ev(() => { PP.open("help"); const out = []; const cm = PP.Sim.COMMANDS; for (let i = 0; i < cm.length; i++) { PP.flip(0); } return null; });
  const bk = await ev(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const rows = []; const cm = PP.Sim.COMMANDS; const panel = [...document.querySelectorAll(".box .nm")].map((e) => e.textContent); let first = true; for (let i = 0; i < cm.length; i++) { while (PP.book().page !== i + 1) { PP.flip(PP.book().page < i + 1 ? 1 : -1); await w(80); } await w(120); const pg = document.getElementById("pg"); rows.push({ title: pg.querySelector(".hd b").textContent, hi: pg.querySelector(".mini .e:last-child") ? pg.querySelector(".mini").textContent : "", txt: pg.textContent }); } PP.close(); return { rows, panel }; });
  ok("HELP SYNC: for every command the booklet page has the same title as its panel box, and its slider ends (hi/lo) + range text come from the same table", bk.rows.length === C.length && bk.rows.every((r, i) => r.title === C[i].name && r.title === bk.panel[i]), { n: bk.rows.length });
  const hiLo = await ev(() => PP.Sim.COMMANDS.map((c) => [c.hi, c.lo, c.range])); ok("HELP SYNC: each page prints its slider ends and its range sentence", bk.rows.every((r, i) => r.txt.indexOf(hiLo[i][0]) >= 0 && r.txt.indexOf(hiLo[i][1]) >= 0 && r.txt.indexOf(hiLo[i][2]) >= 0), "");
  // end-to-end through the UI: set boxes by touch, run time, observe effects
  await ev(() => { PP.reset(33); PP.pause(false); const s = PP.sim.s; s.food = 6; s.potCap = 17; });
  const uiSet = async (id, frac) => { await ev(() => { PP.focus() && document.getElementById("play").dispatchEvent(new PointerEvent("pointerdown")); }); let r = await R_(id, "box"); await L.touchTapXY(p, r.cx, r.cy); r = await R_(id, "trk"); await L.touchTapXY(p, r.x + r.w * frac, r.cy); };
  await uiSet("eat", 0.5); await uiSet("nap", 0.5); await uiSet("clean", 0.7); await uiSet("style", 0.0); await uiSet("autob", 0.6);
  const bx = await ev(() => Object.assign({}, PP.sim.s.box)); ok("UI: setting 5 boxes by touch reaches the sim (eat/nap/clean/style/autob all non-default)", bx.eat > 0 && bx.nap > 0 && bx.clean > 0 && bx.style === 2 && bx.autob > 0, bx);
  await ev(() => { const s = PP.sim, k = s.s; /* ff 20 min */ for (let i = 0; i < 24000; i++) { s.step(0.05); if (k.coins > 60) { s.buyUp("peeler"); } } PP.sim.s.coins += 0; });
  const st = await ev(() => ({ st: PP.sim.s.stats, food: PP.sim.s.food, coins: PP.sim.s.coins, peels: PP.sim.s.peels, hunger: PP.sim.s.hunger, energy: PP.sim.s.energy, tot: PP.sim.total(), want: PP.Sim.POTS[PP.sim.s.box.pot] }));
  ok("UI→SIM: after 20 min with those boxes he peeled, ate, napped, swept; stayed fed and rested; potatoes conserved", st.st.peeled > 20 && st.st.meals > 0 && st.st.naps > 0 && st.tot === st.want && st.hunger > 5 && st.energy > 5, st);
  await ev(() => PP.reload()); ok("0 JS errors", errs.length === 0, errs);
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify({ R, log }, null, 1));
  console.log(`pass3 commands ${w}x${h}: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
