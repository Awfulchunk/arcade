// PASS 2 — Visuals / GUI at one viewport (Papa Potato 0.3): room fit (no scroll), labels, object visibility, peels landing flat, return-chute spill,
// pile shading + spread at low/max counts, HUD fit, 44 px targets, shop + help booklet screens with real touch input, save keys.
const L = require("./lib.cjs"); const { ok, R } = L.reporter();
const [w, h] = (process.argv[2] || "360x800").split("x").map(Number); const DPR = +(process.argv[4] || 2); const OUT = (process.argv[3] || "out/p2") + `-${w}x${h}`; L.fs.mkdirSync(OUT, { recursive: true });
const PX = `
  window.__px = (x, y) => { const c = PP.cv(), d = c.getContext("2d").getImageData(Math.max(0, Math.min(c.width - 1, x | 0)), Math.max(0, Math.min(c.height - 1, y | 0)), 1, 1).data; return [d[0], d[1], d[2]]; };
  window.__isPotato = (c) => c[0] - c[1] >= 24 && c[0] > 50 && c[1] > 20 && c[2] < 120 && c[0] < 235 && !(c[0] > 200 && c[1] > 170);`;
(async () => {
  const b = await L.browser(); let { p, errs } = await L.open(b, [w, h], { dpr: DPR }); let errs2 = []; await p.evaluate(PX);
  const frame = () => p.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))));
  // ---------- room fit ----------
  await p.evaluate(() => PP.reset(101)); await L.sleep(800);
  const fit = await p.evaluate(() => { const l = PP.layout(), S = PP.Sim; const de = document.documentElement; return { l, noScroll: de.scrollHeight <= innerHeight + 1 && de.scrollWidth <= innerWidth + 1 && document.body.scrollHeight <= innerHeight + 1, vw: innerWidth, vh: innerHeight, whole: l.offX >= -0.01 && l.offY >= -0.01 && l.offX + l.fitW <= l.W + 0.01 && l.offY + l.fitH <= l.H + 0.01, ratioRoom: S.RH / S.RW, pr: document.getElementById("play").getBoundingClientRect().toJSON() }; });
  ok("ROOM: the whole 100×240 room is inside the play area (nothing cut off), page does not scroll", fit.noScroll && fit.whole, { fit: { W: fit.l.W, H: fit.l.H, k: +fit.l.k.toFixed(3), offX: +fit.l.offX.toFixed(1), offY: +fit.l.offY.toFixed(1), fitW: +fit.l.fitW.toFixed(1), fitH: +fit.l.fitH.toFixed(1) }, vw: fit.vw, vh: fit.vh });
  const fillPct = Math.max(fit.l.fitW / fit.l.W, fit.l.fitH / fit.l.H);
  ok("ROOM: taller than 0.2 (aspect 1 : 2.4) and fills the play area on its limiting side (≥ 97%)", fit.ratioRoom === 2.4 && fillPct >= 0.97, { aspect: fit.ratioRoom, fill: +fillPct.toFixed(3) });
  const sizes = await p.evaluate(() => { const l = PP.layout(), SC = innerWidth >= 0 ? 1 : 1; const css = (u) => u * l.k * (document.getElementById("play").getBoundingClientRect().width / l.W); return { headCss: css(12), tableW: css(34), tableH: css(18), unitCss: css(1) }; });
  ok("READABLE: Papa's head ≥ 9 css px across, the table ≥ 55 px wide (45 on 320×568)", sizes.headCss >= (h <= 600 ? 8 : 9) && sizes.tableW >= (h <= 600 ? 45 : 55), sizes);
  await p.screenshot({ path: `${OUT}/01-full-room.png` });
  // ---------- labels ----------
  await p.evaluate(() => PP.labels(8000, true)); await L.sleep(500);
  const tg = await p.evaluate(() => { const r = PP.tagRects(), pr = document.getElementById("play").getBoundingClientRect(), out = { bad: [], n: 0 }; const ids = Object.keys(r); out.n = ids.length;
    for (const id of ids) { const q = r[id]; if (!q.on) out.bad.push(id + " off"); if (q.x < pr.left - 0.5 || q.y < pr.top - 0.5 || q.x + q.w > pr.right + 0.5 || q.y + q.h > pr.bottom + 0.5) out.bad.push(id + " outside play"); }
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) { const a = r[ids[i]], c = r[ids[j]]; if (a.x < c.x + c.w && c.x < a.x + a.w && a.y < c.y + c.h && c.y < a.y + a.h) out.bad.push(ids[i] + "×" + ids[j] + " overlap"); }
    out.rects = r; return out; });
  ok("LABELS: SHIP IN, RETURN, PEEL TABLE, BED, FOOD, SEAT, POTATOES all show, inside the play area, none overlapping each other", tg.n === 7 && tg.bad.length === 0, tg.bad);
  await p.evaluate(() => PP.labels(600, true)); await L.sleep(1400); const off = await p.evaluate(() => Object.values(PP.tagRects()).every((q) => !q.on)); ok("LABELS: fade out after their time (first view / tap), come back on a tap of the room", off, {});
  { const r = await L.rect(p, "#play"); await L.touchTapXY(p, r.cx, r.cy); await L.sleep(500); } const on2 = await p.evaluate(() => Object.values(PP.tagRects()).every((q) => q.on)); ok("LABELS: a tap on the room shows every label", on2, {});
  // ---------- objects visible with contrast ----------
  await p.evaluate(() => { PP.pause(true); const s = PP.sim.s; s.g.x = 0.9; s.g.y = 0.03; s.g.act = null; s.g.hold = null; }); await frame(); await frame();
  const obj = await p.evaluate(() => { const l = PP.layout(), G = PP.Sim.GEO, px = (x, y) => window.__px(x * l.k + l.offX, y * l.k + l.offY); const floor = px(15, 60); const d = (a, c) => Math.abs(a[0] - c[0]) + Math.abs(a[1] - c[1]) + Math.abs(a[2] - c[2]);
    const pts = { table: px(50, 80), cooler: px((G.cooler.x0 + G.cooler.x1) / 2, (G.cooler.y0 + G.cooler.y1) / 2 + 2), stool: px(G.stool.x, G.stool.y), bed: px(G.mat.x + 4, G.mat.y), shipChute: px(50, 10), returnPipe: px(G.ret.mouthX + 8, G.ret.y) };
    const out = {}; for (const k of Object.keys(pts)) out[k] = d(pts[k], floor); return { out, floor }; });
  ok("OBJECTS: table, cooler, stool, bed, SHIP IN chute and RETURN pipe all clearly differ from the floor colour (contrast ≥ 60)", Object.values(obj.out).every((v) => v >= 60), obj.out);
  // ---------- peels hop off and land FLAT, stay as mess ----------
  await p.evaluate(() => { PP.pause(false); PP.reset(7); const s = PP.sim.s; s.box.eat = 0; s.box.nap = 0; s.box.clean = 0; s.box.style = 2; s.food = 9; });
  const seen = []; const t0 = Date.now(); let landed = 0;
  while (Date.now() - t0 < 40000 && seen.length < 14) { const f = await p.evaluate(() => { PP.sim.s.hunger = 100; PP.sim.s.energy = 100; return PP.flightsNow(); }); for (const q of f) { if (!seen.find((s) => s.slot === q.slot)) seen.push({ ...q, maxT: q.t, first: q.t }); else seen.find((s) => s.slot === q.slot).maxT = Math.max(seen.find((s) => s.slot === q.slot).maxT, q.t); } await L.sleep(25); }
  await L.sleep(900);
  const pe = await p.evaluate((slots) => { const l = PP.layout(), out = []; for (const sl of slots) { const m = PP.messPos(sl); if (!m) { out.push({ sl, none: 1 }); continue; } const x = m.x * l.k + l.offX, y = m.y * l.k + l.offY; let hit = 0; for (let dx = -3; dx <= 3; dx++) for (let dy = -2; dy <= 2; dy++) { const c = window.__px(x + dx, y + dy); if (c[0] - c[1] >= 20 && c[0] > 150) hit++; } out.push({ sl, hit, ux: +m.x.toFixed(1), uy: +m.y.toFixed(1) }); } return { out, fl: PP.flightsNow().length, peels: PP.sim.s.peels }; }, seen.map((s) => s.slot));
  const T = 1; const ex = await p.evaluate(() => ({ T: PP.Sim.GEO.table, mess: PP.Sim.GEO.mess, WALL: PP.Sim.GEO.WALL }));
  ok(`PEELS: ${seen.length} peel flights observed while he peels; every one lands within 0.75 s (a short hop, not a fall) and none is left in the air`, seen.length >= 8 && seen.every((s) => s.maxT <= 0.75) && pe.fl <= 3, { n: seen.length, maxFlight: Math.max(...seen.map((s) => s.maxT)).toFixed(2), airborneNow: pe.fl });
  ok("PEELS: each landed peel is on the floor in the mess layer where its flight ended (peel-coloured pixels at the slot) and stays", pe.out.every((o) => o.hit >= 2), pe.out.slice(0, 8));
  const geo = await p.evaluate((n) => { const out = []; for (let i = 0; i < n; i++) { const m = PP.messPos(i); if (m) out.push([m.x, m.y]); } return out; }, 140);
  const T0 = ex.T; const nearHim = geo.slice(0, 60).every(([x, y]) => Math.hypot(x - 50, y - 99) <= 40) && geo.every(([x, y]) => y > T0.y1 && x > ex.WALL && x < 100 - ex.WALL);
  ok("PEELS: the first 60 landing slots are within 40 units of where he peels; all 140 slots are on the floor south of the table, inside the room", geo.length === 140 && nearHim, { n: geo.length });
  await p.screenshot({ path: `${OUT}/02-peels-landed.png` });
  // ---------- return chute spill (frozen-time scan) ----------
  await p.evaluate(() => { PP.reset(9); const s = PP.sim.s; s.box.eat = 0; s.box.nap = 0; PP.pause(true); s.g.act = { t: "idle", d: 9999, e: 0, label: "x" }; s.g.x = 0.12; s.g.y = 0.45; PP.sim.setBox("pot", 8); s.chute = 6; s.pile -= 6; PP.sim.startSuck(); });
  const sched = await p.evaluate(() => { const k = PP.sim.s.suck; const sc = PP.Sim.spill(k.t0, k.n); return { ex: sc.ex.map((x) => x - k.t0), ld: sc.ld.map((x) => x - k.t0) }; });
  const rec = await p.evaluate(() => new Promise((res) => { PP.pause(false); const out = [], t00 = performance.now(); const G = PP.Sim.GEO; const tick = () => { const v = PP.retView(), l = PP.layout(); const fr = []; for (const q of v) { if (q.p < 0) { fr.push({ j: q.j, p: -1 }); continue; } const c = window.__px(q.x, q.y - q.z); fr.push({ j: q.j, p: q.p, x: q.x, y: q.y, z: q.z, inPipe: q.inPipe, mouth: q.mouthX, tx: q.tx, ty: q.ty, pot: window.__isPotato(c) }); }
    out.push({ ms: performance.now() - t00, fr, suck: !!PP.sim.s.suck }); if (performance.now() - t00 < 8000 && PP.sim.s.suck) requestAnimationFrame(tick); else res(out); }; requestAnimationFrame(tick); }));
  const ser = (j) => rec.map((r) => r.fr.find((q) => q.j === j)).filter(Boolean); const s0 = ser(0), s5 = ser(5);
  const firstDrawn = (s) => s.findIndex((q) => q.p >= 0);
  ok("SPILL: before its exit time a potato is NOT drawn (p<0) — nothing pops in; potato 0 shows up first, potato 5 later", firstDrawn(s0) > 2 && firstDrawn(s5) > firstDrawn(s0), { f0: firstDrawn(s0), f5: firstDrawn(s5), frames: rec.length });
  const d0 = s0.filter((q) => q.p >= 0); const out0 = d0.find((q) => !q.inPipe);
  ok("SPILL: the first frame a potato is drawn it is inside the return-chute pipe at the mouth (clipped), and it then moves OUT to the west of the mouth", d0[0].inPipe && Math.abs(d0[0].x - d0[0].mouth) <= 14 && out0 && out0.x < out0.mouth, { first: d0[0], firstOut: out0 });
  const fl0 = d0.filter((q) => !q.inPipe && q.p < 0.97); const pixOk = fl0.filter((q) => q.pot).length;
  ok("SPILL: while tumbling, the potato is really on the canvas (potato-coloured pixel at its drawn position in ≥ 80% of frames)", fl0.length >= 12 && pixOk / fl0.length >= 0.8, { frames: fl0.length, potatoPixels: pixOk });
  let peaks = 0; for (const s of [ser(0), ser(1), ser(2)]) { const zs = s.filter((q) => q.p >= 0 && !q.inPipe).map((q) => q.z); for (let i = 1; i < zs.length - 1; i++) if (zs[i] > zs[i - 1] && zs[i] >= zs[i + 1] && zs[i] > 0.8) peaks++; }
  const lastQ = d0[d0.length - 1];
  ok("SPILL: it hops/tumbles (≥ 3 bounce peaks over 3 potatoes) then rests exactly on its pile slot", peaks >= 3 && Math.abs(lastQ.x - lastQ.tx) < 2 && Math.abs(lastQ.y - lastQ.ty) < 2 && lastQ.z < 0.6, { peaks, lastQ });
  const inPipeDrawn = d0.filter((q) => q.inPipe).length;
  ok("SPILL: it spends time inside the pipe before emerging (≥ 2 frames clipped in the pipe), so it visibly comes OUT of the chute", inPipeDrawn >= 2, { inPipeDrawn });
  ok("SPILL: the 6 potatoes of a batch leave at different times (distinct, 0.1–0.65 s apart) and each rests on its own slot", sched.ex.every((x, i) => i === 0 || (x - sched.ex[i - 1] >= 0.0999 && x - sched.ex[i - 1] <= 0.6501)) && new Set(sched.ex.map((x) => x.toFixed(2))).size === 6 && rec.length > 100, { ex: sched.ex, ld: sched.ld });
  await p.evaluate(() => { PP.reset(9); const s = PP.sim.s; s.box.eat = 0; s.box.nap = 0; s.g.act = { t: 'idle', d: 9999, e: 0, label: 'x' }; s.g.x = 0.12; s.g.y = 0.45; PP.sim.setBox('pot', 8); s.chute = 6; s.pile -= 6; PP.sim.startSuck(); }); await L.sleep(2100); await p.screenshot({ path: `${OUT}/03-return-chute-spilling.png` });
  // ---------- pile: spread + shading at low / default / high / max ----------
  const pileM = async (n) => { await p.evaluate((nn) => { PP.pause(true); PP.reset(3); const s = PP.sim.s; s.potCap = 17; s.box.pot = PP.Sim.POTS.indexOf(nn); PP.sim.retarget(); s.g.x = 0.88; s.g.y = 0.05; s.g.act = { t: "idle", d: 9999, e: 0, label: "x" }; s.peels = 0; s.suck = null; s.chute = 0; s.g.hold = null; s.pile = nn; }, n); await frame(); await frame();
    return p.evaluate(() => { const l = PP.layout(), G = PP.Sim.GEO, P = G.pile, c = PP.cv(), ctx = c.getContext("2d"); const y0 = Math.floor((P.base - P.rz - 24) * l.k + l.offY), y1 = Math.ceil((G.WALL ? 240 - G.WALL : 233) * l.k + l.offY), x0 = Math.floor(G.WALL * l.k + l.offX), x1 = Math.ceil((100 - G.WALL) * l.k + l.offX); const d = ctx.getImageData(x0, y0, x1 - x0, y1 - y0); let n = 0, sum = 0, dark = 0, minX = 1e9, maxX = -1, minY = 1e9, maxY = -1; const lum = [];
      for (let yy = 0; yy < d.height; yy++) for (let xx = 0; xx < d.width; xx++) { const i = (yy * d.width + xx) * 4, c3 = [d.data[i], d.data[i + 1], d.data[i + 2]]; if (!window.__isPotato(c3)) { if (c3[0] + c3[1] + c3[2] < 150 && c3[0] - c3[1] < 24) { /* shadow-ish */ } continue; } const L2 = 0.3 * c3[0] + 0.59 * c3[1] + 0.11 * c3[2]; n++; sum += L2; if (L2 < 45) dark++; lum.push(L2); minX = Math.min(minX, xx); maxX = Math.max(maxX, xx); minY = Math.min(minY, yy); maxY = Math.max(maxY, yy); }
      lum.sort((a, b) => a - b); const toU = (px, o) => (px - o) / l.k; return { n, mean: n ? +(sum / n).toFixed(1) : 0, p10: lum[Math.floor(lum.length * 0.1)] || 0, darkPct: n ? +(dark / n * 100).toFixed(2) : 0, widthU: +((maxX - minX) / l.k).toFixed(1), topU: +(toU(minY + y0, l.offY)).toFixed(1), botU: +(toU(maxY + y0, l.offY)).toFixed(1), heightU: +((maxY - minY) / l.k).toFixed(1), leftU: +toU(minX + x0, l.offX).toFixed(1), rightU: +toU(maxX + x0, l.offX).toFixed(1) }; }); };
  const pm = {}; for (const n of [24, 48, 128, 400, 800]) { pm[n] = await pileM(n); if (n === 48) await p.screenshot({ path: `${OUT}/04-pile-low-48.png` }); if (n === 800) await p.screenshot({ path: `${OUT}/05-pile-max-800.png` }); if (n === 128) await p.screenshot({ path: `${OUT}/04b-pile-128.png` }); }
  ok("PILE SHADING: the 800 pile is not darker than the 128 pile (mean luminance ratio ≥ 0.95), outline/dark pixel share does not grow with count (stacked shadows are gone), mean ≥ 80", pm[800].mean / pm[128].mean >= 0.95 && pm[800].darkPct <= pm[128].darkPct && pm[400].darkPct <= pm[128].darkPct && pm[800].mean >= 80, { m128: pm[128].mean, m400: pm[400].mean, m800: pm[800].mean, dark800: pm[800].darkPct, p10: pm[800].p10 });
  ok("PILE SPREAD: 0.2 look kept (potato sprites, tiers) but wider + lower: a 48-potato pile already spans ≥ 55 units of the 100-unit room, 800 spans ≥ 78 units", pm[48].widthU >= 55 && pm[800].widthU >= 78, { w48: pm[48].widthU, w128: pm[128].widthU, w800: pm[800].widthU });
  ok("PILE SPREAD: lies on the floor against the bottom wall (lowest potato within 8 units of the wall) and stays flat (800 pile ≤ 48 units tall, 48 pile ≤ 30)", pm[48].botU >= 225 && pm[800].botU >= 225 && pm[800].heightU <= 48 && pm[48].heightU <= 30, { bot48: pm[48].botU, bot800: pm[800].botU, h48: pm[48].heightU, h800: pm[800].heightU, top800: pm[800].topU });
  ok("PILE: small count looks sparse-but-spread, never negative/empty: 24 potatoes draw ≥ 24 sprites worth of pixels", pm[24].n > 200 && pm[24].widthU >= 40, pm[24]);
  // ---------- HUD + panel geometry ----------
  await p.evaluate(() => { PP.pause(false); PP.reset(101); });
  const clip = await p.evaluate(() => {
    const bad = []; const vw = innerWidth, vh = innerHeight;
    const inside = (e, c) => { const r = e.getBoundingClientRect(), q = c.getBoundingClientRect(); return r.left >= q.left - 0.5 && r.right <= q.right + 0.5 && r.top >= q.top - 0.5 && r.bottom <= q.bottom + 0.5; };
    const hud = document.getElementById("hud"); for (const e of hud.querySelectorAll(".brand,.stat,.st,#doing,.states .k")) if (!inside(e, hud)) bad.push("hud:" + (e.id || e.className || e.textContent));
    if (hud.scrollHeight > hud.clientHeight + 1) bad.push("hud overflows " + hud.scrollHeight + ">" + hud.clientHeight);
    for (const e of document.querySelectorAll(".box .nm,.box .val,.st,.stat .k,.stat .pct,#coins,#food,#bar button,.tag")) if (e.scrollWidth > e.clientWidth + 1 && getComputedStyle(e).display !== "inline") bad.push("text clipped: " + e.textContent);
    for (const e of document.querySelectorAll(".box .nm")) { const r = e.getBoundingClientRect(), v = e.parentNode.querySelector(".val").getBoundingClientRect(); if (r.right > v.left + 0.5) bad.push("name overlaps value: " + e.textContent); }
    for (const e of document.querySelectorAll("#app > *")) { const r = e.getBoundingClientRect(); if (e.id !== "ovl" && (r.right > vw + 0.5 || r.bottom > vh + 0.5)) bad.push("off screen " + e.id); }
    const fs = [...document.querySelectorAll("#hud *, #cmd *")].filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())).map((e) => parseFloat(getComputedStyle(e).fontSize));
    const tg = [...document.querySelectorAll(".pm,#bar button,.box")].map((e) => { const r = e.getBoundingClientRect(); return { k: e.id || e.className.split(" ")[0], w: Math.round(r.width), h: Math.round(r.height) }; });
    return { bad, minFont: Math.min(...fs), tg, boxes: document.querySelectorAll(".box").length };
  });
  ok("HUD/PANEL: nothing clipped or overlapping; 8 command boxes + SHOP and HELP buttons present", clip.bad.length === 0 && clip.boxes === 8, clip.bad);
  ok("HUD/PANEL: smallest UI text ≥ 8 px; touch targets ≥ 44 px (+/−, SHOP, HELP, box rows)", clip.minFont >= 8 && clip.tg.every((t) => t.w >= 44 && t.h >= 44), { minFont: clip.minFont, small: clip.tg.filter((t) => t.w < 44 || t.h < 44) });
  // ---------- SHOP screen (real touch) ----------
  await p.evaluate(() => { PP.reset(55); PP.sim.s.coins = 500; PP.sim.s.food = 2; }); await L.sleep(300);
  await L.touchTap(p, "#shopBtn"); await L.sleep(400);
  const sh = await p.evaluate(() => ({ mode: PP.ovl(), rows: document.querySelectorAll("#ovlBody .row").length, title: document.getElementById("ovlTitle").textContent, covers: (() => { const o = document.getElementById("ovl").getBoundingClientRect(); return o.width >= innerWidth - 1 && o.height >= innerHeight - 1; })(), btn: [...document.querySelectorAll("#ovlBody .go")].map((e) => e.textContent), small: [...document.querySelectorAll("#ovlBody .go,#ovlClose")].filter((e) => { const r = e.getBoundingClientRect(); return r.width < 44 || r.height < 44; }).length }));
  ok("SHOP: the SHOP button opens a full-screen shop with food, potatoes and 6 upgrades (8 rows), buttons ≥ 44 px", sh.mode === "shop" && sh.rows === 8 && sh.covers && sh.small === 0 && sh.title === "SHOP", sh);
  await p.screenshot({ path: `${OUT}/06-shop.png` });
  const tapGo = async (act) => { await p.evaluate((a) => { const e = document.querySelector('#ovlBody .go[data-act="' + a + '"]'), bd = document.getElementById('ovlBody'); const r = e.getBoundingClientRect(), q = bd.getBoundingClientRect(); bd.scrollTop += (r.top + r.height / 2) - (q.top + q.height / 2); }, act); await L.sleep(80); await L.touchTap(p, '#ovlBody .go[data-act="' + act + '"]'); await L.sleep(150); };
  const c0 = await p.evaluate(() => ({ c: PP.sim.s.coins, f: PP.sim.s.food, u: JSON.stringify(PP.sim.s.up), pc: PP.sim.s.potCap }));
  { const r = await L.rect(p, '#ovlBody .go[data-act="buy:food"]'); await L.touchDrag(p, r.cx, r.cy, r.cx + 3, r.cy - 70, 10); }
  const c1 = await p.evaluate(() => ({ c: PP.sim.s.coins, f: PP.sim.s.food }));
  ok("SHOP: a swipe that starts on a BUY button scrolls/does nothing and never buys", c1.c === c0.c && c1.f === c0.f, { c0, c1 });
  await p.evaluate(() => { document.getElementById("ovlBody").scrollTop = 0; }); await tapGo("buy:food");
  const c2 = await p.evaluate(() => ({ c: PP.sim.s.coins, f: PP.sim.s.food, price: null }));
  ok("SHOP: tapping BUY on food spends the price and adds 1 food", c2.f === c0.f + 1 && c0.c - c2.c >= 8 && c0.c - c2.c <= 14, { c0, c2 });
  await L.sleep(800); await tapGo("buy:up:peeler"); await tapGo("buy:pot");
  const c3 = await p.evaluate(() => ({ c: PP.sim.s.coins, up: PP.sim.s.up.peeler, pc: PP.sim.s.potCap, pot: PP.sim.s.box.pot, total: PP.sim.total(), want: PP.Sim.POTS[PP.sim.s.box.pot] }));
  ok("SHOP: SHARP PEELER lv1 (−40c) and MORE POTATOES (−21c, limit 48 → 64, put in play, count conserved) via touch", c3.up === 1 && c3.pc === 7 && c3.pot === 7 && c3.total === c3.want && c2.c - c3.c === 61, { c2, c3 });
  await p.evaluate(() => { PP.sim.s.coins = 3; }); await L.sleep(900); await tapGo("buy:up:boots");
  const poor = await p.evaluate(() => ({ coins: PP.sim.s.coins, boots: PP.sim.s.up.boots, label: document.querySelector('#ovlBody .go[data-act="buy:up:boots"]').textContent })); ok("SHOP: with too few coins a purchase is refused and the button says NEED …", poor.coins === 3 && poor.boots === 0 && /NEED/i.test(poor.label), poor);
  // scroll the shop by a real drag
  await p.evaluate(() => { document.getElementById("ovlBody").scrollTop = 0; }); { const r = await L.rect(p, "#ovlBody"); await L.touchDrag(p, r.cx, r.y + r.h * 0.85, r.cx + 4, r.y + r.h * 0.2, 12); } const sc = await p.evaluate(() => ({ st: document.getElementById("ovlBody").scrollTop, max: document.getElementById("ovlBody").scrollHeight - document.getElementById("ovlBody").clientHeight }));
  ok(`SHOP: a vertical drag scrolls the list when it is longer than the screen (scrollable ${sc.max}px) — all rows reachable`, sc.max <= 0 ? true : sc.st > 20, sc);
  await L.touchTap(p, "#ovlClose"); await L.sleep(300); ok("SHOP: X closes it back to the room", (await p.evaluate(() => PP.ovl())) === null, {});
  // ---------- HELP BOOKLET (real touch) ----------
  await L.touchTap(p, "#helpBtn"); await L.sleep(400);
  const bk0 = await p.evaluate(() => ({ mode: PP.ovl(), book: PP.book(), cover: !!document.querySelector("#pg.cover"), title: document.getElementById("ovlTitle").textContent }));
  ok("BOOKLET: the HELP button opens a booklet on its cover (10 pages = cover + 8 commands + loop)", bk0.mode === "help" && bk0.cover && bk0.book.page === 0 && bk0.book.pages === 10, bk0);
  await p.screenshot({ path: `${OUT}/07-booklet-cover.png` });
  await L.touchTap(p, '#pg .go2'); await L.sleep(600); const bk1 = await p.evaluate(() => PP.book().page); ok("BOOKLET: OPEN THE BOOK turns to page 1", bk1 === 1, bk1);
  const names = await p.evaluate(() => PP.Sim.COMMANDS.map((c) => c.name)), panelNames = await p.evaluate(() => [...document.querySelectorAll(".box .nm")].map((e) => e.textContent));
  const pages = []; for (let i = 0; i < names.length; i++) { await L.sleep(450); pages.push(await p.evaluate(() => ({ pg: PP.book().page, title: document.querySelector("#pg .hd b") && document.querySelector("#pg .hd b").textContent, id: document.querySelector("#pg").getAttribute("data-cmd"), does: (document.querySelector("#pg .tx") || {}).textContent, range: (document.querySelector("#pg .rg") || {}).textContent, affects: [...document.querySelectorAll("#pg .tx")].pop().textContent, slider: !!document.querySelector("#pg .mini .mk"), hasNow: !!document.querySelector("#pg .now"), fits: (() => { const g = document.getElementById("pg"); return g.scrollHeight <= g.clientHeight + 1; })() }))); if (i === 1 || i === 4) await p.screenshot({ path: `${OUT}/08-booklet-page-${i + 1}.png` }); if (i < names.length - 1) await L.touchTap(p, '#bkNav button[data-act="book:next"]'); }
  const cmdsInfo = await p.evaluate(() => PP.Sim.COMMANDS.map((c) => ({ name: c.name, range: c.range, does: c.does, affects: c.affects, id: c.id })));
  ok("BOOKLET: one page per command, in panel order, title = the box name, shows what it does, what the slider affects, its range and a slider picture (generated from the command list)", pages.every((pg, i) => pg.title === cmdsInfo[i].name && pg.id === cmdsInfo[i].id && pg.range === cmdsInfo[i].range && pg.does === cmdsInfo[i].does && pg.affects === cmdsInfo[i].affects && pg.slider && pg.hasNow) && JSON.stringify(names) === JSON.stringify(panelNames), { names, panelNames, bad: pages.filter((pg, i) => pg.title !== cmdsInfo[i].name) });
  ok("BOOKLET: every page fits its card without scrolling (short, not walls of text) and each page has ≤ 150 characters of body text", pages.every((pg) => pg.fits) && cmdsInfo.every((c) => (c.does.length + c.affects.length) <= 150), { lens: cmdsInfo.map((c) => c.does.length + c.affects.length), fits: pages.map((pg) => pg.fits) });
  await L.touchTap(p, '#bkNav button[data-act="book:next"]'); await L.sleep(500); const last = await p.evaluate(() => ({ b: PP.book(), loop: /THE LOOP/.test(document.getElementById("pg").textContent) })); ok("BOOKLET: NEXT past the last command shows THE LOOP page; NEXT is disabled on the last page", last.b.page === 9 && last.loop && (await p.evaluate(() => document.querySelector('#bkNav button[data-act="book:next"]').className)) === "dis", last);
  await p.screenshot({ path: `${OUT}/09-booklet-loop.png` });
  await L.touchTap(p, '#bkNav button[data-act="book:prev"]'); await L.sleep(400); const pv = await p.evaluate(() => PP.book().page); ok("BOOKLET: PREV turns back a page", pv === 8, pv);
  { const r = await L.rect(p, "#pg"); await L.touchDrag(p, r.x + r.w * 0.8, r.cy, r.x + r.w * 0.2, r.cy + 10, 10); await L.sleep(400); const sw1 = await p.evaluate(() => PP.book().page); await L.touchDrag(p, r.x + r.w * 0.2, r.cy, r.x + r.w * 0.8, r.cy + 10, 10); await L.sleep(400); const sw2 = await p.evaluate(() => PP.book().page);
    ok("BOOKLET: a sideways swipe flips the page (left = next, right = back), judged where the finger lifts", sw1 === 9 && sw2 === 8, { sw1, sw2 }); }
  { const r = await L.rect(p, "#pg"); const pg0 = await p.evaluate(() => PP.book().page); await L.touchDrag(p, r.cx, r.y + r.h * 0.8, r.cx + 6, r.y + r.h * 0.2, 10); await L.sleep(300); const pg1 = await p.evaluate(() => PP.book().page); ok("BOOKLET: a vertical drag on a page does not flip it", pg0 === pg1, { pg0, pg1 }); }
  const flipClass = await p.evaluate(() => new Promise((res) => { PP.flip(-1); const c = document.getElementById("pg").className; res(c); })); ok("BOOKLET: pages flip with an animation (flip class on the page)", /flip[np]/.test(flipClass), flipClass);
  await L.touchTap(p, "#ovlClose"); await L.sleep(300);
  // ---------- save keys: v2/v1 are read, never written; v3 is the new key; purchases persist ----------
  const FIX2 = L.fs.readFileSync(__dirname + '/fixtures/v2-save.json', 'utf8').replace('"eat":0', '"eat":25');
  const sk = await p.evaluate((FIX2) => { localStorage.setItem('papaPotato.save.v2', FIX2); localStorage.setItem("papaPotato.save.v1", JSON.stringify({ v: 1, coins: 9 })); localStorage.removeItem("papaPotato.save.v3"); return [localStorage.getItem("papaPotato.save.v2"), localStorage.getItem("papaPotato.save.v1")]; }, FIX2);
  await p.evaluate(() => { const si = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (k === 'papaPotato.save.v3') return; return si.call(this, k, v); }; localStorage.removeItem('papaPotato.save.v3'); }); await p.close(); ({ p, errs: errs2 } = await L.open(b, [w, h], { dpr: DPR, clear: false })); await L.sleep(1200); await p.evaluate(() => { PP.sim.s.coins += 5; PP.save(); }); await L.sleep(1500);
  const sk2 = await p.evaluate(() => ({ v2: localStorage.getItem("papaPotato.save.v2"), v1: localStorage.getItem("papaPotato.save.v1"), v3: localStorage.getItem("papaPotato.save.v3"), migrated: PP.migrated, coins: PP.sim.s.coins, box: PP.sim.s.box.eat, potCap: PP.sim.s.potCap }));
  ok("SAVE KEYS: a 0.2 save in localStorage is migrated (coins/boxes carried), the v2 and v1 values are byte-identical afterwards (0.2 and 0.1 slots untouched), v3 now exists", sk2.v2 === sk[0] && sk2.v1 === sk[1] && !!sk2.v3 && sk2.migrated === "0.2" && sk2.coins >= 77 && sk2.box === 25 && sk2.potCap >= 5, { migrated: sk2.migrated, coins: sk2.coins, potCap: sk2.potCap, v2same: sk2.v2 === sk[0], v1same: sk2.v1 === sk[1] });
  await p.evaluate(() => { PP.sim.s.coins = 999; PP.sim.buyUp("boots"); PP.sim.buyPotatoes(); PP.save(); }); await p.reload(); await p.waitForFunction(() => window.__PP_READY === true); await L.sleep(500);
  const pr = await p.evaluate(() => ({ boots: PP.sim.s.up.boots, potCap: PP.sim.s.potCap, mig: PP.migrated })); ok("SAVE: shop purchases (boots, potatoes) persist across a reload (v3 key)", pr.boots === 1 && pr.potCap >= 8 && pr.mig === false, pr);
  // ---------- time only while visible ----------
  const vis2 = await p.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); Object.defineProperty(document, "hidden", { configurable: true, get: () => true }); document.dispatchEvent(new Event("visibilitychange")); const t0 = PP.sim.s.t; await w(1500); const t1 = PP.sim.s.t; Object.defineProperty(document, "hidden", { configurable: true, get: () => false }); document.dispatchEvent(new Event("visibilitychange")); await w(1500); return { hiddenAdvance: t1 - t0, visibleAdvance: PP.sim.s.t - t1 }; });
  ok("TIME: stops while hidden, resumes when shown", vis2.hiddenAdvance === 0 && vis2.visibleAdvance > 0.8, vis2);
  ok("0 JS errors (page errors + console errors)", errs.length === 0 && errs2.length === 0, errs.concat(errs2));
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify({ R, pm, fit }, null, 1));
  console.log(`pass2 gui ${w}x${h}: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
