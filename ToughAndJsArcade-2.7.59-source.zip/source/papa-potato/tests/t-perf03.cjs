// A03s low-end profile: 360x800 @ DPR 2 (the A03s 720x1600 screen), CPU throttled 6x, headless Chrome (not a phone).
// Papa Potato 0.3 with boxes set. (1) potato-count ladder: frame gaps for N potatoes in play (play + suction + sweeping, real loop),
// (2) worst case: the pile layer re-rendered EVERY frame, (3) panel use, (4) heap, (5) extreme counts for headroom (beyond the slider).
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const RATE = +(process.argv[2] || 6); const OUT = process.argv[3] || "out/perf-a03s"; L.fs.mkdirSync(OUT, { recursive: true });
const stats = (a) => { const x = a.slice().sort((m, n) => m - n); const q = (k) => x[Math.min(x.length - 1, Math.floor(k * x.length))]; const tot = a.reduce((m, n) => m + n, 0); return { frames: x.length, fps: +(x.length / (tot / 1000)).toFixed(1), p50: +q(0.5).toFixed(1), p95: +q(0.95).toFixed(1), p99: +q(0.99).toFixed(1), max: +x[x.length - 1].toFixed(1), over50: x.filter((v) => v > 50).length }; };
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [360, 800], { dpr: 2 });
  p.on("error", (e) => console.log("PAGE CRASH", e.message)); p.on("framenavigated", (f) => console.log("nav", f.url().slice(0, 90))); const s = await L.cdp(p); await s.send("Emulation.setCPUThrottlingRate", { rate: RATE });
  const rec = () => p.evaluate(() => { window.__fr = []; let last = performance.now(); window.__run = true; const f = (t) => { window.__fr.push(t - last); last = t; if (window.__run) requestAnimationFrame(f); }; requestAnimationFrame(f); });
  const stop = () => p.evaluate(() => { window.__run = false; return window.__fr.slice(2); });
  const setup = (potIdx) => p.evaluate((pi) => { PP.reset(9); PP.sim.s.potCap = 17; PP.sim.s.up = { peeler: 0, boots: 0, chute: 0, pantry: 0, broom: 0, mat: 0 }; PP.sim.setBox("eat", 30); PP.sim.setBox("nap", 25); PP.sim.setBox("clean", 15); PP.sim.setBox("pot", pi); PP.sim.s.food = 9; PP.sim.s.peels = 60; PP.sim.s.chute = 4; PP.sim.s.pile -= 4; }, potIdx);
  const ladder = {}; const POTS = await p.evaluate(() => PP.Sim.POTS);
  const heap = async () => { await s.send("HeapProfiler.collectGarbage"); return (await s.send("Runtime.getHeapUsage")).usedSize; }; const h0 = await heap(); p.on("close", () => console.log("PAGE CLOSED")); b.on("disconnected", () => console.log("BROWSER DISCONNECTED")); const mark = (m) => console.log("stage", m, new Date().toISOString().slice(11, 19));
  for (const n of [4, 128, 400, 800]) {
    mark("ladder " + n); await setup(POTS.indexOf(n)); await L.sleep(1200);
    // make sure a full suction cycle happens inside the window: fill the chute (the next drop triggers it)
    await p.evaluate(() => { const s = PP.sim.s, d = Math.min(6 - s.chute, s.pile); s.pile -= d; s.chute += d; PP.sim.startSuck(); });
    await rec(); await L.sleep(16000); ladder[n] = stats(await stop());
    ladder[n].pileRenders = await p.evaluate(() => PP.stats().pileRenders); ladder[n].sucks = await p.evaluate(() => PP.sim.s.stats.sucks); ladder[n].sweeps = await p.evaluate(() => PP.sim.s.stats.sweeps);
  }
  const top = ladder[800];
  ok(`play at 6x throttle with 800 potatoes (the slider max) (suction cycles + sweeping + flights in the window): ≥ 55 fps, p95 ≤ 20 ms, ≤ 2 frames > 50 ms`, top.fps >= 55 && top.p95 <= 20 && top.over50 <= 2 && top.sucks >= 1, top);
  ok(`the whole ladder 4 / 128 / 400 / 800 potatoes stays ≥ 55 fps`, [4, 128, 400, 800].every((n) => ladder[n].fps >= 55), ladder);
  // worst case: pile layer re-rendered every frame (count flips every frame) at 400
  await setup(POTS.indexOf(800)); await L.sleep(800);
  await p.evaluate(() => { PP.pause(true); window.__flip = true; const f = () => { if (!window.__flip) return; PP.forcePile(window.__f1 = !window.__f1 ? 799 : 800); requestAnimationFrame(f); }; requestAnimationFrame(f); });
  await rec(); await L.sleep(8000); const worst = stats(await stop()); await p.evaluate(() => { window.__flip = false; PP.pause(false); });
  ok("worst case, pile re-rendered every single frame at 800 potatoes: ≥ 45 fps, p95 ≤ 25 ms", worst.fps >= 45 && worst.p95 <= 25, worst);
  // panel use at 800
  await setup(POTS.indexOf(800)); await L.sleep(800); const cm = await L.rect(p, "#cmd");
  await rec(); const t0 = Date.now(); let i = 0;
  while (Date.now() - t0 < 8000) { i++; await L.touchTap(p, '.box[data-id="pace"] .pm[data-d="1"]'); await L.touchDrag(p, cm.cx, cm.y + cm.h * 0.8, cm.cx, cm.y + cm.h * 0.2, 6); await L.touchDrag(p, cm.cx, cm.y + cm.h * 0.2, cm.cx, cm.y + cm.h * 0.8, 6); await L.touchTap(p, '.box[data-id="pace"] .pm[data-d="-1"]'); }
  const panel = stats(await stop()); ok("while using the panel (taps + scroll drags) at 800 potatoes: ≥ 50 fps, p95 ≤ 25 ms", panel.fps >= 50 && panel.p95 <= 25, { ...panel, rounds: i });
  const h1 = await heap();
  // extreme headroom beyond the slider (not shippable, for the record): 1500 and 2500 potatoes
  const extreme = {};
  for (const n of [1500, 2500]) { await p.evaluate((nn) => { PP.setPileMax(nn); PP.forcePile(nn); }, n); await L.sleep(600);
    await p.evaluate(() => { PP.pause(true); window.__flip = true; const f = () => { if (!window.__flip) return; PP.forcePile((window.__f1 = !window.__f1) ? PP.sim.s.pile - 1 : PP.sim.s.pile + 1); requestAnimationFrame(f); }; requestAnimationFrame(f); });
    await rec(); await L.sleep(5000); extreme[n] = stats(await stop()); await p.evaluate(() => { window.__flip = false; PP.pause(false); }); }
  console.log("extreme (pile re-render every frame):", JSON.stringify(extreme));
  ok("heap steady (grows < 3 MB over the whole run)", h1 - h0 < 3 * 1048576, [h0, h1]);
  ok("0 JS errors", errs.length === 0, errs);
  L.fs.writeFileSync(`${OUT}/perf.json`, JSON.stringify({ rate: RATE, viewport: "360x800@2x", ladder, worst, panel, extreme, heap: [h0, h1] }, null, 1));
  const n = R.length, pc = R.filter((r) => r.pass).length; console.log(`perf: ${pc}/${n} pass`); await b.close(); process.exit(pc === n ? 0 : 1);
})();
