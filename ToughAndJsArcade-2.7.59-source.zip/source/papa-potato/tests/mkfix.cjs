const L=require("./lib.cjs");(async()=>{const b=await L.browser();const {p}=await L.open(b,[360,800],{url:"file:///workspace/game/build-potato2/out/papa-potato-0.2.html"});
await L.sleep(6000);await p.evaluate(()=>{PP.sim.s.coins=77;PP.save&&PP.save();});await L.sleep(2500);
const k=await p.evaluate(()=>{const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);o[k]=localStorage.getItem(k).length}return o});console.log(k);
const v=await p.evaluate(()=>localStorage.getItem("papaPotato.save.v2"));L.fs.writeFileSync("fixtures/v2-save.json",v);console.log(v.slice(0,300));await b.close()})();
