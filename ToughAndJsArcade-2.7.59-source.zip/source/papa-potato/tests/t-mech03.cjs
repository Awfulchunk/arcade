// PASS 1 — Mechanics (Papa Potato 0.3). Runs the real game file in headless Chrome and fast-forwards the SAME PPSim code (dt 0.05 s, the live step).
// Pathing proof (never crosses the table), stand spots, return-chute spill schedule, potato conservation, peels, upgrades, commands, save migration.
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const OUT = process.argv[2] || "out/p1"; L.fs.mkdirSync(OUT, { recursive: true });
const SIM02 = L.fs.readFileSync("/workspace/game/build-potato2/src/sim.js", "utf8");
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [360, 800]);
  const run = (fn, ...a) => p.evaluate(fn, ...a);
  // ---------- A. PATHING ----------
  const A = await run(() => {
    const S = PP.Sim, G = S.GEO, SP = S.SPOT, I = G.INFL, RW = S.RW, RH = S.RH, out = {};
    const T = G.table, K = G.cooler;
    const inRect = (r, x, y, m) => x > r.x0 - m && x < r.x1 + m && y > r.y0 - m && y < r.y1 + m;
    const segHitsRect = (r, ax, ay, bx, by) => { // dense sampling of the segment
      const n = Math.max(2, Math.ceil(Math.hypot(bx - ax, by - ay) / 0.25)); for (let i = 0; i <= n; i++) { const x = ax + (bx - ax) * i / n, y = ay + (by - ay) * i / n; if (inRect(r, x, y, 0)) return true; } return false; };
    const cfgs = [
      [{ pace: 2 }, 1], [{ pace: 4, eat: 30, nap: 25 }, 2], [{ pace: 0, eat: 40, nap: 30, clean: 20 }, 3], [{ pace: 3, eat: 30, nap: 25, clean: 10, style: 2 }, 4],
      [{ pace: 2, eat: 70, nap: 70, clean: 5 }, 5], [{ pace: 1, eat: 0, nap: 0 }, 6], [{ pace: 4, eat: 20, nap: 20, clean: 5, style: 0, wake: 60, autob: 4 }, 7],
      [{ pace: 2, eat: 30, nap: 25, pot: 0 }, 8], [{ pace: 2, eat: 30, nap: 25, pot: 17 }, 9], [{ pace: 3, eat: 50, nap: 40, clean: 15 }, 10], [{ pace: 4, clean: 5, style: 2 }, 11], [{ pace: 2, eat: 35, nap: 35, clean: 30, autob: 2 }, 12]];
    let minClearT = 1e9, minClearK = 1e9, samples = 0, intrusions = 0, crossings = 0, walks = 0, detoured = 0, wpMax = 0, ratioMax = 0, kin = 0;
    const gap = { grab: [], drop: [], peel: [], eat: [], nap: [], sweep: [] }; const stand = { grab: [], drop: [], peel: [], eat: [] };
    for (const [box, seed] of cfgs) {
      const s = S.fresh(seed); s.s.potCap = 17; Object.assign(s.s.box, box); s.s.food = 9; s.s.coins = 0; s.retarget();
      let px = s.s.g.x * RW, py = s.s.g.y * RH, wasAct = null, walkLen = 0, walkStart = null;
      for (let i = 0; i < 3600 / 0.05; i++) {
        const before = s.s.g.act; s.step(0.05); if (s.s.food < 3 && s.s.coins > 20) s.buyFood();
        const g = s.s.g, x = g.x * RW, y = g.y * RH; samples++;
        minClearT = Math.min(minClearT, Math.max(T.x0 - x, x - T.x1, T.y0 - y, y - T.y1)); minClearK = Math.min(minClearK, Math.max(K.x0 - x, x - K.x1, K.y0 - y, y - K.y1));
        if (inRect(T, x, y, I - 0.6) || inRect(K, x, y, I - 0.6)) intrusions++;
        if (segHitsRect(T, px, py, x, y) || segHitsRect(K, px, py, x, y)) crossings++;
        px = x; py = y;
        const a = g.act;
        if (a && a !== before && a.t === "walk") { walks++; if (a.wp && a.wp.length) detoured++; wpMax = Math.max(wpMax, a.wp ? a.wp.length : 0); walkStart = { x, y, tx: a.x * RW, ty: a.y * RH, len: 0, a }; }
        if (a && a.t === "walk" && walkStart && walkStart.a === a) { /* accumulate path length below */ }
        if (before && before.t === "walk" && a !== before && a && a.t !== "walk") { // arrived: act changed to the work action
          const th = a.t; const spot = { grab: [0, SP.pile.y], drop: [SP.ship.x, SP.ship.y], peel: [SP.table.x, SP.table.y], eat: [SP.food.x, SP.food.y] }[th];
          if (spot) { stand[th].push([x, y]); if (th !== "grab" && (Math.abs(x - spot[0]) > 1e-6 || Math.abs(y - spot[1]) > 1e-6)) intrusions += 1000; if (th === "grab" && Math.abs(y - spot[1]) > 1e-6) intrusions += 1000; }
        }
      }
    }
    const P = G.pile, topEdge = P.base - P.rz;
    out.minClearT = +minClearT.toFixed(2); out.minClearK = +minClearK.toFixed(2); out.samples = samples; out.intrusions = intrusions; out.crossings = crossings; out.walks = walks; out.detoured = detoured; out.wpMax = wpMax;
    out.gapGrab = +(topEdge - SP.pile.y).toFixed(2); out.gapDrop = +(SP.ship.y - G.ship.lip).toFixed(2); out.gapPeel = +(SP.table.y - T.y1).toFixed(2); out.gapEat = +(SP.food.y - K.y1).toFixed(2); out.INFL = I;
    out.standN = { grab: stand.grab.length, drop: stand.drop.length, peel: stand.peel.length, eat: stand.eat.length };
    // route unit test: 3000 random pairs, every segment clear of the (plain) obstacles and the inflated margin
    const rr = (a, b) => a + Math.random() * (b - a); let bad = 0, longest = 0, n = 0, notClear = 0;
    const infl = S.INFL();
    for (let i = 0; i < 3000; i++) { let sx, sy, tx, ty; do { sx = rr(10, 90); sy = rr(10, 230); } while (infl.some((q) => sx > q.x0 + 0.01 && sx < q.x1 - 0.01 && sy > q.y0 + 0.01 && sy < q.y1 - 0.01));
      do { tx = rr(10, 90); ty = rr(10, 230); } while (infl.some((q) => tx > q.x0 + 0.01 && tx < q.x1 - 0.01 && ty > q.y0 + 0.01 && ty < q.y1 - 0.01));
      const r = S.route(sx, sy, tx, ty); let cx = sx, cy = sy, len = 0; for (const w of r) { if (segHitsRect(T, cx, cy, w[0], w[1]) || segHitsRect(K, cx, cy, w[0], w[1])) bad++; len += Math.hypot(w[0] - cx, w[1] - cy); cx = w[0]; cy = w[1]; }
      if (Math.abs(cx - tx) > 1e-9 || Math.abs(cy - ty) > 1e-9) notClear++; n++; const d = Math.hypot(tx - sx, ty - sy); if (d > 20) longest = Math.max(longest, len / d); }
    out.routeN = n; out.routeBad = bad; out.routeEnd = notClear; out.routeMaxRatio = +longest.toFixed(2);
    // the real trips (the two he makes every potato)
    const trips = { tableToShip: S.route(SP.table.x, SP.table.y, SP.ship.x, SP.ship.y), shipToPile: S.route(SP.ship.x, SP.ship.y, 50, SP.pile.y), pileToTable: S.route(40, SP.pile.y, SP.table.x, SP.table.y), tableToFood: S.route(SP.table.x, SP.table.y, SP.food.x, SP.food.y), tableToBed: S.route(SP.table.x, SP.table.y, SP.mat.x, SP.mat.y) };
    out.trips = Object.fromEntries(Object.entries(trips).map(([k, v]) => [k, v.map((q) => q.map((n) => +n.toFixed(1)))]));
    return out;
  });
  ok("PATH: 12 configs × 1 h of play (216,000 steps): he is NEVER inside the table or cooler (+6.4-unit body margin)", A.intrusions === 0 && A.samples === 12 * 72000, { intrusions: A.intrusions, samples: A.samples, minClearTable: A.minClearT, minClearCooler: A.minClearK });
  ok("PATH: no step's straight line from last position to new position ever touches the table or cooler rectangle", A.crossings === 0, { crossings: A.crossings });
  ok("PATH: he really does walk around (walk acts with waypoints exist) and routes are short", A.detoured > 100 && A.wpMax >= 1 && A.walks > 500, { walks: A.walks, detoured: A.detoured, wpMax: A.wpMax });
  ok("PATH: 3000 random start/target pairs: every route segment clear of table + cooler, ends exactly on target, detour ≤ 3x straight", A.routeBad === 0 && A.routeEnd === 0 && A.routeMaxRatio <= 3, { n: A.routeN, bad: A.routeBad, end: A.routeEnd, maxRatio: A.routeMaxRatio });
  ok("PATH: the table↔chute↔pile trips go via corner waypoints, not straight through", A.trips.tableToShip.length >= 2 && A.trips.shipToPile.length >= 2 && A.trips.pileToTable.length === 1, A.trips);
  ok("STAND: he stands against the pile edge (grab gap ≤ 12 units; his reach is ~10), the chute lip (≤ 10), the table (≤ 8) and the cooler (≤ 13)", A.gapGrab <= 12 && A.gapDrop <= 10 && A.gapPeel <= 8 && A.gapEat <= 13, { grab: A.gapGrab, drop: A.gapDrop, peel: A.gapPeel, eat: A.gapEat, stands: A.standN });
  ok("STAND: every arrival lands exactly on its stand spot (grab y, drop, peel, eat) in 12 hours of play", A.intrusions < 1000 && A.standN.grab > 100 && A.standN.drop > 100 && A.standN.peel > 100 && A.standN.eat > 3, A.standN);
  // reload mid-walk determinism + inside-table recovery
  const B1 = await run(() => {
    const S = PP.Sim, RW = S.RW, RH = S.RH, T = S.GEO.table, out = {};
    const mk = () => { const s = S.fresh(31); s.s.potCap = 17; Object.assign(s.s.box, { pace: 3, eat: 30, nap: 25, clean: 15 }); s.s.food = 9; return s; };
    let A = mk(), B = mk(), same = true, walkReloads = 0, intr = 0;
    for (let i = 0; i < 1200 / 0.05; i++) { A.step(0.05); B.step(0.05); if (i % 37 === 0) { if (B.s.g.act && B.s.g.act.t === "walk") walkReloads++; B = S.load(B.serialize()); if (!B) { same = false; break; } }
      const x = B.s.g.x * RW, y = B.s.g.y * RH; if (x > T.x0 && x < T.x1 && y > T.y0 && y < T.y1) intr++;
      if (i % 200 === 0 && (Math.abs(A.s.g.x - B.s.g.x) > 1e-9 || Math.abs(A.s.g.y - B.s.g.y) > 1e-9 || A.s.coins !== B.s.coins || A.s.pile !== B.s.pile)) same = false; }
    out.same = same; out.walkReloads = walkReloads; out.intr = intr; out.coinsA = A.s.coins;
    // loaded straight into the table (a corrupt or migrated save)
    const sv = JSON.parse(mk().serialize()); sv.g.x = 0.5; sv.g.y = 83 / RH; sv.g.act = { t: "walk", x: 0.5, y: 0.8, dir: 2, then: "grab", label: "x", wp: [] }; sv.g.hold = null;
    const s2 = S.load(JSON.stringify(sv)); let out2 = false, steps = 0, intr2 = 0; for (let i = 0; i < 400; i++) { s2.step(0.05); steps++; const x = s2.s.g.x * RW, y = s2.s.g.y * RH; const inside = x > T.x0 + 0.01 && x < T.x1 - 0.01 && y > T.y0 + 0.01 && y < T.y1 - 0.01; if (!inside && !out2) { out2 = true; out.escapeSteps = steps; } if (out2 && inside) intr2++; }
    out.escaped = out2; out.reintrude = intr2; out.wp0 = !!(s2.s.g.act); return out; });
  ok("PATH: reloading the save every 37 steps (mid-walk too) gives byte-identical behaviour to a run that never reloads; never inside the table", B1.same && B1.walkReloads > 5 && B1.intr === 0, B1);
  ok("PATH: a save that has him standing INSIDE the table walks him out within 2 s and he never goes back in", B1.escaped && B1.escapeSteps <= 40 && B1.reintrude === 0, { escapeSteps: B1.escapeSteps, reintrude: B1.reintrude });

  // ---------- B. RETURN CHUTE SPILL + CONSERVATION ----------
  const Bq = await run(() => {
    const S = PP.Sim, C = S.C, out = {}; let allMono = true, allBounds = true, gaps = [], fls = [], det = true;
    for (let i = 0; i < 400; i++) { const t0 = 5 + i * 3.7137, n = 2 + (i % 11), a = S.spill(t0, n), b2 = S.spill(t0, n); if (JSON.stringify(a) !== JSON.stringify(b2)) det = false;
      for (let j = 0; j < n; j++) { if (j && !(a.ex[j] > a.ex[j - 1] && a.ld[j] >= a.ld[j - 1] + 0.05 - 1e-9)) allMono = false; const f = a.ld[j] - a.ex[j]; fls.push(f); if (j) gaps.push(a.ex[j] - a.ex[j - 1]); if (a.ex[0] - t0 < C.tPipe || f < 0.7499) allBounds = false; } }
    const sd = (x) => { const m = x.reduce((a, b) => a + b, 0) / x.length; return Math.sqrt(x.reduce((a, b) => a + (b - m) * (b - m), 0) / x.length); };
    out.det = det; out.mono = allMono; out.bounds = allBounds; out.gapMin = +Math.min(...gaps).toFixed(3); out.gapMax = +Math.max(...gaps).toFixed(3); out.gapSd = +sd(gaps).toFixed(3); out.flMin = +Math.min(...fls).toFixed(2); out.flMax = +Math.max(...fls).toFixed(2); out.flSd = +sd(fls).toFixed(3);
    // sim lands potatoes exactly at the drawn schedule
    const s = S.fresh(4); s.s.potCap = 17; s.s.box.pot = 9; s.retarget(); s.s.box.eat = 0; let maxLate = 0, maxEarly = 0, lands = 0, batches = 0, lastK = null, sched = null, landed0 = 0;
    for (let i = 0; i < 5400 / 0.05; i++) { const k0 = s.s.suck; const pl0 = s.s.pile; s.step(0.05); s.s.hunger = 100; s.s.energy = 100; const k1 = s.s.suck;
      if (s.s.suck && s.s.suck !== lastK) { lastK = s.s.suck; sched = S.spill(lastK.t0, lastK.n); landed0 = 0; batches++; }
      s.s.ev.length = 0;
      if (sched && s.s.suck === lastK) { while (landed0 < s.s.suck.landed) { const ld = sched.ld[landed0]; maxLate = Math.max(maxLate, s.s.t - ld); maxEarly = Math.max(maxEarly, ld - s.s.t); landed0++; lands++; } } }
    out.lands = lands; out.batches = batches; out.maxLate = +maxLate.toFixed(3); out.maxEarly = +maxEarly.toFixed(3);
    return out; });
  ok("SPILL: schedule is a pure function of (t0,n): same inputs → same schedule; exit times increase, rest times never reorder", Bq.det && Bq.mono && Bq.bounds, Bq);
  ok("SPILL: timing is varied, not uniform (exit gaps 0.10–0.65 s with spread SD > 0.12 s; tumble time 0.75–1.35 s with SD > 0.12 s)", Bq.gapMin >= 0.0999 && Bq.gapMax <= 0.66 && Bq.gapSd > 0.12 && Bq.flMin >= 0.7499 && Bq.flMax <= 1.36 && Bq.flSd > 0.12, { gapMin: Bq.gapMin, gapMax: Bq.gapMax, gapSd: Bq.gapSd, flMin: Bq.flMin, flMax: Bq.flMax, flSd: Bq.flSd });
  ok("SPILL: the sim lands each potato within one step (0.05 s) after the drawn rest time, never before it", Bq.lands > 100 && Bq.maxEarly <= 1e-9 && Bq.maxLate <= 0.0501 + 1e-9, { lands: Bq.lands, batches: Bq.batches, maxLate: Bq.maxLate, maxEarly: Bq.maxEarly });
  const Cq = await run(() => {
    const S = PP.Sim, out = {}; let viol = 0, steps = 0, minWait = 0;
    for (const pot of [0, 1, 3, 6, 9, 13, 17]) { const s = S.fresh(pot + 50); s.s.potCap = 17; s.s.box.pot = pot; s.retarget(); Object.assign(s.s.box, { eat: 30, nap: 25, clean: 20, autob: 3 }); s.s.food = 5; s.s.coins = 50;
      for (let i = 0; i < 7200 / 0.05; i++) { s.step(0.05); steps++; if (i % 997 === 0) { const nb = [0, 1, 3, 6, 9, 13, 17, 4, 12][Math.floor(Math.random() * 9)]; if (Math.random() < 0.3) s.setBox("pot", nb); if (Math.random() < 0.1) s.buyPotatoes(); s.s.coins += 100; }
        if (s.total() !== S.POTS[s.s.box.pot] || s.s.pile < 0 || s.s.chute < 0 || s.s.chute > s.chuteCap()) viol++; s.s.ev.length = 0; }
      out["w" + pot] = { peeled: s.s.stats.peeled, wait: +s.s.stats.waitTime.toFixed(1) }; }
    out.viol = viol; out.steps = steps; return out; });
  ok("CONSERVE: potatoes in play (pile + hand + chute + pipe) equals the slider at EVERY step across 7 potato counts × 2 h with random slider moves and shop buys", Cq.viol === 0, { viol: Cq.viol, steps: Cq.steps });
  ok("SPILL: no deadlock with 4 potatoes (chute flushes when the pile runs dry): still earns coins", Cq.w0.peeled > 100, Cq.w0);

  // ---------- C. PEELS ----------
  const Pq = await run(() => {
    const S = PP.Sim, C = S.C, out = {};
    for (const [st, want] of [[0, 2], [1, 3], [2, 5]]) { const s = S.fresh(8 + st); s.s.box.style = st; s.s.box.eat = 0; s.s.box.nap = 0; s.s.food = 9; s.s.energy = 100; let peeledStart = 0, ev = 0, potatoes = 0, maxPer = 0, per = 0, tStart = null, tEnd = [], firstEv = [], inWin = true;
      for (let i = 0; i < 900 / 0.05; i++) { const a0 = s.s.g.act; s.step(0.05); s.s.energy = 100; s.s.hunger = 100;
        for (const e of s.s.ev) { if (e.k === "peel") { per++; if (tStart === null) tStart = s.s.t; firstEv.push(e.slot); } if (e.k === "peeled") { potatoes++; if (per !== want) inWin = false; tEnd.push(s.s.t - tStart); maxPer = Math.max(maxPer, per); per = 0; tStart = null; } } s.s.ev.length = 0; }
      out["st" + st] = { potatoes, ok: inWin, want, maxPer, span: +(tEnd.reduce((a, b) => a + b, 0) / Math.max(1, tEnd.length)).toFixed(2), peels: s.s.peels }; }
    const s = S.fresh(3); s.s.box.pace = 4; s.s.box.style = 2; s.s.box.eat = 0; s.s.box.nap = 0; s.s.energy = 100; let maxP = 0, slotBad = 0; for (let i = 0; i < 3600 / 0.05; i++) { s.step(0.05); s.s.energy = 100; s.s.hunger = 100; maxP = Math.max(maxP, s.s.peels); for (const e of s.s.ev) if (e.k === "peel" && (e.slot < 0 || e.slot > 199)) slotBad++; s.s.ev.length = 0; }
    out.cap = maxP; out.slotBad = slotBad;
    // sweeping stops at 10% of the trigger and never goes negative
    const w = S.fresh(5); w.s.box.clean = 40; w.s.peels = 120; w.s.box.eat = 0; w.s.box.nap = 0; w.s.energy = 100; w.s.hunger = 100; w.s.food = 9; w.s.g.hold = null; w.s.g.act = null; w.s.g.job = "pile"; let minP = 1e9, swept = false;
    for (let i = 0; i < 400 / 0.05; i++) { w.step(0.05); w.s.energy = 100; w.s.hunger = 100; if (w.s.g.act && w.s.g.act.t === "sweep") swept = true; if (swept && w.s.g.act && w.s.g.act.t !== "sweep" && w.s.g.act.t !== "walk") { minP = Math.min(minP, w.s.peels); break; } w.s.ev.length = 0; }
    out.sweepEnd = minP; out.sweepStats = w.s.stats.sweeps; return out; });
  ok("PEELS: each potato pops off exactly 2 / 3 / 5 peels for NEAT / NORMAL / QUICK, one at a time while he peels (progressive events)", Pq.st0.ok && Pq.st1.ok && Pq.st2.ok && Pq.st0.potatoes > 20 && Pq.st1.potatoes > 20 && Pq.st2.potatoes > 20, Pq);
  ok("PEELS: peel count capped at 200, event slots 0..199, never negative", Pq.cap === 200 && Pq.slotBad === 0, { cap: Pq.cap, slotBad: Pq.slotBad });
  ok("PEELS: sweeping stops when the floor is nearly clear (≤ 10% of the trigger = 4 for CLEAN > 40) and counts a sweep", Pq.sweepEnd <= 4 && Pq.sweepEnd >= 0 && Pq.sweepStats >= 1, { end: Pq.sweepEnd, sweeps: Pq.sweepStats });

  // ---------- D. SHOP + UPGRADES ----------
  const U = await run(() => {
    const S = PP.Sim, C = S.C, out = {}; const mkAtTable = (set) => { const s = S.fresh(2); s.s.box.eat = 0; s.s.box.nap = 0; s.s.energy = 100; s.s.hunger = 100; s.s.food = 9; if (set) set(s); return s; };
    // peeler: time from grab done → peeled
    const peelTime = (lv) => { const s = mkAtTable((q) => { q.s.up.peeler = lv; }); s.s.g.hold = "raw"; s.s.g.job = "peel"; s.s.pile -= 1; s.s.g.act = null; s.s.g.x = 0.5; s.s.g.y = 99 / 240; s.startAt("peel"); let t = 0; while (s.s.g.hold === "raw" && t < 60) { s.step(0.05); s.s.energy = 100; s.s.hunger = 100; t += 0.05; } return t; };
    out.peel = [0, 1, 2, 3].map(peelTime);
    const walkTime = (lv) => { const s = mkAtTable((q) => { q.s.up.boots = lv; }); s.s.g.x = 0.3; s.s.g.y = 0.8; s.s.g.hold = null; s.s.g.job = "pile"; s.walkTo(70, 193, 2, "grab", "t"); let t = 0; while (s.s.g.act && s.s.g.act.t === "walk" && t < 60) { s.step(0.05); s.s.energy = 100; t += 0.05; } return t; };
    out.walk = [0, 1, 2, 3].map(walkTime);
    out.cap = [0, 1, 2, 3].map((l) => { const s = mkAtTable((q) => { q.s.up.chute = l; }); return s.chuteCap(); }); out.drop = [0, 1, 2, 3].map((l) => { const s = mkAtTable((q) => { q.s.up.chute = l; }); return +s.dropTime().toFixed(3); });
    out.food = [0, 1, 2].map((l) => { const s = mkAtTable((q) => { q.s.up.pantry = l; }); return s.foodMax(); });
    out.sweep = [0, 1, 2, 3].map((l) => { const s = mkAtTable((q) => { q.s.up.broom = l; q.s.box.clean = 5; q.s.peels = 100; q.s.g.hold = null; }); s.s.g.act = null; s.s.g.x = 0.5; s.s.g.y = 108 / 240; s.startAt("sweep"); let t = 0; const p0 = s.s.peels; while (s.s.peels > 60 && t < 60) { s.step(0.05); s.s.energy = 100; s.s.hunger = 100; t += 0.05; } return +(40 / (t - C.sweepWind)).toFixed(2); });
    out.nap = [0, 1, 2].map((l) => { const s = mkAtTable((q) => { q.s.up.mat = l; q.s.energy = 20; }); s.s.g.act = { t: "nap", label: "x" }; const e0 = s.s.energy; for (let i = 0; i < 20; i++) { s.step(0.05); s.s.hunger = 100; } return +((s.s.energy - e0) / 1.0).toFixed(2); });
    // buying
    const s = S.fresh(1); s.s.coins = 0; out.poor = [s.buyFood(), s.buyPotatoes(), s.buyUp("peeler")]; s.s.coins = 100000; const prices = {}; for (const u of S.UPS) { prices[u.id] = []; for (let i = 0; i < u.max; i++) { prices[u.id].push(s.upPrice(u.id)); if (s.buyUp(u.id) !== "ok") prices[u.id].push("FAIL"); } prices[u.id].push(s.buyUp(u.id), s.upPrice(u.id)); } out.prices = prices;
    const pp = []; while (s.potPrice() !== null) { pp.push([S.POTS[s.s.potCap + 1], s.potPrice()]); if (s.buyPotatoes() !== "ok") break; } out.potPrices = pp; out.potEnd = [s.buyPotatoes(), s.s.potCap, s.s.box.pot, s.total()];
    const f = S.fresh(1); f.s.coins = 1e5; f.s.up.pantry = 2; let n = 0; while (f.buyFood() === "ok") n++; out.foodBought = n; out.foodFull = f.buyFood(); out.coinsAfter = [s.s.coins, f.s.coins]; out.bad = s.buyUp("nope");
    return out; });
  const near = (a, b, tol) => Math.abs(a - b) <= tol;
  ok("UPGRADE SHARP PEELER: peel time ×0.85 per level (6.0 s → 5.1 → 4.34 → 3.69)", [6, 5.1, 4.335, 3.685].every((v, i) => near(U.peel[i], v, 0.12)), U.peel);
  ok("UPGRADE GOOD BOOTS: trip time ÷ (1 + 0.1·level)", [1, 1.1, 1.2, 1.3].every((m, i) => near(U.walk[i] * m, U.walk[0], U.walk[0] * 0.03)), U.walk);
  ok("UPGRADE BIGGER CHUTE: batch size 6/8/10/12 and drop time ×0.7 per level", JSON.stringify(U.cap) === "[6,8,10,12]" && [0.5, 0.35, 0.245, 0.1715].every((v, i) => near(U.drop[i], v, 0.002)), { cap: U.cap, drop: U.drop });
  ok("UPGRADE BIGGER COOLER: food cap 9 / 12 / 15 (shop refuses past it)", JSON.stringify(U.food) === "[9,12,15]" && U.foodBought === 14 && U.foodFull === "full", { food: U.food, bought: U.foodBought, full: U.foodFull });
  ok("UPGRADE STIFF BROOM: sweep rate ×(1 + 0.5·level)", [1, 1.5, 2, 2.5].every((m, i) => near(U.sweep[i] / U.sweep[0], m, 0.12)), U.sweep);
  ok("UPGRADE SOFT BED: nap regen ×(1 + 0.35·level)", [1, 1.35, 1.7].every((m, i) => near(U.nap[i] / U.nap[0], m, 0.05)), U.nap);
  ok("SHOP: can't buy with no coins (poor), can't pass max level (max), unknown item rejected, spends exactly the listed price", U.poor.join() === "poor,poor,poor" && U.bad === "bad" && Object.values(U.prices).every((a) => !a.includes("FAIL") && a[a.length - 2] === "max" && a[a.length - 1] === null), { poor: U.poor, prices: U.prices });
  ok("SHOP POTATOES: tier price = round(15·1.4^(stop−6)) (21c for 64 … 607c for 800), buying puts all of them in play and conserves the count", U.potPrices.length === 11 && U.potPrices.every(([n, pr], i) => pr === Math.round(15 * Math.pow(1.4, 7 + i - 6))) && U.potPrices[0][0] === 64 && U.potPrices[0][1] === 21 && U.potPrices[10][0] === 800 && U.potPrices[10][1] === 607 && U.potEnd[0] === "max" && U.potEnd[1] === 17 && U.potEnd[2] === 17 && U.potEnd[3] === 800, { prices: U.potPrices, end: U.potEnd });

  // ---------- E. COMMANDS (sim side) ----------
  const E = await run(() => {
    const S = PP.Sim, out = {}; const ids = S.COMMANDS.map((c) => c.id), bk = Object.keys(S.BOX);
    out.sameIds = JSON.stringify(ids) === JSON.stringify(bk); out.n = ids.length; out.ids = ids;
    const s = S.fresh(1); s.s.potCap = 9; const t = {}; for (const c of S.COMMANDS) { t[c.id] = [s.setBox(c.id, c.min - 99), s.s.box[c.id], s.setBox(c.id, c.max + 99), s.s.box[c.id], s.setBox(c.id, NaN), s.setBox(c.id, "x")]; s.setBox(c.id, c.def); }
    out.clamp = t;
    s.setBox("pot", 99); out.potGate = s.s.box.pot; s.s.potCap = 17; s.setBox("pot", 99); out.potOpen = s.s.box.pot;
    const w = S.fresh(2); w.setBox("eat", 33); out.snap = w.s.box.eat; w.setBox("wake", 74); out.snapWake = w.s.box.wake;
    // style speed: potatoes per hour (no eat/nap needed) NEAT < NORMAL < QUICK in speed, peels per potato 2/3/5
    const rate = (st) => { const q = S.fresh(6); q.s.box.style = st; q.s.box.pace = 2; q.s.box.eat = 0; q.s.box.nap = 0; q.s.box.clean = 0; let pe = 0; for (let i = 0; i < 1800 / 0.05; i++) { q.step(0.05); q.s.energy = 100; q.s.hunger = 100; q.s.peels = 0; q.s.ev.length = 0; } return q.s.stats.peeled; };
    out.styleRates = [rate(0), rate(1), rate(2)];
    // wake level: nap ends at the chosen energy
    const wk = (lv) => { const q = S.fresh(9); q.s.box.nap = 40; q.s.box.wake = lv; q.s.energy = 30; q.s.hunger = 100; q.s.g.hold = null; q.s.g.act = null; q.decide(); let nap = false, e = null; for (let i = 0; i < 3000; i++) { q.step(0.05); q.s.hunger = 100; if (q.s.g.act && q.s.g.act.t === "nap") nap = true; if (nap && q.s.g.act && q.s.g.act.t !== "nap") { e = q.s.energy; break; } } return e; };
    out.wake = [50, 70, 100].map(wk);
    // auto-buy: keeps food at the set level while coins allow, stops when poor, never exceeds the cooler
    const ab = S.fresh(3); ab.s.box.autob = 4; ab.s.food = 0; ab.s.coins = 100; ab.step(0.05); for (let i = 0; i < 100; i++) ab.step(0.05); out.autob = [ab.s.food, ab.s.stats.autoBuys, ab.s.coins];
    const ab2 = S.fresh(3); ab2.s.box.autob = 9; ab2.s.food = 0; ab2.s.coins = 15; for (let i = 0; i < 100; i++) ab2.step(0.05); out.autobPoor = [ab2.s.food, ab2.s.coins];
    const ab3 = S.fresh(3); ab3.s.box.autob = 9; ab3.s.food = 0; ab3.s.coins = 1e6; for (let i = 0; i < 400; i++) ab3.step(0.05); out.autobMax = ab3.s.food;
    // eat when hunger: eats at threshold, needs food
    const ea = S.fresh(4); ea.s.box.eat = 40; ea.s.food = 3; ea.s.hunger = 39; for (let i = 0; i < 1200; i++) { ea.step(0.05); } out.eat = [ea.s.stats.meals, +ea.s.hunger.toFixed(0)];
    // pace multipliers
    out.pace = S.SPD.map((v, i) => [S.PACE[i], v, S.DRN[i]]);
    return out; });
  ok("COMMANDS: the command table, BOX and panel ids are one list (8 commands)", E.sameIds && E.n === 8, E.ids);
  ok("COMMANDS: every box clamps below/above its range, ignores NaN and text, snaps to its step", Object.entries(E.clamp).every(([id, v]) => v[1] === (E.clamp[id][1]) && v[4] === false && v[5] === false) && E.snap === 35 && E.snapWake === 70, E);
  ok("COMMANDS: POTATOES IN PLAY slider is capped at what you own (potCap) and opens up when you buy", E.potGate === 9 && E.potOpen === 17, { gate: E.potGate, open: E.potOpen });
  ok("COMMAND PEEL STYLE: NEAT is slower than NORMAL is slower than QUICK (potatoes in 30 min)", E.styleRates[0] < E.styleRates[1] && E.styleRates[1] < E.styleRates[2], E.styleRates);
  ok("COMMAND NAP UNTIL: he wakes at the chosen energy (≈50 / 70 / 98+ for 50 / 70 / 100)", E.wake[0] >= 50 && E.wake[0] < 58 && E.wake[1] >= 70 && E.wake[1] < 78 && E.wake[2] >= 98, E.wake);
  ok("COMMAND KEEP FOOD AT LEAST: buys up to the level while coins last, stops when poor, never above the cooler cap", E.autob[0] === 4 && E.autob[1] === 4 && E.autobPoor[0] === 1 && E.autobMax === 9, { autob: E.autob, poor: E.autobPoor, max: E.autobMax });
  ok("COMMAND EAT WHEN HUNGER: eats when hunger drops under the number and food > 0", E.eat[0] >= 1 && E.eat[1] > 40, E.eat);

  // ---------- F. SAVE MIGRATION ----------
  const F = await run((SIM02src) => {
    const S3 = PP.Sim, out = {}; const S2 = (new Function(SIM02src + "\nreturn PPSim;"))();
    const mk2 = (seed, box, T) => { const s = S2.fresh(seed); Object.assign(s.s.box, box); s.s.food = 5; for (let i = 0; i < T / 0.05; i++) { s.step(0.05); if (s.s.food < 2) s.buyFood(); s.s.ev.length = 0; } return s; };
    const cases = [[1, { pace: 2, eat: 30, nap: 25, clean: 20, pot: 9 }, 900], [2, { pace: 4, eat: 40, nap: 30, clean: 0, pot: 17 }, 1800], [3, { pace: 0, eat: 0, nap: 0, clean: 90, pot: 2 }, 400], [4, { pace: 3, eat: 20, nap: 50, clean: 5, pot: 11 }, 3000]];
    const res = []; for (const [seed, box, T] of cases) { const s2 = mk2(seed, box, T), str = s2.serialize(), q = S3.load(str); const o = q.s;
      res.push({ seed, loaded: !!q, v: o.v, coins: o.coins === s2.s.coins, food: o.food === s2.s.food, peels: o.peels === s2.s.peels, hunger: Math.abs(o.hunger - s2.s.hunger) < 1e-9, box: ["pace", "eat", "nap", "clean", "pot"].every((k) => o.box[k] === s2.s.box[k]),
        newBox: JSON.stringify([o.box.style, o.box.wake, o.box.autob]), potCap: o.potCap, up: Object.values(o.up).join(""), total: q.total() === S3.POTS[o.box.pot], act: !!o.g.act, stats: o.stats.earned === s2.s.stats.earned }); 
      for (let i = 0; i < 4000; i++) { q.step(0.05); q.s.ev.length = 0; } res[res.length - 1].ran = q.s.stats.peeled >= 0 && q.total() === S3.POTS[q.s.box.pot] && isFinite(q.s.g.x); }
    out.res = res;
    // 0.1 save (real fixture)
    return out; }, SIM02);
  ok("MIGRATE v2→v3: 4 real 0.2 saves (different boxes/pot counts/ages) load; coins, food, peels, hunger, boxes, stats kept; potatoes conserved; new boxes at defaults; no upgrades; keeps ≥ 128 potato limit", F.res.every((r) => r.loaded && r.v === 3 && r.coins && r.food && r.peels && r.hunger && r.box && r.total && r.stats && r.ran && r.newBox === "[1,100,0]" && /^0+$/.test(r.up)) && F.res.every((r) => r.potCap >= 9), F.res);
  const v1 = L.fs.readFileSync("fixtures/v1-save.json", "utf8");
  const F1 = await run((s1) => { const q = PP.Sim.load(s1); if (!q) return { loaded: false }; for (let i = 0; i < 2000; i++) { q.step(0.05); q.s.ev.length = 0; } return { loaded: true, v: q.s.v, total: q.total() === PP.Sim.POTS[q.s.box.pot], pot: q.s.box.pot, potCap: q.s.potCap, coins: q.s.coins, finite: isFinite(q.s.g.x + q.s.g.y) }; }, v1);
  ok("MIGRATE v1→v3: the real 0.1 save fixture loads and runs", F1.loaded && F1.v === 3 && F1.total && F1.finite, F1);
  const F3 = await run(() => { const S = PP.Sim; const s = S.fresh(12); Object.assign(s.s.box, { pace: 3, eat: 30, style: 2, wake: 70, autob: 3 }); s.s.potCap = 12; s.s.up.peeler = 2; s.s.up.chute = 1; s.s.coins = 321; for (let i = 0; i < 3000; i++) { s.step(0.05); s.s.ev.length = 0; }
    const q = S.load(s.serialize()); let same = JSON.stringify(JSON.parse(s.serialize()).box) === JSON.stringify(q.s.box) && q.s.up.peeler === 2 && q.s.potCap === 12 && q.s.coins === s.s.coins && q.s.t === s.s.t;
    for (let i = 0; i < 4000; i++) { s.step(0.05); q.step(0.05); s.s.ev.length = 0; q.s.ev.length = 0; } return { same, after: s.s.coins === q.s.coins && s.s.pile === q.s.pile && s.s.g.x === q.s.g.x, coins: s.s.coins }; });
  ok("SAVE v3: round trip keeps boxes, upgrades, potato limit, time; the reloaded game then plays identically to the original", F3.same && F3.after, F3);

  // ---------- G. economy report (not a pass/fail on feel; floors only) ----------
  const E2 = await run(() => { const S = PP.Sim, out = {}; for (const [n, box] of [["steady sane", { pace: 2, eat: 30, nap: 25 }], ["grind", { pace: 4, eat: 35, nap: 30 }], ["chill", { pace: 0, eat: 30, nap: 25 }]]) { const s = S.fresh(11); s.s.potCap = 9; Object.assign(s.s.box, box); s.s.food = 9; for (let i = 0; i < 2400 / 0.05; i++) { s.step(0.05); if (s.s.food < 2 && s.s.coins > 20) s.buyFood(); s.s.ev.length = 0; } out[n] = { cpm: +(s.s.stats.earned / 2400 * 60).toFixed(2), peeled: s.s.stats.peeled, lazyPct: +(s.s.stats.lazyTime / 2400 * 100).toFixed(1), wait: +s.s.stats.waitTime.toFixed(1) }; } return out; });
  ok("ECONOMY: 40 min runs earn coins at a sane rate with low lazy time (steady ≥ 3 c/min, lazy < 15%)", E2["steady sane"].cpm >= 3 && E2["steady sane"].lazyPct < 15 && E2.grind.cpm > E2.chill.cpm, E2);
  ok("0 JS errors (page errors + console errors)", errs.length === 0, errs);
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify({ R, A, B1, Bq, Pq, U, E, F, E2 }, null, 1));
  console.log(`pass1 mechanics: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
