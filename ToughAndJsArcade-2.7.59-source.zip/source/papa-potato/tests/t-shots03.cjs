// Screenshots for the 0.3 hand-off (headless Chrome at the given CSS viewport, DPR 2). Not a phone.
const L = require("./lib.cjs"); const [w, h] = (process.argv[2] || "360x800").split("x").map(Number); const OUT = (process.argv[3] || "out/shots03") + `/${w}x${h}`; L.fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [w, h], { dpr: 2 }); const ev = (f, ...a) => p.evaluate(f, ...a); const shot = (n, o) => p.screenshot({ path: `${OUT}/${n}.png`, ...(o || {}) });
  const calm = (id) => ev(() => { const s = PP.sim.s; s.box.eat = 40; s.box.nap = 30; s.food = 9; });
  const crop = async (n, x0, y0, x1, y1) => { const c = await ev(() => { const l = PP.layout(), r = document.getElementById("play").getBoundingClientRect(), sc = r.width / l.W; return { l: { k: l.k, offX: l.offX, offY: l.offY }, r: r.toJSON(), sc }; }); const X = c.r.left + (c.l.offX + x0 * c.l.k) * c.sc, Y = c.r.top + (c.l.offY + y0 * c.l.k) * c.sc, X2 = c.r.left + (c.l.offX + x1 * c.l.k) * c.sc, Y2 = c.r.top + (c.l.offY + y1 * c.l.k) * c.sc; await p.screenshot({ path: `${OUT}/${n}.png`, clip: { x: Math.max(0, X), y: Math.max(0, Y), width: Math.min(X2 - X, w), height: Math.min(Y2 - Y, h) } }); };
  // first view with the tiny labels and the beginner hint
  await ev(() => { PP.reset(5); PP.labels(60000, true); }); await L.sleep(1500); await shot("01-first-view-labels-and-hint");
  await calm(); await ev(() => { PP.reset(5); PP.sim.s.box.eat = 40; PP.sim.s.box.nap = 30; PP.sim.s.food = 9; PP.labels(60000, true); }); await L.sleep(800); await shot("02-full-room-labels");
  await ev(() => { PP.labels(1, true); }); await L.sleep(900);
  // peels land flat on the floor
  await ev(() => { PP.reset(7); const s = PP.sim.s; s.box.eat = 40; s.box.nap = 30; s.food = 9; s.box.style = 2; s.peels = 0; s.stats.peeled = 0; }); let t0 = Date.now(); while (Date.now() - t0 < 60000) { await ev(() => { PP.sim.s.hunger = 100; PP.sim.s.energy = 100; }); if ((await ev(() => PP.sim.s.peels)) >= 24) break; await L.sleep(500); }
  await L.sleep(800); await shot("03-peels-landed-on-floor"); await crop("03b-peels-closeup", 18, 84, 92, 130);
  // mid-flight frame
  t0 = Date.now(); while (Date.now() - t0 < 20000) { const n = await ev(() => PP.flightsNow().length); if (n >= 1) { await shot("03c-peel-mid-hop"); break; } await L.sleep(20); }
  // Papa at the pile and at the chute
  for (const [name, want] of [["04-papa-at-the-pile-grabbing", "grab"], ["05-papa-at-the-chute-dropping", "drop"], ["06-papa-peeling-at-the-table", "peel"], ["06b-papa-eating-at-the-cooler", "eat"], ["06c-papa-napping-in-bed", "nap"], ["06d-papa-sweeping", "sweep"]]) {
    await ev((want) => { PP.reset(13); const s = PP.sim.s; s.box.pot = 8; s.potCap = 17; PP.sim.retarget(); s.food = 9; if (want === "eat") { s.hunger = 20; s.box.eat = 50; } if (want === "nap") { s.energy = 15; s.box.nap = 50; s.box.wake = 100; } else { s.box.nap = 0; } if (want !== "eat") s.box.eat = 40; if (want === "sweep") { s.box.clean = 10; s.peels = 60; } s.box.pace = 2; }, want);
    let got = false; t0 = Date.now(); while (Date.now() - t0 < 120000) { const a = await ev((want) => { const g = PP.sim.s.g; return !!(g.act && g.act.t === want); }, want); if (a) { await L.sleep(want === "grab" || want === "drop" ? 60 : 500); const still = await ev((want) => PP.sim.s.g.act && PP.sim.s.g.act.t === want, want); if (still) { got = true; break; } } await ev(() => { for (let i = 0; i < 2; i++) PP.sim.step(0.05); }); await L.sleep(8); }
    if (got) { await shot(name); const g = await ev(() => ({ x: PP.sim.s.g.x * 100, y: PP.sim.s.g.y * 240 })); await crop(name + "-closeup", Math.max(0, g.x - 24), Math.max(0, g.y - 30), Math.min(100, g.x + 24), Math.min(240, g.y + 22)); } else console.log("no frame for", want);
    await ev(() => { PP.sim.s.g.act = null; }); }
  // return chute spilling
  await ev(() => { PP.reset(9); const s = PP.sim.s; s.box.eat = 40; s.box.nap = 30; s.food = 9; s.g.act = { t: "idle", d: 9999, e: 0, label: "x" }; s.g.x = 0.12; s.g.y = 0.45; s.box.pot = 8; s.potCap = 17; PP.sim.retarget(); s.chute = 6; s.pile -= 6; PP.sim.startSuck(); });
  const sheet = []; for (let i = 0; i < 12; i++) { await L.sleep(i === 0 ? 1900 : 180); await shot(`07-return-chute-spilling-${String(i).padStart(2, "0")}`); }
  await crop("07z-return-chute-closeup", 40, 172, 100, 232);
  // pile at low and max counts
  for (const n of [24, 128, 400, 800]) { await ev((n) => { PP.pause(true); PP.reset(3); const s = PP.sim.s; s.potCap = 17; s.box.pot = PP.Sim.POTS.indexOf(n); PP.sim.retarget(); s.g.x = 0.88; s.g.y = 0.05; s.g.act = { t: "idle", d: 9999, e: 0, label: "x" }; s.box.eat = 40; s.box.nap = 30; s.suck = null; s.chute = 0; s.g.hold = null; s.pile = n; s.peels = 0; }, n); await L.sleep(500); await shot(`08-pile-${n}`); if (n === 24 || n === 800) await crop(`08z-pile-${n}-closeup`, 0, 190, 100, 240); }
  await ev(() => PP.pause(false));
  // command panel
  await ev(() => { PP.reset(2); const s = PP.sim.s; s.box.eat = 40; s.box.nap = 30; s.food = 9; s.coins = 42; PP.sim.setBox("pace", 3); PP.sim.setBox("style", 2); PP.sim.setBox("clean", 30); PP.reload(); PP.sim.s.box.eat = 40; }); await L.sleep(600);
  await ev(() => { document.getElementById("cmd").scrollTop = 0; }); await shot("09-command-panel-top");
  await ev(() => { const c = document.getElementById("cmd"); c.scrollTop = c.scrollHeight; }); await L.sleep(300); await shot("09b-command-panel-scrolled-bar-pinned");
  await ev(() => { document.getElementById("cmd").scrollTop = 0; PP.sim.setBox("pot", 3); }); await L.touchTap(p, '.box[data-id="eat"] .nm'); await L.sleep(300); await shot("09c-command-panel-box-unlocked");
  // shop
  await ev(() => { PP.sim.s.coins = 95; PP.sim.s.up.boots = 1; PP.sim.s.food = 4; PP.open("shop"); }); await L.sleep(500); await shot("10-shop-top");
  await ev(() => { const b = document.getElementById("ovlBody"); b.scrollTop = b.scrollHeight; }); await L.sleep(300); await shot("10b-shop-scrolled"); await ev(() => PP.close());
  // booklet
  await ev(() => PP.open("help")); await L.sleep(500); await shot("11-booklet-cover");
  const nm = await ev(() => PP.Sim.COMMANDS.map((c) => c.id));
  for (const i of [1, 2, 4, 6, 8]) { await ev((i) => { while (PP.book().page < i) PP.flip(1); while (PP.book().page > i) PP.flip(-1); }, i); await L.sleep(700); await shot(`11-booklet-page-${i}-${nm[i - 1]}`); }
  await ev(() => { PP.flip(1); }); await L.sleep(700); await shot("11-booklet-last-page-the-loop"); await ev(() => PP.close());
  // objects up close (each object cropped from the room)
  await ev(() => { PP.reset(4); PP.pause(true); const s = PP.sim.s; s.box.eat = 40; s.box.nap = 30; s.food = 9; s.g.act = { t: "idle", d: 9999, e: 0, label: "x" }; s.g.x = 0.5; s.g.y = 0.34; s.peels = 18; PP.labels(1, true); }); await L.sleep(900);
  const G = await ev(() => PP.Sim.GEO); const R = { ship: [G.ship.x - 22, 0, G.ship.x + 22, 30], ret: [52, G.ret.y - 22, 100, G.ret.y + 14], table: [G.table.x0 - 6, G.table.y0 - 10, G.table.x1 + 6, G.table.y1 + 8], bed: [G.mat.x - 20, G.mat.y - 14, G.mat.x + 20, G.mat.y + 14], cooler: [G.cooler.x0 - 10, G.cooler.y0 - 12, G.cooler.x1 + 8, G.cooler.y1 + 8], stool: [G.stool.x - 14, G.stool.y - 14, G.stool.x + 14, G.stool.y + 12], pile: [0, 195, 100, 240] };
  await ev(() => { PP.labels(1, true); PP.pause(true); PP.forcePile(48); }); await L.sleep(900); for (const k of Object.keys(R)) { await crop(`12-object-${k}`, ...R[k]); }
  await ev(() => { PP.labels(60000, true); }); await L.sleep(700); for (const k of ["table", "stool", "cooler"]) await crop(`12-object-${k}-with-label`, ...R[k]);
  console.log("errors:", errs.length, errs.slice(0, 3)); L.fs.writeFileSync(`${OUT}/errors.json`, JSON.stringify(errs)); await b.close();
})();
