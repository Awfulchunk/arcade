/* ===== Papa Potato 0.3 — renderer, HUD, scroll-safe command panel, shop + help screens, save/load ===== */
(function(){
"use strict";
var SAVE_KEY="papaPotato.save.v3",KEY_V2="papaPotato.save.v2",KEY_V1="papaPotato.save.v1";   /* v2 / v1 are only ever READ (the 0.2 and 0.1 slots own them) */
var C=PPSim.C,BOX=PPSim.BOX,SPOT=PPSim.SPOT,PACE=PPSim.PACE,GEO=PPSim.GEO,RW=PPSim.RW,RH=PPSim.RH,CMDS=PPSim.COMMANDS,UPS=PPSim.UPS,STYLE=PPSim.STYLE,SPD=PPSim.SPD,POTS=PPSim.POTS;
var sim=null;
var migrated=false;
/* 0.3 save first; else carry over a 0.2 save, then a 0.1 save (both read only); else a fresh game */
function loadGame(){var s=null;try{var raw=localStorage.getItem(SAVE_KEY);if(raw)s=PPSim.load(raw);}catch(e){}
  if(!s){try{var o2=localStorage.getItem(KEY_V2);if(o2){s=PPSim.load(o2);if(s)migrated="0.2";}}catch(e){}}
  if(!s){try{var o1=localStorage.getItem(KEY_V1);if(o1){s=PPSim.load(o1);if(s)migrated="0.1";}}catch(e){}}
  return s||PPSim.fresh();}
var lastSave=0;
function saveGame(){if(!sim)return false;try{localStorage.setItem(SAVE_KEY,sim.serialize());lastSave=performance.now();return true;}catch(e){return false;}}
sim=loadGame();

/* ---------- art: the whole room is fitted into the play area (no scrolling) ---------- */
var DETAIL=1.10;      /* ~10% finer pixel grid (t1014) */
var cv=document.getElementById("cv"),ctx=cv.getContext("2d");
var W=0,H=0,SC=3,k=1,camX=0,camY=0,offX=0,offY=0,roomW=RW,roomH=RH,WALL=GEO.WALL;
var staticLayer=null,gx=0,gy=0,table=null,chute=null,playRect=null;
var pops=[];
var pileLayer=null,pileKey=-1,messLayer=null,messKey="",POS=[],ORDER=[],MESSPOS=[],SPR=null,SPRS=null,PEELSPR=null,TIER=[],renders={pile:0,mess:0};
var MAXVIS=400,PILEMAX=POTS[POTS.length-1],LIFT=1.1,MESSVIS=140;
function R(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x|0,y|0,Math.max(1,w),Math.max(1,h));}
function wx(x){return Math.round((x-camX)*k);}
function wy(y){return Math.round((y-camY)*k);}
function ws(s){return Math.max(1,Math.round(s*k));}
function wr(x,y,w,h,c){var x0=wx(x),y0=wy(y),x1=wx(x+w),y1=wy(y+h);R(x0,y0,Math.max(1,x1-x0),Math.max(1,y1-y0),c);}
function oval(cx,cy,rw,rh,c){cx=Math.round(cx);cy=Math.round(cy);rw=Math.max(1,Math.round(rw));rh=Math.max(1,Math.round(rh));var rh2=rh*rh||1;ctx.fillStyle=c;
  for(var dy=-rh;dy<=rh;dy++){var t=1-(dy*dy)/rh2;var row=Math.max(1,Math.round(rw*Math.sqrt(Math.max(0,t))));ctx.fillRect(cx-row,cy+dy,row*2+(row>0?0:1),1);}}
function srng(n){var s=(n*1664525+1013904223)>>>0;return (s%10000)/10000;}
var TAGDEF=[
  {id:"tagShip",x:GEO.ship.x+20,y:15,al:"l"},
  {id:"tagRet",x:GEO.ret.mouthX+3,y:GEO.ret.y-13,al:"c"},
  {id:"tagTable",x:50,y:68,al:"c"},
  {id:"tagBed",x:GEO.mat.x,y:GEO.mat.y-9,al:"c"},
  {id:"tagFood",x:78,y:GEO.cooler.y0-6,al:"c"},
  {id:"tagSeat",x:GEO.stool.x,y:GEO.stool.y+9,al:"c"},
  {id:"tagPot",x:50,y:GEO.pile.base+3,al:"c"}];
function layout(){
  var r=document.getElementById("play").getBoundingClientRect();playRect=r;
  var cssW=Math.max(1,r.width),cssH=Math.max(1,r.height);
  var baseSC=cssW>=230?3:2;SC=baseSC/DETAIL;
  W=Math.max(1,Math.round(cssW/SC));H=Math.max(1,Math.round(cssH/SC));cv.width=W;cv.height=H;
  k=Math.min(W/RW,H/RH)*0.985;offX=(W-RW*k)/2;offY=(H-RH*k)/2;camX=-offX/k;camY=-offY/k;
  gx=GEO.table.x0+(GEO.table.x1-GEO.table.x0)/2;gy=GEO.table.y0+(GEO.table.y1-GEO.table.y0)/2;
  table={x:gx,y:gy,w:GEO.table.x1-GEO.table.x0,h:GEO.table.y1-GEO.table.y0};
  chute={cx:GEO.ship.x,mouthW:GEO.ship.mouth*2,lip:GEO.ship.lip};
  staticLayer=null;pileLayer=null;messLayer=null;buildPile();buildMess();buildSprites();placeTags();
}
function clampTag(el,play,pad){var r=el.getBoundingClientRect();var left=parseFloat(el.style.left)||0;
  if(el.style.transform&&el.style.transform.indexOf("translateX(-50%)")>=0){var half=r.width/2;el.style.left=Math.round(Math.max(pad+half,Math.min(play.width-pad-half,left)))+"px";return;}
  if(r.left<play.left+pad)left+=(play.left+pad)-r.left;if(r.right>play.right-pad)left-=r.right-(play.right-pad);
  el.style.left=Math.round(Math.max(pad,left))+"px";}
function placeTags(){var play=playRect;
  for(var i=0;i<TAGDEF.length;i++){var d=TAGDEF[i],el=document.getElementById(d.id);if(!el)continue;
    var px=(wx(d.x)/W)*play.width,py=(wy(d.y)/H)*play.height;
    el.style.transform=d.al==="c"?"translateX(-50%)":"none";el.style.left=Math.round(px)+"px";
    var hh=el.getBoundingClientRect().height||12;var top=Math.round(Math.max(3,Math.min(play.height-hh-3,py-hh/2)));el.style.top=top+"px";clampTag(el,play,3);}}
var labelsUntil=0;
function showLabels(ms,force){labelsUntil=force?performance.now()+ms:Math.max(labelsUntil,performance.now()+ms);}
var labelsOn=null;
function updateLabels(){var on=performance.now()<labelsUntil&&!ovlMode;if(on===labelsOn)return;labelsOn=on;
  for(var i=0;i<TAGDEF.length;i++){var el=document.getElementById(TAGDEF[i].id);if(el)el.className="tag"+(on?"":" off");}}
function potato(x,y,s,peeled,flip,spots,pal){
  var body=pal||(peeled?["#a88830","#c8a848","#e8c868","#f0d890"]:["#4a2810","#6a4020","#8a5a28","#c48a48"]);
  var out=body[0],dk=body[1],md=body[2],hi=body[3];
  var hw=Math.max(2,Math.round(s)),hh=Math.max(2,Math.round(s*0.72));x=Math.round(x);y=Math.round(y);
  for(var dy=-hh-1;dy<=hh+1;dy++){var row=Math.abs(dy)/(hh+0.01);var rw=Math.max(1,Math.round(hw*(1-row*row*0.72)));
    if(Math.abs(dy)>hh){if(rw>1)R(x-rw+1,y+dy,Math.max(1,rw*2-2),1,out);continue;}
    R(x-rw-1,y+dy,(rw+1)*2,1,out);R(x-rw,y+dy,rw*2+(flip?1:0),1,md);if(rw>2)R(x-rw,y+dy,1,1,dk);if(rw>2)R(x+rw-1,y+dy,1,1,dk);}
  R(x-1,y-hh,2,1,hi);R(x-(hw>3?2:1),y-hh+1,hw>3?3:2,1,hi);if(hw>3)R(x-1,y-hh+2,2,1,hi);
  if(!peeled){R(x+(flip?1:-2),y,1,1,dk);if(s>3)R(x+(flip?-2:1),y+1,1,1,out);if(s>4)R(x+(flip?2:-3),y-1,1,1,"#6a4020");if(s>5)R(x+(flip?-1:2),y+2,1,1,dk);}
  else{R(x-1,y,2,1,hi);if(s>3)R(x,y+1,1,1,"#fff3a0");
    if(spots){var sp=[[-2,-1],[2,1],[0,2],[-1,1],[1,-1]];for(var i=0;i<Math.min(spots,sp.length);i++)R(x+sp[i][0],y+sp[i][1],1,1,"#6a4020");}}
}
/* ---------- room pieces ---------- */
function drawFloor(){R(0,0,W,H,"#2a2820");var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);var fw=Math.max(1,ix2-ix),fh=Math.max(1,iy2-iy);
  R(ix,iy,fw,fh,"#9a947c");var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,"#8e876e");}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?"#7a7460":"#a8a288");}
  ctx.strokeStyle="rgba(60,55,40,0.28)";ctx.lineWidth=1;ctx.beginPath();
  for(var x2=ix;x2<=ix+fw;x2+=step){ctx.moveTo(x2+0.5,iy);ctx.lineTo(x2+0.5,iy+fh);}for(var y2=iy;y2<=iy+fh;y2+=step){ctx.moveTo(ix,y2+0.5);ctx.lineTo(ix+fw,y2+0.5);}ctx.stroke();
  /* 0.3: the dashed centre stripe had no use and is hidden (drawCentreStripe, not called) */
  var lcx=wx(gx),lcy=wy(gy);for(var j=0;j<7;j++){ctx.fillStyle="rgba(255,240,180,"+(0.07-j*0.009)+")";ctx.beginPath();ctx.ellipse(lcx,lcy,ws(22+j*6),ws(15+j*4.5),0,0,6.28);ctx.fill();}}
function drawCentreStripe(){var cx=wx(roomW*0.5);for(var y3=wy(WALL+8);y3<wy(roomH*0.72);y3+=Math.max(5,ws(5)))R(cx-ws(3.5),y3,ws(7),1,"#8a846c");}

function drawWalls(){var x0=wx(0),y0=wy(0),x1=wx(roomW),y1=wy(roomH);var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);
  R(x0,y0,x1-x0,iy-y0,"#3a3830");R(x0,iy2,x1-x0,y1-iy2,"#3a3830");R(x0,iy,ix-x0,iy2-iy,"#3a3830");R(ix2,iy,x1-ix2,iy2-iy,"#3a3830");
  var t=Math.max(2,ws(2.4));R(x0,y0,x1-x0,t,"#1a1814");R(x0,y1-t,x1-x0,t,"#1a1814");R(x0,y0,t,y1-y0,"#1a1814");R(x1-t,y0,t,y1-y0,"#1a1814");
  var bs=Math.max(4,ws(5));for(var i=0;i<80;i++){var side=i%4,bx,by;
    if(side===0){bx=x0+t+((i*11)%Math.max(2,x1-x0-t*2));by=y0+t+((i*5)%Math.max(2,iy-y0-t));}
    else if(side===1){bx=x0+t+((i*13)%Math.max(2,x1-x0-t*2));by=iy2+((i*7)%Math.max(2,y1-iy2-t));}
    else if(side===2){bx=x0+t+((i*3)%Math.max(2,ix-x0-t));by=iy+((i*17)%Math.max(2,iy2-iy));}
    else{bx=ix2+((i*3)%Math.max(2,x1-ix2-t));by=iy+((i*19)%Math.max(2,iy2-iy));}
    R(bx,by,bs,Math.max(2,ws(2.2)),(i%3===0)?"#4a4638":"#323028");}
  R(ix,iy,ix2-ix,1,"#5a5648");R(ix,iy2-1,ix2-ix,1,"#2a2820");R(ix,iy,1,iy2-iy,"#5a5648");R(ix2-1,iy,1,iy2-iy,"#2a2820");
  R(ix+1,iy+1,ws(3),iy2-iy-2,"rgba(0,0,0,0.18)");R(ix+1,iy+1,ix2-ix-2,ws(2),"rgba(0,0,0,0.14)");}
function drawChuteBase(){var cx=wx(chute.cx),mouthW=ws(chute.mouthW),y0=wy(2),yLip=wy(chute.lip),wallInner=wy(WALL),y1=yLip;
  for(var y=y0;y<=y1;y++){var t=(y-y0)/Math.max(1,y1-y0);var half=Math.round((mouthW*0.28)+(mouthW*0.22)*t);
    R(cx-half-2,y,(half+2)*2,1,"#3a4038");R(cx-half,y,half*2,1,t<0.18?"#8a9088":"#5a6058");var ih=Math.max(2,half-3);
    if(y>y0+2&&y>wallInner-2)R(cx-ih,y,ih*2,1,"#12141a");else if(y>y0+2)R(cx-ih,y,ih*2,1,"#1a1c18");}
  var half0=Math.round(mouthW*0.28),half1=Math.round(mouthW*0.50);
  R(cx-half0-2,y0,(half0+2)*2,2,"#8a9088");R(cx-half0-1,y0,(half0+1)*2,1,"#c0c8c0");R(cx-half0,y0+1,2,2,"#c0c8c0");R(cx+half0,y0+1,2,2,"#c0c8c0");
  R(cx-(half1-2),y1-1,2,2,"#8a9088");R(cx+(half1-4),y1-1,2,2,"#8a9088");R(cx-half1,y1,half1*2,2,"#4a5048");R(cx-half1,y1,half1*2,1,"#7a8478");
  var ss=[-0.7,-0.35,0.35,0.7];for(var i=0;i<4;i++)R(cx+Math.round(half1*ss[i])-1,y1,2,2,"#9aa49a");
  }
/* ---- HIDDEN PROPS (never called; kept in code, not deleted) ---- */
function drawLamp(){var lx=wx(gx-roomW*0.18),ly=wy((chute.lip+(table.y-table.h/2))*0.5);var r=Math.max(4,ws(4.5));
  oval(lx,ly,r+1,r+1,"#2a2a24");oval(lx,ly,r,r,"#3a3a32");oval(lx,ly,r-2,r-2,"#c8c070");oval(lx,ly,Math.max(1,r-3),Math.max(1,r-3),"#fff3a0");
  R(lx-1,ly-r-Math.max(2,ws(2.2)),2,Math.max(2,ws(2.2)),"#2a2a24");R(lx-2,ly-r-Math.max(2,ws(2.2)),4,1,"#3a3a32");}
function drawDrain(cx,cy,rad){var x=wx(cx),y=wy(cy),r=Math.max(3,ws(rad));oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#5a6058");oval(x,y,r-1,r-1,"#1a1c18");oval(x,y,Math.max(1,r-2),Math.max(1,r-2),"#12141a");
  R(x-(r-2),y,(r-2)*2,1,"#5a6058");R(x,y-(r-2),1,(r-2)*2,"#5a6058");R(x-(r-2),y-Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");R(x-(r-2),y+Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");}
function drawBucket(cx,cy,rad,inner){var x=wx(cx),y=wy(cy),r=Math.max(4,ws(rad));oval(x+1,y+1,r,r,"rgba(0,0,0,0.28)");oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#6a7068");oval(x,y,r-1,r-1,"#4a5048");
  oval(x,y,Math.max(2,r-2),Math.max(2,r-2),inner||"#2a2c28");R(x-1,y-r,2,1,"#c0c8c0");R(x-(r-1),y-1,1,2,"#8a9088");R(x-Math.max(2,r-2),y-r-Math.max(1,ws(1.2)),Math.max(4,(r-2)*2),Math.max(1,ws(1.2)),"#3a2a20");}
function drawPeelBin(cx,cy,bw,bh){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#3a2a18");R(x+1,y+1,w-2,h-2,"#5a4030");R(x+2,y+2,w-4,h-4,"#2a1c10");R(x+1,y+1,w-2,1,"#8a6a40");
  for(var i=0;i<9;i++)R(x+3+srng(i*3)*(w-8),y+3+srng(i*7)*(h-8),Math.max(2,ws(2.2)),Math.max(1,ws(1.2)),i%2?"#e8c070":"#d4a04a");R(x+2,y+h-2,w-4,1,"#2a1c10");}
function drawTable(){var tw=table.w,th=table.h,x=wx(table.x-tw/2),y=wy(table.y-th/2),w=ws(tw),h=ws(th);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  oval(wx(gx)-ws(3),wy(gy)-ws(6),ws(4),ws(2.5),"rgba(80,50,20,0.25)");
  /* old peels on the table */
  var tx=wx(gx),ty=wy(gy);R(tx+ws(6),ty-ws(9),2,1,"#e8c070");R(tx-ws(9),ty-ws(8),2,2,"#d4a04a");R(tx-ws(6),ty-ws(11),2,1,"#f5e0a8");R(tx+ws(9),ty-ws(6),1,1,"#e8c070");}
function drawSack(cx,cy,bw,bh,rot,spill){var x=wx(cx),y=wy(cy),rw=Math.max(4,ws(bw/2)),rh=Math.max(3,ws(bh/2));
  oval(x+1,y+1,rw,rh,"rgba(0,0,0,0.25)");oval(x,y,rw+1,rh+1,"#4a4028");oval(x,y,rw,rh,"#8a7a50");oval(x-1,y-1,Math.max(2,rw-2),Math.max(2,rh-2),"#9a8a60");oval(x-2,y-2,Math.max(1,rw-4),Math.max(1,rh-4),"#a89868");
  R(x-Math.max(1,rw-3),y,Math.max(2,(rw-3)*2),1,"#6a5a38");R(x,y-Math.max(1,rh-3),1,Math.max(2,(rh-3)*2),"#6a5a38");
  if(rot==="n"){R(x-Math.max(2,ws(2)),y-rh-ws(1.5),Math.max(4,ws(4)),Math.max(2,ws(2.2)),"#6a5a38");R(x-1,y-rh-ws(2),2,Math.max(2,ws(1.5)),"#c4b480");}
  else if(rot==="w"){R(x-rw-ws(1.5),y-Math.max(2,ws(2)),Math.max(2,ws(2.2)),Math.max(4,ws(4)),"#6a5a38");R(x-rw-ws(2),y-1,Math.max(2,ws(1.5)),2,"#c4b480");}
  if(spill){potato(x+rw-1,y+rh-1,Math.max(2,ws(2.6)),false,true);potato(x+rw+ws(2),y+1,Math.max(2,ws(2.4)),false,false);}}
function drawCrate(cx,cy,bw,bh,open,lid){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,1,"#8a6a40");R(x,y,1,h,"#6a4a28");R(x,y+h-1,w,1,"#3a200c");R(x+w-1,y,1,h,"#3a200c");
  R(x+1,y+1,w-2,h-2,"#6a4a28");var sl=Math.max(2,ws(2.4));for(var i=0;i<Math.max(2,Math.floor((h-2)/sl));i++)R(x+1,y+1+i*sl,w-2,1,i%2?"#8a6a40":"#5a3a20");
  var b=Math.max(2,ws(2));R(x,y,b,b,"#3a2a18");R(x+w-b,y,b,b,"#3a2a18");R(x,y+h-b,b,b,"#3a2a18");R(x+w-b,y+h-b,b,b,"#3a2a18");
  if(open){var inset=Math.max(2,ws(2));R(x+inset,y+inset,w-inset*2,h-inset*2,"#2a1c10");potato(x+Math.round(w*0.35),y+Math.round(h*0.45),Math.max(2,ws(2.8)),false,false);potato(x+Math.round(w*0.62),y+Math.round(h*0.4),Math.max(2,ws(2.5)),false,true);potato(x+Math.round(w*0.5),y+Math.round(h*0.65),Math.max(2,ws(2.6)),false,false);}
  else if(lid){R(x+1,y+1,w-2,h-2,"#7a5a30");R(x+2,y+Math.round(h*0.45),w-4,1,"#4a3018");R(x+Math.round(w*0.5)-1,y+2,2,h-4,"#5a3a20");}}
function drawShelf(){var x=WALL,y1=roomH*0.20,y2=roomH*0.62,depth=Math.max(5,WALL*0.7);
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x+depth-0.8,y1,0.8,y2-y1,"#3a200c");for(var i=1;i<=4;i++)wr(x,y1+(y2-y1)*i/5,depth,0.7,"#5a3a20");
  var spots=[0.24,0.30,0.36,0.44,0.50,0.56],kinds=["jar","tin","jar","bag","tin","jar"];
  for(var j=0;j<spots.length;j++){var ix=wx(x+depth*0.55),iy=wy(roomH*spots[j]);
    if(kinds[j]==="jar"){oval(ix,iy,ws(1.8),ws(1.8),"#6a3030");oval(ix,iy,ws(1.2),ws(1.2),"#8a4840");R(ix-1,iy-ws(1.8),2,1,"#c4b480");}
    else if(kinds[j]==="tin"){R(ix-ws(1.8),iy-ws(1.4),ws(3.6),ws(2.8),"#5a6058");R(ix-ws(1.8),iy-ws(1.4),ws(3.6),1,"#8a9088");}
    else oval(ix,iy,ws(2.0),ws(1.6),"#6a5a38");}}
function drawToolRack(){var depth=Math.max(4.5,WALL*0.65),x=roomW-WALL-depth,y1=WALL+2,y2=roomH*0.27;
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x,y1+0.8,0.7,y2-y1-1.6,"#5a3a20");
  for(var i=0;i<6;i++){var yy=y1+2+(y2-y1-4)*(i+0.5)/6,hx=wx(x),hy=wy(yy);R(hx-1,hy,2,2,"#8a9088");
    if(i%2===0){R(hx-ws(5.5),hy-1,ws(5.5),Math.max(2,ws(1.6)),"#3a2a20");R(hx-ws(10.5),hy-1,ws(5.2),Math.max(2,ws(1.4)),"#c8d0d8");R(hx-ws(10.5),hy-1,ws(5.2),1,"#e8eef4");}
    else{R(hx-ws(4.8),hy-1,ws(4.8),Math.max(2,ws(1.8)),"#4a3020");R(hx-ws(8.5),hy,ws(4.0),Math.max(1,ws(1.2)),"#c8d0d8");R(hx-ws(8.5),hy,1,Math.max(1,ws(1.2)),"#e8eef4");}}}
function drawPipes(){var x2=chute.cx-chute.mouthW*0.55;wr(WALL+1,WALL+1.4,x2-(WALL+1),2.6,"#4a5048");wr(WALL+1,WALL+1.4,x2-(WALL+1),0.8,"#7a8478");
  var fl=[WALL+4,(WALL+x2)*0.5,x2-3];for(var i=0;i<3;i++)wr(fl[i],WALL+0.7,1.6,4.0,"#6a7068");wr(WALL+1.0,WALL+1.0,3.2,3.2,"#5a6058");
  var px=wx(WALL+2.6),py=wy(WALL+8),r=Math.max(3,ws(3.2));oval(px,py,r+1,r+1,"#3a4038");oval(px,py,r,r,"#6a7068");oval(px,py,r-2,r-2,"#2a2e2a");oval(px,py,Math.max(1,r-3),Math.max(1,r-3),"#12141a");
  var vx=wx(WALL+7),vy=wy(WALL+2.6);oval(vx,vy,ws(2.2),ws(2.2),"#8a9088");R(vx-ws(1.6),vy,ws(3.2),1,"#c0c8c0");R(vx,vy-ws(1.6),1,ws(3.2),"#c0c8c0");
  wr(roomW-WALL-8,WALL+1.4,7,2.4,"#4a5048");wr(roomW-WALL-8,WALL+1.4,7,0.7,"#7a8478");wr(roomW-WALL-9,WALL+0.8,1.6,3.6,"#6a7068");}
function drawMachinePad(cx,cy,bw,bh,kind){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#3a4038");R(x,y,w,1,"#8a9088");R(x,y,1,h,"#6a7068");R(x,y+h-1,w,1,"#2a2e2a");R(x+w-1,y,1,h,"#2a2e2a");R(x+2,y+2,w-4,h-4,"#4a5048");
  var inx=x+Math.max(3,ws(2.5)),iny=y+Math.max(3,ws(2.5)),inw=w-Math.max(6,ws(5)),inh=h-Math.max(6,ws(5));R(inx,iny,inw,inh,"#323830");
  for(var i=0;i<inw;i+=2){R(inx+i,iny,1,1,"#6a7068");R(inx+i,iny+inh-1,1,1,"#2a2e2a");}
  var b=Math.max(1,ws(1.3)),bolts=[[x+2,y+2],[x+w-3-b,y+2],[x+2,y+h-3-b],[x+w-3-b,y+h-3-b]];for(var j=0;j<4;j++){R(bolts[j][0],bolts[j][1],b+1,b+1,"#8a9088");R(bolts[j][0],bolts[j][1],b,b,"#c0c8c0");}
  if(kind==="drum"){oval(x+w/2,y+h/2,ws(3.2),ws(3.2),"#2a2e2a");oval(x+w/2,y+h/2,ws(1.6),ws(1.6),"#1a1c18");}
  else if(kind==="slot")R(x+Math.round(w*0.25),y+Math.round(h*0.45),Math.round(w*0.5),Math.max(2,ws(2)),"#2a2e2a");}
function drawMat(){var cx=roomW*SPOT.mat.x+2,cy=roomH*SPOT.mat.y,mw=19,mh=9;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#5a2a2a");R(x+1,y+1,w-2,h-2,"#8a3a34");
  for(var i=2;i<w-2;i+=3)R(x+i,y+1,1,h-2,"#a04a40");R(x+1,y+Math.round(h/2),w-2,1,"#6a2a28");
  R(x,y,w,1,"#b06a50");for(var j=0;j<h;j+=2){R(x-1,y+j,1,1,"#c4a070");R(x+w,y+j,1,1,"#c4a070");}
  /* pillow at the west end */
  R(x+2,y+2,Math.max(3,ws(4)),h-4,"#d8d0b8");R(x+2,y+2,Math.max(3,ws(4)),1,"#f0ead8");}
function drawCooler(){var cx=roomW*SPOT.food.x,cy=roomH*SPOT.food.y-8.5,bw=11,bh=8;var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#2a4a6a");R(x+1,y+1,w-2,h-2,"#3a6a9a");R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+Math.round(h*0.55),w-2,1,"#24405a");
  R(x+Math.round(w*0.3),y+Math.round(h*0.25),Math.round(w*0.4),Math.max(1,ws(1.4)),"#e8eef4");
  /* stool in front */
  oval(wx(cx+5.5),wy(cy+7),ws(2.2),ws(2.2),"#5a3a20");oval(wx(cx+5.5),wy(cy+7),ws(1.6),ws(1.6),"#8a6a40");}

/* ---- 0.3 redraw: every visible object reads at a glance (top-down, mock 0.1b style) ---- */
function drawShipChute(){drawChuteBase();
  var cx=wx(chute.cx),y0=wy(GEO.ship.top),yl=wy(chute.lip),mw=ws(chute.mouthW);
  /* red up-chevrons inside the funnel: the intake pulls UP into the wall */
  for(var i=0;i<3;i++){var yy=Math.round(y0+(yl-y0)*(0.30+i*0.22)),sp=Math.max(2,Math.round(ws(2)*(0.8+i*0.3)));
    for(var d=0;d<sp;d++){R(cx-d-1,yy+d,2,1,"#d04050");R(cx+d,yy+d,2,1,"#d04050");}}
  /* hazard stripe on the lip */
  var half1=Math.round(mw*0.50),bl=Math.max(2,ws(2.2));for(var x=-half1+2,n=0;x<half1-2;x+=bl,n++)R(cx+x,yl+2,bl,Math.max(1,ws(1.2)),n%2?"#2a2a24":"#e0b020");}
function drawReturnChute(){var G=GEO.ret,x0=G.mouthX,x1=RW-WALL,y=G.y,hh=G.w/2+0.5,len=x1-x0;
  wr(x0+1,y-hh+2,len,hh*2,"rgba(0,0,0,0.28)");
  wr(x0,y-hh,len+0.5,hh*2,"#323830");wr(x0,y-hh+0.4,len+0.5,hh*2-0.8,"#5a6258");wr(x0,y-hh+1.4,len+0.5,hh*2-2.8,"#6a7268");
  wr(x0,y-hh,len+0.5,1.4,"#9aa49a");wr(x0,y+hh-1.6,len+0.5,1.6,"#3a4038");
  /* pipe rings */
  var rx=[x0+3,x0+9,x0+15];for(var i=0;i<rx.length;i++){wr(rx[i],y-hh-0.8,1.4,hh*2+1.6,"#3a4038");wr(rx[i],y-hh-0.8,0.7,hh*2+1.6,"#7a8478");}
  /* green arrows pointing OUT (west) */
  for(var a=0;a<2;a++){var ax=x0+5.5+a*6,ay=y;for(var d=0;d<3;d++){wr(ax+d*0.9,ay-d*0.9,1,1,"#3ad070");wr(ax+d*0.9,ay+d*0.9,1,1,"#3ad070");}}
  /* wall flange */
  wr(x1-0.5,y-hh-2,4.5,hh*2+4,"#3a4038");wr(x1-0.5,y-hh-2,1,hh*2+4,"#8a9088");
  wr(x1+1,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+1,y+hh-0.2,1.2,1.2,"#c0c8c0");
  /* the open mouth */
  var mx=wx(x0),my=wy(y);oval(mx,my,ws(2.6),ws(hh+0.6),"#9aa49a");oval(mx,my,Math.max(1,ws(2.0)),ws(hh-0.2),"#12141a");oval(mx+1,my,Math.max(1,ws(1.2)),ws(hh-1.2),"#06070a");
  /* spill tray on the floor under the mouth */
  wr(x0-7,y-hh+0.5,6,hh*2-1,"rgba(40,50,40,0.22)");for(var t=0;t<3;t++)wr(x0-6+t*2,y-hh+1,0.6,hh*2-2,"rgba(200,210,200,0.18)");}
function drawTable2(){var G=GEO.table,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  /* cutting board (where the potato sits while he peels) */
  var bx=wx(40),by=wy(G.y0+4),bw=ws(20),bh=ws(12);
  R(bx+1,by+1,bw,bh,"rgba(0,0,0,0.25)");R(bx,by,bw,bh,"#8a6a30");R(bx+1,by+1,bw-2,bh-2,"#d8b878");R(bx+1,by+1,bw-2,1,"#ecd29a");
  for(var j=0;j<5;j++)R(bx+3+j*Math.max(2,Math.round(bw/6)),by+3+(j%2)*2,Math.max(2,Math.round(bw/9)),1,"#b8985c");
  /* knife resting beside the board */
  var kx=wx(62),ky=wy(G.y0+9);R(kx,ky,Math.max(3,ws(3.4)),Math.max(2,ws(1.8)),"#3a2a20");R(kx-Math.max(5,ws(5.5)),ky,Math.max(5,ws(5.5)),Math.max(2,ws(1.5)),"#c8d0d8");R(kx-Math.max(5,ws(5.5)),ky,Math.max(5,ws(5.5)),1,"#f0f4f8");}
function drawBed(){var cx=GEO.mat.x,cy=GEO.mat.y,mw=GEO.mat.w,mh=GEO.mat.h;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.25)");R(x,y,w,h,"#3a3a50");R(x+1,y+1,w-2,h-2,"#e8e4d4");
  /* blanket (blue, folded edge) over the east two thirds; pillow at the west end */
  var bw=Math.round(w*0.66);R(x+w-bw-1,y+1,bw,h-2,"#4a6aa8");R(x+w-bw-1,y+1,bw,Math.max(2,Math.round(h*0.22)),"#6a8ac8");
  for(var i=2;i<bw-2;i+=4)R(x+w-bw-1+i,y+Math.round(h*0.3),1,h-Math.round(h*0.3)-2,"#3a5a98");
  R(x+2,y+2,Math.max(3,ws(4.4)),h-4,"#fffaf0");R(x+2,y+2,Math.max(3,ws(4.4)),1,"#ffffff");R(x+2,y+h-3,Math.max(3,ws(4.4)),1,"#c8c0a8");
  R(x,y,w,1,"#6a6a88");}
function drawCooler2(){var G=GEO.cooler,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#1c3a5a");R(x+1,y+1,w-2,h-2,"#3a6a9a");R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+Math.round(h*0.62),w-2,1,"#24405a");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),Math.max(1,ws(1.5)),"#e8eef4");   /* handle */
  /* a can of food on the lid (the stock lives in here) */
  var cw=Math.max(3,ws(3.4)),chh=Math.max(3,ws(3.6)),cx0=x+Math.round(w*0.12),cy0=y+Math.round(h*0.12);
  R(cx0,cy0,cw,chh,"#7a3a10");R(cx0,cy0+1,cw,chh-2,"#e0a040");R(cx0,cy0,cw,1,"#f0e0b0");R(cx0+1,cy0+Math.round(chh/2),Math.max(1,cw-2),1,"#b04020");}
function drawStool(){var x=wx(GEO.stool.x),y=wy(GEO.stool.y),r=Math.max(5,ws(4.4)),q=Math.max(2,Math.round(r*0.34)),lg=Math.round(r*0.95);
  oval(x+1,y+r*0.45,r+1,r*0.7,"rgba(0,0,0,0.30)");
  /* four wooden legs poking out under the cushion */
  ctx.fillStyle="#3a2410";var d=[[-1,-1],[1,-1],[-1,1],[1,1]];for(var i=0;i<4;i++)ctx.fillRect(Math.round(x+d[i][0]*lg-q/2),Math.round(y+d[i][1]*lg*0.8-q/2),q,q);
  /* round red cushion with a dark rim and a highlight, so it reads as a seat and not as a potato */
  oval(x,y,r,r*0.86,"#2a1010");oval(x,y,r-1,r*0.86-1,"#a8302a");oval(x,y,r-2,r*0.86-2,"#c8443a");oval(x-r*0.25,y-r*0.2,Math.max(1,r*0.4),Math.max(1,r*0.28),"#e87a64");}
function drawPileShadow(){var G=GEO.pile;ctx.fillStyle="rgba(40,30,16,0.22)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+1),ws(G.rx+4),ws(G.rz+2),0,0,6.28);ctx.fill();
  ctx.fillStyle="rgba(30,22,10,0.16)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+2),ws(G.rx-4),ws(G.rz-2),0,0,6.28);ctx.fill();}
/* ---------- the pile: 0.2 look (stacked tiers), spread wider and lower along the bottom wall ---------- */
function shadeHex(h,f){var n=parseInt(h.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function c(v){v=Math.round(v*f);return Math.max(0,Math.min(255,v));}return"rgb("+c(r)+","+c(g)+","+c(b)+")";}
var LVF=[0.60,0.74,0.90,1.08,1.25,1.42];
function buildPile(){POS=[];ORDER=[];TIER=[];var G=GEO.pile,cx=G.cx,base=G.base,rx0=G.rx,rz0=G.rz,idx=0;
  var LF=LIFT;
  for(var t=0;idx<PILEMAX;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(100*sc*sc):90;TIER.push(idx);
    for(var j=0;j<cap;j++,idx++){var r=Math.sqrt(((j+0.5)*0.7548776662)%1),th=(((j+0.5)*0.5698402910)%1)*6.28318+t*1.3;   /* R2 low-discrepancy: ANY prefix of a tier is spread over the whole tier, so a small pile already lies wide along the floor */
      var x=cx+rx0*sc*r*Math.cos(th)+(srng(idx*5+2)-0.5)*3,z=base+rz0*sc*r*Math.sin(th)+(srng(idx*3+7)-0.5)*2.2;
      POS.push({x:x,y:z-Math.min(t,9)*LF,z:z,t:t,vi:idx%3,fl:(idx*7)%2});}}
  MAXVIS=POS.length;ORDER=POS.map(function(p,i){return i;});ORDER.sort(function(a,b){var pa=POS[a],pb=POS[b];return pa.t!==pb.t?pa.t-pb.t:pa.y-pb.y;});}
function withCtx(c2,fn){var o=ctx;ctx=c2;try{fn();}finally{ctx=o;}}
function mkSprite(w,h,fn){var c=document.createElement("canvas");c.width=w;c.height=h;withCtx(c.getContext("2d"),fn);return c;}
function buildSprites(){SPR=[];SPRS=[];var sizes=[2.9,3.3,3.7];
  for(var vi=0;vi<3;vi++){var sp=Math.max(3,Math.round(sizes[vi]*k)),hw=Math.max(2,Math.round(sp)),hh=Math.max(2,Math.round(sp*0.72)),w=2*hw+6,hgt=2*hh+7;
    for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++){var base=["#4a2810","#6a4020","#8a5a28","#c48a48"],f=LVF[lv];
      var pal=[shadeHex(base[0],f*0.9),shadeHex(base[1],f),shadeHex(base[2],f),shadeHex(base[3],f)];
      for(var sh=0;sh<2;sh++){(function(sh2){var spr=mkSprite(w,hgt,function(){if(sh2)oval(hw+3+1,hh+4+1,hw+1,hh,"rgba(0,0,0,0.20)");potato(hw+3,hh+3,sp,false,!!fl,0,pal);});
        spr.cx=hw+3;spr.cy=hh+3;(sh2?SPRS:SPR)[(vi*6+lv)*2+fl]=spr;})(sh);}}}
  PEELSPR=[];var pcol=[["#f5e0a8","#e8c070","#b08838"],["#e8c070","#d4a04a","#9a7430"],["#f0d890","#c8a040","#8a6a2a"]];
  var pats=[[".XX.","X..X","...X"],["XX..",".XXX","...."],[".X.","X.X",".XX"],["XXX.","...X",".XX."]];
  for(var q=0;q<12;q++){var pc=pcol[q%3],pt=pats[q%4];PEELSPR[q]=mkSprite(6,5,function(){for(var yy=0;yy<pt.length;yy++)for(var xx=0;xx<pt[yy].length;xx++)if(pt[yy][xx]==="X"){R(1+xx,1+yy+1,1,1,pc[2]);R(1+xx,1+yy,1,1,pc[(xx+yy)%2]);}});}}
/* mess slots: the first peels land right where he works (south of the table), later ones spread out; sorted by distance so the heap grows from his feet */
function buildMess(){MESSPOS=[];var G=GEO.mess,T=GEO.table;
  for(var i=0,tries=0;i<MESSVIS&&tries<6000;tries++){var r=Math.sqrt((i+0.5)/MESSVIS),th2=(i+tries)*2.39996,x=G.cx+G.rx*r*Math.cos(th2)+(srng(tries*3+1)-0.5)*3,y=G.cy+G.rz*r*Math.sin(th2)+(srng(tries*7+3)-0.5)*3;
    if(x<WALL+3||x>RW-WALL-3||y<T.y1+3||y>GEO.pile.base-GEO.pile.rz-8)continue;
    if(Math.abs(x-GEO.mat.x)<GEO.mat.w/2+2&&Math.abs(y-GEO.mat.y)<GEO.mat.h/2+2)continue;
    MESSPOS.push({x:x,y:y,q:(i*5+tries)%12});i++;}}
function renderPile(n){if(!pileLayer||pileLayer.width!==W||pileLayer.height!==H){pileLayer=document.createElement("canvas");pileLayer.width=W;pileLayer.height=H;pileKey=-1;}
  if(pileKey===n)return;pileKey=n;renders.pile++;var c=pileLayer.getContext("2d");c.clearRect(0,0,W,H);
  /* 0.3 shading: a fixed, gentle light ramp by tier (never relative to the heap height) and a soft shadow only under the bottom tier, so a big pile stays readable */
  for(var q=0;q<ORDER.length;q++){var i=ORDER[q];if(i>=n)continue;var p=POS[i],lv=Math.min(4,2+Math.floor(p.t/3)),sp=(p.t===0?SPRS:SPR)[(p.vi*6+lv)*2+p.fl];c.drawImage(sp,wx(p.x)-sp.cx,wy(p.y)-sp.cy);}}
var flying={},messVer=0;
function renderMess(n){if(!messLayer||messLayer.width!==W||messLayer.height!==H){messLayer=document.createElement("canvas");messLayer.width=W;messLayer.height=H;messKey="";}
  var key=n+"|"+messVer;if(messKey===key)return;messKey=key;renders.mess++;var c=messLayer.getContext("2d");c.clearRect(0,0,W,H);
  for(var i=0;i<n&&i<MESSPOS.length;i++){if(flying[i])continue;var p=MESSPOS[i];c.drawImage(PEELSPR[p.q],wx(p.x)-3,wy(p.y)-2);}}
function drawStatic(){drawFloor();drawWalls();
  /* hidden props (0.2.1 t1027, still hidden): drawPipes drawShelf drawToolRack drawMachinePad x3 drawDrain drawPeelBin drawBucket drawSack x4 drawCrate x3 drawLamp; 0.3 also hides drawCentreStripe and the old drawChuteBase/drawCooler/drawMat/drawTable */
  drawPileShadow();drawBed();drawTable2();drawCooler2();drawStool();drawShipChute();drawReturnChute();}
function ensureStatic(){if(staticLayer&&staticLayer.width===W&&staticLayer.height===H)return;drawStatic();var copy=document.createElement("canvas");copy.width=W;copy.height=H;copy.getContext("2d").drawImage(cv,0,0);staticLayer=copy;}

/* ---------- the guy: true top-down, top of the head + shoulders + arms, 4 facings (mock 0.1b look lock, unchanged) ---------- */
function M(dx,dy){switch(GD){case 1:return[GX-dy,GY+dx];case 2:return[GX-dx,GY-dy];case 3:return[GX+dy,GY-dx];default:return[GX+dx,GY+dy];}}
function O(dx,dy,rw,rh,c){var p=M(dx,dy);if(GD&1)oval(p[0],p[1],rh,rw,c);else oval(p[0],p[1],rw,rh,c);}
function limb(x0,y0,x1,y1,x2,y2,w){function seg(a,b,c2,d,ww,col){var dx=c2-a,dy=d-b,n=Math.max(1,Math.round(Math.sqrt(dx*dx+dy*dy)));for(var i=0;i<=n;i++)O(a+dx*i/n,b+dy*i/n,ww/2,ww/2,col);}
  seg(x0,y0,x1,y1,w+1,"#8a6840");seg(x1,y1,x2,y2,w+1,"#8a6840");seg(x0,y0,x1,y1,w-1,"#c4a070");seg(x1,y1,x2,y2,w-1,"#c4a070");}
function hand(x,y,hw){O(x,y,hw+1,hw,"#8a6840");O(x,y,hw,hw-1,"#c4a070");}
function drawGuy(now){
  var g=sim.s.g,a=g.act||{t:"idle"};var u=k;
  var rx=g.x*roomW,ry=g.y*roomH;GX=wx(rx);GY=wy(ry);GD=g.dir|0;
  var hr=Math.max(5,Math.round(6.0*u)),shW=Math.max(hr*2+6,Math.round(17.5*u)),shH=Math.max(5,Math.round(7.2*u));
  var shY=Math.round(hr*0.82),armW=Math.max(3,Math.round(3.8*u)),workY=-hr-Math.max(4,Math.round(4.2*u));
  var armX=Math.round(shW*0.40),armRootY=shY-Math.round(shH*0.42),hw=Math.max(2,Math.round(2.6*u));
  if(a.t==="nap"||a.t==="lazynap"){drawSleeper(now,hr,shW,shH,a.t==="lazynap");return;}
  /* shadow */
  ctx.fillStyle="rgba(0,0,0,0.28)";var sp=M(0,shY+1);ctx.beginPath();ctx.ellipse(sp[0]+0.5,sp[1],(GD&1?shH*0.65:shW*0.5),(GD&1?shW*0.5:shH*0.65),0,0,6.28);ctx.fill();
  /* shoulders + apron strap */
  O(0,shY,shW/2,shH/2+1,"#2a4a62");O(0,shY,shW/2-1,shH/2,"#3a6a8a");O(0,shY-1,Math.max(4,shW/2-3),Math.max(2,shH/2-2),"#5a8aaa");
  var sl=Math.max(3,Math.round(3.8*u));O(-armX,armRootY,sl,sl-1,"#2a4a62");O(-armX,armRootY,sl-1,sl-2,"#3a6a8a");O(armX,armRootY,sl,sl-1,"#2a4a62");O(armX,armRootY,sl-1,sl-2,"#4a7a9a");
  /* scalp, no face */
  O(0,0,hr+1,hr,"#2a2018");O(0,0,hr,hr-1,"#4a3828");O(0,0,hr-1,hr-2,"#5a4634");O(-Math.round(hr*0.18),-Math.round(hr*0.28),Math.max(2,Math.round(hr*0.48)),Math.max(2,Math.round(hr*0.34)),"#6a5640");
  for(var i=0;i<Math.max(4,hr);i++)O(-Math.round(hr*0.12),-hr+2+i,0.5,0.5,"#2a2018");
  var ear=Math.max(1,Math.round(1.4*u));O(-hr,1,ear+0.5,ear,"#a88058");O(hr,1,ear+0.5,ear,"#a88058");
  var t=now/1000;
  if(a.t==="peel"){
    var stroke=Math.sin(t*(g.lazy?5:9)*(sim.spd()))*Math.round(2.4*u);var potX=-Math.round(1.2*u),lH=potX+Math.round(2.2*u),rH=potX+Math.round(5.4*u)+Math.round(stroke);
    limb(-armX,armRootY-1,-armX-Math.round(3.2*u),Math.round((armRootY+workY)/2),lH,workY,armW);
    limb(armX,armRootY-1,armX+Math.round(3.2*u),Math.round((armRootY+workY)/2),rH,workY+Math.round(stroke*0.3),armW);
    hand(lH,workY,hw);hand(rH,workY+Math.round(stroke*0.3),hw);
    var pp=M(potX,workY-Math.round(0.4*u));var pr=g.peel;potato(pp[0],pp[1],Math.max(3.5,4.8*u),pr>0.55,(Math.floor(t*3)%2)===0,pr>0.55?Math.round((1-pr)*10):0);
    /* knife */
    var kb=M(rH-Math.max(6,Math.round(6.8*u))+2,workY-1),kh=M(rH,workY-1);
    if(GD===0){R(kh[0],kh[1],Math.max(3,Math.round(3.6*u)),Math.max(2,Math.round(1.8*u)),"#3a2a20");R(kb[0],kb[1],Math.max(6,Math.round(6.8*u)),Math.max(2,Math.round(1.6*u)),"#c8d0d8");R(kb[0],kb[1],Math.max(6,Math.round(6.8*u)),1,"#f0f4f8");}
  }else if(a.t==="eat"){
    var bite=(Math.sin(t*5)>0);var mY=bite?-hr+1:workY+2;
    limb(-armX,armRootY-1,-armX-Math.round(3*u),Math.round((armRootY+workY)/2),-Math.round(2*u),mY,armW);
    limb(armX,armRootY-1,armX+Math.round(3*u),Math.round((armRootY+workY)/2)+2,Math.round(3*u),workY+3,armW);
    hand(-Math.round(2*u),mY,hw);hand(Math.round(3*u),workY+3,hw);
    var fp=M(-Math.round(2*u),mY-1);R(fp[0]-2,fp[1]-1,4,3,"#e8c070");R(fp[0]-2,fp[1]-1,4,1,"#c08040");
  }else if(a.t==="sweep"){
    var sw2=Math.sin(t*7.5)*Math.round(3.4*u),hx0=-Math.round(1.6*u)+Math.round(sw2*0.35),hy0=workY+Math.round(2.5*u);
    limb(-armX,armRootY-1,-armX-Math.round(2.6*u),Math.round((armRootY+hy0)/2),hx0,hy0,armW);
    limb(armX,armRootY-1,armX+Math.round(2.6*u),Math.round((armRootY+hy0)/2),hx0+Math.round(3.4*u),hy0+Math.round(1.2*u),armW);
    hand(hx0,hy0,hw);hand(hx0+Math.round(3.4*u),hy0+Math.round(1.2*u),hw);
    var tipY=workY-Math.round(8*u),tipX=Math.round(sw2*1.5);
    for(var bi=0;bi<=10;bi++){var bq=bi/10;O(hx0+(tipX-hx0)*bq,hy0+(tipY-hy0)*bq,0.8,0.8,"#8a6840");}
    O(tipX,tipY,Math.max(3,Math.round(3.4*u)),Math.max(1.5,Math.round(1.5*u)),"#5a4020");O(tipX,tipY-1,Math.max(3,Math.round(3.2*u)),Math.max(1,Math.round(1.1*u)),"#c8a860");
  }else if(g.hold){
    /* carrying: both hands forward holding the potato, with a walking bob */
    var bob=a.t==="walk"?Math.round(Math.sin(g.walkPh)*1):0;var cy=workY+2+bob;
    limb(-armX,armRootY-1,-armX-Math.round(2.6*u),Math.round((armRootY+cy)/2),-Math.round(2*u),cy,armW);
    limb(armX,armRootY-1,armX+Math.round(2.6*u),Math.round((armRootY+cy)/2),Math.round(2*u),cy,armW);
    hand(-Math.round(2.4*u),cy,hw);hand(Math.round(2.4*u),cy,hw);
    var cp=M(0,cy-1);potato(cp[0],cp[1],Math.max(3,4.2*u),g.hold==="peeled",false,g.hold==="peeled"&&g.sloppy?3:0);
  }else{
    /* walking or standing: arms at the sides, swinging */
    var sw=a.t==="walk"?Math.round(Math.sin(g.walkPh)*3*u):0;if(a.t==="idle")sw=Math.round(Math.sin(t*1.5)*1);
    var yL=shY-1+sw,yR=shY-1-sw;
    limb(-armX,armRootY,-armX-Math.round(2*u),Math.round((armRootY+yL)/2),-armX-Math.round(1*u),yL-Math.round(3*u),armW);
    limb(armX,armRootY,armX+Math.round(2*u),Math.round((armRootY+yR)/2),armX+Math.round(1*u),yR-Math.round(3*u),armW);
    hand(-armX-Math.round(1*u),yL-Math.round(3*u),hw);hand(armX+Math.round(1*u),yR-Math.round(3*u),hw);
    if(a.t==="grab"){var gp=M(0,workY+2);potato(gp[0],gp[1],Math.max(3,4.0*u),false,false);}
    if(a.t==="drop"){var dp=M(0,workY-Math.round(a.e/sim.dropTime()*6*u));potato(dp[0],dp[1],Math.max(3,4.0*u),true,false);}
  }
}
function drawSleeper(now,hr,shW,shH,lazy){
  /* lying flat (head west), seen from above */
  var t=now/1000;GD=1;
  var breathe=Math.round((Math.sin(t*1.8)+1)*0.6);
  ctx.fillStyle="rgba(0,0,0,0.25)";ctx.beginPath();ctx.ellipse(GX+2,GY+1,shW*0.9,shH*0.75,0,0,6.28);ctx.fill();
  /* body (shoulders + legs) to the east */
  oval(GX+Math.round(shW*0.55),GY,Math.round(shW*0.75),Math.round(shH*0.55)+breathe,"#2a4a62");
  oval(GX+Math.round(shW*0.55),GY,Math.round(shW*0.75)-1,Math.round(shH*0.55)+breathe-1,"#3a6a8a");
  oval(GX+Math.round(shW*1.15),GY,Math.round(shW*0.35),Math.round(shH*0.45),"#4a4038");
  oval(GX+Math.round(shW*1.15),GY,Math.round(shW*0.35)-1,Math.round(shH*0.45)-1,"#6a5a48");
  oval(GX,GY,hr,hr+1,"#2a2018");oval(GX,GY,hr-1,hr,"#4a3828");oval(GX-1,GY-1,Math.max(2,hr-3),Math.max(2,hr-2),"#5a4634");
  oval(GX+Math.round(shW*0.45),GY-Math.round(shH*0.7),2,1,"#c4a070");oval(GX+Math.round(shW*0.45),GY+Math.round(shH*0.7),2,1,"#c4a070");
  /* Zzz */
  for(var i=0;i<3;i++){var ph=((t*0.6+i/3)%1);var zx=GX-2+Math.round(ph*6)+i,zy=GY-hr-3-Math.round(ph*12);ctx.globalAlpha=1-ph;var s=1+(i===2?1:0);
    R(zx,zy,3*s,1,lazy?"#ffb07a":"#e8eef4");R(zx+2*s-1,zy+1,1,1,lazy?"#ffb07a":"#e8eef4");R(zx+1,zy+2,1,1,lazy?"#ffb07a":"#e8eef4");R(zx,zy+3,3*s,1,lazy?"#ffb07a":"#e8eef4");}
  ctx.globalAlpha=1;
}
/* ---------- effects: peels hop off and land flat on the floor; sweep dust; shipping suction (Swarm port) ---------- */
var flights=[],dust=[],sucks=[],dustAcc=0,GX=0,GY=0,GD=0;
function M2(dx,dy){var g=sim.s.g;GX=wx(g.x*roomW);GY=wy(g.y*roomH);GD=g.dir|0;return M(dx,dy);}
function spawnPeel(slot){if(slot<0||slot>=MESSPOS.length||flights.length>60)return;
  var hr=Math.max(5,Math.round(6*k)),o=M2(Math.round((0.8+Math.random()*2.4)*k),-hr-Math.max(4,Math.round(4.2*k))),tp=MESSPOS[slot];
  flights.push({slot:slot,x0:o[0],y0:o[1],tx:wx(tp.x),ty:wy(tp.y),t:0,dur:0.42+Math.random()*0.26,q:tp.q,h:(4+Math.random()*3)*k});flying[slot]=true;messVer++;}
function tickFlights(dt){var np=sim.s.peels;for(var i=flights.length-1;i>=0;i--){var f=flights[i];f.t+=dt;
    if(f.t>=f.dur||f.slot>=np){delete flying[f.slot];flights.splice(i,1);messVer++;}}}
function drawFlights(){for(var i=0;i<flights.length;i++){var f=flights[i],p=Math.min(1,f.t/f.dur),e=1-(1-p)*(1-p);
    var gxp=f.x0+(f.tx-f.x0)*e,gyp=f.y0+(f.ty-f.y0)*e,z=Math.sin(p*Math.PI)*f.h;
    R(Math.round(gxp)-1,Math.round(gyp)+1,3,1,"rgba(40,30,16,0.32)");
    var sp=PEELSPR[(f.q+Math.floor(p*8))%12];ctx.drawImage(sp,Math.round(gxp)-3,Math.round(gyp-z)-2);}}
function tickDust(dt){var g=sim.s.g,a=g.act;
  if(a&&a.t==="sweep"&&a.e>C.sweepWind){var hr2=Math.max(5,Math.round(6*k));var sw=Math.sin(performance.now()/1000*7.5);var o2=M2(Math.round(sw*5*k),-hr2-Math.max(4,Math.round(14*k)));dustAcc+=dt*14;
    while(dustAcc>1){dustAcc-=1;if(dust.length<28)dust.push({x:o2[0]+(Math.random()*6-3),y:o2[1]+(Math.random()*4-2),vx:(Math.random()-0.5)*8,vy:-2-Math.random()*5,life:0.5});}}
  for(var i=dust.length-1;i>=0;i--){var d=dust[i];d.x+=d.vx*dt;d.y+=d.vy*dt;d.life-=dt;if(d.life<=0)dust.splice(i,1);}}
function drawDust(){for(var i=0;i<dust.length;i++){var d=dust[i];ctx.globalAlpha=Math.max(0,d.life*1.6);R(d.x,d.y,2,1,"#d8c898");}ctx.globalAlpha=1;}
/* shipping: the skinned potato is simply sucked up the intake (Swarm's 3 pulsing red rings + a shrinking swirl), 0.5 s, nothing lingers */
var SUCK_T=0.5;
function pushSuck(sloppy){if(sucks.length<6)sucks.push({t:0,sl:!!sloppy});}
function tickSucks(dt){for(var i=sucks.length-1;i>=0;i--){sucks[i].t+=dt;if(sucks[i].t>=SUCK_T)sucks.splice(i,1);}}
function drawSucks(){var cx=wx(chute.cx),topY=wy(GEO.ship.top+4),y0=wy(SPOT.ship.y-16);
  for(var i=0;i<sucks.length;i++){var s=sucks[i],p=s.t/SUCK_T,e=Math.pow(p,1.6),sw=Math.sin(p*Math.PI*2)*ws(3)*(1-p);
    potato(cx+sw,y0+(topY-y0)*e,Math.max(2,Math.round(Math.max(3,ws(3.1))*(1-0.65*p))),true,i%2===1,s.sl?3:0);
    var tt=performance.now()/1000;ctx.save();ctx.globalAlpha=(0.30+0.18*Math.sin(tt*20))*(1-p*0.6);ctx.strokeStyle="#ff3050";ctx.lineWidth=1;
    for(var q=0;q<3;q++){ctx.beginPath();ctx.arc(cx,topY+ws(2),ws(4)+((tt*16+q*5.4)%ws(13)),0,6.28);ctx.stroke();}ctx.restore();}}
/* return chute: raw potatoes come OUT of the mouth (clipped inside the pipe), tumble and bounce, roll and settle onto their slot in the pile.
   The schedule (exit + rest times) comes from PPSim.spill(t0,n): the sim lands each potato at exactly the time drawn here. */
var RT=0,retLight=0;
/* where potato j of the batch is at time RT (canvas px): phase A it slides out of the mouth (clipped inside the pipe), phase B it bounces/rolls to its slot. Shared by the drawing and the test hook. */
function retPos(kk,sc,j,rt){var s=sim.s,mx=GEO.ret.mouthX,ex=sc.ex[j],ld=sc.ld[j],p=(rt-ex)/(ld-ex);if(p<0)return null;if(p>1)p=1;
  var idx=Math.min(MAXVIS-1,s.pile+(j-kk.landed)),tp=POS[idx],tx=wx(tp.x),ty=wy(tp.y),key=Math.round(kk.t0*100);
  var sy=GEO.ret.y+(srng(key+j*17)-0.5)*3.6,spx=wx(mx),spy=wy(sy);
  var pA=Math.min(1,p/0.18),pB=Math.min(1,Math.max(0,(p-0.18)/0.82)),bn=2+Math.floor(srng(key+j*31)*2.99),amp=(5+srng(j*7+Math.round(kk.t0*10))*5)*k;
  var x,y,z=0;
  if(pB<=0){x=spx+ws(4)-ws(13)*pA;y=spy;}
  else{var e=1-Math.pow(1-pB,2.3),bx=spx-ws(9);x=bx+(tx-bx)*e;y=spy+(ty-spy)*Math.pow(pB,0.85);z=Math.abs(Math.sin(pB*Math.PI*bn))*amp*Math.pow(1-pB,1.4);}
  return {x:x,y:y,z:z,p:p,inPipe:pB<=0,ex:ex,ld:ld,tx:tx,ty:ty,mouthX:spx,slot:idx};}
function drawReturn(){var s=sim.s,kk=s.suck;if(!kk)return;var sc=PPSim.spill(kk.t0,kk.n);retLight=0;
  for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);if(!q)break;
    if(RT-q.ex<0.3)retLight=1;
    ctx.fillStyle="rgba(0,0,0,0.30)";ctx.beginPath();ctx.ellipse(q.x,q.y+ws(2.2),ws(2.8),ws(1.3),0,0,6.28);ctx.fill();
    if(q.inPipe){ctx.save();ctx.beginPath();ctx.rect(0,0,q.mouthX-ws(1.2),H);ctx.clip();}
    potato(q.x,q.y-q.z,Math.max(3,ws(3.3)),false,Math.floor(q.p*9)%2===0,0,["#5a3418","#7a4c28","#9a6a34","#d89a54"]);
    if(q.inPipe)ctx.restore();}
  if(retLight){var my=wy(GEO.ret.y-GEO.ret.w/2-0.2);R(wx(GEO.ret.mouthX+8),my,2,1,"#40ff70");}}
function drawScene(now){if(W<2||H<2)return;ensureStatic();var s=sim.s;ctx.drawImage(staticLayer,0,0);
  renderMess(Math.min(s.peels,MESSVIS));ctx.drawImage(messLayer,0,0);
  renderPile(Math.min(s.pile,MAXVIS));ctx.drawImage(pileLayer,0,0);
  drawGuy(now);drawFlights();drawDust();drawSucks();drawReturn();}

/* ---------- HUD ---------- */
var $=function(id){return document.getElementById(id);};
var hud={};
function coinIcon(){var g=$("coinIco").getContext("2d");var r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};
  r(3,1,8,12,"#c4a020");r(4,0,6,14,"#c4a020");r(2,2,10,10,"#c4a020");r(4,1,6,12,"#ffe066");r(3,2,8,10,"#ffe066");r(5,2,4,10,"#fff3a0");r(4,3,6,8,"#fff3a0");r(6,5,2,5,"#c4a020");r(5,6,4,1,"#c4a020");
  var f=$("foodIco").getContext("2d");var q=function(x,y,w,h,c){f.fillStyle=c;f.fillRect(x,y,w,h);};
  q(1,5,12,7,"#5a3a20");q(2,6,10,5,"#c08040");q(2,4,10,2,"#e8c070");q(3,3,8,1,"#f5e0a8");q(4,7,2,2,"#7a4a20");q(8,8,2,1,"#7a4a20");
  var pl=$("peelIco").getContext("2d");var w=function(x,y,ww,h,c){pl.fillStyle=c;pl.fillRect(x,y,ww,h);};
  w(2,3,9,2,"#b08838");w(2,2,9,2,"#f5e0a8");w(10,4,2,4,"#e8c070");w(3,6,9,2,"#d4a04a");w(3,5,8,2,"#f5e0a8");w(2,8,2,3,"#e8c070");w(3,10,9,2,"#b08838");w(3,9,9,2,"#e8c070");}
function setText(id,v){if(hud[id]!==v){hud[id]=v;$(id).textContent=v;}}
var boxSnap="";
function messPct(){return Math.round((1-sim.messF())*100);}
function updateHud(){var s=sim.s;var bs="",ci;for(ci=0;ci<CMDS.length;ci++)bs+=s.box[CMDS[ci].id]+",";bs+=s.potCap+","+s.up.chute;if(bs!==boxSnap){boxSnap=bs;renderAll();}
  setText("coins",String(s.coins));setText("peels",String(s.peels));var mp=messPct();
  var pe=$("peelRow"),pc="food peels"+(mp>=22?" filthy":(mp>=8?" messy":""));if(hud.pc!==pc){hud.pc=pc;pe.className=pc;}
  var mt=mp>=1?"MESS: "+mp+"% SLOWER":"";if(hud.mt!==mt){hud.mt=mt;var me=$("mess");me.textContent=mt;me.className="mess"+(mp>=8?" on":"");}setText("food",s.food+(s.food>=sim.foodMax()?" MAX":""));
  $("foodRow").className="food"+(s.food<=0?" out":"");
  var h=Math.round(s.hunger),e=Math.round(s.energy);
  if(hud.h!==h){hud.h=h;$("hFill").style.transform="scaleX("+(h/100)+")";$("hPct").textContent=h+"%";$("hBar").className="bar hunger"+(h<20?" low":"");}
  if(hud.e!==e){hud.e=e;$("eFill").style.transform="scaleX("+(e/100)+")";$("ePct").textContent=e+"%";$("eBar").className="bar energy"+(e<20?" low":"");}
  var st=sim.stateName();if(hud.st!==st){hud.st=st;var els=document.querySelectorAll(".st");for(var i=0;i<els.length;i++)els[i].classList.toggle("on",els[i].getAttribute("data-s")===st);}
  var a=s.g.act;setText("doing",a&&a.label?a.label:"");
  /* object labels carry live numbers */
  tagText("tagFood","FOOD x"+s.food);tagText("tagPot","POTATOES "+POTS[s.box.pot]);tagText("tagRet",s.chute>0?"RETURN "+s.chute+"/"+sim.chuteCap():"RETURN");
  var can=s.coins>=Math.min(sim.price(),sim.potPrice()||9999)?" can":"";var sb=$("shopBtn");var sc2="shopb"+can;if(hud.sb!==sc2){hud.sb=sc2;sb.className=can?"can":"";}
  if(ovlMode){$("ovlCoins").textContent=ovlMode==="shop"?s.coins+"c":"";if(ovlDirty){ovlDirty=false;buildOvl();}}
  updateHint();}
function tagText(id,t){var key="t"+id;if(hud[key]!==t){hud[key]=t;var el=$(id);el.textContent=t;if(playRect)placeTagsSoon();}}
var tagTimer=0;function placeTagsSoon(){if(tagTimer)return;tagTimer=setTimeout(function(){tagTimer=0;if(playRect)placeTags();},60);}
var hintShown="",migUntil=0;
function updateHint(){var s=sim.s,msg="";
  if(migrated&&performance.now()<migUntil)msg="Welcome back. Your "+migrated+" save was carried over ("+migrated+" itself is untouched).";
  else if(s.peels>=45&&s.box.clean===0&&s.t<7200)msg="The floor is a mess: he works "+messPct()+"% slower. Set CLEAN WHEN PEELS > to make him sweep.";
  else if(s.box.eat===0&&s.box.nap===0&&s.t<240)msg="Tap a box to unlock its slider. Set EAT and NAP or he goes lazy. HELP explains every box.";
  else if(s.box.eat>0&&s.food<=0&&s.hunger<s.box.eat)msg="Out of food! He's slacking. Open the SHOP (or set KEEP FOOD AT LEAST).";
  else if(s.g.lazy&&s.box.eat===0&&s.hunger<C.lazyLow)msg="Hungry and no EAT box set: he's going lazy.";
  else if(s.g.lazy&&s.box.nap===0&&s.energy<C.lazyLow)msg="Tired and no NAP box set: he naps wherever.";
  if(msg!==hintShown){hintShown=msg;var el=$("hint");if(msg){el.textContent=msg;el.className="";}else el.className="off";}}
function popCoin(v,sloppy){var el=document.createElement("div");el.className="pop";el.textContent="+"+v+"c"+(sloppy?" sloppy":"");
  var x=(wx(chute.cx)/W)*playRect.width,y=(wy(chute.lip+6)/H)*playRect.height;el.style.left=Math.round(x+8)+"px";el.style.top=Math.round(y)+"px";$("play").appendChild(el);pops.push({el:el,t:0,y:y});}
function tickPops(dt){for(var i=pops.length-1;i>=0;i--){var p=pops[i];p.t+=dt;p.el.style.transform="translateY("+(-p.t*22)+"px)";p.el.style.opacity=String(Math.max(0,1-p.t/1.2));if(p.t>1.2){p.el.parentNode&&p.el.parentNode.removeChild(p.el);pops.splice(i,1);}}}

/* ---------- command panel: scroll-safe (Jay t1015) ----------
   Built from PPSim.COMMANDS, the same table the HELP screen reads, so the two can never drift apart.
   A slider is LOCKED until you tap its box (the box lights up). Vertical drags always scroll the panel and never move a slider.
   + and - always work (they act on a clean tap). SHOP / HELP also need a clean tap, so scrolling can't open them. A slide applies its value where the finger lifts. */
var cmd=$("cmd"),focusId=null;
function fmt(id,v){
  if(id==="pace")return PACE[v]+" x"+SPD[v];
  if(id==="pot")return String(POTS[v]);
  if(id==="clean")return v>0?"> "+v:"OFF";
  if(id==="style")return STYLE[v].n+" x"+STYLE[v].sp;
  if(id==="wake")return v+"%";
  if(id==="autob")return v>0?">= "+v:"OFF";
  return v>0?"< "+v+"%":"OFF";}
function bmax(id){return id==="pot"?Math.max(1,sim.potMax()):BOX[id].max;}
function pct(id,v){var b=BOX[id];return (v-b.min)/(bmax(id)-b.min);}
var UNSET={eat:1,nap:1,clean:1,autob:1};
function buildPanel(){var h="";
  for(var i=0;i<CMDS.length;i++){var c=CMDS[i];
    h+='<div class="box" data-id="'+c.id+'"><button class="pm" data-d="1" aria-label="'+c.name+' up">+</button><div class="mid"><div class="top"><span class="nm">'+c.name.replace(/</g,"&lt;").replace(/>/g,"&gt;")+'</span><span class="lk"></span><span class="val"></span></div><div class="trk"><div class="ln"></div><div class="fill"></div><div class="kn"></div></div></div><button class="pm" data-d="-1" aria-label="'+c.name+' down">&minus;</button></div>';}
  $("boxes").innerHTML=h;}
function renderTicks(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),trk=el.querySelector(".trk"),b=BOX[id],mx=bmax(id),old=trk.querySelectorAll(".tk");for(var j=0;j<old.length;j++)trk.removeChild(old[j]);
  var n=Math.max(1,Math.round((mx-b.min)/b.step)),tn=Math.min(n,14);for(var i=0;i<=tn;i++){var t=document.createElement("i");t.className="tk";t.style.left=(i/tn*100)+"%";trk.appendChild(t);}}
function renderBox(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),v=sim.s.box[id],p=pct(id,v);
  el.querySelector(".kn").style.left=((1-p)*100)+"%";el.querySelector(".fill").style.width=(p*100)+"%";el.querySelector(".val").textContent=fmt(id,v);
  el.classList.toggle("unset",!!UNSET[id]&&v===0);el.classList.toggle("focus",focusId===id);el.querySelector(".lk").textContent=focusId===id?"<SLIDE>":"";
  var key=id==="pot"?"tk"+sim.potMax():"tk";if(el.getAttribute("data-tk")!==key){el.setAttribute("data-tk",key);renderTicks(id);}}
function renderAll(){for(var id in BOX)renderBox(id);}
function setFocus(id){focusId=id;renderAll();}
buildPanel();
function changed(){renderAll();updateHud();saveGame();}
function valFromX(id,trk,clientX){var r=trk.getBoundingClientRect(),b=BOX[id];var q=(clientX-r.left)/r.width;q=Math.max(0,Math.min(1,q));return b.min+(1-q)*(bmax(id)-b.min);}
var G=null; /* the active gesture */
var SLOP=8;
function doAct(a){
  if(a==="shop")openOvl("shop");else if(a==="help")openOvl("help");else if(a==="close")closeOvl();
  else if(a==="book:next")flipBook(1);else if(a==="book:prev")flipBook(-1);
  else if(a&&a.indexOf("buy:")===0)shopBuy(a.slice(4));}
cmd.addEventListener("pointerdown",function(e){if(G&&G.id!==e.pointerId)return;
  var t=e.target,box=t.closest?t.closest(".box"):null,pm=t.closest?t.closest(".pm"):null,trk=t.closest?t.closest(".trk"):null,btn=t.closest?t.closest("#bar button"):null;
  G={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:cmd.scrollTop,box:box,bid:box?box.getAttribute("data-id"):null,pm:pm,trk:trk,btn:btn,mode:null};
  if(pm)pm.classList.add("press");if(btn)btn.classList.add("press");
  try{cmd.setPointerCapture(e.pointerId);}catch(x){}
  e.preventDefault();});
cmd.addEventListener("pointermove",function(e){if(!G||G.id!==e.pointerId)return;var dx=e.clientX-G.x0,dy=e.clientY-G.y0;
  if(G.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){
    if(Math.abs(dy)>=Math.abs(dx)*0.75)G.mode="scroll";
    else if(G.bid&&G.bid===focusId&&(G.trk||(!G.pm)))G.mode="slide";
    else G.mode="none";
    if(G.pm)G.pm.classList.remove("press");if(G.btn)G.btn.classList.remove("press");}
  if(G.mode==="scroll")cmd.scrollTop=G.st0-dy;
  else if(G.mode==="slide"){var trk=G.box.querySelector(".trk");if(sim.setBox(G.bid,valFromX(G.bid,trk,e.clientX)))changed();}});
function endG(e,cancel){if(!G||G.id!==e.pointerId)return;var g=G;G=null;if(g.pm)g.pm.classList.remove("press");if(g.btn)g.btn.classList.remove("press");
  /* a slide ends where the finger lifts: a slow WebView may not deliver a final move */
  if(!cancel&&g.mode==="slide"){var tk=g.box.querySelector(".trk");if(sim.setBox(g.bid,valFromX(g.bid,tk,e.clientX)))changed();return;}
  if(cancel||g.mode!==null)return;
  /* slow old WebViews can deliver a swipe as down -> up with few or no moves: judge by where the finger lifted */
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)cmd.scrollTop=g.st0-dy;return;}
  /* a clean tap */
  if(g.pm&&g.bid){var d=+g.pm.getAttribute("data-d");setFocus(g.bid);if(sim.setBox(g.bid,sim.s.box[g.bid]+d*BOX[g.bid].step))changed();return;}
  if(g.btn){doAct(g.btn.getAttribute("data-act"));return;}
  if(g.bid){if(focusId===g.bid&&g.trk){if(sim.setBox(g.bid,valFromX(g.bid,g.trk,e.clientX)))changed();}else setFocus(g.bid);return;}
  setFocus(null);}
cmd.addEventListener("pointerup",function(e){endG(e,false);});
cmd.addEventListener("pointercancel",function(e){endG(e,true);});
cmd.addEventListener("lostpointercapture",function(e){if(G&&G.id===e.pointerId&&G.mode!==null)endG(e,true);});
var GL=[];window.__ppGL=GL;["pointerdown","pointermove","pointerup","pointercancel"].forEach(function(t){cmd.addEventListener(t,function(e){GL.push(t.slice(7)+":"+Math.round(e.clientX)+","+Math.round(e.clientY)+(G?":"+G.mode:""));if(GL.length>40)GL.shift();},true);});
cmd.addEventListener("click",function(e){e.preventDefault();});
$("play").addEventListener("pointerdown",function(){if(focusId)setFocus(null);showLabels(8000);});

/* ---------- shop + help screens (same scroll-safe rule: a tap is judged where the finger lifts; drags scroll) ---------- */
var ovl=$("ovl"),ovlBody=$("ovlBody"),ovlMode=null,ovlDirty=false,OG=null;
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function goBtn(act,price,state){var cls="go"+(state==="poor"?" poor":"")+(state==="done"?" done":"");
  return '<button class="'+cls+'" type="button" data-act="'+act+'">'+(state==="done"?"MAXED":price+"c<br>BUY")+'</button>';}
function buildShop(){var s=sim.s,h="",pr=sim.price(),fm=sim.foodMax();
  h+='<div class="sec">FOOD</div>';
  h+='<div class="row"><div class="tx"><div class="nm">FOOD CAN <b>'+s.food+' / '+fm+'</b></div><div class="fx">One can = +55 hunger when he eats. The price climbs a little with each can and slowly over time.</div></div>'+(s.food>=fm?goBtn("buy:food",pr,"done"):goBtn("buy:food",pr,s.coins<pr?"poor":""))+'</div>';
  h+='<div class="sec">POTATOES</div>';var pp=sim.potPrice(),cap=s.potCap;
  h+='<div class="row"><div class="tx"><div class="nm">MORE POTATOES <b>'+POTS[cap]+(pp===null?'':' &rarr; '+POTS[cap+1])+'</b></div><div class="fx">You own '+POTS[cap]+'. Buying raises your limit to the next stop and puts the new potatoes on the pile. The POTATOES IN PLAY slider goes up to what you own.</div></div>'+(pp===null?goBtn("buy:pot",0,"done"):goBtn("buy:pot",pp,s.coins<pp?"poor":""))+'</div>';
  h+='<div class="sec">UPGRADES</div>';
  for(var i=0;i<UPS.length;i++){var u=UPS[i],lv=sim.up(u.id),p2=sim.upPrice(u.id);
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(u.name)+' <b>LV '+lv+'/'+u.max+'</b></div><div class="fx">'+esc(u.fx)+'</div></div>'+(p2===null?goBtn("buy:up:"+u.id,0,"done"):goBtn("buy:up:"+u.id,p2,s.coins<p2?"poor":""))+'</div>';}
  ovlBody.innerHTML=h;}
/* ---- the HELP booklet: cover, one page per command (generated from PPSim.COMMANDS), a last page on the loop. Flip with PREV / NEXT or a sideways swipe. ---- */
var bookPage=0;
function bookPages(){return CMDS.length+2;}      /* cover + commands + loop */
function icoDraw(cv2,id){var g=cv2.getContext("2d"),r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};g.clearRect(0,0,16,16);
  if(id==="cover"){r(2,2,12,12,"#8a5a28");r(3,3,10,10,"#c48a48");r(4,4,8,2,"#e8c070");r(5,8,2,2,"#6a4020");r(9,9,2,2,"#6a4020");r(6,11,2,1,"#6a4020");}
  else if(id==="pace"){r(1,6,3,1,"#8a6a40");r(0,9,4,1,"#8a6a40");r(2,12,3,1,"#8a6a40");r(5,3,3,10,"#c0361e");r(8,5,2,6,"#c0361e");r(10,6,2,4,"#c0361e");r(12,7,2,2,"#c0361e");}
  else if(id==="eat"){r(3,4,10,9,"#7a3a10");r(3,5,10,7,"#e0a040");r(3,4,10,1,"#f0e0b0");r(4,8,8,2,"#b04020");r(6,2,4,2,"#9aa49a");}
  else if(id==="nap"){r(1,5,14,8,"#3a3a50");r(2,6,12,6,"#e8e4d4");r(6,7,8,5,"#4a6aa8");r(2,7,4,4,"#fffaf0");r(9,3,3,1,"#4a6aa8");r(11,2,3,1,"#4a6aa8");r(9,4,3,1,"#4a6aa8");}
  else if(id==="clean"){for(var i=0;i<9;i++)r(11-i,1+i,2,2,"#8a6840");r(1,10,8,5,"#c8a860");r(1,13,8,2,"#8a6a30");for(var j=0;j<4;j++)r(2+j*2,10,1,5,"#5a4020");}
  else if(id==="pot"){r(4,5,8,7,"#8a5a28");r(3,6,10,5,"#8a5a28");r(5,4,6,1,"#c48a48");r(5,5,3,1,"#e8c070");r(6,8,1,1,"#4a2810");r(9,9,1,1,"#4a2810");r(7,11,1,1,"#4a2810");r(4,12,8,1,"#4a2810");}
  else if(id==="style"){r(2,10,5,3,"#3a2a20");r(6,8,8,3,"#c8d0d8");r(7,8,7,1,"#f0f4f8");r(12,7,2,1,"#c8d0d8");r(3,3,2,1,"#e8c070");r(6,2,3,1,"#e8c070");r(10,4,2,1,"#e8c070");}
  else if(id==="wake"){r(6,6,4,4,"#ffe066");r(5,7,6,2,"#ffe066");r(7,2,2,2,"#ffd060");r(7,12,2,2,"#ffd060");r(2,7,2,2,"#ffd060");r(12,7,2,2,"#ffd060");r(4,4,1,1,"#ffd060");r(11,4,1,1,"#ffd060");r(4,11,1,1,"#ffd060");r(11,11,1,1,"#ffd060");}
  else if(id==="autob"){r(2,6,9,8,"#7a3a10");r(2,7,9,6,"#e0a040");r(2,6,9,1,"#f0e0b0");r(9,1,5,5,"#c4a020");r(10,2,3,3,"#ffe066");r(11,3,1,1,"#c4a020");}
  else{r(1,7,3,3,"#8a6a40");r(3,6,10,5,"#3a4038");r(4,7,8,3,"#12141a");r(5,3,6,1,"#c0361e");r(7,2,2,1,"#c0361e");r(5,12,6,1,"#3ad070");}}
function miniSlider(c,v){var mx=c.id==="pot"?Math.max(1,sim.potMax()):c.max,p=(v-c.min)/(mx-c.min),n=Math.max(1,Math.round((mx-c.min)/c.step)),tn=Math.min(n,14),tk="";
  for(var i=0;i<=tn;i++)tk+='<i class="tk" style="left:'+(i/tn*100)+'%"></i>';
  return '<div class="mini"><span class="e">'+esc(c.hi)+'</span><div class="mt"><div class="ln"></div><div class="mf" style="width:'+(p*100)+'%"></div>'+tk+'<div class="mk" style="left:'+((1-p)*100)+'%"></div></div><span class="e r">'+esc(c.lo)+'</span></div>';}
function pageHtml(pg){var s=sim.s,N=bookPages(),pn='<span class="pn">'+(pg+1)+' / '+N+'</span>';
  if(pg===0)return '<div id="pg" class="cover"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><div class="t1">PAPA POTATO</div><div class="t2">HANDBOOK</div><button class="go2" type="button" data-act="book:next">OPEN THE BOOK</button><div class="note" style="margin-top:12px;color:#d8b878">'+CMDS.length+' commands, one page each</div></div>';
  if(pg===N-1)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="loop" width="16" height="16"></canvas><b>THE LOOP</b></div><div class="lb">WHAT HE DOES</div><div class="chips"><span>PILE</span><span>&gt; PEEL TABLE</span><span>&gt; SHIP IN</span><span>&gt; RETURN</span><span>&gt; PILE</span></div><div class="tx">Peels pop off onto the floor and slow him down. A full chute spills back out of RETURN.</div><div class="lb">YOUR COINS GO TO</div><div class="chips"><span>FOOD</span><span>POTATOES</span><span>UPGRADES</span></div><div class="tx">Open the SHOP. Tap the room to see object names.</div></div>';
  var c=CMDS[pg-1],v=s.box[c.id];
  return '<div id="pg" data-cmd="'+c.id+'">'+pn+'<div class="hd"><canvas class="ic" data-ic="'+c.id+'" width="16" height="16"></canvas><b>'+esc(c.name)+'</b></div><div class="lb">DOES</div><div class="tx">'+esc(c.does)+'</div><div class="lb">SLIDER</div>'+miniSlider(c,v)+'<div class="now">NOW: '+esc(fmt(c.id,v))+'</div><div class="lb">AFFECTS</div><div class="tx">'+esc(c.affects)+'</div><div class="lb">RANGE</div><div class="rg">'+esc(c.range)+'</div></div>';}
function buildBook(dir){var N=bookPages(),h='<div id="book">'+pageHtml(bookPage)+'<div id="bkNav"><button type="button" data-act="book:prev"'+(bookPage<=0?' class="dis"':'')+'>&lt; PREV</button><div class="dots">';
  for(var i=0;i<N;i++)h+='<i'+(i===bookPage?' class="on"':'')+'></i>';h+='</div><button type="button" data-act="book:next"'+(bookPage>=N-1?' class="dis"':'')+'>NEXT &gt;</button></div></div>';
  ovlBody.innerHTML=h;var cs=ovlBody.querySelectorAll("canvas.ic");for(var j=0;j<cs.length;j++)icoDraw(cs[j],cs[j].getAttribute("data-ic"));
  if(dir){var pg=$("pg");pg.className=(pg.className?pg.className+" ":"")+(dir>0?"flipn":"flipp");}}
function flipBook(d){d=+d;d=d>0?1:(d<0?-1:0);var n=Math.max(0,Math.min(bookPages()-1,bookPage+d));if(n===bookPage)return false;bookPage=n;buildBook(d);return true;}
function buildOvl(){var st=ovlBody.scrollTop;ovlBody.className=ovlMode==="help"?"book":"";if(ovlMode==="shop")buildShop();else if(ovlMode==="help")buildBook(0);ovlBody.scrollTop=ovlMode==="shop"?st:0;$("ovlCoins").textContent=ovlMode==="shop"?sim.s.coins+"c":"";}
function openOvl(mode){ovlMode=mode;ovl.className="on";$("ovlTitle").textContent=mode==="shop"?"SHOP":"HELP BOOKLET";ovlBody.scrollTop=0;if(mode==="help")bookPage=0;buildOvl();if(focusId)setFocus(null);}
function closeOvl(){ovlMode=null;ovl.className="";OG=null;}
function flash(btn,txt){if(!btn)return;var old=btn.innerHTML;btn.innerHTML=txt;setTimeout(function(){if(ovlMode)ovlDirty=true;},700);}
function shopBuy(what){var r,btn=ovl.querySelector('[data-act="buy:'+what+'"]'),pr;
  if(what==="food"){pr=sim.price();r=sim.buyFood();}
  else if(what==="pot"){pr=sim.potPrice();r=sim.buyPotatoes();}
  else if(what.indexOf("up:")===0){var id=what.slice(3);pr=sim.upPrice(id);r=sim.buyUp(id);}
  else return "bad";
  if(r==="ok"){if(btn)btn.innerHTML="BOUGHT!";setTimeout(function(){ovlDirty=true;},600);changed();}
  else if(r==="poor"){if(btn)btn.innerHTML="NEED<br>"+pr+"c";setTimeout(function(){ovlDirty=true;},800);}
  else{if(btn)btn.innerHTML=r==="full"?"FULL":"MAXED";setTimeout(function(){ovlDirty=true;},800);}
  updateHud();saveGame();return r;}
ovl.addEventListener("pointerdown",function(e){if(OG&&OG.id!==e.pointerId)return;var t=e.target,btn=t.closest?t.closest("[data-act]"):null;
  OG={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:ovlBody.scrollTop,btn:btn,mode:null};if(btn)btn.classList.add("press");
  try{ovl.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();});
ovl.addEventListener("pointermove",function(e){if(!OG||OG.id!==e.pointerId)return;var dx=e.clientX-OG.x0,dy=e.clientY-OG.y0;
  if(OG.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){OG.mode=Math.abs(dy)>=Math.abs(dx)*0.75?"scroll":"none";if(OG.btn)OG.btn.classList.remove("press");}
  if(OG.mode==="scroll")ovlBody.scrollTop=OG.st0-dy;});
function endO(e,cancel){if(!OG||OG.id!==e.pointerId)return;var g=OG;OG=null;if(g.btn)g.btn.classList.remove("press");if(cancel)return;
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(ovlMode==="help"&&Math.abs(dx)>=40&&Math.abs(dx)>=Math.abs(dy)*1.2){flipBook(dx<0?1:-1);return;}   /* sideways swipe turns the page, judged where the finger lifts */
  if(g.mode!==null)return;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)ovlBody.scrollTop=g.st0-dy;return;}
  if(g.btn)doAct(g.btn.getAttribute("data-act"));}
ovl.addEventListener("pointerup",function(e){endO(e,false);});
ovl.addEventListener("pointercancel",function(e){endO(e,true);});
ovl.addEventListener("click",function(e){e.preventDefault();});

/* ---------- main loop: time runs only while the game is open and visible ---------- */
function events(){var ev=sim.s.ev;while(ev.length){var e=ev.shift();if(e.k==="coin"){popCoin(e.v,e.sloppy);pushSuck(e.sloppy);}else if(e.k==="peel")spawnPeel(e.slot);}}
var last=0,acc=0,STEP=0.05,paused=false,frames=0;
function frame(ts){
  var dt=last?Math.min(0.25,(ts-last)/1000):0;last=ts;
  if(!paused){acc+=dt;while(acc>=STEP){sim.step(STEP);acc-=STEP;}events();tickFlights(dt);tickDust(dt);tickSucks(dt);tickPops(dt);}
  RT=sim.s.t+acc;drawScene(ts);frames++;updateLabels();
  if(frames%6===0)updateHud();
  if(ts-lastSave>2000)saveGame();
  requestAnimationFrame(frame);}
document.addEventListener("visibilitychange",function(){if(document.hidden){paused=true;saveGame();}else{paused=false;last=0;}});
window.addEventListener("pagehide",saveGame);window.addEventListener("beforeunload",saveGame);window.addEventListener("unload",saveGame);
window.addEventListener("resize",function(){layout();drawScene(performance.now());});
/* what is on screen, for the HANDOFF object table and the tests */
var OBJECTS=[
  {id:"ship",name:"SHIP IN chute",use:"He drops each peeled potato here: +2c (+1c sloppy). It is sucked in and joins the batch.",gameplay:true},
  {id:"return",name:"RETURN chute",use:"A full batch (or an empty pile) spills back out of its mouth onto the pile, raw again.",gameplay:true},
  {id:"table",name:"PEEL TABLE",use:"Where he stands to peel (never walked over: he goes around it).",gameplay:true},
  {id:"bed",name:"BED",use:"NAP WHEN ENERGY < sends him here; SOFT BED upgrade speeds naps.",gameplay:true},
  {id:"cooler",name:"FOOD cooler",use:"Holds the food cans (HUD FOOD count, BIGGER COOLER upgrade); EAT WHEN HUNGER < sends him here.",gameplay:true},
  {id:"stool",name:"SEAT (stool)",use:"The spot he stands on to eat. Position only: it has no effect of its own.",gameplay:false},
  {id:"pile",name:"POTATOES pile",use:"The raw potatoes (POTATOES IN PLAY, shop potatoes). He grabs from its top edge.",gameplay:true},
  {id:"peels",name:"Peels on the floor",use:"Mess: slows him up to 30%; CLEAN WHEN PEELS > and STIFF BROOM deal with it.",gameplay:true},
  {id:"light",name:"Soft light pool under the table",use:"Lighting only. No gameplay.",gameplay:false}];
coinIcon();layout();renderAll();updateHud();migUntil=performance.now()+9000;RT=sim.s.t;showLabels(30000);drawScene(performance.now());
requestAnimationFrame(frame);
/* test + debug hooks */
window.PP={get sim(){return sim;},Sim:PPSim,save:saveGame,key:SAVE_KEY,reset:function(seed){sim=PPSim.fresh(seed);focusId=null;hud={};boxSnap="";flights=[];flying={};messVer++;sucks=[];renderAll();updateHud();saveGame();},
  reload:function(){sim=loadGame();hud={};flights=[];flying={};messVer++;renderAll();updateHud();},focus:function(){return focusId;},
  pause:function(p){paused=!!p;},layout:function(){return {W:W,H:H,k:k,roomW:roomW,roomH:roomH,offX:offX,offY:offY,detail:DETAIL,fitW:RW*k,fitH:RH*k};},version:"0.3",
  setPileMax:function(n){PILEMAX=n;buildPile();pileLayer=null;pileKey=-1;},forcePile:function(n){sim.s.pile=n;},get migrated(){return migrated;},
  stats:function(){return {pileRenders:renders.pile,messRenders:renders.mess,maxVis:MAXVIS,tiers:TIER.slice(),messVis:MESSPOS.length,flights:flights.length,sucks:sucks.length};},
  objects:function(){return OBJECTS;},labels:function(ms,force){showLabels(ms||8000,force);},ovl:function(){return ovlMode;},book:function(){return {page:bookPage,pages:bookPages()};},flip:flipBook,open:openOvl,close:closeOvl,buy:shopBuy,
  retView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);o.push(q?{j:j,x:q.x,y:q.y,z:q.z,p:q.p,inPipe:q.inPipe,mouthX:q.mouthX,tx:q.tx,ty:q.ty}:{j:j,p:-1});}return o;},spillView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++)o.push({j:j,ex:sc.ex[j],ld:sc.ld[j],rt:RT});return o;},
  posOf:function(i){return POS[i];},messPos:function(i){return MESSPOS[i];},tagRects:function(){var o={};for(var i=0;i<TAGDEF.length;i++){var r=$(TAGDEF[i].id).getBoundingClientRect();o[TAGDEF[i].id]={x:r.left,y:r.top,w:r.width,h:r.height,on:$(TAGDEF[i].id).className.indexOf("off")<0};}return o;},
  flightsNow:function(){return flights.map(function(f){return {slot:f.slot,t:f.t,dur:f.dur,x0:f.x0,y0:f.y0,tx:f.tx,ty:f.ty,h:f.h};});},cv:function(){return cv;}};
window.__PP_READY=true;
})();
