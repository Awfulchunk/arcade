/* ===== Papa Potato 0.3 — simulation (no DOM; runs headless for tests) ===== */
var PPSim=(function(){
  var RW=100,RH=240;                    /* canonical room, units. x,y in the save are fractions of this */
  var PACE=["CHILL","EASY","STEADY","BRISK","GRIND"];
  var SPD=[0.6,0.8,1.0,1.25,1.5];      /* work + walk speed */
  var DRN=[0.55,0.75,1.0,1.45,2.0];    /* hunger + energy drain */
  var STYLE=[{n:"NEAT",sp:0.8,peels:2},{n:"NORMAL",sp:1.0,peels:3},{n:"QUICK",sp:1.3,peels:5}];
  var C={
    walk:34,            /* room units / s (0.2: 18 in a 150-tall room; 0.3's room is taller so he walks faster) */
    grab:0.7, peel:6.0, drop:0.5, eat:3.0,
    meal:55, foodPrice:8, foodMax:9,
    hungerDrain:0.30, hungerDrainNap:0.10,
    energyDrain:0.42,
    napRegen:6.0, lazyNapRegen:4.0, napWake:98,
    value:2, sloppyValue:1,
    lazyLow:25, lazySpeed:0.5,
    startCoins:0, startFood:1,
    chuteCap:6, tPipe:1.6,              /* a full chute's batch spends tPipe in the pipe, then spills out of the return chute */
    peelPer:3, peelPerSloppy:5, peelMax:200, messFull:90, messMax:0.30,
    sweepRate:6, sweepWind:0.8, sweepTidy:0.10,
    priceGrow:1.05, priceCap:14, priceEvery:900,
    potBase:6, potLegacy:9, potPrice0:15, potPriceGrow:1.4
  };
  var POTS=[4,8,12,16,24,32,48,64,96,128,160,200,250,300,400,500,650,800];
  var POT_MAX=POTS.length-1;
  /* ---- room geometry (units; room = 100 wide x 240 tall). The renderer draws from these; the router avoids OBST. ---- */
  var GEO={WALL:7,INFL:7,
    ship:{x:50,lip:22,top:2,mouth:18},                 /* shipping chute hangs from the top wall */
    table:{x0:33,y0:74,x1:67,y1:92},
    cooler:{x0:71,y0:49,x1:85,y1:59},
    stool:{x:78,y:70},
    mat:{x:22,y:150,w:20,h:10},
    pile:{cx:50,base:218,rx:41,rz:14},
    ret:{wallX:93,mouthX:77,y:198,w:9},               /* return chute: pipe out of the right wall, mouth opens onto the pile */
    mess:{cx:50,cy:111,rx:26,rz:15}};
  var OBST=[{id:"table",x0:GEO.table.x0,y0:GEO.table.y0,x1:GEO.table.x1,y1:GEO.table.y1},{id:"cooler",x0:GEO.cooler.x0,y0:GEO.cooler.y0,x1:GEO.cooler.x1,y1:GEO.cooler.y1}];
  var SPOT={
    ship:{x:50,y:30,dir:0},
    table:{x:50,y:99,dir:0},
    food:{x:78,y:70,dir:0},
    mat:{x:22,y:150,dir:1},
    sweep:{x:50,y:108,dir:2},
    pile:{y:193,x0:24,x1:74}};
  /* ---- the command table: ONE source for the panel, the sim's BOX limits and the HELP screen ---- */
  var COMMANDS=[
    {id:"pace",does:"How fast he walks and works.",affects:"Speed x0.6 up to x1.5. Faster drains hunger and energy faster (x0.55 up to x2.0).",hi:"GRIND",lo:"CHILL",name:"WORK PACE",min:0,max:4,step:1,def:2,
      what:"How fast he walks and works.",
      effect:"Faster pace = more potatoes per minute, but hunger and energy drain faster. CHILL x0.6 speed (0.55 drain) up to GRIND x1.5 speed (2.0 drain).",
      range:"5 steps: CHILL, EASY, STEADY, BRISK, GRIND"},
    {id:"eat",does:"Sends him to eat when he gets hungry.",affects:"Hunger under the number = go eat (1 food = +55 hunger). OFF = never.",hi:"70%",lo:"OFF",name:"EAT WHEN HUNGER <",min:0,max:70,step:5,def:0,
      what:"Sends him to the cooler to eat when his hunger drops below the number.",
      effect:"Higher = he eats sooner and never gets hungry. Eating takes 3 s and uses 1 food (+55 hunger). OFF = he never eats on his own and goes lazy at 25%.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"nap",does:"Sends him to bed when he gets tired.",affects:"Energy under the number = go nap. OFF = he dozes on the floor instead.",hi:"70%",lo:"OFF",name:"NAP WHEN ENERGY <",min:0,max:70,step:5,def:0,
      what:"Sends him to the bed to nap when his energy drops below the number.",
      effect:"Higher = he naps sooner. OFF = he never goes to bed and dozes on the floor when he gets too tired. Pair it with NAP UNTIL.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"clean",does:"Sends him to sweep up peels.",affects:"Peels over the number = sweep. Lower = tidier floor but more sweeping.",hi:"90",lo:"OFF",name:"CLEAN WHEN PEELS >",min:0,max:90,step:5,def:0,
      what:"Sends him to sweep when the peel count on the floor goes over the number.",
      effect:"Lower = he sweeps earlier and keeps the floor clean, but spends more time sweeping. He sweeps until the floor is nearly clear (under 10% of the trigger). OFF = never. Peels slow him up to 30% at 90 peels.",
      range:"OFF, 5 to 90 peels (step 5)"},
    {id:"pot",does:"How many potatoes are in the loop.",affects:"More = bigger pile, no waiting. The top of the slider is what you own (buy more in the SHOP).",hi:"OWNED",lo:"4",name:"POTATOES IN PLAY",min:0,max:POT_MAX,step:1,def:6,dyn:"potCap",
      what:"How many potatoes are in the loop (pile + hands + chute + pipe).",
      effect:"More potatoes = a bigger pile and he never waits for the pipe. Fewer = a small pile. The top of the slider is what you own: buy more in the SHOP.",
      range:"4 up to the amount you own (4, 8, 12 ... 800)"},
    {id:"style",does:"How carefully he peels.",affects:"NEAT: slow, 2 peels. NORMAL: 3 peels. QUICK: fast, 5 peels (messy).",hi:"QUICK",lo:"NEAT",name:"PEEL STYLE",min:0,max:2,step:1,def:1,
      what:"How carefully he peels.",
      effect:"NEAT x0.8 speed, 2 peels per potato (clean floor). NORMAL x1.0, 3 peels. QUICK x1.3 speed, 5 peels per potato (fast but very messy).",
      range:"3 steps: NEAT, NORMAL, QUICK"},
    {id:"wake",does:"How rested he is when he gets up.",affects:"Lower = short naps, back to work sooner. 100% = fully rested. Needs NAP WHEN.",hi:"100%",lo:"50%",name:"NAP UNTIL ENERGY >",min:50,max:100,step:10,def:100,
      what:"How rested he is before he gets up from a nap.",
      effect:"Lower = short naps, back to work sooner (but he tires again sooner). 100% = sleeps until fully rested. Only matters if NAP WHEN is set.",
      range:"50% to 100% (step 10)"},
    {id:"autob",does:"Buys food for you.",affects:"Keeps at least this many cans stocked while you have the coins. OFF = buy in the SHOP.",hi:"9",lo:"OFF",name:"KEEP FOOD AT LEAST",min:0,max:9,step:1,def:0,
      what:"Automatically buys food (at the shop price) whenever you have fewer cans than the number and enough coins.",
      effect:"Higher = he never runs out, but it spends your coins as soon as they come in. OFF = you buy food yourself in the SHOP. Cannot go over the cooler size.",
      range:"OFF, 1 to 9 food (step 1)"}
  ];
  var BOX={};for(var ci=0;ci<COMMANDS.length;ci++){var cm=COMMANDS[ci];BOX[cm.id]={min:cm.min,max:cm.max,step:cm.step,def:cm.def};}
  /* ---- the shop ---- */
  var UPS=[
    {id:"peeler",name:"SHARP PEELER",max:3,prices:[40,110,260],fx:"Peeling takes 15% less time per level."},
    {id:"boots",name:"GOOD BOOTS",max:3,prices:[30,90,220],fx:"Walks 10% faster per level."},
    {id:"chute",name:"BIGGER CHUTE",max:3,prices:[35,100,240],fx:"Drops go in 30% quicker and each batch holds 2 more potatoes per level."},
    {id:"pantry",name:"BIGGER COOLER",max:2,prices:[25,80],fx:"The cooler holds 3 more food per level (9, then 12, then 15)."},
    {id:"broom",name:"STIFF BROOM",max:3,prices:[30,90,200],fx:"Sweeps 50% faster per level."},
    {id:"mat",name:"SOFT BED",max:2,prices:[30,90],fx:"Naps restore energy 35% faster per level."}
  ];
  var UPI={};for(var ui=0;ui<UPS.length;ui++)UPI[UPS[ui].id]=UPS[ui];
  function upsFresh(){var o={};for(var i=0;i<UPS.length;i++)o[UPS[i].id]=0;return o;}
  function hash(a,b){var x=Math.imul((Math.round(a*1000)|0)^0x9e3779b9,0x85ebca6b)^Math.imul((b|0)+1,0xc2b2ae35);x^=x>>>13;x=Math.imul(x,0x27d4eb2f);x^=x>>>15;x=Math.imul(x,0x165667b1);x^=x>>>16;return (x>>>0)/4294967296;}
  /* the spill schedule of one batch: when potato j leaves the return chute (ex) and when it comes to rest on the pile (ld). Pure function of (t0,n): sim and renderer share it. */
  function spill(t0,n){var ex=[],ld=[],t=t0+C.tPipe,pl=0;
    for(var j=0;j<n;j++){t+=(j===0?hash(t0,900)*0.25:0.10+hash(t0,j*7+1)*0.55);ex.push(t);
      var l=t+0.75+hash(t0,j*7+3)*0.6;if(l<pl+0.05)l=pl+0.05;ld.push(l);pl=l;}
    return {ex:ex,ld:ld};}
  /* ---- routing: shortest path round the inflated obstacles (visibility graph) ---- */
  function inflated(){var r=[],I=GEO.INFL;for(var i=0;i<OBST.length;i++){var o=OBST[i];r.push({x0:o.x0-I,y0:o.y0-I,x1:o.x1+I,y1:o.y1+I});}return r;}
  var INF=inflated(),EPS=0.01;
  function inside(b,x,y){return x>b.x0+EPS&&x<b.x1-EPS&&y>b.y0+EPS&&y<b.y1-EPS;}
  function segHits(b,ax,ay,bx,by){var t0=0,t1=1,dx=bx-ax,dy=by-ay,p=[-dx,dx,-dy,dy],q=[ax-(b.x0+EPS),(b.x1-EPS)-ax,ay-(b.y0+EPS),(b.y1-EPS)-ay];
    for(var i=0;i<4;i++){if(p[i]===0){if(q[i]<=0)return false;}else{var r=q[i]/p[i];if(p[i]<0){if(r>t1)return false;if(r>t0)t0=r;}else{if(r<t0)return false;if(r<t1)t1=r;}}}
    return t1-t0>1e-9;}
  function clearSeg(ax,ay,bx,by){for(var i=0;i<INF.length;i++)if(segHits(INF[i],ax,ay,bx,by))return false;return true;}
  function route(sx,sy,tx,ty){
    var pre=[];
    for(var i=0;i<INF.length;i++){var b=INF[i];if(inside(b,sx,sy)){ /* started inside an obstacle's margin: step out by the shortest way */
        var dl=sx-b.x0,dr=b.x1-sx,dt=sy-b.y0,db=b.y1-sy,m=Math.min(dl,dr,dt,db);
        if(m===dl)sx=b.x0;else if(m===dr)sx=b.x1;else if(m===dt)sy=b.y0;else sy=b.y1;pre.push([sx,sy]);}}
    if(clearSeg(sx,sy,tx,ty))return pre.concat([[tx,ty]]);
    var N=[[sx,sy],[tx,ty]],lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3;
    for(var k=0;k<INF.length;k++){var c=INF[k],cs=[[c.x0,c.y0],[c.x1,c.y0],[c.x0,c.y1],[c.x1,c.y1]];
      for(var q=0;q<4;q++){var p=cs[q];if(p[0]<lo||p[0]>hx||p[1]<lo||p[1]>hy)continue;var bad=false;for(var m2=0;m2<INF.length;m2++)if(inside(INF[m2],p[0],p[1])){bad=true;break;}if(!bad)N.push(p);}}
    var n=N.length,D=[],P=[],U=[],i2,j2;for(i2=0;i2<n;i2++){D.push(i2===0?0:1e9);P.push(-1);U.push(false);}
    for(var it=0;it<n;it++){var u=-1;for(i2=0;i2<n;i2++)if(!U[i2]&&(u<0||D[i2]<D[u]))u=i2;if(u<0||D[u]>=1e9)break;U[u]=true;if(u===1)break;
      for(j2=0;j2<n;j2++){if(U[j2])continue;if(!clearSeg(N[u][0],N[u][1],N[j2][0],N[j2][1]))continue;
        var d=D[u]+Math.sqrt((N[u][0]-N[j2][0])*(N[u][0]-N[j2][0])+(N[u][1]-N[j2][1])*(N[u][1]-N[j2][1]));if(d<D[j2]){D[j2]=d;P[j2]=u;}}}
    if(P[1]<0)return pre.concat([[tx,ty]]);
    var path=[],cur=1;while(cur>0){path.unshift(N[cur]);cur=P[cur];}
    return pre.concat(path);}
  function fresh(seed){
    seed=(seed>>>0)||((Math.random()*4294967295)>>>0);
    var b={};for(var id in BOX)b[id]=BOX[id].def;
    return {v:3,seed:seed,rs:0,rr:seed|0,t:0,
      coins:C.startCoins,food:C.startFood,hunger:100,energy:100,
      box:b,potCap:C.potBase,up:upsFresh(),
      pile:POTS[BOX.pot.def],chute:0,suck:null,peels:0,
      stats:{peeled:0,earned:0,meals:0,naps:0,lazyNaps:0,bought:0,spent:0,lazyTime:0,eatTime:0,napTime:0,firstBuyT:-1,
        sucks:0,swept:0,sweeps:0,peelsMade:0,maxPeels:0,cleanTime:0,waitTime:0,boughtPot:0,boughtUp:0,autoBuys:0},
      g:{x:0.5,y:0.20,dir:2,hold:null,job:"pile",peel:0,pgot:0,sloppy:false,lazy:false,act:null,walkPh:0},
      ev:[]};
  }
  function Sim(st){
    this.s=st||fresh();if(typeof this.s.rr!=="number")this.s.rr=this.s.seed|0;
    if(!this.s.g.act)this.decide();
  }
  var P=Sim.prototype;
  P.rand=function(){var a=this.s.rr=(this.s.rr+0x6D2B79F5)|0;this.s.rs=(this.s.rs|0)+1;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  P.emit=function(e){if(this.s.ev.length<64)this.s.ev.push(e);};
  P.up=function(id){return Math.max(0,Math.min(UPI[id].max,this.s.up[id]|0));};
  P.spd=function(){var g=this.s.g;return g.lazy?C.lazySpeed:SPD[this.s.box.pace];};
  P.messF=function(){return 1-C.messMax*Math.min(1,this.s.peels/C.messFull);};
  P.wspd=function(){return this.spd()*this.messF();};
  P.price=function(){var b=this.s.stats.bought;return Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery));};
  P.foodMax=function(){return C.foodMax+3*this.up("pantry");};
  P.chuteCap=function(){return C.chuteCap+2*this.up("chute");};
  P.peelTime=function(){return C.peel*Math.pow(0.85,this.up("peeler"))/STYLE[this.s.box.style].sp;};
  P.dropTime=function(){return C.drop*Math.pow(0.7,this.up("chute"));};
  P.walkMul=function(){return 1+0.10*this.up("boots");};
  P.sweepRate=function(){return C.sweepRate*(1+0.5*this.up("broom"));};
  P.napRegen=function(){return C.napRegen*(1+0.35*this.up("mat"));};
  P.potMax=function(){return Math.max(0,Math.min(POT_MAX,this.s.potCap));};
  P.target=function(){return POTS[this.s.box.pot];};
  P.total=function(){var s=this.s,k=s.suck;return s.pile+(s.g.hold?1:0)+s.chute+(k?k.n-k.landed:0);};
  /* a full chute (or an empty pile) sends the batch up the pipe; it spills out of the return chute onto the pile */
  P.startSuck=function(){var s=this.s;if(s.suck||s.chute<=0)return false;s.suck={t0:s.t,n:s.chute,landed:0};s.chute=0;s.stats.sucks++;this.emit({k:"suck"});return true;};
  P.retarget=function(){var s=this.s,d=this.target()-this.total();if(d>0){s.pile+=d;return;}
    var r=-d,t=Math.min(r,s.pile);s.pile-=t;r-=t;
    if(r>0){t=Math.min(r,s.chute);s.chute-=t;r-=t;}
    if(r>0&&s.suck){var k=s.suck;t=Math.min(r,k.n-k.landed);k.n-=t;r-=t;if(k.n<=k.landed)s.suck=null;}};
  P.drn=function(){var g=this.s.g;return g.lazy?DRN[0]:DRN[this.s.box.pace];};
  P.needState=function(){
    var s=this.s,b=s.box;
    var eatThr=b.eat>0?b.eat:0,napThr=b.nap>0?b.nap:0;
    var wantEat=eatThr>0&&s.hunger<eatThr&&s.food>0;
    var wantNap=napThr>0&&s.energy<napThr;
    var hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<C.lazyLow);
    var energyUnmet=napThr>0?false:(s.energy<C.lazyLow);
    var lazy=(hungerUnmet||energyUnmet);
    return {wantEat:wantEat,wantNap:wantNap,lazy:lazy,hungerUnmet:hungerUnmet,energyUnmet:energyUnmet,
      wantClean:b.clean>0&&s.peels>b.clean&&!lazy&&!s.g.hold};
  };
  P.walkTo=function(xu,yu,dir,then,label){var g=this.s.g,r=route(g.x*RW,g.y*RH,xu,yu),wp=[];for(var i=0;i<r.length-1;i++)wp.push([r[i][0]/RW,r[i][1]/RH]);
    g.act={t:"walk",x:xu/RW,y:yu/RH,dir:dir,then:then,label:label,wp:wp};};
  P.decide=function(){
    var s=this.s,g=s.g,n=this.needState();
    if(n.wantEat){g.lazy=false;this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the food");return;}
    if(n.wantNap){g.lazy=false;this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the bed");return;}
    g.lazy=n.lazy;
    if(n.wantClean){this.walkTo(SPOT.sweep.x,SPOT.sweep.y,SPOT.sweep.dir,"sweep","to sweep");return;}
    if(g.lazy){
      var r=this.rand();
      if(s.energy<15||(s.energy<70&&r<0.30)){g.act={t:"lazynap",until:Math.min(100,60+this.rand()*35),label:"dozing on the floor"};s.stats.lazyNaps++;this.emit({k:"lazynap"});return;}
      if(r>0.72){g.act={t:"idle",d:1.5+this.rand()*2.5,e:0,label:"slacking off"};return;}
    }
    if(g.job==="pile"){var px=SPOT.pile.x0+this.rand()*(SPOT.pile.x1-SPOT.pile.x0);this.walkTo(px,SPOT.pile.y,2,"grab","to the pile");}
    else if(g.job==="table"||g.job==="peel"){this.walkTo(SPOT.table.x,SPOT.table.y,SPOT.table.dir,"peel","to the table");}
    else this.walkTo(SPOT.ship.x,SPOT.ship.y,SPOT.ship.dir,"drop","to the chute");
  };
  P.startAt=function(kind){
    var g=this.s.g;
    if(kind==="grab")g.act={t:"grab",e:0,label:"grabbing a potato"};
    else if(kind==="peel"){g.job="peel";g.act={t:"peel",label:g.lazy?"peeling (sloppy)":"peeling"};}
    else if(kind==="drop")g.act={t:"drop",e:0,label:"shipping it"};
    else if(kind==="eat")g.act={t:"eat",e:0,label:"eating"};
    else if(kind==="sweep")g.act={t:"sweep",e:0,acc:0,label:"sweeping up the peels"};
    else if(kind==="nap"){g.act={t:"nap",label:"napping on the bed"};this.s.stats.naps++;this.emit({k:"nap"});}
  };
  P.peelEmit=function(n){var s=this.s;for(var i=0;i<n;i++){if(s.peels>=C.peelMax)break;s.peels++;s.stats.peelsMade++;if(s.peels>s.stats.maxPeels)s.stats.maxPeels=s.peels;this.emit({k:"peel",slot:s.peels-1});}};
  P.step=function(dt){
    var s=this.s,g=s.g,a=g.act,sp=this.spd(),dr=this.drn(),wsp=sp*this.messF();
    s.t+=dt;
    if(s.suck){var k=s.suck,sc=spill(k.t0,k.n);
      while(k.landed<k.n&&s.t>=sc.ld[k.landed]){s.pile++;k.landed++;this.emit({k:"land"});}
      if(k.landed>=k.n)s.suck=null;}
    if(!s.suck&&s.chute>=this.chuteCap())this.startSuck();
    if(s.box.autob>0&&s.food<s.box.autob&&s.food<this.foodMax()&&s.coins>=this.price()){this.buyFood(true);}
    if(a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep")))s.stats.cleanTime+=dt;
    var resting=a&&(a.t==="nap"||a.t==="lazynap"),eating=a&&a.t==="eat";
    if(resting){s.hunger-=C.hungerDrainNap*dt;}
    else if(!eating){s.hunger-=C.hungerDrain*dr*dt;s.energy-=C.energyDrain*dr*dt*(a&&a.t==="idle"?0.4:1);}
    if(s.hunger<0)s.hunger=0;if(s.energy<0)s.energy=0;
    if(g.lazy)s.stats.lazyTime+=dt;
    if(eating||(a&&a.t==="walk"&&a.then==="eat"))s.stats.eatTime+=dt;
    if(resting||(a&&a.t==="walk"&&a.then==="nap"))s.stats.napTime+=dt;
    if(!a){this.decide();return;}
    switch(a.t){
      case "walk":{
        var fin=!(a.wp&&a.wp.length),gt=fin?[a.x,a.y]:a.wp[0];
        var dx=(gt[0]-g.x)*RW,dy=(gt[1]-g.y)*RH,d=Math.sqrt(dx*dx+dy*dy),mv=C.walk*wsp*this.walkMul()*dt;
        g.walkPh+=mv*0.35;
        if(Math.abs(dx)>Math.abs(dy)*0.8)g.dir=dx>0?1:3;else g.dir=dy>0?2:0;
        if(d<=mv||d<0.01){g.x=gt[0];g.y=gt[1];if(fin){g.dir=a.dir;this.startAt(a.then);}else a.wp.shift();}
        else{g.x+=dx/d*mv/RW;g.y+=dy/d*mv/RH;}
        break;}
      case "grab":a.e+=dt*wsp;if(a.e>=C.grab){
          if(s.pile<=0){a.e=C.grab;a.label="waiting for potatoes";s.stats.waitTime+=dt;if(s.chute>0&&!s.suck)this.startSuck();break;}
          s.pile--;g.hold="raw";g.job="table";g.peel=0;g.pgot=0;g.sloppy=false;this.emit({k:"grab"});this.decide();}break;
      case "peel":{
        if(g.lazy)g.sloppy=true;
        var np=g.sloppy?C.peelPerSloppy:STYLE[s.box.style].peels;
        g.peel+=dt*wsp/this.peelTime();
        /* the skin comes off progressively: one peel pops off at each fraction of the potato */
        while(g.pgot<np&&g.peel>=(g.pgot+1)/(np+1)&&g.peel<1){g.pgot++;this.peelEmit(1);}
        if(g.peel>=1){g.peel=1;g.hold="peeled";g.job="chute";if(g.pgot<np)this.peelEmit(np-g.pgot);g.pgot=0;
          this.emit({k:"peeled"});this.decide();}
        break;}
      case "drop":a.e+=dt*wsp;if(a.e>=this.dropTime()){
          if(s.chute>=this.chuteCap()){a.e=this.dropTime();a.label="waiting for the chute";s.stats.waitTime+=dt;break;}
          var v=g.sloppy?C.sloppyValue:C.value;s.chute++;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;
          if(s.chute>=this.chuteCap())this.startSuck();
          g.hold=null;g.job="pile";g.peel=0;this.emit({k:"coin",v:v,sloppy:g.sloppy});g.sloppy=false;this.decide();}break;
      case "eat":a.e+=dt;if(a.e>=C.eat){
          if(s.food>0){s.food--;s.hunger=Math.min(100,s.hunger+C.meal);s.stats.meals++;this.emit({k:"ate"});}
          var n=this.needState();if(n.wantEat){a.e=0;}else this.decide();}break;
      case "nap":{s.energy=Math.min(100,s.energy+this.napRegen()*dt);var wk=s.box.wake>=100?C.napWake:s.box.wake;if(s.energy>=wk)this.decide();break;}
      case "lazynap":s.energy=Math.min(100,s.energy+C.lazyNapRegen*dt);if(s.energy>=a.until)this.decide();break;
      case "idle":a.e+=dt;if(a.e>=a.d)this.decide();break;
      case "sweep":{
        var nn=this.needState();
        if(s.box.clean<=0||nn.wantEat||nn.wantNap||nn.lazy){this.decide();break;}
        a.e+=dt*sp;
        if(a.e>C.sweepWind){a.acc+=dt*sp*this.sweepRate();var kk=Math.floor(a.acc);if(kk>0){a.acc-=kk;var rm=Math.min(kk,s.peels);s.peels-=rm;s.stats.swept+=rm;}}
        if(s.peels<=Math.floor(s.box.clean*C.sweepTidy)){if(s.peels>0){s.stats.swept+=s.peels;s.peels=0;}s.stats.sweeps++;this.emit({k:"swept"});this.decide();}
        break;}
    }
  };
  P.run=function(sec,h){h=h||0.1;var n=Math.round(sec/h);for(var i=0;i<n;i++)this.step(h);};
  P.poke=function(){var g=this.s.g,a=g.act,n=this.needState();
    if(a&&(a.t==="idle"||a.t==="lazynap"))this.decide();
    else if(a&&a.t==="walk"&&/grab|peel|drop|sweep/.test(a.then)&&(n.wantEat||n.wantNap))this.decide();
    else if(g.lazy&&!n.lazy){g.lazy=false;}};
  P.setBox=function(id,v){var b=BOX[id];if(!b)return false;v=Number(v);if(v!==v)return false;var mx=id==="pot"?this.potMax():b.max;
    v=Math.max(b.min,Math.min(mx,Math.round((v-b.min)/b.step)*b.step+b.min));if(this.s.box[id]===v)return false;this.s.box[id]=v;if(id==="pot")this.retarget();this.poke();return true;};
  P.buyFood=function(auto){var s=this.s,pr=this.price();if(s.food>=this.foodMax())return "full";if(s.coins<pr)return "poor";
    s.coins-=pr;s.food++;s.stats.bought++;s.stats.spent+=pr;if(auto)s.stats.autoBuys++;if(s.stats.firstBuyT<0)s.stats.firstBuyT=s.t;this.poke();return "ok";};
  P.potPrice=function(){var i=this.s.potCap+1;if(i>POT_MAX)return null;return Math.round(C.potPrice0*Math.pow(C.potPriceGrow,i-C.potBase));};
  /* buying potatoes raises the limit to the next stop and puts them in play right away */
  P.buyPotatoes=function(){var s=this.s,pr=this.potPrice();if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.potCap++;s.box.pot=s.potCap;s.stats.boughtPot++;s.stats.spent+=pr;this.retarget();this.poke();return "ok";};
  P.upPrice=function(id){var u=UPI[id],l=this.up(id);return l>=u.max?null:u.prices[l];};
  P.buyUp=function(id){var s=this.s;if(!UPI[id])return "bad";var pr=this.upPrice(id);if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.up[id]=this.up(id)+1;s.stats.boughtUp++;s.stats.spent+=pr;this.poke();return "ok";};
  P.stateName=function(){var g=this.s.g,a=g.act;if(g.lazy)return "AUTO-LAZY";if(!a)return "PEELING";
    if(a.t==="eat"||(a.t==="walk"&&a.then==="eat"))return "EATING";
    if(a.t==="nap"||(a.t==="walk"&&a.then==="nap"))return "NAPPING";
    if(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"))return "CLEANING";return "PEELING";};
  P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];return JSON.stringify(o);};
  /* accepts a 0.3 save (v:3), a 0.2 save (v:2) or a 0.1 save (v:1). Older saves are migrated in memory; the old keys are never written. */
  Sim.load=function(str){try{var o=JSON.parse(str);if(!o||(o.v!==1&&o.v!==2&&o.v!==3)||typeof o.coins!=="number"||!o.g||typeof o.g!=="object"||!o.box||typeof o.box!=="object")return null;
      var old=o.v<3,from1=o.v===1;o.v=3;
      var f=fresh(o.seed);for(var k in f)if(!(k in o))o[k]=f[k];
      if(!o.stats||typeof o.stats!=="object")o.stats={};for(var k2 in f.stats)if(typeof o.stats[k2]!=="number"||!isFinite(o.stats[k2]))o.stats[k2]=f.stats[k2];
      var oldPot=+o.box.pot;
      for(var id in BOX){var v=+o.box[id];if(!(v>=BOX[id].min&&v<=BOX[id].max))o.box[id]=BOX[id].def;else o.box[id]=Math.round((v-BOX[id].min)/BOX[id].step)*BOX[id].step+BOX[id].min;}
      if(old){o.potCap=Math.max(C.potLegacy,o.box.pot);o.up=upsFresh();}
      if(!o.up||typeof o.up!=="object")o.up=upsFresh();for(var ui2=0;ui2<UPS.length;ui2++){var uu=Math.floor(+o.up[UPS[ui2].id]);o.up[UPS[ui2].id]=(uu>=0&&uu<=UPS[ui2].max)?uu:0;}
      o.potCap=Math.floor(+o.potCap);if(!(o.potCap>=0&&o.potCap<=POT_MAX))o.potCap=C.potBase;if(o.box.pot>o.potCap)o.potCap=o.box.pot;
      o.hunger=Math.max(0,Math.min(100,+o.hunger||0));o.energy=Math.max(0,Math.min(100,+o.energy||0));
      o.coins=Math.max(0,Math.min(1e9,Math.floor(+o.coins||0)));
      var fmx=C.foodMax+3*o.up.pantry,cmx=C.chuteCap+2*o.up.chute;
      o.food=Math.max(0,Math.min(fmx,Math.floor(+o.food||0)));o.ev=[];
      o.t=Math.max(0,+o.t||0);if(!isFinite(o.t))o.t=0;
      o.peels=Math.max(0,Math.min(C.peelMax,Math.floor(+o.peels||0)));
      o.chute=Math.max(0,Math.min(cmx,Math.floor(+o.chute||0)));
      o.pile=Math.max(0,Math.floor(+o.pile||0));
      var kk=o.suck;if(kk&&typeof kk==="object"&&isFinite(+kk.t0)&&+kk.n>0&&+kk.n<=cmx&&+kk.landed>=0&&+kk.landed<=+kk.n){o.suck={t0:+kk.t0,n:Math.floor(+kk.n),landed:Math.floor(+kk.landed)};if(o.suck.t0>o.t)o.suck.t0=o.t;}else o.suck=null;
      var g=o.g;if(g.act&&typeof g.act!=="object")g.act=null;
      if(old)g.act=null;      /* geometry changed in 0.3: let him re-decide from where he stands */
      var ok={walk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1};if(g.act&&!ok[g.act.t])g.act=null;
      if(g.act&&g.act.t==="walk"&&!(isFinite(+g.act.x)&&isFinite(+g.act.y)))g.act=null;
      if(typeof g.x!=="number"||!(g.x>=0&&g.x<=1))g.x=0.5;if(typeof g.y!=="number"||!(g.y>=0&&g.y<=1))g.y=0.2;if(typeof g.dir!=="number"||!(g.dir>=0&&g.dir<=3))g.dir=2;
      if(old){g.x=Math.max(0.12,Math.min(0.88,g.x));g.y=Math.max(0.08,Math.min(0.92,g.y));}
      if(g.hold!==null&&g.hold!=="raw"&&g.hold!=="peeled")g.hold=null;
      var h=g.hold;g.job=h==="raw"?(g.job==="peel"?"peel":"table"):(h==="peeled"?"chute":"pile");
      if(g.act){var at=g.act,wt=at.t==="walk"?at.then:null;
        if((at.t==="peel"&&h!=="raw")||(at.t==="drop"&&h!=="peeled")||(at.t==="grab"&&h!==null)||(at.t==="sweep"&&h!==null)||
           (at.t==="walk"&&(["grab","peel","drop","eat","nap","sweep"].indexOf(wt)<0||(wt==="peel"&&h!=="raw")||(wt==="drop"&&h!=="peeled")||(wt==="grab"&&h!==null)||(wt==="sweep"&&h!==null))))g.act=null;}
      if(g.peel!==0&&!(g.peel>0&&g.peel<=1))g.peel=0;
      g.pgot=Math.max(0,Math.min(5,Math.floor(+g.pgot||0)));
      if(g.act&&g.act.t==="walk"){var rr=route(g.x*RW,g.y*RH,g.act.x*RW,g.act.y*RH),wp=[];for(var ri=0;ri<rr.length-1;ri++)wp.push([rr[ri][0]/RW,rr[ri][1]/RH]);g.act.wp=wp;}
      var sim=new Sim(o);
      var want=POTS[o.box.pot],have=sim.total();
      if(from1||have!==want){if(have>want){o.pile=Math.max(0,o.pile-(have-want));}else o.pile+=want-have;}
      return sim;}catch(e){return null;}};
  Sim.fresh=function(seed){return new Sim(fresh(seed));};
  Sim.C=C;Sim.POTS=POTS;Sim.BOX=BOX;Sim.PACE=PACE;Sim.SPOT=SPOT;Sim.SPD=SPD;Sim.DRN=DRN;Sim.GEO=GEO;Sim.OBST=OBST;Sim.RW=RW;Sim.RH=RH;
  Sim.COMMANDS=COMMANDS;Sim.UPS=UPS;Sim.STYLE=STYLE;Sim.spill=spill;Sim.route=route;Sim.INFL=function(){return INF;};
  return Sim;
})();
if(typeof module!=="undefined")module.exports=PPSim;
