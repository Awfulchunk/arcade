#!/bin/bash
# Build papa-potato-0.3.html from src/ (single file, no deps).
set -euo pipefail
cd "$(dirname "$0")"
{ cat src/head.html; echo "<script>"; cat src/sim.js; echo; cat src/game.js; echo "</script>"; echo "</body></html>"; } > out/papa-potato-0.3.html
node -e 'const fs=require("fs");const t=fs.readFileSync("out/papa-potato-0.3.html","utf8");const m=t.match(/<script>([\s\S]*)<\/script>/);new Function(m[1]);console.log("syntax ok",t.length,"bytes")'
