# Tough & J's Arcade 2.7.59 (versionCode 97) — source (GPL-3.0)

2.7.59 is cumulative over 2.7.58 (Papa Potato 0.2 stays playable as slot papa-potato:v02, 0.1 as papa-potato:v01):
- NEW: Papa Potato 0.3 (latest) — source/papa-potato/ (game src, frozen 0.1 + 0.2 html, assembler/verify/tests, WebView-83 emulator scripts, README).
- Unchanged from 2.7.58: Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms: source/latch-ui, latch-manual, latch-build, funmotion-0.2.5, swarm-1.6.14, needle-ui, engine, android-app, old-webview.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
