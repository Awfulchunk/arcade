# Pixel War 0.4.5 source (Tough & J's Arcade 2.7.68) — GPL-3.0
- game/pixel-war-0.4.5.html: the whole game is this one file (no build step). Full physics pass on 0.4.4: free forward wander in the hitbox (the drawn path is a direction guide, not a rail), hard lane edges, thin-lane packing, in-lane chip/knock when a hit does not ricochet, short random ricochet sprays, and a loose widening cone past the path end. Steady 200–400 on the field. Save keys `pixelwar.v45*` (prefs/forms/custom/AI memory fall back from v44/v43). Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.4.html: kept as `pixelwar:v044`; 0.4.3 as `v043`; 0.4.2 as `v042`; 0.4.1 as `v041`; 0.3 as `v03`.
- arcade-2.7.68/: assemble-2768.mjs and verify-2768.cjs (checks the signed APK against 2.7.67).
- tests/ were not re-run for 0.4.5. No signing keys and no Latch code are included.
