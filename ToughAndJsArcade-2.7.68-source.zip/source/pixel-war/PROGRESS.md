# PROGRESS 0.4.5 (copy of 0.4.4) 2026-11-15 16:52 PT (America/Los_Angeles)

2026-11-15 16:52 PT: Copied build-pixelwar044 -> build-pixelwar045. Jay t1149-t1151: full physics pass (lane flow, collisions, ricochet, path end), then ship 2.7.68 / code 106 with no tests. No cluster.

Audit of 0.4.4 against t1116-t1148 / MISSING A12-A17 / 043-044 notes. Keep: free forward wander, path as guide only, hard edges, steady 200-400 flow, interpolation, random short ricochet, no loop-back. Fixes:
- Collisions that do not ricochet still chip and knock (small in-lane push / slowdown). 0.4.4 only sprayed or passed through, so head-on streams lacked cause and effect.
- Thin hitboxes pack tighter by reducing wander (t1132 density-rises-when-thinned), with no pull to the center line.
- Lane edges settle slightly inside after a soft-reflect so streams do not hug the rim (A13).
- holdLane is skipped while a wall cooldown is active, so a defense-line bounce is not immediately pushed back into the wall.
- Path end is a loose widening cone (gentle outward drift, still mostly straight), then short-leash fade. No swirl or loop-back.
- flowRate lifetime uses the short end leash + fade, so the 200-400 on-field target stays honest after t1143.
