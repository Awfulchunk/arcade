// ---------------------------------------------------------------- 8) kit in the shop: 7/7/7, AMMO buy, AMMO RACK (replaces PITFALL)
const RK=AMMO13.rack;
BUILDS.push({id:RK.id,nm:RK.nm,cost:RK.cost});
{const i=TABS.DEFENSE.indexOf("PITFALL");if(i>=0)TABS.DEFENSE.splice(i+1,0,RK.nm);else TABS.DEFENSE.push(RK.nm);}
if(typeof RN!=="undefined")RN[RK.nm]=["AMMO RACK","Slowly refills reserve ammo for every owned gun during waves · up to "+RK.maxRacks+" racks, capped"];
const KEEP_B=new Set(["WALL","MINE","TAR PIT","E-FENCE",RK.nm,"FLAMEVENT","MEATGRINDER","RATE","AUX 35%","GEN","REPAIR","SHIELDGEN","CRYO GEN","SIDE GUN"]);
const ITEM_NAMES=new Set([...TABS.DEFENSE,...TABS.ABILITIES,...BUILDS.map(b=>b.nm)]);
window.__kit13={weapons:ORDER13.slice(),builds:[...KEEP_B],hiddenW:WEAPONS.filter(w=>w.hidden13).map(w=>w.id)};
function racks(){return slots.filter(s=>s.build===RK.id&&s.hp>0);}
function rackMul(){const n=racks().length;return n?Math.min(RK.capMul,1+RK.stack*(n-1)):0;}
{const _b=buildShop;buildShop=function(){_b();const shop=$("shop");if(!shop)return;let anyW=false;
  for(const c of shop.children){if(c.classList.contains("go"))continue;const n=c.querySelector(".nm");if(!n)continue;const raw=n.dataset.raw||n.textContent;
    const w=WEAPONS.find(q=>q.nm===raw);if(w){if(w.hidden13)c.style.display="none";else if(c.style.display!=="none")anyW=true;continue;}
    if(ITEM_NAMES.has(raw)&&!KEEP_B.has(raw))c.style.display="none";
    if(raw===RK.nm&&racks().length>=RK.maxRacks){const ct=c.querySelector(".ct");if(ct)ct.textContent="MAX "+RK.maxRacks;}}
  if(between&&anyW&&!placeMode&&tab==="WEAPONS"){const el=document.createElement("div");el.className="chip";el.id="ammo13Chip";
    el.innerHTML=`<canvas class="ic" width="32" height="28"></canvas><div class="nm">${AMMO13.shop.nm}</div><div class="ct">${AMMO13.shop.cost}¢</div>`;
    const g=el.querySelector("canvas").getContext("2d");g.fillStyle="#121828";g.fillRect(0,0,32,28);g.fillStyle="#5a4a20";g.fillRect(4,12,24,12);g.fillStyle="#8a7030";g.fillRect(4,12,24,3);
    for(let i=0;i<5;i++){g.fillStyle="#b08020";g.fillRect(7+i*4,5,3,8);g.fillStyle="#ffd860";g.fillRect(7+i*4,5,3,2);}
    el.onclick=()=>{if(credits<AMMO13.shop.cost)return toast("Need "+AMMO13.shop.cost);const own=ownedGuns().filter(id=>gunAmmo(id).max!==Infinity);if(!own.length)return toast("BASIC has infinite ammo");
      if(own.every(id=>am(id).res>=gunAmmo(id).max))return toast("Reserves full");credits-=AMMO13.shop.cost;
      for(const id of own){const a=am(id),g=gunAmmo(id);a.res=Math.min(g.max,a.res+g.max*AMMO13.shop.fill);}S13.ammoBuys=(S13.ammoBuys||0)+1;A13.play("reload",{g:.4});toast("AMMO +"+Math.round(AMMO13.shop.fill*100)+"% reserves");buildShop();hud();};
    const nx=shop.querySelector(".go");if(nx&&nx.nextSibling)shop.insertBefore(el,nx.nextSibling);else shop.appendChild(el);}
  if(!between)for(const c of shop.children){const n=c.querySelector(".nm");const w=n&&WEAPONS.find(q=>q.nm===(n.dataset.raw||n.textContent));if(w&&G13[w.id]&&!w.locked){c.dataset.gun=w.id;}}chipAmmo13();};}
function chipAmmo13(){if(between)return;const shop=$("shop");if(!shop)return;for(const c of shop.querySelectorAll(".chip[data-gun]")){const a=am(c.dataset.gun),ct=c.querySelector(".ct");const tx=a.rl>0?"RELOAD":a.mag+"/"+(a.res===Infinity?"∞":Math.floor(a.res));if(ct&&ct.textContent!==tx)ct.textContent=tx;}}
setInterval(()=>{if(running&&!dead)chipAmmo13();},400);
{const _tp=tryPlaceSlot;tryPlaceSlot=function(sx,sy){if(placeMode!==RK.id||!between)return _tp(sx,sy);
  if(racks().length>=RK.maxRacks){toast("Max "+RK.maxRacks+" racks");placeMode=null;buildShop();return true;}
  if(Math.hypot(sx,sy)<26||Math.hypot(sx,sy)>360){toast("Too close / off the field");return true;}
  for(const s of slots)if(s.build&&Math.hypot(s.x-sx,s.y-sy)<18){toast("Something is already there");return true;}
  if(credits<RK.cost){toast("Need "+RK.cost);return true;}credits-=RK.cost;
  slots.push({x:sx,y:sy,build:RK.id,hp:RK.hp,max:RK.hp,cost:RK.cost,tick:0});placeMode=null;toast("AMMO RACK placed · x"+rackMul().toFixed(1)+" refill");buildShop();hud();return true;};}
{const _bi=drawBuildIcon;drawBuildIcon=function(c,id){_bi(c,id);if(id!==RK.id||!c)return;const g=c.getContext("2d");g.fillStyle="#121828";g.fillRect(0,0,32,28);
  g.fillStyle="#2a3018";g.fillRect(5,9,22,15);g.fillStyle="#5a6a30";g.fillRect(6,10,20,13);g.fillStyle="#8a9a50";g.fillRect(6,10,20,2);
  for(let i=0;i<4;i++){g.fillStyle="#b08020";g.fillRect(8+i*5,4,3,8);g.fillStyle="#ffd860";g.fillRect(8+i*5,4,3,2);}g.fillStyle="#7f6";g.fillRect(22,18,3,3);};}
{const _de=drawExtra;drawExtra=function(){_de();for(const s of slots)if(s.build===RK.id)upright(s.x,s.y,()=>drawRack(s));};}
function drawRack(s){const R=pr,on=(s.tick||0)>0;ctx.save();ctx.translate(Math.round(s.x),Math.round(s.y));
  R(-13,6,26,4,"#0005");R(-12,-10,24,16,"#232832");R(-11,-9,22,14,"#4f5a2c");R(-11,-9,22,2,"#7d8c46");R(-11,0,22,1,"#2e3418");
  for(let i=0;i<5;i++){const x=-9+i*4;R(x,-16,3,8,"#7a5a18");R(x,-16,3,6,"#b08020");R(x,-16,3,2,"#ffd860");}
  R(7,1,3,3,on?"#9f6":"#3a5a30");R(-10,8,20,2,"#25232a");R(-10,8,20*clamp(s.hp/s.max,0,1),2,"#81ad78");ctx.restore();}
// ---------------------------------------------------------------- 9) update glue: slow-mo, hugger ring + separation, kills, rack, ammo, FX
function ring13(){const near=[];for(const e of enemies){const d=Math.hypot(e.x,e.y),R=13+e.r*.45-.6;
   if(d<R){if(d<.01){const a=(e.fa||0)+Math.PI;e.x=Math.cos(a)*R;e.y=Math.sin(a)*R;}else{e.x*=R/d;e.y*=R/d;}}if(d<R+24)near.push(e);}
 for(let i=0;i<near.length;i++)for(let j=i+1;j<near.length;j++){const a=near[i],b=near[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||.01,m=(a.r+b.r)*.62;
   if(d<m){const p=(m-d)/2,ux=dx/d,uy=dy/d;a.x-=ux*p;a.y-=uy*p;b.x+=ux*p;b.y+=uy*p;}}
 for(const e of near){const d=Math.hypot(e.x,e.y),R=13+e.r*.45-.6;if(d<R&&d>.01){e.x*=R/d;e.y*=R/d;}}
 S13.huggers=near.length;}
{const _u=update;update=function(dt){
  const real=dt;if(PANEL13)dt*=SLOWMO;S13.simDt=dt;S13.realDt=real;
  for(const e of enemies){e._px13=e.x;e._py13=e.y;}
  // rockets airburst at max range
  for(const b of bullets)if(b.rk13&&!b.boomed&&b.o&&Math.hypot(b.x-b.o[0],b.y-b.o[1])>=b.rng-8){b.boomed=1;b.life=0;blast13(b.x,b.y,W_("rocket"),G13.rocket,null,b.src);}
  _u(dt);if(dead||!running)return;
  if(dt>0){for(const e of enemies){if(e._px13!=null){e.vx13=(e.x-e._px13)/dt;e.vy13=(e.y-e._py13)/dt;}}}
  ring13();
  for(let i=enemies.length-1;i>=0;i--)if(enemies[i].hp<=0)killEnemy(enemies[i],i);
  tickAmmo(dt);
  if(!between&&running){const m=rackMul();S13.rackMul=m;if(m>0){for(const id of ownedGuns()){const g=gunAmmo(id),a=am(id);if(g.max===Infinity||!g.rack)continue;a.res=Math.min(g.max,a.res+g.rack*m*dt);}
    for(const s of racks()){for(const e of enemies)if(Math.hypot(e.x-s.x,e.y-s.y)<14)s.hp-=e.dmg*dt*.8;if(s.hp<=0){s.build=null;floaters.push({x:s.x,y:s.y,t:0,txt:"RACK LOST",col:"#f66"});continue;}s.tick=(s.tick||0)-dt;s.tk2=(s.tk2||0)+dt;if(s.tk2>1.6){s.tk2=0;s.tick=.25;p13({k:"plus",x:s.x,y:s.y*KY-20,max:.8});}}}}
  for(let i=P13.length-1;i>=0;i--){const f=P13[i];f.t+=dt;if(f.t>=f.max){P13.splice(i,1);continue;}
    if(f.k==="spk"||f.k==="shell"){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=(f.k==="shell"?260:120)*dt;}else if(f.k==="flm"){f.x+=f.vx*dt;f.y+=f.vy*dt;f.z=Math.max(4,f.z-dt*30);f.vx*=1-1.2*dt;f.vy*=1-1.2*dt;}
    else if(f.k==="smk"){f.y-=14*dt;f.r+=8*dt;}else if(f.k==="plus")f.y-=10*dt;}
  for(const b of bullets)if(b.rk13&&Math.random()<.7)p13({k:"smk",x:b.x,y:b.y*KY-z13(b),r:1.5,max:.45});
  A13.idle(real);};}
{const _k=killEnemy;killEnemy=function(e,i){if(e&&enemies[i]!==e){i=enemies.indexOf(e);if(i<0)return;}A13.kill(e);return _k(e,i);};}
{const _r=resetRun;resetRun=function(){const r=_r();resetAmmo();TAG13=null;AIS.panic=null;P13.length=0;SPIN13=0;openPanel(false);A13.stopAll();return r;};}
{const _sw=startWave;startWave=function(){const r=_sw();if(waveActive){for(const id of ownedGuns()){const a=am(id),g=gunAmmo(id);a.rl=0;const take=Math.min(g.mag-a.mag,a.res);a.mag+=take;if(a.res!==Infinity)a.res-=take;}}TAG13=null;AIS.panic=null;return r;};}
{const _ew=endWave;endWave=function(){AIS.panic=null;TAG13=null;return _ew.apply(this,arguments);};}
// keep the frame + sound in the same frame for timing tests
{const _d=draw;draw=function(){FRAME_T=performance.now();_d();drawHud13();A13.drawn(performance.now());};}
window.__drawHug13=function(){ // called inside the world transform right after the turret (base draw patch)
 for(const e of enemies){if(Math.hypot(e.x,e.y)<13+e.r*.45+12)upright(e.x,e.y,()=>drawType(e));}
 if(TAG13&&TAG13.e.hp>0){const e=TAG13.e,B=box13(e),k=depthK(e.y),top=B.top/k;upright(e.x,e.y,()=>{const p=(t*3)%1,y0=e.y+top-6-Math.sin(t*8)*1.5;
   ctx.fillStyle="#000";ctx.beginPath();ctx.moveTo(e.x-5,y0-6);ctx.lineTo(e.x+5,y0-6);ctx.lineTo(e.x,y0+1);ctx.fill();
   ctx.fillStyle=((t*4)|0)%2?"#ff5a3a":"#ffe066";ctx.beginPath();ctx.moveTo(e.x-4,y0-5.5);ctx.lineTo(e.x+4,y0-5.5);ctx.lineTo(e.x,y0);ctx.fill();
   ctx.strokeStyle="rgba(255,90,58,"+(.8-.6*p)+")";ctx.lineWidth=1.2;ctx.strokeRect(e.x-B.hw/k-2,e.y+top-2,B.hw/k*2+4,(B.bot-B.top)/k+4);});}
 ctx.save();ctx.scale(1,1/KY); // P13 lives in screen units
 for(const f of P13){const u=f.t/f.max,al=1-u;ctx.globalAlpha=Math.max(0,al);
  if(f.k==="beam"){ctx.strokeStyle=f.c;ctx.lineWidth=f.wd*1.8;ctx.globalAlpha=al*.35;ctx.beginPath();ctx.moveTo(f.x,f.y);ctx.lineTo(f.x2,f.y2);ctx.stroke();ctx.globalAlpha=al;ctx.lineWidth=f.wd*.6;ctx.strokeStyle="#fff";ctx.stroke();}
  else if(f.k==="trc"){ctx.strokeStyle=f.c;ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(f.x,f.y);ctx.lineTo(f.x2,f.y2);ctx.stroke();}
  else if(f.k==="spk"){ctx.fillStyle=f.c;ctx.fillRect(f.x-.8,f.y-.8,1.6,1.6);}
  else if(f.k==="shell"){ctx.fillStyle=f.c;ctx.fillRect(f.x-1,f.y-.6,2,1.2);}
  else if(f.k==="mf"){ctx.save();ctx.translate(f.x,f.y);ctx.rotate(f.a);ctx.fillStyle=f.c;ctx.fillRect(0,-f.r*.35,f.r*1.6,f.r*.7);ctx.fillStyle="#fff6db";ctx.fillRect(0,-f.r*.18,f.r,f.r*.36);ctx.restore();}
  else if(f.k==="cone"){ctx.globalAlpha=al*.45;ctx.fillStyle=f.c;ctx.beginPath();ctx.moveTo(f.x,f.y);ctx.arc(f.x,f.y,f.r,f.a-f.sp,f.a+f.sp);ctx.closePath();ctx.fill();}
  else if(f.k==="flm"){const r=f.r*(1+u*3);ctx.globalAlpha=Math.min(1,al*1.3)*.85;ctx.fillStyle=u<.25?"#ffe060":u<.6?"#ffb030":u<.85?"#ff6a10":"#6a3020";ctx.beginPath();ctx.arc(f.x,f.y*KY-f.z,r,0,6.28);ctx.fill();}
  else if(f.k==="smk"){ctx.globalAlpha=al*.35;ctx.fillStyle="#9a9aa0";ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,6.28);ctx.fill();}
  else if(f.k==="boom"){ctx.globalAlpha=al*.8;ctx.fillStyle=u<.3?"#fff0b0":"#ff8a30";ctx.beginPath();ctx.arc(f.x,f.y,f.r*(.5+u*.7),0,6.28);ctx.fill();}
  else if(f.k==="plus"){ctx.globalAlpha=al*.7;ctx.fillStyle="#bfe86a";ctx.fillRect(f.x-1.5,f.y-.5,3,1);ctx.fillRect(f.x-.5,f.y-1.5,1,3);}}
 ctx.globalAlpha=1;ctx.restore();};
function drawHud13(){if(!running||!$("overlay").classList.contains("off"))return;const w=curW();if(!G13[w.id])return;const a=am(w.id),g=gunAmmo(w.id);
 const x=CX,y=TY+16*VS*depthK(0);ctx.save();ctx.setTransform(DPR||1,0,0,DPR||1,0,0);
 const txt=w.nm+" "+a.mag+"/"+(a.res===Infinity?"∞":Math.floor(a.res));ctx.font="bold 10px monospace";ctx.textAlign="center";const tw=ctx.measureText(txt).width+8;
 ctx.fillStyle="#000a";ctx.fillRect(x-tw/2,y,tw,13);const low=a.mag<=Math.ceil(g.mag*.2);ctx.fillStyle=a.rl>0?"#9fd8ff":low?"#ff7a5a":"#ffe066";ctx.fillText(txt,x,y+10);
 ctx.fillStyle="#222";ctx.fillRect(x-tw/2,y+13,tw,2);ctx.fillStyle=a.rl>0?"#9fd8ff":"#ffe066";ctx.fillRect(x-tw/2,y+13,tw*(a.rl>0?1-a.rl/(a.rlT||1):a.mag/g.mag),2);
 if(a.rl>0){const p=1-a.rl/(a.rlT||1),ty=TY-14*VS;ctx.strokeStyle="#9fd8ff";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,ty,18,-Math.PI/2,-Math.PI/2+p*6.283);ctx.stroke();ctx.fillStyle="#9fd8ff";ctx.fillText("RELOAD",x,ty-22);}
 if(AIS.panic&&mainAuto()){ctx.fillStyle="#ff5a3a";ctx.fillText("PANIC · "+w.nm,x,y+26);}
 ctx.restore();}
/*__T13__*/
