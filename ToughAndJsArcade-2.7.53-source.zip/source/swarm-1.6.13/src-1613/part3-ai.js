// ---------------------------------------------------------------- 5) Turret AI rules (panel boxes) + ammo-aware firing
const DEF13={switch:4,range:90,prio:1,style:4,panic:60,order:0,tag:40,reload:4};
const PRESET13={safe:{switch:3,range:100,prio:0,style:2,panic:100,order:0,tag:50,reload:1},
               bal:{switch:4,range:90,prio:1,style:4,panic:60,order:0,tag:40,reload:4},
               aggro:{switch:6,range:110,prio:4,style:8,panic:30,order:0,tag:25,reload:8}};
let CFG=Object.assign({},DEF13);try{const s=JSON.parse(localStorage.getItem("swarm.ai13")||"null");if(s)for(const k in DEF13)if(typeof s[k]==="number")CFG[k]=s[k];}catch(e){}
function saveCfg(){try{localStorage.setItem("swarm.ai13",JSON.stringify(CFG));}catch(e){}}
const LEAD=.7,TURN=6.5; // automatic defaults (Jay t993: no boxes)
const STR13=["rocket","sniper","shotgun","laser","minigun","fire","basic"]; // STRONG -> WEAK
const PRIO_NAMES=["CORE-HUGGERS","NEAREST","FASTEST","WEAKEST","STRONGEST"];
const AIS={swT:0,panic:null,burstN:0,pause:0,lastShot:-9};
let TAG13=null;
function curW(){return WEAPONS[activeW];}
function setGun(id,why){const i=WEAPONS.findIndex(w=>w.id===id&&!w.locked);if(i<0||i===activeW)return false;const old=WEAPONS[activeW];activeW=i;AIS.burstN=0;
 if(old&&G13[old.id]&&am(old.id).mag<=0)startReload(old.id);
 S13.log.push({t:+t.toFixed(2),gun:id,why});if(S13.log.length>300)S13.log.shift();try{buildShop();}catch(e){}return true;}
function rngOf(w){return (G13[w.id]?G13[w.id].rng:w.rng||270)*CFG.range/100;}
function pick13(list,m){let best=null,bv=Infinity;for(const e of list){const d=Math.hypot(e.x,e.y),sp=(e.slowT>0?.5:1)*(e.sp||1);
  let da=Math.abs(Math.atan2(e.y,e.x)-aim);if(da>Math.PI)da=6.283-da; // turret economy: among near-equal picks prefer the one the barrel already faces
  const v=m===0?d/Math.max(4,sp)+da*.5:m===1?d+da*30:m===2?-sp:m===3?e.hp:-e.hp;if(v+d*1e-6<bv){bv=v+d*1e-6;best=e;}}return best;}
function shootRate(w){let r=Math.max(.035,w.rate*(1-fireRateBonus*.08)*(1-lvl(w)*.06));if(w.id==="minigun")r*=2.5-1.5*SPIN13;return r;}
function tryShoot13(){const w=curW();if(!G13[w.id]){fireCd=shootRate(w);shootFrom(Math.cos(aim)*14,Math.sin(aim)*14,aim,w,"main");return true;}
 const a=am(w.id);if(a.rl>0||fireCd>0)return false;
 if(a.mag<=0){if(!startReload(w.id)){if(!hasAmmo(w.id))dryOut(w.id);}return false;}
 a.mag--;fireCd=shootRate(w)*STYLE13.rate;AIS.lastShot=t;shootFrom(Math.cos(aim)*14,Math.sin(aim)*14,aim,w,"main");return true;}
function dryOut(id){ // never soft-locks: a fully dry gun hands over to a gun with ammo (BASIC is infinite)
 const alt=bestGun(true)||"basic";if(alt!==id){setGun(alt,"dry");toast(W_(id).nm+" dry → "+W_(alt).nm);}}
function situation(){const s={n:0,dN:1e9,big:0,packN:0,nearN:0,inR:{}};let nn=null;
 for(const id of ownedGuns())s.inR[id]=0;
 for(const e of enemies){if(e.hp<=0)continue;const d=Math.hypot(e.x,e.y);s.n++;if(d<s.dN){s.dN=d;nn=e;}if(d<120)s.nearN++;
   for(const id in s.inR){const R=G13[id].rng*CFG.range/100;if(d<=R){s.inR[id]++;if(id==="sniper"&&e.hp>s.big)s.big=e.hp;}}}
 if(nn)for(const e of enemies)if(Math.hypot(e.x-nn.x,e.y-nn.y)<60)s.packN++;return s;}
// score = how well each gun fits what is in ITS range right now (crowd -> minigun/laser/fire, packs -> rocket, tanks -> sniper, close -> shotgun)
function bestGun(loadedOnly){const S=situation();let best=null,bv=-1e9;
 for(const id of ownedGuns()){const a=am(id),g=gunAmmo(id);if(loadedOnly?a.mag<=0:!hasAmmo(id))continue;const n=S.inR[id]||0;if(!n&&id!=="basic")continue;let v=1+Math.min(n,12)*.12;
   if(id==="minigun")v+=n>=6?2.6:.4;if(id==="shotgun")v+=S.dN<110&&S.nearN>=2?3.6:-1;if(id==="fire")v+=S.dN<100&&S.nearN>=3?4.2:-1.5;
   if(id==="rocket")v+=S.packN>=5&&S.dN>70?3.2:S.packN>=3?1:-1;if(id==="laser")v+=n>=8?2.4:.3;
   if(id==="sniper")v+=(S.big>=300?3.4:S.big>=150?1.6:-1)-(n>=10?2.5:0);
   if(id==="basic")v+=.2;if(a.mag<=0)v-=2.5;if(g.max!==Infinity&&a.res+a.mag<g.mag)v-=1;if(id===curW().id)v+=.6;if(v>bv){bv=v;best=id;}}
 return best||"basic";}
function panicList(){const L=STR13.filter(id=>ownedGuns().indexOf(id)>=0);return CFG.order?L.reverse():L;}
function nextPanicGun(){const P=AIS.panic,L=P.list;if(!L.length)return;let pickId=null;
 for(let k=1;k<=L.length;k++){const id=L[(P.idx+k)%L.length];if(am(id).mag>0){pickId=id;P.idx=(P.idx+k)%L.length;break;}}
 if(!pickId)for(let k=1;k<=L.length;k++){const id=L[(P.idx+k)%L.length];if(hasAmmo(id)){pickId=id;P.idx=(P.idx+k)%L.length;break;}}
 P.t=0;if(pickId){setGun(pickId,"panic");P.seq.push(pickId);}}
function tagStep(inR){const T=TAG13,th=CFG.tag/100,frac=e=>e.hp/(e.max||e.hp||1),ok=e=>e&&e.hp>0&&enemies.indexOf(e)>=0;
 const inRange=e=>inR.indexOf(e)>=0;const ph=p=>{if(T.phase!==p){T.phase=p;T.trace.push(p);}};
 if(T.phase===0){if(!ok(T.orig)){T.orig=pick13(inR.filter(e=>e!==T.e),CFG.prio);if(T.orig)T.trace.push("orig");}
   if(!T.orig){ph(1);}else if(frac(T.orig)>th)return inRange(T.orig)?T.orig:null;else ph(1);}
 if(T.phase===1){if(frac(T.e)>th)return inRange(T.e)?T.e:null;ph(ok(T.orig)?2:3);}
 if(T.phase===2){if(ok(T.orig))return inRange(T.orig)?T.orig:null;ph(3);}
 if(T.phase===3)return inRange(T.e)?T.e:null;return null;}
function ai13(dt){const w=curW();
 if(TAG13&&(TAG13.e.hp<=0||enemies.indexOf(TAG13.e)<0)){TAG13.done=1;S13.lastTag=TAG13;TAG13=null;}
 // PANIC: breach -> dump every owned gun, one at a time
 let breach=null,bd=1e9;const PR=CFG.panic+(AIS.panic?18:0);if(CFG.panic>0)for(const e of enemies){if(e.hp<=0)continue;const d=Math.hypot(e.x,e.y);if(d<PR&&d<bd){bd=d;breach=e;}}
 if(AIS.panic){if(breach)AIS.panic.clr=0;else{AIS.panic.clr=(AIS.panic.clr||0)+dt;if(AIS.panic.clr<.5)breach=AIS.panic.lastB&&AIS.panic.lastB.hp>0?AIS.panic.lastB:"hold";}if(breach&&breach!=="hold")AIS.panic.lastB=breach;}
 if(breach==="hold")breach=pick13(enemies.filter(e=>e.hp>0&&Math.hypot(e.x,e.y)<PR+40),1)||"hold";
 if(breach&&!AIS.panic){AIS.panic={prev:w.id,idx:-1,t:0,list:panicList(),seq:[]};nextPanicGun();S13.panics=(S13.panics||0)+1;S13.lastPanic=AIS.panic;}
 else if(!breach&&AIS.panic){const prev=AIS.panic.prev;AIS.panic.end=t;AIS.panic=null;if(hasAmmo(prev))setGun(prev,"panic over");}
 if(AIS.panic){AIS.panic.t+=dt;const a=am(curW().id);if((a.mag<=0&&curW().id!=="basic")||AIS.panic.t>1.4)nextPanicGun();}
 // WEAPON SWITCH timer
 if(!AIS.panic&&CFG.switch<10){AIS.swT+=dt;if(AIS.swT>=CFG.switch){AIS.swT=0;const b=bestGun(false);if(b&&b!==curW().id)setGun(b,"switch");}}
 const W0=curW(),R=rngOf(W0),inR=[];for(const e of enemies)if(e.hp>0&&Math.hypot(e.x,e.y)<=R+e.r*.4)inR.push(e);
 let tgt=null;
 if(AIS.panic)tgt=breach==="hold"?null:breach;
 else{let hb=1e9;for(const e of inR){const d=Math.hypot(e.x,e.y);if(d>=13+e.r*.45+14)continue;let da=Math.abs(Math.atan2(e.y,e.x)-aim);if(da>Math.PI)da=6.283-da;const v=da*20+d;if(v<hb){hb=v;tgt=e;}} // huggers: the one the barrel already faces first (sweep the ring, don't spin)
   const hug=!!tgt;
   if(!tgt&&TAG13)tgt=tagStep(inR);
   if(!tgt)tgt=pick13(inR,CFG.prio);
   // target lock: no frame-by-frame thrash in a crowd (keeps the barrel on one body ~0.45 s unless it dies/leaves range or a new hugger shows up)
   const L=AIS.lock;if(!TAG13&&L&&L.e!==tgt&&L.e.hp>0&&inR.indexOf(L.e)>=0&&t-L.t<.45&&(!hug||L.hug))tgt=L.e;
   if(tgt&&(!L||L.e!==tgt))AIS.lock={e:tgt,t,hug};}
 const pre=tgt||pick13(enemies.filter(e=>e.hp>0),1); // pre-aim at the next arrival
 AIM_T13=tgt;
 if(pre){const g=G13[W0.id],sp=g&&g.spd?g.spd:0,d=Math.hypot(pre.x,pre.y),tt=sp?d/sp:0;const px=pre.x+(pre.vx13||0)*tt*LEAD,py=pre.y+(pre.vy13||0)*tt*LEAD;
   const want=Math.atan2(py,px);let df=want-aim;while(df>Math.PI)df-=6.283;while(df<-Math.PI)df+=6.283;aim+=clamp(df,-TURN*dt,TURN*dt);aim=Math.atan2(Math.sin(aim),Math.cos(aim));AIS.err=Math.abs(df);}
 // FIRE STYLE: tight bursts .. full spray
 const s=AIS.panic?8:CFG.style;STYLE13=AIS.panic?{spr:1.3,rate:.85}:{spr:.75+.09*s,rate:1.12-.04*s};
 const a=G13[W0.id]?am(W0.id):null;
 const tgtHug=tgt&&Math.hypot(tgt.x,tgt.y)<13+tgt.r*.45+16; // point-blank shots hit whatever hugs the barrel side (pb arc), no need to wait for exact alignment
 if(tgt&&AIS.err<(tgtHug?.6:Math.max(.12,(W0.spread||0)+.06))){
   if(AIS.pause>0)AIS.pause-=dt;
   else if(tryShoot13()){AIS.burstN++;const n=s>=8?1e9:3+s*2;if(AIS.burstN>=n&&W0.rate<.3){AIS.burstN=0;AIS.pause=.32*(1-s/8);}}}
 // RELOAD rule: early top-up .. empty then swap
 if(a&&a.rl<=0){const g=gunAmmo(W0.id),frac=a.mag/g.mag,r=CFG.reload,idle=!tgt;
   if(a.mag<=0){let alt=null;if(r>=5&&!AIS.panic){alt=bestGun(true);if(alt===W0.id)alt=null;}if(alt)setGun(alt,"empty→swap");else if(!startReload(W0.id)&&!hasAmmo(W0.id))dryOut(W0.id);}
   else if(r<=3&&idle&&frac<1)startReload(W0.id);
   else if(r<=1&&frac<=.25)startReload(W0.id);}
 if(CFG.reload>=5)for(const id of ownedGuns())if(id!==curW().id){const q=am(id);if(q.mag<gunAmmo(id).mag&&q.rl<=0&&q.res>0){q.rlT=q.rl=gunAmmo(id).reload;}} // holstered guns reload in the background
}
{const _tf=tryFire;tryFire=function(dt){
   const w=curW(),manual=!mainAuto();fireCd-=dt;const fc=fireCd,a0=aim,mf=MAIN_INPUT.fire;
   fireCd=1e9;MAIN_INPUT.fire=false;try{_tf(dt);}finally{fireCd=fc;MAIN_INPUT.fire=mf;}  // legacy: aux guns + manual aim only
   if(t-AIS.lastShot<.2&&curW().id==="minigun")SPIN13=Math.min(1,SPIN13+dt/1.1);else SPIN13=Math.max(0,SPIN13-dt*1.5);
   if(manual){STYLE13={spr:1,rate:1};AIM_T13=null;if(MAIN_INPUT.fire)tryShoot13();
     const q=G13[curW().id]?am(curW().id):null;if(q&&q.mag<=0&&q.rl<=0&&!startReload(curW().id)&&!hasAmmo(curW().id))dryOut(curW().id);}
   else{aim=a0;ai13(dt);}};}
window.__ai13={cfg:CFG,set:(k,v)=>{CFG[k]=v;saveCfg();},preset:p=>{Object.assign(CFG,PRESET13[p]);saveCfg();},AIS,tag:()=>TAG13,setTag:e=>{TAG13=e?{e,orig:null,phase:0,trace:[]}:null;},PRESET13,DEF13,G13,bestGun,STR13,panicList};
