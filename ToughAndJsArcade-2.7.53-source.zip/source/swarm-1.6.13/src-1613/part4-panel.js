// ---------------------------------------------------------------- 6) Turret AI panel (tap MAIN turret; 0.5x slow-mo; + left / − right)
let PANEL13=false;const SLOWMO=.5;
{const st=document.createElement("style");st.textContent=`
#ai13{position:fixed;left:0;right:0;bottom:0;z-index:20;display:none;flex-direction:column;background:#0c1220;border-top:3px solid #3a5080;box-shadow:0 -10px 30px #000a;padding:0 6px calc(6px + env(safe-area-inset-bottom));font-family:"Courier New",Courier,monospace;color:#eee;user-select:none;-webkit-user-select:none}
#ai13.on{display:flex}
#ai13 .notch{position:absolute;top:-11px;width:0;height:0;border-left:9px solid transparent;border-right:9px solid transparent;border-bottom:9px solid #3a5080;transform:translateX(-50%)}
#ai13 .hdr{display:flex;align-items:center;gap:6px;padding:6px 2px 5px}
#ai13 .tt{flex:1;min-width:0}#ai13 .tt b{display:block;color:#ffe066;font-size:13px;letter-spacing:.06em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ai13 .tt span{display:block;color:#9ab;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ai13 .x,#ai13 .au{flex:0 0 auto;height:34px;border:3px solid #647b8f;border-radius:4px;background:#162434;color:#dbe8e5;font:700 13px monospace;box-shadow:inset 0 -4px #080f1d}
#ai13 .x{width:40px;font-size:15px}#ai13 .au{padding:0 6px;font-size:10px}#ai13 .au.on{border-color:#ffe066;color:#ffe066}
#ai13 .pre{display:flex;gap:4px;padding:0 2px 5px}#ai13 .pre button{flex:1;padding:5px 0;font:700 10px monospace;border:2px solid #2e4060;border-radius:5px;background:#1a2840;color:#cde}
#ai13 .pre button.on{border-color:#ffe066;color:#ffe066}
#ai13 .list{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#152038;border:2px solid #2a3a58;border-radius:6px;padding:4px;display:flex;flex-direction:column;gap:4px}
#ai13 .box{flex:0 0 auto;background:#1a2840;border:2px solid #2e4060;border-radius:5px;padding:3px 4px;box-shadow:inset 0 -3px #0003;display:flex;align-items:center;gap:5px}
#ai13 .box.focus{border-color:#ffe066}#ai13 .box .mid{flex:1;min-width:0}#ai13 .box.off{opacity:.55}
#ai13 .top{display:flex;align-items:center;gap:6px;height:15px}#ai13 .nm{font:700 11px monospace;color:#cde;letter-spacing:.05em;white-space:nowrap}
#ai13 .val{margin-left:auto;font:700 11px monospace;color:#ffe066;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ai13 .tog{font:700 9px monospace;padding:1px 4px;border:1px solid #ff9a7a;border-radius:3px;background:#2a1a1a;color:#ffb4a0}
#ai13 .help{font-size:10px;color:#bac9d4;line-height:1.25;padding:4px 3px 0;min-height:28px}#ai13 .help b{color:#ffe066}
#ai13 .pm{flex:0 0 auto;width:36px;height:34px;border:3px solid #647b8f;border-radius:4px;background:#162434;color:#dbe8e5;font:700 17px/1 monospace;box-shadow:inset 0 -4px #080f1d;touch-action:none}
#ai13 .pm:active{background:#45664f;border-color:#c4e490}
#ai13 .trk{position:relative;height:22px;touch-action:none;margin:0 8px}#ai13 .ln{position:absolute;left:0;right:0;top:9px;height:5px;background:#0c1220;border:1px solid #2e4060}
#ai13 .fill{position:absolute;right:0;top:9px;height:5px;background:#ffe066}#ai13 .tk{position:absolute;top:16px;width:1px;height:4px;background:#3a4a60}
#ai13 .kn{position:absolute;top:2px;width:18px;height:18px;margin-left:-9px;border:3px solid #b3d5c1;background:#55746b;box-shadow:inset 0 -4px #304d49}
#ai13 .box.danger .fill{background:#ff5a3a}#ai13 .box.danger .nm{color:#ffb4a0}
#slow13{position:fixed;left:50%;top:calc(46px + env(safe-area-inset-top));transform:translateX(-50%);display:none;align-items:center;gap:6px;background:#141c2ce8;border:2px solid #3a5080;border-radius:6px;padding:4px 9px;font:700 12px "Courier New",monospace;color:#9fd8ff;letter-spacing:.08em;z-index:21;pointer-events:none}
#slow13.on{display:flex}
#tmodeBtn{top:calc(104px + env(safe-area-inset-top))!important}
@media (max-height:600px){#ai13 .hdr{padding:3px 2px 2px}#ai13 .tt span{display:none}#ai13 .pre{padding-bottom:3px}#ai13 .pre button{padding:2px 0}#ai13 .list{gap:3px;padding:3px}#ai13 .box{padding:2px 4px}#ai13 .pm{height:30px;width:34px}#ai13 .help{min-height:24px;font-size:9.5px;padding-top:2px}}`;document.head.appendChild(st);}
const BOX13=[
 {id:"switch",nm:"WEAPON SWITCH",plus:-1,min:1,max:10,step:1,fmt:x=>x>=10?"OFF":"every "+x+"s",ds:x=>x>=10?"Stays on the gun you picked":"Swaps to the owned gun (with ammo) that fits the closest pack"},
 {id:"range",nm:"FIRE RANGE",min:50,max:110,step:5,fmt:x=>x+"% of gun range",ds:x=>"Opens fire at: "+ownedGuns().map(id=>W_(id).nm+" "+Math.round(G13[id].rng*x/100)).join(" · ")},
 {id:"prio",nm:"TARGET PRIORITY",min:0,max:4,step:1,fmt:x=>PRIO_NAMES[x],ds:x=>["Whoever reaches the core first","Closest zombie in range","Runners and skitters first","Finish off hurt ones","Brutes, bloaters, bosses"][x]},
 {id:"style",nm:"FIRE STYLE",min:0,max:8,step:1,fmt:x=>x===0?"tight bursts":x>=8?"full spray":"bursts of "+(3+x*2),ds:x=>x>=8?"Dumps bullets: fastest rate, widest scatter":"Short controlled bursts with a pause; tighter scatter the lower it is"},
 {id:"panic",nm:"PANIC MODE",min:0,max:120,step:10,danger:1,tog:1,fmt:x=>x===0?"OFF":"breach "+x,ds:x=>x===0?"No close-range override":"A zombie inside "+x+" → dump EVERY owned gun, one at a time ("+(CFG.order?"WEAK→STRONG":"STRONG→WEAK")+"). Ends when the ring is clear"},
 {id:"tag",nm:"TAG",min:10,max:90,step:10,plus:-1,fmt:x=>(TAG13?"TAGGED · ":"tap a zombie · ")+"drop to "+x+"%",ds:x=>TAG13?"Current target → "+x+"%, tagged → "+x+"%, kill current, then kill tagged":"Tap ONE zombie on the field to tag it. Nothing tagged = this box does nothing"},
 {id:"reload",nm:"RELOAD",min:0,max:8,step:1,fmt:x=>x<=1?"top up early":x>=8?"empty → swap gun":x>=5?"empty, swap if loaded":"reload when idle",ds:x=>x>=5?"Shoots the mag dry, then swaps to a loaded gun; holstered guns reload":"Reloads early to keep the mag topped"}
];
const panel=document.createElement("div");panel.id="ai13";panel.innerHTML=`<div class="notch"></div><div class="hdr"><div class="tt"><b>MAIN TURRET · AUTO AI</b><span class="sub"></span></div><button class="au">AUTO</button><button class="x" aria-label="Close and resume">✕</button></div>
<div class="pre"><button data-p="safe">SAFE</button><button data-p="bal">BALANCED</button><button data-p="aggro">AGGRO</button></div><div class="list"></div><div class="help"></div>`;
document.body.appendChild(panel);const slow=document.createElement("div");slow.id="slow13";slow.textContent="▮▮ SLOW-MO 0.5×";document.body.appendChild(slow);
const list=panel.querySelector(".list");let FOC=null;
function help(){const b=FOC;if(b)panel.querySelector(".help").innerHTML="<b>"+b.nm+"</b> — "+b.ds(CFG[b.id])+' · <span style="color:#7f93ad">+ stronger · − softer</span>';}
function focus(b){if(FOC)FOC.el.classList.remove("focus");FOC=b;b.el.classList.add("focus");help();}
function pct(b){const p=(CFG[b.id]-b.min)/(b.max-b.min);return (b.plus||1)>0?p:1-p;}
function render(b){const el=b.el,p=pct(b);el.querySelector(".kn").style.left=((1-p)*100)+"%";el.querySelector(".fill").style.width=(p*100)+"%";
 el.querySelector(".val").textContent=b.fmt(CFG[b.id]);if(b.tog)el.querySelector(".tog").textContent=CFG.order?"WEAK→STRONG":"STRONG→WEAK";
 el.classList.toggle("off",(b.id==="switch"&&CFG.switch>=10)||(b.id==="panic"&&CFG.panic===0)||(b.id==="tag"&&!TAG13));if(b===FOC)help();}
function clearPre(){panel.querySelectorAll(".pre button").forEach(x=>x.classList.toggle("on",false));}
function markPre(){clearPre();for(const k in PRESET13){if(Object.keys(PRESET13[k]).every(q=>PRESET13[k][q]===CFG[q]))panel.querySelector('[data-p="'+k+'"]').classList.add("on");}}
for(const b of BOX13){const el=document.createElement("div");el.className="box"+(b.danger?" danger":"");el.dataset.id=b.id;
 const n=Math.min(12,Math.round((b.max-b.min)/b.step));let tk="";for(let i=0;i<=n;i++)tk+=`<i class="tk" style="left:${i/n*100}%"></i>`;
 el.innerHTML=`<button class="pm" data-d="1" aria-label="${b.nm} stronger">+</button><div class="mid"><div class="top"><span class="nm">${b.nm}</span>${b.tog?'<button class="tog"></button>':""}<span class="val"></span></div><div class="trk"><div class="ln"></div><div class="fill"></div>${tk}<div class="kn"></div></div></div><button class="pm" data-d="-1" aria-label="${b.nm} softer">−</button>`;
 b.el=el;list.appendChild(el);render(b);
 el.querySelectorAll(".pm").forEach(btn=>btn.onclick=e=>{e.stopPropagation();focus(b);CFG[b.id]=clamp(CFG[b.id]+(+btn.dataset.d)*(b.plus||1)*b.step,b.min,b.max);saveCfg();render(b);markPre();});
 if(b.tog)el.querySelector(".tog").onclick=e=>{e.stopPropagation();focus(b);CFG.order=CFG.order?0:1;saveCfg();render(b);markPre();};
 const trk=el.querySelector(".trk");let drag=false;
 const set=e=>{const r=trk.getBoundingClientRect();let q=clamp((e.clientX-r.left)/r.width,0,1);focus(b);const qq=(b.plus||1)>0?1-q:q;CFG[b.id]=clamp(Math.round((b.min+qq*(b.max-b.min))/b.step)*b.step,b.min,b.max);saveCfg();render(b);markPre();};
 trk.addEventListener("pointerdown",e=>{drag=true;try{trk.setPointerCapture(e.pointerId);}catch(_){}set(e);});trk.addEventListener("pointermove",e=>{if(drag)set(e);});
 trk.addEventListener("pointerup",()=>drag=false);trk.addEventListener("pointercancel",()=>drag=false);}
focus(BOX13[0]);markPre();
panel.querySelectorAll(".pre button").forEach(btn=>btn.onclick=e=>{e.stopPropagation();Object.assign(CFG,PRESET13[btn.dataset.p]);saveCfg();BOX13.forEach(render);markPre();});
panel.addEventListener("pointerdown",e=>e.stopPropagation());
panel.querySelector(".x").onclick=e=>{e.stopPropagation();openPanel(false);};
const au=panel.querySelector(".au");let prevAim="arrows";
au.onclick=e=>{e.stopPropagation();const S=window.SWARM_SET;if(S.controls.aim==="auto")S.controls.aim=prevAim==="auto"?"arrows":prevAim;else{prevAim=S.controls.aim;S.controls.aim="auto";}
 try{localStorage.setItem("swarm.settings",JSON.stringify(S));}catch(_){}if(window.__mainControls)window.__mainControls();refreshPanel();};
function refreshPanel(){const S=window.SWARM_SET,on=S&&S.controls.aim==="auto";au.textContent=on?"AUTO ON":"AUTO OFF";au.classList.toggle("on",!!on);
 const w=curW(),a=G13[w.id]?am(w.id):null;panel.querySelector(".sub").textContent=(on?"":"Manual aim now · rules apply in AUTO · ")+"Gun: "+w.nm+(a?" "+a.mag+"/"+(a.res===Infinity?"∞":Math.floor(a.res)):"")+" · owned: "+ownedGuns().map(id=>W_(id).nm).join(" ");
 BOX13.forEach(render);}
function placePanel(){const ty=TY+6*VS,top=Math.min(ty+26,innerHeight-236);panel.style.top=Math.max(120,top)+"px";panel.querySelector(".notch").style.left=CX+"px";}
function openPanel(o){if(o&&(!running||dead))return;PANEL13=!!o;panel.classList.toggle("on",PANEL13);slow.classList.toggle("on",PANEL13);if(PANEL13){if(window.__releaseMain)window.__releaseMain();placePanel();refreshPanel();}S13.panelOpen=PANEL13;}
window.__panel13={open:openPanel,isOpen:()=>PANEL13,refresh:refreshPanel,BOX13};
// TARGET button (was hidden under ⚙ SETTINGS): moved below it, now opens the AI panel
{const b=$("tmodeBtn");if(b){b.style.top="104px";const lab=()=>{const tx="AI: "+PRIO_NAMES[CFG.prio]+" ▸";if(b.textContent!==tx)b.textContent=tx;};lab();b.onclick=ev=>{ev.stopPropagation();openPanel(!PANEL13);lab();};setInterval(lab,500);}}
// taps: MAIN turret toggles the panel; a zombie tap sets the TAG (one at a time; tap again to clear)
function zombieAt(sx,sy){let best=null,bd=1e9;for(const e of enemies){if(e.hp<=0)continue;const B=box13(e),x=CX+e.x*VS,y=TY+e.y*KY*VS,pad=10;
  if(sx<x-B.hw*VS-pad||sx>x+B.hw*VS+pad||sy<y+B.top*VS-pad||sy>y+B.bot*VS+pad)continue;const d=Math.hypot(sx-x,sy-(y+(B.top+B.bot)/2*VS));if(d<bd){bd=d;best=e;}}return best;}
function turretAt(sx,sy){const k=depthK(0)*VS;return Math.abs(sx-CX)<20*Math.max(1,k)&&sy>TY-34*k&&sy<TY+10*k;}
cv.addEventListener("pointerdown",e=>{if(placeMode||!running||dead||!$("overlay").classList.contains("off"))return;
 const r=cv.getBoundingClientRect(),sx=e.clientX-r.left,sy=e.clientY-r.top;
 if(turretAt(sx,sy)){e.stopImmediatePropagation();e.preventDefault();openPanel(!PANEL13);return;}
 if(!between&&enemies.length&&(mainAuto()||PANEL13)){const z=zombieAt(sx,sy);if(z){e.stopImmediatePropagation();e.preventDefault();if(TAG13&&TAG13.e===z){TAG13=null;toast("Tag cleared");}else{TAG13={e:z,orig:null,phase:0,trace:[],at:t};toast("TAGGED — turret drops it to "+CFG.tag+"%");}if(PANEL13)refreshPanel();return;}}
 if(PANEL13){e.stopImmediatePropagation();openPanel(false);}},true);
{const _back=window.swarmBack;window.swarmBack=function(){if(PANEL13){openPanel(false);return true;}return _back&&_back.apply(this,arguments);};}
