/* ===== v1.6.13 — t991/t993/t994: 7/7/7 kit, ammo + AMMO RACK, turret AI panel, huggers, true hitboxes, synced audio =====
 * Zombie art untouched (pxBody/drawType never edited). Hidden items stay in code (HIDE13 sets), nothing deleted.
 */
;(function(){
"use strict";
const S13=window.__S13={ver:"1.6.13",log:[],hits:[],flashNoDmg:0,pb:0,shots:0,errors:0,fired:{}};
// ---------------------------------------------------------------- 0) no Custom Game
CUSTOM=false;LEARN_AI=false;try{localStorage.removeItem("swarmCustom");localStorage.removeItem("swarmLearnAI");}catch(e){}
for(const id of ["customChk","learnChk"]){const c=$(id);if(c&&c.parentNode)c.parentNode.remove();}
{const s=document.querySelector("#overlay .sub");if(s)s.innerHTML="LAST STAND<br>You are the AI core. The swarm wants you dead.<br>Hold the line. Grind the horde.<br>7 guns · 7 defenses · 7 abilities. Tap the turret for its AI.";}
// tiny dodge is rolled BEFORE contact now (bHit13) -> no post-flash refunds
MISS.skitter=0;MISS.tiny=0;
// ---------------------------------------------------------------- 1) the 7 guns (data)
// fo:[full-damage distance, max distance, damage multiplier at max]
const G13={
 basic:  {cost:0,  dmg:12, rate:.11, spd:560, rng:280, spread:.025,sgrow:.02, fo:[170,280,.7], col:"#ffe066", r:1.6,
          desc:"Steady mid-range rifle. Full damage to 170, 70% at 280."},
 minigun:{cost:280,dmg:5,  rate:.05, spd:640, rng:300, spread:.045,sgrow:.04, fo:[130,300,.55],col:"#fff2b0", r:1.3,spin:1,
          desc:"Spins up from 8 to 20 shots/s. Hose that loses bite past 130."},
 shotgun:{cost:200,dmg:8,  rate:.62, spd:520, rng:170, pellets:8, cone:.30, sgrow:.10, fo:[45,170,.25],col:"#ffd080", r:1.8,knock:7,
          desc:"8 pellets. Shreds point-blank, knocks back, weak past 100."},
 fire:   {cost:260,dmg:7,  rate:.07, rng:150, cone:.28, sgrow:.08, fo:[60,150,.45], col:"#ff9030", burn:2.4,
          desc:"Cone that hits everything in it and sets them burning."},
 rocket: {cost:340,dmg:26, rate:.8,  spd:300, rng:320, spread:.02,sgrow:.015,col:"#ff6a3a", r:3, blast:62, bfo:.3, knock:16,
          desc:"Splash. 100% at the centre, 30% at the edge. Airbursts at max range."},
 laser:  {cost:380,dmg:15, rate:.22, rng:440, maxN:8, pm:.9, col:"#ff4a9a",
          desc:"Hitscan line. Cuts 8 deep (-10% each). No falloff."},
 sniper: {cost:420,dmg:140,rate:1.4, rng:640, maxN:2, pm:.6, col:"#ffffff", knock:20, stagger:.45,
          desc:"One heavy round, 2 deep. Knocks back and staggers. Boss killer."}
};
const ORDER13=["basic","minigun","shotgun","fire","rocket","laser","sniper"];
for(const w of WEAPONS){const g=G13[w.id];if(!g){w.hidden13=1;continue;}
  Object.assign(w,{cost:g.cost,dmg:g.dmg,rate:g.rate,rng:g.rng,spread:g.spread||g.cone||0,sgrow:g.sgrow||0,col:g.col});if(g.spd)w.spd=g.spd;w.pierce=0;w.explode=0;w.fire=0;w.pellets=1;}
// ---------------------------------------------------------------- 2) AMMO (data-driven, Jay t993/t994: SHOP buy + AMMO RACK, no kill drops)
const AMMO13={
 guns:{ // mag, reload s, start reserve, max reserve, rack units/s (per rack, during waves)
  basic:  {mag:30, reload:1.0, res:Infinity,max:Infinity,rack:0},
  minigun:{mag:150,reload:2.4, res:450, max:900, rack:1.0},
  shotgun:{mag:6,  reload:1.7, res:36,  max:72,  rack:.06},
  fire:   {mag:120,reload:2.0, res:360, max:720, rack:.8},
  rocket: {mag:4,  reload:2.2, res:16,  max:32,  rack:.025},
  laser:  {mag:24, reload:1.8, res:96,  max:192, rack:.12},
  sniper: {mag:5,  reload:2.5, res:20,  max:40,  rack:.025}},
 shop:{nm:"AMMO",cost:90,fill:.5},          // +50% of each owned gun's max reserve, between waves
 rack:{id:"ammorack",nm:"AMMO RACK",cost:220,hp:120,stack:.6,capMul:2.0,maxRacks:3}, // 1 rack=1x, each extra +0.6x, hard cap 2x
 sources:["shop","rack"]
};
window.__AMMO13=AMMO13;
const AM={};function am(id){if(!AM[id]){const g=AMMO13.guns[id]||AMMO13.guns.basic;AM[id]={mag:g.mag,res:g.res,rl:0,rlT:0,rack:0};}return AM[id];}
function gunAmmo(id){return AMMO13.guns[id]||AMMO13.guns.basic;}
function ownedGuns(){return ORDER13.filter(id=>{const w=W_(id);return w&&!w.locked;});}
function hasAmmo(id){const a=am(id);return a.mag>0||a.res>0;}
function reloadable(id){const a=am(id),g=gunAmmo(id);return a.mag<g.mag&&a.res>0&&a.rl<=0;}
function startReload(id){if(!reloadable(id))return false;const w=W_(id),a=am(id);a.rlT=a.rl=gunAmmo(id).reload*(1-(w?w.lvl:0)*.05);A13.play("reload",{x:0,g:.55});return true;}
function tickAmmo(dt){for(const id of ORDER13){const a=AM[id];if(!a||a.rl<=0)continue;a.rl-=dt;if(a.rl<=0){a.rl=0;const g=gunAmmo(id),need=g.mag-a.mag,take=Math.min(need,a.res);a.mag+=take;if(a.res!==Infinity)a.res-=take;}}}
function resetAmmo(){for(const k in AM)delete AM[k];}
window.__am13={get:id=>Object.assign({},am(id)),AM,startReload,hasAmmo,owned:ownedGuns};
// ---------------------------------------------------------------- 3) geometry: muzzle, height, sprite-fitted hitboxes
const MUZ_L=22,PIV=16,TORSO=6;
function bodyScale13(e){
 if(e.limbstack)return "L";
 if(e.curt)return[1,1];if(e.ashheart)return[.8,1];if(e.curtbrute)return[1.35,1.2];if(e.spitface)return[1.02,1];
 if(e.gnasher)return[.55,1];if(e.tick)return[.42,1.1];if(e.dragger)return null;
 if(e.boomer){const sw=e.swell||0;return[1.15*(1+sw*.35),1.25+sw*.2];}
 if(e.stitcher||e.lantern)return[1,1];if(e.skitter)return[.58,1];if(e.howler)return[1.02,1];if(e.bloater)return[1.38,1.55];
 if(e.armored)return e.shield?[1.15,1.15]:[1.42,1.25];if(e.twin||e.twinCol)return[.72,1];if(e.spitter)return[1,1];
 if(e.kind==="mutant")return e.shield?[1.15,1.15]:(e.brute||e.armored)?[1.42,1.25]:[1.35,1.15];
 if(e.kind==="runner")return e.crawler?null:[.82,1];
 return[1,1];}
// screen-units box (x right, y down) around the ground anchor (e.x, e.y*KY); includes upright depth scale
function box13(e){const k=depthK(e.y),s=bodyScale13(e);let hw,top,bot;
 if(s==="L"){hw=15;top=-22;bot=11;}else if(!s){hw=9;top=-5;bot=5;}else{hw=6.6*s[1]*s[0];top=-19.5*s[0];bot=8.8*s[0];}
 return{hw:hw*k,top:top*k,bot:bot*k};}
function torsoH(e){const b=box13(e);return Math.max(2,-(b.top+b.bot)/2);}
function muzzle13(a){const k=depthK(0),n=Math.hypot(Math.cos(a),KY*Math.sin(a))||1,r0=k*MUZ_L/n;return{x:Math.cos(a)*r0,y:Math.sin(a)*r0,z:PIV*k,r0};}
function z13(b){if(b.z0==null)return b.z==null?TORSO:b.z;const s=Math.hypot(b.x-b.ox,b.y-b.oy);return b.zt+(b.z0-b.zt)*Math.max(0,1-s/b.zd);}
window.__geo13={box13,muzzle13,z13,bodyScale13};
function fall13(fo,d){if(!fo||d<=fo[0])return 1;return Math.max(fo[2],1-(1-fo[2])*(d-fo[0])/(fo[1]-fo[0]));}
// THE projectile hit test (called by the base bullet loop instead of the old ground circle)
function bHit13(b,e){
 if(e.hp<=0)return false;const dx=b.x-e.x;if(dx>36||dx<-36)return false;
 if(b.hs13&&b.hs13.indexOf(e)>=0)return false;
 const B=box13(e),rr=b.r13||1.6;if(Math.abs(dx)>B.hw+rr)return false;
 const dy=(b.y*KY-z13(b))-e.y*KY;if(dy<B.top-rr||dy>B.bot+rr)return false;
 b.hs13=b.hs13||[];b.hs13.push(e);
 if(e.tiny||e.skitter){const p=e.skitter?.30:.18;if(Math.random()<p){ // dodge BEFORE contact: no flash, no damage, bullet flies on
   floaters.push({x:e.x,y:e.y-6,t:0,txt:"MISS",col:"#9ab"});const s=Math.random()<.5?-1:1;e.x+=s*5;S13.dodge=(S13.dodge||0)+1;return false;}}
 if(b.dmg0==null)b.dmg0=b.dmg;
 const d=b.o?Math.hypot(b.x-b.o[0],b.y-b.o[1]):0;b.dmg=b.dmg0*fall13(b.fo13,d)*Math.pow(.85,b.nh13||0);b.nh13=(b.nh13||0)+1;
 if(e.armored&&!e.limbstack){const f=Math.hypot(e.x,e.y)||1;if((b.vx*-e.x/f+b.vy*-e.y/f)/(Math.hypot(b.vx,b.vy)||1)<-.5)b.dmg*=.3;}
 spark13(b.x,b.y*KY-z13(b),b.col||"#ffe066",b.wid);
 A13.hit(e);S13.lastHit=e;return true;}
window.bHit13=bHit13;
