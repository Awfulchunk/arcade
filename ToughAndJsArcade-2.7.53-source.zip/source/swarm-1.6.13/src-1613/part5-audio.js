// ---------------------------------------------------------------- 7) Audio 1.6.13: no beat grid, same-frame, quiet master, gentle compressor, voice cap w/ stealing
const A13=(function(){
 let AC=null,MAST=null,COMP=null,SFX=null,ZB=null,AN=null;const BUF={},voices=[],loops={},PEND=[];
 const ST={shots:0,started:0,stolen:0,dropped:{},gunDropped:0,peakVoices:0,events:[],grunts:0,moans:0,groans:0,reloads:0,boom:0,maxOffsetMs:0};
 const CAP=24,GCAP={minigun:7,fire:3,basic:6};
 const SET=()=>window.SWARM_SET||{audio:{master:.6,sfx:.7,music:.5,mute:0}};
 // one-time quieter defaults (old untouched defaults only)
 try{const S=window.SWARM_SET;if(S&&!S.audio.a13){for(const [k,v,n] of [["master",.35,.6],["sfx",.35,.7],["music",.25,.5]])if(S.audio[k]===v)S.audio[k]=n;S.audio.a13=1;localStorage.setItem("swarm.settings",JSON.stringify(S));}}catch(e){}
 function ok(){const S=SET();return AC&&AC.state==="running"&&running&&!dead&&!document.hidden&&$("swSet")?.style.display!=="flex"&&!S.audio.mute&&S.audio.master>0;}
 // --- tiny synth kit (rendered once to buffers) ---
 let seed=12345;const rn=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
 function mk(dur,fn){const sr=AC.sampleRate,n=Math.max(1,Math.ceil(dur*sr)),d=new Float32Array(n);fn(d,sr,n);let pk=0;for(let i=0;i<n;i++)pk=Math.max(pk,Math.abs(d[i]));if(pk>0)for(let i=0;i<n;i++)d[i]/=pk;
   for(let i=0;i<Math.min(64,n);i++){d[i]*=i/64;d[n-1-i]*=i/64;}const b=AC.createBuffer(1,n,sr);b.getChannelData(0).set(d);return b;}
 function bq(type,f,q,sr){const w=2*Math.PI*f/sr,al=Math.sin(w)/(2*q),c=Math.cos(w);let b0,b1,b2,a0=1+al,a1=-2*c,a2=1-al;
   if(type==="bp"){b0=al;b1=0;b2=-al;}else if(type==="lp"){b0=(1-c)/2;b1=1-c;b2=(1-c)/2;}else{b0=(1+c)/2;b1=-(1+c);b2=(1+c)/2;}
   let x1=0,x2=0,y1=0,y2=0;return x=>{const y=(b0*x+b1*x1+b2*x2-a1*y1-a2*y2)/a0;x2=x1;x1=x;y2=y1;y1=y;return y;};}
 const env=(t,a,d)=>t<a?t/a:Math.exp(-(t-a)/d);
 // gun = click + body + bass (each gun tuned apart)
 function gun(o){return mk(o.len,(d,sr,n)=>{let ph=0,pb=0;const hp=bq("hp",o.ck,1,sr),lp=bq("lp",o.lp||3000,.7,sr);
   for(let i=0;i<n;i++){const t=i/sr,nz=rn();const click=hp(nz)*env(t,.0005,o.ckd)*o.ckg;
     const bf=o.bf*(1+(o.bsl||0)*Math.exp(-t/.02));ph+=bf/sr;let body;
     if(o.bt==="sq")body=Math.sign(Math.sin(2*Math.PI*ph))*.6;else if(o.bt==="fm")body=Math.sin(2*Math.PI*ph+2.2*Math.exp(-t/.05)*Math.sin(2*Math.PI*ph*1.5));else if(o.bt==="nz")body=lp(nz);else body=Math.sin(2*Math.PI*ph);
     body*=env(t,.002,o.bd)*o.bg;const pf=o.pf1*Math.pow(o.pf2/o.pf1,Math.min(1,t/o.pd));pb+=pf/sr;const bass=Math.sin(2*Math.PI*pb)*env(t,.003,o.pd)*o.pg;
     let ex=0;if(o.echo&&t>o.echo)ex=lp(rn())*env(t-o.echo,.005,.08)*.25;d[i]=click+body+bass+ex;}});}
 const RECIPES={
  basic:  {len:.16,ck:4000,ckd:.005,ckg:.5,bf:180,bt:"sq",bd:.04,bg:.35,pf1:72,pf2:52,pd:.06,pg:.9},
  minigun:{len:.09,ck:3000,ckd:.003,ckg:.55,bf:240,bt:"sq",bd:.025,bg:.3,pf1:64,pf2:56,pd:.04,pg:.6},
  shotgun:{len:.38,ck:1500,ckd:.008,ckg:.9,bf:0,bt:"nz",lp:2500,bd:.13,bg:.9,pf1:62,pf2:42,pd:.18,pg:1},
  rocket: {len:.42,ck:900,ckd:.01,ckg:.4,bf:0,bt:"nz",lp:1400,bd:.25,bg:.45,pf1:95,pf2:60,pd:.12,pg:1},
  laser:  {len:.2,ck:6000,ckd:.002,ckg:.15,bf:440,bt:"fm",bsl:-.5,bd:.11,bg:.7,pf1:110,pf2:90,pd:.1,pg:.55},
  sniper: {len:.5,ck:6000,ckd:.003,ckg:1,bf:0,bt:"nz",lp:1200,bd:.06,bg:.7,pf1:52,pf2:38,pd:.25,pg:1,echo:.16},
  fire:   {len:.12,ck:1200,ckd:.02,ckg:.25,bf:0,bt:"nz",lp:900,bd:.06,bg:.5,pf1:80,pf2:70,pd:.08,pg:.4}};
 function build(){if(BUF.basic)return;for(const k in RECIPES){const r=RECIPES[k];BUF[k]=[0,1,2].map(v=>{seed=999+v*77+k.length*13;return gun(Object.assign({},r,{bf:r.bf*(1+v*.025),pf1:r.pf1*(1-v*.03)}));});}
  BUF.boom=[mk(.75,(d,sr,n)=>{const lp=bq("lp",500,.7,sr);let ph=0;for(let i=0;i<n;i++){const t=i/sr;ph+=(40+30*Math.exp(-t/.05))/sr;d[i]=Math.sin(2*Math.PI*ph)*env(t,.004,.3)+lp(rn())*env(t,.002,.4)*.8;}})];
  BUF.reload=[mk(.32,(d,sr,n)=>{const hp=bq("hp",2500,2,sr);for(let i=0;i<n;i++){const t=i/sr;let x=0;for(const c of[0,.17])if(t>=c)x+=hp(rn())*env(t-c,.0005,.012)+Math.sin(2*Math.PI*1800*(t-c))*env(t-c,.0005,.02)*.4;d[i]=x;}})];
  BUF.dry=[mk(.06,(d,sr,n)=>{const hp=bq("hp",3000,2,sr);for(let i=0;i<n;i++){const t=i/sr;d[i]=hp(rn())*env(t,.0005,.008);}})];
  BUF.rack=[mk(.05,(d,sr,n)=>{for(let i=0;i<n;i++){const t=i/sr;d[i]=Math.sin(2*Math.PI*2400*t)*env(t,.001,.01);}})];
  BUF.suck=[mk(.6,(d,sr,n)=>{const lp=bq("bp",500,2,sr);for(let i=0;i<n;i++){const t=i/sr;d[i]=lp(rn())*Math.sin(Math.PI*t/.6);}})];
  BUF.grind=[mk(.25,(d,sr,n)=>{let ph=0;for(let i=0;i<n;i++){const t=i/sr;ph+=(85+40*Math.sin(t*60))/sr;d[i]=((ph%1)*2-1)*env(t,.005,.1);}})];
  // zombie voices: saw through two formants ("uh"), droop
  const voice=(dur,f0,f1,fa,fb,syl)=>mk(dur,(d,sr,n)=>{const A=bq("bp",fa,4,sr),B=bq("bp",fb,5,sr);let ph=0;for(let i=0;i<n;i++){const t=i/sr,u=t/dur;const f=f0+(f1-f0)*u+3*Math.sin(t*31);ph+=f/sr;const saw=(ph%1)*2-1;
    let a=Math.sin(Math.PI*Math.min(1,u*1.15))*(.85+.15*Math.sin(t*23));if(syl){const s2=u<.35?Math.sin(Math.PI*u/.35):Math.sin(Math.PI*(u-.35)/.65)*1.1;a=Math.max(0,s2)*.9;}
    d[i]=(A(saw)*1+B(saw)*.6+rn()*.04)*a;}});
  BUF.groan=[voice(1.1,118,92,520,880),voice(1.4,105,84,480,820),voice(.9,132,110,560,940),voice(1.6,96,78,460,780)];
  BUF.grunt=[voice(.13,180,140,620,1000),voice(.11,200,150,600,1100),voice(.14,165,130,580,950)];
  BUF.moan=[voice(.95,140,96,540,900,1),voice(1.05,125,88,500,860,1)];
  // loops
  BUF.motor=[mk(1,(d,sr,n)=>{let ph=0;for(let i=0;i<n;i++){const t=i/sr;ph+=110/sr;d[i]=(((ph%1)*2-1)*.6+Math.sin(2*Math.PI*55*t)*.5)*(.75+.25*Math.sin(2*Math.PI*24*t));}})];
  BUF.flame=[mk(1,(d,sr,n)=>{const A=bq("bp",600,1.2,sr),L=bq("lp",120,.7,sr);for(let i=0;i<n;i++){const t=i/sr,x=rn();d[i]=A(x)*1.2+L(x)*3*(.8+.2*Math.sin(2*Math.PI*7*t));}})];}
 function init(){if(AC)return AC;try{AC=new (window.AudioContext||window.webkitAudioContext)({latencyHint:"interactive"});}catch(e){try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e2){return null;}}
  MAST=AC.createGain();COMP=AC.createDynamicsCompressor();COMP.threshold.value=-18;COMP.knee.value=12;COMP.ratio.value=3;COMP.attack.value=.005;COMP.release.value=.2;
  SFX=AC.createGain();ZB=AC.createGain();SFX.connect(MAST);ZB.connect(MAST);MAST.connect(COMP);COMP.connect(AC.destination);AN=AC.createAnalyser();AN.fftSize=2048;COMP.connect(AN);
  build();gains();return AC;}
 let gT=0;function gains(){if(!AC)return;const S=SET().audio,m=S.mute?0:S.master*.55,duck=(AC.currentTime-lastGun<.25)?.5:1;
  MAST.gain.setTargetAtTime(m,AC.currentTime,.02);SFX.gain.setTargetAtTime(S.sfx,AC.currentTime,.02);ZB.gain.setTargetAtTime(S.music*.8*duck,AC.currentTime,.06);}
 addEventListener("pointerdown",()=>{const c=init();if(c&&c.state!=="running"&&c.resume)c.resume().catch(()=>{});},{passive:true,capture:true});
 document.addEventListener("visibilitychange",()=>{if(document.hidden){stopAll();if(AC&&AC.suspend)AC.suspend();}else if(AC&&AC.resume)AC.resume().catch(()=>{});});
 function prune(){const now=AC.currentTime;for(let i=voices.length-1;i>=0;i--)if(voices[i].end<=now)voices.splice(i,1);}
 function kill(v){try{v.g.gain.cancelScheduledValues(AC.currentTime);v.g.gain.setTargetAtTime(0,AC.currentTime,.004);v.s.stop(AC.currentTime+.03);}catch(e){}v.end=0;const i=voices.indexOf(v);if(i>=0)voices.splice(i,1);ST.stolen++;}
 let lastGun=-9;
 function play(name,o){if(!ok())return null;const set=BUF[name];if(!set)return null;o=o||{};prune();const pr=o.pr||2,grp=o.grp||name;
  const same=voices.filter(v=>v.grp===grp);if(GCAP[grp]&&same.length>=GCAP[grp])kill(same[0]);
  if(voices.length>=CAP){let vic=null;for(const v of voices)if(v.pr<=pr&&(!vic||v.pr<vic.pr||(v.pr===vic.pr&&v.t0<vic.t0)))vic=v;
    if(!vic){ST.dropped[name]=(ST.dropped[name]||0)+1;if(o.gun)ST.gunDropped++;return null;}kill(vic);}
  const b=set[(Math.random()*set.length)|0],s=AC.createBufferSource(),g=AC.createGain();s.buffer=b;const rate=(o.rate||1)*(1+(Math.random()-.5)*.05);s.playbackRate.value=rate;
  g.gain.value=o.g==null?.5:o.g;s.connect(g);let out=g;if(AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=clamp((o.x||0)/260,-.6,.6);g.connect(p);out=p;}
  out.connect(o.bus==="z"?ZB:SFX);const when=AC.currentTime;s.start(when); // immediate: same frame as the visual, no grid
  const v={s,g,pr,grp,t0:when,end:when+b.duration/rate+.02};voices.push(v);s.onended=()=>{const i=voices.indexOf(v);if(i>=0)voices.splice(i,1);};
  ST.started++;ST.peakVoices=Math.max(ST.peakVoices,voices.length);
  const ev={n:name,callT:performance.now(),acNow:AC.currentTime,sched:when,lat:(AC.baseLatency||0)+(AC.outputLatency||0)};ST.events.push(ev);PEND.push(ev);if(ST.events.length>400)ST.events.shift();return v;}
 const GG={basic:.42,minigun:.3,shotgun:.6,fire:.35,rocket:.55,laser:.4,sniper:.65};
 function shot(id,x,src){ST.shots++;const sub=src!=="main";if(id==="fire"){loop("flame",.35,sub?.5:1);return;}
  lastGun=AC?AC.currentTime:0;const v=play(id,{x,g:GG[id]*(sub?.45:1),pr:3,gun:1,grp:id,rate:id==="minigun"?(SPIN13>.5?1.04:1):1});if(id==="minigun"&&!sub)loop("motor",.12+.1*SPIN13,1);if(v&&ST.events.length)ST.events[ST.events.length-1].gun=1;}
 function loop(name,g,on){if(!ok())return;let L=loops[name];if(!L){const s=AC.createBufferSource(),gg=AC.createGain();s.buffer=BUF[name][0];s.loop=true;gg.gain.value=0;s.connect(gg);gg.connect(SFX);s.start();L=loops[name]={s,g:gg};}
  L.g.gain.setTargetAtTime(g*on,AC.currentTime,.03);L.last=AC.currentTime;}
 function stopLoops(force){if(!AC)return;for(const k in loops){const L=loops[k];if(force||AC.currentTime-L.last>.15)L.g.gain.setTargetAtTime(0,AC.currentTime,.05);}}
 function stopAll(){for(const v of voices.slice())try{v.s.stop();}catch(e){}voices.length=0;stopLoops(true);}
 let hitT=0,hitN=0,lastStreak=0,streak=0,groanCd=0,moanT=-9,lastSt=-1;
 function hit(e){if(!AC)return;const now=AC.currentTime;if(now-hitT>1){hitT=now;hitN=0;}if(hitN>=6||(e._gr13&&now-e._gr13<.3))return;hitN++;e._gr13=now;
  if(play("grunt",{x:e.x,g:.22,pr:1.5,bus:"z",rate:e.big?.8:e.tiny?1.25:1}))ST.grunts++;}
 const CHORD=[1,1.189,1.498,2,1.189*2];
 function kill1(e){if(!AC)return;const now=AC.currentTime;streak=now-lastStreak<.8?streak+1:0;lastStreak=now;const st=Math.min(streak,4);
  ST.streak=Math.max(ST.streak||0,streak);if(now-moanT<.14&&st===lastSt)return;moanT=now;lastSt=st;
  if(play("moan",{x:e.x,g:Math.min(.5,.22*Math.pow(1.25,st)),pr:2,bus:"z",grp:"moan",rate:CHORD[st]*(e.big?.75:1)}))ST.moans++;}
 function idle(dt){if(!ok()){stopLoops(true);return;}gains();stopLoops(false);groanCd-=dt;if(between||groanCd>0)return;
  let near=0;for(const e of enemies)if(Math.hypot(e.x,e.y)<300)near++;if(!near)return;
  if(voices.filter(v=>v.grp==="groan").length>=2)return;if(Math.random()<Math.min(.55,near*.035)*dt*4){groanCd=2.2+Math.random()*2.2;const e=enemies[(Math.random()*enemies.length)|0];
   if(play("groan",{x:e.x,g:.13,pr:1,bus:"z",grp:"groan",rate:.85+Math.random()*.3}))ST.groans++;}}
 return{drawn(now){for(const e of PEND)e.drawT=now;PEND.length=0;},init,play,shot,hit,kill:kill1,idle,stopAll,ST,ok,ctx:()=>AC,an:()=>AN,voices:()=>voices.length,CAP,
  sfx(k){if(k==="boom"){ST.boom++;return play("boom",{g:.7,pr:3});}if(k==="suck")return play("suck",{g:.3});if(k==="grind")return play("grind",{g:.3});}};
})();
let FRAME_T=0;window.__A13=A13;
