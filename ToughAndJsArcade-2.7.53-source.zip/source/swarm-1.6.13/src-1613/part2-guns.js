// ---------------------------------------------------------------- 4) firing the 7 guns (all sources), point-blank from the core
const P13=[]; // own FX in SCREEN units: {k,x,y,...,t,max}
function p13(o){if(P13.length<260)P13.push(Object.assign({t:0},o));}
function spark13(sx,sy,c,id){const n=id==="sniper"?7:id==="shotgun"?2:3;for(let i=0;i<n;i++){const a=rnd(6.283),s=rnd(25,id==="sniper"?120:70);p13({k:"spk",x:sx,y:sy,vx:Math.cos(a)*s,vy:Math.sin(a)*s-20,c,max:rnd(.12,.22)});}}
function lvl(w){return w&&w.lvl||0;}
function dmg13(e,amt,src){if(!e||e.hp<=0)return false;e.hp-=amt;e.hit=.1;A13.hit(e);return true;}
function knock13(e,amt,fromX,fromY){if(e.limbstack||e.big)amt*=.35;const dx=e.x-fromX,dy=e.y-fromY,d=Math.hypot(dx,dy)||1;e.x+=dx/d*amt;e.y+=dy/d*amt;}
let AIM_T13=null; // main AI target (for torso-height aim)
function aimInfo(src,ox,oy,a,w){ // target distance + target torso height so shots fly to the body, not over it
 let d=80,zt=TORSO;const tg=src==="main"?AIM_T13:null;
 if(tg&&tg.hp>0){d=Math.max(20,Math.hypot(tg.x-ox,tg.y-oy));zt=torsoH(tg);}
 return{d,zt};}
function huggers13(a,arc){const out=[];for(const e of enemies){if(e.hp<=0)continue;const d=Math.hypot(e.x,e.y);if(d>13+e.r*.45+16)continue;
  let q=Math.atan2(e.y,e.x)-a;while(q>Math.PI)q-=6.283;while(q<-Math.PI)q+=6.283;if(d<12||Math.abs(q)<arc)out.push([d,e]);}
 out.sort((p,q)=>p[0]-q[0]);return out.map(p=>p[1]);}
function pbFx(e,c){const M=muzzle13(aim),B=box13(e);p13({k:"trc",x:M.x,y:M.y*KY-M.z,x2:e.x,y2:e.y*KY+(B.top+B.bot)/2,c,max:.07});spark13(e.x,e.y*KY+(B.top+B.bot)/2,c);}
function spawnBullet(o,a,sp,w,src,g,extra){const b=Object.assign({x:o.x,y:o.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,dmg:w.dmg*lvlK(w),col:g.col,pierce:Math.floor(lvl(w)/2),
   explode:0,fire:0,life:g.rng/sp+.15,src,wid:w.id,o:[o.x,o.y],rng:g.rng,sg:g.sgrow,k:rnd(-1,1),ea:0,ox:o.x,oy:o.y,z0:o.z,zt:o.zt,zd:o.zd,fo13:g.fo,r13:g.r||1.6},extra||{});
 b.dmg0=b.dmg;bullets.push(b);return b;}
function rayScreen(ox,oy,oz,a,len,zt,zd){ // straight screen-space line from the muzzle; returns enemies hit in order + end point
 const sx=ox,sy=oy*KY-oz,tx=ox+Math.cos(a)*zd,ty=(oy+Math.sin(a)*zd)*KY-zt;let dx=tx-sx,dy=ty-sy;const L=Math.hypot(dx,dy)||1;dx/=L;dy/=L;
 const n=Math.hypot(Math.cos(a),KY*Math.sin(a))||1,maxL=len*n;const hits=[];
 for(const e of enemies){if(e.hp<=0)continue;const B=box13(e),cx=e.x,cy=e.y*KY;
   let t0=0,t1=maxL;const sl=(p,d,lo,hi)=>{if(Math.abs(d)<1e-9)return p>=lo&&p<=hi;let u=(lo-p)/d,v=(hi-p)/d;if(u>v){const q=u;u=v;v=q;}t0=Math.max(t0,u);t1=Math.min(t1,v);return t0<=t1;};
   if(sl(sx,dx,cx-B.hw-1,cx+B.hw+1)&&sl(sy,dy,cy+B.top-1,cy+B.bot+1))hits.push([t0,e]);}
 hits.sort((p,q)=>p[0]-q[0]);return{hits:hits.map(h=>h[1]),ts:hits.map(h=>h[0]),sx,sy,dx,dy,maxL};}
const FIRE13={
 basic(src,o,a,w,g){const sp=g.spd*(1+lvl(w)*.05),s=(g.spread)*(1-lvl(w)*.05)*STYLE13.spr;spawnBullet(o,a+rnd(-s,s),sp,w,src,g);},
 minigun(src,o,a,w,g){const sp=g.spd*(1+lvl(w)*.05),s=g.spread*(1+SPIN13*.4)*STYLE13.spr;spawnBullet(o,a+rnd(-s,s),sp,w,src,g);
   if(src==="main"){const M=muzzle13(a);p13({k:"shell",x:M.x*.4,y:M.y*KY*.4-12,vx:-Math.sin(a)*rnd(30,60)+rnd(-10,10),vy:-rnd(40,70),c:"#d0a040",max:.45});}},
 shotgun(src,o,a,w,g){const sp=g.spd*(1+lvl(w)*.05),n=g.pellets,c=g.cone*(1-lvl(w)*.04)*STYLE13.spr;let hs=src==="main"?huggers13(a,.9):[];
   for(let i=0;i<n;i++){const q=a+(-c+2*c*(i+.5)/n)+rnd(-.04,.04);
     if(hs.length&&i<Math.ceil(n*.6)){const e=hs[i%hs.length];if(e.hp>0){dmg13(e,w.dmg*lvlK(w),src);knock13(e,g.knock,0,0);pbFx(e,g.col);S13.pb++;continue;}}
     const b=spawnBullet(o,q,sp*rnd(.9,1.08),w,src,g);b.fx=(e)=>knock13(e,g.knock,b.ox,b.oy);}
   p13({k:"cone",x:o.x,y:o.y*KY-o.z,a:Math.atan2(Math.sin(a)*KY,Math.cos(a)),r:18,sp:c,c:"#ffe0a0",max:.07});},
 fire(src,o,a,w,g){const R=g.rng,base=w.dmg*lvlK(w);let n=0;
   const cx=src==="main"?0:o.x,cy=src==="main"?0:o.y;
   for(const e of enemies){if(e.hp<=0)continue;const d=Math.hypot(e.x-cx,e.y-cy),de=d;if(de>R+e.r*.5)continue;
     let q=Math.atan2(e.y-cy,e.x-cx)-a;while(q>Math.PI)q-=6.283;while(q<-Math.PI)q+=6.283;
     const cone=g.cone*STYLE13.spr+g.sgrow*de/100;if(d>14&&Math.abs(q)>cone)continue;
     dmg13(e,base*fall13(g.fo,de),src);e.burn=Math.max(e.burn,g.burn);n++;}
   for(let i=0;i<3;i++){const q=a+rnd(-.18,.18),s=rnd(200,260);p13({k:"flm",x:o.x,y:o.y,z:o.z,vx:Math.cos(q)*s,vy:Math.sin(q)*s,r:rnd(2.2,3.6),max:R/s*rnd(.85,1.05)});}
   return n;},
 rocket(src,o,a,w,g){const hs=src==="main"?huggers13(a,.7):[];if(hs.length){blast13(hs[0].x,hs[0].y,w,g,null,src);pbFx(hs[0],g.col);S13.pb++;return;}
   const sp=g.spd*(1+lvl(w)*.05),s=g.spread*STYLE13.spr,b=spawnBullet(o,a+rnd(-s,s),sp,w,src,g,{rk13:1});b.fx=(e)=>{blast13(b.x,b.y,w,g,e,src);b.boomed=1;};},
 laser(src,o,a,w,g){beam13(src,o,a,w,g,"#ff4a9a",2.2,.16);},
 sniper(src,o,a,w,g){beam13(src,o,a,w,g,"#ffffff",1.1,.12);if(src==="main")p13({k:"smk",x:o.x,y:o.y*KY-o.z,max:.6,r:3});}
};
function beam13(src,o,a,w,g,c,wd,life){const R=rayScreen(o.x,o.y,o.z,a,g.rng,o.zt,o.zd);let list=R.hits.slice(),endT=R.maxL;
 if(src==="main"){const hs=huggers13(a,.6);for(const e of hs)if(list.indexOf(e)<0)list.unshift(e);if(hs.length)S13.pb++;}
 let mul=1,n=0;for(let i=0;i<list.length&&n<g.maxN+Math.floor(lvl(w)/2);i++){const e=list[i];
   dmg13(e,w.dmg*lvlK(w)*mul,src);mul*=g.pm;n++;
   if(g.knock){knock13(e,g.knock,o.x,o.y);e.slowT=Math.max(e.slowT||0,g.stagger);goreAt(e.x,e.y,4,false);}else e.slowT=Math.max(e.slowT||0,.15);
   const ti=R.hits.indexOf(e);if(ti>=0){const tt=R.ts[ti];spark13(R.sx+R.dx*tt,R.sy+R.dy*tt,c,w.id);if(n>=g.maxN+Math.floor(lvl(w)/2))endT=tt+4;}}
 p13({k:"beam",x:R.sx,y:R.sy,x2:R.sx+R.dx*endT,y2:R.sy+R.dy*endT,c,wd,max:life});}
function blast13(x,y,w,g,skip,src){const Rb=g.blast*(1+lvl(w)*.1),base=w.dmg*lvlK(w)*.9;
 for(const e of enemies){if(e===skip||e.hp<=0)continue;const d=Math.hypot(e.x-x,e.y-y);if(d>Rb+e.r*.4)continue;const f=1-(1-g.bfo)*Math.min(1,d/Rb);
   dmg13(e,base*f,src);knock13(e,g.knock*(1-Math.min(1,d/Rb)),x,y);}
 fxp({k:"ring",x,y,r:Rb,c:"#ffb060",max:.22});p13({k:"boom",x,y:y*KY-4,r:Rb*.55,max:.32});
 for(let i=0;i<4;i++)blood.push({x:x+rnd(-14,14),y:y+rnd(-10,10),r:rnd(3,7),life:.6,a:1,rot:0,dot:1});
 shake=Math.min(11,shake+3.5);A13.play("boom",{x,g:.8});}
let SPIN13=0,STYLE13={spr:1,rate:1};
function fireGun13(x,y,ang,w,src){const g=G13[w.id];let o;if(src==="main"){S13.fired[w.id]=(S13.fired[w.id]||0)+1;if(AIM_T13){(S13.sd=S13.sd||[]).push([w.id,Math.round(Math.hypot(AIM_T13.x,AIM_T13.y)),t]);if(S13.sd.length>2000)S13.sd.shift();}}
 if(src==="main"){const M=muzzle13(ang),ai=aimInfo(src,M.x,M.y,ang,w);o={x:M.x,y:M.y,z:M.z,zt:ai.zt,zd:Math.max(ai.d-M.r0,20)};}
 else o={x,y,z:8,zt:TORSO,zd:60};
 if(src==="main"&&w.id!=="shotgun"&&w.id!=="rocket"&&w.id!=="fire"&&w.id!=="laser"&&w.id!=="sniper"){ // bullet guns: point-blank from the core
   const hs=huggers13(ang,.75);if(hs.length){const e=hs[0];dmg13(e,w.dmg*lvlK(w),src);pbFx(e,g.col);S13.pb++;S13.shots++;A13.shot(w.id,0,src);T890_RECOIL=.12;flash13(w.id,ang);return;}}
 FIRE13[w.id](src,o,ang,w,g);S13.shots++;
 if(src==="main"){T890_RECOIL=.12;flash13(w.id,ang);}
 A13.shot(w.id,src==="main"?0:x,src);}
function flash13(id,a){const M=muzzle13(a);const sz={basic:5,minigun:4,shotgun:9,fire:0,rocket:8,laser:4,sniper:10}[id]||5;if(!sz)return;
 p13({k:"mf",x:M.x,y:M.y*KY-M.z,a:Math.atan2(Math.sin(a)*KY,Math.cos(a)),r:sz,c:G13[id].col,max:.05});}
{const _s=shootFrom;shootFrom=function(x,y,ang,wep,src){
   if(wep&&G13[wep.id]){const n0=bullets.length;fireGun13(x,y,ang,wep,src);return;}
   const n0=bullets.length;const r=_s(x,y,ang,wep,src);for(let i=n0;i<bullets.length;i++)if(bullets[i].z==null)bullets[i].z=src==="main"?TORSO:8;return r;};}
// bullets: draw lifted by their height so the sprite IS the hitbox point
{const _db=drawBig;drawBig=function(b){const z=z13(b);ctx.save();ctx.translate(0,-z/KY);try{_db(b);}finally{ctx.restore();}};}
