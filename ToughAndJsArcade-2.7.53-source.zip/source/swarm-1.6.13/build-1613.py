#!/usr/bin/env python3
# Swarm 1.6.13 builder: exact-match patches on 1.6.12 + inner IIFE from src-1613/part*.js
import sys,hashlib,glob,os,re
D=os.path.dirname(os.path.abspath(__file__))
src=open(os.path.join(D,'backups/pre-1613-20261110-1913/swarm.html'),encoding='utf-8').read()
assert hashlib.sha256(src.encode()).hexdigest().startswith('2cadc174a0450fb7'),'base is not 1.6.12'
lines=src.split('\n')
def rep(old,new,count=1):
    global src
    n=src.count(old)
    assert n==count,(old[:80],n)
    src=src.replace(old,new)
def dropline(prefix):
    global src
    L=src.split('\n');k=[i for i,l in enumerate(L) if l.startswith(prefix)]
    assert len(k)==1,(prefix,len(k));del L[k[0]];src='\n'.join(L)
rep('const VERSION="1.6.12";','const VERSION="1.6.13";')
rep('if(hypot(b.x-e.x,b.y-e.y)<e.r+5){','if(window.bHit13?window.bHit13(b,e):hypot(b.x-e.x,b.y-e.y)<e.r+5){')
rep('e.hit=((e.wind*10)|0)%2?.1:0; // pull back + flash','// 1.6.13: no windup flash (flash always means damage) // pull back')
rep('Build anywhere, unlock 23 guns, survive.','Build anywhere, 7 guns, survive.')
rep('let LEARN_AI=false;try{LEARN_AI=localStorage.getItem("swarmLearnAI")==="1";}catch(e){}','let LEARN_AI=false;try{localStorage.removeItem("swarmLearnAI");}catch(e){}')
dropline('{const ov=$("startBtn")&&$("startBtn").parentNode;if(ov&&!$("learnChk")){')
rep('let CUSTOM=false;try{CUSTOM=localStorage.getItem("swarmCustom")==="1";}catch(e){}','let CUSTOM=false;try{localStorage.removeItem("swarmCustom");}catch(e){}')
dropline('{const ov=$("startBtn").parentNode,l=document.createElement("label");l.style.cssText="display:block;margin:6px 0;color:#cde;font:12px monospace;pointer-events:auto";l.innerHTML=\'<input type="checkbox" id="customChk">')
dropline('setTimeout(()=>{const a=$("learnChk"),b=$("customChk");')
rep('#tmodeBtn{top:calc(66px + env(safe-area-inset-top))!important;','#tmodeBtn{top:calc(104px + env(safe-area-inset-top))!important;')
# audio: the 1.6.13 engine (window.__A13) owns all sound; old engine stays as code but goes silent
rep('function gunSound(x,y,w,src,ang){','function gunSound(x,y,w,src,ang){if(window.__A13)return;')
rep('function ac(){if(AC)return AC;try{AC=new','function ac(){if(window.__A13)return null;if(AC)return AC;try{AC=new')
rep('function sfx(k,id){if(!audioOK()','function sfx(k,id){if(window.__A13){if(k!=="shot"&&k!=="hit"&&k!=="kill")window.__A13.sfx(k);return;}if(!audioOK()')
rep('setInterval(()=>{if(!AC||AC.state!=="running"||!running||!waveActive','setInterval(()=>{if(window.__A13)return;if(!AC||AC.state!=="running"||!running||!waveActive')
rep('  {const _u=update;update=function(dt){for(const e of enemies)e._beatHp=e.hp;_u(dt);if(enemies.some(e=>e.hp<e._beatHp))sfx("hit");};}\n','  // 1.6.13: burn/DoT hit-tick wrapper removed (grunts come from real bullet hits)\n')
rep("  ctx.restore();\n  // depth haze at the far edge","  if(window.__drawHug13)window.__drawHug13();\n  ctx.restore();\n  // depth haze at the far edge")
parts=sorted(glob.glob(os.path.join(D,'src-1613/part*.js')))
inner='\n'.join(open(p,encoding='utf-8').read() for p in parts)+'\n})();\n'
tail='})();\n</script>'
i=src.rfind(tail);assert i>0
src=src[:i]+'/* ===== 1.6.13: 7/7/7 kit, ammo + AMMO RACK, turret AI panel, hugger/hit fixes, audio engine ===== */\n'+inner+src[i:]
out=os.path.join(D,'swarm.html')
open(out,'w',encoding='utf-8').write(src)
print('wrote',out,len(src.encode()),hashlib.sha256(src.encode()).hexdigest())
