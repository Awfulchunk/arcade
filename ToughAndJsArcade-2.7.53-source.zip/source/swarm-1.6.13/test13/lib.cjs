const fs=require('fs'),puppeteer=require('/workspace/game/build-needle/gui/node_modules/puppeteer-core');
const D='/workspace/game/build-swarm/',OUT=D+'test13/';
function runtime(){fs.writeFileSync(OUT+'runtime.html',fs.readFileSync(D+'swarm.html','utf8').replace('/*__T13__*/','window.__EV13=c=>eval(c);').replace('console.log("Swarm: Last Stand"','window.__EV=c=>eval(c);'+fs.readFileSync(OUT+'helpers.js','utf8')+';console.log("Swarm: Last Stand"'));}
async function open(vw={width:360,height:800},opt={}){runtime();
 const browser=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--allow-file-access-from-files','--autoplay-policy=no-user-gesture-required']});
 const p=await browser.newPage(),errors=[],logs=[];p.on('pageerror',e=>errors.push(e.message+' '+(e.stack||'').split('\n').slice(0,3).join(' | ')));p.on('console',m=>{if(m.type()==='error')errors.push('console: '+m.text());logs.push(m.text());});
 await p.setViewport({...vw,deviceScaleFactor:2,isMobile:true,hasTouch:true});
 await p.goto('file://'+OUT+'runtime.html');await new Promise(r=>setTimeout(r,700));
 const E=c=>p.evaluate(c=>__EV13(c),c);
 return {browser,p,errors,logs,E,sleep:ms=>new Promise(r=>setTimeout(r,ms))};}
module.exports={open,OUT,D,fs};
