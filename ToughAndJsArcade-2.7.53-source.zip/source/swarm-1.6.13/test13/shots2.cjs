const {open,OUT}=require('./lib.cjs');
(async()=>{const T=await open({width:360,height:800});const {p,E,errors,sleep}=T;
 await p.click('#startBtn');await sleep(400);
 // AMMO RACK: placed between waves, DEFENSE tab
 await E(`(()=>{H13.scene({guns:["minigun","rocket","laser"]});enemies.length=0;between=true;waveActive=false;credits=2000;for(const q of [[70,30],[-75,35]]){placeMode="ammorack";tryPlaceSlot(q[0],q[1]);}tab="DEFENSE";buildShop();hud();return 1})()`);
 await sleep(600);await p.screenshot({path:OUT+'shots/ammo-rack-shop.png'});
 // WEAPONS tab between waves: AMMO buy chip
 await E(`(()=>{tab="WEAPONS";buildShop();return 1})()`);await sleep(300);await p.screenshot({path:OUT+'shots/ammo-shop-chip.png'});
 // in wave: rack refill ticks + ammo HUD on the turret + chip mag/res
 await E(`(()=>{between=false;waveActive=true;running=true;SWARM_SET.controls.aim="auto";activeW=WEAPONS.findIndex(w=>w.id==="rocket");am("rocket").mag=1;for(let i=0;i<12;i++)H13.z(-90+i*16,-200-(i%3)*15,{sp:8,hp:300});buildShop();return 1})()`);
 await sleep(1900);await p.screenshot({path:OUT+'shots/ammo-hud-reload-and-rack.png'});
 const clip=await E('(()=>{const r=cv.getBoundingClientRect();return {x:Math.max(0,r.left+CX-140),y:r.top+TY-90,width:280,height:150}})()');
 await p.screenshot({path:OUT+'shots/ammo-hud-closeup.png',clip});
 console.log(errors);await T.browser.close();})();
