// audio: timing (no grid, same frame), voice cap stress 180 zombies >=120 s real time, quiet master/no clip, no burn ticks, groan sparsity, moan streak
const {open,OUT,fs}=require('./lib.cjs');
const STRESS_SEC=+(process.env.STRESS_SEC||125);
(async()=>{const T=await open();const {p,E,errors,sleep}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await p.click('#startBtn');await sleep(400);
 const st=await E('(()=>{const c=__A13.ctx();return c?c.state:"none"})()');
 ok('context_running',st==="running",{state:st});
 // 1) timing: each gun fires in real time, compare scheduled start vs now and vs the frame that draws it
 await E(`SWARM_SET.controls.aim="auto";for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e9;Object.assign(__ai13.cfg,{switch:10,panic:0});for(const id of __am13.owned())am(id).res=1e5;1`);
 const per={};
 for(const g of ["basic","minigun","shotgun","fire","rocket","laser","sniper"]){
  await E(`(()=>{activeW=WEAPONS.findIndex(w=>w.id==="${g}");__A13.ST.events.length=0;enemies.length=0;for(let i=0;i<12;i++)H13.z(-60+i*10,-${g==="fire"||g==="shotgun"?90:180},{sp:0,hp:1e7});return 1})()`);
  await sleep(2500);
  per[g]=await E(`(()=>{const ev=__A13.ST.events.filter(e=>e.drawT);const sd=ev.map(e=>(e.sched-e.acNow)*1000),fg=ev.map(e=>e.drawT-e.callT).sort((a,b)=>a-b);
    return {n:ev.length,names:[...new Set(ev.map(e=>e.n))],maxSchedDelayMs:+Math.max(0,...sd).toFixed(2),p95FrameGapMs:+(fg[Math.floor(fg.length*.95)]||0).toFixed(2),maxFrameGapMs:+(fg[fg.length-1]||0).toFixed(2),outLatMs:+((ev[0]&&ev[0].lat||0)*1000).toFixed(1)}})()`);}
 const old=await E('__audio1612.stats().shots');
 ok('timing_under_20ms',Object.values(per).every(x=>x.maxSchedDelayMs<1&&x.p95FrameGapMs<20)&&Object.entries(per).filter(([g])=>g!=="fire").every(([g,x])=>x.n>0),{per,oldGridEngineShots:old,note:"sound starts at AudioContext.currentTime (no 125 ms grid); frameGap = sound call → the draw that shows the shot"});
 // 2) burn alone makes no hit sound
 const burn=await E(`(()=>{enemies.length=0;bullets.length=0;Object.assign(__ai13.cfg,{range:50});const e=H13.z(0,-400,{sp:0,hp:1e7});e.burn=30;const g0=__A13.ST.grunts;H13.run(5);const g1=__A13.ST.grunts;Object.assign(__ai13.cfg,__ai13.DEF13);return {grunts:g1-g0,hpLost:Math.round(1e7-e.hp)}})()`);
 ok('no_hit_ticks_from_burn',burn.grunts===0&&burn.hpLost>0,burn);
 // 3) moan streak stacks
 const mo=await E(`(()=>{__A13.ST.streak=0;const L=[];for(let i=0;i<6;i++)L.push(H13.z(i*5,-200,{sp:0,hp:1}));for(const e of L){const i=enemies.indexOf(e);if(i>=0)killEnemy(e,i);}return {streak:__A13.ST.streak,moans:__A13.ST.moans}})()`);
 ok('death_moans_stack',mo.streak>=4,mo);
 // 4) stress: 180 live zombies, auto AI cycling guns, real time
 for(let k=0;k<40;k++){const bt=await E('(()=>{if(between){startWave();}return between})()');if(!bt)break;await sleep(250);}
 await E(`(()=>{toSpawn=0;Object.assign(__ai13.cfg,{switch:3,panic:40,style:8});__A13.ST.gunDropped=0;__A13.ST.peakVoices=0;__A13.ST.stolen=0;__A13.ST.shots=0;__A13.ST.groans=0;window.__fps=[];let last=performance.now();(function f(){const n=performance.now();window.__fps.push(n-last);last=n;if(window.__fps.length<1e5)requestAnimationFrame(f);})();
   window.__top=setInterval(()=>{let k=0;while(enemies.length<180&&k++<60){const a=Math.random()*6.283,r=260+Math.random()*120;H13.z(Math.cos(a)*r,Math.sin(a)*r*.8,{hp:120,sp:30});}for(const id of __am13.owned())if(am(id).res<50)am(id).res=500;},400);
   window.__pk=0;window.__pkI=setInterval(()=>{const an=__A13.an();if(!an)return;const b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let ss=0;for(const x of b){window.__pk=Math.max(window.__pk,Math.abs(x));ss+=x*x;}const rms=Math.sqrt(ss/b.length);window.__rms=(window.__rms||[]);window.__rms.push(rms);},100);return 1})()`);
 const samples=[];for(let s=0;s<STRESS_SEC;s+=5){await sleep(5000);samples.push(await E(`({t:${s+5},n:enemies.length,voices:__A13.voices(),peak:__A13.ST.peakVoices,shots:__A13.ST.shots,gunDropped:__A13.ST.gunDropped,stolen:__A13.ST.stolen,groans:__A13.ST.groans,pk:+window.__pk.toFixed(3)})`));}
 const fin=await E(`(()=>{clearInterval(window.__top);clearInterval(window.__pkI);const f=window.__fps.slice(30).sort((a,b)=>a-b);return {frames:f.length,p50:+f[Math.floor(f.length*.5)].toFixed(1),p95:+f[Math.floor(f.length*.95)].toFixed(1),cap:__A13.CAP,fired:__S13.fired,ST:{peakVoices:__A13.ST.peakVoices,shots:__A13.ST.shots,gunDropped:__A13.ST.gunDropped,dropped:__A13.ST.dropped,stolen:__A13.ST.stolen,groans:__A13.ST.groans,grunts:__A13.ST.grunts,moans:__A13.ST.moans},peakAbs:+window.__pk.toFixed(3),rmsAvgDb:+(20*Math.log10((window.__rms||[1e-9]).reduce((a,b)=>a+b,0)/((window.__rms||[1]).length)||1e-9)).toFixed(1),rmsMaxDb:+(20*Math.log10(Math.max(1e-9,...(window.__rms||[0])))).toFixed(1),master:SWARM_SET.audio.master}})()`);
 const minN=Math.min(...samples.slice(1).map(s=>s.n));
 ok('voice_cap_stress',fin.ST.shots>300&&fin.ST.peakVoices<=fin.cap&&fin.ST.gunDropped===0&&STRESS_SEC>=120&&minN>=150,{seconds:STRESS_SEC,minLiveZombies:minN,fin});
 ok('mix_peak_rms',fin.peakAbs<0.9&&fin.rmsMaxDb<-6&&fin.rmsAvgDb<-14,{peakAbs:fin.peakAbs,peakDbFS:+(20*Math.log10(fin.peakAbs)).toFixed(1),rmsAvgDb:fin.rmsAvgDb,rmsMaxDb:fin.rmsMaxDb,targets:'peak < -0.9 dBFS (no clip), RMS max < -6 dBFS, RMS avg < -14 dBFS',master:fin.master});
 ok('groans_sparse',fin.ST.groans>0&&fin.ST.groans/(STRESS_SEC/60)<=25,{groansPerMin:+(fin.ST.groans/(STRESS_SEC/60)).toFixed(1)});
 R.samples=samples;ok('zero_js_errors',errors.length===0,errors.slice(0,5));
 const pass=Object.values(R).filter(x=>x&&x.pass).length,tot=Object.values(R).filter(x=>x&&x.pass!=null).length;R.summary=pass+"/"+tot;
 fs.writeFileSync(OUT+'t-audio.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1).slice(0,5000));await T.browser.close();})();
