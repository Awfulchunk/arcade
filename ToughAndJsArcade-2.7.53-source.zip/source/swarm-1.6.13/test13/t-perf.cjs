// A03s-style sanity: 4x CPU throttle, 360x800 @DPR2, 150 live zombies, auto AI, 20 s real time; same scene on 1.6.12 vs 1.6.13
const fs=require('fs'),puppeteer=require('/workspace/game/build-needle/gui/node_modules/puppeteer-core');
const D='/workspace/game/build-swarm/';
async function run(file,label){const html=fs.readFileSync(file,'utf8').replace('console.log("Swarm: Last Stand"','window.__EV=c=>eval(c);console.log("Swarm: Last Stand"');fs.writeFileSync(D+'test13/perf-'+label+'.html',html);
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--allow-file-access-from-files','--autoplay-policy=no-user-gesture-required']});
 const p=await b.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});
 await p.goto('file://'+D+'test13/perf-'+label+'.html');await new Promise(r=>setTimeout(r,700));await p.click('#startBtn');await new Promise(r=>setTimeout(r,300));
 const cdp=await p.target().createCDPSession();await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
 await p.evaluate(()=>__EV(`SWARM_SET.controls.aim="auto";if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e9;wave=8;
   window.__top=setInterval(()=>{let k=0;while(enemies.length<150&&k++<40){spawnOne();}},300);window.__fr=[];let l=performance.now();(function f(){const n=performance.now();__fr.push(n-l);l=n;requestAnimationFrame(f);})();1`));
 await new Promise(r=>setTimeout(r,20000));
 const res=await p.evaluate(()=>__EV(`(()=>{const f=__fr.slice(60).sort((a,b)=>a-b);const sum=f.reduce((a,b)=>a+b,0);return {frames:f.length,avgFps:+(1000*f.length/sum).toFixed(1),p50:+f[f.length>>1].toFixed(1),p95:+f[Math.floor(f.length*.95)].toFixed(1),p99:+f[Math.floor(f.length*.99)].toFixed(1),live:enemies.length,bullets:bullets.length}})()`));
 res.errors=errors.length;await b.close();return res;}
(async()=>{const out={old_1612:await run(D+'backups/pre-1613-20261110-1913/swarm.html','1612'),new_1613:await run(D+'swarm.html','1613')};
 out.pass=out.new_1613.errors===0&&out.new_1613.avgFps>=out.old_1612.avgFps*0.85;fs.writeFileSync(D+'test13/t-perf.json',JSON.stringify(out,null,1));console.log(JSON.stringify(out,null,1));})();
