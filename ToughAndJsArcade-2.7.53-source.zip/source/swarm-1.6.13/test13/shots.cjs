const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const T=await open({width:360,height:800});const {p,E,errors,sleep}=T;
 await p.click('#startBtn');await sleep(400);
 await E(`SWARM_SET.controls.aim="auto";if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e9;Object.assign(__ai13.cfg,{switch:10,panic:0});for(const id of __am13.owned())am(id).res=1e5;1`);
 // huggers getting killed (point-blank, drawn in front of the turret)
 for(const g of ["minigun","shotgun","fire"]){
  await E(`(()=>{H13.scene({guns:["minigun","shotgun","fire","rocket","laser","sniper"],cfg:{switch:10,panic:0},gun:"${g}"});hp=maxHp=1e9;for(const id of __am13.owned())am(id).res=1e5;for(let i=0;i<14;i++){const a=i/14*6.283;H13.z(Math.cos(a)*22,Math.sin(a)*22,{hp:${g==="shotgun"?60:35},sp:25,keep:1});}for(let i=0;i<10;i++)H13.z(-80+i*18,-140-(i%2)*20,{sp:25});return 1})()`);
  for(const ms of [400,1500,3000]){await sleep(ms===400?400:ms===1500?1100:1500);await p.screenshot({path:OUT+`shots/huggers-${g}-${ms}.png`,clip:await E('(()=>{const r=cv.getBoundingClientRect();return {x:Math.max(0,r.left+CX-110),y:r.top+TY-150,width:220,height:200}})()')});}
 }
 // each gun firing at mid range
 for(const g of ["basic","minigun","shotgun","fire","rocket","laser","sniper"]){
  await E(`(()=>{H13.scene({guns:["minigun","shotgun","fire","rocket","laser","sniper"],cfg:{switch:10,panic:0},gun:"${g}"});hp=maxHp=1e9;for(const id of __am13.owned())am(id).res=1e5;const R=${'{basic:200,minigun:220,shotgun:110,fire:100,rocket:230,laser:260,sniper:300}'}["${g}"];for(let i=0;i<10;i++)H13.z(-70+i*16+(i%2)*6,-R+(i%3)*14,{sp:6,hp:${g==="sniper"?400:150}});return 1})()`);
  await sleep(g==="sniper"||g==="rocket"?1500:900);
  for(let k=0;k<6;k++){const fresh=await E(`(()=>{const P=eval("P13");return P.some(f=>f.k==="mf"&&f.t<.03)||bullets.length>0})()`);if(fresh)break;await sleep(60);}
  await p.screenshot({path:OUT+`shots/gun-${g}.png`});
 }
 console.log(errors);await T.browser.close();})();
