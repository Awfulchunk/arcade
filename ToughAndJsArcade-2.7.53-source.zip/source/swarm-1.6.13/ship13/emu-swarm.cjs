// WebView 83 emulator: launch Swarm (default = 1.6.13, legacy variant auto-picked), start, auto AI, open panel (slow-mo), tag, all 7 guns fire, rack + ammo, 0 JS errors. Then Swarm v1.6.12 still launches.
const connect=require('/workspace/game/build-latch/fix/cdp.cjs');const {execSync}=require('child_process');const fs=require('fs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));const OUT=__dirname+'/emu/';const ADB='/workspace/tools/sdk/platform-tools/adb';
const shot=n=>execSync(`${ADB} exec-out screencap -p > ${OUT}${n}.png`);
(async()=>{let c=await connect(9333);const R={};
 await c.ev(`(()=>{try{localStorage.removeItem('arcade.legacy')}catch(e){};location.reload();return 1})()`).catch(()=>{});c.close();await sleep(4000);
 for(let i=0;i<30;i++){try{c=await connect(9333);if(await c.ev("typeof ARCADE==='object'"))break;c.close();}catch(e){}await sleep(2000);}
 await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";v=v.split('/*__T13__*/').join('window.__EV13=c=>eval(c);').split('ctx.restore()}})()})();').join('ctx.restore()}window.__EV13=c=>eval(c);})()})();');v=/<head[^>]*>/i.test(v)?v.replace(/<head[^>]*>/i,m=>m+inj):inj+v;d.set.call(this,v);},get(){return d.get.call(this);}});return 1})()`);
 R.shell=JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:navigator.userAgent.match(/Chrome\\/[0-9.]+/)[0],swarmVersions:ARCADE.GAMES.find(g=>g.id==='swarm').versions.slice(-3).map(v=>v.id+(v.def?'*':''))})`));
 const launch=async(ver)=>{if(await c.ev("ARCADE.inGame")){await c.ev("ARCADE.back(),1");await sleep(1500);}const n0=c.ctx.length;
   await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='swarm');${ver?`ARCADE.launch(i,'${ver}')`:'ARCADE.launchCard(i)'};const e=document.getElementById('game');e.style.top='0';e.style.left='0';e.style.width='100%';e.style.height='100%';return 1})()`);
   await sleep(8000);return c.ctx.slice(n0).filter(x=>x.auxData&&x.auxData.isDefault).pop();};
 const cx=await launch(null);if(!cx){R.error='no swarm context';console.log(JSON.stringify(R));process.exit(1);}
 const E=async(js)=>c.ev('__EV13('+JSON.stringify(js)+')',cx.id);
 R.hook=await c.ev("typeof __EV13",cx.id);R.boot=JSON.parse(await E(`JSON.stringify({ver:typeof VERSION!=='undefined'?VERSION:(window.__S13&&__S13.ver),errs:window.__errs,legacyPrelude:typeof window.__tjGap,panel:!!window.__panel13,a13:!!window.__A13,title:document.querySelector('.sub')&&document.querySelector('.sub').innerText.slice(-60),custom:!!document.getElementById('customChk')})`));
 shot('01-title');
 await E(`(()=>{document.getElementById('startBtn').click();return 1})()`);await sleep(1500);
 await E(`(()=>{SWARM_SET.controls.aim='auto';if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;return 1})()`);
 await sleep(4000);shot('02-wave-auto');
 R.fps=await E(`new Promise(r=>{let n=0;const t0=performance.now();const f=()=>{n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n*1000/(performance.now()-t0)).toFixed(1))};requestAnimationFrame(f)})`);
 // panel + slow-mo (measure game clock t vs wall)
 const rate=async()=>{const a=JSON.parse(await E(`JSON.stringify([t,performance.now()])`));await sleep(4000);const b=JSON.parse(await E(`JSON.stringify([t,performance.now()])`));return (b[0]-a[0])/((b[1]-a[1])/1000);};
 const r0=await rate();await E(`__panel13.open(true),1`);await sleep(400);shot('03-panel-open');const r1=await rate();await E(`__panel13.open(false),1`);
 R.slowmo={closed:+r0.toFixed(3),open:+r1.toFixed(3),ratio:+(r1/r0).toFixed(3)};
 // every gun fires (AI switch OFF, force each gun for 2.5 s)
 R.guns={};R.gunDbg={};for(const g of ['basic','minigun','shotgun','fire','rocket','laser','sniper']){await E(`(()=>{if(between){between=false;}__ai13.set('switch',10);__ai13.set('panic',0);activeW=WEAPONS.findIndex(w=>w.id==='${g}');const a=am('${g}');if(a&&a.res!=null){a.res=Math.max(a.res,999);}for(let i=0;i<6;i++){__SW.force('tiny');const e=enemies[enemies.length-1];e.x=-90+i*36;e.y=-140-(i%2)*30;e.hp=e.max=400;}__S13.fired={};return 1})()`);await sleep(8000);R.gunDbg[g]=JSON.parse(await E(`JSON.stringify({running,between,waveActive,aw:WEAPONS[activeW].id,n:enemies.length,am:am('${g}'),fired:__S13.fired})`));R.guns[g]=R.gunDbg[g].fired[g]||0;if(g==='fire'||g==='laser'||g==='minigun')shot('04-gun-'+g);}
 R.after=JSON.parse(await E(`JSON.stringify({errs:window.__errs,hp:Math.round(hp),wave,kills,huggers:__S13.huggers,pb:__S13.pb,ammo:__am13.get('rocket')})`));
 await E(`(()=>{const P=__ai13.PRESET13.bal;for(const k in P)__ai13.set(k,P[k]);return 1})()`);
 // Swarm 1.6.12 still launches from the version picker
 R.v1612='skipped';try{const cx2=await launch('v1612');if(cx2){R.v1612=JSON.parse(await c.ev(`JSON.stringify({ver:window.__SW&&__SW.st().ver,errs:window.__errs})`,cx2.id));await c.ev(`(()=>{document.getElementById('startBtn').click();return 1})()`,cx2.id).catch(()=>{});await sleep(9000);R.v1612.fpsInWave=await c.ev(`new Promise(r=>{let n=0;const t0=performance.now();const f=()=>{n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n*1000/(performance.now()-t0)).toFixed(1))};requestAnimationFrame(f)})`,cx2.id);shot('05-swarm-v1612');}}catch(e){R.v1612='ERR '+e.message.slice(0,120);}
 if(await c.ev("ARCADE.inGame"))await c.ev("ARCADE.back(),1");
 R.pass=R.boot.ver==='1.6.13'&&(!R.boot.errs||R.boot.errs.length===0)&&(!R.after.errs||R.after.errs.length===0)&&Math.abs(R.slowmo.ratio-.5)<.1&&Object.entries(R.guns).every(([g,n])=>n>0);
 fs.writeFileSync(OUT+'emu-swarm.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1));c.close();process.exit(0);
})().catch(e=>{console.error('ERR',e.message.slice(0,400));process.exit(1);});
