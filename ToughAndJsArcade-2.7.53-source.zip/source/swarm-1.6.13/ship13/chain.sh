set -e
# 2.7.53 chain: build Swarm 1.6.13 -> assemble on LIVE 2.7.52 -> APK (code 91) -> verify. Never publishes.
H=/workspace/game/build-swarm; S=$H/ship13; E=$S/evidence; mkdir -p $E
python3 $H/build-1613.py > $E/build-1613.txt
P=/workspace/game/build-needle/package-2.7.53
(cd /workspace/game/build-latch/fix && node $S/assemble-2753.mjs $P/tough-and-js-arcade.html > $E/assemble-2753.txt)
cp $P/assembly-verification.json $E/
rm -f $P/out/ToughAndJsArcade-2.7.53.apk $P/out/ToughAndJsArcade-2.7.53.apk.idsig
(cd $P && ./build-apk.sh > $E/build-apk.txt 2>&1)
PATH=/workspace/tools/jdk/bin:$PATH node $S/verify-2753.cjs > $E/verify-2753.txt || { echo VERIFY-FAILED; exit 1; }
sha256sum $P/out/ToughAndJsArcade-2.7.53.apk $P/tough-and-js-arcade.html $H/swarm.html
echo BUILD-DONE
