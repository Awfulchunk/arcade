# Tough & J's Arcade 2.7.69 (versionCode 107) — source (GPL-3.0)

2.7.69 is cumulative over 2.7.68 (everything else unchanged):
- Pixel War 0.4.6 is now `pixelwar:latest` (default). Pixel War 0.4.5 is kept as `pixelwar:v045`, 0.4.4 as `v044`, 0.4.3 as `v043`, 0.4.2 as `v042`, 0.4.1 as `v041`, 0.3 as `v03`. Source: source/pixel-war/.
- Unchanged from 2.7.68 otherwise: Papa Potato 0.4.1, Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
