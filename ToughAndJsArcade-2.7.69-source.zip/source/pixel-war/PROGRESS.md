# Pixel War 0.4.6

Copied from 0.4.5. Jay t1152–t1153.

- Slider panel is scroll-safe: a vertical drag scrolls the panel and never moves a slider. Only a mostly horizontal drag that starts on the track/thumb (past a 12px direction-lock) changes the value. A short tap on the track still sets it. touch-action: pan-y. The +/- buttons still work (FLOW +/- steps by 10).
- FLOW slider is 200–1000 on-field pixels (was 1–10 mapping to 200–400). Default stays 289. Per-side cap raised to 1000. Old 1–10 saves map through the old formula (5 → 289).
- Pace +14.8% (paceMax 27 → 31). Speed 1/5/10 = 7.75 / 18.08 / 31 u/s.
- Density and spacing are one Density slider: higher = tighter spacing and more packed. Old saves: density' = round((2*density + (11-spacing))/3), so (5,5) stays 5. Spacing row is hidden, not deleted.
- VFX: pool 1800→2800, bounce list 400→800, per-tick spawn budget and spark bit count scale down as the field grows past the old 800-pixel total, so cost stays near A03s.
- Saves: pixelwar.v46* (falls back from v45, then v44, then v43). DELETE AI MEMORY clears v46–v43.

Lint + 3s headless load (0 JS errors) + apksigner + verify-2769. No suites. No phone tests.
