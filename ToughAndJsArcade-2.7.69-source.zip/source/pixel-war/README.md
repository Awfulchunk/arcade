# Pixel War 0.4.6 source (Tough & J's Arcade 2.7.69) — GPL-3.0
- game/pixel-war-0.4.6.html: the whole game is this one file (no build step). Scroll-safe sliders, FLOW up to 1000 (default still 289), slightly quicker pace, and a single Density slider (higher = tighter / more packed). Save keys `pixelwar.v46*` (prefs/forms/custom/AI memory fall back from v45/v44/v43). Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.5.html: kept as `pixelwar:v045`; 0.4.4 as `v044`; 0.4.3 as `v043`; 0.4.2 as `v042`; 0.4.1 as `v041`; 0.3 as `v03`.
- arcade-2.7.69/: assemble-2769.mjs and verify-2769.cjs (checks the signed APK against 2.7.68).
- tests/ were not re-run for 0.4.6. No signing keys and no Latch code are included.
