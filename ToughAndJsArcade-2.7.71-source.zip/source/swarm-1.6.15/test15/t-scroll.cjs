// 1.6.15 scroll-safe panel: vertical drags (on track, on +/-, on box) scroll and never change values; horizontal on-track drag adjusts; tap on track sets; +/- tap works
const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const ALL={};
for(const vw of [{width:360,height:800},{width:320,height:568}]){const tag=vw.width+'x'+vw.height;
 const T=await open(vw);const {p,E,errors,sleep}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await E('localStorage.removeItem("swarm.ai13");1');
 await p.click('#startBtn');await sleep(300);
 await E(`SWARM_SET.controls.aim="auto";if(window.__mainControls)__mainControls();hp=maxHp=1e6;1`);await sleep(800);
 const tur=await E('(()=>{const r=cv.getBoundingClientRect();return {x:r.left+CX,y:r.top+TY-10*depthK(0)*VS}})()');
 await p.touchscreen.tap(tur.x,tur.y);await sleep(300);ok('panel_open',await E('__panel13.isOpen()'),tur);
 const cfg=()=>E('JSON.stringify(__ai13.cfg)');
 const L=await E(`(()=>{const l=document.querySelector("#ai13 .list");return {sh:l.scrollHeight,ch:l.clientHeight}})()`);
 ok('list_scrollable',L.sh>L.ch+4,L);
 const cs=await p.createCDPSession();
 const drag=async(x0,y0,x1,y1,steps=12)=>{await cs.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:x0,y:y0}]});
   for(let i=1;i<=steps;i++){await cs.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x0+(x1-x0)*i/steps,y:y0+(y1-y0)*i/steps}]});await sleep(16);}
   await cs.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(250);};
 const where=sel=>E(`(()=>{const l=document.querySelector("#ai13 .list");const bs=[...document.querySelectorAll("#ai13 .box")];const lr=l.getBoundingClientRect();
   const b=bs.find(b=>{const r=b.getBoundingClientRect();return r.top>=lr.top&&r.bottom<=lr.bottom});if(!b)return null;const e=b.querySelector(${JSON.stringify(sel)}),r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2,st:l.scrollTop,id:b.dataset.id}})()`);
 const scrollTop=()=>E('document.querySelector("#ai13 .list").scrollTop');
 // vertical swipes from track / + / − / name, both up and down
 for(const [sel,nm] of [[".trk","track"],[".pm","plus"],['.pm[data-d="-1"]',"minus"],[".nm","name"]]){
   await E('document.querySelector("#ai13 .list").scrollTop=0;1');await sleep(100);
   let w=await where(sel);const c0=await cfg();await drag(w.x,w.y,w.x+6,w.y-110);const s1=await scrollTop();const c1=await cfg();
   w=await where(sel);await drag(w.x,w.y,w.x-6,w.y+110);const s2=await scrollTop();const c2=await cfg();
   ok('vertical_'+nm+'_scrolls_no_change',s1>20&&s2<s1&&c0===c1&&c1===c2,{s1,s2,changed:c0!==c1||c1!==c2});}
 // diagonal-ish vertical (dx 40, dy 90) on track: still scroll, no change
 await E('document.querySelector("#ai13 .list").scrollTop=0;1');let w=await where('.trk');let c0=await cfg();await drag(w.x,w.y,w.x+40,w.y-90);
 ok('diagonal_on_track_no_change',c0===await cfg(),{});
 // horizontal drag on track adjusts
 await E('document.querySelector("#ai13 .list").scrollTop=0;1');w=await where('.trk');
 const tr=await E(`(()=>{const b=document.querySelector('#ai13 .box[data-id="${w.id}"] .trk').getBoundingClientRect();return {l:b.left,r:b.right,y:b.top+b.height/2}})()`);
 c0=await E(`__ai13.cfg["${w.id}"]`);await drag(tr.l+8,tr.y,tr.r-8,tr.y+3);const c1=await E(`__ai13.cfg["${w.id}"]`);await drag(tr.r-8,tr.y,tr.l+8,tr.y-3);const c2=await E(`__ai13.cfg["${w.id}"]`);
 ok('horizontal_track_drag_adjusts',c1!==c0&&c2!==c1,{id:w.id,c0,c1,c2});
 // horizontal drag NOT starting on track (on name) does not adjust
 w=await where('.nm');c0=await cfg();await drag(w.x,w.y,w.x+120,w.y);ok('horizontal_off_track_no_change',c0===await cfg(),{});
 // tap on track sets
 w=await where('.trk');const id=w.id;const tr2=await E(`(()=>{const b=document.querySelector('#ai13 .box[data-id="${id}"] .trk').getBoundingClientRect();return {l:b.left,r:b.right,y:b.top+b.height/2}})()`);
 const t0=await E(`__ai13.cfg["${id}"]`);await p.touchscreen.tap(tr2.l+3,tr2.y);await sleep(150);const t1=await E(`__ai13.cfg["${id}"]`);await p.touchscreen.tap(tr2.r-3,tr2.y);await sleep(150);const t2=await E(`__ai13.cfg["${id}"]`);
 ok('tap_track_sets',t1!==t2,{id,t0,t1,t2});
 // +/- taps still work
 w=await where('.pm');const pid=w.id;const v0=await E(`__ai13.cfg["${pid}"]`);
 const pm=await E(`(()=>[...document.querySelectorAll('#ai13 .box[data-id="${pid}"] .pm')].map(x=>{const r=x.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2}}))()`);
 await p.touchscreen.tap(pm[1].x,pm[1].y);await sleep(150);const v1=await E(`__ai13.cfg["${pid}"]`);await p.touchscreen.tap(pm[0].x,pm[0].y);await sleep(150);const v2=await E(`__ai13.cfg["${pid}"]`);
 ok('plus_minus_tap_work',v1!==v0||v2!==v1,{pid,v0,v1,v2});
 // 20 random vertical flings: no value change
 c0=await cfg();let ch=0;for(let i=0;i<20;i++){await E('document.querySelector("#ai13 .list").scrollTop='+(i%2?0:999)+';1');const ww=await where(['.trk','.pm','.nm','.val'][i%4]);if(!ww)continue;const dy=(i%2?-1:1)*(40+i*7);await drag(ww.x,ww.y,ww.x+((i*13)%25-12),ww.y+dy,8);if(await cfg()!==c0){ch++;c0=await cfg();}}
 ok('random_vertical_flings_no_change',ch===0,{changes:ch});
 await p.screenshot({path:OUT+`shots/scroll-panel-${tag}.png`});
 ok('zero_js_errors',errors.length===0,errors.slice(0,5));
 ALL[tag]=R;await T.browser.close();}
let pass=0,tot=0;for(const v in ALL)for(const k in ALL[v]){tot++;if(ALL[v][k].pass)pass++;}ALL.summary=pass+"/"+tot;
fs.writeFileSync(OUT+'t-scroll.json',JSON.stringify(ALL,null,1));console.log(JSON.stringify(ALL,null,1));})();
