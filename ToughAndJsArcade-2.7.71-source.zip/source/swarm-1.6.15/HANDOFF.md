# Swarm 1.6.15: TEST build (not shipped)

**Not signed. Not in an APK. Not published.** This build waits for Jay to say ship.
- Base: live 1.6.14 (Arcade 2.7.70 `swarm-last-stand.html`, sha 9c3be799…).
- The zombie look, the 7 guns, audio and panel visuals are unchanged.
- Save keys are unchanged.
- Full diff: `source/diff-1.6.14-to-1.6.15.diff`.

## Changes
- **Scroll-safe turret panel** (Jay t1015). It uses the same direction lock as Pixel War 0.4.6:
  - A vertical drag scrolls the command list and never moves a slider. That holds whether the drag starts on the track, on +/-, or on the box.
  - Only a mostly-horizontal drag that starts on the track adjusts the value (12 px lock, ratio 1.15).
  - A short tap on the track still sets the value.
  - +/- always work, and a scroll never counts as a +/- tap.
  - The note had planned tap-to-unlock. The direction lock was used instead, as directed.
- **Blocked storage** (private mode): the game now runs on an in-memory store instead of showing a blank screen. This bug was already in 1.6.14.
- **Tap targets**: the HOLD THE LINE and SETTINGS buttons are now at least 44 px tall.
- **Tool opt-outs**: the menu overlay and the canvas are marked as intended overlaps for tough-tools. The HUD sits over the field by design.

## Note audit (t987–t994, t1004)
Everything is already in 1.6.13/1.6.14:
- the 7/7/7 kit with the rest hidden
- AMMO + AMMO RACK
- tapping the turret opens the panel, with 0.5× slow-mo
- the 7 rule boxes
- fixes for huggers and hitboxes
- chiptune SFX and the beat
- the range, panic and tag visuals

The only missing item was the scroll fix.

## Tests
| Suite | Result |
|---|---|
| t-scroll (new, 360×800 + 320×568) | **26/26** (1.6.14 fails 16/26, so the bug is reproduced) |
| t-panel / t-rules / t-combat / t-visuals / t-audio | 24/24 · 14/14 · 4/4 · 18/18 · 9/9 |
| tough-tools `test --all` (one run) | 5 FAIL. The same 5 fail on the 1.6.14 baseline. |
| after fixes, re-ran visual+buff | 0 FAIL, 0 warn (soak-frames not re-run, see below) |

The remaining tough-tools item:
- `stress/soak-frames @6x` fails because the idle menu has no render loop. This is by design; 4× soak with play started ran at 59 fps.
- The WebView 83 warning (`??=` etc.) also appears on 1.6.14, which passed the WV83 emulator.

## Gaps
- Not tested on a phone or the WV83 emulator. That happens at the ship step.
