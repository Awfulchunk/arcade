# Swarm 1.6.15 — PROGRESS
Build dir: /workspace/game/build-swarm1615 (copy of live 1.6.14, sha 9c3be799…, base kept as swarm-v1.6.14.base.html). Not shipped / signed / published.
- [Nov 18 PT] Scroll-safe turret panel (direction lock from Pixel War 0.4.6): vertical drag scrolls, horizontal on-track drag adjusts, tap on track sets, +/- always work, a scroll never counts as a +/- tap.
- Note audit t987–t994 + t1004: all in 1.6.13/1.6.14 already; nothing missing beyond the scroll fix.
- tt --all (one run): 5 FAIL, identical on 1.6.14 baseline. Fixed: storage-blocked shim (in-memory store), tap targets 44px, overlay/canvas marked allowed-overlap. soak-frames@6x = idle menu has no rAF loop (by design, false positive). Re-ran visual+buff: 0 FAIL, 0 warn.
- test15: t-scroll 26/26 (1.6.14 fails 16/26), t-panel 24/24, t-rules 14/14, t-combat 4/4, t-visuals 18/18, t-audio 9/9 (before the last small fixes).
- [4:38 PM PT] Resumed after interrupt: final regression rerun of test15 suites, then stage finished-ship/swarm-1.6.15-test/.
- [4:53 PM PT] Final suites all green; staged to finished-ship/swarm-1.6.15-test/.
