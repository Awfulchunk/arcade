# Tough & J's Arcade 2.7.71 (versionCode 109) — source (GPL-3.0)

2.7.71 is cumulative over 2.7.70 (everything else unchanged):
- Pixel War 0.4.9 is now `pixelwar:latest` (default). 0.4.7 is kept as `pixelwar:v047`; v046, v045, v044, v043, v042, v041, v03 unchanged. Source: source/pixel-war/arcade-2.7.71/.
- Papa Potato 0.4.2 is now `papa-potato:latest`. 0.4.1 is kept as `papa-potato:v041`; v03, v02, v01 unchanged. Source: source/papa-potato/0.4.2/.
- Swarm 1.6.15 is now `swarm:latest`. 1.6.14 is kept as `swarm:v1614`; older slots unchanged. Source: source/swarm-1.6.15/ (plus source/swarm-1.6.14/).
- Unchanged otherwise: Latch 2.1, FunMotion 0.2.5, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
