# Third-party code inside Arcade 2.7.50 (Needle on-phone engine)

| Component | Version | License | Where it's used |
|---|---|---|---|
| NewPipeExtractor (TeamNewPipe) | v0.27.1 (JitPack) | GPL-3.0-or-later | Reads YouTube/Shorts links and lists the real streams |
| NewPipe app stream muxers: Mp4FromDashWriter, OggFromWebMWriter, Mp4DashReader, WebMReader, DataReader, SharpStream (TeamNewPipe, dev@49aaaeb) | ported to com.toughandj.arcade.needle.streams | GPL-3.0-or-later | Merges H.264 video and AAC audio into one .mp4; makes .m4a and .ogg without re-encoding |
| jump3r (pure-Java LAME port) | 1.0.5 | LGPL (LAME) | Real MP3 encoding on the phone |
| Mozilla Rhino | 1.8.1 | MPL-2.0 | Used by NewPipeExtractor for YouTube's player JS |
| jsoup | 1.24.1 | MIT | Used by NewPipeExtractor |
| nanojson | (NewPipe fork) | Apache-2.0 / MIT | Used by NewPipeExtractor |
| protobuf-javalite | 4.36.2 | BSD-3-Clause | Used by NewPipeExtractor |
| jsr305 | 3.0.2 | BSD-3-Clause | Annotations only |
| desugar_jdk_libs_nio (Google) | 2.1.5 | GPL-2.0 with Classpath Exception | Lets Java 11-17 APIs run on Android 8-12 |

**What this means:** because the APK links GPL-3 code, anyone who gets this APK is owed the full matching source under GPL-3: the Java engine, the app wrapper and the Needle UI. That source is in `../source/`. The original NewPipe muxer files and their LICENSE are in `../source/third-party/newpipe-streams-original/`, and the jump3r sources jar is in `../source/third-party/`. The GPL-3 text is in `GPL-3.0-NewPipe.txt`.
