// Make an old-WebView ("~legacy") variant of a cartridge: lowered CSS + JS (esbuild, chrome80) + prelude polyfills.
import { createRequire } from "node:module"; import fs from "node:fs";
import { legacyCss } from "./legacy-css.mjs";
const require = createRequire("/workspace/game/build-latch/tool/");
const esbuild = require("esbuild");
const PRELUDE = fs.readFileSync(new URL("./legacy-prelude.js", import.meta.url), "utf8");
export const CSS_NEED = /@layer|oklch\(|oklab\(|color-mix\(|[^a-z-]lab\(|:where\(|:is\(|[;{]\s*inset(-inline|-block)?\s*:|\d(dvh|svh|lvh)\b|(margin|padding)-(inline|block)\s*:|[;{]\s*(translate|scale|rotate)\s*:|\((min-|max-)?(width|height)\s*[<>]=?|[^\\]&|@container|@property|:has\(|:focus-visible|::file-selector-button|@starting-style/;
export const PRELUDE_SRC = PRELUDE;
export function legacyHtml(html, report = {}) { return joinParts(legacyParts(html, report), html); }

// Same transform, but returned as parts: strings (new text) or [start,len] refs into the original (unchanged regions/assets).
export function legacyParts(html, report = {}) {
  report.css = 0; report.js = 0; report.jsFail = [];
  const edits = [];
  const re = /<script([^>]*)>([\s\S]*?)<\/script>|<style([^>]*)>([\s\S]*?)<\/style>/gi; let m;
  while ((m = re.exec(html))) {
    const one = legacyHtmlBlock(m, report); if (one !== null) edits.push([m.index, m[0].length, one]);
  }
  report.changed = edits.length > 0;
  const pre = `<script>${PRELUDE}</script>`; const h = /<head[^>]*>/i.exec(html);
  const at = h ? h.index + h[0].length : 0; edits.push([at, 0, pre]); edits.sort((x, y) => x[0] - y[0] || x[1] - y[1]);
  const parts = []; let pos = 0;
  const pushText = (txt) => { const r = /[A-Za-z0-9+\/=]{4000,}/g; let k, last = 0; while ((k = r.exec(txt))) { const i = html.indexOf(k[0]); if (i < 0) continue; if (k.index > last) parts.push(txt.slice(last, k.index)); parts.push([i, k[0].length]); last = k.index + k[0].length; } if (last < txt.length) parts.push(txt.slice(last)); };
  for (const [s, len, txt] of edits) { if (s > pos) parts.push([pos, s - pos]); pushText(txt); pos = s + len; }
  if (pos < html.length) parts.push([pos, html.length - pos]);
  return parts;
}
function legacyHtmlBlock(m, report) {
  const [, attrs, js, sattrs, css] = m;
  if (js === undefined) { if (!CSS_NEED.test(css)) return null; report.css++; return `<style${sattrs}>${legacyCss(css)}</style>`; }
  if (/\bsrc\s*=/.test(attrs) || !js.trim() || /type\s*=\s*["']?(application\/json|text\/plain|importmap|text\/template)/i.test(attrs)) return null;
  const isModule = /type\s*=\s*["']?module/i.test(attrs);
  try {
    const opts = { loader: "js", format: isModule ? "esm" : undefined, minifyWhitespace: true, legalComments: "none", supported: { "top-level-await": true } };
    const UNIT = /(?<![A-Za-z0-9+\/_$.\[-])(\d+(?:\.\d+)?)(d|s|l)v(h|w|min|max)(?![A-Za-z0-9+\/=_$\]-])/g;
    const needSyntax = esbuild.transformSync(js, { ...opts, target: "esnext" }).code !== esbuild.transformSync(js, { ...opts, target: "chrome80" }).code;
    if (!needSyntax) {
      // only viewport units in inline-style strings (e.g. React style={{height:"100dvh"}}): Chrome 83 drops them
      if (!UNIT.test(js)) return null; UNIT.lastIndex = 0;
      report.js++; report.units = (report.units || 0) + (js.match(UNIT) || []).length; return `<script${attrs}>${js.replace(UNIT, "$1v$3")}</script>`;
    }
    const r = esbuild.transformSync(js, { ...opts, target: "chrome80" });
    const code = r.code.replace(UNIT, "$1v$3");
    report.units = (report.units || 0) + (r.code.match(UNIT) || []).length;
    report.js++; return `<script${attrs}>${code.replace(/<\/script/gi, "<\\/script")}</script>`;
  } catch (e) { report.jsFail.push(String(e.message).split("\n")[0].slice(0, 160)); return null; }
}
export function joinParts(parts, base) { return parts.map((p) => (typeof p === "string" ? p : base.substr(p[0], p[1]))).join(""); }
