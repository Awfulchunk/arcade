// emu-one.cjs <id> <legacy 0|1|auto> <out.png> [waitMs] : reload shell with arcade.legacy, launch game, report errors/stats, screenshot.
const connect = require("./cdp.cjs"); const { execSync } = require("child_process"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const [id, mode, out, wait] = process.argv.slice(2);
(async () => {
  let c = await connect(9333);
  await c.ev(`(()=>{try{${mode === "auto" ? "localStorage.removeItem('arcade.legacy')" : `localStorage.setItem('arcade.legacy','${mode}')`}}catch(e){};location.reload();return 1})()`).catch(() => {});
  c.close(); await sleep(4000);
  for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  const n0 = c.ctx.length;
  await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='${id}');ARCADE.launchCard(i);return 1})()`);
  await sleep(+(wait || 7000));
  const cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault).pop();
  const st = cx ? await c.ev(`JSON.stringify((()=>{let vis=0;for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect();if(r.width>0&&r.height>0)vis++;}return {legacyPrelude:!!window.__tjGap||typeof window.__tjGap,errs:window.__errs,vis,text:document.body.innerText.slice(0,80),html:document.documentElement.outerHTML.length}})())`, cx.id).catch((e) => e.message) : "noctx";
  const shell = await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),frame:(()=>{const r=ARCADE.frame()&&ARCADE.frame().getBoundingClientRect();return r?[r.width,r.height]:null})()})`);
  execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > ${out}`);
  console.log(id, mode, shell, st); c.close(); process.exit(0);
})().catch((e) => { console.error("ERR", e.message.slice(0, 300)); process.exit(1); });
