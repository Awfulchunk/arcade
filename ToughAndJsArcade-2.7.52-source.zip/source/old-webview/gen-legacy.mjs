// Build "~legacy" cartridge slots for old WebViews. Output: JSON {key: parts} where parts = array of strings or [start,len] refs into the base slot (so big assets aren't stored twice).
import fs from "node:fs"; import vm from "node:vm"; import { legacyHtml, legacyParts, joinParts } from "./legacy-html.mjs";
const [bundlePath, outPath] = process.argv.slice(2);
const t = fs.readFileSync(bundlePath, "utf8");
const a = t.indexOf("const GAME_SRC="), b = t.indexOf("// END_PACKED_GAME_SRC");
const G = vm.runInNewContext(t.slice(a, b) + "\nGAME_SRC;");
const gi = t.indexOf("const GAMES="), ge = t.indexOf("\n", gi); const GAMES = JSON.parse(t.slice(gi + 12, ge).replace(/;\s*$/, ""));
const keys = [];
for (const g of GAMES) { const def = (g.versions || []).find((v) => v.def) || (g.versions || []).slice(-1)[0]; keys.push(def ? g.id + ":" + def.id : g.id); }
if (G["latch:v11"]) keys.push("latch:v11");
const out = {}, stats = [];
for (const key of keys) {
  const base = G[key]; if (!base) { stats.push({ key, missing: true }); continue; }
  const rep = {}; const L = legacyHtml(base, rep);
  if (!rep.changed) { stats.push({ key, variant: false, jsFail: rep.jsFail }); continue; }
  const rep2 = {}; const parts = legacyParts(base, rep2);
  if (joinParts(parts, base) !== L) throw new Error("parts mismatch " + key);
  const refBytes = parts.reduce((s, p) => s + (typeof p === "string" ? 0 : p[1]), 0);
  out[key + "~legacy"] = parts;
  stats.push({ key, variant: true, css: rep.css, js: rep.js, jsFail: rep.jsFail, bytes: L.length, stored: L.length - refBytes });
}
fs.writeFileSync(outPath, JSON.stringify(out));
console.table(stats);
