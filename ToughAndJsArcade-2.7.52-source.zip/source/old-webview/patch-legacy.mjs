// 2.7.52 fix pass: old-WebView support for the arcade shell + "~legacy" cartridge variants (GAME_LEGACY).
// Modern browsers: shell only loses `inset` shorthand (same layout via longhands); every GAME_SRC slot is untouched.
import fs from "node:fs"; import vm from "node:vm"; import { legacyParts, legacyHtml, joinParts, PRELUDE_SRC } from "./legacy-html.mjs";
const file = process.argv[2]; let t = fs.readFileSync(file, "utf8");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
assert(!t.includes("GAME_LEGACY"), "already patched");
const gsA = t.indexOf("const GAMES="), endMark = "// END_PACKED_GAME_SRC", gsB = t.indexOf(endMark) + endMark.length;
let head = t.slice(0, gsA), mid = t.slice(gsA, gsB), tail = t.slice(gsB);
// 1) shell CSS/JS: inset shorthand (Chrome 87+) -> longhands
const insetRe = /([;{\s'"])inset:0(?=[;}\s'"])/g;
const nHead = (head.match(insetRe) || []).length, nTail = (tail.match(insetRe) || []).length;
head = head.replace(insetRe, "$1top:0;right:0;bottom:0;left:0"); tail = tail.replace(insetRe, "$1top:0;right:0;bottom:0;left:0");
assert(nHead === 8 && nTail === 1, `inset counts ${nHead}/${nTail}`);
// 2) prelude (polyfills + flex-gap fallback; no-op on modern) for the shell itself
const PRE = `<script>${PRELUDE_SRC}</script>`;
assert(head.startsWith("<!DOCTYPE") || head.indexOf("<head>") < 200, "shell head");
head = head.replace("<head>", "<head>" + PRE);
// 3) legacy variants
const G = vm.runInNewContext(t.slice(t.indexOf("const GAME_SRC="), t.indexOf(endMark)) + "\nGAME_SRC;");
const GAMES = JSON.parse(t.slice(gsA + 12, t.indexOf("\n", gsA)).replace(/;\s*$/, ""));
const keys = [];
for (const g of GAMES) { const def = (g.versions || []).find((v) => v.def) || (g.versions || []).slice(-1)[0]; keys.push(def ? g.id + ":" + def.id : g.id); }
if (G["latch:v11"]) keys.push("latch:v11");
const LEG = {}, stats = [];
for (const k of keys) {
  const base = G[k]; assert(base, "missing " + k); const rep = {}; const parts = legacyParts(base, rep);
  if (!rep.changed) { stats.push({ key: k, variant: "prelude only (no CSS/JS lowering needed)" }); continue; }
  assert(joinParts(parts, base) === legacyHtml(base, {}), "parts mismatch " + k);
  LEG[k] = parts; stats.push({ key: k, variant: `css ${rep.css} js ${rep.js}`, jsFail: rep.jsFail.length });
}
const legLine = "\nconst GAME_LEGACY=" + JSON.stringify(LEG).replace(/<\//g, "<\\/") + ";\nconst LEGACY_PRE=" + JSON.stringify(PRE).replace(/<\//g, "<\\/") + ";";
// 4) shell: detect old WebView, pick variant
const anchor = "const $=id=>document.getElementById(id);";
assert(tail.split(anchor).length === 2, "anchor");
const SRCFOR = anchor + `
// Old Android WebViews (Chrome < 88-ish) can't run Tailwind v4 / newest JS: use the lowered "~legacy" build. localStorage arcade.legacy=1/0 forces it.
const LEGACY=(()=>{try{const o=localStorage.getItem('arcade.legacy');if(o==='1')return true;if(o==='0')return false;}catch(e){}try{return !(window.CSS&&CSS.supports&&CSS.supports('selector(:where(a))'));}catch(e){return true;}})();
function srcFor(k){const s=GAME_SRC[k];if(!LEGACY||!s)return s;const v=GAME_LEGACY[k];if(v)return v.map(p=>typeof p==='string'?p:s.substr(p[0],p[1])).join('');return /<head[^>]*>/i.test(s)?s.replace(/<head[^>]*>/i,m=>m+LEGACY_PRE):LEGACY_PRE+s;}
try{document.documentElement.classList.toggle('legacy-webview',LEGACY);}catch(e){}`;
tail = tail.replace(anchor, SRCFOR);
const r1 = "const src=GAME_SRC[key];", r2 = "const html=GAME_SRC[key].replace(";
assert(tail.split(r1).length === 2 && tail.split(r2).length === 2, "launch/swap anchors");
tail = tail.replace(r1, "const src=srcFor(key);").replace(r2, "const html=srcFor(key).replace(");
t = head + mid + legLine + tail;
fs.writeFileSync(file, t);
console.table(stats);
console.log(JSON.stringify({ legacyVariants: Object.keys(LEG).length, legacyBytes: legLine.length, shellInsetFixed: nHead + nTail }));
