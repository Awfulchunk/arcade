const { decodeGifBytes } = require("/tmp/gifjs.cjs"); const fs = require("fs"); const { execSync } = require("child_process");
for (const f of process.argv.slice(2)) {
  const g = decodeGifBytes(new Uint8Array(fs.readFileSync(f)), 1000);
  const n = Number(execSync(`python3 -c "from PIL import Image;print(Image.open('${f}').n_frames)"`).toString());
  // compare frame k against PIL composite
  let maxd = 0;
  for (const k of [0, Math.floor(g.frames.length / 2), g.frames.length - 1]) {
    const ref = execSync(`python3 -c "
from PIL import Image;import sys
im=Image.open('${f}');im.seek(${k});sys.stdout.buffer.write(im.convert('RGBA').tobytes())"`, { maxBuffer: 1 << 28 });
    let d = 0, cnt = 0; const a = g.frames[k].rgba; for (let i = 0; i < a.length; i += 4) { if (ref[i + 3] === 0 && a[i + 3] === 0) continue; cnt++; d += Math.abs(a[i] - ref[i]) + Math.abs(a[i + 1] - ref[i + 1]) + Math.abs(a[i + 2] - ref[i + 2]); }
    maxd = Math.max(maxd, d / Math.max(1, cnt));
  }
  console.log(f.split("/").pop(), `${g.w}x${g.h}`, "js frames", g.frames.length, "PIL frames", n, "mean abs diff/px", maxd.toFixed(3));
}
