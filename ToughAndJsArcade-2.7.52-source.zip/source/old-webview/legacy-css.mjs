// Build-time CSS lowering for old Android WebViews (Chrome 80-83): flatten @layer, lower nesting/colours/media ranges/
// logical props with lightningcss, then fix what lightningcss leaves: :where/:is/:not(list) selectors, unknown
// pseudo-elements that kill whole selector lists, individual transform props, dvh/svh/lvh units, inset.
import { createRequire } from "node:module";
const require = createRequire("/workspace/game/build-latch/tool/");
const { transform } = require("lightningcss");

// ---- tiny CSS block parser (works on any CSS; respects strings, comments, parens) ----
function parse(css) {
  const out = []; let i = 0; const n = css.length;
  const skipWs = () => { while (i < n) { if (/\s/.test(css[i])) i++; else if (css.startsWith("/*", i)) { const e = css.indexOf("*/", i + 2); i = e < 0 ? n : e + 2; } else break; } };
  const readUntil = (stops) => { let s = i, depth = 0; while (i < n) { const ch = css[i];
      if (ch === '"' || ch === "'") { i++; while (i < n && css[i] !== ch) { if (css[i] === "\\") i++; i++; } i++; continue; }
      if (css.startsWith("/*", i)) { const e = css.indexOf("*/", i + 2); i = e < 0 ? n : e + 2; continue; }
      if (ch === "(" || ch === "[") depth++; else if (ch === ")" || ch === "]") depth--;
      else if (depth <= 0 && stops.includes(ch)) break; i++; } return css.slice(s, i); };
  const readBlock = () => { // at css[i]=='{'
    let s = ++i, depth = 1; while (i < n && depth > 0) { const ch = css[i];
      if (ch === '"' || ch === "'") { i++; while (i < n && css[i] !== ch) { if (css[i] === "\\") i++; i++; } i++; continue; }
      if (css.startsWith("/*", i)) { const e = css.indexOf("*/", i + 2); i = e < 0 ? n : e + 2; continue; }
      if (ch === "{") depth++; else if (ch === "}") depth--; i++; }
    return css.slice(s, i - 1); };
  while (true) { skipWs(); if (i >= n) break;
    if (css[i] === "}") { i++; continue; }
    if (css[i] === "@") { const pre = readUntil(";{"); if (css[i] === ";") { i++; out.push({ t: "at", pre: pre.trim(), block: null }); } else if (css[i] === "{") { out.push({ t: "at", pre: pre.trim(), block: readBlock() }); } else out.push({ t: "at", pre: pre.trim(), block: null }); continue; }
    const sel = readUntil("{;"); if (css[i] === ";") { i++; continue; } if (css[i] !== "{") break; out.push({ t: "rule", sel: sel.trim(), body: readBlock() }); }
  return out; }
const atName = (pre) => (/^@(-?[\w-]+)/.exec(pre) || [])[1] || "";
const BLOCK_AT = new Set(["media", "supports", "document", "-moz-document"]);

function flattenLayers(css) {
  return parse(css).map((x) => { if (x.t === "at") { const nm = atName(x.pre);
      if (nm === "layer") return x.block == null ? "" : flattenLayers(x.block);
      if (x.block != null && BLOCK_AT.has(nm)) return `${x.pre}{${flattenLayers(x.block)}}`;
      return x.block == null ? `${x.pre};` : `${x.pre}{${x.block}}`; }
    return `${x.sel}{${x.body}}`; }).join("");
}

// ---- selectors ----
function splitTop(s, sep = ",") { const parts = []; let d = 0, q = null, start = 0; for (let i = 0; i < s.length; i++) { const ch = s[i];
    if (q) { if (ch === "\\") i++; else if (ch === q) q = null; continue; } if (ch === '"' || ch === "'") { q = ch; continue; }
    if (ch === "(" || ch === "[") d++; else if (ch === ")" || ch === "]") d--; else if (d === 0 && ch === sep) { parts.push(s.slice(start, i)); start = i + 1; } }
  parts.push(s.slice(start)); return parts.map((p) => p.trim()).filter(Boolean); }
function matchParen(s, open) { let d = 0; for (let i = open; i < s.length; i++) { if (s[i] === "(") d++; else if (s[i] === ")") { d--; if (d === 0) return i; } } return -1; }
function expandSel(sel, depth = 0) {
  if (depth > 6) return [sel];
  const m = /:(where|is|-webkit-any|matches)\(/.exec(sel);
  if (m) { const open = m.index + m[0].length - 1, close = matchParen(sel, open); if (close < 0) return [sel];
    const args = splitTop(sel.slice(open + 1, close)); const out = [];
    for (const a of args) for (const e of expandSel(sel.slice(0, m.index) + a + sel.slice(close + 1), depth + 1)) out.push(e);
    return out; }
  // :not(a,b) -> :not(a):not(b)
  const nm = /:not\(/g; let k; let s2 = sel;
  while ((k = nm.exec(s2))) { const open = k.index + 4, close = matchParen(s2, open); if (close < 0) break; const args = splitTop(s2.slice(open + 1, close));
    if (args.length > 1) { s2 = s2.slice(0, k.index) + args.map((a) => `:not(${a})`).join("") + s2.slice(close + 1); nm.lastIndex = 0; } }
  return [s2];
}
const BAD_SEL = /::file-selector-button|:has\(|::part\(|:focus-visible|:user-(in)?valid|::target-text|:popover-open|::details-content|:open\b|:modal\b|::picker|::marker|:-moz-|::-moz-/;
function fixSelectorList(sel) {
  const out = []; for (const part of splitTop(sel)) for (const e of expandSel(part)) { if (BAD_SEL.test(e)) continue; out.push(e); }
  return [...new Set(out)];
}
// ---- declarations ----
function fixDecls(body) {
  const decls = splitTop(body, ";"); const out = []; const tf = [];
  for (const d of decls) { const c = d.indexOf(":"); if (c < 0) { out.push(d); continue; }
    const prop = d.slice(0, c).trim(); let val = d.slice(c + 1).trim();
    val = val.replace(/(\d)(dvh|svh|lvh)\b/g, "$1vh").replace(/(\d)(dvw|svw|lvw)\b/g, "$1vw");
    if (prop === "inset") { const v = splitTop(val, " ").length ? val.split(/\s+(?![^(]*\))/) : [val]; const [t, r = t, b = t, l = r] = v; out.push(`top:${t}`, `right:${r}`, `bottom:${b}`, `left:${l}`); continue; }
    if (prop === "inset-inline" || prop === "inset-block") { const v = val.split(/\s+(?![^(]*\))/); const [a, b = a] = v; if (prop === "inset-inline") out.push(`left:${a}`, `right:${b}`); else out.push(`top:${a}`, `bottom:${b}`); continue; }
    const lg = /^(margin|padding|border|scroll-margin|scroll-padding)-(inline|block)(-width|-style|-color)?$/.exec(prop);
    if (lg && !/^(-start|-end)/.test(lg[3] || "")) { const v = val.split(/\s+(?![^(]*\))/); const [a, b = a] = v; const sfx = lg[3] || "";
      if (lg[2] === "inline") out.push(`${lg[1]}-left${sfx}:${a}`, `${lg[1]}-right${sfx}:${lg[1] === "border" && !sfx ? a : b}`); else out.push(`${lg[1]}-top${sfx}:${a}`, `${lg[1]}-bottom${sfx}:${lg[1] === "border" && !sfx ? a : b}`); continue; }
    if (prop === "translate" && val !== "none") { const v = val.split(/\s+(?![^(]*\))/); tf.push(`translate(${v[0]},${v[1] || 0})`); continue; }
    if (prop === "scale" && val !== "none") { const v = val.split(/\s+(?![^(]*\))/); tf.push(`scale(${v[0]},${v[1] || v[0]})`); continue; }
    if (prop === "rotate" && val !== "none" && !/\s/.test(val)) { tf.push(`rotate(${val})`); continue; }
    out.push(`${prop}:${val}`); }
  if (tf.length) { const ti = out.findIndex((d) => /^transform:/.test(d)); if (ti >= 0 && !/^transform:\s*none/.test(out[ti])) out[ti] = `transform:${tf.join(" ")} ${out[ti].slice(10)}`; else if (ti >= 0) out[ti] = `transform:${tf.join(" ")}`; else out.push(`transform:${tf.join(" ")}`); }
  return out.join(";");
}
function post(css) {
  return parse(css).map((x) => { if (x.t === "at") { const nm = atName(x.pre);
      if (nm === "property" || nm === "starting-style" || nm === "container" || nm === "scope") return ""; // unsupported anyway
      if (x.block != null && BLOCK_AT.has(nm)) return `${x.pre}{${post(x.block)}}`;
      if (x.block != null && (nm === "keyframes" || nm === "-webkit-keyframes")) return `${x.pre}{${parse(x.block).map((k) => `${k.sel}{${fixDecls(k.body)}}`).join("")}}`;
      return x.block == null ? `${x.pre};` : `${x.pre}{${x.block}}`; }
    const sels = fixSelectorList(x.sel); if (!sels.length) return ""; const body = fixDecls(x.body);
    // one rule per selector so one unknown selector can't drop the others
    return sels.length === 1 ? `${sels[0]}{${body}}` : sels.map((s) => `${s}{${body}}`).join("");
  }).join("");
}
export function legacyCss(css) {
  let flat = flattenLayers(css);
  let lowered = flat;
  try {
    const r = transform({ filename: "x.css", code: Buffer.from(flat), minify: true, errorRecovery: true, targets: { chrome: 80 << 16, android: 80 << 16 } });
    lowered = r.code.toString();
  } catch (e) { /* keep flattened */ }
  return post(lowered);
}
