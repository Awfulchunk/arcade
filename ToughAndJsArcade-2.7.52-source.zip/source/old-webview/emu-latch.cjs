// Emulator (Android 11, WebView 83): Latch v2.0 GIF (JS decoder) animates + bounces, flex-gap fallback, Latch v1.1 renders, Needle renders.
const connect = require("./cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT = process.argv[2] || "emu-latch"; fs.mkdirSync(OUT, { recursive: true });
const shot = (n) => execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > ${OUT}/${n}.png`);
const GIF = fs.readFileSync("/workspace/game/build-latch/latch-sample.gif").toString("base64");
(async () => {
  let c; for (let i = 0; i < 40; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d).slice(0, 300)); };
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const shell = JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:(navigator.userAgent.match(/Chrome\\/[\\d.]+/)||[''])[0]})`));
  ok("shell on old WebView picks legacy builds", shell.legacy && /Chrome\/83/.test(shell.ua), shell);
  const launch = async (id, ver, wait) => { if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(1500); } const n0 = c.ctx.length; await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='${id}');${ver ? `ARCADE.launch(i,'${ver}')` : "ARCADE.launchCard(i)"};return 1})()`); await sleep(wait || 8000); let cx; for (let i = 0; i < 20 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); } if (!cx) throw new Error('no iframe context for ' + id); return (e) => c.ev(e, cx.id); };
  const HASH = `(()=>{const cv=[...document.querySelectorAll('.vf canvas')].find(e=>e.width>10);if(!cv)return 'none';const s=document.createElement('canvas');s.width=24;s.height=24;const x=s.getContext('2d');x.drawImage(cv,0,0,24,24);const d=x.getImageData(0,0,24,24).data;let h=0;for(let i=0;i<d.length;i+=3)h=(h*31+d[i])>>>0;return String(h)})()`;
  const distinctHash = async (ev, ms) => { const s = new Set(); const t0 = Date.now(); while (Date.now() - t0 < ms) { s.add(await ev(HASH)); await sleep(60); } return s.size; };
  // on-screen change: real screencaps of the viewfinder area, 3 diffs (the in-page canvas hash is unreliable on WebView 83)
  const distinct = async (ev, ms, tag) => { const fsx = []; for (let i = 0; i < 4; i++) { const f = `${OUT}/_${tag}${i}.png`; execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > ${f}`); fsx.push(f); }
    const out = execSync(`python3 -c "from PIL import Image,ImageChops;import sys;ims=[Image.open(f).convert('RGB').crop((0,120,1080,900)) for f in sys.argv[1:]];print(sum(1 for i in range(len(ims)-1) if ImageChops.difference(ims[i],ims[i+1]).getbbox()))" ${fsx.join(" ")}`).toString().trim(); fsx.forEach((f) => fs.unlinkSync(f)); return +out; };
  const GAPCHK = `JSON.stringify((()=>{let n=0,good=0,bad=[];for(const el of document.querySelectorAll('body *')){const cs=getComputedStyle(el);if(cs.display!=='flex'||cs.flexDirection!=='row'||cs.flexWrap!=='nowrap')continue;const g=parseFloat(cs.columnGap)||0;if(g<2)continue;const k=[...el.children].filter(x=>{const s=getComputedStyle(x);return s.display!=='none'&&s.position!=='absolute'&&s.position!=='fixed'&&x.getBoundingClientRect().width>0});if(k.length<2)continue;n++;const a=k[0].getBoundingClientRect(),b=k[1].getBoundingClientRect();const real=b.left-a.right;if(Math.abs(real-g)<=1.5)good++;else bad.push(String(el.className).slice(0,30)+' gap '+g+' real '+real.toFixed(1))}return {n,good,bad:bad.slice(0,4)}})())`;
  // Latch v2.0
  let ev = await launch("latch", null, 9000);
  const env = JSON.parse(await ev(`JSON.stringify({vtr:!!document.querySelector('main.vtr'),imageDecoder:typeof window.ImageDecoder,gapShim:!!window.__tjGap,errs:window.__errs})`));
  ok("Latch v2.0 renders (VTR UI), 0 errors", env.vtr && env.errs.length === 0, env);
  shot("01-latch-v2.0");
  const gap = JSON.parse(await ev(GAPCHK)); ok("Latch v2.0: flex gap spacing restored (row gaps measured)", gap.n > 0 && gap.good === gap.n, gap);
  await ev(`(async()=>{const b=atob('${GIF}');const u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);const f=new File([u],'sample-anim.gif',{type:'image/gif'});const inp=document.querySelector('main.vtr input[type=file]');const dt=new DataTransfer();dt.items.add(f);inp.files=dt.files;inp.dispatchEvent(new Event('change',{bubbles:true}));return 1})()`);
  await sleep(4000);
  const osd = await ev(`(document.querySelector('.osd.otr')||{}).textContent||''`);
  const d1 = await distinct(ev, 2500, 'g'); shot("02-latch-gif-playing");
  ok("Latch v2.0: animated GIF plays on WebView 83 (no ImageDecoder -> JS decoder)", env.imageDecoder === "undefined" && d1 >= 3 && /GIF/.test(osd), { imageDecoder: env.imageDecoder, changedOf3Screencaps: d1, osd });
  await ev(`(async()=>{const s=ms=>new Promise(r=>setTimeout(r,ms));document.querySelector('[data-tool=bounce]').click();await s(500);document.querySelector('.drawer [data-tip^="Bounce|"]').click();await s(300);document.querySelector('[data-done]').click();return 1})()`);
  await sleep(1200); const d2 = await distinct(ev, 2500, 'b'); shot("03-latch-gif-bounce");
  const led = await ev(`!!document.querySelector('[data-tool=bounce] .led.on')`);
  ok("Latch v2.0: GIF bounce plays", led && d2 >= 3, { led, changedOf3Screencaps: d2 });
  const e2 = await ev("JSON.stringify(window.__errs)"); ok("Latch v2.0: 0 JS errors after GIF + bounce", e2 === "[]", e2);
  // Latch v1.1
  ev = await launch("latch", "v11", 9000);
  const v11 = JSON.parse(await ev(`JSON.stringify((()=>{let vis=0;for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect();if(r.width>0&&r.height>0)vis++;}return {qm:document.querySelectorAll('.qm').length,vis,text:document.body.innerText.length,errs:window.__errs,sw:document.scrollingElement.scrollWidth}})())`));
  shot("04-latch-v1.1");
  ok("Latch v1.1 renders on WebView 83 (? badges present), 0 errors", v11.qm > 5 && v11.vis > 20 && v11.errs.length === 0 && v11.sw <= 413, v11);
  // Needle
  ev = await launch("needle", null, 9000);
  const nd = JSON.parse(await ev(`JSON.stringify((()=>{let vis=0;for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect();if(r.width>0&&r.height>0)vis++;}const b=document.querySelector('button');return {vis,text:document.body.innerText.slice(0,60),errs:window.__errs,sw:document.scrollingElement.scrollWidth,bg:getComputedStyle(document.body).backgroundColor,btnBg:b&&getComputedStyle(b).backgroundColor}})())`));
  shot("05-needle");
  const ng = JSON.parse(await ev(GAPCHK));
  ok("Needle renders on WebView 83 (Tailwind v4 lowered), 0 errors, no sideways overflow", nd.vis > 20 && nd.errs.length === 0 && nd.sw <= 413, { ...nd, gap: ng });
  await c.ev("ARCADE.back(),1"); await sleep(1500); shot("06-menu");
  const ref = JSON.parse(fs.readFileSync("/tmp/gapref.json", "utf8"));
  const mine = JSON.parse(await c.ev(`JSON.stringify((()=>{const out=[];for(const el of document.querySelectorAll('body *')){const cs=getComputedStyle(el);if(cs.display!=='flex'||cs.flexDirection!=='row'||cs.flexWrap!=='nowrap')continue;const g=parseFloat(cs.columnGap)||0;if(g<2)continue;const k=[...el.children].filter(x=>{const s=getComputedStyle(x);return s.display!=='none'&&s.position!=='absolute'&&s.position!=='fixed'&&x.getBoundingClientRect().width>0});if(k.length<2)continue;const a=k[0].getBoundingClientRect(),c=k[1].getBoundingClientRect();out.push((el.id||el.className||el.tagName)+' gap '+g+' real '+(c.left-a.right).toFixed(1)+' jc '+cs.justifyContent)}return out})())`));
  const near = (x, y) => { const rx = +/real (-?[\d.]+)/.exec(x)[1], ry = +/real (-?[\d.]+)/.exec(y)[1]; return x.split(" real ")[0] === y.split(" real ")[0] && Math.abs(rx - ry) <= 1.5; };
  const miss = ref.filter((r) => !mine.some((m) => near(m, r)));
  ok("Arcade menu: flex row spacing matches modern Chrome", miss.length === 0, { emulator: mine, missingVsChrome: miss });
  fs.writeFileSync(`${OUT}/emu-latch.json`, JSON.stringify(R, null, 1)); console.log(`emu-latch: ${R.filter((r) => r.pass).length}/${R.length}`); c.close(); process.exit(0);
})().catch((e) => { console.error("ERR", e.message.slice(0, 400)); process.exit(1); });
