// Launch every game's newest version on the emulator WebView, collect JS errors + rough render stats + screenshot.
const connect = require("./cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT = process.argv[2] || "emu-survey"; fs.mkdirSync(OUT, { recursive: true });
const SIZE = process.argv[3] !== "nosize";
const only = process.argv[4] ? process.argv[4].split(",") : null;
(async () => {
  const c = await connect(9333);
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\\/script>"; d.set.call(this, v?inj+v:v);}, get(){return d.get.call(this);}}); return 1})()`);
  const games = await c.ev(`ARCADE.GAMES.map((g,i)=>({i,id:g.id,ver:((g.versions||[]).find(v=>v.def)||(g.versions||[]).slice(-1)[0]||{}).id||null}))`);
  const R = []; const T = (p, ms) => Promise.race([p, new Promise((_, j) => setTimeout(() => j(new Error("timeout")), ms))]);
  for (const g of games) {
    if (only && !only.includes(g.id)) continue;
    if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(1200); }
    const n0 = c.ctx.length;
    await c.ev(`(()=>{ARCADE.launchCard(${g.i}); ${SIZE ? "const e=document.getElementById('game'); e.style.top='0';e.style.left='0';e.style.width='100%';e.style.height='100%';" : ""} return 1})()`);
    await sleep(10000);
    const fr = await T(c.ev(`JSON.stringify((()=>{const f=ARCADE.frame(); const r=f&&f.getBoundingClientRect(); return r?[Math.round(r.width),Math.round(r.height)]:null})())`), 20000).catch(()=>'null');
    const cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault).pop();
    let st = { noctx: true };
    if (cx) { try { st = JSON.parse(await T(c.ev(`JSON.stringify((()=>{const all=[...document.querySelectorAll('body *')]; let vis=0, zero=0; for(const e of all){const r=e.getBoundingClientRect(); if(r.width>0&&r.height>0) vis++; else zero++;} const cs=document.querySelectorAll('canvas').length; const se=document.scrollingElement; return {errs:(window.__errs||[]).slice(0,4), text:document.body.innerText.length, vis, zero, canvases:cs, sw:se.scrollWidth, sh:se.scrollHeight, iw:innerWidth, ih:innerHeight}})())`, cx.id), 20000)); } catch (e) { st = { evalErr: e.message.slice(0, 200) }; } }
    execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > ${OUT}/${g.id}.png`);
    const row = { id: g.id, ver: g.ver, frame: JSON.parse(fr), ...st }; R.push(row); fs.appendFileSync(`${OUT}/survey.jsonl`, JSON.stringify(row) + "\n");
  }
  if (await c.ev("ARCADE.inGame")) await c.ev("ARCADE.back(),1");
  fs.writeFileSync(`${OUT}/survey.json`, JSON.stringify(R, null, 1)); c.close(); process.exit(0);
})().catch((e) => { console.error("ERR", e.message.slice(0, 400)); process.exit(1); });
