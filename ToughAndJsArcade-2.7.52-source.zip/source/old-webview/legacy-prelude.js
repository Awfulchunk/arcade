/* TJ legacy prelude (old Android WebView, Chrome 80-83): small polyfills + flex `gap` fallback. Does nothing on modern browsers. */
(function(){
var d=function(o,k,v){if(!o[k])try{Object.defineProperty(o,k,{value:v,writable:true,configurable:true});}catch(e){}};
d(Array.prototype,'at',function(i){i=Math.trunc(i)||0;if(i<0)i+=this.length;return i<0||i>=this.length?undefined:this[i];});
d(String.prototype,'at',function(i){i=Math.trunc(i)||0;if(i<0)i+=this.length;return i<0||i>=this.length?undefined:this.charAt(i);});
d(String.prototype,'replaceAll',function(a,b){if(a instanceof RegExp)return this.replace(a,b);return this.split(String(a)).join(typeof b==='function'?b(a):b);});
d(Object,'hasOwn',function(o,k){return Object.prototype.hasOwnProperty.call(o,k);});
d(Array.prototype,'findLast',function(f,t){for(var i=this.length-1;i>=0;i--)if(f.call(t,this[i],i,this))return this[i];});
d(Array.prototype,'findLastIndex',function(f,t){for(var i=this.length-1;i>=0;i--)if(f.call(t,this[i],i,this))return i;return -1;});
d(Array.prototype,'toSorted',function(f){return this.slice().sort(f);});
d(Array.prototype,'toReversed',function(){return this.slice().reverse();});
d(Promise,'any',function(ps){return new Promise(function(res,rej){var n=0,errs=[],arr=Array.from(ps);if(!arr.length)rej(new Error('All promises were rejected'));arr.forEach(function(p,i){Promise.resolve(p).then(res,function(e){errs[i]=e;if(++n===arr.length)rej(new Error('All promises were rejected'));});});});});
if(typeof Element!=='undefined')d(Element.prototype,'replaceChildren',function(){while(this.firstChild)this.removeChild(this.firstChild);this.append.apply(this,arguments);});
if(typeof crypto!=='undefined'&&crypto.getRandomValues)d(crypto,'randomUUID',function(){var b=crypto.getRandomValues(new Uint8Array(16));b[6]=b[6]&15|64;b[8]=b[8]&63|128;var h=[].map.call(b,function(x){return(x+256).toString(16).slice(1);}).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);});
function rr(x,y,w,h,r){if(r==null)r=0;var a=Array.isArray(r)?r:[r];a=a.map(function(v){return typeof v==='object'&&v?(v.x||0):(+v||0);});var tl,tr,br,bl;if(a.length===1){tl=tr=br=bl=a[0];}else if(a.length===2){tl=br=a[0];tr=bl=a[1];}else if(a.length===3){tl=a[0];tr=bl=a[1];br=a[2];}else{tl=a[0];tr=a[1];br=a[2];bl=a[3];}var m=Math.min(Math.abs(w),Math.abs(h))/2;tl=Math.min(tl,m);tr=Math.min(tr,m);br=Math.min(br,m);bl=Math.min(bl,m);if(w<0){x+=w;w=-w;}if(h<0){y+=h;h=-h;}this.moveTo(x+tl,y);this.lineTo(x+w-tr,y);this.arcTo(x+w,y,x+w,y+tr,tr);this.lineTo(x+w,y+h-br);this.arcTo(x+w,y+h,x+w-br,y+h,br);this.lineTo(x+bl,y+h);this.arcTo(x,y+h,x,y+h-bl,bl);this.lineTo(x,y+tl);this.arcTo(x,y,x+tl,y,tl);this.closePath();}
if(typeof CanvasRenderingContext2D!=='undefined')d(CanvasRenderingContext2D.prototype,'roundRect',rr);
if(typeof OffscreenCanvasRenderingContext2D!=='undefined')d(OffscreenCanvasRenderingContext2D.prototype,'roundRect',rr);
if(typeof Path2D!=='undefined')d(Path2D.prototype,'roundRect',rr);
if(typeof structuredClone==='undefined')window.structuredClone=function c(v){if(v===null||typeof v!=='object')return v;if(v instanceof Date)return new Date(v.getTime());if(ArrayBuffer.isView(v))return v.slice();if(v instanceof ArrayBuffer)return v.slice(0);if(v instanceof Map){var m=new Map();v.forEach(function(x,k){m.set(c(k),c(x));});return m;}if(v instanceof Set){var s=new Set();v.forEach(function(x){s.add(c(x));});return s;}if(typeof Blob!=='undefined'&&v instanceof Blob)return v;if(Array.isArray(v))return v.map(c);var o={};for(var k in v)if(Object.prototype.hasOwnProperty.call(v,k))o[k]=c(v[k]);return o;};
if(typeof AbortSignal!=='undefined')d(AbortSignal,'timeout',function(ms){var a=new AbortController();setTimeout(function(){a.abort();},ms);return a.signal;});
// ---- inline styles set from JS (React style={{...}}): dvh/svh/lvh -> vh, inset -> top/right/bottom/left ----
try{if(window.CSS&&CSS.supports&&!CSS.supports('height','1dvh')&&typeof CSSStyleDeclaration!=='undefined'){
 var VU=/(\d|\.)(d|s|l)v(h|w|min|max)\b/g,fixV=function(v){return typeof v==='string'&&v.indexOf('v')>=0?v.replace(VU,'$1v$3'):v;};
 var SP=CSSStyleDeclaration.prototype,names=Object.getOwnPropertyNames(SP);
 names.forEach(function(n){var ds=Object.getOwnPropertyDescriptor(SP,n);if(!ds||!ds.set||!ds.configurable||n==='cssText')return;var set=ds.set;Object.defineProperty(SP,n,{get:ds.get,set:function(v){set.call(this,fixV(v));},configurable:true,enumerable:ds.enumerable});});
 var sp=SP.setProperty;SP.setProperty=function(k,v,pr){if(k==='inset'){var q=String(v).trim().split(/\s+/);var t=q[0],r=q[1]||t,b=q[2]||t,l=q[3]||r;sp.call(this,'top',fixV(t),pr);sp.call(this,'right',fixV(r),pr);sp.call(this,'bottom',fixV(b),pr);sp.call(this,'left',fixV(l),pr);return;}return sp.call(this,k,fixV(v),pr);};
 var ct=Object.getOwnPropertyDescriptor(SP,'cssText');if(ct&&ct.set)Object.defineProperty(SP,'cssText',{get:ct.get,set:function(v){if(typeof v==='string')v=fixV(v).replace(/(^|;)\s*inset\s*:\s*([^;!]+)/g,function(m,a,val){var q=val.trim().split(/\s+/);var t=q[0],r=q[1]||t,b=q[2]||t,l=q[3]||r;return a+'top:'+t+';right:'+r+';bottom:'+b+';left:'+l;});ct.set.call(this,v);},configurable:true});
 if(!('inset' in document.documentElement.style))Object.defineProperty(SP,'inset',{get:function(){return '';},set:function(v){this.setProperty('inset',String(v));},configurable:true});
}}catch(e){}
// ---- flex gap fallback (Chrome < 84): margins on flex children, kept in sync with DOM changes ----
function gapOK(){var f=document.createElement('div');f.style.display='flex';f.style.flexDirection='column';f.style.rowGap='1px';f.style.position='absolute';f.appendChild(document.createElement('div'));f.appendChild(document.createElement('div'));(document.body||document.documentElement).appendChild(f);var ok=f.scrollHeight===1;f.parentNode.removeChild(f);return ok;}
function start(){
 if(window.__tjGap)return;window.__tjGap=1;
 if(document.documentElement.hasAttribute('data-own-gap')||gapOK())return;
 var applied=new WeakMap(),busy=false,t=0;
 function setM(el,prop,val){var a=applied.get(el)||{};var prev=a[prop]||0;if(prev===val)return;var cs=getComputedStyle(el);var base=(parseFloat(cs[prop])||0)-prev;el.style[prop]=(base+val)+'px';a[prop]=val;applied.set(el,a);}
 function run(){busy=true;try{var all=document.querySelectorAll('*');for(var i=0;i<all.length;i++){var el=all[i];if(el.namespaceURI!=='http://www.w3.org/1999/xhtml')continue;var cs=getComputedStyle(el);var disp=cs.display;if(disp!=='flex'&&disp!=='inline-flex')continue;var cg=parseFloat(cs.columnGap)||0,rg=parseFloat(cs.rowGap)||0;if(!cg&&!rg)continue;var dir=cs.flexDirection,wrap=cs.flexWrap!=='nowrap',col=dir.indexOf('column')===0,rev=dir.indexOf('reverse')>0;var kids=[];for(var j=0;j<el.children.length;j++){var k=el.children[j],ks=getComputedStyle(k);if(ks.display==='none'||ks.position==='absolute'||ks.position==='fixed')continue;kids.push(k);}
  for(var n=0;n<kids.length;n++){var k2=kids[n];if(wrap){setM(k2,col?'marginBottom':'marginRight',n<kids.length-1?(col?rg:cg):0);setM(k2,col?'marginRight':'marginBottom',col?cg:rg);}else if(col){setM(k2,rev?'marginBottom':'marginTop',n?rg:0);}else{setM(k2,rev?'marginRight':'marginLeft',n?cg:0);}}}}catch(e){}setTimeout(function(){busy=false;},0);}
 function soon(){if(busy)return;clearTimeout(t);t=setTimeout(run,120);}
 run();new MutationObserver(soon).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});addEventListener('resize',soon);addEventListener('load',soon);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
