const fs=require('fs');
const t=fs.readFileSync('/workspace/game/build-needle/package-2.7.51/tough-and-js-arcade.html','utf8');
const a=t.indexOf('const GAME_SRC=');const b=t.indexOf('// END_PACKED_GAME_SRC');
fs.writeFileSync('/tmp/gs51.js',t.slice(a,b)+'\nmodule.exports=GAME_SRC;');const G=require('/tmp/gs51.js');
const gi=t.indexOf('const GAMES=');const ge=t.indexOf('\n',gi);const GAMES=JSON.parse(t.slice(gi+12,ge).replace(/;\s*$/,''));
const rows=[];
for(const g of GAMES){const def=(g.versions||[]).find(v=>v.def)||(g.versions||[]).slice(-1)[0];const key=def?g.id+':'+def.id:g.id;const h=G[key]||'';
 const f=(re)=>(h.match(re)||[]).length;
 rows.push({key,tool:!!g.tool,bytes:h.length,tw4:f(/tailwindcss v4/g),layer:f(/@layer/g),dvh:f(/\d+dvh/g),inset:f(/[;{]inset:/g),gapFlex:f(/gap:/g),oklch:f(/oklch\(/g),where:f(/:where\(/g),at:f(/\.at\(/g),replaceAll:f(/replaceAll\(/g),hasOwn:f(/Object\.hasOwn/g),sclone:f(/structuredClone/g),nullAssign:f(/\?\?=|\|\|=|&&=/g),findLast:f(/findLast/g)});}
console.table(rows);
console.log('keys total',Object.keys(G).length);
