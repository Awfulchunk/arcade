import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.stream.*;
import com.toughandj.arcade.needle.NeedleHttp;
public class Probe0 { public static void main(String[] a) throws Exception {
  NewPipe.init(NeedleHttp.get());
  for (String u : a) { try {
    StreamInfo si = StreamInfo.getInfo(ServiceList.YouTube, u);
    System.out.println("TITLE "+si.getName()+" dur="+si.getDuration());
    for (AudioStream s : si.getAudioStreams()) System.out.println(" A itag="+s.getItag()+" "+s.getFormat()+" "+s.getAverageBitrate()+" dt="+s.getDeliveryMethod()+" size="+(s.getItagItem()!=null?s.getItagItem().getContentLength():-1));
    for (VideoStream s : si.getVideoStreams()) System.out.println(" V itag="+s.getItag()+" "+s.getFormat()+" "+s.getResolution()+" "+s.getDeliveryMethod());
    for (VideoStream s : si.getVideoOnlyStreams()) System.out.println(" VO itag="+s.getItag()+" "+s.getFormat()+" "+s.getResolution()+" "+s.getDeliveryMethod());
  } catch (Exception e) { System.out.println("ERR "+u+" "+e); Throwable c=e.getCause(); while(c!=null){System.out.println("  cause "+c);c=c.getCause();} } }
}}
