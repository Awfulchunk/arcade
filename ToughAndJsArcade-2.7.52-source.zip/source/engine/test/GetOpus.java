import com.toughandj.arcade.needle.NeedleCore; import java.io.File; import java.util.concurrent.atomic.AtomicBoolean;
public class GetOpus { public static void main(String[] a) throws Exception { NeedleCore.Probe p=NeedleCore.probe(a[0]); NeedleCore.Option o=NeedleCore.find(p,"audio","a251");
 System.out.println(NeedleCore.download(o.audioUrl,new File(a[1]),o.audioBytes,null,new AtomicBoolean())); }}
