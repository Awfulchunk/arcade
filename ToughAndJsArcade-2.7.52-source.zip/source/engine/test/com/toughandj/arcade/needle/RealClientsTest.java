package com.toughandj.arcade.needle;

import java.io.File;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Real YouTube from this machine: each reader on its own (read + 1 KB stream check + a real audio download), then the full fallback. */
public class RealClientsTest {
    public static void main(String[] a) throws Exception {
        NeedleCore.init();
        String[] vids = a.length > 0 ? a : new String[]{"jNQXAC9IVRw", "aqz-KE-bpKQ"};
        List<NeedleYouTube.Client> cl = Arrays.asList(new NeedleYouTube.VisionOs(), new NeedleYouTube.AndroidVr(), new NeedleYouTube.TvSamsung());
        for (String v : vids) for (NeedleYouTube.Client c : cl) {
            long t0 = System.currentTimeMillis();
            String res;
            try {
                NeedleCore.Probe p = c.read(v); p.client = c.name();
                String chk; try { NeedleYouTube.streamCheck(p); chk = "streams OK"; } catch (NeedleCore.NeedleError e) { chk = "stream check " + e.code; }
                String dl = "";
                if (chk.equals("streams OK")) {
                    NeedleCore.Option o = null; for (NeedleCore.Option x : p.audio) if (x.id.equals("a140")) o = x;
                    if (o != null) { File f = File.createTempFile("rctest", ".m4a"); try { long n = NeedleCore.download(o.audioUrl, f, o.audioBytes, null, new AtomicBoolean(), p.userAgent); dl = " | a140 download " + n + "/" + o.audioBytes + (n == o.audioBytes ? " OK" : " SHORT"); } catch (NeedleCore.NeedleError e) { dl = " | a140 download " + e.code; } finally { f.delete(); } }
                }
                res = "read OK \"" + p.title + "\" audio=" + p.audio.size() + " video=" + p.video.size() + " | " + chk + dl;
            } catch (NeedleCore.NeedleError e) { res = "FAIL " + e.code + ": " + NeedleCore.clip(e.getMessage()); }
            catch (Throwable e) { res = "CRASH " + e; }
            System.out.println(v + " " + c.name() + " (" + (System.currentTimeMillis() - t0) + " ms): " + res);
        }
        for (String v : vids) {
            NeedleYouTube y = NeedleYouTube.get(); y.log.clear();
            long t0 = System.currentTimeMillis();
            List<String> notes = new ArrayList<>();
            try { NeedleCore.Probe p = y.probe(v, null, s -> { if (!s.isEmpty()) notes.add(s); }, new AtomicBoolean()); System.out.println("FALLBACK " + v + " -> " + p.client + " in " + (System.currentTimeMillis() - t0) + " ms; attempts " + y.log + " notes " + notes + " remembered=" + y.preferred()); }
            catch (NeedleCore.NeedleError e) { System.out.println("FALLBACK " + v + " -> ERROR " + e.code + " after " + (System.currentTimeMillis() - t0) + " ms; attempts " + y.log + " notes " + notes); }
        }
    }
}
