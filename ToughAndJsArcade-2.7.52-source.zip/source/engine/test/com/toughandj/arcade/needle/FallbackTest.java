package com.toughandj.arcade.needle;

import com.sun.net.httpserver.HttpServer;
import java.io.File;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** 2.7.51 unit tests: auto-retry/backoff + reader fallback order, with simulated bot-checks (no network). */
public class FallbackTest {
    static int pass, fail;
    static void ok(boolean c, String what) { if (c) pass++; else fail++; System.out.println((c ? "PASS " : "FAIL ") + what); }

    /** scripted fake reader: each call pops the next outcome ("ok", or an error code) */
    static final class Fake implements NeedleYouTube.Client {
        final String n; final Deque<String> script; int calls; String url = "https://x.invalid/s";
        Fake(String n, String... s) { this.n = n; this.script = new ArrayDeque<>(Arrays.asList(s)); }
        public String name() { return n; }
        public NeedleCore.Probe read(String id) throws NeedleCore.NeedleError {
            calls++;
            String s = script.isEmpty() ? "ok" : script.pop();
            if (s.equals("boom")) throw new IllegalStateException("simulated bug");
            if (!s.equals("ok")) throw new NeedleCore.NeedleError(s, "simulated " + s);
            NeedleCore.Probe p = NeedleYouTube.newProbe(id); p.title = "T-" + n;
            NeedleYouTube.Fmt m = new NeedleYouTube.Fmt(); m.type = 'm'; m.itag = 18; m.container = "mp4"; m.height = 360; m.url = url; m.bytes = 300_000;
            NeedleYouTube.Fmt a = new NeedleYouTube.Fmt(); a.type = 'a'; a.itag = 140; a.container = "m4a"; a.codec = "aac"; a.kbps = 128; a.url = url; a.bytes = 300_000;
            NeedleYouTube.buildOptions(p, Arrays.asList(m, a));
            return p;
        }
    }
    static final List<Long> slept = new ArrayList<>();
    static NeedleYouTube.Sleeper rec = (ms, c) -> { if (c.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled."); slept.add(ms); };
    static NeedleYouTube yt(NeedleYouTube.Checker ch, Fake... f) { slept.clear(); return new NeedleYouTube(new ArrayList<>(Arrays.asList(f)), ch, rec); }
    static String code(Exception e) { return e instanceof NeedleCore.NeedleError ? ((NeedleCore.NeedleError) e).code : e.toString(); }

    public static void main(String[] args) throws Exception {
        List<String> notes = new ArrayList<>();
        NeedleYouTube.Notes nt = s -> { if (!s.isEmpty()) notes.add(s); };

        // 1 default reader works: one call, no waiting
        Fake v = new Fake("visionos"), r = new Fake("android_vr"), t = new Fake("tv_samsung");
        NeedleYouTube y = yt(null, v, r, t);
        NeedleCore.Probe p = y.probe("abcdefghijk", null, nt, null);
        ok("visionos".equals(p.client) && v.calls == 1 && r.calls == 0 && slept.isEmpty(), "1 default reader first, no retries when it works");

        // 2 bot-check on default -> next reader, remembered for the session
        v = new Fake("visionos", "bot", "bot"); r = new Fake("android_vr"); t = new Fake("tv_samsung"); notes.clear();
        y = yt(null, v, r, t);
        p = y.probe("abcdefghijk", null, nt, null);
        ok("android_vr".equals(p.client) && slept.isEmpty() && "android_vr".equals(y.preferred()), "2 bot on visionos -> android_vr in the same round, remembered");
        ok(notes.contains("YouTube busy, trying another way…"), "2b note while switching reader: " + notes);
        p = y.probe("zzzzzzzzzzz", null, nt, null);
        ok("android_vr".equals(p.client) && v.calls == 1 && r.calls == 2, "2c next video goes to the remembered reader first (visionos not asked again)");

        // 3 every reader bot-checked twice, works in round 3: backoff 4 s then 8 s, notes 2/3 and 3/3
        v = new Fake("visionos", "bot", "bot"); r = new Fake("android_vr", "bot", "bot"); t = new Fake("tv_samsung", "bot", "bot"); notes.clear();
        y = yt(null, v, r, t);
        p = y.probe("abcdefghijk", null, nt, null);
        ok("visionos".equals(p.client) && slept.equals(Arrays.asList(4000L, 8000L)), "3 works on round 3 after waits " + slept);
        ok(notes.contains("YouTube busy, retrying (2/3)") && notes.contains("YouTube busy, retrying (3/3)"), "3b retry notes shown: " + new LinkedHashSet<>(notes));
        ok(y.log.equals(Arrays.asList("1:visionos:bot", "1:android_vr:bot", "1:tv_samsung:bot", "2:visionos:bot", "2:android_vr:bot", "2:tv_samsung:bot", "3:visionos:ok")), "3c exact attempt order " + y.log);

        // 4 never works: 3 rounds x 3 readers, total simulated wait 12 s, final error is the bot-check (Try again / Home-PC text)
        v = new Fake("visionos", "bot", "bot", "bot"); r = new Fake("android_vr", "forbidden", "forbidden", "forbidden"); t = new Fake("tv_samsung", "changed", "changed", "changed");
        y = yt(null, v, r, t);
        try { y.probe("abcdefghijk", null, nt, null); ok(false, "4 should fail"); }
        catch (NeedleCore.NeedleError e) {
            long total = 0; for (long s : slept) total += s;
            ok("bot".equals(e.code) && total == 12000 && v.calls == 3 && r.calls == 3, "4 gives up after 3 rounds, 12 s of waiting, best error = bot (" + e.code + ", tv calls " + t.calls + ")");
            ok(t.calls == 1, "4b reader with broken code path (changed) is skipped for the rest of the session");
        }

        // 5 terminal errors stop at once (age / private / region / paid)
        for (String c : new String[]{"age", "private", "region", "paid"}) {
            v = new Fake("visionos", c); r = new Fake("android_vr");
            y = yt(null, v, r);
            try { y.probe("abcdefghijk", null, null, null); ok(false, "5 " + c); }
            catch (NeedleCore.NeedleError e) { ok(c.equals(e.code) && r.calls == 0 && slept.isEmpty(), "5 " + c + " is final: no other reader, no retry"); }
        }

        // 6 stream links answer 403 on the 1 KB check -> next reader
        final AtomicInteger checks = new AtomicInteger();
        NeedleYouTube.Checker ch = pr -> { checks.incrementAndGet(); if (pr.client.equals("visionos")) throw new NeedleCore.NeedleError("forbidden", "403"); };
        v = new Fake("visionos"); r = new Fake("android_vr");
        y = yt(ch, v, r);
        p = y.probe("abcdefghijk", null, null, null);
        ok("android_vr".equals(p.client) && checks.get() == 2, "6 403 on visionos stream check -> android_vr used");

        // 7 "unavailable" everywhere is not transient: no retry rounds
        v = new Fake("visionos", "unavailable"); r = new Fake("android_vr", "unavailable");
        y = yt(null, v, r);
        try { y.probe("abcdefghijk", null, null, null); ok(false, "7"); }
        catch (NeedleCore.NeedleError e) { ok("unavailable".equals(e.code) && slept.isEmpty() && v.calls == 1, "7 unavailable on every reader -> no pointless waiting"); }

        // 8 "unavailable" on one reader (e.g. made-for-kids on visionOS) but another works
        v = new Fake("visionos", "unavailable"); r = new Fake("android_vr");
        y = yt(null, v, r);
        ok("android_vr".equals(y.probe("abcdefghijk", null, null, null).client), "8 reader-specific 'unavailable' falls through to the next reader");

        // 9 avoid list: readers that just failed for this video go last
        v = new Fake("visionos"); r = new Fake("android_vr"); t = new Fake("tv_samsung");
        y = yt(null, v, r, t);
        List<String> ord = new ArrayList<>(); for (NeedleYouTube.Client c : y.order(new HashSet<>(Collections.singletonList("visionos")))) ord.add(c.name());
        ok(ord.equals(Arrays.asList("android_vr", "tv_samsung", "visionos")), "9 avoid order " + ord);
        y.preferred = "tv_samsung"; ord.clear(); for (NeedleYouTube.Client c : y.order(Collections.emptySet())) ord.add(c.name());
        ok(ord.equals(Arrays.asList("tv_samsung", "visionos", "android_vr")), "9b remembered reader first " + ord);

        // 10 a crashing reader doesn't kill the read
        v = new Fake("visionos", "boom"); r = new Fake("android_vr");
        y = yt(null, v, r);
        ok("android_vr".equals(y.probe("abcdefghijk", null, null, null).client), "10 RuntimeException in a reader -> next reader");

        // 11 cancel: before start, and during the real backoff wait (must stop within ~0.3 s, not after 4 s)
        v = new Fake("visionos", "bot", "bot", "bot");
        y = new NeedleYouTube(new ArrayList<>(Collections.singletonList(v)), null, NeedleYouTube::realSleep);
        AtomicBoolean cancel = new AtomicBoolean(true);
        try { y.probe("abcdefghijk", null, null, cancel); ok(false, "11"); } catch (NeedleCore.NeedleError e) { ok("cancelled".equals(e.code) && v.calls == 0, "11 cancelled before start"); }
        final AtomicBoolean c2 = new AtomicBoolean();
        new Thread(() -> { try { Thread.sleep(500); } catch (InterruptedException ignored) {} c2.set(true); }).start();
        long t0 = System.currentTimeMillis();
        try { y.probe("abcdefghijk", null, null, c2); ok(false, "11b"); }
        catch (NeedleCore.NeedleError e) { long dt = System.currentTimeMillis() - t0; ok("cancelled".equals(e.code) && dt < 1000, "11b cancel during backoff stops in " + dt + " ms"); }

        // 12 real backoff timing with a reader that always says bot: about 12 s of waiting in total (10-20 s window)
        v = new Fake("visionos", "bot", "bot", "bot");
        y = new NeedleYouTube(new ArrayList<>(Collections.singletonList(v)), null, NeedleYouTube::realSleep);
        t0 = System.currentTimeMillis();
        try { y.probe("abcdefghijk", null, null, new AtomicBoolean()); } catch (NeedleCore.NeedleError e) {
            long dt = System.currentTimeMillis() - t0; ok("bot".equals(e.code) && dt >= 11900 && dt < 14000 && v.calls == 3, "12 real waits: 3 tries over " + dt + " ms");
        }

        // 13 jobs: the stream 403s mid-pull on one reader -> pull restarts on the other reader, status shows the note, file is right
        NeedleCore.testAllowLoopback = true;
        byte[] body = new byte[300_000]; new Random(7).nextBytes(body);
        HttpServer srv = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        srv.createContext("/bad", ex -> { ex.sendResponseHeaders(403, -1); ex.close(); });
        srv.createContext("/good", ex -> {
            String rg = ex.getRequestHeaders().getFirst("Range"); long a = 0, b = body.length - 1;
            if (rg != null) { String[] s = rg.replace("bytes=", "").split("-"); a = Long.parseLong(s[0]); if (s.length > 1 && !s[1].isEmpty()) b = Math.min(b, Long.parseLong(s[1])); }
            ex.getResponseHeaders().add("Content-Range", "bytes " + a + "-" + b + "/" + body.length);
            ex.sendResponseHeaders(rg != null ? 206 : 200, b - a + 1);
            try (OutputStream o = ex.getResponseBody()) { o.write(body, (int) a, (int) (b - a + 1)); }
        });
        srv.start();
        String base = "http://127.0.0.1:" + srv.getAddress().getPort();
        Fake bad = new Fake("visionos"); bad.url = base + "/bad";
        Fake good = new Fake("android_vr"); good.url = base + "/good";
        final List<String> seenNotes = Collections.synchronizedList(new ArrayList<>());
        NeedleYouTube.Sleeper slow = (ms, c) -> { try { Thread.sleep(400); } catch (InterruptedException ignored) {} };
        NeedleYouTube.install(new NeedleYouTube(new ArrayList<>(Arrays.asList(bad, good)), null, slow));
        File work = new File("/tmp/needle-fallback-test"); 
        NeedleJobs jobs = new NeedleJobs(work, null);
        String id = jobs.start("{\"url\":\"https://youtu.be/abcdefghijk\",\"kind\":\"video\",\"option\":\"m18\",\"format\":\"mp3\"}");
        String st = "";
        for (int i = 0; i < 200; i++) { st = jobs.status(id); int k = st.indexOf("\"note\":\""); if (k > 0) { String n = st.substring(k + 8, st.indexOf('"', k + 8)); if (!n.isEmpty()) seenNotes.add(n); } if (st.contains("\"state\":\"done\"") || st.contains("\"state\":\"error\"")) break; Thread.sleep(25); }
        File out = jobs.output(id);
        ok(st.contains("\"state\":\"done\"") && st.contains("\"client\":\"android_vr\"") && out != null && Arrays.equals(java.nio.file.Files.readAllBytes(out.toPath()), body), "13 403 mid-pull -> re-read on android_vr, byte-exact file: " + st.replaceAll("\"probe\".*", ""));
        ok(seenNotes.contains("YouTube busy, retrying (2/3)"), "13b status note during the retry: " + new LinkedHashSet<>(seenNotes));

        // 14 jobs: 403 on every reader -> real error after 3 tries, no partial files left
        good.url = base + "/bad";
        String id2 = jobs.start("{\"url\":\"https://youtu.be/bbbbbbbbbbb\",\"kind\":\"video\",\"option\":\"m18\",\"format\":\"mp3\"}");
        for (int i = 0; i < 200; i++) { st = jobs.status(id2); if (st.contains("\"state\":\"error\"") || st.contains("\"state\":\"done\"")) break; Thread.sleep(25); }
        String[] left = work.list();
        ok(st.contains("\"code\":\"forbidden\"") && st.contains("\"note\":\"\"") && left != null && left.length <= 1, "14 403 everywhere -> honest 403 error, note cleared, no partials (" + (left == null ? 0 : left.length) + " files incl. job 13's output)");

        // 15 jobs: cancel during the retry wait
        good.url = base + "/bad";
        NeedleYouTube.install(new NeedleYouTube(new ArrayList<>(Arrays.asList(bad, good)), null, NeedleYouTube::realSleep));
        String id3 = jobs.start("{\"url\":\"https://youtu.be/ccccccccccc\",\"kind\":\"video\",\"option\":\"m18\",\"format\":\"mp3\"}");
        for (int i = 0; i < 200; i++) { st = jobs.status(id3); if (st.contains("retrying")) break; Thread.sleep(20); }
        jobs.cancel(id3); t0 = System.currentTimeMillis();
        for (int i = 0; i < 200; i++) { st = jobs.status(id3); if (!st.contains("\"state\":\"running\"")) break; Thread.sleep(20); }
        ok(st.contains("\"state\":\"cancelled\""), "15 cancel during the retry wait -> cancelled in " + (System.currentTimeMillis() - t0) + " ms");

        // 16 probe job (what the quality sheet polls) shows the note while it waits, then the probe
        Fake pv = new Fake("visionos", "bot"); Fake pr2 = new Fake("android_vr", "bot");
        NeedleYouTube.install(new NeedleYouTube(new ArrayList<>(Arrays.asList(pv, pr2)), null, slow));
        String pid = jobs.probe("https://youtube.com/shorts/ddddddddddd?si=x");
        Set<String> pn = new LinkedHashSet<>();
        for (int i = 0; i < 200; i++) { st = jobs.status(pid); int k = st.indexOf("\"note\":\""); if (k > 0) { String n = st.substring(k + 8, st.indexOf('"', k + 8)); if (!n.isEmpty()) pn.add(n); } if (st.contains("\"state\":\"done\"")) break; Thread.sleep(20); }
        ok(st.contains("\"state\":\"done\"") && st.contains("\"client\":\"visionos\"") && pn.contains("YouTube busy, retrying (2/3)"), "16 probe status notes " + pn);

        srv.stop(0); NeedleYouTube.install(null); NeedleCore.testAllowLoopback = false;
        System.out.println("FallbackTest: " + pass + " pass, " + fail + " fail");
        System.exit(fail == 0 ? 0 : 1);
    }
}
