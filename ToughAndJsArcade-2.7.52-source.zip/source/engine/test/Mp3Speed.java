import com.toughandj.arcade.needle.NeedleMp3; import java.io.*;
public class Mp3Speed { public static void main(String[] a) throws Exception {
  byte[] raw = java.nio.file.Files.readAllBytes(new File(a[0]).toPath()); int ch=Integer.parseInt(a[1]), sr=Integer.parseInt(a[2]);
  short[] s = new short[raw.length/2]; for(int i=0;i<s.length;i++) s[i]=(short)((raw[2*i]&0xff)|(raw[2*i+1]<<8));
  long t=System.nanoTime(); try(OutputStream o=new BufferedOutputStream(new FileOutputStream(a[3]))){ NeedleMp3 m=new NeedleMp3(ch,sr,Integer.parseInt(a[4]),o);
  int F=4096; for(int f=0; f< s.length/ch; f+=F){ int n=Math.min(F,s.length/ch-f); short[] c=new short[n*ch]; System.arraycopy(s,f*ch,c,0,n*ch); m.writePcm16(c,n,ch);} m.finish(); }
  double sec=(System.nanoTime()-t)/1e9, dur=(double)s.length/ch/sr; System.out.printf("encoded %.1fs audio in %.2fs = %.1fx realtime%n",dur,sec,dur/sec);
}}
