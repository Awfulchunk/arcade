import com.toughandj.arcade.needle.NeedleCore; import com.toughandj.arcade.needle.NeedleCore.*;
import java.io.*; import java.util.concurrent.atomic.AtomicBoolean;
public class NeedleTest {
  static int pass=0, fail=0;
  static void ok(boolean c, String n){ if(c){pass++;System.out.println("PASS "+n);} else {fail++;System.out.println("FAIL "+n);} }
  public static void main(String[] a) throws Exception {
    String[][] ids = {
      {"https://www.youtube.com/watch?v=jNQXAC9IVRw","jNQXAC9IVRw"},{"youtube.com/shorts/aqz-KE-bpKQ?si=Xy12_ab","aqz-KE-bpKQ"},
      {"https://youtu.be/jNQXAC9IVRw?si=AbCdEf123","jNQXAC9IVRw"},{"https://m.youtube.com/watch?v=jNQXAC9IVRw&feature=share","jNQXAC9IVRw"},
      {"https://music.youtube.com/watch?v=jNQXAC9IVRw&list=RD","jNQXAC9IVRw"},{"https://www.youtube.com/shorts/aqz-KE-bpKQ","aqz-KE-bpKQ"},
      {"https://www.youtube.com/embed/jNQXAC9IVRw","jNQXAC9IVRw"},{"https://www.youtube.com/live/jNQXAC9IVRw?si=x","jNQXAC9IVRw"},
      {"https://www.youtube.com/watch?feature=x&v=jNQXAC9IVRw","jNQXAC9IVRw"},{"https://www.youtube.com/playlist?list=PL123",null},
      {"https://example.com/watch?v=jNQXAC9IVRw",null},{"https://youtu.be/short",null}};
    for (String[] t: ids){ String got=NeedleCore.youtubeId(t[0]); ok(t[1]==null?got==null:t[1].equals(got),"id "+t[0]+" -> "+got); }
    ok(NeedleCore.isPrivateHost("192.168.1.20")&&NeedleCore.isPrivateHost("localhost")&&!NeedleCore.isPrivateHost("example.com"),"private host check");
    File dir=new File(a.length>0?a[0]:"/tmp/needle-test"); dir.mkdirs();
    // ---- real YouTube probes
    for (String u: new String[]{"https://youtu.be/jNQXAC9IVRw?si=test","https://youtube.com/shorts/aqz-KE-bpKQ?si=abc"}) {
      try { Probe p=NeedleCore.probe(u); System.out.println("  "+p.title+" "+p.durationSec+"s audio="+p.audio.size()+" video="+p.video.size());
        for (Option o: p.audio) System.out.println("    A "+o.id+" "+o.label+" "+o.bytes+" | "+o.detail);
        for (Option o: p.video) System.out.println("    V "+o.id+" "+o.label+" "+o.bytes+" | "+o.detail);
        ok(!p.audio.isEmpty() && !p.video.isEmpty(),"probe "+u);
        String js=NeedleCore.toJson(p); ok(js.startsWith("{\"ok\":true")&&!js.contains("googlevideo"),"json has no stream urls");
      } catch (NeedleError e){ ok(false,"probe "+u+" -> "+e.code+": "+e.getMessage()); }
    }
    // ---- real YouTube downloads (zoo: small)
    try { Probe p=NeedleCore.probe("https://www.youtube.com/watch?v=jNQXAC9IVRw");
      Option au=null; for(Option o:p.audio) if("aac".equals(o.codec)){au=o;break;}
      long n=NeedleCore.download(au.audioUrl,new File(dir,"yt-audio.m4a"),au.audioBytes,null,new AtomicBoolean());
      ok(n==au.audioBytes,"yt audio bytes "+n+"/"+au.audioBytes);
      Option v=null; for(Option o:p.video) if(o.merge){v=o;} // lowest merged
      final long[] last={0}; long nv=NeedleCore.download(v.videoUrl,new File(dir,"yt-video.mp4"),v.videoBytes,(d,t)->last[0]=d,new AtomicBoolean());
      ok(nv==v.videoBytes && last[0]==nv,"yt video-only bytes "+nv+" ("+v.label+") progress "+last[0]);
      // cancel test
      AtomicBoolean c=new AtomicBoolean(); try { NeedleCore.download(au.audioUrl,new File(dir,"cancel.m4a"),au.audioBytes,(d,t)->{ if(d>50000)c.set(true);},c); ok(false,"cancel"); }
      catch(NeedleError e){ ok("cancelled".equals(e.code)&&!new File(dir,"cancel.m4a").exists(),"cancel stops + deletes partial"); }
    } catch (NeedleError e){ ok(false,"yt download "+e.code+": "+e.getMessage()); }
    // ---- bigger: BBB 1080p option presence + 4-chunk download
    try { Probe p=NeedleCore.probe("https://www.youtube.com/watch?v=aqz-KE-bpKQ");
      Option v=null; for(Option o:p.video) if(o.merge && o.height==360) v=o;
      long nv=NeedleCore.download(v.videoUrl,new File(dir,"bbb-360.mp4"),v.videoBytes,null,new AtomicBoolean());
      ok(nv==v.videoBytes && nv>NeedleCore_CHUNK(),"multi-chunk download "+nv+" bytes");
    } catch (NeedleError e){ ok(false,"bbb "+e.code+": "+e.getMessage()); }
    // ---- error mapping
    try { NeedleCore.probe("https://www.youtube.com/watch?v=xxxxxxxxxxx"); ok(false,"bad id should fail"); } catch(NeedleError e){ System.out.println("  bad id -> "+e.code+": "+e.getMessage()); ok(true,"bad id gives plain error"); }
    try { NeedleCore.probe("https://example.com/"); ok(false,"html page"); } catch(NeedleError e){ ok("notfile".equals(e.code),"web page refused: "+e.getMessage()); }
    try { NeedleCore.probe("http://192.168.1.1/a.mp3"); ok(false,"lan"); } catch(NeedleError e){ ok("private".equals(e.code),"LAN link blocked"); }
    // ---- direct file
    for (String u: new String[]{"https://www.w3schools.com/html/horse.mp3","https://download.samplelib.com/mp4/sample-5s.mp4","https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm"}) {
      try { Probe p=NeedleCore.probe(u); Option o=(p.video.isEmpty()?p.audio:p.video).get(0);
        long n=NeedleCore.download(o.videoUrl!=null?o.videoUrl:o.audioUrl,new File(dir,"direct-"+p.fileName),o.bytes,null,new AtomicBoolean());
        ok(n>1000 && (o.bytes<0||n==o.bytes),"direct "+u+" "+n+" bytes kind="+o.kind+" ext="+o.ext);
      } catch(NeedleError e){ ok(false,"direct "+u+" "+e.code+": "+e.getMessage()); }
    }
    System.out.println("RESULT pass="+pass+" fail="+fail); System.exit(fail==0?0:1);
  }
  static long NeedleCore_CHUNK(){ return 9L*1024*1024; }
}
