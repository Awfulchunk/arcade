import com.toughandj.arcade.needle.streams.*; import java.io.*;
public class MuxTest { public static void main(String[] a) throws Exception {
  String mode=a[0];
  if(mode.equals("merge")){ SharpStream v=new FileSharp(new File(a[1]),false), au=new FileSharp(new File(a[2]),false), o=new FileSharp(new File(a[3]),true);
    Mp4FromDashWriter w=new Mp4FromDashWriter(v,au); w.parseSources(); w.selectTracks(0,0); w.build(o); w.close(); o.close(); }
  else if(mode.equals("m4a")){ SharpStream au=new FileSharp(new File(a[1]),false), o=new FileSharp(new File(a[2]),true);
    Mp4FromDashWriter w=new Mp4FromDashWriter(au); w.setMainBrand(0x4D344120); w.parseSources(); w.selectTracks(0); w.build(o); w.close(); o.close(); }
  else if(mode.equals("ogg")){ SharpStream au=new FileSharp(new File(a[1]),false), o=new FileSharp(new File(a[2]),true);
    OggFromWebMWriter w=new OggFromWebMWriter(au,o,null); w.parseSource(); w.selectTrack(0); w.build(); w.close(); o.close(); }
  System.out.println("ok "+mode);
}}
