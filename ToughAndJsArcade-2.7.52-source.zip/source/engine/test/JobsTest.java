import com.toughandj.arcade.needle.*; import java.io.*; import java.util.concurrent.atomic.AtomicBoolean;
/** Runs NeedleJobs end to end on the JVM. The Android MediaCodec decoder is stood in for by ffmpeg->PCM, then the REAL NeedleMp3 encoder. */
public class JobsTest {
  static int pass=0, fail=0; static void ok(boolean c,String n){ if(c){pass++;System.out.println("PASS "+n);}else{fail++;System.out.println("FAIL "+n);} }
  static short[] pcm(File in,int[] fmt) throws Exception { Process p=new ProcessBuilder("ffmpeg","-v","error","-i",in.getPath(),"-f","s16le","-ac","2","-ar","44100","-").start();
    byte[] b=p.getInputStream().readAllBytes(); p.waitFor(); fmt[0]=2; fmt[1]=44100; short[] s=new short[b.length/2]; for(int i=0;i<s.length;i++) s[i]=(short)((b[2*i]&0xff)|(b[2*i+1]<<8)); return s; }
  public static void main(String[] a) throws Exception {
    File work=new File("/tmp/needle-jobs"); 
    NeedleJobs.Converter conv=new NeedleJobs.Converter(){
      public void mp3(File in, File out, int kbps, AtomicBoolean c, NeedleJobs.NeedleMedia_Frac f) throws NeedleCore.NeedleError { try{ int[] fm=new int[2]; short[] s=pcm(in,fm); try(OutputStream o=new BufferedOutputStream(new FileOutputStream(out))){ NeedleMp3 m=new NeedleMp3(fm[0],fm[1],kbps,o); int F=4096; for(int i=0;i<s.length/2;i+=F){ if(c.get()) throw new NeedleCore.NeedleError("cancelled","Cancelled."); int n=Math.min(F,s.length/2-i); short[] ch=new short[n*2]; System.arraycopy(s,i*2,ch,0,n*2); m.writePcm16(ch,n,2); f.at((double)i/(s.length/2)); } m.finish(); } } catch(NeedleCore.NeedleError e){throw e;} catch(Exception e){ throw new NeedleCore.NeedleError("encode",e.toString()); } }
      public void wav(File in, File out, AtomicBoolean c, NeedleJobs.NeedleMedia_Frac f) throws NeedleCore.NeedleError { try{ new ProcessBuilder("ffmpeg","-v","error","-y","-i",in.getPath(),"-c:a","pcm_s16le",out.getPath()).start().waitFor(); }catch(Exception e){ throw new NeedleCore.NeedleError("encode",e.toString()); } }
      public void aacToM4a(File in, File out, AtomicBoolean c) throws NeedleCore.NeedleError { try{ new ProcessBuilder("ffmpeg","-v","error","-y","-i",in.getPath(),"-vn","-c:a","copy","-f","ipod",out.getPath()).start().waitFor(); }catch(Exception e){ throw new NeedleCore.NeedleError("encode",e.toString()); } }
    };
    NeedleJobs J=new NeedleJobs(work,conv);
    String yt="https://youtu.be/jNQXAC9IVRw?si=jaytest";
    String pid=J.probe(yt); String st=waitFor(J,pid); ok(st.contains("\"state\":\"done\"")&&st.contains("\"probe\":{"),"probe job: "+st.substring(0,Math.min(160,st.length())));
    String[][] runs={ {yt,"audio","a140","mp3","192","mp3"},{yt,"audio","a140","m4a","192","m4a"},{yt,"audio","a251","ogg","192","ogg"},{yt,"audio","a251","mp3","128","mp3"},{yt,"audio","a140","wav","192","wav"},{yt,"video","v133+a140","mp3","192","mp4"},
      {"https://www.w3schools.com/html/horse.mp3","audio","file","mp3","192","mp3"},{"https://download.samplelib.com/mp4/sample-5s.mp4","video","file","mp3","192","mp4"},{"https://download.samplelib.com/mp4/sample-5s.mp4","audio","file","mp3","256","mp3"},
      {"https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm","video","file","mp3","192","webm"},{"https://download.samplelib.com/mp4/sample-5s.mp4","audio","file","ogg","192","ERR"}};
    File outDir=new File("/tmp/needle-out"); outDir.mkdirs();
    for(String[] r: runs){
      String spec="{\"url\":\""+r[0]+"\",\"kind\":\""+r[1]+"\",\"option\":\""+r[2]+"\",\"format\":\""+r[3]+"\",\"bitrate\":"+r[4]+"}";
      String id=J.start(spec); String s=waitFor(J,id);
      if(r[5].equals("ERR")){ ok(s.contains("\"state\":\"error\"")&&s.contains("noopus"),"honest refusal "+r[1]+"/"+r[3]+": "+s.replaceAll(".*\"error\":\"([^\"]*)\".*","$1")); continue; }
      File f=J.output(id); boolean good=f!=null&&s.contains("\"state\":\"done\"");
      String probe=""; if(good){ File keep=new File(outDir,r[2].replace('+','_')+"-"+r[3]+"."+r[5]); java.nio.file.Files.copy(f.toPath(),keep.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        Process p=new ProcessBuilder("ffprobe","-v","error","-show_entries","stream=codec_name:format=format_name,duration,bit_rate","-of","csv=p=0",keep.getPath()).redirectErrorStream(true).start(); probe=new String(p.getInputStream().readAllBytes()).replace('\n',' '); }
      String name=s.replaceAll(".*\"name\":\"([^\"]*)\".*","$1");
      ok(good && name.endsWith("."+r[5]),r[1]+" "+r[2]+" -> "+r[3]+": "+name+" | "+probe);
      J.release(id); ok(f==null||!f.exists(),"release deletes native copy");
    }
    // cancel mid-download on a big one
    String bid=J.start("{\"url\":\"https://www.youtube.com/watch?v=aqz-KE-bpKQ\",\"kind\":\"video\",\"option\":\"v134+a140\",\"format\":\"mp3\",\"bitrate\":192}");
    long t0=System.currentTimeMillis(); while(System.currentTimeMillis()-t0<60000){ String s=J.status(bid); if(s.contains("\"progress\":") && !s.contains("\"progress\":0.0")&&!s.contains("\"progress\":1.0")&&s.contains("running")) break; Thread.sleep(100);} 
    J.cancel(bid); String cs=waitFor(J,bid); ok(cs.contains("\"state\":\"cancelled\""),"cancel mid-download: "+cs.substring(0,Math.min(140,cs.length())));
    File[] left=work.listFiles(); ok(left==null||left.length==0,"no partial files left after cancel ("+(left==null?0:left.length)+")");
    ok(J.status("nope").contains("gone"),"unknown job is reported gone");
    System.out.println("RESULT pass="+pass+" fail="+fail); System.exit(fail==0?0:1);
  }
  static String waitFor(NeedleJobs J,String id) throws Exception { for(int i=0;i<3000;i++){ String s=J.status(id); if(!s.contains("\"state\":\"running\"")&&!s.contains("\"state\":\"queued\"")) return s; Thread.sleep(100);} return J.status(id); }
}
