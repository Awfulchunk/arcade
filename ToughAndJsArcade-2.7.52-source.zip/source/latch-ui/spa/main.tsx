import { useState } from "react";
import { createRoot } from "react-dom/client";
import { Comic } from "@/components/bench/comic";
import { Editor } from "@/components/bench/editor";
import { GuideCtx, Tips } from "@/components/bench/vtr";
import "../src/vtr.css";

// Latch 2.0 "VTR-1": the ? badges (qmarks.ts) are gone; help is hold-for-tip balloons plus the ? Guide.
function Home() {
  const [mode, setMode] = useState<"clip" | "comic">("clip");
  const [guide, setGuide] = useState(false);
  return (
    <GuideCtx.Provider value={{ guide, setGuide }}>
      <div className={mode === "clip" ? "" : "vtr-hide"} style={mode === "clip" ? { height: "100%" } : { display: "none" }}>
        <Editor onComic={() => setMode("comic")} />
      </div>
      <div style={mode === "comic" ? { height: "100%" } : { display: "none" }}>
        <Comic active={mode === "comic"} onClip={() => setMode("clip")} />
      </div>
      <Tips />
    </GuideCtx.Provider>
  );
}

createRoot(document.getElementById("root")!).render(<Home />);
