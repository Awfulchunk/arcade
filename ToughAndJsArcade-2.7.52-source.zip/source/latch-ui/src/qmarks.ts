// "?" badge next to every Latch button: tap it to see what that button does.
const HELP: Record<string, [string, string]> = {
  "open": ["Open", "Bring in a video, a GIF, or a still picture from your phone."],
  "open a video, gif, or still": ["Open", "Bring in a video, a GIF, or a still picture from your phone."],
  "comic page": ["Comic page", "Leave the clip bench and lay out a comic, manga, or webtoon page from stills."],
  "what each tool does": ["Help", "Opens the full guide to every tool, with examples."],
  "what this does": ["Help", "Opens the full guide to every tool, with examples."],
  "what comic mode does": ["Help", "Opens the guide for comic pages."],
  "unlock assist": ["Assist lock", "Unlocks the Assist bar, which reads the frame and suggests grade and crop sliders. It never redraws the picture."],
  "lock assist": ["Assist lock", "Hides the Assist bar again."],
  "undo": ["Undo", "Steps back one cut, crop, or sticker move."],
  "play": ["Play", "Starts and stops the clip. The big circle on the picture does the same."],
  "pause": ["Pause", "Stops the clip where it is."],
  "trim": ["Trim", "Choose where the clip starts and ends. Step by one frame or ten under the picture."],
  "bounce": ["Bounce", "Plays forward then back, on the picture and in the saved GIF."],
  "crop": ["Crop", "Drag the frame to cut the picture down. Corners resize it."],
  "grade": ["Grade", "Light, contrast, color, and warmth sliders. The picture updates as you move them."],
  "stickers": ["Stickers", "Put a sticker, picture, or text on the clip and drag it where you want."],
  "join": ["Join", "Stack scenes and extra clips, choose cut, fade, or dip between them, then play the reel."],
  "end result": ["End result", "Shows a small preview of exactly what you would save, crop and all."],
  "comic": ["Comic", "Switches to comic page mode."],
  "clips": ["Clips", "Goes back to the clip bench."],
  "save": ["Save", "Saves your work as a still, a GIF, or a comic page."],
  "save page": ["Save page", "Saves the comic page as one picture."],
  "add pictures": ["Add pictures", "Pick stills from your phone to put on the page."],
  "add": ["Add", "Pick stills from your phone to put on the page."],
  "order": ["Order", "Tap panels in the order they should be read, 1, 2, 3."],
  "bubbles": ["Bubbles", "Lay speech bubbles on the page and type what they say."],
  "format": ["Format", "Switch the page between comic, manga, and webtoon layouts."],
  "\u221210": ["Back 10 frames", "Moves the playhead back ten frames."],
  "\u22121": ["Back 1 frame", "Moves the playhead back one frame."],
  "+1": ["Forward 1 frame", "Moves the playhead forward one frame."],
  "+10": ["Forward 10 frames", "Moves the playhead forward ten frames."],
  "in\u2212": ["In \u2212", "Moves the start of the cut one frame earlier."],
  "in+": ["In +", "Moves the start of the cut one frame later."],
  "out\u2212": ["Out \u2212", "Moves the end of the cut one frame earlier."],
  "out+": ["Out +", "Moves the end of the cut one frame later."],
  "set in": ["Set in", "Marks the current frame as where the cut starts."],
  "set out": ["Set out", "Marks the current frame as where the cut ends."],
  "split": ["Split", "Cuts the clip at the playhead into two pieces so a fade or dip can sit between them."],
  "loop": ["Loop", "At the end the clip jumps to the start and plays again."],
  "0.5\u00d7": ["Speed", "Plays at half speed."],
  "1\u00d7": ["Speed", "Plays at normal speed."],
  "1.5\u00d7": ["Speed", "Plays one and a half times faster."],
  "2\u00d7": ["Speed", "Plays twice as fast."],
  "hold here": ["Hold here", "Freezes this frame for a moment in the saved GIF."],
  "smooth": ["Smooth", "Blends each frame with the one before so choppy GIFs look softer."],
  "slower": ["Slower", "Half speed, on the picture and in the saved GIF."],
  "reverse": ["Reverse", "Plays the clip backward."],
  "s": ["Small", "Small size."],
  "m": ["Medium", "Medium size."],
  "l": ["Large", "Large size."],
  "keep": ["Keep", "Stores these settings on this phone. Tap the number that appears to put them back."],
  "done": ["Done", "Saves what you typed and closes this box."],
  "cut": ["Cut", "Jump straight from one scene to the next."],
  "fade": ["Fade", "Blend one scene into the next."],
  "dip": ["Dip", "Dip to black between scenes."],
  "keep this scene": ["Keep this scene", "Keeps this piece of the reel in the join."],
  "split here": ["Split here", "Cuts the scene at the playhead."],
  "add clip": ["Add clip", "Adds another clip or GIF to the join."],
  "play join": ["Play join", "Plays the whole reel with the cuts and fades."],
  "gif": ["GIF", "Add a GIF to the reel."],
  "save joined gif": ["Save joined GIF", "Saves the whole reel as one GIF."],
  "save still": ["Save still", "Saves this one frame as a picture."],
  "save gif": ["Save GIF", "Saves the cut, crop, grade, loop and bounce as a GIF."],
  "bounce off": ["Bounce off", "Turns bounce off again."],
  "nudge left": ["Nudge left", "Moves the picked panel a little left."],
  "nudge right": ["Nudge right", "Moves the picked panel a little right."],
  "nudge up": ["Nudge up", "Moves the picked panel a little up."],
  "nudge down": ["Nudge down", "Moves the picked panel a little down."],
  "sound off": ["Sound", "Mutes the clip."],
  "sound on": ["Sound", "Turns the clip sound on."],
  "reading order": ["Order", "Tap panels in the order they should be read."],
  "page format": ["Format", "Switch the page between comic, manga, and webtoon layouts."],
};
const key = (b: HTMLElement) => ((b.getAttribute("aria-label") || b.textContent || "").trim().toLowerCase());
const lookup = (b: HTMLElement): [string, string] | null => {
  const k = key(b);
  if (HELP[k]) return HELP[k];
  const t = (b.textContent || "").trim().toLowerCase();
  if (HELP[t]) return HELP[t];
  if (/^hold\b/.test(t)) return HELP["hold here"];
  if (/^(before|after)/.test(t)) return ["Before / After", "Pick which part of the reel you are editing."];
  if (/^\d+$/.test(t)) return ["Kept setting", "Tap to put back the settings you stored with Keep."];
  if (k.startsWith("panel ")) return ["Panel", "A picture on the page. Tap to select it."];
  if (k.startsWith("remove panel")) return ["Remove panel", "Takes this picture off the page."];
  return null;
};
let pop: HTMLDivElement | null = null;
function show(title: string, text: string) {
  hide();
  pop = document.createElement("div");
  pop.setAttribute("data-qpop", "1");
  pop.style.cssText = "position:fixed;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom) + 96px);z-index:9999;background:#fff;color:#111;border:2px solid #000;padding:12px 14px;font:500 15px/1.35 system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.5);max-width:420px;margin:0 auto";
  pop.innerHTML = "<b style='display:block;font-size:16px;margin-bottom:4px'></b><span></span><div style='margin-top:8px;font-size:12px;opacity:.6'>Tap anywhere to close</div>";
  (pop.querySelector("b") as HTMLElement).textContent = title;
  (pop.querySelector("span") as HTMLElement).textContent = text;
  document.body.appendChild(pop);
  setTimeout(() => document.addEventListener("pointerdown", hide, { once: true, capture: true }), 50);
}
function hide() {
  if (pop) { pop.remove(); pop = null; }
}
function decorate() {
  document.querySelectorAll<HTMLElement>("button").forEach((b) => {
    if (b.querySelector(":scope > .qm") || b.closest("[data-qpop]")) return;
    const h = lookup(b);
    if (!h) return;
    const r = b.getBoundingClientRect();
    if (r.width < 8) return;
    const q = document.createElement("span");
    q.className = "qm";
    q.textContent = "?";
    q.setAttribute("role", "note");
    q.setAttribute("data-t", h[0]);
    q.setAttribute("data-d", h[1]);
    const cs = getComputedStyle(b);
    if (cs.position === "static") b.style.position = "relative";
    b.appendChild(q);
  });
}
let raf = 0;
export function installQMarks() {
  const style = document.createElement("style");
  style.textContent = ".qm{position:absolute;top:-6px;right:-4px;width:17px;height:17px;border-radius:50%;background:#ffd24a;color:#111;border:1.5px solid #111;font:800 11px/14px system-ui,sans-serif;text-align:center;z-index:30;pointer-events:auto;padding:0}";
  document.head.appendChild(style);
  const grab = (e: Event) => {
    const t = e.target as HTMLElement;
    if (t && t.classList && t.classList.contains("qm")) {
      e.preventDefault();
      e.stopPropagation();
      if (e.type === "click") show(t.getAttribute("data-t") || "", t.getAttribute("data-d") || "");
    }
  };
  for (const ev of ["pointerdown", "pointerup", "mousedown", "mouseup", "touchstart", "click"]) document.addEventListener(ev, grab, true);
  const run = () => { raf = 0; decorate(); };
  new MutationObserver(() => { if (!raf) raf = requestAnimationFrame(run); }).observe(document.body, { childList: true, subtree: true });
  decorate();
}
