import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Comic } from "@/components/bench/comic";
import { Editor } from "@/components/bench/editor";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [mode, setMode] = useState<"clip" | "comic">("clip");
  return (
    <>
      <div className={mode === "clip" ? "h-dvh" : "hidden"}>
        <Editor onComic={() => setMode("comic")} />
      </div>
      <div className={mode === "comic" ? "h-dvh" : "hidden"}>
        <Comic active={mode === "comic"} onClip={() => setMode("clip")} />
      </div>
    </>
  );
}
