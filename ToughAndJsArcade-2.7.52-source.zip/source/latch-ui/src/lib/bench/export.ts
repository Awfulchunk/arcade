import { cropPixels, gifBudget, planMotion, slowedDelay, stem, type Adj, type Crop, type Motion } from "@/lib/bench/model";
import { renderCrop } from "@/lib/bench/draw";
import type { Dress } from "@/lib/bench/overlay";

export type Look = {
  rot: number;
  flip: boolean;
  crop: Crop;
  adj: Adj;
  dress: Dress | null;
};

export type GifTiming = {
  slowMid: number;
  holdAt: number | null;
  holdMs: number;
};

const BAYER = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];

function clamp8(n: number) {
  return n < 0 ? 0 : n > 255 ? 255 : n;
}

function mapDither(data: Uint8ClampedArray, w: number, h: number, palette: number[][]) {
  const idx = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    const row = BAYER[y & 3]!;
    for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4;
      const j = ((row[x & 3] ?? 0) - 7.5) * 2.2;
      const r = clamp8((data[o] ?? 0) + j);
      const g = clamp8((data[o + 1] ?? 0) + j);
      const b = clamp8((data[o + 2] ?? 0) + j);
      let best = 0;
      let bestD = 1e12;
      for (let i = 0; i < palette.length; i++) {
        const p = palette[i]!;
        const dr = r - (p[0] ?? 0);
        const dg = g - (p[1] ?? 0);
        const db = b - (p[2] ?? 0);
        const d = dr * dr * 2 + dg * dg * 4 + db * db;
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      }
      idx[y * w + x] = best;
    }
  }
  return idx;
}

export function seek(video: HTMLVideoElement, time: number): Promise<void> {
  return new Promise((resolve) => {
    const duration = Number.isFinite(video.duration) ? video.duration : time;
    const t = Math.min(Math.max(time, 0), Math.max(0, duration - 0.001));
    if (Math.abs(video.currentTime - t) < 0.02 && video.readyState >= 2) {
      resolve();
      return;
    }
    const done = () => {
      video.removeEventListener("seeked", done);
      resolve();
    };
    video.addEventListener("seeked", done);
    window.setTimeout(done, 1200);
    try {
      video.currentTime = t;
    } catch {
      done();
    }
  });
}

function download(blob: Blob, filename: string) {
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = filename;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function canvasBlob(canvas: HTMLCanvasElement, type: string, quality?: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("empty"))), type, quality);
  });
}

export async function exportStill(
  source: CanvasImageSource,
  natW: number,
  natH: number,
  look: Look,
  filename: string,
) {
  const size = cropPixels(natW, natH, look.rot, look.crop, 1600);
  const canvas = document.createElement("canvas");
  canvas.width = size.w;
  canvas.height = size.h;
  renderCrop(canvas, source, natW, natH, look.rot, look.flip, look.crop, look.adj, look.dress);
  const blob = await canvasBlob(canvas, "image/png");
  download(blob, `${stem(filename)}-still.png`);
}

function mixHalf(a: Uint8ClampedArray, b: Uint8ClampedArray) {
  const out = new Uint8ClampedArray(a.length);
  for (let i = 0; i < a.length; i += 4) {
    out[i] = ((a[i] ?? 0) + (b[i] ?? 0)) >> 1;
    out[i + 1] = ((a[i + 1] ?? 0) + (b[i + 1] ?? 0)) >> 1;
    out[i + 2] = ((a[i + 2] ?? 0) + (b[i + 2] ?? 0)) >> 1;
    out[i + 3] = 255;
  }
  return out;
}

export async function exportGif(opts: {
  video?: HTMLVideoElement;
  paintAt?: (time: number) => CanvasImageSource | null;
  baked?: boolean;
  natW: number;
  natH: number;
  look: Look;
  inPoint: number;
  outPoint: number;
  fps: number;
  linger: number;
  motion: Motion;
  timing: GifTiming;
  edge: number;
  forever: boolean;
  open: boolean;
  filename: string;
  signal: AbortSignal;
  onProgress: (pct: number) => void;
}): Promise<"clamped" | "ok"> {
  const budget = gifBudget(opts.open);
  const span = Math.max(0.05, opts.outPoint - opts.inPoint);
  const used = Math.min(span, budget.maxSpan);
  const end = opts.inPoint + used;
  const fps = Math.min(Math.max(6, opts.fps), budget.maxFps);
  const step = 1 / fps;
  const times: number[] = [];
  for (let t = opts.inPoint; t < end - 0.02 && times.length < budget.maxFrames; t += step) times.push(t);
  if (times.length === 0) times.push(opts.inPoint);
  const { ops, oneWay } = planMotion(times, opts.motion, budget.maxFrames);

  const size = cropPixels(opts.natW, opts.natH, opts.look.rot, opts.look.crop, Math.min(opts.edge, budget.maxEdge));
  const canvas = document.createElement("canvas");
  canvas.width = size.w;
  canvas.height = size.h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("canvas");

  const take = async (t: number, target: HTMLCanvasElement) => {
    if (opts.paintAt) {
      const frame = opts.paintAt(t);
      if (!frame) throw new Error("frame");
      if (opts.baked) {
        const tctx = target.getContext("2d");
        if (!tctx) throw new Error("canvas");
        tctx.setTransform(1, 0, 0, 1, 0, 0);
        tctx.clearRect(0, 0, target.width, target.height);
        tctx.drawImage(frame, 0, 0, target.width, target.height);
        return;
      }
      renderCrop(target, frame, opts.natW, opts.natH, opts.look.rot, opts.look.flip, opts.look.crop, opts.look.adj, opts.look.dress);
      return;
    }
    if (!opts.video) throw new Error("video");
    await seek(opts.video, t);
    renderCrop(target, opts.video, opts.natW, opts.natH, opts.look.rot, opts.look.flip, opts.look.crop, opts.look.adj, opts.look.dress);
  };

  const { GIFEncoder, quantize } = await import("gifenc");
  const sample = document.createElement("canvas");
  sample.width = 96;
  sample.height = 54;
  const chunks: Uint8ClampedArray[] = [];
  const picks = [times[0]!, times[Math.floor(times.length / 2)]!, times[times.length - 1]!];
  for (const t of picks) {
    if (opts.signal.aborted) throw new DOMException("aborted", "AbortError");
    await take(t, sample);
    const sctx = sample.getContext("2d");
    if (sctx) chunks.push(new Uint8ClampedArray(sctx.getImageData(0, 0, 96, 54).data));
  }
  const merged = new Uint8ClampedArray(chunks.reduce((n, c) => n + c.length, 0));
  let off = 0;
  for (const c of chunks) {
    merged.set(c, off);
    off += c.length;
  }
  const palette = quantize(merged, 128);
  if (!palette.length) throw new Error("palette");

  const gif = GIFEncoder();
  let delay = Math.max(20, Math.round((used * 1000) / Math.max(1, oneWay)));
  if (opts.motion.slower) delay = Math.min(500, delay * 2);
  let holdIndex = -1;
  if (opts.timing.holdAt != null && opts.timing.holdMs > 20) {
    let best = 1e9;
    for (let i = 0; i < ops.length; i++) {
      const op = ops[i]!;
      const t = "t" in op ? op.t : (op.a + op.b) / 2;
      const dist = Math.abs(t - opts.timing.holdAt);
      if (dist < best) {
        best = dist;
        holdIndex = i;
      }
    }
  }
  const held = new Map<number, Uint8ClampedArray>();
  const pixelsAt = async (t: number) => {
    const hit = held.get(t);
    if (hit) return hit;
    if (opts.signal.aborted) throw new DOMException("aborted", "AbortError");
    await take(t, canvas);
    const copy = new Uint8ClampedArray(ctx.getImageData(0, 0, size.w, size.h).data);
    held.set(t, copy);
    if (held.size > 4) {
      const oldest = held.keys().next().value;
      if (oldest !== undefined) held.delete(oldest);
    }
    return copy;
  };

  for (let i = 0; i < ops.length; i++) {
    if (opts.signal.aborted) throw new DOMException("aborted", "AbortError");
    const op = ops[i]!;
    const opTime = "t" in op ? op.t : (op.a + op.b) / 2;
    const u = Math.min(1, Math.max(0, (opTime - opts.inPoint) / used));
    let frameDelay = opts.timing.slowMid > 0 ? slowedDelay(delay, u, opts.timing.slowMid) : delay;
    if (i === holdIndex) frameDelay = Math.min(2000, frameDelay + opts.timing.holdMs);
    const frame = "t" in op ? await pixelsAt(op.t) : mixHalf(await pixelsAt(op.a), await pixelsAt(op.b));
    const index = mapDither(frame, size.w, size.h, palette);
    const last = i === ops.length - 1;
    gif.writeFrame(index, size.w, size.h, {
      palette: i === 0 ? palette : null,
      delay: last ? frameDelay + Math.max(0, opts.linger) : frameDelay,
      repeat: i === 0 ? (opts.forever ? 0 : -1) : undefined,
    });
    opts.onProgress((i + 1) / ops.length);
    await new Promise((r) => window.setTimeout(r, 0));
  }
  gif.finish();
  const bytes = gif.bytes();
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  download(new Blob([copy], { type: "image/gif" }), `${stem(opts.filename)}.gif`);
  return used + 0.05 < span ? "clamped" : "ok";
}

export async function exportClip(opts: {
  video: HTMLVideoElement;
  natW: number;
  natH: number;
  look: Look;
  inPoint: number;
  outPoint: number;
  filename: string;
  signal: AbortSignal;
}) {
  if (typeof MediaRecorder === "undefined") throw new Error("recorder");
  const size = cropPixels(opts.natW, opts.natH, opts.look.rot, opts.look.crop, 960);
  const canvas = document.createElement("canvas");
  canvas.width = size.w;
  canvas.height = size.h;
  canvas.style.cssText = "position:fixed;left:0;top:0;width:2px;height:2px;opacity:0;pointer-events:none";
  document.body.appendChild(canvas);
  try {
    opts.video.pause();
    await seek(opts.video, opts.inPoint);
    renderCrop(canvas, opts.video, opts.natW, opts.natH, opts.look.rot, opts.look.flip, opts.look.crop, opts.look.adj, opts.look.dress);
    const stream = canvas.captureStream(24);
    const withCap = opts.video as HTMLVideoElement & { captureStream?: () => MediaStream };
    if (withCap.captureStream) {
      try {
        withCap.captureStream().getAudioTracks().forEach((t) => stream.addTrack(t));
      } catch {
        /* picture only */
      }
    }
    const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
      ? "video/webm;codecs=vp8,opus"
      : MediaRecorder.isTypeSupported("video/webm;codecs=vp8")
        ? "video/webm;codecs=vp8"
        : "video/webm";
    const rec = new MediaRecorder(stream, { mimeType: mime });
    const chunks: Blob[] = [];
    rec.ondataavailable = (e) => {
      if (e.data.size) chunks.push(e.data);
    };
    const stopped = new Promise<void>((resolve, reject) => {
      rec.onstop = () => resolve();
      rec.onerror = () => reject(new Error("record"));
    });
    rec.start(200);
    await opts.video.play();
    await new Promise<void>((resolve) => {
      const tick = () => {
        if (opts.signal.aborted || opts.video.currentTime >= opts.outPoint - 0.02 || opts.video.paused) {
          opts.video.pause();
          if (rec.state !== "inactive") rec.stop();
          resolve();
          return;
        }
        renderCrop(canvas, opts.video, opts.natW, opts.natH, opts.look.rot, opts.look.flip, opts.look.crop, opts.look.adj, opts.look.dress);
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    await stopped;
    const blob = new Blob(chunks, { type: mime });
    if (blob.size < 80) throw new Error("empty");
    download(blob, `${stem(opts.filename)}.webm`);
  } finally {
    canvas.remove();
  }
}
