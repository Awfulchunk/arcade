import { renderCrop } from "@/lib/bench/draw";
import { DEFAULT_ADJ, FULL, clamp, oriented, type Adj, type Crop } from "@/lib/bench/model";

export function gradeFromPixels(data: Uint8ClampedArray): Pick<Adj, "light" | "contrast" | "color" | "warmth"> {
  const bins = new Uint32Array(256);
  let n = 0;
  let rSum = 0;
  let bSum = 0;
  let satSum = 0;
  const step = data.length > 160 * 160 * 4 ? 16 : 4;
  for (let i = 0; i < data.length; i += step) {
    const r = data[i] ?? 0;
    const g = data[i + 1] ?? 0;
    const b = data[i + 2] ?? 0;
    const y = (r * 54 + g * 183 + b * 19) >> 8;
    bins[y]! += 1;
    n += 1;
    rSum += r;
    bSum += b;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    satSum += max === 0 ? 0 : (max - min) / max;
  }
  if (n < 1) return { light: 1, contrast: 1, color: 1, warmth: 0 };
  const at = (p: number) => {
    const target = Math.max(1, n * p);
    let acc = 0;
    for (let i = 0; i < 256; i++) {
      acc += bins[i] ?? 0;
      if (acc >= target) return i / 255;
    }
    return 1;
  };
  const lo = at(0.02);
  const hi = at(0.98);
  const span = Math.max(0.08, hi - lo);
  const mid = Math.max(0.06, (lo + hi) / 2);
  const light = clamp(0.5 / mid, 0.45, 1.75);
  const contrast = clamp((1.8 * mid) / span, 0.7, 1.65);
  const sat = satSum / n;
  const color = clamp(sat < 0.16 ? 1.28 : sat < 0.3 ? 1.12 : 1, 0, 2);
  const warmth = clamp((bSum - rSum) / n / 140, 0, 0.8);
  return { light, contrast, color, warmth };
}

export function subjectCrop(data: Uint8ClampedArray, w: number, h: number, ratio: number | null): Crop {
  if (w < 8 || h < 8) return FULL;
  const gray = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const o = i * 4;
    gray[i] = (data[o] ?? 0) * 0.2126 + (data[o + 1] ?? 0) * 0.7152 + (data[o + 2] ?? 0) * 0.0722;
  }
  const energy = new Float32Array(w * h);
  let maxE = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const gx = (gray[i + 1] ?? 0) - (gray[i - 1] ?? 0);
      const gy = (gray[i + w] ?? 0) - (gray[i - w] ?? 0);
      const v = Math.abs(gx) + Math.abs(gy);
      energy[i] = v;
      if (v > maxE) maxE = v;
    }
  }
  if (maxE < 8) return FULL;
  const thr = maxE * 0.28;
  let sx = 0;
  let sy = 0;
  let sw = 0;
  let x2 = 0;
  let y2 = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const v = energy[y * w + x] ?? 0;
      if (v < thr) continue;
      sx += x * v;
      sy += y * v;
      sw += v;
      x2 += x * x * v;
      y2 += y * y * v;
    }
  }
  if (sw < 1) return FULL;
  const cx = (sx / sw) * 0.84 + (w / 2) * 0.16;
  const cy = (sy / sw) * 0.84 + (h / 2) * 0.16;
  const devX = Math.sqrt(Math.max(4, x2 / sw - (sx / sw) * (sx / sw)));
  const devY = Math.sqrt(Math.max(4, y2 / sw - (sy / sw) * (sy / sw)));
  let bw = clamp(devX * 4.4, w * 0.32, w * 0.92);
  let bh = clamp(devY * 4.4, h * 0.32, h * 0.92);
  if (ratio != null && ratio > 0) {
    if (bw / bh > ratio) bh = bw / ratio;
    else bw = bh * ratio;
    if (bw > w * 0.96) {
      bw = w * 0.96;
      bh = bw / ratio;
    }
    if (bh > h * 0.96) {
      bh = h * 0.96;
      bw = bh * ratio;
    }
    bw = Math.min(bw, w);
    bh = Math.min(bh, h);
  }
  let x = cx - bw / 2;
  let y = cy - bh / 2;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x + bw > w) x = w - bw;
  if (y + bh > h) y = h - bh;
  return {
    x: clamp(x / w, 0, 1),
    y: clamp(y / h, 0, 1),
    w: clamp(bw / w, 0.08, 1),
    h: clamp(bh / h, 0.08, 1),
  };
}

export function grabFrame(
  source: CanvasImageSource,
  natW: number,
  natH: number,
  rot: number,
  flip: boolean,
  crop: Crop,
): { data: Uint8ClampedArray; w: number; h: number } | null {
  const o = oriented(natW, natH, rot);
  const long = Math.max(o.w * crop.w, o.h * crop.h, 1);
  const scale = Math.min(1, 160 / long);
  let w = Math.max(8, Math.round(o.w * crop.w * scale));
  let h = Math.max(8, Math.round(o.h * crop.h * scale));
  if (w % 2) w = Math.max(8, w - 1);
  if (h % 2) h = Math.max(8, h - 1);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  renderCrop(canvas, source, natW, natH, rot, flip, crop, DEFAULT_ADJ);
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  const data = ctx.getImageData(0, 0, w, h).data;
  return { data, w, h };
}

export function suggestGrade(
  source: CanvasImageSource,
  natW: number,
  natH: number,
  rot: number,
  flip: boolean,
  crop: Crop,
): Pick<Adj, "light" | "contrast" | "color" | "warmth"> | null {
  const frame = grabFrame(source, natW, natH, rot, flip, crop);
  if (!frame) return null;
  return gradeFromPixels(frame.data);
}

export function suggestCrop(
  source: CanvasImageSource,
  natW: number,
  natH: number,
  rot: number,
  flip: boolean,
  ratio: number | null,
): Crop | null {
  const frame = grabFrame(source, natW, natH, rot, flip, FULL);
  if (!frame) return null;
  return subjectCrop(frame.data, frame.w, frame.h, ratio);
}
