import type { Shape } from "@/lib/bench/model";

export type Sticker = {
  id: string;
  name: string;
  x: number;
  y: number;
  scale: number;
  rot: number;
  bend: number;
  tint: number;
  tintColor: string;
  shadow: number;
};

export type Caption = {
  id: string;
  text: string;
  x: number;
  y: number;
  size: number;
  color: string;
};

export type StickerAsset = {
  img: HTMLImageElement;
  mask: HTMLCanvasElement;
  url: string;
  rev: number;
  cacheKey: string;
  cache: HTMLCanvasElement | null;
};

export type Dress = {
  straight: number;
  flip: boolean;
  shape: Shape;
  stickers: Sticker[];
  captions: Caption[];
  assets: Map<string, StickerAsset>;
  blend: number;
};

export function toView(x: number, y: number, straight: number, flip: boolean) {
  let lx = x - 0.5;
  const ly = y - 0.5;
  if (flip) lx = -lx;
  const a = (straight * Math.PI) / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  return { x: 0.5 + lx * c - ly * s, y: 0.5 + lx * s + ly * c };
}

export function fromView(x: number, y: number, straight: number, flip: boolean) {
  const dx = x - 0.5;
  const dy = y - 0.5;
  const a = (-straight * Math.PI) / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  let lx = dx * c - dy * s;
  const ly = dx * s + dy * c;
  if (flip) lx = -lx;
  return { x: lx + 0.5, y: ly + 0.5 };
}

export function makeMask(img: HTMLImageElement) {
  const max = 512;
  const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight, 1));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  return canvas;
}

export function stickerSize(st: Sticker, imgW: number, imgH: number, aspect: number) {
  const w = st.scale;
  const h = st.scale * (imgH / Math.max(1, imgW)) * aspect;
  const pad = 1 + Math.abs(st.bend) * 0.42;
  return { hw: (w * pad) / 2, hh: h / 2, w, h };
}

function localOf(st: Sticker, nx: number, ny: number, straight: number, flip: boolean, aspect: number, imgW: number, imgH: number) {
  const c = toView(st.x, st.y, straight, flip);
  const dx = nx - c.x;
  const dy = ny - c.y;
  const a = (-st.rot * Math.PI) / 180;
  const cos = Math.cos(a);
  const sin = Math.sin(a);
  const lx = dx * cos - dy * sin;
  const ly = dx * sin + dy * cos;
  const size = stickerSize(st, imgW, imgH, aspect);
  return { lx, ly, size };
}

export function hitSticker(
  st: Sticker,
  asset: StickerAsset,
  nx: number,
  ny: number,
  straight: number,
  flip: boolean,
  aspect: number,
) {
  const img = asset.img;
  if (!img.naturalWidth) return false;
  const { lx, ly, size } = localOf(st, nx, ny, straight, flip, aspect, img.naturalWidth, img.naturalHeight);
  return Math.abs(lx) <= size.hw && Math.abs(ly) <= size.hh;
}

export function stickerUV(
  st: Sticker,
  asset: StickerAsset,
  nx: number,
  ny: number,
  straight: number,
  flip: boolean,
  aspect: number,
) {
  const img = asset.img;
  if (!img.naturalWidth) return null;
  const { lx, ly, size } = localOf(st, nx, ny, straight, flip, aspect, img.naturalWidth, img.naturalHeight);
  if (Math.abs(lx) > size.hw || Math.abs(ly) > size.hh) return null;
  const v = ly / Math.max(0.0001, size.h) + 0.5;
  const bendShift = Math.sin(Math.min(1, Math.max(0, v)) * Math.PI) * st.bend * size.w * 0.42;
  const u = (lx - bendShift) / Math.max(0.0001, size.w) + 0.5;
  if (u < -0.02 || v < -0.02 || u > 1.02 || v > 1.02) return null;
  return { u, v };
}

export function eraseAt(asset: StickerAsset, u: number, v: number, radius: number) {
  const ctx = asset.mask.getContext("2d");
  if (!ctx) return;
  const x = u * asset.mask.width;
  const y = v * asset.mask.height;
  const r = Math.max(8, radius * asset.mask.width);
  ctx.save();
  ctx.globalCompositeOperation = "destination-out";
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  asset.rev += 1;
  asset.cache = null;
}

function strips(ctx: CanvasRenderingContext2D, source: CanvasImageSource, sw: number, sh: number, dw: number, dh: number, bend: number) {
  if (Math.abs(bend) < 0.02) {
    ctx.drawImage(source, 0, 0, sw, sh, 0, 0, dw, dh);
    return;
  }
  const n = 28;
  for (let i = 0; i < n; i++) {
    const t = (i + 0.5) / n;
    const ox = Math.sin(t * Math.PI) * bend * dw * 0.42;
    const sy = (sh * i) / n;
    const she = sh / n + 1;
    ctx.drawImage(source, 0, sy, sw, she, ox, (dh * i) / n, dw, dh / n + 1);
  }
}

function stickerBitmap(st: Sticker, asset: StickerAsset) {
  const key = `${st.bend.toFixed(3)}|${st.tint.toFixed(3)}|${st.tintColor}|${asset.rev}`;
  if (asset.cache && asset.cacheKey === key) return asset.cache;
  const img = asset.img;
  const maxW = 480;
  const dw = maxW;
  const dh = Math.max(1, Math.round((maxW * img.naturalHeight) / Math.max(1, img.naturalWidth)));
  const canvas = document.createElement("canvas");
  canvas.width = dw;
  canvas.height = dh;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  strips(ctx, img, img.naturalWidth, img.naturalHeight, dw, dh, st.bend);
  const mask = document.createElement("canvas");
  mask.width = dw;
  mask.height = dh;
  const mctx = mask.getContext("2d");
  if (mctx) {
    strips(mctx, asset.mask, asset.mask.width, asset.mask.height, dw, dh, st.bend);
    ctx.globalCompositeOperation = "destination-in";
    ctx.drawImage(mask, 0, 0);
    ctx.globalCompositeOperation = "source-over";
  }
  if (st.tint > 0.01) {
    ctx.save();
    ctx.globalCompositeOperation = "source-atop";
    ctx.globalAlpha = Math.min(1, st.tint);
    ctx.fillStyle = st.tintColor;
    ctx.fillRect(0, 0, dw, dh);
    ctx.restore();
  }
  asset.cache = canvas;
  asset.cacheKey = key;
  return canvas;
}

export function paintOverlays(
  ctx: CanvasRenderingContext2D,
  dress: Dress,
  fx: number,
  fy: number,
  fw: number,
  fh: number,
) {
  for (const st of dress.stickers) {
    const asset = dress.assets.get(st.id);
    if (!asset?.img.naturalWidth) continue;
    const bmp = stickerBitmap(st, asset);
    const at = toView(st.x, st.y, dress.straight, dress.flip);
    const sw = st.scale * fw;
    const sh = sw * (bmp.height / Math.max(1, bmp.width));
    ctx.save();
    ctx.translate(fx + at.x * fw, fy + at.y * fh);
    ctx.rotate((st.rot * Math.PI) / 180);
    if (st.shadow > 0.01) {
      ctx.save();
      ctx.filter = `blur(${Math.max(1, sw * 0.05)}px)`;
      ctx.globalAlpha = 0.5 * st.shadow;
      ctx.drawImage(bmp, -sw / 2, -sh / 2 + sh * 0.05, sw, sh);
      ctx.restore();
    }
    const mix = Math.min(1, Math.max(0, dress.blend));
    if (mix > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = "multiply";
      ctx.globalAlpha = mix;
      ctx.drawImage(bmp, -sw / 2, -sh / 2, sw, sh);
      ctx.restore();
      ctx.globalAlpha = 1 - mix * 0.65;
    }
    ctx.drawImage(bmp, -sw / 2, -sh / 2, sw, sh);
    ctx.globalAlpha = 1;
    ctx.restore();
  }
  for (const cap of dress.captions) {
    const text = cap.text.trim();
    if (!text) continue;
    const at = toView(cap.x, cap.y, dress.straight, dress.flip);
    ctx.save();
    ctx.translate(fx + at.x * fw, fy + at.y * fh);
    ctx.fillStyle = cap.color;
    ctx.font = `500 ${Math.max(10, cap.size * fh)}px Outfit, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text.slice(0, 48), 0, 0);
    ctx.restore();
  }
}

export function hitCaption(cap: Caption, nx: number, ny: number, straight: number, flip: boolean, aspect: number) {
  const at = toView(cap.x, cap.y, straight, flip);
  const hh = cap.size * 0.65;
  const hw = Math.max(0.06, (cap.text.length * cap.size * 0.32) / Math.max(0.2, aspect));
  return Math.abs(nx - at.x) <= hw && Math.abs(ny - at.y) <= hh;
}

let shapeScratch: HTMLCanvasElement | null = null;

export function applyShape(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, shape: Shape) {
  if (shape === "none" || w < 2 || h < 2) return;
  if (shape === "frame") {
    ctx.save();
    ctx.strokeStyle = "rgba(243,239,230,0.92)";
    ctx.lineWidth = Math.max(2, Math.min(w, h) * 0.035);
    const inset = ctx.lineWidth;
    ctx.strokeRect(x + inset, y + inset, w - inset * 2, h - inset * 2);
    ctx.restore();
    return;
  }
  const iw = Math.max(1, Math.round(w));
  const ih = Math.max(1, Math.round(h));
  if (!shapeScratch) shapeScratch = document.createElement("canvas");
  if (shapeScratch.width !== iw || shapeScratch.height !== ih) {
    shapeScratch.width = iw;
    shapeScratch.height = ih;
  }
  const sctx = shapeScratch.getContext("2d");
  if (!sctx) return;
  sctx.setTransform(1, 0, 0, 1, 0, 0);
  sctx.globalCompositeOperation = "source-over";
  sctx.clearRect(0, 0, iw, ih);
  sctx.drawImage(ctx.canvas, x, y, w, h, 0, 0, iw, ih);
  sctx.globalCompositeOperation = "destination-in";
  if (shape === "circle") {
    sctx.fillStyle = "#fff";
    sctx.beginPath();
    sctx.ellipse(iw / 2, ih / 2, iw / 2, ih / 2, 0, 0, Math.PI * 2);
    sctx.fill();
  } else {
    const r = Math.min(iw, ih) * 0.5;
    const g = sctx.createRadialGradient(iw / 2, ih / 2, r * 0.55, iw / 2, ih / 2, r);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.78, "rgba(255,255,255,1)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    sctx.fillStyle = g;
    sctx.fillRect(0, 0, iw, ih);
  }
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();
  ctx.fillStyle = "#1a212b";
  ctx.fillRect(x, y, w, h);
  ctx.drawImage(shapeScratch, x, y, w, h);
  ctx.restore();
}
