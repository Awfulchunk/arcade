import type { Adj, Crop } from "@/lib/bench/model";
import { applyShape, paintOverlays, type Dress } from "@/lib/bench/overlay";

export type Fit = { dx: number; dy: number; dw: number; dh: number };

function filterCss(adj: Adj, frameH: number): string {
  const contrast = adj.contrast + adj.clarity * 0.45;
  const sat = Math.max(0, adj.color + adj.clarity * 0.12);
  const blur = adj.soft * frameH * 0.012;
  const blurCss = blur > 0.4 ? ` blur(${blur.toFixed(2)}px)` : "";
  return `brightness(${adj.light}) contrast(${contrast}) saturate(${sat}) hue-rotate(${adj.tint}deg)${blurCss}`;
}

let scratch: HTMLCanvasElement | null = null;

function bloom(canvas: HTMLCanvasElement, amount: number) {
  if (amount <= 0.01) return;
  if (!scratch) scratch = document.createElement("canvas");
  const w = canvas.width;
  const h = canvas.height;
  if (scratch.width !== w || scratch.height !== h) {
    scratch.width = w;
    scratch.height = h;
  }
  const sctx = scratch.getContext("2d");
  const ctx = canvas.getContext("2d");
  if (!sctx || !ctx) return;
  sctx.setTransform(1, 0, 0, 1, 0, 0);
  sctx.clearRect(0, 0, w, h);
  const radius = Math.min(32, (6 + amount * 16) * (h / 480));
  sctx.filter = `blur(${radius}px) brightness(1.25)`;
  sctx.drawImage(canvas, 0, 0);
  sctx.filter = "none";
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalCompositeOperation = "screen";
  ctx.globalAlpha = 0.55 * amount;
  ctx.drawImage(scratch, 0, 0);
  ctx.restore();
}

function warmth(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, amount: number) {
  if (amount <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.fillStyle = `rgba(214, 92, 36, ${Math.min(1, amount)})`;
  ctx.fillRect(x, y, w, h);
  ctx.restore();
}

function falloff(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, amount: number) {
  if (amount <= 0) return;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const g = ctx.createRadialGradient(cx, cy, Math.min(w, h) * 0.22, cx, cy, Math.max(w, h) * 0.68);
  g.addColorStop(0, "rgba(18,17,14,0)");
  g.addColorStop(1, `rgba(18,17,14,${amount})`);
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
}

export function paintStage(
  canvas: HTMLCanvasElement,
  source: CanvasImageSource,
  natW: number,
  natH: number,
  cssW: number,
  cssH: number,
  rot: number,
  flip: boolean,
  adj: Adj,
  crop: Crop,
  dress: Dress | null,
  underlay: CanvasImageSource | null,
  mix = 0.55,
): Fit {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const bw = Math.max(1, Math.round(cssW * dpr));
  const bh = Math.max(1, Math.round(cssH * dpr));
  if (canvas.width !== bw || canvas.height !== bh) {
    canvas.width = bw;
    canvas.height = bh;
  }
  const ctx = canvas.getContext("2d");
  if (!ctx || natW < 2 || natH < 2) return { dx: 0, dy: 0, dw: cssW, dh: cssH };

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#0c100e";
  ctx.fillRect(0, 0, bw, bh);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  const swap = rot % 2 === 1;
  const ow = swap ? natH : natW;
  const oh = swap ? natW : natH;
  const scale = Math.min(bw / ow, bh / oh);
  const dw = ow * scale;
  const dh = oh * scale;
  const dx = (bw - dw) / 2;
  const dy = (bh - dh) / 2;

  const pw = swap ? dh : dw;
  const ph = swap ? dw : dh;
  const straight = dress?.straight ?? 0;
  const paintSrc = (src: CanvasImageSource, alpha: number, filtered: boolean) => {
    ctx.save();
    ctx.beginPath();
    ctx.rect(dx, dy, dw, dh);
    ctx.clip();
    ctx.translate(dx + dw / 2, dy + dh / 2);
    ctx.rotate((rot * Math.PI) / 2 + (straight * Math.PI) / 180);
    ctx.scale(flip ? -1 : 1, 1);
    ctx.globalAlpha = alpha;
    ctx.filter = filtered ? filterCss(adj, dh) : "none";
    ctx.drawImage(src, -pw / 2, -ph / 2, pw, ph);
    ctx.restore();
  };
  if (underlay) paintSrc(underlay, 1, false);
  paintSrc(source, underlay ? Math.max(0.28, 1 - Math.min(1, mix) * 0.75) : 1, true);

  ctx.save();
  ctx.beginPath();
  ctx.rect(dx, dy, dw, dh);
  ctx.clip();
  warmth(ctx, dx, dy, dw, dh, adj.warmth);
  ctx.restore();

  if (adj.glow > 0) bloom(canvas, adj.glow);

  ctx.save();
  ctx.beginPath();
  ctx.rect(dx, dy, dw, dh);
  ctx.clip();
  falloff(ctx, dx, dy, dw, dh, adj.falloff);
  ctx.restore();

  if (dress && (dress.stickers.length > 0 || dress.captions.length > 0)) {
    paintOverlays(ctx, { ...dress, straight, flip }, dx, dy, dw, dh);
  }
  if (dress && dress.shape !== "none") {
    applyShape(ctx, dx + crop.x * dw, dy + crop.y * dh, crop.w * dw, crop.h * dh, dress.shape);
  }

  return { dx: dx / dpr, dy: dy / dpr, dw: dw / dpr, dh: dh / dpr };
}

export function renderCrop(
  target: HTMLCanvasElement,
  source: CanvasImageSource,
  natW: number,
  natH: number,
  rot: number,
  flip: boolean,
  crop: Crop,
  adj: Adj,
  dress?: Dress | null,
) {
  const ctx = target.getContext("2d", { willReadFrequently: true });
  if (!ctx) return;
  const tw = target.width;
  const th = target.height;
  const swap = rot % 2 === 1;
  const dw = tw / Math.max(0.0001, crop.w);
  const dh = th / Math.max(0.0001, crop.h);
  const dx = -crop.x * dw;
  const dy = -crop.y * dh;

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, tw, th);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.save();
  ctx.translate(dx + dw / 2, dy + dh / 2);
  ctx.rotate((rot * Math.PI) / 2 + ((dress?.straight ?? 0) * Math.PI) / 180);
  ctx.scale(flip ? -1 : 1, 1);
  ctx.filter = filterCss(adj, dh);
  const pw = swap ? dh : dw;
  const ph = swap ? dw : dh;
  ctx.drawImage(source, -pw / 2, -ph / 2, pw, ph);
  ctx.restore();
  warmth(ctx, 0, 0, tw, th, adj.warmth);
  if (adj.glow > 0) bloom(target, adj.glow);
  falloff(ctx, 0, 0, tw, th, adj.falloff);
  if (dress && (dress.stickers.length > 0 || dress.captions.length > 0)) {
    const fw = tw / Math.max(0.0001, crop.w);
    const fh = th / Math.max(0.0001, crop.h);
    paintOverlays(ctx, dress, -crop.x * fw, -crop.y * fh, fw, fh);
  }
  if (dress && dress.shape !== "none") applyShape(ctx, 0, 0, tw, th, dress.shape);
}
