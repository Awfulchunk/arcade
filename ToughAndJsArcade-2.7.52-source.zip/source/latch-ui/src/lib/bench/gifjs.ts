// Small pure-JS GIF decoder (LZW + frame compositing) for browsers without ImageDecoder (Android WebView < 94).
export type RawGif = { w: number; h: number; frames: { rgba: Uint8ClampedArray; delay: number }[] };

function lzw(minCode: number, data: Uint8Array, pixels: number): Uint8Array {
  const out = new Uint8Array(pixels);
  const clear = 1 << minCode;
  const eoi = clear + 1;
  const prefix = new Int16Array(4096);
  const suffix = new Uint8Array(4096);
  const stack = new Uint8Array(4097);
  let size = minCode + 1;
  let mask = (1 << size) - 1;
  let avail = clear + 2;
  let old = -1;
  let first = 0;
  let datum = 0;
  let bits = 0;
  let op = 0;
  for (let i = 0; i < clear; i++) suffix[i] = i;
  for (let p = 0; p < data.length && op < pixels; ) {
    datum |= data[p++] << bits;
    bits += 8;
    while (bits >= size && op < pixels) {
      let code = datum & mask;
      datum >>= size;
      bits -= size;
      if (code === clear) {
        size = minCode + 1;
        mask = (1 << size) - 1;
        avail = clear + 2;
        old = -1;
        continue;
      }
      if (code === eoi) return out;
      if (old === -1) {
        out[op++] = suffix[code];
        old = code;
        first = code;
        continue;
      }
      const inCode = code;
      let sp = 0;
      if (code >= avail) {
        stack[sp++] = first;
        code = old;
      }
      while (code >= clear) {
        stack[sp++] = suffix[code];
        code = prefix[code];
      }
      first = suffix[code];
      stack[sp++] = first;
      if (avail < 4096) {
        prefix[avail] = old;
        suffix[avail] = first;
        avail++;
        if ((avail & mask) === 0 && avail < 4096) {
          size++;
          mask += avail;
        }
      }
      old = inCode;
      while (sp > 0 && op < pixels) out[op++] = stack[--sp];
    }
  }
  return out;
}

export function decodeGifBytes(buf: Uint8Array, maxFrames = 180): RawGif | null {
  if (buf.length < 13 || String.fromCharCode(buf[0], buf[1], buf[2]) !== "GIF") return null;
  let p = 6;
  const W = buf[p] | (buf[p + 1] << 8);
  const H = buf[p + 2] | (buf[p + 3] << 8);
  const flags = buf[p + 4];
  const bgIndex = buf[p + 5];
  p += 7;
  let gct: Uint8Array | null = null;
  if (flags & 0x80) {
    const n = 3 * (1 << ((flags & 7) + 1));
    gct = buf.subarray(p, p + n);
    p += n;
  }
  if (W < 1 || H < 1 || W * H > 4096 * 4096) return null;
  const canvas = new Uint8ClampedArray(W * H * 4);
  let saved: Uint8ClampedArray | null = null;
  const frames: RawGif["frames"] = [];
  let delay = 0.1;
  let trans = -1;
  let dispose = 0;
  void bgIndex;
  while (p < buf.length && frames.length < maxFrames) {
    const b = buf[p++];
    if (b === 0x3b) break;
    if (b === 0x21) {
      const label = buf[p++];
      if (label === 0xf9 && buf[p] >= 4) {
        const f = buf[p + 1];
        dispose = (f >> 2) & 7;
        const d = buf[p + 2] | (buf[p + 3] << 8);
        delay = Math.max(0.02, d / 100 || 0.1);
        trans = f & 1 ? buf[p + 4] : -1;
      }
      while (p < buf.length && buf[p] !== 0) p += buf[p] + 1;
      p++;
      continue;
    }
    if (b !== 0x2c) return frames.length ? { w: W, h: H, frames } : null;
    const x = buf[p] | (buf[p + 1] << 8);
    const y = buf[p + 2] | (buf[p + 3] << 8);
    const w = buf[p + 4] | (buf[p + 5] << 8);
    const h = buf[p + 6] | (buf[p + 7] << 8);
    const f = buf[p + 8];
    p += 9;
    let table = gct;
    if (f & 0x80) {
      const n = 3 * (1 << ((f & 7) + 1));
      table = buf.subarray(p, p + n);
      p += n;
    }
    const interlaced = (f & 0x40) !== 0;
    const minCode = buf[p++];
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (p < buf.length && buf[p] !== 0) {
      const n = buf[p];
      chunks.push(buf.subarray(p + 1, p + 1 + n));
      total += n;
      p += n + 1;
    }
    p++;
    const data = new Uint8Array(total);
    let o = 0;
    for (const c of chunks) {
      data.set(c, o);
      o += c.length;
    }
    if (!table) return null;
    if (dispose === 3) saved = canvas.slice();
    const idx = lzw(minCode, data, w * h);
    const rows: number[] = [];
    if (interlaced) {
      for (const [start, step] of [[0, 8], [4, 8], [2, 4], [1, 2]]) for (let r = start; r < h; r += step) rows.push(r);
    }
    for (let r = 0; r < h; r++) {
      const ry = interlaced ? rows[r] : r;
      const cy = y + ry;
      if (cy >= H) continue;
      for (let c = 0; c < w; c++) {
        const cx = x + c;
        if (cx >= W) continue;
        const k = idx[r * w + c];
        if (k === trans) continue;
        const q = (cy * W + cx) * 4;
        canvas[q] = table[k * 3];
        canvas[q + 1] = table[k * 3 + 1];
        canvas[q + 2] = table[k * 3 + 2];
        canvas[q + 3] = 255;
      }
    }
    frames.push({ rgba: canvas.slice(), delay });
    if (dispose === 2) {
      for (let r = y; r < Math.min(H, y + h); r++) canvas.fill(0, (r * W + x) * 4, (r * W + Math.min(W, x + w)) * 4);
    } else if (dispose === 3 && saved) {
      canvas.set(saved);
    }
    trans = -1;
    dispose = 0;
    delay = 0.1;
  }
  return frames.length ? { w: W, h: H, frames } : null;
}
