import { kindOf } from "@/lib/bench/model";
import { decodeGifBytes } from "@/lib/bench/gifjs";

export type GifClip = {
  frames: ImageBitmap[];
  stamps: number[];
  duration: number;
  w: number;
  h: number;
};

export function frameAt(clip: GifClip, time: number): ImageBitmap | null {
  if (!clip.frames.length) return null;
  const t = Math.min(Math.max(time, 0), Math.max(0, clip.duration - 0.0001));
  let i = 0;
  while (i < clip.stamps.length - 1 && (clip.stamps[i + 1] ?? 0) <= t) i += 1;
  return clip.frames[i] ?? null;
}

export function closeGif(clip: GifClip | null) {
  clip?.frames.forEach((frame) => frame.close());
}

type VideoFrameLike = {
  displayWidth: number;
  displayHeight: number;
  duration: number | null;
  close: () => void;
};

type Decoder = {
  close: () => void;
  tracks: { ready: Promise<void>; selectedTrack: { frameCount: number } | null };
  decode: (opts: { frameIndex: number }) => Promise<{ image: VideoFrameLike }>;
};

export async function classifyFile(file: File): Promise<"image" | "video" | "gif" | null> {
  const named = kindOf(file);
  if (named === "video" || named === "gif") return named;
  try {
    const buf = new Uint8Array(await file.slice(0, 16).arrayBuffer());
    const text = (start: number, end: number) => String.fromCharCode(...buf.slice(start, end));
    if (text(0, 4) === "GIF8") return "gif";
    if (text(4, 8) === "ftyp") return "video";
    if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return "video";
  } catch {
    /* keep the name guess */
  }
  return named;
}

export async function decodeGif(file: File): Promise<GifClip | null> {
  const Ctor = (
    globalThis as unknown as {
      ImageDecoder?: new (init: { data: BufferSource; type: string }) => Decoder;
    }
  ).ImageDecoder;
  if (typeof createImageBitmap !== "function") return null;
  if (!Ctor) return decodeGifJs(file);
  const dec = new Ctor({ data: await file.arrayBuffer(), type: "image/gif" });
  try {
    await dec.tracks.ready;
    const track = dec.tracks.selectedTrack;
    if (!track || track.frameCount < 1) return null;
    const count = Math.min(track.frameCount, 180);
    const frames: ImageBitmap[] = [];
    const stamps: number[] = [];
    let cursor = 0;
    let w = 0;
    let h = 0;
    for (let i = 0; i < count; i++) {
      const { image } = await dec.decode({ frameIndex: i });
      w = image.displayWidth || w;
      h = image.displayHeight || h;
      const bmp = await createImageBitmap(image as unknown as ImageBitmapSource);
      const delay = Math.max(0.02, (image.duration ?? 100000) / 1e6);
      image.close();
      stamps.push(cursor);
      cursor += delay;
      frames.push(bmp);
    }
    if (!frames.length || w < 2 || h < 2) {
      frames.forEach((frame) => frame.close());
      return null;
    }
    return { frames, stamps, duration: Math.max(0.05, cursor), w, h };
  } catch {
    return null;
  } finally {
    dec.close();
  }
}

// 2.0: old Android WebViews (Chrome < 94) have no ImageDecoder, so decode the GIF in JS instead of showing a still.
async function decodeGifJs(file: File): Promise<GifClip | null> {
  try {
    const raw = decodeGifBytes(new Uint8Array(await file.arrayBuffer()), 180);
    if (!raw || raw.w < 2 || raw.h < 2) return null;
    const frames: ImageBitmap[] = [];
    const stamps: number[] = [];
    let cursor = 0;
    for (const f of raw.frames) {
      frames.push(await createImageBitmap(new ImageData(f.rgba, raw.w, raw.h)));
      stamps.push(cursor);
      cursor += f.delay;
    }
    return { frames, stamps, duration: Math.max(0.05, cursor), w: raw.w, h: raw.h };
  } catch {
    return null;
  }
}
