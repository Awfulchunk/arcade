export type Crop = { x: number; y: number; w: number; h: number };

export type Adj = {
  light: number;
  contrast: number;
  color: number;
  tint: number;
  warmth: number;
  soft: number;
  falloff: number;
  glow: number;
  clarity: number;
};

export const FULL: Crop = { x: 0, y: 0, w: 1, h: 1 };

export const DEFAULT_ADJ: Adj = {
  light: 1,
  contrast: 1,
  color: 1,
  tint: 0,
  warmth: 0,
  soft: 0,
  falloff: 0,
  glow: 0,
  clarity: 0,
};

export type Shape = "none" | "circle" | "soft" | "frame";

export type Scene = {
  id: string;
  name: string;
  inPoint: number;
  outPoint: number;
  crop: Crop;
  adj: Adj;
  rot: number;
  flip: boolean;
  ratio: number | null;
  straight: number;
  shape: Shape;
  transition?: "cut" | "fade" | "dip";
  transMs?: number;
  sourceId?: string;
};

export const ASPECTS: { id: string; label: string; ratio: number | null }[] = [
  { id: "free", label: "Free", ratio: null },
  { id: "1:1", label: "1:1", ratio: 1 },
  { id: "4:5", label: "4:5", ratio: 4 / 5 },
  { id: "3:4", label: "3:4", ratio: 3 / 4 },
  { id: "9:16", label: "9:16", ratio: 9 / 16 },
  { id: "16:9", label: "16:9", ratio: 16 / 9 },
];

export const PRESETS: { id: string; label: string; studio?: boolean; adj: Adj }[] = [
  { id: "flat", label: "Flat", adj: DEFAULT_ADJ },
  { id: "punch", label: "Punch", adj: { ...DEFAULT_ADJ, contrast: 1.22, color: 1.14 } },
  { id: "fade", label: "Fade", adj: { ...DEFAULT_ADJ, contrast: 0.86, light: 1.08, color: 0.8 } },
  {
    id: "night",
    label: "Night",
    adj: { ...DEFAULT_ADJ, light: 0.8, contrast: 1.3, color: 0.7, falloff: 0.55 },
  },
  {
    id: "lamp",
    label: "Lamp",
    studio: true,
    adj: { ...DEFAULT_ADJ, warmth: 0.62, light: 1.06, contrast: 0.92, soft: 0.8, color: 1.05 },
  },
  {
    id: "heat",
    label: "Heat",
    studio: true,
    adj: { ...DEFAULT_ADJ, warmth: 0.8, color: 1.3, contrast: 1.14 },
  },
  {
    id: "haze",
    label: "Haze",
    studio: true,
    adj: { ...DEFAULT_ADJ, glow: 0.7, light: 1.12, contrast: 0.88, clarity: 0.2 },
  },
];

const STORE = "lt.m";
const MARK = "REDACTED-set-your-own";

export function readOpen(): boolean {
  try {
    return localStorage.getItem(STORE) === "1";
  } catch {
    return false;
  }
}

export function writeOpen(open: boolean) {
  try {
    if (open) localStorage.setItem(STORE, "1");
    else localStorage.removeItem(STORE);
  } catch {
    /* private mode */
  }
}

export function accepts(value: string): boolean {
  return value.trim() === MARK;
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function kindOf(file: File): "image" | "video" | "gif" | null {
  const n = file.name.toLowerCase();
  if (file.type === "image/gif" || n.endsWith(".gif")) return "gif";
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/")) return "video";
  if (/\.(png|jpe?g|webp|bmp)$/.test(n)) return "image";
  if (/\.(mp4|webm|mov|m4v|ogv)$/.test(n)) return "video";
  return null;
}

export function stem(name: string): string {
  const i = name.lastIndexOf(".");
  const base = (i > 0 ? name.slice(0, i) : name).trim() || "latch";
  return base.replace(/[^\w-]+/g, "-").replace(/-+/g, "-").slice(0, 48);
}

export function fmt(t: number): string {
  if (!Number.isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s.toFixed(2).padStart(5, "0")}`;
}

export function oriented(natW: number, natH: number, rot: number): { w: number; h: number } {
  return rot % 2 === 1 ? { w: natH, h: natW } : { w: natW, h: natH };
}

export function frameRatio(natW: number, natH: number, rot: number): number {
  const o = oriented(natW, natH, rot);
  return o.h === 0 ? 1 : o.w / o.h;
}

export function fitAspect(ratio: number, frame: number): Crop {
  const norm = ratio / (frame || 1);
  let w = 1;
  let h = norm === 0 ? 1 : w / norm;
  if (h > 1) {
    h = 1;
    w = h * norm;
  }
  if (w > 1) {
    w = 1;
    h = w / norm;
  }
  w = clamp(w, 0.08, 1);
  h = clamp(h, 0.08, 1);
  return { x: (1 - w) / 2, y: (1 - h) / 2, w, h };
}

export function moveCrop(start: Crop, dx: number, dy: number): Crop {
  return {
    ...start,
    x: clamp(start.x + dx, 0, 1 - start.w),
    y: clamp(start.y + dy, 0, 1 - start.h),
  };
}

type Handle = "nw" | "ne" | "sw" | "se";

export function resizeFree(start: Crop, dx: number, dy: number, handle: Handle): Crop {
  const min = 0.08;
  let x0 = start.x;
  let y0 = start.y;
  let x1 = start.x + start.w;
  let y1 = start.y + start.h;
  if (handle.includes("w")) x0 = clamp(start.x + dx, 0, x1 - min);
  if (handle.includes("e")) x1 = clamp(start.x + start.w + dx, x0 + min, 1);
  if (handle.includes("n")) y0 = clamp(start.y + dy, 0, y1 - min);
  if (handle.includes("s")) y1 = clamp(start.y + start.h + dy, y0 + min, 1);
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

export function resizeLocked(
  start: Crop,
  dx: number,
  dy: number,
  handle: Handle,
  ratio: number,
  frame: number,
): Crop {
  const norm = ratio / (frame || 1);
  const min = 0.08;
  const signX = handle.includes("e") ? 1 : -1;
  const signY = handle.includes("s") ? 1 : -1;
  const anchorX = handle.includes("w") ? start.x + start.w : start.x;
  const anchorY = handle.includes("n") ? start.y + start.h : start.y;
  let w = start.w + signX * dx;
  let h = start.h + signY * dy;
  if (Math.abs(dx) >= Math.abs(dy)) h = w / norm;
  else w = h * norm;
  if (!(w > 0) || !(h > 0)) {
    w = start.w;
    h = start.h;
  }
  if (w < min) {
    w = min;
    h = w / norm;
  }
  if (h < min) {
    h = min;
    w = h * norm;
  }
  let x = handle.includes("w") ? anchorX - w : anchorX;
  let y = handle.includes("n") ? anchorY - h : anchorY;
  if (x < 0) {
    w += x;
    x = 0;
    h = w / norm;
    if (handle.includes("n")) y = anchorY - h;
  }
  if (y < 0) {
    h += y;
    y = 0;
    w = h * norm;
    if (handle.includes("w")) x = anchorX - w;
  }
  if (x + w > 1) {
    w = 1 - x;
    h = w / norm;
    if (handle.includes("n")) y = anchorY - h;
  }
  if (y + h > 1) {
    h = 1 - y;
    w = h * norm;
    if (handle.includes("w")) x = anchorX - w;
  }
  w = clamp(w, min, 1);
  h = clamp(h, min, 1);
  x = clamp(x, 0, 1 - w);
  y = clamp(y, 0, 1 - h);
  return { x, y, w, h };
}

export function cropPixels(
  natW: number,
  natH: number,
  rot: number,
  crop: Crop,
  maxEdge: number,
): { w: number; h: number } {
  const o = oriented(natW, natH, rot);
  let w = Math.max(2, Math.round(crop.w * o.w));
  let h = Math.max(2, Math.round(crop.h * o.h));
  const edge = Math.max(w, h);
  if (edge > maxEdge) {
    const s = maxEdge / edge;
    w = Math.max(2, Math.round(w * s));
    h = Math.max(2, Math.round(h * s));
  }
  if (w % 2) w = Math.max(2, w - 1);
  if (h % 2) h = Math.max(2, h - 1);
  return { w, h };
}

export function gifBudget(open: boolean): {
  maxSpan: number;
  maxFrames: number;
  maxEdge: number;
  maxFps: number;
} {
  return open
    ? { maxSpan: 15, maxFrames: 150, maxEdge: 480, maxFps: 16 }
    : { maxSpan: 6, maxFrames: 72, maxEdge: 400, maxFps: 10 };
}

export type Motion = {
  smooth: boolean;
  slower: boolean;
  reverse: boolean;
  pingpong: boolean;
};

export type GifOp = { t: number } | { a: number; b: number };

function subsampleTimes(times: number[], n: number): number[] {
  if (n >= times.length) return times.slice();
  if (n <= 1) return [times[0] ?? 0];
  const out: number[] = [];
  const last = times.length - 1;
  for (let i = 0; i < n; i++) out.push(times[Math.round((i * last) / (n - 1))] ?? 0);
  return out;
}

export function planMotion(times: number[], motion: Motion, maxFrames: number): { ops: GifOp[]; oneWay: number } {
  const src0 = times.length > 0 ? times : [0];
  const cost = (count: number) => {
    const blended = motion.smooth && count > 1 ? count * 2 - 1 : count;
    return motion.pingpong && blended > 2 ? blended * 2 - 2 : blended;
  };
  let n = src0.length;
  while (n > 1 && cost(n) > maxFrames) n -= 1;
  const src = subsampleTimes(src0, n);
  let ops: GifOp[] = src.map((t) => ({ t }));
  if (motion.smooth && src.length > 1) {
    const mixed: GifOp[] = [];
    for (let i = 0; i < src.length; i++) {
      mixed.push({ t: src[i] ?? 0 });
      if (i < src.length - 1) mixed.push({ a: src[i] ?? 0, b: src[i + 1] ?? 0 });
    }
    ops = mixed;
  }
  if (motion.reverse) ops = [...ops].reverse();
  const oneWay = ops.length;
  if (motion.pingpong && ops.length > 2) ops = [...ops, ...ops.slice(1, -1).reverse()];
  if (ops.length > maxFrames) ops = ops.slice(0, maxFrames);
  return { ops, oneWay };
}

export function slowedDelay(base: number, u: number, slowMid: number) {
  const bell = Math.exp(-((u - 0.5) * (u - 0.5)) / 0.05);
  return Math.max(20, Math.min(2000, Math.round(base * (1 + slowMid * bell * 2.2))));
}
