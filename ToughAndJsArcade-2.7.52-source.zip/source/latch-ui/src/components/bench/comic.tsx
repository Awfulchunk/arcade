import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, BookOpen, Check, Download, Film, ImagePlus, LayoutGrid, ListOrdered, MessageSquare, Plus, RotateCcw, Trash2 } from "lucide-react";
import { Bar, Body, ColorBars, HS, LATCH_VERSION, ModeKey, Sheet } from "@/components/bench/vtr";
import {
  drawComicPreview,
  exportComic,
  readingOrder,
  type BubbleKind,
  type ComicFormat,
  type FitMode,
  type PageLayout,
} from "@/lib/bench/comic";

type Panel = {
  id: string;
  name: string;
  url: string;
  img: HTMLImageElement;
  w: number;
  h: number;
  order: number;
  added: number;
  bubbles: { id: string; kind: BubbleKind; text: string; x: number; y: number }[];
};

const GUIDE = [
  { name: "Add", what: "Bring in stills from this device. Videos are skipped.", example: "Four panels of the same scene." },
  { name: "Order", what: "Tap pictures in the order a reader should see them. The page rearranges.", example: "Tap the wide shot, then the face, then the hands." },
  { name: "Manga", what: "Same order, placed right to left.", example: "1 sits on the right of the row." },
  { name: "Webtoon", what: "One tall strip. First tap is the top.", example: "A scroll you save as one long picture." },
  { name: "Comic", what: "Left to right, then the next row.", example: "A two-column page." },
  { name: "Bubbles", what: "Speech, thought, caption, or shout. You type the words. Drag the bubble, or use the arrows.", example: "A speech balloon over the face." },
  { name: "Whole / Fill", what: "Whole keeps the entire picture. Fill crops it to the panel.", example: "Whole if a face is near the edge." },
  { name: "Save", what: "Writes the page as a PNG. Numbers from Order are not in the file.", example: "latch-manga.png in your downloads." },
];

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function loadImage(file: File) {
  return new Promise<{ img: HTMLImageElement; url: string }>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => resolve({ img, url });
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(file.name));
    };
    img.src = url;
  });
}

export function Comic({ active, onClip }: { active: boolean; onClip: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const layoutRef = useRef<PageLayout | null>(null);
  const dragRef = useRef<{ panelId: string; id: string } | null>(null);
  const urls = useRef<string[]>([]);

  const [panels, setPanels] = useState<Panel[]>([]);
  const [queue, setQueue] = useState<string[]>([]);
  const [format, setFormat] = useState<ComicFormat>("comic");
  const [cols, setCols] = useState(2);
  const [fit, setFit] = useState<FitMode>("whole");
  const [tool, setTool] = useState<"order" | "bubbles" | "format" | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [bubbleId, setBubbleId] = useState<string | null>(null);
  const [kind, setKind] = useState<BubbleKind>("speech");
  const [draft, setDraft] = useState("");
  const [note, setNote] = useState("Add stills. Tap Order, then tap them in reading order.");
  const [help, setHelp] = useState(false);
  const [menu, setMenu] = useState(false);
  const [toastOn, setToastOn] = useState(false);
  const [busy, setBusy] = useState(false);

  const sorted = useMemo(() => readingOrder(panels, queue), [panels, queue]);

  useEffect(() => {
    const owned = urls.current;
    return () => {
      for (const u of owned) URL.revokeObjectURL(u);
    };
  }, []);

  useEffect(() => {
    if (!active) return;
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas || sorted.length === 0) {
      layoutRef.current = null;
      return;
    }
    const draw = () => {
      if (wrap.clientWidth < 40) return;
      const opts = { badges: tool === "order", activeId: tool === "bubbles" ? activeId : null, activeBubble: bubbleId, fit };
      const w = Math.max(120, wrap.clientWidth - 4);
      let placed = drawComicPreview(canvas, sorted, format, cols, w, opts);
      if (format !== "webtoon" && placed.pageH * (w / placed.pageW) > wrap.clientHeight - 4) {
        const fitW = Math.max(100, ((wrap.clientHeight - 4) * placed.pageW) / placed.pageH);
        placed = drawComicPreview(canvas, sorted, format, cols, fitW, opts);
      }
      layoutRef.current = placed;
    };
    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [active, sorted, format, cols, fit, tool, activeId, bubbleId]);

  useEffect(() => {
    if (!note) return;
    setToastOn(true);
    const t = window.setTimeout(() => setToastOn(false), 3500);
    return () => window.clearTimeout(t);
  }, [note]);

  function toggle(next: "order" | "bubbles" | "format") {
    setTool((cur) => (cur === next ? null : next));
    if (next === "order" && tool !== "order") setNote("Tap panels in reading order. First tap is 1.");
    if (next === "bubbles" && tool !== "bubbles") setNote(activeId ? "Type, then add. Drag the bubble to move it." : "Tap a panel, then add a bubble.");
  }

  function assign(id: string) {
    if (queue.includes(id)) {
      setNote("Already numbered. Start over if you want a new order.");
      return;
    }
    const next = [...queue, id];
    setQueue(next);
    const left = panels.length - next.length;
    setNote(left ? `${next.length} set. Tap the next one. ${left} left.` : "That's the whole order.");
  }

  async function addFiles(list: File[]) {
    if (!list.length) {
      setNote("Nothing picked.");
      return;
    }
    setNote(`Opening ${list.length}…`);
    const loaded: Panel[] = [];
    let skipped = 0;
    for (const file of list) {
      if (!file.type.startsWith("image/")) {
        skipped += 1;
        continue;
      }
      try {
        const pic = await loadImage(file);
        urls.current.push(pic.url);
        loaded.push({
          id: uid(),
          name: file.name,
          url: pic.url,
          img: pic.img,
          w: pic.img.naturalWidth || pic.img.width,
          h: pic.img.naturalHeight || pic.img.height,
          order: 0,
          added: 0,
          bubbles: [],
        });
      } catch {
        skipped += 1;
      }
    }
    if (!loaded.length) {
      setNote("Those weren't pictures. Comic uses stills.");
      return;
    }
    setPanels((ps) => {
      let order = ps.reduce((m, p) => Math.max(m, p.order), -1) + 1;
      const stamp = Date.now();
      return [
        ...ps,
        ...loaded.map((p, i) => ({ ...p, order: order + i, added: stamp + i })),
      ];
    });
    const total = panels.length + loaded.length;
    if (total >= 2 && queue.length === 0) {
      setTool("order");
      setNote(`Added ${loaded.length}. Tap them in the order you read.`);
    } else {
      setNote(skipped ? `Added ${loaded.length}. Skipped ${skipped}.` : `Added ${loaded.length}.`);
    }
  }

  function removePanel(id: string) {
    const found = panels.find((p) => p.id === id);
    if (found) {
      URL.revokeObjectURL(found.url);
      urls.current = urls.current.filter((u) => u !== found.url);
    }
    setPanels((ps) => ps.filter((p) => p.id !== id));
    setQueue((q) => q.filter((x) => x !== id));
    if (activeId === id) {
      setActiveId(null);
      setBubbleId(null);
      setDraft("");
    }
  }

  function onDraft(value: string) {
    const v = value.slice(0, 180);
    setDraft(v);
    if (!bubbleId || !activeId) return;
    setPanels((ps) =>
      ps.map((p) =>
        p.id !== activeId ? p : { ...p, bubbles: p.bubbles.map((b) => (b.id === bubbleId ? { ...b, text: v } : b)) },
      ),
    );
  }

  function pickKind(next: BubbleKind) {
    setKind(next);
    if (!bubbleId || !activeId) return;
    setPanels((ps) =>
      ps.map((p) =>
        p.id !== activeId ? p : { ...p, bubbles: p.bubbles.map((b) => (b.id === bubbleId ? { ...b, kind: next } : b)) },
      ),
    );
  }

  function addBubble() {
    if (!activeId) {
      setNote("Tap a panel first.");
      return;
    }
    const id = uid();
    const text = draft.trim();
    setPanels((ps) =>
      ps.map((p) => {
        if (p.id !== activeId) return p;
        const y = kind === "caption" ? 0.16 : kind === "shout" ? 0.5 : p.bubbles.length % 2 === 0 ? 0.28 : 0.72;
        return { ...p, bubbles: [...p.bubbles, { id, kind, text, x: 0.5, y }] };
      }),
    );
    setBubbleId(id);
    setNote("Drag the bubble, or use the arrows.");
  }

  function removeBubble() {
    if (!activeId || !bubbleId) return;
    setPanels((ps) =>
      ps.map((p) => (p.id !== activeId ? p : { ...p, bubbles: p.bubbles.filter((b) => b.id !== bubbleId) })),
    );
    setBubbleId(null);
    setDraft("");
  }

  function nudge(dx: number, dy: number) {
    if (!activeId || !bubbleId) return;
    setPanels((ps) =>
      ps.map((p) =>
        p.id !== activeId
          ? p
          : {
              ...p,
              bubbles: p.bubbles.map((b) =>
                b.id !== bubbleId ? b : { ...b, x: Math.min(0.92, Math.max(0.08, b.x + dx)), y: Math.min(0.92, Math.max(0.08, b.y + dy)) },
              ),
            },
      ),
    );
  }

  function pagePoint(e: React.PointerEvent) {
    const canvas = canvasRef.current;
    const layout = layoutRef.current;
    if (!canvas || !layout) return null;
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    return {
      x: ((e.clientX - rect.left) / rect.width) * layout.pageW,
      y: ((e.clientY - rect.top) / rect.height) * layout.pageH,
    };
  }

  function onPointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    const pt = pagePoint(e);
    const layout = layoutRef.current;
    if (!pt || !layout) return;
    if (tool !== "order") {
      const bubble = [...layout.bubbles].reverse().find((b) => pt.x >= b.x && pt.x <= b.x + b.w && pt.y >= b.y && pt.y <= b.y + b.h);
      if (bubble) {
        const panel = panels.find((p) => p.id === bubble.panelId);
        const found = panel?.bubbles.find((b) => b.id === bubble.id);
        setTool("bubbles");
        setActiveId(bubble.panelId);
        setBubbleId(bubble.id);
        setKind(found?.kind ?? "speech");
        setDraft(found?.text ?? "");
        dragRef.current = { panelId: bubble.panelId, id: bubble.id };
        e.currentTarget.setPointerCapture(e.pointerId);
        return;
      }
    }
    const cell = layout.cells.find((c) => pt.x >= c.x && pt.x <= c.x + c.w && pt.y >= c.y && pt.y <= c.y + c.h);
    if (!cell) return;
    if (tool === "order") {
      assign(cell.id);
      return;
    }
    setActiveId(cell.id);
    setBubbleId(null);
    setDraft("");
  }

  function onPointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    const drag = dragRef.current;
    if (!drag) return;
    const pt = pagePoint(e);
    const layout = layoutRef.current;
    if (!pt || !layout) return;
    const cell = layout.cells.find((c) => c.id === drag.panelId);
    if (!cell || cell.w < 1 || cell.h < 1) return;
    const x = Math.min(0.92, Math.max(0.08, (pt.x - cell.x) / cell.w));
    const y = Math.min(0.92, Math.max(0.08, (pt.y - cell.y) / cell.h));
    setPanels((ps) =>
      ps.map((p) =>
        p.id !== drag.panelId ? p : { ...p, bubbles: p.bubbles.map((b) => (b.id === drag.id ? { ...b, x, y } : b)) },
      ),
    );
  }

  async function save() {
    if (!sorted.length || busy) {
      setNote("Add pictures first.");
      return;
    }
    setBusy(true);
    setNote("Writing the page…");
    try {
      await exportComic(sorted, format, cols, fit);
      setNote("Saved. Order numbers are not in the file.");
    } catch {
      setNote("Couldn't write that page. Try fewer pictures.");
    } finally {
      setBusy(false);
    }
  }

  const activePanel = panels.find((p) => p.id === activeId) ?? null;
  const activeIndex = sorted.findIndex((p) => p.id === activeId);
  const fmtLabel = format === "webtoon" ? "WEBTOON" : `${format.toUpperCase()} · ${cols} COL`;

  return (
    <main className="vtr">
      <input
        ref={fileRef}
        className="clip-input"
        type="file"
        accept="image/*"
        multiple
        onChange={(e) => {
          const files = e.target.files ? [...e.target.files] : [];
          e.target.value = "";
          void addFiles(files);
        }}
      />
      <Bar page="page" onClip={onClip} onPage={() => {}} canUndo={false} onUndo={() => {}} onMenu={() => setMenu(true)} undoTip="Undo|Undo works on clips. On a page, tap a bubble and Remove it." />

      <div className="vfwrap">
        <div className="vf" data-guide="3" data-gl={sorted.length ? "Your page (tap a panel)" : "Page preview"} data-gpos="br">
          {sorted.length === 0 ? (
            <>
              <ColorBars />
              <div className="notape">
                <b>NO PAGE</b>
                <span>ADD STILLS BELOW ▼</span>
              </div>
            </>
          ) : (
            <div ref={wrapRef} className="pagewrap">
              <canvas
                ref={canvasRef}
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={() => {
                  dragRef.current = null;
                }}
                onPointerCancel={() => {
                  dragRef.current = null;
                }}
              />
            </div>
          )}
          <div className="osd obl" style={{ left: 14, bottom: 8 }}>
            <span className={`dot${sorted.length ? "" : " red"}`} />
            {sorted.length ? `PAGE · ${sorted.length} PIC` : "STBY"}
          </div>
          <div className="osd obr" style={{ right: 14, bottom: 8 }}>
            {fmtLabel}
          </div>
          {toastOn && note ? <div className="toast" style={{ top: 10 }}>{note}</div> : null}
        </div>
      </div>

      {sorted.length ? (
        <div className="deck">
          <div className="slots" data-guide="4" data-gl="Pictures: tap one; + adds">
            {sorted.map((p, i) => (
              <button
                key={p.id}
                type="button"
                className={`s${activeId === p.id ? " on" : ""}`}
                aria-label={`Panel ${i + 1}`}
                data-tip={tool === "order" ? "Order|Tap pictures in reading order. This one becomes the next number." : `Panel ${i + 1}|Selects it for bubbles.`}
                onClick={() => {
                  if (tool === "order") assign(p.id);
                  else {
                    setActiveId(p.id);
                    setBubbleId(null);
                    setDraft("");
                  }
                }}
              >
                <img src={p.url} alt="" />
                <i>{i + 1}</i>
              </button>
            ))}
            <button type="button" className="add" data-tip="Add|Bring in more stills from this phone." onClick={() => fileRef.current?.click()}>
              <ImagePlus className="ico sm" /> ADD
            </button>
          </div>
        </div>
      ) : null}

      {sorted.length ? (
        <div className="drawer">
          {!tool ? (
            <>
              <div className="dh">
                <span className="tag">
                  <b>PAGE</b> · PICK A TOOL
                </span>
              </div>
              <div className="tiles">
                {(
                  [
                    ["format", "Layout", "Comic, manga or webtoon", <LayoutGrid key="f" className="ico" />, "Layout|Comic grid, manga (right to left) or one tall webtoon strip."],
                    ["bubbles", "Bubble", "Speech, thought, shout", <MessageSquare key="b" className="ico" />, "Bubble|Tap a panel, type the words, add a bubble, drag it."],
                    ["order", "Order", "Tap in reading order", <ListOrdered key="o" className="ico" />, "Order|Tap pictures in the order a reader sees them."],
                  ] as const
                ).map(([id, label, desc, icon, tip]) => (
                  <button key={id} type="button" className="tile" data-tool={id} data-tip={tip} onClick={() => toggle(id)}>
                    {icon}
                    <b>{label}</b>
                    <span className="ds">{desc}</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="dh">
                <span className="tag">
                  PAGE › <b>{tool === "format" ? "LAYOUT" : tool === "bubbles" ? `BUBBLE${activePanel ? ` · PANEL ${activeIndex + 1}` : ""}` : "ORDER"}</b>
                </span>
                <button type="button" className="done" data-done="" data-tip="Done|Closes this tool." onClick={() => setTool(null)}>
                  <Check className="ico sm" /> DONE
                </button>
              </div>
              <Body>
                {tool === "order" ? (
                  <>
                    <p className="p">
                      Tap pictures (on the page or in the strip) in the order you read them.{" "}
                      {format === "manga" ? "Manga places 1 on the right, then left, then the next row." : format === "webtoon" ? "Webtoon stacks them. 1 is the top." : "Comic reads left to right, then the next row."}
                    </p>
                    <button
                      type="button"
                      className="chip sq wide"
                      data-tip="Start over|Clears the numbers so you can tap a new order."
                      onClick={() => {
                        setQueue([]);
                        setNote("Order cleared. Tap the first panel.");
                      }}
                    >
                      <RotateCcw className="ico sm" /> Start order over
                    </button>
                  </>
                ) : null}
                {tool === "format" ? (
                  <>
                    <HS label="Format">
                      {(
                        [
                          ["comic", "Comic"],
                          ["manga", "Manga"],
                          ["webtoon", "Webtoon"],
                        ] as const
                      ).map(([id, label]) => (
                        <button key={id} type="button" className={`chip sq${format === id ? " on" : ""}`} data-fmt={id} data-tip={`${label}|${id === "manga" ? "Same order, placed right to left." : id === "webtoon" ? "One tall strip; first is the top." : "Left to right, then the next row."}`} onClick={() => setFormat(id)}>
                          {label}
                        </button>
                      ))}
                    </HS>
                    <div className="grid2">
                      {format !== "webtoon"
                        ? [2, 3].map((n) => (
                            <button key={n} type="button" className={`chip sq${cols === n ? " on" : ""}`} data-tip={`${n} columns|Panels per row.`} onClick={() => setCols(n)}>
                              {n} columns
                            </button>
                          ))
                        : null}
                      <button type="button" className={`chip sq${fit === "whole" ? " on" : ""}`} data-tip="Whole|Keeps every edge of each picture." onClick={() => setFit("whole")}>
                        Whole picture
                      </button>
                      <button type="button" className={`chip sq${fit === "fill" ? " on" : ""}`} data-tip="Fill|Crops each picture to fill its panel." onClick={() => setFit("fill")}>
                        Fill panel
                      </button>
                    </div>
                    {activePanel ? (
                      <button type="button" className="chip sq wide" data-tip="Remove picture|Takes the selected picture off the page." onClick={() => removePanel(activePanel.id)}>
                        <Trash2 className="ico sm" /> Remove picture {activeIndex + 1}
                      </button>
                    ) : null}
                  </>
                ) : null}
                {tool === "bubbles" ? (
                  <>
                    <HS label="Bubble kind">
                      {(
                        [
                          ["speech", "Speech"],
                          ["thought", "Thought"],
                          ["caption", "Caption"],
                          ["shout", "Shout!"],
                        ] as const
                      ).map(([id, label]) => (
                        <button key={id} type="button" className={`chip${kind === id ? " on" : ""}`} data-bub={id} data-tip={`${label}|Bubble style.`} onClick={() => pickKind(id)}>
                          {label}
                        </button>
                      ))}
                    </HS>
                    <div className="row">
                      <input value={draft} onChange={(e) => onDraft(e.target.value)} maxLength={180} placeholder={activePanel ? "What they say" : "Tap a panel first"} className="txt" aria-label="Bubble words" />
                      <button type="button" className="chip sq hot" data-tip="Add bubble|Puts a bubble with these words on the selected panel." onClick={addBubble}>
                        <Plus className="ico sm" /> Add
                      </button>
                    </div>
                    {activePanel && activePanel.bubbles.length ? (
                      <HS label="Bubbles">
                        {activePanel.bubbles.map((b) => (
                          <button
                            key={b.id}
                            type="button"
                            className={`chip sq${bubbleId === b.id ? " on" : ""}`}
                            data-tip="Bubble|Selects it to edit, move or remove."
                            onClick={() => {
                              setBubbleId(b.id);
                              setKind(b.kind);
                              setDraft(b.text);
                            }}
                          >
                            {b.kind}: {(b.text || "empty").slice(0, 12)}
                          </button>
                        ))}
                      </HS>
                    ) : null}
                    <div className="grid4" style={bubbleId ? undefined : { opacity: 0.5 }}>
                      <button type="button" className="chip sq" aria-label="Nudge left" data-tip="Left|Moves the bubble left." onClick={() => nudge(-0.04, 0)}>
                        <ArrowLeft className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Nudge up" data-tip="Up|Moves the bubble up." onClick={() => nudge(0, -0.04)}>
                        <ArrowUp className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Nudge down" data-tip="Down|Moves the bubble down." onClick={() => nudge(0, 0.04)}>
                        <ArrowDown className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Nudge right" data-tip="Right|Moves the bubble right." onClick={() => nudge(0.04, 0)}>
                        <ArrowRight className="ico sm" />
                      </button>
                    </div>
                    {bubbleId ? (
                      <button type="button" className="chip sq wide" data-tip="Remove|Deletes the selected bubble." onClick={removeBubble}>
                        <Trash2 className="ico sm" /> Remove bubble
                      </button>
                    ) : null}
                  </>
                ) : null}
              </Body>
            </>
          )}
        </div>
      ) : null}

      {sorted.length ? (
        <div className="modes" data-guide="5" data-gl="Page tools + SAVE">
          <ModeKey n="01" label="LAYOUT" icon={<LayoutGrid className="ico" />} on={tool === "format"} tip="Layout|Comic, manga or webtoon; columns; whole or fill." onClick={() => toggle("format")} />
          <ModeKey n="02" label="BUBBLE" icon={<MessageSquare className="ico" />} on={tool === "bubbles"} tip="Bubble|Speech, thought, caption or shout on a panel." onClick={() => toggle("bubbles")} />
          <ModeKey n="03" label="ORDER" icon={<ListOrdered className="ico" />} on={tool === "order"} tip="Order|Tap pictures in reading order." onClick={() => toggle("order")} />
          <ModeKey n="REC" label="SAVE" hot icon={<Download className="ico" />} tip="Save|Writes the page as a PNG on this phone. Order numbers are not in the file." onClick={() => void save()} />
        </div>
      ) : (
        <div className="slot">
          <button type="button" className="insert" data-tip="Add pictures|Pick stills from this phone. Videos are skipped." data-guide="4" data-gl="Start here: add stills" data-gpos="tc" onClick={() => fileRef.current?.click()}>
            <span className="ib">
              <ImagePlus className="ico" />
            </span>
            <span>
              <b>Add pictures</b>
              <span>Stills from your phone, as many as you like</span>
            </span>
          </button>
          <div className="alts" data-guide="5" data-gl="Back to the clip editor">
            <button type="button" className="alt" data-tip="Clip editor|Back to cutting clips." onClick={onClip}>
              <Film className="ico sm" /> Clip editor
            </button>
          </div>
          <div className="steps">
            <span>
              <i>1</i> ADD
            </span>
            <span>→</span>
            <span>
              <i>2</i> LAYOUT · BUBBLE · ORDER
            </span>
            <span>→</span>
            <span>
              <i>3</i> SAVE
            </span>
          </div>
          <div className="privacy">Nothing leaves this phone.</div>
        </div>
      )}

      <p className="clip-input" aria-live="polite" data-note="">
        {note}
      </p>

      {menu ? (
        <Sheet title="MENU" onClose={() => setMenu(false)}>
          <div className="tiles">
            <button
              type="button"
              className="tile"
              data-tip="Add pictures|More stills for this page."
              onClick={() => {
                setMenu(false);
                fileRef.current?.click();
              }}
            >
              <ImagePlus className="ico" />
              <b>Add pictures</b>
              <span className="ds">From this phone</span>
            </button>
            <button
              type="button"
              className="tile"
              data-tip="Manual|What each page tool does."
              onClick={() => {
                setMenu(false);
                setHelp(true);
              }}
            >
              <BookOpen className="ico" />
              <b>Manual</b>
              <span className="ds">Page tools</span>
            </button>
          </div>
          <p className="p" style={{ marginTop: 8 }}>
            Latch {LATCH_VERSION} · VTR-1 · Page. Nothing leaves this phone.
          </p>
        </Sheet>
      ) : null}

      {help ? (
        <Sheet title="PAGE MANUAL" onClose={() => setHelp(false)}>
          <ul className="list">
            {GUIDE.map((item) => (
              <li key={item.name}>
                <b>{item.name}</b>
                <span>{item.what}</span>
                <em>Example: {item.example}</em>
              </li>
            ))}
          </ul>
        </Sheet>
      ) : null}
    </main>
  );
}
