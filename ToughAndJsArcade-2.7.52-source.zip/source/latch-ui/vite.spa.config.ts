import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import { fileURLToPath } from "node:url";
export default defineConfig({
  root: "spa",
  base: "./",
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  plugins: [tailwindcss(), react(), viteSingleFile()],
  // 2.0: old Android WebViews (Chrome 80+) ignore CSS `inset` etc., so tell the minifier not to emit them.
  build: { outDir: "../spa-dist", emptyOutDir: true, assetsInlineLimit: 100000000, target: ["es2020", "chrome80"], cssTarget: "chrome80" },
});
