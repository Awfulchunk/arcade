const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const A = (f) => "/workspace/game/build-latch/test/assets/" + f;
const HOOK = () => {
  const blobs = new Map();
  const oc = URL.createObjectURL.bind(URL);
  URL.createObjectURL = (b) => { const u = oc(b); blobs.set(u, b); return u; };
  window.__dl = [];
  const click = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download) {
      const b = blobs.get(this.href);
      if (b) { const r = new FileReader(); r.onload = () => window.__dl.push({ name: this.download, type: b.type, size: b.size, data: String(r.result).split(",")[1] }); r.readAsDataURL(b); return; }
    }
    return click.call(this);
  };
};
async function open(url, vp, opts = {}) {
  const b = opts.browser || (await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required", "--allow-file-access-from-files"] }));
  const p = await b.newPage();
  const errs = [];
  p.on("pageerror", (e) => errs.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errs.push("console: " + m.text()); });
  await p.setViewport({ width: vp[0], height: vp[1], deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.evaluateOnNewDocument(HOOK);
  await p.goto(url);
  await sleep(700);
  return { b, p, errs };
}
// tap the visible element matching sel (optionally containing text) with a real mouse click
async function tap(p, sel, text, hold = 0) {
  const pt = await p.evaluate((sel, text) => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== "hidden"; };
    const els = [...document.querySelectorAll(sel)].filter(vis).filter((e) => !text || e.textContent.toLowerCase().includes(text.toLowerCase()));
    const e = els[0]; if (!e) return null;
    e.scrollIntoView({ block: "nearest", inline: "nearest" });
    const r = e.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }, sel, text || "");
  if (!pt) throw new Error("not found: " + sel + (text ? " / " + text : ""));
  await sleep(60);
  if (hold) { await p.mouse.move(pt.x, pt.y); await p.mouse.down(); await sleep(hold); await p.mouse.up(); }
  else await p.mouse.click(pt.x, pt.y);
  await sleep(250);
}
const tip = (t) => `[data-tip^="${t}|"]`;
async function audit(p, name, dir, extra = {}) {
  await sleep(350);
  const m = await p.evaluate(() => {
    const de = document.documentElement;
    const W = innerWidth, H = innerHeight;
    const vis = (e) => { const r = e.getBoundingClientRect(); if (!(r.width > 0 && r.height > 0)) return false; const cs = getComputedStyle(e); if (cs.visibility === "hidden" || cs.display === "none") return false; if (e.closest(".clip-input")) return false; return true; };
    const small = [];
    const sel = "button, a[href], input:not([type=hidden]), select, textarea, [role=button]";
    let count = 0;
    for (const e of document.querySelectorAll(sel)) {
      if (!vis(e)) continue;
      // only those inside the viewport vertically (sheets) - all should be on-screen anyway
      count++;
      const r = e.getBoundingClientRect();
      if (r.width < 43.5 || r.height < 43.5) small.push(`${e.tagName.toLowerCase()}.${(e.className && e.className.baseVal === undefined ? e.className : "").toString().split(" ")[0]} "${(e.getAttribute("aria-label") || e.textContent || e.getAttribute("type") || "").trim().slice(0, 24)}" ${Math.round(r.width)}x${Math.round(r.height)}`);
    }
    const se = document.scrollingElement;
    const offscreen = [];
    for (const e of document.querySelectorAll(".vtr button, .sheet button, .legend button")) {
      if (!vis(e)) continue;
      const r = e.getBoundingClientRect();
      // a button is fine if inside a scroller (hs / dbody / list); else it must be on-screen
      if (e.closest(".hs, .dbody, .sheet, .slots, .tiles")) continue;
      if (r.bottom > H + 1 || r.top < -1 || r.right > W + 1 || r.left < -1) offscreen.push((e.getAttribute("aria-label") || e.textContent || "").trim().slice(0, 20));
    }
    const vf = [...document.querySelectorAll(".vf")].find(vis)?.getBoundingClientRect();
    const pic = [...document.querySelectorAll(".vf canvas, .vf video")].find(vis)?.getBoundingClientRect();
    const leg = document.querySelector(".legend")?.getBoundingClientRect();
    const legOverVf = !!(leg && vf && !document.querySelector(".vf .notape") && leg.top < vf.bottom - 1 && leg.bottom > vf.top + 1);
    return {
      scroll: { sh: se.scrollHeight, sw: se.scrollWidth, H, W, y: se.scrollTop },
      noPageScroll: se.scrollHeight <= H + 1 && se.scrollWidth <= W + 1,
      targets: count, small, offscreen,
      vfH: vf ? Math.round(vf.height) : 0, picH: pic ? Math.round(Math.min(pic.bottom, vf.bottom) - Math.max(pic.top, vf.top)) : 0,
      legOverVf, qmarks: document.querySelectorAll(".qm").length,
    };
  });
  await p.screenshot({ path: `${dir}/${name}.png` });
  return { name, ...m, ...extra };
}
module.exports = { open, tap, tip, audit, sleep, A, fs };
