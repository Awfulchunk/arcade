// Test-only: WebView 83 has no CSS `inset`, so the arcade's #game layer is 0x0 for every game.
// For a visual check we size #game in this session only (top/left/width/height), then drive Latch v2.0.
const connect = require("./cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const shot = (n) => execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > emu/${n}.png`);
(async () => { const c = await connect(9333); const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d)); };
  await c.ev("ARCADE.inGame && ARCADE.back(), 1"); await sleep(1500);
  const run = async (id, ver, label, probe) => {
    const n0 = c.ctx.length;
    await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='${id}'); ${ver ? `ARCADE.launch(i,'${ver}')` : "ARCADE.launchCard(i)"}; const g=document.getElementById('game'); g.style.top='0'; g.style.left='0'; g.style.width='100%'; g.style.height='100%'; return 1})()`);
    await sleep(7000);
    const cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault).pop();
    const r = cx ? await c.ev(`(${probe})()`, cx.id) : { noctx: true };
    shot(label); return { r, cx };
  };
  let { r } = await run("funmotion", null, "funmotion", `()=>JSON.stringify({ih:innerHeight, text:document.body.innerText.slice(0,40)})`); r = JSON.parse(r); ok("FunMotion launches + has size (WebView 83)", r.ih > 300 && /FUNMOTION/i.test(r.text), r);
  await c.ev("ARCADE.back(),1"); await sleep(1500);
  ({ r } = await run("needle", null, "needle", `()=>JSON.stringify({ih:innerHeight, text:document.body.innerText.slice(0,40)})`)); r = JSON.parse(r); ok("Needle launches + has size (WebView 83)", r.ih > 300 && /Needle/.test(r.text), r);
  await c.ev("ARCADE.back(),1"); await sleep(1500);
  const L = await run("latch", null, "latch-v2-empty", `()=>{window.__e=[];addEventListener('error',e=>__e.push(String(e.message)));const m=document.querySelector('main.vtr');return JSON.stringify({ih:innerHeight, vtr:!!m, h:m&&Math.round(m.getBoundingClientRect().height), sh:document.scrollingElement.scrollHeight, qm:document.querySelectorAll('.qm').length})}`);
  r = JSON.parse(L.r); ok("Latch v2.0 VTR UI fills the screen, no page scroll (WebView 83)", r.vtr && r.h >= r.ih - 2 && r.sh <= r.ih + 1 && r.qm === 0, r);
  const F = (e) => c.ev(e, L.cx.id);
  await F(`document.querySelector('[data-sample]').click(),1`); await sleep(4000); shot("latch-v2-sample");
  r = JSON.parse(await F(`JSON.stringify({pic:!!document.querySelector('.vf canvas.pic'), osd:(document.querySelector('.osd.obl')||{}).textContent, hint:!!document.querySelector('.hint'), errs:__e})`)); ok("Latch v2.0 Try sample plays (WebView 83)", r.pic && r.errs.length === 0, r);
  await F(`(document.querySelector('.hint button')||{click(){}}).click(); [...document.querySelectorAll('.mk')].find(e=>/LOOK/.test(e.textContent)).click(); 1`); await sleep(700);
  await F(`document.querySelector('[data-tool=grade]').click(),1`); await sleep(2500); shot("latch-v2-grade");
  r = JSON.parse(await F(`JSON.stringify({tag:document.querySelector('.drawer .tag').textContent, vf:Math.round(document.querySelector('.vf').getBoundingClientRect().height), thumbs:document.querySelectorAll('[data-pre] img').length, errs:__e})`)); ok("Latch v2.0 Grade opens, preview kept (WebView 83)", /GRADE/.test(r.tag) && r.vf > 150 && r.errs.length === 0, r);
  await F(`[...document.querySelectorAll('.mk')].find(e=>/SAVE/.test(e.textContent)).click(); 1`); await sleep(700);
  await sleep(800); await F(`(document.querySelector('[data-save-still]')||document.querySelector('[data-save-gif]')).click(),1`); await sleep(8000); shot("latch-v2-save");
  r = JSON.parse(await F(`JSON.stringify({note:document.querySelector('[data-note]').textContent, job:!!document.querySelector('.job'), errs:__e})`)); ok("Latch v2.0 Save runs (WebView 83; sample opens as a still here, so Save still)", r.errs.length === 0 && !/couldn/i.test(r.note), r);
  await c.ev("ARCADE.back(),1"); await sleep(1500);
  ({ r } = await run("latch", "v11", "latch-v1.1", `()=>JSON.stringify({ih:innerHeight, qm:document.querySelectorAll('.qm').length, len:document.body.innerText.length})`)); r = JSON.parse(r); ok("Latch v1.1 launches from Older versions (WebView 83)", r.ih > 300, r);
  await c.ev("ARCADE.back(),1");
  fs.writeFileSync("emu/emu.json", JSON.stringify(R, null, 1)); console.log(`emulator: ${R.filter((x) => x.pass).length}/${R.length} pass`); c.close(); process.exit(0);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); process.exit(1); });
