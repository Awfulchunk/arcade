// Every default cartridge in the 2.7.52 bundle (from the APK) on modern Chrome: normal mode, then forced old-WebView mode (arcade.legacy=1).
// Per game: frame fills the screen, something renders, 0 JS errors. Screenshots in arcade-all/<mode>/.
const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BENIGN = /ResizeObserver loop/;
(async () => {
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, d); };
  for (const mode of ["modern", "forced-legacy"]) {
    const dir = `arcade-all/${mode}`; fs.mkdirSync(dir, { recursive: true });
    const p = await b.newPage(); const errs = [];
    p.on("pageerror", (e) => errs.push("shell: " + e.message));
    await p.setViewport({ width: 412, height: 732, isMobile: true, hasTouch: true });
    await p.evaluateOnNewDocument((mode) => {
      try { localStorage.setItem("arcade.legacy", mode === "modern" ? "" : "1"); if (mode === "modern") localStorage.removeItem("arcade.legacy"); } catch (e) {}
      const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc");
      Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))},true);addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } });
    }, mode);
    await p.goto("file:///workspace/game/build-latch/test/arcade/index-from-apk.html"); await sleep(1500);
    const leg = await p.evaluate(() => document.documentElement.classList.contains("legacy-webview"));
    ok(`[${mode}] shell legacy flag = ${mode !== "modern"}`, leg === (mode !== "modern"));
    await p.screenshot({ path: `${dir}/00-menu.png` });
    const games = await p.evaluate(() => ARCADE.GAMES.map((g, i) => ({ i, id: g.id })));
    for (const g of games) {
      await p.evaluate((i) => ARCADE.launchCard(i), g.i); await sleep(g.id === "ironwake" || g.id === "empire" ? 6000 : 3800);
      const fr = p.frames().find((f) => f !== p.mainFrame());
      const box = await p.evaluate(() => { const f = ARCADE.frame(); const r = f && f.getBoundingClientRect(); return r ? [Math.round(r.width), Math.round(r.height)] : null; });
      let st = { noframe: true };
      if (fr) st = await fr.evaluate(() => { let vis = 0; for (const e of document.querySelectorAll("body *")) { const r = e.getBoundingClientRect(); if (r.width > 0 && r.height > 0) vis++; } const se = document.scrollingElement; return { vis, text: document.body.innerText.length, canvases: document.querySelectorAll("canvas").length, sw: se.scrollWidth, errs: (window.__errs || ["no capture"]).filter((x) => !/ResizeObserver loop/.test(x)), prelude: !!window.__tjGap }; }).catch((e) => ({ evalErr: e.message }));
      await p.screenshot({ path: `${dir}/${g.id}.png` });
      const pass = box && box[0] === 412 && box[1] === 732 && st.vis > 0 && st.errs && st.errs.length === 0 && st.sw <= 413;
      ok(`[${mode}] ${g.id}: fills screen, renders, 0 JS errors`, pass, JSON.stringify({ box, ...st }).slice(0, 260));
      await p.evaluate(() => ARCADE.back()); await sleep(700);
    }
    ok(`[${mode}] shell 0 JS errors`, errs.length === 0, errs.join("; "));
    await p.close();
  }
  fs.writeFileSync("arcade-all/arcade-all.json", JSON.stringify(R, null, 1));
  console.log(`arcade-all: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(0);
})();
