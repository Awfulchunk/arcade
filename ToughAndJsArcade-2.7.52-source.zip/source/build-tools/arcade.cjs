// Arcade 2.7.52 bundle (taken out of the APK): FunMotion, Needle and all three Latch versions launch with 0 errors.
const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, d); };
  const page = async () => {
    const p = await b.newPage(); const errs = [];
    p.on("pageerror", (e) => errs.push("shell: " + e.message));
    await p.setViewport({ width: 360, height: 800, isMobile: true, hasTouch: true });
    await p.evaluateOnNewDocument(() => {
      const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc");
      Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } });
    });
    await p.goto("file:///workspace/game/build-latch/test/arcade/index-from-apk.html"); await sleep(1500);
    return { p, errs };
  };
  const { p, errs } = await page();
  await p.screenshot({ path: "arcade/00-menu.png" });
  const info = await p.evaluate(() => { const g = GAMES.find((x) => x.id === "latch"); return { latch: g.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")), has: ["funmotion", "needle", "latch"].map((id) => GAMES.findIndex((x) => x.id === id)) }; });
  ok("GAMES has funmotion, needle, latch", info.has.every((i) => i >= 0), JSON.stringify(info.has));
  ok("Latch picker v1 / v1.1 / v2.0 default", info.latch.length === 3 && /latest=v2\.0.*\(default\)/.test(info.latch[2]) && /^v11=v1\.1/.test(info.latch[1]), info.latch.join(" | "));
  const run = async (id, verId, check, shot) => {
    await p.evaluate((id, verId) => { const i = GAMES.findIndex((g) => g.id === id); const G = GAMES[i]; if (verId) ARCADE.launch(i, verId); else ARCADE.launchCard(i); }, id, verId);
    await sleep(3500);
    const fr = p.frames().find((f) => f !== p.mainFrame());
    let res = { loaded: false };
    if (fr) res = await fr.evaluate(check).catch((e) => ({ loaded: false, err: e.message }));
    const ferrs = fr ? await fr.evaluate(() => window.__errs || ["no capture"]).catch(() => ["eval failed"]) : ["no frame"];
    await p.screenshot({ path: `arcade/${shot}.png` });
    ok(`${id}${verId ? ":" + verId : ""} launches, 0 JS errors`, res.loaded && ferrs.length === 0, JSON.stringify({ ...res, errs: ferrs }).slice(0, 300));
    await p.evaluate(() => ARCADE.back()); await sleep(800);
    return fr;
  };
  await run("funmotion", null, () => ({ loaded: document.body.innerText.length > 20 || !!document.querySelector("canvas"), text: document.body.innerText.slice(0, 60) }), "01-funmotion");
  await run("needle", null, () => ({ loaded: document.body.innerText.length > 20, text: document.body.innerText.slice(0, 60) }), "02-needle");
  // Latch v2.0 (default): VTR UI, no ? badges, sample loads inside the arcade
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "latch"); ARCADE.launchCard(i); }); await sleep(2500);
  let fr = p.frames().find((f) => f !== p.mainFrame());
  const v2 = await fr.evaluate(async () => { const vtr = !!document.querySelector("main.vtr"); const qm = document.querySelectorAll(".qm").length; document.querySelector("[data-sample]").click(); await new Promise((r) => setTimeout(r, 1800)); return { vtr, qm, pic: !!document.querySelector(".vf canvas.pic"), osd: document.querySelector(".osd.obl")?.textContent, ver: document.body.innerText.includes("VTR") }; });
  const e2 = await fr.evaluate(() => window.__errs);
  await p.screenshot({ path: "arcade/03-latch-v2.0.png" });
  ok("latch v2.0 (default) = VTR-1 UI, no ? badges, sample plays, 0 errors", v2.vtr && v2.qm === 0 && v2.pic && e2.length === 0, JSON.stringify({ ...v2, errs: e2 }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await run("latch", "v11", () => ({ loaded: document.querySelectorAll(".qm").length > 5 && !document.querySelector("main.vtr"), qm: document.querySelectorAll(".qm").length }), "04-latch-v1.1");
  await run("latch", "v1", () => ({ loaded: document.body.innerText.length > 20 && !document.querySelector("main.vtr") }), "05-latch-v1");
  // Older versions tab lists Latch v1.1
  await p.evaluate(() => document.querySelector('#tabs [data-t="older"]').click()); await sleep(800);
  const pt = await p.evaluate(() => { const r = [...document.querySelectorAll("#ovList *")].filter((e) => e.children.length < 8 && /^\s*\S*LATCH\s*$/.test(e.textContent.split("2 older")[0]) ).pop(); const b = (r || document.body).closest("button,[role=button],.orow,div") || r; b.scrollIntoView({ block: "center" }); const q = b.getBoundingClientRect(); return { x: q.left + q.width / 2, y: q.top + q.height / 2, t: b.textContent.slice(0, 30) }; });
  await p.mouse.click(pt.x, pt.y); await sleep(1000);
  const row = pt.t;
  const older = await p.evaluate(() => [...document.querySelectorAll("#ovList *, #sheet *, .asc *")].filter((e) => e.getClientRects().length && e.children.length === 0).map((e) => e.textContent).join(" | "));
  console.log("older row:", row);
  await p.screenshot({ path: "arcade/06-older-tab.png" });
  ok("Older versions tab lists Latch v1.1", /v1\.1 – \? on every button/.test(older));
  ok("arcade shell 0 JS errors", errs.length === 0, errs.join("; "));
  fs.writeFileSync("arcade/arcade.json", JSON.stringify(R, null, 1));
  console.log(`arcade: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close();
})();
