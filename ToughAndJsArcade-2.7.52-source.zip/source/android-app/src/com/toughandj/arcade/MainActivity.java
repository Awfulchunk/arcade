package com.toughandj.arcade;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.widget.Toast;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private ValueCallback<Uri[]> fileCb;
    private static final int PICK_WEB_FILE = 4243;
    private static final int PICK_IMG = 4244;
    private static final String TAG = "TJArcade";
    /** The arcade page bundled in assets. */
    private static final String START_URL = "file:///android_asset/index.html";
    /** UNUSED for now (no hosting; updates are picked from local files). Kept so a URL could be added later. */
    @SuppressWarnings("unused")
    private static final String UPDATE_URL = "";

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Uri pendingInstallUri = null;
    /** set when shouldInterceptRequest served the imported html for START_URL */
    private volatile boolean servedOverride = false;
    /** 2.7.50: Needle's on-phone download engine (window.TJNeedle). */
    private NeedleBridge needle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        setContentView(web);
        goImmersive();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.addJavascriptInterface(new Bridge(), "TJApp");
        needle = NeedleBridge.get(this);
        web.addJavascriptInterface(needle, "TJNeedle");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                // <input type=file> (Word Search v3 "Upload Picture"): open the phone's gallery / file picker
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    Intent in;
                    try { in = params.createIntent(); }
                    catch (Exception e0) { in = new Intent(Intent.ACTION_GET_CONTENT); in.addCategory(Intent.CATEGORY_OPENABLE); in.setType("image/*"); }
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(in, "Choose a file"), PICK_WEB_FILE);
                }
                catch (Exception e) { fileCb = null; cb.onReceiveValue(null); return false; }
                return true;
            }
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, "console: " + m.message() + " @" + m.sourceId() + ":" + m.lineNumber());
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return handleUrl(req.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleUrl(Uri.parse(url));
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                String u = req.getUrl().toString();
                WebResourceResponse n = needle != null ? needle.intercept(u) : null;
                if (n != null) return n;
                return interceptIndex(u);
            }
            @SuppressWarnings("deprecation")
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, String url) {
                WebResourceResponse n = needle != null ? needle.intercept(url) : null;
                if (n != null) return n;
                return interceptIndex(url);
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                // Safety net: if this WebView didn't let us intercept the asset URL, load the imported
                // file directly (still a file:// page, and Chromium shares one localStorage for file://).
                if (url != null && url.startsWith(START_URL) && !servedOverride) {
                    File f = activeOverride();
                    if (f != null) { Log.w(TAG, "intercept not used; loading override directly"); v.loadUrl(Uri.fromFile(f).toString()); return; }
                }
                if (url != null && url.startsWith("file://")) {
                    String js = readAsset("tj-wrapper.js");
                    if (js != null) v.evaluateJavascript(js, null);
                }
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else { servedOverride = false; web.loadUrl(START_URL); }
    }

    /** Keep everything inside the app offline; anything external opens in the browser. */
    private boolean handleUrl(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme();
        if (sc.equals("file") || sc.equals("about") || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { Log.w(TAG, "no handler for " + u); }
        return true;
    }

    @SuppressWarnings("deprecation")
    private void goImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) { web.onResume(); web.resumeTimers(); }
        goImmersive();
        // came back from the "allow installs from this app" settings screen
        if (pendingInstallUri != null && canInstall()) {
            Uri u = pendingInstallUri; pendingInstallUri = null; launchInstaller(u);
        }
    }

    @Override
    protected void onPause() {
        if (web != null) { web.onPause(); web.pauseTimers(); }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /** Back: let the arcade handle it (close sheet / leave game); at the menu, ask to exit. */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){try{return window.__tjBack?window.__tjBack():'exit';}catch(e){return 'exit';}})()", r -> {
            if (r != null && r.contains("handled")) return;
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Leave the arcade?")
                    .setMessage("Your progress and settings are saved.")
                    .setPositiveButton("Exit", (d, w) -> finish())
                    .setNegativeButton("Stay", null)
                    .setOnDismissListener(d -> goImmersive())
                    .show();
        });
    }

    // ---------------------------------------------------------------- local-file updates
    // Jay gets updates as files in chat. "Update" opens the file picker:
    //  * .html  -> validated, copied to filesDir/arcade/index.html and served IN PLACE of the bundled
    //              asset at the SAME URL (file:///android_asset/index.html) via shouldInterceptRequest,
    //              so the WebView origin (and every localStorage save) stays identical.
    //  * .apk   -> copied to cache/updates/ and handed to the system installer through our own
    //              FilesProvider content:// URI (must be signed with keys/tj-release.jks).
    // UPDATE_URL is intentionally unused (no hosting); assets/config.json keeps the slot for later.
    private static final int PICK_FILE = 4711;
    private static final String PREFS = "tj_update";

    private File overrideFile() { return new File(new File(getFilesDir(), "arcade"), "index.html"); }

    /** The overriding arcade html, or null if we should use the bundled one. */
    private File activeOverride() {
        File f = overrideFile();
        if (!f.isFile() || f.length() < 1000) return null;
        // an APK update with a newer built-in arcade wins over an older imported html
        int at = getSharedPreferences(PREFS, MODE_PRIVATE).getInt("importedOnVersionCode", 0);
        if (at < myVersionCode()) { f.delete(); getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply(); return null; }
        return f;
    }

    WebResourceResponse interceptIndex(String url) {
        if (url == null || !url.startsWith(START_URL)) return null;
        File f = activeOverride();
        if (f == null) return null;
        try { WebResourceResponse r = new WebResourceResponse("text/html", "UTF-8", new FileInputStream(f)); servedOverride = true; return r; }
        catch (Exception e) { return null; }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) { return readAll(in); } catch (Exception e) { return null; }
    }
    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] b = new byte[65536]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toString("UTF-8");
    }
    private int myVersionCode() {
        try { PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0); return p.versionCode; } catch (Exception e) { return 1; }
    }
    private String myVersionName() {
        try { PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0); return p.versionName; } catch (Exception e) { return "?"; }
    }
    private String arcadeVersionText() {
        if (activeOverride() == null) return "built-in " + myVersionName();
        long t = getSharedPreferences(PREFS, MODE_PRIVATE).getLong("importedAt", overrideFile().lastModified());
        return "updated " + new SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(new Date(t));
    }

    private void info(String title, String msg) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null)
                .setOnDismissListener(d -> goImmersive()).show();
    }

    private void showUpdateMenu() {
        if (isFinishing()) return;
        boolean overridden = activeOverride() != null;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Update Tough & J's Arcade")
                .setMessage("App: " + myVersionName() + "\nArcade: " + arcadeVersionText()
                        + "\n\nPick the file Tough sent you in chat:\n• tough-and-js-arcade.html  (game update)\n• ToughAndJsArcade-x.y.z.apk  (app update)\n\nYour saves and settings are kept.")
                .setPositiveButton("Pick file…", (d, w) -> openPicker())
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(d -> goImmersive());
        if (overridden) b.setNeutralButton("Reset to built-in", (d, w) -> confirmReset());
        b.show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this).setTitle("Reset to built-in version?")
                .setMessage("Goes back to the arcade that came with the app (" + myVersionName() + "). Saves are kept.")
                .setPositiveButton("Reset", (d, w) -> {
                    overrideFile().delete();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply();
                    reloadArcade();
                    Toast.makeText(this, "Back on the built-in arcade " + myVersionName(), Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("Cancel", null).setOnDismissListener(d -> goImmersive()).show();
    }

    private void openPicker() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, PICK_FILE);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "Pick the update file"), PICK_FILE);
            } catch (Exception e2) { info("No file picker", "This phone has no file picker app."); }
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK_IMG) {
            goImmersive();
            if (res != RESULT_OK || data == null) return;
            final java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
            if (data.getClipData() != null) { for (int k = 0; k < data.getClipData().getItemCount() && k < 12; k++) uris.add(data.getClipData().getItemAt(k).getUri()); }
            else if (data.getData() != null) uris.add(data.getData());
            new Thread(() -> {
                int n = 0;
                for (Uri u : uris) {
                    try {
                        String name = displayName(u); if (name == null) name = "picture";
                        String mime = getContentResolver().getType(u); if (mime == null) mime = "image/*";
                        InputStream in = getContentResolver().openInputStream(u);
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[65536]; int r; while ((r = in.read(buf)) > 0) { bo.write(buf, 0, r); if (bo.size() > 14 * 1024 * 1024) break; }
                        in.close();
                        final String b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                        final String id = "i" + System.currentTimeMillis() + "_" + (n++);
                        final String nm = name.replace("\\", "\\\\").replace("'", "\\'"), mm = mime;
                        ui.post(() -> web.evaluateJavascript("window.__tjImgBegin&&__tjImgBegin('" + id + "','" + nm + "','" + mm + "')", null));
                        for (int p = 0; p < b64.length(); p += 120000) {
                            final String part = b64.substring(p, Math.min(b64.length(), p + 120000));
                            ui.post(() -> web.evaluateJavascript("window.__tjImgPart&&__tjImgPart('" + id + "','" + part + "')", null));
                        }
                        ui.post(() -> web.evaluateJavascript("window.__tjImgEnd&&__tjImgEnd('" + id + "')", null));
                    } catch (Exception e) { Log.d(TAG, "pickImages failed: " + e); }
                }
            }).start();
            return;
        }
        if (req == PICK_WEB_FILE) {
            if (fileCb != null) fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null; goImmersive(); return;
        }
        if (req != PICK_FILE || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        final String name = displayName(u);
        Toast.makeText(this, "Reading " + (name == null ? "file" : name) + "…", Toast.LENGTH_SHORT).show();
        new Thread(() -> handlePicked(u, name)).start();
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return u.getLastPathSegment();
    }

    /** Runs on a worker thread. Sniffs the bytes (names from chat apps are unreliable). */
    private void handlePicked(Uri u, String name) {
        File tmp = new File(getCacheDir(), "picked.tmp");
        long size;
        try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("can't open");
            byte[] b = new byte[65536]; int n; size = 0;
            while ((n = in.read(b)) > 0) { out.write(b, 0, n); size += n; if (size > 300L * 1024 * 1024) throw new IOException("too big"); }
        } catch (Exception e) {
            ui.post(() -> info("Couldn't read that file", "Try saving it to Downloads first, then pick it again.\n\n(" + e.getMessage() + ")"));
            return;
        }
        byte[] head = new byte[4];
        try (InputStream in = new FileInputStream(tmp)) { int r = in.read(head); if (r < 4) head = new byte[4]; } catch (Exception ignored) {}
        String lname = name == null ? "" : name.toLowerCase(Locale.US);
        boolean isZip = head[0] == 'P' && head[1] == 'K' && head[2] == 3 && head[3] == 4;
        if (isZip || lname.endsWith(".apk")) {
            if (!isZip) { tmp.delete(); ui.post(() -> info("Not an app file", "That .apk looks broken or incomplete. Ask Tough to send it again.")); return; }
            File dir = new File(getCacheDir(), "updates"); dir.mkdirs();
            for (File old : dir.listFiles()) old.delete();
            File apk = new File(dir, "update.apk");
            if (!tmp.renameTo(apk)) { ui.post(() -> info("Couldn't prepare the update", "Not enough space?")); return; }
            final Uri cu = FilesProvider.uriFor(this, apk);
            ui.post(() -> installApk(cu));
            return;
        }
        // otherwise treat it as an arcade html
        String html;
        try (InputStream in = new FileInputStream(tmp)) { html = readAll(in); } catch (Exception e) { html = ""; }
        String low = html.length() > 4000 ? html.substring(0, 4000).toLowerCase(Locale.US) : html.toLowerCase(Locale.US);
        boolean looksHtml = low.contains("<html") || low.contains("<!doctype html");
        boolean isArcade = html.contains("Tough &amp; J's Arcade") || html.contains("Tough & J's Arcade") || html.contains("window.ARCADE=");
        if (!looksHtml || !isArcade || html.length() < 10000) {
            tmp.delete();
            final String why = !looksHtml ? "That isn't a web page or an .apk." : "That page isn't Tough & J's Arcade (pick tough-and-js-arcade.html).";
            ui.post(() -> info("Wrong file", why));
            return;
        }
        File dst = overrideFile(); dst.getParentFile().mkdirs();
        File part = new File(dst.getParentFile(), "index.html.part");
        part.delete();
        if (!tmp.renameTo(part) || !(part.renameTo(dst) || (dst.delete() && part.renameTo(dst)))) {
            ui.post(() -> info("Couldn't save the update", "Not enough space?")); return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putLong("importedAt", System.currentTimeMillis())
                .putInt("importedOnVersionCode", myVersionCode())
                .putString("fileName", name == null ? "" : name).apply();
        ui.post(() -> {
            reloadArcade();
            info("Arcade updated!", "Now running: " + arcadeVersionText() + "\nYour saves and settings are kept.\n\nUse Update → Reset to built-in to undo.");
        });
    }

    private void reloadArcade() {
        if (web == null) return;
        web.clearCache(false);
        servedOverride = false;
        web.loadUrl(START_URL);
    }

    private boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    private void installApk(Uri u) {
        if (!canInstall()) {
            pendingInstallUri = u;
            new AlertDialog.Builder(this).setTitle("One more step")
                    .setMessage("Allow Tough & J's Arcade to install updates (switch it on), then come back. Your saves are kept.")
                    .setPositiveButton("Open settings", (d, w) -> {
                        try { startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); }
                        catch (Exception e) { pendingInstallUri = null; info("Can't open settings", "Install the .apk from your Files app instead."); }
                    })
                    .setNegativeButton("Cancel", (d, w) -> pendingInstallUri = null)
                    .setOnDismissListener(d -> goImmersive()).show();
            return;
        }
        launchInstaller(u);
    }

    private void launchInstaller(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            info("Couldn't start the installer", "Open the .apk from your Files app instead.");
        }
    }

    private long saveBytes, saveTouched; private OutputStream saveOut; private Uri saveUri; private File saveFileLegacy; private String saveName;
    private void closeSave(boolean failed) {
        try { if (saveOut != null) saveOut.close(); } catch (Exception ignored) {}
        saveOut = null;
        if (saveUri != null) {
            try {
                if (failed) getContentResolver().delete(saveUri, null, null);
                else if (Build.VERSION.SDK_INT >= 29) { ContentValues cv = new ContentValues(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0); getContentResolver().update(saveUri, cv, null, null); }
            } catch (Exception ignored) {}
            saveUri = null;
        }
        if (failed && saveFileLegacy != null) { saveFileLegacy.delete(); }
        saveFileLegacy = null;
    }

    /** Exposed to the page as window.TJApp */
    private class Bridge {
        /** 2.6.4: native picture picker used by the Emoji maker as a backup to the web file input. Pictures come back through __tjImgBegin/__tjImgPart/__tjImgEnd. */
        @JavascriptInterface public void pickImages() {
            ui.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(i, "Pick pictures or GIFs"), PICK_IMG);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "No picture picker on this phone.", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void checkUpdate() { ui.post(MainActivity.this::showUpdateMenu); }
        @JavascriptInterface public void openUpdate() { ui.post(MainActivity.this::showUpdateMenu); }
        @JavascriptInterface public String arcadeVersion() { return arcadeVersionText(); }
        @JavascriptInterface public String versionName() { return myVersionName(); }
        @JavascriptInterface public int versionCode() { return myVersionCode(); }
        @JavascriptInterface public boolean canPickFiles() { return true; }
        @JavascriptInterface public void exitApp() { ui.post(MainActivity.this::finish); }
        // ---- save a file the page made (blob/data download) into Downloads/ToughAndJs ----
        @JavascriptInterface public synchronized boolean beginSave(String name, String mime) {
            try {
                if (saveOut != null && System.currentTimeMillis() - saveTouched < 4000) return false; // another save is still writing: never mix two files
                closeSave(false);
                saveBytes = 0; saveTouched = System.currentTimeMillis();
                String safe = (name == null || name.trim().isEmpty()) ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                saveName = safe;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ToughAndJs");
                    saveUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (saveUri == null) return false;
                    saveOut = getContentResolver().openOutputStream(saveUri);
                } else {
                    File dir = getExternalFilesDir(null); if (dir == null) dir = getFilesDir();
                    dir = new File(dir, "Download"); dir.mkdirs();
                    saveFileLegacy = new File(dir, safe);
                    saveOut = new FileOutputStream(saveFileLegacy);
                }
                return saveOut != null;
            } catch (Exception e) { Log.w(TAG, "beginSave " + e); closeSave(true); return false; }
        }
        @JavascriptInterface public synchronized boolean saveChunk(String b64) {
            try { if (saveOut == null) return false; byte[] d = Base64.decode(b64, Base64.DEFAULT); saveOut.write(d); saveBytes += d.length; saveTouched = System.currentTimeMillis(); return true; }
            catch (Exception e) { Log.w(TAG, "saveChunk " + e); closeSave(true); return false; }
        }
        @JavascriptInterface public synchronized String lastSaveBytes() { return String.valueOf(saveBytes); }
        /** Cartridge: finish the save, but only keep the file if exactly `expected` bytes were written; otherwise delete it. */
        @JavascriptInterface public synchronized String endSaveChecked(String expected) {
            String n = saveName; boolean have = saveOut != null; long got = saveBytes, want = -1;
            try { want = Long.parseLong(expected); } catch (Exception ignored) {}
            boolean good = have && got == want;
            closeSave(!good);
            final String msg = good ? ("Saved " + n + " (" + got + " bytes) to Downloads/ToughAndJs") : ("Save of " + n + " was wrong (" + got + " of " + want + " bytes) and was deleted");
            ui.post(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
            return good ? "ok" : ("bad " + got + "/" + want);
        }
        @JavascriptInterface public synchronized String endSave() {
            String n = saveName; boolean ok = saveOut != null;
            closeSave(false);
            final String msg = ok ? ("Saved " + n + " to Downloads/ToughAndJs") : "Couldn't save that file";
            ui.post(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
            return ok ? "ok" : "fail";
        }
    }
}
