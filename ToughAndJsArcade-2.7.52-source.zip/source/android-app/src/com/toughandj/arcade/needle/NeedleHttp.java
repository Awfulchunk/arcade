package com.toughandj.arcade.needle;

import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Plain HttpURLConnection downloader for NewPipeExtractor (works on the JVM and on Android, no OkHttp). */
public final class NeedleHttp extends Downloader {
    public static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0";
    private static final NeedleHttp INSTANCE = new NeedleHttp();
    public static NeedleHttp get() { return INSTANCE; }
    private NeedleHttp() {}

    @Override
    public Response execute(Request request) throws IOException, ReCaptchaException {
        String url = request.url();
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestMethod(request.httpMethod());
        boolean hasUa = false;
        for (Map.Entry<String, List<String>> h : request.headers().entrySet()) {
            if (h.getKey().equalsIgnoreCase("User-Agent")) hasUa = true;
            StringBuilder sb = new StringBuilder();
            for (String v : h.getValue()) { if (sb.length() > 0) sb.append(", "); sb.append(v); }
            c.setRequestProperty(h.getKey(), sb.toString());
        }
        if (!hasUa) c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept-Encoding", "gzip");
        byte[] data = request.dataToSend();
        if (data != null) {
            c.setDoOutput(true);
            try (OutputStream o = c.getOutputStream()) { o.write(data); }
        }
        int code = c.getResponseCode();
        if (code == 429) {
            c.disconnect();
            throw new ReCaptchaException("reCaptcha Challenge requested", url);
        }
        String body = "";
        InputStream in = null;
        try { in = code >= 400 ? c.getErrorStream() : c.getInputStream(); } catch (IOException ignored) {}
        if (in != null) {
            if ("gzip".equalsIgnoreCase(c.getContentEncoding())) in = new GZIPInputStream(in);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            body = bo.toString("UTF-8");
        }
        String latest = c.getURL().toString();
        Map<String, List<String>> headers = c.getHeaderFields();
        c.disconnect();
        return new Response(code, c.getResponseMessage(), headers, body, latest);
    }
}
