package com.toughandj.arcade.needle;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;

/** Android-only media work for Needle: decode any phone-supported audio to PCM (-> real MP3 / WAV), and pull an AAC track out of an .mp4. */
public final class NeedleMedia {
    private NeedleMedia() {}

    public interface Frac { void at(double f); }

    /** Receives interleaved 16-bit PCM. */
    interface PcmSink { void pcm(short[] s, int frames, int channels, int rate) throws IOException; void end() throws IOException; }

    /** Decode the first audio track of `in` and feed PCM to sink. */
    static void decode(File in, PcmSink sink, AtomicBoolean cancel, Frac frac) throws NeedleCore.NeedleError {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec dec = null;
        try {
            ex.setDataSource(in.getPath());
            int track = -1; MediaFormat f = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat t = ex.getTrackFormat(i);
                String m = t.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; f = t; break; }
            }
            if (track < 0) throw new NeedleCore.NeedleError("nosound", "That file has no sound track.");
            ex.selectTrack(track);
            String mime = f.getString(MediaFormat.KEY_MIME);
            long durUs = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) : -1;
            int rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE), ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            try { dec = MediaCodec.createDecoderByType(mime); }
            catch (Exception e) { throw new NeedleCore.NeedleError("codec", "This phone can't decode " + mime + " sound."); }
            dec.configure(f, null, null, 0);
            dec.start();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inEos = false, outEos = false, isFloat = false;
            short[] sb = new short[0];
            int idle = 0;
            while (!outEos) {
                if (cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
                if (!inEos) {
                    int ii = dec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer b = dec.getInputBuffer(ii);
                        int n = b == null ? -1 : ex.readSampleData(b, 0);
                        if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inEos = true; }
                        else { dec.queueInputBuffer(ii, 0, n, Math.max(0, ex.getSampleTime()), 0); ex.advance(); }
                    }
                }
                int oi = dec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    isFloat = of.containsKey("pcm-encoding") && of.getInteger("pcm-encoding") == 4; // AudioFormat.ENCODING_PCM_FLOAT
                } else if (oi >= 0) {
                    idle = 0;
                    ByteBuffer ob = dec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        ((java.nio.Buffer) ob).position(info.offset); ((java.nio.Buffer) ob).limit(info.offset + info.size);
                        ByteBuffer le = ob.slice().order(ByteOrder.LITTLE_ENDIAN);
                        int samples = isFloat ? info.size / 4 : info.size / 2;
                        if (sb.length < samples) sb = new short[samples];
                        if (isFloat) { for (int i = 0; i < samples; i++) { float v = le.getFloat(i * 4); sb[i] = (short) Math.max(-32768, Math.min(32767, Math.round(v * 32767f))); } }
                        else le.asShortBuffer().get(sb, 0, samples);
                        sink.pcm(sb, samples / Math.max(1, ch), ch, rate);
                    }
                    dec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outEos = true;
                    if (durUs > 0 && frac != null) frac.at(Math.min(1, info.presentationTimeUs / (double) durUs));
                } else if (inEos && ++idle > 500) {
                    break; // decoder never signalled end (seen on a few old codecs): ~5 s with nothing, call it done
                }
            }
            sink.end();
        } catch (NeedleCore.NeedleError e) { throw e; }
        catch (Exception e) { throw new NeedleCore.NeedleError("decode", "Couldn't read the sound in that file (" + e.getClass().getSimpleName() + ")."); }
        finally {
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) {}
            ex.release();
        }
    }

    /** Real MP3 at kbps via LAME (jump3r). */
    public static void toMp3(File in, File out, int kbps, AtomicBoolean cancel, Frac frac) throws NeedleCore.NeedleError {
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
            final NeedleMp3[] enc = {null};
            decode(in, new PcmSink() {
                @Override public void pcm(short[] s, int frames, int channels, int rate) throws IOException {
                    if (enc[0] == null) enc[0] = new NeedleMp3(channels, rate, kbps, os);
                    enc[0].writePcm16(s, frames, channels);
                }
                @Override public void end() throws IOException { if (enc[0] != null) enc[0].finish(); }
            }, cancel, frac);
            if (enc[0] == null) throw new NeedleCore.NeedleError("nosound", "No sound came out of that file.");
        } catch (NeedleCore.NeedleError e) { out.delete(); throw e; }
        catch (IOException e) { out.delete(); throw new NeedleCore.NeedleError("encode", "MP3 encoding failed: " + e.getMessage()); }
    }

    /** 16-bit PCM WAV (stereo max). */
    public static void toWav(File in, File out, AtomicBoolean cancel, Frac frac) throws NeedleCore.NeedleError {
        try (RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            raf.setLength(0);
            raf.write(new byte[44]);
            final long[] bytes = {0}; final int[] fmt = {0, 0};
            final byte[][] buf = {new byte[0]};
            decode(in, new PcmSink() {
                @Override public void pcm(short[] s, int frames, int channels, int rate) throws IOException {
                    int oc = Math.min(2, channels);
                    if (fmt[0] == 0) { fmt[0] = oc; fmt[1] = rate; }
                    int need = frames * oc * 2;
                    if (buf[0].length < need) buf[0] = new byte[need];
                    byte[] b = buf[0]; int k = 0;
                    for (int i = 0; i < frames; i++) for (int c = 0; c < oc; c++) { short v = s[i * channels + c]; b[k++] = (byte) v; b[k++] = (byte) (v >> 8); }
                    raf.write(b, 0, need); bytes[0] += need;
                    if (bytes[0] > 0xFFFFFFF0L - 44) throw new IOException("over 4 GB");
                }
                @Override public void end() {}
            }, cancel, frac);
            if (fmt[0] == 0) throw new NeedleCore.NeedleError("nosound", "No sound came out of that file.");
            ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
            h.put(new byte[]{'R', 'I', 'F', 'F'}).putInt((int) (36 + bytes[0])).put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '})
             .putInt(16).putShort((short) 1).putShort((short) fmt[0]).putInt(fmt[1]).putInt(fmt[1] * fmt[0] * 2).putShort((short) (fmt[0] * 2)).putShort((short) 16)
             .put(new byte[]{'d', 'a', 't', 'a'}).putInt((int) bytes[0]);
            raf.seek(0); raf.write(h.array());
        } catch (NeedleCore.NeedleError e) { out.delete(); throw e; }
        catch (IOException e) { out.delete(); throw new NeedleCore.NeedleError("encode", "WAV writing failed: " + e.getMessage()); }
    }

    /** Copy the AAC sound track of an .mp4/.m4a/.mov into a plain .m4a (no re-encode). */
    public static void aacToM4a(File in, File out, AtomicBoolean cancel) throws NeedleCore.NeedleError {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mx = null; boolean started = false;
        try {
            ex.setDataSource(in.getPath());
            int track = -1; MediaFormat f = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat t = ex.getTrackFormat(i);
                if ("audio/mp4a-latm".equals(t.getString(MediaFormat.KEY_MIME))) { track = i; f = t; break; }
            }
            if (track < 0) throw new NeedleCore.NeedleError("noaac", "That file's sound isn't AAC, so it can't become .m4a without re-encoding. Pick mp3 or wav instead.");
            ex.selectTrack(track);
            mx = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int ot = mx.addTrack(f);
            mx.start(); started = true;
            int cap = f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE) ? Math.max(f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE), 65536) : 1 << 20;
            ByteBuffer b = ByteBuffer.allocateDirect(cap);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                if (cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
                int n = ex.readSampleData(b, 0);
                if (n < 0) break;
                info.set(0, n, Math.max(0, ex.getSampleTime()), (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
                mx.writeSampleData(ot, b, info);
                ex.advance();
            }
        } catch (NeedleCore.NeedleError e) { out.delete(); throw e; }
        catch (Exception e) { out.delete(); throw new NeedleCore.NeedleError("mux", "Couldn't copy the sound out (" + e.getClass().getSimpleName() + ")."); }
        finally {
            try { if (mx != null) { if (started) mx.stop(); mx.release(); } } catch (Exception ignored) {}
            ex.release();
        }
    }
}
