package com.toughandj.arcade.needle;

import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.exceptions.AgeRestrictedContentException;
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException;
import org.schabi.newpipe.extractor.exceptions.GeographicRestrictionException;
import org.schabi.newpipe.extractor.exceptions.PaidContentException;
import org.schabi.newpipe.extractor.exceptions.ParsingException;
import org.schabi.newpipe.extractor.exceptions.PrivateContentException;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import org.schabi.newpipe.extractor.exceptions.SignInConfirmNotBotException;
import org.schabi.newpipe.extractor.exceptions.YoutubeMusicPremiumContentException;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.AudioTrackType;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Needle's on-phone engine, platform-neutral half (runs on the JVM for tests and on Android):
 *  - reads a YouTube / Shorts / youtu.be link with NewPipeExtractor (GPL-3) and lists the REAL streams it offers
 *  - reads a direct file link (HEAD / 1-byte GET) and lists the one file it is
 *  - downloads a stream to a file in chunks, with progress and cancel
 * Android-only work (merge with MediaMuxer, decode with MediaCodec) lives in NeedleMedia.
 */
public final class NeedleCore {
    private NeedleCore() {}
    private static volatile boolean inited;
    public static synchronized void init() {
        if (inited) return;
        NewPipe.init(NeedleHttp.get());
        inited = true;
    }

    /** A failure with a plain-words message for Jay. */
    public static final class NeedleError extends Exception {
        public final String code;
        public NeedleError(String code, String msg) { super(msg); this.code = code; }
        public NeedleError(String code, String msg, Throwable cause) { super(msg, cause); this.code = code; }
    }

    public interface Progress { void bytes(long done, long total); }

    /** One stream (or stream pair) the user can pick. */
    public static final class Option {
        public String id;          // stable id inside one probe
        public String kind;        // "audio" | "video"
        public String label;       // short, e.g. "720p60"
        public String detail;      // honest description, e.g. "H.264 video + AAC 128 kbps audio, merged into one .mp4"
        public String container;   // source container: m4a | webm | mp4 | file
        public String codec;       // e.g. aac, opus, avc1
        public int height, fps, kbps;
        public long bytes = -1;    // approximate total, -1 = unknown
        public String videoUrl, audioUrl; public long videoBytes = -1, audioBytes = -1;
        public String ext;         // extension of the downloaded source (before any conversion)
        public boolean merge;      // video-only + audio-only -> one mp4
    }

    public static final class Probe {
        public String source;      // "youtube" | "web"
        public String client;      // which YouTube reader produced it (visionos | android_vr | tv_samsung), null for web
        public String userAgent;   // UA the stream links expect (null = Needle's normal one)
        public String url, id, title, uploader, thumbnail, mime, fileName;
        public long durationSec = -1;
        public final List<Option> audio = new ArrayList<>();
        public final List<Option> video = new ArrayList<>();
    }

    // ------------------------------------------------------------------ URLs
    private static final Pattern YT_ID = Pattern.compile("^[\\w-]{11}$");

    /** Video id from watch / shorts / youtu.be / m. / music. / embed / live links, ?si= and other junk ignored. */
    public static String youtubeId(String raw) {
        if (raw == null) return null;
        String s = raw.trim().replaceAll("[),.;!?]+$", "");
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        try {
            URL u = new URL(s);
            String host = u.getHost().toLowerCase(Locale.US).replaceFirst("^(www|m|music)\\.", "");
            String path = u.getPath() == null ? "" : u.getPath();
            if (host.equals("youtu.be")) {
                String[] seg = path.split("/");
                for (String p : seg) if (!p.isEmpty()) return YT_ID.matcher(p).matches() ? p : null;
                return null;
            }
            if (!host.equals("youtube.com") && !host.equals("youtube-nocookie.com")) return null;
            String q = u.getQuery();
            if (q != null) for (String kv : q.split("&")) {
                int e = kv.indexOf('=');
                if (e > 0 && kv.substring(0, e).equals("v")) {
                    String v = URLDecoder.decode(kv.substring(e + 1), "UTF-8");
                    if (YT_ID.matcher(v).matches()) return v;
                }
            }
            Matcher m = Pattern.compile("/(shorts|embed|live|v)/([\\w-]{11})(?:[/?#]|$)").matcher(path);
            if (m.find()) return m.group(2);
        } catch (Exception ignored) {}
        return null;
    }

    public static boolean isPrivateHost(String host) {
        String h = host == null ? "" : host.replaceAll("^\\[|\\]$", "").toLowerCase(Locale.US);
        if (h.isEmpty() || h.equals("localhost") || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan")) return true;
        if (h.equals("0.0.0.0") || h.equals("::") || h.equals("::1")) return true;
        if (h.matches("^(127\\.|10\\.|192\\.168\\.|0\\.|169\\.254\\.|172\\.(1[6-9]|2\\d|3[0-1])\\.).*")) return true;
        if (h.startsWith("fc") || h.startsWith("fd") || h.startsWith("fe80")) return true;
        return false;
    }

    /** Also refuse names that RESOLVE to a home-network address (so a link can't poke the router). */
    /** unit tests only (a local fake YouTube server on 127.0.0.1); never set in the app */
    static volatile boolean testAllowLoopback;
    static void checkPublic(URL u) throws NeedleError {
        if (testAllowLoopback && "127.0.0.1".equals(u.getHost())) return;
        if (isPrivateHost(u.getHost())) throw new NeedleError("private", "Links to this phone or your home network are blocked.");
        try {
            for (InetAddress a : InetAddress.getAllByName(u.getHost())) {
                if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress() || a.isAnyLocalAddress())
                    throw new NeedleError("private", "That link points into a home network. Blocked.");
            }
        } catch (NeedleError e) { throw e; } catch (Exception e) {
            throw new NeedleError("offline", "Couldn't find " + u.getHost() + ". Is the phone online?");
        }
    }

    // ------------------------------------------------------------------ probe
    public static Probe probe(String raw) throws NeedleError { return probe(raw, null, null, null); }

    /** 2.7.51: YouTube links go through NeedleYouTube (auto-retry with backoff + player-client fallback). */
    public static Probe probe(String raw, java.util.Set<String> avoid, NeedleYouTube.Notes notes, AtomicBoolean cancel) throws NeedleError {
        String id = youtubeId(raw);
        if (id != null) return NeedleYouTube.get().probe(id, avoid, notes, cancel);
        return probeDirect(raw);
    }

    static int parseHeight(String res) {
        if (res == null) return 0;
        Matcher m = Pattern.compile("(\\d{3,4})p").matcher(res);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    static NeedleError mapYoutube(Throwable e) {
        Throwable t = e;
        for (int i = 0; t != null && i < 6; i++, t = t.getCause()) {
            if (t instanceof SignInConfirmNotBotException) return new NeedleError("bot", "YouTube asked this phone to \"confirm you're not a bot\". Wait a while, switch Wi-Fi/mobile data, or use Home-PC server mode in Settings.", e);
            if (t instanceof AgeRestrictedContentException) return new NeedleError("age", "This video is age-restricted. YouTube only shows it to signed-in adults, and Needle on the phone doesn't sign in. Home-PC server mode may work.", e);
            if (t instanceof GeographicRestrictionException) return new NeedleError("region", "This video is blocked in your country.", e);
            if (t instanceof PrivateContentException) return new NeedleError("private", "This video is private.", e);
            if (t instanceof PaidContentException || t instanceof YoutubeMusicPremiumContentException) return new NeedleError("paid", "This video needs a paid YouTube membership.", e);
            if (t instanceof ReCaptchaException) return new NeedleError("bot", "YouTube is blocking this phone for now (too many requests). Wait a while or switch networks.", e);
            if (t instanceof ContentNotAvailableException) return new NeedleError("unavailable", "YouTube says this video isn't available" + (t.getMessage() != null ? ": " + clip(t.getMessage()) : "."), e);
            if (t instanceof java.net.UnknownHostException) return new NeedleError("offline", "No internet. Check Wi-Fi or mobile data.", e);
            if (t instanceof java.net.SocketTimeoutException) return new NeedleError("offline", "YouTube took too long to answer. Try again.", e);
        }
        if (e instanceof ParsingException || (e.getCause() instanceof ParsingException))
            return new NeedleError("changed", "YouTube changed its site and Needle's reader (NewPipeExtractor) can't read it right now. An app update with a newer extractor will fix it; Home-PC server mode is the fallback.", e);
        if (e instanceof IOException) return new NeedleError("network", "Network problem talking to YouTube: " + clip(String.valueOf(e.getMessage())), e);
        return new NeedleError("changed", "Couldn't read this YouTube video (" + e.getClass().getSimpleName() + "). YouTube may have changed its site; Home-PC server mode is the fallback.", e);
    }

    static String clip(String s) { return s.length() > 160 ? s.substring(0, 160) + "…" : s; }

    // ------------------------------------------------------------------ direct links
    private static final Pattern MEDIA_EXT = Pattern.compile("(?i)\\.(mp4|m4v|webm|mkv|mov|3gp|m4a|mp3|aac|ogg|oga|opus|wav|flac)$");

    static Probe probeDirect(String raw) throws NeedleError {
        String s = raw == null ? "" : raw.trim();
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        URL u;
        try { u = new URL(s); } catch (Exception e) { throw new NeedleError("badurl", "That isn't a link Needle can read."); }
        if (!u.getProtocol().equalsIgnoreCase("https") && !u.getProtocol().equalsIgnoreCase("http")) throw new NeedleError("badurl", "Only http/https links.");
        if (u.getUserInfo() != null) throw new NeedleError("badurl", "Links with a username or password are blocked.");
        checkPublic(u);
        HttpURLConnection c = null;
        try {
            c = open(u.toString(), "bytes=0-0");
            int code = c.getResponseCode();
            if (code >= 400) throw new NeedleError("http", "That link answered " + code + (code == 403 ? " (forbidden)" : code == 404 ? " (not found)" : "") + ".");
            URL fin = c.getURL(); checkPublic(fin);
            String type = c.getContentType() == null ? "" : c.getContentType().toLowerCase(Locale.US);
            long total = totalFromRange(c.getHeaderField("Content-Range"));
            if (total < 0 && code == 200) total = c.getContentLengthLong();
            String name = fileNameFrom(c.getHeaderField("Content-Disposition"), fin.getPath());
            String ext = extOf(name);
            boolean media = type.startsWith("audio/") || type.startsWith("video/") || MEDIA_EXT.matcher(name).find()
                    || (type.contains("octet-stream") && MEDIA_EXT.matcher(name).find());
            if (type.startsWith("text/html") || !media) {
                throw new NeedleError("notfile", "That link is a web page, not a sound or video file. On the phone Needle pulls YouTube links and direct file links (ending .mp4, .mp3, .m4a, .webm, .ogg, .wav…). Home-PC server mode can read other pages.");
            }
            if (ext.isEmpty()) ext = type.startsWith("audio/mpeg") ? "mp3" : type.startsWith("audio/") ? "m4a" : "mp4";
            Probe p = new Probe();
            p.source = "web"; p.url = u.toString(); p.title = name.replaceAll("\\.[^.]+$", ""); p.fileName = name; p.mime = type;
            boolean isVideo = type.startsWith("video/") || ext.matches("mp4|m4v|webm|mkv|mov|3gp");
            Option o = new Option();
            o.kind = isVideo ? "video" : "audio"; o.id = "file"; o.container = "file"; o.ext = ext;
            o.codec = ext; o.bytes = total; o.videoBytes = total;
            o.videoUrl = u.toString(); o.audioUrl = u.toString();
            o.label = "Original ." + ext;
            o.detail = "The file itself, exactly as the site has it (direct links come in one quality)" + (type.isEmpty() ? "" : ", " + type.split(";")[0]);
            (isVideo ? p.video : p.audio).add(o);
            if (isVideo) { // a video file can also give its sound
                Option a = new Option();
                a.kind = "audio"; a.id = "file"; a.container = "file"; a.ext = ext; a.codec = ext; a.bytes = total;
                a.audioUrl = u.toString(); a.videoUrl = u.toString();
                a.label = "Sound from ." + ext;
                a.detail = "Downloads the whole video file, then keeps only its sound";
                p.audio.add(a);
            }
            return p;
        } catch (NeedleError e) { throw e; }
        catch (java.net.UnknownHostException e) { throw new NeedleError("offline", "Couldn't find " + u.getHost() + ". Is the phone online?", e); }
        catch (IOException e) { throw new NeedleError("network", "Couldn't reach that link: " + clip(String.valueOf(e.getMessage())), e); }
        finally { if (c != null) c.disconnect(); }
    }

    static String extOf(String name) {
        int d = name.lastIndexOf('.');
        String e = d >= 0 ? name.substring(d + 1).toLowerCase(Locale.US) : "";
        return e.matches("[a-z0-9]{2,4}") ? e : "";
    }

    static String fileNameFrom(String disp, String path) {
        if (disp != null) {
            Matcher m = Pattern.compile("(?i)filename\\*?=(?:UTF-8'')?\"?([^\";]+)").matcher(disp);
            if (m.find()) { try { return safeName(URLDecoder.decode(m.group(1), "UTF-8")); } catch (Exception ignored) {} }
        }
        String last = path == null ? "" : path.replaceAll(".*/", "");
        try { last = URLDecoder.decode(last, "UTF-8"); } catch (Exception ignored) {}
        return safeName(last.isEmpty() ? "file" : last);
    }

    public static String safeName(String s) {
        String t = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").replaceAll("\\s+", " ").trim();
        if (t.length() > 90) t = t.substring(0, 90).trim();
        return t.isEmpty() ? "file" : t;
    }

    static long totalFromRange(String cr) {
        if (cr == null) return -1;
        int s = cr.lastIndexOf('/');
        try { return s >= 0 ? Long.parseLong(cr.substring(s + 1).trim()) : -1; } catch (Exception e) { return -1; }
    }

    static HttpURLConnection open(String url, String range) throws IOException { return open(url, range, null); }

    static HttpURLConnection open(String url, String range, String ua) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", ua != null ? ua : NeedleHttp.UA);
        c.setRequestProperty("Accept", "*/*");
        if (range != null) c.setRequestProperty("Range", range);
        return c;
    }

    // ------------------------------------------------------------------ download
    /** YouTube throttles long single reads; ~10 MB range chunks keep full speed. */
    static final long CHUNK = 9L * 1024 * 1024;
    public static final long MAX_BYTES = 2L * 1024 * 1024 * 1024; // 2 GB hard cap per file

    /**
     * Download url into out. Chunked Range requests with 3 retries per chunk (resumes where it stopped).
     * Works for servers without Range too (single stream).
     */
    public static long download(String url, File out, long knownTotal, Progress prog, AtomicBoolean cancel) throws NeedleError {
        return download(url, out, knownTotal, prog, cancel, null);
    }

    public static long download(String url, File out, long knownTotal, Progress prog, AtomicBoolean cancel, String ua) throws NeedleError {
        try { checkPublic(new URL(url)); } catch (NeedleError e) { throw e; } catch (Exception e) { throw new NeedleError("badurl", "Bad stream link."); }
        long done = 0, total = knownTotal;
        byte[] buf = new byte[64 * 1024];
        try (RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            raf.setLength(0);
            int fails = 0;
            boolean rangeOk = true;
            while (total < 0 || done < total) {
                if (cancel.get()) throw new NeedleError("cancelled", "Cancelled.");
                long end = done + CHUNK - 1;
                if (total > 0) end = Math.min(end, total - 1);
                HttpURLConnection c = null;
                try {
                    c = open(url, rangeOk ? ("bytes=" + done + "-" + end) : null, ua);
                    int code = c.getResponseCode();
                    if (code == 416 && total < 0) break; // asked past the end of an unknown-length file
                    if (code == 403) throw new NeedleError("forbidden", "The server refused the download (403). For YouTube the link may have expired: pull it again.");
                    if (code >= 400) throw new IOException("HTTP " + code);
                    if (code == 200) { // server ignored Range: take the whole body from the start
                        if (done > 0) { raf.setLength(0); raf.seek(0); done = 0; }
                        rangeOk = false;
                        long len = c.getContentLengthLong();
                        if (len > 0) total = len;
                    } else if (total < 0) {
                        total = totalFromRange(c.getHeaderField("Content-Range"));
                    }
                    if (total > MAX_BYTES) throw new NeedleError("toobig", "That file is bigger than 2 GB. Too big for the phone.");
                    raf.seek(done);
                    try (InputStream in = c.getInputStream()) {
                        int n; long got = 0;
                        while ((n = in.read(buf)) > 0) {
                            if (cancel.get()) throw new NeedleError("cancelled", "Cancelled.");
                            raf.write(buf, 0, n); done += n; got += n;
                            if (done > MAX_BYTES) throw new NeedleError("toobig", "That file is bigger than 2 GB. Too big for the phone.");
                            if (prog != null) prog.bytes(done, total);
                        }
                        if (got == 0 && rangeOk && total < 0) break;
                    }
                    fails = 0;
                    if (!rangeOk) break; // single full stream finished
                } catch (NeedleError e) { throw e; }
                catch (InterruptedIOException | java.net.SocketException e) {
                    if (++fails > 3) throw new NeedleError("network", "The download kept dropping. Check the connection and try again.", e);
                    sleep(800L * fails);
                } catch (IOException e) {
                    if (++fails > 3) throw new NeedleError("network", "Download failed: " + clip(String.valueOf(e.getMessage())), e);
                    sleep(800L * fails);
                } finally { if (c != null) c.disconnect(); }
            }
            if (total > 0 && done < total) throw new NeedleError("network", "The download stopped early (" + done + " of " + total + " bytes).");
            if (done < 256) throw new NeedleError("empty", "The server sent an empty file. The stream was blocked.");
            return done;
        } catch (NeedleError e) { out.delete(); throw e; }
        catch (IOException e) { out.delete(); throw new NeedleError("disk", "Couldn't write the file on the phone (storage full?).", e); }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

    // ------------------------------------------------------------------ tiny JSON helpers (no org.json on the JVM)
    public static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '<': b.append("\\u003c"); break;
                default:
                    if (ch < 0x20 || ch == 0x2028 || ch == 0x2029) b.append(String.format(Locale.US, "\\u%04x", (int) ch));
                    else b.append(ch);
            }
        }
        return b.append('"').toString();
    }

    /** Probe -> JSON for the page. Stream URLs are NOT sent to the page; they stay native. */
    public static String toJson(Probe p) {
        StringBuilder b = new StringBuilder("{");
        b.append("\"ok\":true,\"source\":").append(q(p.source)).append(",\"url\":").append(q(p.url))
         .append(",\"id\":").append(q(p.id)).append(",\"title\":").append(q(p.title)).append(",\"uploader\":").append(q(p.uploader))
         .append(",\"durationSec\":").append(p.durationSec).append(",\"fileName\":").append(q(p.fileName));
        b.append(",\"audio\":"); opts(b, p.audio);
        b.append(",\"video\":"); opts(b, p.video);
        return b.append('}').toString();
    }

    private static void opts(StringBuilder b, List<Option> l) {
        b.append('[');
        for (int i = 0; i < l.size(); i++) {
            Option o = l.get(i);
            if (i > 0) b.append(',');
            b.append("{\"id\":").append(q(o.id)).append(",\"kind\":").append(q(o.kind)).append(",\"label\":").append(q(o.label))
             .append(",\"detail\":").append(q(o.detail)).append(",\"container\":").append(q(o.container)).append(",\"codec\":").append(q(o.codec))
             .append(",\"ext\":").append(q(o.ext)).append(",\"height\":").append(o.height).append(",\"fps\":").append(o.fps)
             .append(",\"kbps\":").append(o.kbps).append(",\"bytes\":").append(o.bytes).append(",\"merge\":").append(o.merge).append('}');
        }
        b.append(']');
    }

    public static Option find(Probe p, String kind, String id) {
        for (Option o : "video".equals(kind) ? p.video : p.audio) if (o.id.equals(id)) return o;
        return null;
    }

    public static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }
    @SuppressWarnings("unused") private static void touch(File f) throws IOException { new FileOutputStream(f, true).close(); }
}
