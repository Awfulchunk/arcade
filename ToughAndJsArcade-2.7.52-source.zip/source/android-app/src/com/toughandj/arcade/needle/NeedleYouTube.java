package com.toughandj.arcade.needle;

import com.grack.nanojson.JsonArray;
import com.grack.nanojson.JsonObject;
import com.grack.nanojson.JsonParser;
import com.grack.nanojson.JsonWriter;

import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.localization.ContentCountry;
import org.schabi.newpipe.extractor.localization.Localization;
import org.schabi.newpipe.extractor.services.youtube.InnertubeClientRequestInfo;
import org.schabi.newpipe.extractor.services.youtube.YoutubeJavaScriptPlayerManager;
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.AudioTrackType;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.net.HttpURLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 2.7.51: reading YouTube with automatic retry + player-client fallback.
 *
 * Readers ("clients"), in order:
 *  1. visionos     - NewPipeExtractor 0.27.1's own reader (StreamInfo). Default.
 *  2. android_vr   - YouTube's Android VR (Quest) player client, asked directly; plain stream URLs, no JavaScript.
 *  3. tv_samsung   - YouTube's TV (TVHTML5) player client, asked directly; its URLs need YouTube's player JavaScript,
 *                    which NewPipeExtractor's YoutubeJavaScriptPlayerManager runs (signature + "n" parameter).
 * Every reader's result is checked with a tiny real download (1 KB) before it is trusted, because YouTube sometimes
 * hands out stream links that answer 403. A reader that works is remembered for the rest of the app session.
 * Rounds: up to 3, with a short wait between them (4 s, then 8 s), cancellable, and a status note for the page.
 * Nothing is faked: if every reader fails, the real error is shown.
 */
public final class NeedleYouTube {

    // ------------------------------------------------------------------ plug points (tests replace these)
    public interface Client { String name(); NeedleCore.Probe read(String id) throws NeedleCore.NeedleError; }
    public interface Checker { void check(NeedleCore.Probe p) throws NeedleCore.NeedleError; }
    public interface Sleeper { void sleep(long ms, AtomicBoolean cancel) throws NeedleCore.NeedleError; }
    public interface Notes { void note(String s); }

    public static final int ROUNDS = 3;
    public static final long[] BACKOFF_MS = {4000, 8000};

    final List<Client> clients;
    final Checker checker;
    final Sleeper sleeper;
    /** session memory: the reader that last worked goes first; readers whose code path is broken are skipped */
    volatile String preferred;
    final Set<String> broken = Collections.synchronizedSet(new HashSet<>());
    /** for tests / evidence: every attempt in order, e.g. "1:visionos:bot" */
    public final List<String> log = Collections.synchronizedList(new ArrayList<>());

    public NeedleYouTube(List<Client> clients, Checker checker, Sleeper sleeper) {
        this.clients = clients; this.checker = checker; this.sleeper = sleeper;
    }

    private static volatile NeedleYouTube real;
    /** The app-wide instance with the real readers. */
    public static NeedleYouTube get() {
        if (real == null) synchronized (NeedleYouTube.class) {
            if (real == null) {
                List<Client> l = new ArrayList<>();
                l.add(new VisionOs()); l.add(new AndroidVr()); l.add(new TvSamsung());
                real = new NeedleYouTube(l, NeedleYouTube::streamCheck, NeedleYouTube::realSleep);
            }
        }
        return real;
    }

    public String preferred() { return preferred; }
    /**
     * Test hook: keep only the named readers, in this order (e.g. "android_vr,tv_samsung"). The app only calls this when
     * a file named needle-readers.txt exists in its private storage, which only adb root can create (emulator tests).
     */
    public synchronized void onlyReaders(List<String> names) {
        List<Client> keep = new ArrayList<>();
        for (String n : names) for (Client c : clients) if (c.name().equals(n.trim())) keep.add(c);
        if (!keep.isEmpty()) { clients.clear(); clients.addAll(keep); preferred = null; broken.clear(); }
    }
    /** tests: swap in fake readers (pass null to go back to the real ones) */
    public static void install(NeedleYouTube y) { real = y; }
    public void pause(int afterRound, AtomicBoolean cancel) throws NeedleCore.NeedleError {
        sleeper.sleep(BACKOFF_MS[Math.min(Math.max(afterRound, 1) - 1, BACKOFF_MS.length - 1)], cancel);
    }

    /** Reader order for this attempt: remembered one first, then the rest; "avoid" ones (they just failed for this video) last. */
    List<Client> order(Set<String> avoid) {
        List<Client> first = new ArrayList<>(), last = new ArrayList<>();
        Client pref = null;
        for (Client c : clients) if (c.name().equals(preferred)) pref = c;
        if (pref != null) (avoid.contains(pref.name()) ? last : first).add(pref);
        for (Client c : clients) {
            if (c == pref) continue;
            if (broken.contains(c.name()) && broken.size() < clients.size()) continue;
            (avoid.contains(c.name()) ? last : first).add(c);
        }
        first.addAll(last);
        return first;
    }

    static boolean terminal(String code) { return code.matches("age|region|private|paid|cancelled|badurl"); }
    static boolean transientErr(String code) { return code.matches("bot|network|offline|forbidden|empty|nostreams|http"); }
    static int rank(String code) {
        switch (code) {
            case "bot": return 0; case "forbidden": case "empty": return 1; case "network": case "offline": return 2;
            case "nostreams": return 3; case "unavailable": return 4; default: return 5;
        }
    }

    public NeedleCore.Probe probe(String id, Set<String> avoid, Notes notes, AtomicBoolean cancel) throws NeedleCore.NeedleError {
        if (avoid == null) avoid = Collections.emptySet();
        if (cancel == null) cancel = new AtomicBoolean();
        NeedleCore.NeedleError best = null;
        for (int round = 1; round <= ROUNDS; round++) {
            boolean anyTransient = false;
            int i = 0;
            for (Client c : order(avoid)) {
                if (cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
                if (i++ > 0 && notes != null) notes.note(round > 1 ? "YouTube busy, retrying (" + round + "/" + ROUNDS + ")" : "YouTube busy, trying another way…");
                try {
                    NeedleCore.Probe p = c.read(id);
                    p.client = c.name();
                    if (checker != null) checker.check(p);
                    log.add(round + ":" + c.name() + ":ok");
                    preferred = c.name();
                    broken.remove(c.name());
                    if (notes != null) notes.note("");
                    return p;
                } catch (NeedleCore.NeedleError e) {
                    log.add(round + ":" + c.name() + ":" + e.code);
                    if (terminal(e.code)) throw e;
                    if ("changed".equals(e.code)) broken.add(c.name());
                    if (transientErr(e.code)) anyTransient = true;
                    if (best == null || rank(e.code) < rank(best.code)) best = e;
                } catch (RuntimeException e) {
                    log.add(round + ":" + c.name() + ":bug");
                    broken.add(c.name());
                    NeedleCore.NeedleError ne = NeedleCore.mapYoutube(e);
                    if (best == null || rank(ne.code) < rank(best.code)) best = ne;
                }
            }
            if (!anyTransient || round == ROUNDS) break;
            if (notes != null) notes.note("YouTube busy, retrying (" + (round + 1) + "/" + ROUNDS + ")");
            sleeper.sleep(BACKOFF_MS[Math.min(round - 1, BACKOFF_MS.length - 1)], cancel);
        }
        if (notes != null) notes.note("");
        throw best != null ? best : new NeedleCore.NeedleError("changed", "Couldn't read this YouTube video.");
    }

    static void realSleep(long ms, AtomicBoolean cancel) throws NeedleCore.NeedleError {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
            try { Thread.sleep(100); } catch (InterruptedException e) { throw new NeedleCore.NeedleError("cancelled", "Cancelled."); }
        }
    }

    /**
     * Ask for 1 KB of the best audio stream and of the first video stream. The KB is taken from the END of the file:
     * YouTube serves the first ~1 MB of a link that lacks a proof-of-origin token and then answers 403, so a check at
     * the start can pass while the real download fails (seen on the android_vr reader from this box, Nov 2026).
     */
    static void streamCheck(NeedleCore.Probe p) throws NeedleCore.NeedleError {
        NeedleCore.Option a = null, v = null;
        for (NeedleCore.Option o : p.audio) if (o.audioUrl != null && (a == null || ("m4a".equals(o.container) && !"m4a".equals(a.container)))) a = o;
        for (NeedleCore.Option o : p.video) if (o.videoUrl != null) { v = o; break; }
        if (a != null) ping(a.audioUrl, a.audioBytes > 0 ? a.audioBytes : a.bytes, p.userAgent);
        if (v != null) ping(v.videoUrl, v.videoBytes > 0 ? v.videoBytes : v.bytes, p.userAgent);
    }

    static String checkRange(long len) { return len > 2048 ? "bytes=" + (len - 1024) + "-" + (len - 1) : "bytes=0-1023"; }

    static void ping(String url, long len, String ua) throws NeedleCore.NeedleError {
        HttpURLConnection c = null;
        try {
            c = NeedleCore.open(url, checkRange(len), ua);
            int code = c.getResponseCode();
            if (code == 403 || code == 401) throw new NeedleCore.NeedleError("forbidden", "YouTube refused the stream links (403).");
            if (code >= 400) throw new NeedleCore.NeedleError("http", "YouTube's stream answered " + code + ".");
        } catch (NeedleCore.NeedleError e) { throw e; }
        catch (java.io.IOException e) { throw new NeedleCore.NeedleError("network", "Network problem talking to YouTube: " + NeedleCore.clip(String.valueOf(e.getMessage())), e); }
        finally { if (c != null) c.disconnect(); }
    }

    // ------------------------------------------------------------------ one neutral format list -> options (same rules for every reader)
    public static final class Fmt {
        public int itag; public char type; // 'a' audio-only, 'v' video-only, 'm' muxed (video+sound)
        public String container;           // m4a | webm | mp4
        public String codec = "";          // e.g. aac, opus, avc1.4d401f
        public int kbps, height, fps; public long bytes = -1;
        public String url; public boolean original = true; public String trackName;
    }

    public static void buildOptions(NeedleCore.Probe p, List<Fmt> fmts) throws NeedleCore.NeedleError {
        List<Fmt> aud = new ArrayList<>();
        for (Fmt f : fmts) if (f.type == 'a' && f.url != null) aud.add(f);
        boolean hasOriginal = false;
        for (Fmt f : aud) if (f.original) hasOriginal = true;
        Fmt bestM4a = null;
        Set<String> seen = new HashSet<>();
        for (Fmt a : aud) {
            if (hasOriginal && !a.original) continue;
            boolean m4a = "m4a".equals(a.container) && a.codec.startsWith("aac");
            boolean opus = "webm".equals(a.container) && a.codec.startsWith("opus");
            if (!m4a && !opus) continue;
            int kbps = Math.max(a.kbps, 0);
            if (!seen.add(a.container + ":" + kbps)) continue;
            NeedleCore.Option o = new NeedleCore.Option();
            o.kind = "audio"; o.id = "a" + a.itag; o.kbps = kbps;
            o.container = m4a ? "m4a" : "webm"; o.codec = m4a ? "aac" : "opus"; o.ext = m4a ? "m4a" : "webm";
            o.audioUrl = a.url; o.audioBytes = a.bytes; o.bytes = a.bytes;
            o.label = (m4a ? "AAC " : "Opus ") + (kbps > 0 ? kbps + " kbps" : "");
            o.detail = "YouTube " + (m4a ? "AAC (.m4a)" : "Opus (.webm)") + " audio stream" + (kbps > 0 ? ", about " + kbps + " kbps" : "")
                    + (a.trackName != null && !hasOriginal ? ", track: " + a.trackName : "");
            p.audio.add(o);
            if (m4a && (bestM4a == null || a.kbps > bestM4a.kbps)) bestM4a = a;
        }
        p.audio.sort((x, y) -> y.kbps != x.kbps ? y.kbps - x.kbps : x.codec.compareTo(y.codec));

        // video: H.264 only (every phone decodes it and the muxer handles it; AV1/VP9 skipped on purpose)
        Set<String> vseen = new HashSet<>();
        if (bestM4a != null) {
            for (Fmt v : fmts) {
                if (v.type != 'v' || v.url == null || !"mp4".equals(v.container) || !v.codec.startsWith("avc1")) continue;
                int h = v.height, fps = v.fps;
                if (!vseen.add(h + "@" + (fps > 30 ? fps : 30))) continue;
                NeedleCore.Option o = new NeedleCore.Option();
                o.kind = "video"; o.id = "v" + v.itag + "+a" + bestM4a.itag; o.merge = true;
                o.height = h; o.fps = fps; o.codec = "avc1"; o.container = "mp4"; o.ext = "mp4";
                o.videoUrl = v.url; o.audioUrl = bestM4a.url;
                o.videoBytes = v.bytes; o.audioBytes = bestM4a.bytes;
                o.bytes = (o.videoBytes > 0 && o.audioBytes > 0) ? o.videoBytes + o.audioBytes : -1;
                o.label = h + "p" + (fps > 30 ? String.valueOf(fps) : "");
                o.detail = "H.264 video " + o.label + " + AAC " + Math.max(bestM4a.kbps, 0) + " kbps audio, merged on the phone into one .mp4";
                p.video.add(o);
            }
        }
        for (Fmt v : fmts) {
            if (v.type != 'm' || v.url == null || !"mp4".equals(v.container)) continue;
            NeedleCore.Option o = new NeedleCore.Option();
            o.kind = "video"; o.id = "m" + v.itag; o.merge = false; o.height = v.height; o.fps = v.fps;
            o.codec = "avc1"; o.container = "mp4"; o.ext = "mp4";
            o.videoUrl = v.url; o.videoBytes = v.bytes; o.bytes = v.bytes;
            o.label = v.height + "p single file";
            o.detail = "One .mp4 YouTube already made (video and sound together), " + v.height + "p";
            p.video.add(o);
        }
        p.video.sort((x, y) -> y.height != x.height ? y.height - x.height : (y.fps != x.fps ? y.fps - x.fps : Boolean.compare(y.merge, x.merge)));
        if (p.audio.isEmpty() && p.video.isEmpty())
            throw new NeedleCore.NeedleError("nostreams", "YouTube didn't offer any downloadable stream for this video. Try again later, or use Home-PC server mode in Settings.");
    }

    static NeedleCore.Probe newProbe(String id) {
        NeedleCore.Probe p = new NeedleCore.Probe();
        p.source = "youtube"; p.id = id; p.url = "https://www.youtube.com/watch?v=" + id;
        return p;
    }

    // ------------------------------------------------------------------ 1. NewPipeExtractor's own reader (visionOS client in 0.27.1)
    static final class VisionOs implements Client {
        public String name() { return "visionos"; }
        public NeedleCore.Probe read(String id) throws NeedleCore.NeedleError {
            NeedleCore.init();
            StreamInfo si;
            try { si = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=" + id); }
            catch (Exception e) { throw NeedleCore.mapYoutube(e); }
            NeedleCore.Probe p = newProbe(id);
            p.title = si.getName(); p.uploader = si.getUploaderName(); p.durationSec = si.getDuration();
            try { if (!si.getThumbnails().isEmpty()) p.thumbnail = si.getThumbnails().get(si.getThumbnails().size() - 1).getUrl(); } catch (Exception ignored) {}
            List<Fmt> l = new ArrayList<>();
            for (AudioStream a : si.getAudioStreams()) {
                if (a.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP || !a.isUrl()) continue;
                Fmt f = new Fmt(); f.type = 'a'; f.itag = a.getItag(); f.url = a.getContent();
                if (a.getFormat() == MediaFormat.M4A) { f.container = "m4a"; f.codec = "aac"; }
                else if (a.getFormat() == MediaFormat.WEBMA_OPUS || a.getFormat() == MediaFormat.OPUS) { f.container = "webm"; f.codec = "opus"; }
                else continue;
                f.kbps = Math.max(a.getAverageBitrate(), 0);
                f.bytes = a.getItagItem() != null ? a.getItagItem().getContentLength() : -1;
                f.original = a.getAudioTrackType() == null || a.getAudioTrackType() == AudioTrackType.ORIGINAL;
                f.trackName = a.getAudioTrackName();
                l.add(f);
            }
            for (VideoStream v : si.getVideoOnlyStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP || !v.isUrl() || v.getFormat() != MediaFormat.MPEG_4) continue;
                Fmt f = new Fmt(); f.type = 'v'; f.itag = v.getItag(); f.url = v.getContent(); f.container = "mp4";
                f.codec = v.getCodec() == null ? "" : v.getCodec();
                f.height = v.getHeight() > 0 ? v.getHeight() : NeedleCore.parseHeight(v.getResolution()); f.fps = v.getFps();
                f.bytes = v.getItagItem() != null ? v.getItagItem().getContentLength() : -1;
                l.add(f);
            }
            for (VideoStream v : si.getVideoStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP || !v.isUrl() || v.getFormat() != MediaFormat.MPEG_4) continue;
                Fmt f = new Fmt(); f.type = 'm'; f.itag = v.getItag(); f.url = v.getContent(); f.container = "mp4"; f.codec = "avc1";
                f.height = v.getHeight() > 0 ? v.getHeight() : NeedleCore.parseHeight(v.getResolution()); f.fps = v.getFps();
                f.bytes = v.getItagItem() != null ? v.getItagItem().getContentLength() : -1;
                l.add(f);
            }
            buildOptions(p, l);
            return p;
        }
    }

    // ------------------------------------------------------------------ 2./3. YouTube player clients asked directly (InnerTube /player)
    private static volatile String visitorData;
    static String visitor() throws NeedleCore.NeedleError {
        if (visitorData != null) return visitorData;
        NeedleCore.init();
        try {
            visitorData = YoutubeParsingHelper.getVisitorDataFromInnertube(InnertubeClientRequestInfo.ofWebClient(), Localization.DEFAULT,
                    ContentCountry.DEFAULT, YoutubeParsingHelper.getYouTubeHeaders(), "https://www.youtube.com/youtubei/v1/", null, false);
        } catch (Exception e) { throw NeedleCore.mapYoutube(e); }
        return visitorData;
    }

    abstract static class Innertube implements Client {
        abstract String clientName(); abstract String clientVersion(); abstract String clientId(); abstract String ua();
        void extra(Map<String, Object> client) {}
        boolean needsPlayerJs() { return false; }

        public NeedleCore.Probe read(String id) throws NeedleCore.NeedleError {
            NeedleCore.init();
            String vd = visitor();
            Integer sts = null;
            if (needsPlayerJs()) {
                try { sts = YoutubeJavaScriptPlayerManager.getSignatureTimestamp(id); }
                catch (Exception e) { throw new NeedleCore.NeedleError("changed", "Couldn't read YouTube's player script for the " + name() + " reader.", e); }
            }
            Map<String, Object> client = new HashMap<>();
            client.put("clientName", clientName()); client.put("clientVersion", clientVersion()); client.put("userAgent", ua());
            client.put("hl", "en"); client.put("gl", "US"); client.put("visitorData", vd);
            extra(client);
            JsonObject ctx = new JsonObject(); ctx.put("client", new JsonObject(client));
            JsonObject body = new JsonObject();
            body.put("context", ctx); body.put("videoId", id); body.put("contentCheckOk", true); body.put("racyCheckOk", true);
            if (sts != null) {
                JsonObject cpc = new JsonObject(); cpc.put("signatureTimestamp", sts); cpc.put("html5Preference", "HTML5_PREF_WANTS");
                JsonObject pc = new JsonObject(); pc.put("contentPlaybackContext", cpc); body.put("playbackContext", pc);
            }
            Map<String, List<String>> h = new HashMap<>();
            h.put("User-Agent", Collections.singletonList(ua()));
            h.put("X-YouTube-Client-Name", Collections.singletonList(clientId()));
            h.put("X-YouTube-Client-Version", Collections.singletonList(clientVersion()));
            h.put("X-Goog-Visitor-Id", Collections.singletonList(vd));
            h.put("Origin", Collections.singletonList("https://www.youtube.com"));
            JsonObject j;
            try {
                Response r = NewPipe.getDownloader().postWithContentTypeJson("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", h,
                        JsonWriter.string(body).getBytes("UTF-8"), Localization.DEFAULT);
                if (r.responseCode() >= 500) throw new NeedleCore.NeedleError("network", "YouTube answered " + r.responseCode() + ".");
                if (r.responseCode() >= 400) throw new NeedleCore.NeedleError("changed", "YouTube refused the " + name() + " reader (" + r.responseCode() + ").");
                j = JsonParser.object().from(r.responseBody());
            } catch (NeedleCore.NeedleError e) { throw e; }
            catch (Exception e) { throw NeedleCore.mapYoutube(e); }
            return parse(id, j);
        }

        NeedleCore.Probe parse(String id, JsonObject j) throws NeedleCore.NeedleError {
            playability(j.getObject("playabilityStatus"));
            NeedleCore.Probe p = newProbe(id);
            JsonObject vd = j.getObject("videoDetails");
            p.title = vd.getString("title"); p.uploader = vd.getString("author");
            try { p.durationSec = Long.parseLong(vd.getString("lengthSeconds", "-1")); } catch (Exception ignored) {}
            p.userAgent = ua();
            JsonObject sd = j.getObject("streamingData");
            List<Fmt> l = new ArrayList<>();
            boolean sawCipherOrUrl = false;
            for (String key : new String[]{"adaptiveFormats", "formats"}) {
                JsonArray arr = sd.getArray(key);
                for (Object o : arr) {
                    if (!(o instanceof JsonObject)) continue;
                    JsonObject f = (JsonObject) o;
                    Fmt x = fmt(f, key.equals("formats"));
                    if (x == null) continue;
                    String url = f.getString("url");
                    String cipher = f.getString("signatureCipher", f.getString("cipher"));
                    if (url == null && cipher == null) continue; // SABR-only / no direct link: skip honestly
                    sawCipherOrUrl = true;
                    x.url = streamUrl(id, url, cipher);
                    l.add(x);
                }
            }
            if (!sawCipherOrUrl)
                throw new NeedleCore.NeedleError("nostreams", "The " + name() + " reader got no direct stream links from YouTube.");
            buildOptions(p, l);
            return p;
        }

        String streamUrl(String id, String url, String cipher) throws NeedleCore.NeedleError {
            try {
                if (url == null) {
                    Map<String, String> m = new HashMap<>();
                    for (String kv : cipher.split("&")) { int e = kv.indexOf('='); if (e > 0) m.put(kv.substring(0, e), URLDecoder.decode(kv.substring(e + 1), "UTF-8")); }
                    String sp = m.containsKey("sp") ? m.get("sp") : "signature";
                    url = m.get("url") + "&" + sp + "=" + URLEncoder.encode(YoutubeJavaScriptPlayerManager.deobfuscateSignature(id, m.get("s")), "UTF-8");
                }
                if (needsPlayerJs() && url.contains("&n=") || needsPlayerJs() && url.contains("?n="))
                    url = YoutubeJavaScriptPlayerManager.getUrlWithThrottlingParameterDeobfuscated(id, url);
                return url;
            } catch (Exception e) {
                throw new NeedleCore.NeedleError("changed", "The " + name() + " reader couldn't unlock YouTube's stream links (YouTube changed its player script).", e);
            }
        }
    }

    static Fmt fmt(JsonObject f, boolean muxed) {
        String mime = f.getString("mimeType", "");
        int semi = mime.indexOf(';');
        String type = (semi > 0 ? mime.substring(0, semi) : mime).trim();
        String codecs = "";
        int ci = mime.indexOf("codecs=\"");
        if (ci > 0) { int e = mime.indexOf('"', ci + 8); codecs = mime.substring(ci + 8, e > 0 ? e : mime.length()).toLowerCase(Locale.US); }
        Fmt x = new Fmt();
        x.itag = f.getInt("itag");
        try { x.bytes = Long.parseLong(f.getString("contentLength", "-1")); } catch (Exception e) { x.bytes = -1; }
        int br = f.getInt("averageBitrate", f.getInt("bitrate", 0));
        if (muxed) {
            if (!type.equals("video/mp4")) return null;
            x.type = 'm'; x.container = "mp4"; x.codec = "avc1"; x.height = f.getInt("height"); x.fps = f.getInt("fps");
        } else if (type.startsWith("audio/")) {
            x.type = 'a';
            if (type.equals("audio/mp4") && codecs.startsWith("mp4a")) { x.container = "m4a"; x.codec = "aac"; }
            else if (type.equals("audio/webm") && codecs.startsWith("opus")) { x.container = "webm"; x.codec = "opus"; }
            else return null;
            x.kbps = Math.round(br / 1000f);
            JsonObject t = f.getObject("audioTrack");
            if (!t.isEmpty()) { x.original = t.getBoolean("audioIsDefault", false) || t.getString("id", "").contains(".4"); x.trackName = t.getString("displayName"); }
        } else if (type.startsWith("video/")) {
            x.type = 'v'; x.container = type.equals("video/mp4") ? "mp4" : "webm"; x.codec = codecs;
            x.height = f.getInt("height"); x.fps = f.getInt("fps");
        } else return null;
        // YouTube's own audio itags: round to the familiar figures (AAC 128/48, Opus 160/70/50) like NewPipe does
        if (x.type == 'a') {
            switch (x.itag) { case 140: x.kbps = 128; break; case 139: x.kbps = 48; break; case 251: x.kbps = 160; break; case 250: x.kbps = 70; break; case 249: x.kbps = 50; break; default: }
        }
        return x;
    }

    static void playability(JsonObject ps) throws NeedleCore.NeedleError {
        String st = ps.getString("status", "");
        String reason = ps.getString("reason", "");
        if (st.equals("OK")) return;
        String r = reason.toLowerCase(Locale.US);
        if (r.contains("not a bot") || r.contains("confirm you")) throw new NeedleCore.NeedleError("bot", "YouTube asked this phone to \"confirm you're not a bot\". Wait a while, switch Wi-Fi/mobile data, or use Home-PC server mode in Settings.");
        if (st.equals("AGE_CHECK_REQUIRED") || st.equals("AGE_VERIFICATION_REQUIRED") || r.contains("age") && r.contains("confirm"))
            throw new NeedleCore.NeedleError("age", "This video is age-restricted. YouTube only shows it to signed-in adults, and Needle on the phone doesn't sign in. Home-PC server mode may work.");
        if (r.contains("private")) throw new NeedleCore.NeedleError("private", "This video is private.");
        if (r.contains("country")) throw new NeedleCore.NeedleError("region", "This video is blocked in your country.");
        if (r.contains("members") || r.contains("purchase")) throw new NeedleCore.NeedleError("paid", "This video needs a paid YouTube membership.");
        if (st.equals("LOGIN_REQUIRED")) throw new NeedleCore.NeedleError("bot", "YouTube asked this phone to sign in (\"" + NeedleCore.clip(reason) + "\"). Wait a while, switch Wi-Fi/mobile data, or use Home-PC server mode in Settings.");
        if (r.contains("reload")) throw new NeedleCore.NeedleError("changed", "YouTube didn't accept this reader (\"" + NeedleCore.clip(reason) + "\").");
        throw new NeedleCore.NeedleError("unavailable", "YouTube says this video isn't available" + (reason.isEmpty() ? "." : ": " + NeedleCore.clip(reason)));
    }

    static final class AndroidVr extends Innertube {
        public String name() { return "android_vr"; }
        String clientName() { return "ANDROID_VR"; }
        String clientVersion() { return "1.65.10"; }
        String clientId() { return "28"; }
        String ua() { return "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"; }
        @Override void extra(Map<String, Object> c) {
            c.put("deviceMake", "Oculus"); c.put("deviceModel", "Quest 3"); c.put("androidSdkVersion", 32); c.put("osName", "Android"); c.put("osVersion", "12L");
        }
    }

    static final class TvSamsung extends Innertube {
        public String name() { return "tv_samsung"; }
        String clientName() { return "TVHTML5"; }
        String clientVersion() { return "5.20260707"; }
        String clientId() { return "7"; }
        String ua() { return "Mozilla/5.0 (SMART-TV; Linux; Tizen 2.4.0) AppleWebKit/538.1 (KHTML, like Gecko) Version/2.4.0 TV Safari/538.1"; }
        @Override boolean needsPlayerJs() { return true; }
        @Override void extra(Map<String, Object> c) {
            c.put("deviceMake", "Samsung"); c.put("deviceModel", "UKS9800"); c.put("osName", "Tizen"); c.put("osVersion", "2.4.0");
        }
    }

    /** list of reader names in default order (for the page / evidence) */
    public List<String> names() { List<String> l = new ArrayList<>(); for (Client c : clients) l.add(c.name()); return l; }
    @SuppressWarnings("unused") private static Set<String> set(String... s) { return new LinkedHashSet<>(java.util.Arrays.asList(s)); }
}
