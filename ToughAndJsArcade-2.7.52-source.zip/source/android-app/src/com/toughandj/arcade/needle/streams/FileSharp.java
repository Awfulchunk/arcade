package com.toughandj.arcade.needle.streams;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/** SharpStream over a RandomAccessFile (read or read/write, seekable). Tough & J's. */
public final class FileSharp extends SharpStream {
    private final RandomAccessFile f; private final boolean write; private boolean closed;
    public FileSharp(File file, boolean write) throws IOException { this.f = new RandomAccessFile(file, write ? "rw" : "r"); this.write = write; if (write) f.setLength(0); }
    @Override public int read() throws IOException { return f.read(); }
    @Override public int read(byte[] b) throws IOException { return f.read(b); }
    @Override public int read(byte[] b, int o, int n) throws IOException { return f.read(b, o, n); }
    @Override public long skip(long n) throws IOException { long p = f.getFilePointer(), e = Math.min(f.length(), p + n); f.seek(e); return e - p; }
    @Override public long available() { try { return f.length() - f.getFilePointer(); } catch (IOException e) { return 0; } }
    @Override public void rewind() throws IOException { f.seek(0); }
    @Override public boolean isClosed() { return closed; }
    @Override public void close() { closed = true; try { f.close(); } catch (IOException ignored) {} }
    @Override public boolean canRewind() { return true; }
    @Override public boolean canRead() { return true; }
    @Override public boolean canWrite() { return write; }
    @Override public boolean canSetLength() { return write; }
    @Override public boolean canSeek() { return true; }
    @Override public void write(byte v) throws IOException { f.write(v); }
    @Override public void write(byte[] b) throws IOException { f.write(b); }
    @Override public void write(byte[] b, int o, int n) throws IOException { f.write(b, o, n); }
    @Override public void setLength(long l) throws IOException { f.setLength(l); }
    @Override public void seek(long o) throws IOException { f.seek(o); }
    @Override public long length() throws IOException { return f.length(); }
}
