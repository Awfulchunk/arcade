package com.toughandj.arcade.needle;

import com.grack.nanojson.JsonObject;
import com.grack.nanojson.JsonParser;
import com.toughandj.arcade.needle.streams.FileSharp;
import com.toughandj.arcade.needle.streams.Mp4FromDashWriter;
import com.toughandj.arcade.needle.streams.OggFromWebMWriter;
import com.toughandj.arcade.needle.streams.SharpStream;

import java.io.File;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Needle job runner (pure Java; Android plugs in a Converter backed by MediaCodec/MediaMuxer).
 * The page polls status(id) as JSON. Stream URLs never leave native code.
 */
public final class NeedleJobs {
    public interface Converter {
        void mp3(File in, File out, int kbps, AtomicBoolean cancel, NeedleMedia_Frac f) throws NeedleCore.NeedleError;
        void wav(File in, File out, AtomicBoolean cancel, NeedleMedia_Frac f) throws NeedleCore.NeedleError;
        void aacToM4a(File in, File out, AtomicBoolean cancel) throws NeedleCore.NeedleError;
    }
    /** progress 0..1 of a conversion step */
    public interface NeedleMedia_Frac { void at(double f); }

    static final class Job {
        final String id, type; final AtomicBoolean cancel = new AtomicBoolean();
        volatile String state = "queued", phase = "", error, code, probeJson, name, mime, title, note = "", client;
        volatile double progress; volatile File out; volatile long size;
        final long created = System.currentTimeMillis();
        Job(String id, String type) { this.id = id; this.type = type; }
    }
    static final class Cached { final NeedleCore.Probe p; final long at = System.currentTimeMillis(); Cached(NeedleCore.Probe p) { this.p = p; } }

    private final File work;
    private final Converter conv;
    private final ExecutorService pool = Executors.newFixedThreadPool(2, r -> { Thread t = new Thread(r, "needle"); t.setDaemon(true); return t; });
    private final ExecutorService probes = Executors.newFixedThreadPool(2, r -> { Thread t = new Thread(r, "needle-probe"); t.setDaemon(true); return t; });
    private final Map<String, Job> jobs = new ConcurrentHashMap<>();
    private final Map<String, Cached> cache = new ConcurrentHashMap<>();
    private static final long CACHE_MS = 45L * 60 * 1000; // YouTube stream links live ~6 h; re-read after 45 min to be safe

    public NeedleJobs(File workDir, Converter conv) {
        this.work = workDir; this.conv = conv;
        work.mkdirs();
        File[] old = work.listFiles();
        if (old != null) for (File f : old) f.delete(); // leftovers from a killed run
    }

    // ------------------------------------------------------------------ API
    public String probe(final String url) {
        final Job j = new Job("p" + UUID.randomUUID().toString().substring(0, 8), "probe");
        jobs.put(j.id, j);
        j.state = "running"; j.phase = "reading";
        probes.execute(() -> {
            try {
                NeedleCore.Probe p = probeCached(url, true, null, j);
                if (j.cancel.get()) { j.state = "cancelled"; return; }
                j.client = p.client;
                j.probeJson = NeedleCore.toJson(p); j.title = p.title;
                j.progress = 100; j.state = "done";
            } catch (NeedleCore.NeedleError e) { j.note = ""; if ("cancelled".equals(e.code)) { j.state = "cancelled"; j.error = "Cancelled."; j.code = e.code; } else fail(j, e); }
            catch (Throwable t) { j.note = ""; fail(j, new NeedleCore.NeedleError("bug", "Needle hit a bug reading that link (" + t.getClass().getSimpleName() + ").")); }
        });
        return j.id;
    }

    /** spec: {"url","kind":"audio|video","option":id,"format":"mp3|m4a|wav|ogg","bitrate":192} */
    public String start(String specJson) {
        final Job j = new Job("j" + UUID.randomUUID().toString().substring(0, 8), "pull");
        jobs.put(j.id, j);
        final JsonObject spec;
        try { spec = JsonParser.object().from(specJson); }
        catch (Exception e) { fail(j, new NeedleCore.NeedleError("bug", "Bad request from the page.")); return j.id; }
        pool.execute(() -> {
            try { run(j, spec); }
            catch (NeedleCore.NeedleError e) { cleanup(j); if ("cancelled".equals(e.code)) { j.note = ""; j.state = "cancelled"; j.error = "Cancelled."; j.code = e.code; } else fail(j, e); }
            catch (Throwable t) { cleanup(j); fail(j, new NeedleCore.NeedleError("bug", "Needle hit a bug (" + t.getClass().getSimpleName() + (t.getMessage() != null ? ": " + NeedleCore.clip(t.getMessage()) : "") + ").")); }
        });
        return j.id;
    }

    public void cancel(String id) { Job j = jobs.get(id); if (j != null) j.cancel.set(true); }

    /** The page has copied the finished file into the crate: drop the native copy. */
    public void release(String id) {
        Job j = jobs.remove(id);
        if (j != null) { j.cancel.set(true); if (j.out != null) j.out.delete(); }
    }

    public File output(String id) { Job j = jobs.get(id); return j != null && "done".equals(j.state) ? j.out : null; }
    public String mime(String id) { Job j = jobs.get(id); return j == null ? null : j.mime; }

    public String status(String id) {
        Job j = jobs.get(id);
        if (j == null) return "{\"id\":" + NeedleCore.q(id) + ",\"state\":\"gone\",\"error\":\"That job is gone (the app restarted?). Pull it again.\"}";
        StringBuilder b = new StringBuilder("{");
        b.append("\"id\":").append(NeedleCore.q(j.id)).append(",\"type\":").append(NeedleCore.q(j.type))
         .append(",\"state\":").append(NeedleCore.q(j.state)).append(",\"phase\":").append(NeedleCore.q(j.phase))
         .append(",\"progress\":").append(String.format(Locale.US, "%.1f", j.progress))
         .append(",\"error\":").append(NeedleCore.q(j.error)).append(",\"code\":").append(NeedleCore.q(j.code))
         .append(",\"title\":").append(NeedleCore.q(j.title))
         .append(",\"note\":").append(NeedleCore.q(j.note)).append(",\"client\":").append(NeedleCore.q(j.client));
        if ("done".equals(j.state) && j.out != null)
            b.append(",\"name\":").append(NeedleCore.q(j.name)).append(",\"mime\":").append(NeedleCore.q(j.mime)).append(",\"size\":").append(j.size);
        if (j.probeJson != null) b.append(",\"probe\":").append(j.probeJson);
        return b.append('}').toString();
    }

    // ------------------------------------------------------------------ work
    NeedleCore.Probe probeCached(String url, boolean fresh) throws NeedleCore.NeedleError { return probeCached(url, fresh, null, null); }

    NeedleCore.Probe probeCached(String url, boolean fresh, java.util.Set<String> avoid, final Job j) throws NeedleCore.NeedleError {
        String key = keyFor(url);
        Cached c = cache.get(key);
        if (c != null && !fresh && System.currentTimeMillis() - c.at < CACHE_MS) return c.p;
        NeedleCore.Probe p = NeedleCore.probe(url, avoid, j == null ? null : s -> j.note = s, j == null ? null : j.cancel);
        cache.put(key, new Cached(p));
        return p;
    }

    static String keyFor(String url) { String id = NeedleCore.youtubeId(url); return id != null ? "yt:" + id : url.trim(); }

    private static void fail(Job j, NeedleCore.NeedleError e) { j.note = ""; j.code = e.code; j.error = e.getMessage(); j.state = "error"; }
    private static void cleanup(Job j) { if (j.out != null) j.out.delete(); }

    private File tmp(Job j, String ext) { return new File(work, j.id + "-" + UUID.randomUUID().toString().substring(0, 4) + "." + ext); }

    private void need(long bytes) throws NeedleCore.NeedleError {
        if (bytes <= 0) return;
        long free = work.getUsableSpace();
        if (free > 0 && free < bytes * 2 + 50L * 1024 * 1024)
            throw new NeedleCore.NeedleError("space", "Not enough free space on the phone for this (" + (bytes / 1048576) + " MB, needs about twice that while working).");
    }

    private void run(final Job j, JsonObject spec) throws NeedleCore.NeedleError {
        String url = spec.getString("url", "");
        String kind = "video".equals(spec.getString("kind", "audio")) ? "video" : "audio";
        String optId = spec.getString("option", "");
        String format = spec.getString("format", "mp3").toLowerCase(Locale.US);
        if (!format.matches("mp3|m4a|wav|ogg")) format = "mp3";
        int kbps = spec.getInt("bitrate", 192);
        if (kbps != 128 && kbps != 192 && kbps != 256 && kbps != 320) kbps = 192;
        j.state = "running"; j.phase = "reading"; j.progress = 1;
        NeedleCore.Probe p = probeCached(url, false, null, j);
        NeedleCore.Option o = NeedleCore.find(p, kind, optId);
        if (o == null) { p = probeCached(url, true, null, j); o = NeedleCore.find(p, kind, optId); }
        if (o == null) throw new NeedleCore.NeedleError("nooption", "That quality isn't offered any more. Pick again.");
        j.title = p.title;
        String base = NeedleCore.safeName(p.title == null || p.title.isEmpty() ? "needle" : p.title);
        java.util.Set<String> avoid = new java.util.HashSet<>();
        // 2.7.51: if YouTube refuses the stream links mid-pull (403 / empty), wait, read the video again with
        // another reader (the one that failed goes last) and start the pull again. Up to 3 tries in all.
        for (int attempt = 1; ; attempt++) {
            j.client = p.client;
            try { pipe(j, p, o, kind, format, kbps, base); return; }
            catch (NeedleCore.NeedleError e) {
                boolean retry = "youtube".equals(p.source) && ("forbidden".equals(e.code) || "empty".equals(e.code))
                        && attempt < NeedleYouTube.ROUNDS && !j.cancel.get();
                if (!retry) throw e;
                cleanup(j); j.out = null;
                if (p.client != null) avoid.add(p.client);
                j.note = "YouTube busy, retrying (" + (attempt + 1) + "/" + NeedleYouTube.ROUNDS + ")";
                j.phase = "reading"; j.progress = 1;
                NeedleYouTube.get().pause(attempt, j.cancel);
                p = probeCached(url, true, avoid, j);
                j.note = "YouTube busy, retrying (" + (attempt + 1) + "/" + NeedleYouTube.ROUNDS + ")";
                o = NeedleCore.find(p, kind, optId);
                if (o == null) { j.note = ""; throw new NeedleCore.NeedleError("nooption", "YouTube refused the first links and the new ones don't have that quality. Pick again."); }
            }
        }
    }

    private void pipe(final Job j, NeedleCore.Probe p, NeedleCore.Option o, String kind, String format, int kbps, String base) throws NeedleCore.NeedleError {
        final String ua = p.userAgent;
        if (j.cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
        need(o.bytes);

        if (kind.equals("video")) {
            if (o.merge) {
                File v = tmp(j, "v.mp4"), a = tmp(j, "a.m4a"), out = tmp(j, "mp4");
                final long vb = Math.max(o.videoBytes, 1), ab = Math.max(o.audioBytes, 1), tot = vb + ab;
                try {
                    j.phase = "video";
                    NeedleCore.download(o.videoUrl, v, o.videoBytes, (d, t) -> { j.progress = 2 + 88.0 * d / tot; j.note = ""; }, j.cancel, ua);
                    j.phase = "sound";
                    NeedleCore.download(o.audioUrl, a, o.audioBytes, (d, t) -> { j.progress = 2 + 88.0 * (vb + d) / tot; j.note = ""; }, j.cancel, ua);
                    j.phase = "merge"; j.progress = 91;
                    j.out = out;
                    dashMerge(out, j.cancel, v, a);
                } finally { v.delete(); a.delete(); }
                finish(j, out, base + ".mp4", "video/mp4");
            } else {
                File out = tmp(j, o.ext);
                j.out = out; j.phase = "video";
                NeedleCore.download(o.videoUrl, out, o.videoBytes, (d, t) -> { j.progress = 2 + 97.0 * d / Math.max(1, t > 0 ? t : d * 2); j.note = ""; }, j.cancel, ua);
                finish(j, out, base + "." + o.ext, mimeOf(o.ext));
            }
            return;
        }

        // ---------------- audio
        boolean yt = "youtube".equals(p.source);
        String src = o.ext; // m4a | webm | (direct) mp3/m4a/mp4/ogg/...
        boolean convert = !(format.equals(src) || (format.equals("m4a") && yt && src.equals("m4a")) || (format.equals("ogg") && (src.equals("ogg") || src.equals("oga") || src.equals("opus"))));
        final double dlShare = (format.equals("mp3") || format.equals("wav")) && !format.equals(src) ? 55 : 92;
        File raw = tmp(j, src);
        try {
            j.phase = "sound";
            NeedleCore.download(o.audioUrl, raw, o.audioBytes > 0 ? o.audioBytes : o.bytes, (d, t) -> { j.progress = 2 + dlShare * d / Math.max(1, t > 0 ? t : d * 2); j.note = ""; }, j.cancel, ua);
            if (j.cancel.get()) throw new NeedleCore.NeedleError("cancelled", "Cancelled.");
            final double from = 2 + dlShare;
            File out;
            String ext = format;
            if (!convert) {
                if (yt && src.equals("m4a")) { // YouTube DASH m4a -> plain m4a (players and the cutter like it better)
                    out = tmp(j, "m4a"); j.out = out; j.phase = "tidy"; dashM4a(raw, out, j.cancel);
                } else { out = raw; raw = null; ext = src; }
            } else if (format.equals("m4a")) {
                if (src.equals("m4a") || src.matches("mp4|m4v|mov|3gp")) { out = tmp(j, "m4a"); j.out = out; j.phase = "tidy"; conv.aacToM4a(raw, out, j.cancel); }
                else throw new NeedleCore.NeedleError("noaac", "This sound isn't AAC, so Needle can't make a true .m4a without re-encoding. Pick mp3, wav or ogg.");
            } else if (format.equals("ogg")) {
                if (src.equals("webm")) { out = tmp(j, "ogg"); j.out = out; j.phase = "tidy"; webmOgg(raw, out); }
                else throw new NeedleCore.NeedleError("noopus", "A real .ogg needs an Opus/Vorbis source. Pick an Opus quality (YouTube) or choose mp3/wav.");
            } else {
                File decodeFrom = raw;
                File clean = null;
                if (yt && src.equals("m4a")) { clean = tmp(j, "m4a"); j.phase = "tidy"; dashM4a(raw, clean, j.cancel); decodeFrom = clean; }
                out = tmp(j, format); j.out = out;
                j.phase = format.equals("mp3") ? "mp3" : "wav";
                final double span = 99 - from;
                try {
                    if (format.equals("mp3")) conv.mp3(decodeFrom, out, kbps, j.cancel, f -> j.progress = from + span * f);
                    else conv.wav(decodeFrom, out, j.cancel, f -> j.progress = from + span * f);
                } finally { if (clean != null) clean.delete(); }
            }
            finish(j, out, base + "." + ext, mimeOf(ext));
        } finally { if (raw != null) raw.delete(); }
    }

    private void finish(Job j, File out, String name, String mime) throws NeedleCore.NeedleError {
        if (j.cancel.get()) { out.delete(); throw new NeedleCore.NeedleError("cancelled", "Cancelled."); }
        if (!out.isFile() || out.length() < 256) { out.delete(); throw new NeedleCore.NeedleError("empty", "The finished file came out empty."); }
        j.out = out; j.name = name; j.mime = mime; j.size = out.length(); j.progress = 100; j.phase = "done"; j.state = "done";
    }

    static String mimeOf(String ext) {
        switch (ext) {
            case "mp3": return "audio/mpeg";
            case "m4a": case "aac": return "audio/mp4";
            case "wav": return "audio/wav";
            case "ogg": case "oga": case "opus": return "audio/ogg";
            case "flac": return "audio/flac";
            case "webm": return "video/webm";
            case "mkv": return "video/x-matroska";
            case "mov": return "video/quicktime";
            case "3gp": return "video/3gpp";
            default: return "video/mp4";
        }
    }

    // ---- NewPipe's pure-Java muxers (GPL-3): DASH mp4 video + DASH m4a -> one mp4; DASH m4a -> m4a; WebM Opus -> Ogg
    static void dashMerge(File out, AtomicBoolean cancel, File... in) throws NeedleCore.NeedleError {
        SharpStream[] src = new SharpStream[in.length]; SharpStream o = null;
        try {
            for (int i = 0; i < in.length; i++) src[i] = new FileSharp(in[i], false);
            o = new FileSharp(out, true);
            Mp4FromDashWriter w = new Mp4FromDashWriter(src);
            w.parseSources();
            int[] sel = new int[in.length];
            w.selectTracks(sel);
            w.build(o);
            w.close();
        } catch (Exception e) {
            out.delete();
            throw new NeedleCore.NeedleError("mux", "Couldn't merge video and sound (" + e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + NeedleCore.clip(e.getMessage()) : "") + ").");
        } finally {
            for (SharpStream s : src) if (s != null) s.close();
            if (o != null) o.close();
        }
        if (cancel.get()) { out.delete(); throw new NeedleCore.NeedleError("cancelled", "Cancelled."); }
    }

    static void dashM4a(File in, File out, AtomicBoolean cancel) throws NeedleCore.NeedleError {
        SharpStream s = null, o = null;
        try {
            s = new FileSharp(in, false); o = new FileSharp(out, true);
            Mp4FromDashWriter w = new Mp4FromDashWriter(s);
            w.setMainBrand(0x4D344120); // "M4A "
            w.parseSources(); w.selectTracks(0); w.build(o); w.close();
        } catch (Exception e) {
            out.delete();
            throw new NeedleCore.NeedleError("mux", "Couldn't tidy the m4a (" + e.getClass().getSimpleName() + ").");
        } finally { if (s != null) s.close(); if (o != null) o.close(); }
        if (cancel.get()) { out.delete(); throw new NeedleCore.NeedleError("cancelled", "Cancelled."); }
    }

    static void webmOgg(File in, File out) throws NeedleCore.NeedleError {
        SharpStream s = null, o = null;
        try {
            s = new FileSharp(in, false); o = new FileSharp(out, true);
            OggFromWebMWriter w = new OggFromWebMWriter(s, o, null);
            w.parseSource(); w.selectTrack(0); w.build(); w.close();
        } catch (Exception e) {
            out.delete();
            throw new NeedleCore.NeedleError("mux", "Couldn't make the .ogg (" + e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + NeedleCore.clip(e.getMessage()) : "") + ").");
        } finally { if (s != null) s.close(); if (o != null) o.close(); }
    }
}
