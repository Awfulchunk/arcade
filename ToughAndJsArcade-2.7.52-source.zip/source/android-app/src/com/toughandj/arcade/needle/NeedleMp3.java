package com.toughandj.arcade.needle;

import de.sciss.jump3r.mp3.BRHist;
import de.sciss.jump3r.mp3.BitStream;
import de.sciss.jump3r.mp3.GainAnalysis;
import de.sciss.jump3r.mp3.GetAudio;
import de.sciss.jump3r.mp3.ID3Tag;
import de.sciss.jump3r.mp3.Lame;
import de.sciss.jump3r.mp3.LameGlobalFlags;
import de.sciss.jump3r.mp3.Parse;
import de.sciss.jump3r.mp3.Presets;
import de.sciss.jump3r.mp3.Quantize;
import de.sciss.jump3r.mp3.QuantizePVT;
import de.sciss.jump3r.mp3.Reservoir;
import de.sciss.jump3r.mp3.Takehiro;
import de.sciss.jump3r.mp3.VBRTag;
import de.sciss.jump3r.mp3.Version;
import de.sciss.jump3r.mpg.Common;
import de.sciss.jump3r.mpg.Interface;
import de.sciss.jump3r.mpg.MPGLib;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Real MP3 (MPEG-1/2 Layer III, CBR) encoder: pure-Java LAME port "jump3r" (LGPL), wired up the same way
 * as jump3r's own lowlevel.LameEncoder but without javax.sound (not on Android).
 */
public final class NeedleMp3 {
    private final Lame lame;
    private final LameGlobalFlags gfp;
    private final OutputStream out;
    private final int channels;
    private byte[] mp3buf = new byte[1 << 16];
    private int[] l = new int[0], r = new int[0];

    public NeedleMp3(int channels, int sampleRate, int kbps, OutputStream out) throws IOException {
        if (channels < 1) throw new IOException("no audio channels");
        this.channels = Math.min(2, channels);
        this.out = out;
        lame = new Lame();
        GetAudio gaud = new GetAudio(); GainAnalysis ga = new GainAnalysis(); BitStream bs = new BitStream();
        Presets p = new Presets(); QuantizePVT qupvt = new QuantizePVT(); Quantize qu = new Quantize();
        VBRTag vbr = new VBRTag(); Version ver = new Version(); ID3Tag id3 = new ID3Tag(); Reservoir rv = new Reservoir();
        Takehiro tak = new Takehiro(); Parse parse = new Parse(); new BRHist();
        MPGLib mpg = new MPGLib(); Interface intf = new Interface(); Common common = new Common();
        lame.setModules(ga, bs, p, qupvt, qu, vbr, ver, id3, mpg);
        bs.setModules(ga, mpg, ver, vbr);
        id3.setModules(bs, ver);
        p.setModules(lame);
        qu.setModules(bs, rv, qupvt, tak);
        qupvt.setModules(tak, rv, lame.enc.psy);
        rv.setModules(bs);
        tak.setModules(qupvt);
        vbr.setModules(lame, bs, ver);
        gaud.setModules(parse, mpg);
        parse.setModules(ver, id3, p);
        mpg.setModules(intf, common);
        intf.setModules(vbr, common);
        gfp = lame.lame_init();
        gfp.num_channels = this.channels;
        gfp.in_samplerate = sampleRate;
        gfp.brate = kbps;
        gfp.quality = 5; // LAME -q 5 ("middle"): good quality/speed balance for a low-end phone
        id3.id3tag_init(gfp);
        gfp.write_id3tag_automatic = false;
        gfp.findReplayGain = false;
        int rc = lame.lame_init_params(gfp);
        if (rc < 0) throw new IOException("MP3 encoder refused " + sampleRate + " Hz / " + kbps + " kbps (code " + rc + ")");
    }

    public int effectiveKbps() { return gfp.brate; }
    public int effectiveSampleRate() { return gfp.out_samplerate; }

    /** Interleaved 16-bit PCM, srcChannels per frame (extra channels beyond 2 are dropped). */
    public void writePcm16(short[] pcm, int frames, int srcChannels) throws IOException {
        if (frames <= 0) return;
        if (l.length < frames) { l = new int[frames]; r = new int[frames]; }
        for (int i = 0, k = 0; i < frames; i++, k += srcChannels) {
            int a = pcm[k] << 16;
            l[i] = a;
            r[i] = (srcChannels > 1) ? (pcm[k + 1] << 16) : a;
        }
        int need = (int) (1.25 * frames) + 7200;
        if (mp3buf.length < need) mp3buf = new byte[need];
        int n = lame.lame_encode_buffer_int(gfp, l, r, frames, mp3buf, 0, mp3buf.length);
        if (n < 0) throw new IOException("MP3 encoder error " + n);
        if (n > 0) out.write(mp3buf, 0, n);
    }

    public void finish() throws IOException {
        int n = lame.lame_encode_flush(gfp, mp3buf, 0, mp3buf.length);
        if (n > 0) out.write(mp3buf, 0, n);
        lame.lame_close(gfp);
        out.flush();
    }
}
