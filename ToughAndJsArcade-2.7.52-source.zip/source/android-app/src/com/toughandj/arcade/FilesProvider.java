package com.toughandj.arcade;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Tiny read-only FileProvider replacement (no AndroidX): serves ONLY files in cache/updates/
 * so the system installer can read a picked .apk via a content:// URI.
 */
public class FilesProvider extends ContentProvider {
    static final String AUTH = "com.toughandj.arcade.files";

    static Uri uriFor(Context c, File f) {
        return new Uri.Builder().scheme("content").authority(AUTH).appendPath("updates").appendPath(f.getName()).build();
    }

    private File fileFor(Uri u) throws FileNotFoundException {
        if (u.getPathSegments().size() != 2 || !"updates".equals(u.getPathSegments().get(0))) throw new FileNotFoundException(u.toString());
        String name = u.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) throw new FileNotFoundException(u.toString());
        File f = new File(new File(getContext().getCacheDir(), "updates"), name);
        if (!f.isFile()) throw new FileNotFoundException(u.toString());
        return f;
    }

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri u) {
        String n = u.getLastPathSegment();
        return n != null && n.endsWith(".apk") ? "application/vnd.android.package-archive" : "application/octet-stream";
    }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        if (mode != null && mode.contains("w")) throw new SecurityException("read-only");
        return ParcelFileDescriptor.open(fileFor(u), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri u, String[] proj, String sel, String[] args, String sort) {
        File f; try { f = fileFor(u); } catch (FileNotFoundException e) { return null; }
        if (proj == null) proj = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(proj, 1); Object[] row = new Object[proj.length];
        for (int i = 0; i < proj.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(proj[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(proj[i])) row[i] = f.length();
        }
        c.addRow(row); return c;
    }

    @Override public Uri insert(Uri u, ContentValues v) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
