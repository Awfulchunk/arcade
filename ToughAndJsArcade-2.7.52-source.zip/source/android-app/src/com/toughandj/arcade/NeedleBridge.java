package com.toughandj.arcade;

import android.content.Context;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceResponse;

import com.toughandj.arcade.needle.NeedleCore;
import com.toughandj.arcade.needle.NeedleJobs;
import com.toughandj.arcade.needle.NeedleMedia;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 2.7.50: Needle's on-phone download engine, exposed to the page as window.TJNeedle.
 * 2.7.51: YouTube reads retry by themselves and fall back to other real YouTube player clients (see NeedleYouTube).
 * No home-PC server, no Termux: NewPipeExtractor reads YouTube, NewPipe's muxers merge, MediaCodec + LAME (jump3r) make real MP3.
 * Finished files are handed to the page at https://tj-needle.local/out/<jobId> (served by shouldInterceptRequest, never the network).
 */
public final class NeedleBridge {
    public static final String VERSION = "1.1.0";
    static final String OUT_PREFIX = "https://tj-needle.local/out/";
    private final NeedleJobs jobs;
    private static NeedleBridge one;

    /** One engine per app process (an Activity re-create must not wipe running jobs). */
    static synchronized NeedleBridge get(Context c) {
        if (one == null) one = new NeedleBridge(c.getApplicationContext());
        return one;
    }

    private NeedleBridge(Context c) {
        File work = new File(c.getFilesDir(), "needle-work");
        // emulator test hook only: adb root can drop files/needle-readers.txt ("android_vr,tv_samsung") to force readers
        File force = new File(c.getFilesDir(), "needle-readers.txt");
        if (force.isFile()) {
            try { com.toughandj.arcade.needle.NeedleYouTube.get().onlyReaders(java.util.Arrays.asList(new String(java.nio.file.Files.readAllBytes(force.toPath()), "UTF-8").trim().split(","))); }
            catch (Exception ignored) {}
        }
        jobs = new NeedleJobs(work, new NeedleJobs.Converter() {
            @Override public void mp3(File in, File out, int kbps, java.util.concurrent.atomic.AtomicBoolean cancel, NeedleJobs.NeedleMedia_Frac f) throws NeedleCore.NeedleError { NeedleMedia.toMp3(in, out, kbps, cancel, f::at); }
            @Override public void wav(File in, File out, java.util.concurrent.atomic.AtomicBoolean cancel, NeedleJobs.NeedleMedia_Frac f) throws NeedleCore.NeedleError { NeedleMedia.toWav(in, out, cancel, f::at); }
            @Override public void aacToM4a(File in, File out, java.util.concurrent.atomic.AtomicBoolean cancel) throws NeedleCore.NeedleError { NeedleMedia.aacToM4a(in, out, cancel); }
        });
    }

    /** NewPipeExtractor uses java.time (Android 8+). */
    static boolean supported() { return Build.VERSION.SDK_INT >= 26; }

    @JavascriptInterface public String info() {
        return "{\"engine\":\"phone\",\"version\":\"" + VERSION + "\",\"extractor\":\"NewPipeExtractor v0.27.1\",\"mp3\":\"LAME 3.98 (jump3r)\",\"sdk\":" + Build.VERSION.SDK_INT
                + ",\"readers\":\"" + String.join(",", com.toughandj.arcade.needle.NeedleYouTube.get().names()) + "\",\"reader\":" + NeedleCore.q(com.toughandj.arcade.needle.NeedleYouTube.get().preferred())
                + ",\"ok\":" + supported() + ",\"why\":" + NeedleCore.q(supported() ? null : "The on-phone downloader needs Android 8 or newer. Use Home-PC server mode.") + "}";
    }
    @JavascriptInterface public String probe(String url) { return supported() ? jobs.probe(url) : ""; }
    @JavascriptInterface public String start(String specJson) { return supported() ? jobs.start(specJson) : ""; }
    @JavascriptInterface public String status(String id) { return jobs.status(id); }
    @JavascriptInterface public void cancel(String id) { jobs.cancel(id); }
    @JavascriptInterface public void release(String id) { jobs.release(id); }

    /** Serve a finished job's file to the page. Returns null for every other URL. */
    WebResourceResponse intercept(String url) {
        if (url == null || !url.startsWith(OUT_PREFIX)) return null;
        String id = url.substring(OUT_PREFIX.length()).replaceAll("[?#].*$", "");
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-store");
        File f = id.matches("[a-z0-9]{1,16}") ? jobs.output(id) : null;
        try {
            if (f == null || !f.isFile()) return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new java.io.ByteArrayInputStream("gone".getBytes("UTF-8")));
            h.put("Content-Length", String.valueOf(f.length()));
            String mime = jobs.mime(id);
            return new WebResourceResponse(mime == null ? "application/octet-stream" : mime, null, 200, "OK", h, new FileInputStream(f));
        } catch (Exception e) { return null; }
    }
}
