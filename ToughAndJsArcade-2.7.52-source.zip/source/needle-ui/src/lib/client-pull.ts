import { serverAuth, serverFail, serverUrl } from "./server-base";
import { cratePut, mimeForName, underbedPut } from "./crate-db";
import { sanitizeJobError } from "./pull-errors";
import { isArchiveAudio } from "./underbed";
import { audioFormatOf, type AudioFormat } from "./audio-format";

export type PullFileOpts = {
  url: string;
  kind: "audio" | "video";
  source: "youtube" | "web";
  bitrate: number;
  quality: number;
  adult: boolean;
  audioFormat?: AudioFormat;
};

export async function pullFileToCrate(
  opts: PullFileOpts,
): Promise<{ filename: string; title: string }> {
  const res = await fetch(serverUrl("/api/pull-file"), {
    method: "POST",
    headers: { ...serverAuth(), "content-type": "application/json", accept: "*/*" },
    body: JSON.stringify(opts),
  });
  if (!res.ok) {
    const text = (await res.text().catch(() => "")).trim();
    throw new Error(serverFail(res, text) || sanitizeJobError(text) || "Pull failed.");
  }
  const filename =
    res.headers.get("X-Needle-Filename")?.trim() ||
    (opts.kind === "video" ? "video.mp4" : `audio.${audioFormatOf(opts.audioFormat)}`);
  const title = res.headers.get("X-Needle-Title")?.trim() || filename;
  const mime = res.headers.get("content-type") || mimeForName(filename);
  const blob = await res.blob();
  if (blob.size < 1000) throw new Error("YouTube sent an empty file. The stream was blocked.");
  await cratePut({
    name: filename,
    size: blob.size,
    mtime: Date.now(),
    mime,
    blob,
  });
  if (isArchiveAudio(filename)) {
    await underbedPut({
      name: filename,
      size: blob.size,
      mtime: Date.now(),
      mime,
      blob,
    }).catch(() => undefined);
  }
  return { filename, title };
}
