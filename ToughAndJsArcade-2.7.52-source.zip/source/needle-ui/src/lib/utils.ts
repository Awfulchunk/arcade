import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** i;
  return `${value < 10 && i > 0 ? value.toFixed(1) : Math.round(value)} ${units[i]}`;
}

export function formatClock(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem.toString().padStart(2, "0")}`;
}

export function isVideoFile(name: string): boolean {
  return /\.(mp4|webm|mkv|mov)$/i.test(name);
}

export function fileKind(name: string): "audio" | "video" {
  return isVideoFile(name) ? "video" : "audio";
}

export function displayTrackName(name: string): string {
  return name.replace(/\.(m4a|mp3|mp4|webm|mkv|mov|wav|ogg|flac|aac|opus)$/i, "").replace(/_/g, " ");
}

export function clampVolume(n: number): number {
  if (!Number.isFinite(n)) return 0.9;
  return Math.min(1, Math.max(0, n));
}
