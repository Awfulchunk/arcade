const VIDEO_ID_RE = /^[\w-]{11}$/;

const HOST_RE =
  /^(https?:\/\/)?((www|m|music)\.)?(youtube\.com|youtu\.be)\//i;

const EXTRACT_PATTERNS = [
  /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/watch\?(?:[^\s<>"']*?&)?v=([\w-]{11})/gi,
  /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/(?:shorts|embed|live)\/([\w-]{11})/gi,
  /(?:https?:\/\/)?(?:www\.)?youtu\.be\/([\w-]{11})/gi,
  /(?:https?:\/\/)?music\.youtube\.com\/watch\?(?:[^\s<>"']*?&)?v=([\w-]{11})/gi,
];

const PLAYLIST_OR_CHANNEL_RE =
  /(?:youtube\.com\/(?:playlist|channel\/|@|user\/|c\/|feeds\/)|[?&]list=)/i;

function stripTrailingPunct(url: string): string {
  return url.replace(/[),.;!?]+$/g, "");
}

function withProtocol(raw: string): string {
  return /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
}

export function canonicalWatchUrl(videoId: string): string {
  return `https://www.youtube.com/watch?v=${videoId}`;
}

export function isYoutubeUrl(value: string): boolean {
  return HOST_RE.test(value.trim()) || youtubeVideoId(value) !== null;
}

export function isPlaylistOrChannelUrl(url: string): boolean {
  try {
    const parsed = new URL(withProtocol(url.trim()));
    const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
    const path = parsed.pathname;
    if (host === "youtu.be" || host === "m.youtu.be") return false;
    if (!host.endsWith("youtube.com")) return false;
    if (
      path.startsWith("/playlist") ||
      path.startsWith("/channel/") ||
      path.startsWith("/@") ||
      path.startsWith("/user/") ||
      path.startsWith("/c/") ||
      path.startsWith("/feeds/")
    ) {
      return true;
    }
    const hasList = parsed.searchParams.has("list");
    const hasVideo = parsed.searchParams.has("v") || /\/(shorts|embed|live)\//.test(path);
    if (hasList && !hasVideo && !path.startsWith("/watch") && !path.startsWith("/shorts")) {
      return true;
    }
    if (path === "/playlist" || path.startsWith("/playlist/")) return true;
    return false;
  } catch {
    return true;
  }
}

export function youtubeVideoId(url: string): string | null {
  try {
    const parsed = new URL(withProtocol(stripTrailingPunct(url.trim())));
    const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be" || host === "m.youtu.be") {
      const id = parsed.pathname.split("/").filter(Boolean)[0] ?? null;
      return id && VIDEO_ID_RE.test(id) ? id : null;
    }
    const v = parsed.searchParams.get("v");
    if (v && VIDEO_ID_RE.test(v)) return v;
    const path = parsed.pathname;
    const fromPath = path.match(/\/(shorts|embed|live)\/([\w-]{11})/);
    return fromPath?.[2] && VIDEO_ID_RE.test(fromPath[2]) ? fromPath[2] : null;
  } catch {
    return null;
  }
}

export function mentionsBlockedYoutube(text: string): boolean {
  return PLAYLIST_OR_CHANNEL_RE.test(text) && parseYoutubeUrls(text).length === 0;
}

export function parseYoutubeUrls(text: string): string[] {
  const ids: string[] = [];
  const seen = new Set<string>();

  const pushId = (id: string | undefined | null) => {
    if (!id || !VIDEO_ID_RE.test(id) || seen.has(id)) return;
    seen.add(id);
    ids.push(id);
  };

  const hits: { index: number; id: string }[] = [];
  for (const pattern of EXTRACT_PATTERNS) {
    pattern.lastIndex = 0;
    for (const match of text.matchAll(pattern)) {
      const id = match[1];
      if (id && VIDEO_ID_RE.test(id)) {
        hits.push({ index: match.index ?? 0, id });
      }
    }
  }
  hits.sort((a, b) => a.index - b.index);
  for (const hit of hits) pushId(hit.id);

  for (const token of text.split(/[\s,;|]+/)) {
    const t = stripTrailingPunct(token.trim());
    if (!t) continue;
    if (HOST_RE.test(t)) pushId(youtubeVideoId(t));
  }

  return ids.map(canonicalWatchUrl);
}
