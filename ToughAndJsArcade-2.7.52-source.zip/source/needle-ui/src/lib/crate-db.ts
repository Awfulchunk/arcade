export type CrateRecord = {
  name: string;
  size: number;
  mtime: number;
  mime: string;
  blob: Blob;
};

export type CrateFile = {
  name: string;
  size: number;
  mtime: number;
};

const DB_NAME = "needle-crate";
const FILES = "files";
const UNDERBED = "underbed";
const DB_VERSION = 2;

export function mimeForName(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase();
  if (ext === "mp4") return "video/mp4";
  if (ext === "webm") return "video/webm";
  if (ext === "m4a" || ext === "aac") return "audio/mp4";
  if (ext === "mp3") return "audio/mpeg";
  if (ext === "wav") return "audio/wav";
  if (ext === "ogg" || ext === "opus") return "audio/ogg";
  if (ext === "flac") return "audio/flac";
  if (ext === "mov" || ext === "m4v") return "video/mp4";
  return "application/octet-stream";
}

/** Phones refuse to play a blob that has no audio type. */
export function typedBlob(blob: Blob, name: string): Blob {
  const mime = mimeForName(name);
  if (mime === "application/octet-stream") return blob;
  if (blob.type === mime) return blob;
  return new Blob([blob], { type: mime });
}

export function mergeCrateFiles(primary: CrateFile[], extra: CrateFile[]): CrateFile[] {
  const map = new Map<string, CrateFile>();
  for (const file of extra) map.set(file.name, file);
  for (const file of primary) map.set(file.name, file);
  return [...map.values()].sort((a, b) => b.mtime - a.mtime);
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("Crate storage is not available in this browser."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(FILES)) {
        db.createObjectStore(FILES, { keyPath: "name" });
      }
      if (!db.objectStoreNames.contains(UNDERBED)) {
        db.createObjectStore(UNDERBED, { keyPath: "name" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the crate."));
  });
}

function runStore<T>(
  storeName: string,
  mode: IDBTransactionMode,
  work: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(storeName, mode);
        const req = work(tx.objectStore(storeName));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error ?? new Error("Crate request failed."));
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(tx.error ?? new Error("Crate transaction failed."));
      }),
  );
}

async function listRecords(storeName: string): Promise<CrateRecord[]> {
  try {
    const rows = await runStore<CrateRecord[]>(storeName, "readonly", (store) => store.getAll());
    return (rows ?? []).filter((row) => row?.name && row.blob);
  } catch {
    return [];
  }
}

async function putRecord(storeName: string, record: CrateRecord): Promise<void> {
  await runStore(storeName, "readwrite", (store) =>
    store.put({
      name: record.name,
      size: record.size || record.blob.size,
      mtime: record.mtime || Date.now(),
      mime: record.mime || mimeForName(record.name),
      blob: record.blob,
    }),
  );
}

async function getRecord(storeName: string, name: string): Promise<CrateRecord | null> {
  try {
    const row = await runStore<CrateRecord>(storeName, "readonly", (store) => store.get(name));
    return row?.name && row.blob ? row : null;
  } catch {
    return null;
  }
}

export async function crateListRecords(): Promise<CrateRecord[]> {
  return listRecords(FILES);
}

export async function crateList(): Promise<CrateFile[]> {
  const rows = await crateListRecords();
  return rows
    .map((row) => ({ name: row.name, size: row.size || row.blob.size, mtime: row.mtime || 0 }))
    .sort((a, b) => b.mtime - a.mtime);
}

export async function cratePut(record: CrateRecord): Promise<void> {
  await putRecord(FILES, record);
}

export async function crateGet(name: string): Promise<CrateRecord | null> {
  return getRecord(FILES, name);
}

export async function crateRemove(name: string): Promise<void> {
  await runStore(FILES, "readwrite", (store) => store.delete(name));
}

export async function crateClear(): Promise<void> {
  await runStore(FILES, "readwrite", (store) => store.clear());
}

export async function underbedListRecords(): Promise<CrateRecord[]> {
  return listRecords(UNDERBED);
}

export async function underbedPut(record: CrateRecord): Promise<void> {
  await putRecord(UNDERBED, record);
}

export async function underbedGet(name: string): Promise<CrateRecord | null> {
  return getRecord(UNDERBED, name);
}

export async function underbedRemove(name: string): Promise<void> {
  await runStore(UNDERBED, "readwrite", (store) => store.delete(name));
}

export async function underbedClear(): Promise<void> {
  await runStore(UNDERBED, "readwrite", (store) => store.clear());
}
