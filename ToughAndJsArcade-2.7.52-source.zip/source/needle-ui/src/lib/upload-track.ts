const AUDIO = new Set(["m4a", "mp3", "wav", "ogg", "flac", "aac", "opus"]);
const VIDEO = new Set(["mp4", "webm", "m4v", "mov"]);

const MIME_EXT: Record<string, string> = {
  "audio/mpeg": "mp3",
  "audio/mp3": "mp3",
  "audio/mp4": "m4a",
  "audio/m4a": "m4a",
  "audio/x-m4a": "m4a",
  "audio/aac": "aac",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
  "audio/wave": "wav",
  "audio/ogg": "ogg",
  "audio/flac": "flac",
  "audio/x-flac": "flac",
  "audio/webm": "webm",
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/quicktime": "mov",
};

export function uploadExt(name: string): string {
  return name.split(".").pop()?.toLowerCase() || "";
}

/** Keep a user filename. Reject anything that is not audio or video. */
export function safeUploadName(raw: string): string | null {
  const base = String(raw || "")
    .split(/[/\\]/)
    .pop()
    ?.trim();
  if (!base) return null;
  const cleaned = base
    .replace(/[^\w.\- ()\[\]]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^\.+/, "")
    .slice(0, 140);
  const ext = uploadExt(cleaned);
  if (!AUDIO.has(ext) && !VIDEO.has(ext)) return null;
  return cleaned;
}

export function extForMime(mime: string): string | null {
  const key = mime.toLowerCase().split(";")[0]?.trim() || "";
  return MIME_EXT[key] ?? null;
}

/** Phone pickers often hand back a nameless file. Trust the audio type. */
export function nameForUpload(fileName: string, mime: string): string | null {
  const named = safeUploadName(fileName);
  if (named) return named;
  const ext = extForMime(mime);
  if (!ext) return null;
  const stem = String(fileName || "song")
    .split(/[/\\]/)
    .pop()!
    .replace(/\.[^.]+$/, "")
    .replace(/[^\w\- ()\[\]]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80);
  return `${stem || "song"}.${ext}`;
}

export function uniqueUploadName(name: string, taken: Set<string>): string {
  if (!taken.has(name)) return name;
  const dot = name.lastIndexOf(".");
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  let n = 2;
  while (taken.has(`${stem}_${n}${ext}`)) n += 1;
  return `${stem}_${n}${ext}`;
}

export function uploadByteCap(name: string): number {
  return VIDEO.has(uploadExt(name)) ? 400 * 1024 * 1024 : 80 * 1024 * 1024;
}
