export const MISSING_DEPS = "The downloader isn't available. Retry in a moment.";

export const AGE_RESTRICTED = "That video is age-restricted and cannot be pulled here.";
export const AGE_NEEDS_ADULT =
  "Turn on Adult mode in settings, then retry. R-rated and age-gated titles need it.";
export const UNAVAILABLE = "That video is unavailable.";
export const PRIVATE = "That video is private.";
export const BLOCKED_STREAM = "YouTube blocked the media stream. Wait and retry, or try another video.";
export const SIGN_IN = "YouTube asked for a sign-in. This video cannot be pulled from here.";
export const NO_AUDIO = "No matching format was available for that video.";
export const EMPTY_FILE = "YouTube sent an empty file. The stream was blocked.";
export const NETWORK = "The network dropped mid-pull. Retry.";
export const TIMED_OUT = "Timed out. Try a shorter video, or retry.";
export const GENERIC = "Could not pull that clip. Wait and retry, or try another.";
export const UNSUPPORTED = "No video at that link. Try a direct file, or another page.";

const FRIENDLY = new Set([
  MISSING_DEPS,
  AGE_RESTRICTED,
  AGE_NEEDS_ADULT,
  UNAVAILABLE,
  PRIVATE,
  BLOCKED_STREAM,
  SIGN_IN,
  NO_AUDIO,
  EMPTY_FILE,
  NETWORK,
  TIMED_OUT,
  GENERIC,
  UNSUPPORTED,
]);

/** True only when the yt-dlp package itself is missing, not a plugin or submodule. */
export function isMissingYtDlp(raw: string): boolean {
  return /No module named ['"]yt_dlp['"](?![\w.])/.test(raw) || /No module named yt_dlp(?![\w.])/.test(raw);
}

export function stripYtDlpNoise(raw: string): string {
  return String(raw || "")
    .replace(/If you want your application to use our API[\s\S]*$/gim, "")
    .replace(/https?:\/\/video-download-api\.com\S*/gi, "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => {
      if (!line) return false;
      if (/^Deprecated Feature:/i.test(line)) return false;
      if (/Support for Python version/i.test(line)) return false;
      if (/please update to Python/i.test(line)) return false;
      if (/^WARNING:/i.test(line)) return false;
      if (/^\[debug\]/i.test(line)) return false;
      return true;
    })
    .join("\n")
    .replace(/ERROR:\s*\[youtube\]\s*[^\s:]+:\s*/gi, "")
    .replace(/^ERROR:\s*/gim, "")
    .trim();
}

export function friendlyError(raw: string): string {
  const text = stripYtDlpNoise(raw);
  if (isMissingYtDlp(text)) return MISSING_DEPS;
  if (/age[- ]restricted/i.test(text) || /sign in to confirm your age/i.test(text)) {
    return AGE_RESTRICTED;
  }
  if (/Private video/i.test(text)) return PRIVATE;
  if (/Requested format is not available/i.test(text)) return NO_AUDIO;
  if (
    /this video is not available/i.test(text) ||
    /Video unavailable/i.test(text) ||
    /That video is unavailable/i.test(text)
  ) {
    return UNAVAILABLE;
  }
  if (/The downloaded file is empty/i.test(text) || /empty file/i.test(text)) {
    return EMPTY_FILE;
  }
  if (/timed? ?out/i.test(text) || /TimeoutError/i.test(text)) return TIMED_OUT;
  if (
    /ECONNRESET|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|fetch failed|socket hang up|network dropped/i.test(
      text,
    )
  ) {
    return NETWORK;
  }
  if (
    /HTTP Error 403/i.test(text) ||
    /unable to download video data/i.test(text) ||
    /nsig|n-challenge|sabr|po.?token/i.test(text)
  ) {
    return BLOCKED_STREAM;
  }
  if (/Sign in to confirm/i.test(text) || /bot detection/i.test(text)) {
    return SIGN_IN;
  }
  if (/Unsupported URL/i.test(text) || /no video formats found/i.test(text)) {
    return UNSUPPORTED;
  }
  if (/cannot be downloaded/i.test(text) || /could not pull audio/i.test(text)) {
    return GENERIC;
  }
  if (FRIENDLY.has(text)) return text;
  return text.slice(-800) || "Pull failed.";
}

export function isMediaBlocked(message: string): boolean {
  const text = friendlyError(message);
  return (
    text === BLOCKED_STREAM ||
    text === EMPTY_FILE ||
    text === SIGN_IN ||
    text === UNAVAILABLE ||
    text === AGE_RESTRICTED ||
    text === AGE_NEEDS_ADULT ||
    text === NETWORK ||
    text === TIMED_OUT ||
    text === GENERIC
  );
}

export function isPermanentFailure(message: string): boolean {
  const text = friendlyError(message);
  return text === AGE_RESTRICTED || text === PRIVATE || text === MISSING_DEPS;
}

export function isRetryableFailure(message: string): boolean {
  return !isPermanentFailure(message);
}

export function shouldAbortRelays(message: string): boolean {
  const text = friendlyError(message);
  return text === PRIVATE || text === AGE_NEEDS_ADULT;
}

export function isAgeGatedFailure(message: string): boolean {
  const text = friendlyError(message);
  return text === AGE_RESTRICTED || text === UNAVAILABLE;
}

export function shouldTryRelay(message: string): boolean {
  const text = friendlyError(message);
  if (text === PRIVATE || text === AGE_NEEDS_ADULT) return false;
  return true;
}

export function shouldTryNextClient(message: string): boolean {
  const text = friendlyError(message);
  if (
    text === PRIVATE ||
    text === MISSING_DEPS ||
    text === AGE_RESTRICTED ||
    text === UNAVAILABLE ||
    text === AGE_NEEDS_ADULT
  ) {
    return false;
  }
  return true;
}

export function adultGateError(message: string, adult: boolean): string | null {
  if (adult) return null;
  if (isAgeGatedFailure(message)) return AGE_NEEDS_ADULT;
  return null;
}

export function allowAgeRelay(name: string, adult: boolean): boolean {
  if (adult) return true;
  return name !== "ytmp3";
}

function looksLikeInternal(msg: string): boolean {
  if (msg === MISSING_DEPS) return false;
  if (FRIENDLY.has(msg)) return false;
  return /traceback|yt_dlp|python(3|\s*version)?|ffmpeg version|ERROR:\s*\[|Deprecated Feature|File "\/|node:internal|at Object\.|googlevideo|innertube|extractor-args|js runtime/i.test(
    msg,
  );
}

export function sanitizeJobError(raw: string): string {
  let msg = friendlyError(raw);
  if (/Deprecated Feature|please update to Python|ERROR:\s*\[youtube\]/i.test(msg)) {
    msg = friendlyError(msg);
  }
  if (looksLikeInternal(msg) || /Deprecated Feature|please update to Python|ERROR:\s*\[youtube\]/i.test(msg)) {
    return GENERIC;
  }
  const line = msg.split(/\r?\n/).map((part) => part.trim()).find(Boolean);
  return line || "Pull failed.";
}

export function relayError(detail?: string): Error {
  const t = stripYtDlpNoise(String(detail || ""));
  if (/age[- ]restricted/i.test(t) || /sign in to confirm your age/i.test(t)) {
    return new Error(AGE_RESTRICTED);
  }
  if (/private video|\bprivate\b/i.test(t) && /video/i.test(t)) return new Error(PRIVATE);
  if (/not available|unavailable/i.test(t)) return new Error(UNAVAILABLE);
  return new Error(GENERIC);
}
