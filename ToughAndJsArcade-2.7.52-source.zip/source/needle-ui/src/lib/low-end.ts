let cached: boolean | null = null;
export function lowEndDevice(): boolean {
  if (cached !== null) return cached;
  let v = false;
  try {
    const c = (window as any).__tjCfg;
    if (c && typeof c.lowEnd === "boolean") v = c.lowEnd;
    else {
      const n = navigator as any;
      v = !!((n.deviceMemory && n.deviceMemory <= 4) || (n.hardwareConcurrency && n.hardwareConcurrency <= 4) || Math.min(screen.width, screen.height) * (window.devicePixelRatio || 1) <= 800);
    }
  } catch { /* ignore */ }
  cached = v;
  return v;
}
