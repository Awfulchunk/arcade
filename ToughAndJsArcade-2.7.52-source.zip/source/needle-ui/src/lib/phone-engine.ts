/* 2.7.50: Needle's on-phone download engine (no home-PC server, no Termux).
   The Android app exposes window.TJNeedle (NewPipeExtractor + NewPipe muxers + MediaCodec/LAME, all native).
   Finished files come back from https://tj-needle.local/out/<job> (served by the app itself, not the internet). */
import { cratePut, mimeForName, underbedPut } from "./crate-db";
import { isArchiveAudio } from "./underbed";
import type { AudioFormat } from "./audio-format";

type NativeNeedle = {
  info(): string;
  probe(url: string): string;
  start(spec: string): string;
  status(id: string): string;
  cancel(id: string): void;
  release(id: string): void;
};

export type EngineOption = {
  id: string;
  kind: "audio" | "video";
  label: string;
  detail: string;
  container: string;
  codec: string;
  ext: string;
  height: number;
  fps: number;
  kbps: number;
  bytes: number;
  merge: boolean;
};
export type EngineProbe = {
  ok: true;
  source: "youtube" | "web";
  url: string;
  id: string | null;
  title: string | null;
  uploader: string | null;
  durationSec: number;
  fileName: string | null;
  audio: EngineOption[];
  video: EngineOption[];
};
type Status = {
  id: string;
  state: "queued" | "running" | "done" | "error" | "cancelled" | "gone";
  phase: string;
  progress: number;
  error: string | null;
  code: string | null;
  title: string | null;
  note?: string;
  client?: string | null;
  name?: string;
  mime?: string;
  size?: number;
  probe?: EngineProbe;
};

export const OUT_BASE = "https://tj-needle.local/out/";

function native(): NativeNeedle | null {
  const w = window as unknown as { TJNeedle?: NativeNeedle; parent?: { TJNeedle?: NativeNeedle } };
  try {
    if (w.TJNeedle && typeof w.TJNeedle.probe === "function") return w.TJNeedle;
  } catch {
    /* ignore */
  }
  try {
    const p = window.parent as unknown as { TJNeedle?: NativeNeedle };
    if (p && p !== (window as unknown) && p.TJNeedle && typeof p.TJNeedle.probe === "function") return p.TJNeedle;
  } catch {
    /* cross-origin parent */
  }
  return null;
}

/** True when this copy of Needle is running inside the arcade app that has the on-phone engine. */
export function phoneEngineAvailable(): boolean {
  return native() !== null;
}

export function phoneEngineInfo(): { ok: boolean; why: string | null; version: string; extractor: string } | null {
  const n = native();
  if (!n) return null;
  try {
    return JSON.parse(n.info());
  } catch {
    return null;
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function readStatus(n: NativeNeedle, id: string): Status {
  try {
    return JSON.parse(n.status(id)) as Status;
  } catch {
    return { id, state: "error", phase: "", progress: 0, error: "The app sent a bad status.", code: "bug", title: null };
  }
}

/** Read a link and list the REAL qualities it offers. */
export async function phoneProbe(url: string, signal?: AbortSignal, onNote?: (note: string) => void): Promise<EngineProbe> {
  const n = native();
  if (!n) throw new Error("The on-phone downloader is only in the Tough & J's Arcade app.");
  const id = n.probe(url);
  if (!id) throw new Error(phoneEngineInfo()?.why || "The on-phone downloader can't run on this phone.");
  for (;;) {
    if (signal?.aborted) {
      n.cancel(id);
      throw new Error("Cancelled.");
    }
    const s = readStatus(n, id);
    if (s.state === "done" && s.probe) {
      n.release(id);
      return s.probe;
    }
    if (s.state === "error" || s.state === "gone" || s.state === "cancelled") {
      n.release(id);
      throw new Error(s.error || "Couldn't read that link.");
    }
    onNote?.(s.note || "");
    await sleep(250);
  }
}

export type PhonePullOpts = {
  url: string;
  kind: "audio" | "video";
  option: string;
  format: AudioFormat;
  bitrate: number;
  onProgress?: (pct: number, phase: string, note: string) => void;
  onJob?: (jobId: string) => void;
  signal?: AbortSignal;
};

/** Download + convert natively, then copy the finished file into the crate (IndexedDB) and drop the native copy. */
export async function phonePullToCrate(o: PhonePullOpts): Promise<{ filename: string; title: string }> {
  const n = native();
  if (!n) throw new Error("The on-phone downloader is only in the Tough & J's Arcade app.");
  const id = n.start(
    JSON.stringify({ url: o.url, kind: o.kind, option: o.option, format: o.format, bitrate: o.bitrate }),
  );
  if (!id) throw new Error(phoneEngineInfo()?.why || "The on-phone downloader can't run on this phone.");
  o.onJob?.(id);
  let s: Status;
  for (;;) {
    if (o.signal?.aborted) n.cancel(id);
    s = readStatus(n, id);
    if (s.state === "done") break;
    if (s.state === "error" || s.state === "gone") {
      n.release(id);
      throw new Error(s.error || "Pull failed.");
    }
    if (s.state === "cancelled") {
      n.release(id);
      throw new Error("Cancelled.");
    }
    o.onProgress?.(Math.max(1, Math.min(99, s.progress)), s.phase, s.note || "");
    await sleep(300);
  }
  try {
    o.onProgress?.(99, "crate", "");
    const res = await fetch(OUT_BASE + id, { cache: "no-store" });
    if (!res.ok) throw new Error("The finished file went missing. Pull it again.");
    const filename = s.name || (o.kind === "video" ? "video.mp4" : `audio.${o.format}`);
    const mime = s.mime || mimeForName(filename);
    const raw = await res.blob();
    const blob = raw.type === mime ? raw : new Blob([raw], { type: mime });
    if (blob.size < 256) throw new Error("The finished file came out empty.");
    if (s.size && blob.size !== s.size) throw new Error(`The file didn't copy fully (${blob.size} of ${s.size} bytes). Pull it again.`);
    const rec = { name: filename, size: blob.size, mtime: Date.now(), mime, blob };
    await cratePut(rec);
    if (isArchiveAudio(filename)) await underbedPut(rec).catch(() => undefined);
    return { filename, title: s.title || filename };
  } finally {
    n.release(id);
  }
}

/** Which listed options make sense for this pull (kind + chosen audio format). */
export function optionsFor(p: EngineProbe, kind: "audio" | "video", format: AudioFormat): EngineOption[] {
  if (kind === "video") return p.video;
  if (p.source === "youtube") {
    if (format === "m4a") return p.audio.filter((a) => a.codec === "aac");
    if (format === "ogg") return p.audio.filter((a) => a.codec === "opus");
  }
  return p.audio;
}

/** Pre-pick the option closest to the Settings defaults (video cap / best AAC). */
export function defaultOption(opts: EngineOption[], kind: "audio" | "video", cap: number): string | null {
  if (opts.length === 0) return null;
  if (kind === "video") {
    const under = opts.filter((o) => o.height <= cap);
    const pool = under.length ? under : [...opts].sort((a, b) => a.height - b.height);
    return pool[0]!.id;
  }
  const aac = opts.find((o) => o.codec === "aac" && o.kbps >= 100);
  return (aac || opts[0])!.id;
}

export function engineOutputLabel(kind: "audio" | "video", format: AudioFormat, opt: EngineOption | undefined, bitrate: number): string {
  if (!opt) return "";
  if (kind === "video") return opt.merge ? "One .mp4 (merged on the phone)" : `.${opt.ext} file`;
  if (format === "mp3") return opt.ext === "mp3" ? "Kept as the original .mp3" : `Real MP3, ${bitrate} kbps (encoded on the phone)`;
  if (format === "wav") return opt.ext === "wav" ? "Kept as the original .wav" : "WAV (uncompressed, big)";
  if (format === "m4a") return "AAC .m4a, copied as-is (no re-encode)";
  return "Ogg Opus, copied as-is (no re-encode)";
}
