/** Sample-accurate clip edits for the Cut desk. Pure data — no Web Audio. */

export type Stereo = {
  channels: Float32Array[];
  sampleRate: number;
};

export type SpanOp = {
  kind: "span";
  at: number;
  prev: Float32Array[];
  next: Float32Array[];
};

export type CutOp = { kind: "cut"; at: number; removed: Stereo };
export type InsertOp = { kind: "insert"; at: number; piece: Stereo };
export type ReplaceOp = { kind: "replace"; at: number; removed: Stereo; piece: Stereo };
export type EditOp = SpanOp | CutOp | InsertOp | ReplaceOp;

export type Session = {
  clip: Stereo;
  undo: EditOp[];
  redo: EditOp[];
  clipboard: Stereo | null;
};

const UNDO_CAP = 30;

export function lengthOf(clip: Stereo): number {
  return clip.channels[0]?.length ?? 0;
}

export function makeClip(channels: Float32Array[], sampleRate: number): Stereo {
  const n = channels[0]?.length ?? 0;
  return {
    sampleRate,
    channels: channels.map((ch) => {
      const copy = new Float32Array(n);
      copy.set(ch.subarray(0, Math.min(n, ch.length)));
      return copy;
    }),
  };
}

export function sessionFrom(clip: Stereo): Session {
  return { clip, undo: [], redo: [], clipboard: null };
}

function push(session: Session, clip: Stereo, op: EditOp, clipboard = session.clipboard): Session {
  return {
    clip,
    clipboard,
    undo: [...session.undo, op].slice(-UNDO_CAP),
    redo: [],
  };
}

function bounds(n: number, start: number, end: number): [number, number] {
  const a = Math.max(0, Math.min(n, Math.floor(Math.min(start, end))));
  const b = Math.max(0, Math.min(n, Math.floor(Math.max(start, end))));
  return [a, b];
}

export function sliceClip(clip: Stereo, start: number, end: number): Stereo {
  const [a, b] = bounds(lengthOf(clip), start, end);
  return {
    sampleRate: clip.sampleRate,
    channels: clip.channels.map((ch) => ch.slice(a, b)),
  };
}

export function removeRange(clip: Stereo, start: number, end: number): { next: Stereo; removed: Stereo; at: number } {
  const n = lengthOf(clip);
  const [a, b] = bounds(n, start, end);
  const removed = sliceClip(clip, a, b);
  const keep = n - (b - a);
  return {
    at: a,
    removed,
    next: {
      sampleRate: clip.sampleRate,
      channels: clip.channels.map((ch) => {
        const out = new Float32Array(keep);
        out.set(ch.subarray(0, a), 0);
        out.set(ch.subarray(b), a);
        return out;
      }),
    },
  };
}

function pieceChannel(piece: Stereo, index: number, count: number): Float32Array {
  const src = piece.channels[Math.min(index, Math.max(0, piece.channels.length - 1))];
  const out = new Float32Array(count);
  if (src) out.set(src.subarray(0, count));
  return out;
}

export function resample(clip: Stereo, sampleRate: number): Stereo {
  if (clip.sampleRate === sampleRate || sampleRate <= 0) return clip;
  const n = lengthOf(clip);
  if (n === 0) return { sampleRate, channels: clip.channels.map(() => new Float32Array(0)) };
  const outN = Math.max(1, Math.round((n * sampleRate) / clip.sampleRate));
  return {
    sampleRate,
    channels: clip.channels.map((ch) => {
      const out = new Float32Array(outN);
      const last = n - 1;
      for (let i = 0; i < outN; i++) {
        const pos = (i * (n - 1)) / Math.max(1, outN - 1);
        const i0 = Math.floor(pos);
        const i1 = Math.min(last, i0 + 1);
        const t = pos - i0;
        out[i] = (ch[i0] ?? 0) * (1 - t) + (ch[i1] ?? 0) * t;
      }
      return out;
    }),
  };
}

export function insertClip(clip: Stereo, at: number, piece: Stereo): Stereo {
  const fitted = piece.sampleRate === clip.sampleRate ? piece : resample(piece, clip.sampleRate);
  const n = lengthOf(clip);
  const add = lengthOf(fitted);
  const index = Math.max(0, Math.min(n, Math.floor(at)));
  if (add === 0) return clip;
  return {
    sampleRate: clip.sampleRate,
    channels: clip.channels.map((ch, i) => {
      const src = pieceChannel(fitted, i, add);
      const out = new Float32Array(n + add);
      out.set(ch.subarray(0, index), 0);
      out.set(src, index);
      out.set(ch.subarray(index), index + add);
      return out;
    }),
  };
}

function writeSpan(clip: Stereo, at: number, data: Float32Array[]): Stereo {
  return {
    sampleRate: clip.sampleRate,
    channels: clip.channels.map((ch, i) => {
      const out = new Float32Array(ch);
      const src = data[i];
      if (src && at >= 0 && at + src.length <= out.length) out.set(src, at);
      return out;
    }),
  };
}

function applyOp(clip: Stereo, op: EditOp): Stereo {
  if (op.kind === "span") return writeSpan(clip, op.at, op.next);
  if (op.kind === "cut") return removeRange(clip, op.at, op.at + lengthOf(op.removed)).next;
  if (op.kind === "insert") return insertClip(clip, op.at, op.piece);
  const cleared = removeRange(clip, op.at, op.at + lengthOf(op.removed)).next;
  return insertClip(cleared, op.at, op.piece);
}

function invertOp(clip: Stereo, op: EditOp): Stereo {
  if (op.kind === "span") return writeSpan(clip, op.at, op.prev);
  if (op.kind === "cut") return insertClip(clip, op.at, op.removed);
  if (op.kind === "insert") return removeRange(clip, op.at, op.at + lengthOf(op.piece)).next;
  const cleared = removeRange(clip, op.at, op.at + lengthOf(op.piece)).next;
  return insertClip(cleared, op.at, op.removed);
}

export function sessionUndo(session: Session): Session {
  const op = session.undo[session.undo.length - 1];
  if (!op) return session;
  return {
    ...session,
    clip: invertOp(session.clip, op),
    undo: session.undo.slice(0, -1),
    redo: [...session.redo, op],
  };
}

export function sessionRedo(session: Session): Session {
  const op = session.redo[session.redo.length - 1];
  if (!op) return session;
  return {
    ...session,
    clip: applyOp(session.clip, op),
    redo: session.redo.slice(0, -1),
    undo: [...session.undo, op],
  };
}

export function sessionCopy(session: Session, start: number, end: number): Session {
  const removed = sliceClip(session.clip, start, end);
  if (lengthOf(removed) === 0) return session;
  return { ...session, clipboard: removed };
}

export function sessionCut(session: Session, start: number, end: number): Session {
  const { next, removed, at } = removeRange(session.clip, start, end);
  if (lengthOf(removed) === 0) return session;
  return push(session, next, { kind: "cut", at, removed }, removed);
}

/** Keep only the selected span. Everything outside it is cut away. */
export function sessionCrop(session: Session, start: number, end: number): Session {
  const n = lengthOf(session.clip);
  const [a, b] = bounds(n, start, end);
  if (b - a < 1 || (a === 0 && b === n)) return session;
  let next = session;
  if (b < lengthOf(next.clip)) next = sessionCut(next, b, lengthOf(next.clip));
  if (a > 0) next = sessionCut(next, 0, Math.min(a, lengthOf(next.clip)));
  return next;
}

export function sessionPaste(session: Session, at: number, selection?: { start: number; end: number } | null): Session {
  const piece = session.clipboard;
  if (!piece || lengthOf(piece) === 0) return session;
  if (selection) {
    const { next, removed, at: from } = removeRange(session.clip, selection.start, selection.end);
    if (lengthOf(removed) === 0) {
      return push(session, insertClip(session.clip, at, piece), { kind: "insert", at: Math.floor(at), piece });
    }
    const replaced = insertClip(next, from, piece);
    return push(session, replaced, { kind: "replace", at: from, removed, piece });
  }
  const index = Math.max(0, Math.min(lengthOf(session.clip), Math.floor(at)));
  return push(session, insertClip(session.clip, index, piece), { kind: "insert", at: index, piece });
}

function spanEdit(session: Session, start: number, end: number, map: (sample: number, i: number, span: number) => number): Session {
  const n = lengthOf(session.clip);
  const [a, b] = bounds(n, start, end);
  if (b <= a) return session;
  const span = b - a;
  const prev = session.clip.channels.map((ch) => ch.slice(a, b));
  const next = session.clip.channels.map((ch) => {
    const out = new Float32Array(span);
    for (let i = 0; i < span; i++) {
      const s = map(ch[a + i] ?? 0, i, span);
      out[i] = s > 1 ? 1 : s < -1 ? -1 : s;
    }
    return out;
  });
  return push(session, writeSpan(session.clip, a, next), { kind: "span", at: a, prev, next });
}

export function sessionGain(session: Session, start: number, end: number, gain: number): Session {
  const g = Number.isFinite(gain) ? gain : 1;
  return spanEdit(session, start, end, (sample) => sample * g);
}

export function sessionFade(session: Session, start: number, end: number, edge: "in" | "out"): Session {
  return spanEdit(session, start, end, (sample, i, span) => {
    const t = span <= 1 ? 1 : i / (span - 1);
    return sample * (edge === "in" ? t : 1 - t);
  });
}

export type Mip = { bucket: number; min: Float32Array; max: Float32Array };

export function buildMips(channel: Float32Array): Mip[] {
  const levels: Mip[] = [];
  let bucket = 32;
  while (bucket < channel.length) {
    const bins = Math.ceil(channel.length / bucket);
    const min = new Float32Array(bins);
    const max = new Float32Array(bins);
    for (let i = 0; i < bins; i++) {
      const a = i * bucket;
      const b = Math.min(channel.length, a + bucket);
      let lo = 1;
      let hi = -1;
      for (let s = a; s < b; s++) {
        const v = channel[s] ?? 0;
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      min[i] = lo;
      max[i] = hi;
    }
    levels.push({ bucket, min, max });
    bucket *= 4;
  }
  return levels;
}

export function spanPeaks(
  channel: Float32Array,
  mips: Mip[],
  start: number,
  end: number,
  width: number,
): { min: number; max: number }[] {
  const pixels = Math.max(1, Math.floor(width));
  const spp = Math.max(0, end - start) / pixels;
  const mip = [...mips].reverse().find((level) => level.bucket <= spp && spp >= 8);
  const out: { min: number; max: number }[] = [];
  for (let x = 0; x < pixels; x++) {
    const a = Math.max(0, Math.floor(start + x * spp));
    const b = Math.min(channel.length, Math.max(a + 1, Math.ceil(start + (x + 1) * spp)));
    let lo = 1;
    let hi = -1;
    if (mip && b - a > mip.bucket) {
      const i0 = Math.max(0, Math.floor(a / mip.bucket));
      const i1 = Math.min(mip.min.length, Math.ceil(b / mip.bucket));
      for (let i = i0; i < i1; i++) {
        if ((mip.min[i] ?? 1) < lo) lo = mip.min[i] ?? lo;
        if ((mip.max[i] ?? -1) > hi) hi = mip.max[i] ?? hi;
      }
    } else {
      for (let s = a; s < b; s++) {
        const v = channel[s] ?? 0;
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
    }
    if (hi < lo) {
      lo = 0;
      hi = 0;
    }
    out.push({ min: lo, max: hi });
  }
  return out;
}

export function encodeWav(clip: Stereo): Blob {
  const channels = Math.max(1, clip.channels.length);
  const n = lengthOf(clip);
  const block = channels * 2;
  const dataSize = n * block;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);
  const write = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
  };
  write(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, clip.sampleRate, true);
  view.setUint32(28, clip.sampleRate * block, true);
  view.setUint16(32, block, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, dataSize, true);
  let offset = 44;
  for (let i = 0; i < n; i++) {
    for (let c = 0; c < channels; c++) {
      const sample = Math.max(-1, Math.min(1, clip.channels[c]?.[i] ?? 0));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }
  return new Blob([buffer], { type: "audio/wav" });
}

export function formatWindow(samples: number, sampleRate: number): string {
  if (sampleRate <= 0) return "0 ms";
  const ms = (samples / sampleRate) * 1000;
  if (ms < 1000) return `${ms < 10 ? ms.toFixed(1) : Math.round(ms)} ms`;
  const s = Math.round(ms / 1000);
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem.toString().padStart(2, "0")}`;
}

export function formatPrecise(samples: number, sampleRate: number): string {
  if (sampleRate <= 0) return "0";
  const sec = samples / sampleRate;
  if (sec < 10) return `${sec.toFixed(3)}s`;
  const whole = Math.floor(sec);
  const m = Math.floor(whole / 60);
  const rem = whole % 60;
  return `${m}:${rem.toString().padStart(2, "0")}`;
}

export function safeStem(name: string): string {
  const stem = name.replace(/\.[a-z0-9]+$/i, "");
  const clean = stem
    .replace(/[^A-Za-z0-9._-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "");
  return (clean || "needle").slice(0, 60);
}

export function nextCrateName(base: string, taken: Set<string>): string {
  if (!taken.has(base)) return base;
  const match = base.match(/^(.*?)(\.[a-z0-9]+)$/i);
  const stem = match?.[1] || base;
  const ext = match?.[2] || "";
  let i = 2;
  while (taken.has(`${stem}_${i}${ext}`)) i += 1;
  return `${stem}_${i}${ext}`;
}

export function dbToGain(db: number): number {
  return 10 ** (db / 20);
}
