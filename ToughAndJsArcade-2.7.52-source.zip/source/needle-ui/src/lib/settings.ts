import { create } from "zustand";
import { persist } from "zustand/middleware";
import { audioFormatOf, type AudioFormat } from "./audio-format";

export const BITRATES = [128, 192, 256] as const;
export type Bitrate = (typeof BITRATES)[number];
export type CrateSort = "newest" | "name" | "size";
export type PullKind = "audio" | "video";
export type PullSource = "youtube" | "web";
/** 2.7.50: where link pulls run. "phone" = built-in engine in the arcade app; "server" = the old home-PC server. */
export type PullEngine = "phone" | "server";
export const VIDEO_QUALITIES = [360, 720, 1080] as const;
export type VideoQuality = (typeof VIDEO_QUALITIES)[number];

function clampVolume(n: number): number {
  if (!Number.isFinite(n)) return 0.9;
  return Math.min(1, Math.max(0, n));
}

export type NeedleSettings = {
  bitrate: Bitrate;
  kind: PullKind;
  source: PullSource;
  videoQuality: VideoQuality;
  autoSweep: boolean;
  chime: boolean;
  sort: CrateSort;
  bundleZip: boolean;
  volume: number;
  adultMode: boolean;
  audioFormat: AudioFormat;
  engine: PullEngine;
  set: (patch: Partial<Omit<NeedleSettings, "set">>) => void;
};

export const useSettings = create<NeedleSettings>()(
  persist(
    (set) => ({
      bitrate: 192,
      kind: "audio",
      source: "youtube",
      videoQuality: 720,
      autoSweep: false,
      chime: true,
      sort: "newest",
      bundleZip: false,
      volume: 0.9,
      adultMode: false,
      audioFormat: "mp3",
      engine: "phone",
      set: (patch) =>
        set({
          ...patch,
          ...(patch.volume !== undefined ? { volume: clampVolume(patch.volume) } : {}),
          ...(patch.adultMode !== undefined ? { adultMode: !!patch.adultMode } : {}),
          ...(patch.audioFormat !== undefined ? { audioFormat: audioFormatOf(patch.audioFormat) } : {}),
          ...(patch.engine !== undefined ? { engine: patch.engine === "server" ? "server" : "phone" } : {}),
        }),
    }),
    { name: "needle-settings" },
  ),
);

export function sortCrate<T extends { name: string; size: number; mtime: number }>(
  files: T[],
  sort: CrateSort,
): T[] {
  const next = [...files];
  if (sort === "name") next.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === "size") next.sort((a, b) => b.size - a.size);
  else next.sort((a, b) => b.mtime - a.mtime);
  return next;
}
