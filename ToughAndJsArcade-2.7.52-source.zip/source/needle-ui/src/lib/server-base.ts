/* Offline app: the original needs its own server for link pulls and some format conversion. Here the server is a setting: the address of the
   home-PC server (same Wi-Fi), e.g. http://192.168.1.20:8765. Empty = no server (local audio tools still work). */
const KEY = "needle.server";
export function getServer(): string { try { return (localStorage.getItem(KEY) || "").trim().replace(/\/+$/, ""); } catch { return ""; } }
export function setServer(v: string) { try { localStorage.setItem(KEY, v.trim()); } catch { /* ignore */ } }
export function serverUrl(path: string): string {
  const b = getServer();
  if (!b) throw new Error("No server address set. Open Settings (gear) and type your home-PC server address, like http://192.168.1.20:8765");
  return b + path;
}

/* 2.7.2: the hardened home-PC server wants a long secret token on every call. It is typed in Settings and kept on this phone only. */
const TKEY = "needle.token";
export function getToken(): string { try { return (localStorage.getItem(TKEY) || "").trim(); } catch { return ""; } }
export function setToken(v: string) { try { localStorage.setItem(TKEY, v.trim()); } catch { /* ignore */ } }
export function serverAuth(): Record<string, string> {
  const t = getToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}
export function serverFail(res: Response, text: string): string | null {
  if (res.status === 401) return "The home server did not accept the token. Check the token in Settings (gear).";
  if (res.status === 429) return "The home server locked this phone out for 15 minutes (too many wrong tokens).";
  if (res.status === 403) return "The home server refused this app (origin not allowed).";
  return null;
}
export async function testServer(address: string, token: string): Promise<{ ok: boolean; message: string }> {
  const base = address.trim().replace(/\/+$/, "");
  if (!base) return { ok: false, message: "Type the server address first." };
  if (!token.trim()) return { ok: false, message: "Paste the token the server printed on your PC." };
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 5000);
  try {
    const r = await fetch((/^https?:\/\//i.test(base) ? base : "http://" + base) + "/health", { headers: { Authorization: `Bearer ${token.trim()}` }, signal: ac.signal, cache: "no-store" });
    const m = serverFail(r, "");
    if (m) return { ok: false, message: m };
    if (!r.ok) return { ok: false, message: `The server answered ${r.status}.` };
    const j = await r.json().catch(() => null);
    if (!j || j.ok !== true) return { ok: false, message: "That address answered, but it is not the home server." };
    return { ok: true, message: `Connected. ffmpeg ${j.ffmpeg ? "found" : "missing"}, yt-dlp ${j.ytdlp ? "found" : "missing (direct links only)"}.` };
  } catch { return { ok: false, message: "Could not reach it. Same Wi-Fi? Is the server window open?" }; } finally { clearTimeout(t); }
}
