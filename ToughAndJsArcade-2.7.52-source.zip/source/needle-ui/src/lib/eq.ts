/** Ten-band peaking EQ. Curve math matches the Web Audio biquad cookbook. */

export const EQ_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000] as const;
export const EQ_Q = 1.414;
export const EQ_MIN = -12;
export const EQ_MAX = 12;

export type EqPreset = { id: string; label: string; gains: number[] };
export type StemMode = "full" | "vocals" | "instrumental";

export const EQ_PRESETS: EqPreset[] = [
  { id: "flat", label: "Flat", gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  { id: "warm", label: "Warm", gains: [2, 3, 2, 1, 0, -1, -1, 0, -1, -2] },
  { id: "bass", label: "Bass", gains: [6, 5, 3, 1, 0, 0, 0, 0, 0, 0] },
  { id: "vocal", label: "Vocal", gains: [-2, -1, 0, 1, 3, 4, 3, 1, 0, -1] },
  { id: "night", label: "Night", gains: [-3, -1, 0, 0, 0, -1, -2, -4, -6, -8] },
  { id: "bright", label: "Bright", gains: [-1, 0, 0, 0, 1, 2, 3, 4, 4, 3] },
];

export const BAND_GUIDE = [
  { name: "Rumble", plain: "The lowest thump. You feel it more than you hear it." },
  { name: "Bass", plain: "Kick and bass. Up makes the bottom louder." },
  { name: "Warmth", plain: "Thickness. Too far up sounds muddy." },
  { name: "Body", plain: "The chest of the song. Too far up sounds boxy." },
  { name: "Honk", plain: "The middle. This is where a mix can sound hollow." },
  { name: "Push", plain: "Shoves the song forward, closer to you." },
  { name: "Vocals", plain: "The singer. Up makes words clearer and louder." },
  { name: "Bite", plain: "Consonants and snap. Too far up sounds harsh." },
  { name: "Air", plain: "Sparkle, cymbals, and breath." },
  { name: "Sheen", plain: "The very top. Mostly shine. Little music lives here." },
] as const;

export const PRESET_PLAIN: Record<string, string> = {
  flat: "No change. The song as it was recorded.",
  warm: "More bass, softer top. Feels cozy.",
  bass: "Turns the low end up.",
  vocal: "Makes the singer clearer and louder.",
  night: "Cuts the sharp highs so it is easier when the volume is low.",
  bright: "More sparkle, cymbals, and detail.",
  mine: "The curve you kept on this phone.",
  custom: "Your own mix of the ten sliders.",
};

export const STEM_PLAIN: Record<StemMode, string> = {
  full: "The whole song. Singer and music together.",
  vocals: "Keeps the center, which is usually the singer. Best when the voice sits in the middle.",
  instrumental: "Cuts the center, which usually drops the singer and leaves the music.",
};

export function flatGains(): number[] {
  return EQ_BANDS.map(() => 0);
}

export function clampGain(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.min(EQ_MAX, Math.max(EQ_MIN, Math.round(n * 2) / 2));
}

export function normalizeGains(gains: number[]): number[] {
  return EQ_BANDS.map((_, i) => clampGain(gains[i] ?? 0));
}

/** Magnitude of one peaking biquad, in dB. */
export function biquadMagDb(freq: number, f0: number, q: number, gainDb: number, sampleRate: number): number {
  if (gainDb === 0 || freq <= 0 || f0 <= 0 || sampleRate <= 0) return 0;
  const A = 10 ** (gainDb / 40);
  const w0 = (2 * Math.PI * f0) / sampleRate;
  const alpha = Math.sin(w0) / (2 * q);
  const cos0 = Math.cos(w0);
  const b0 = 1 + alpha * A;
  const b1 = -2 * cos0;
  const b2 = 1 - alpha * A;
  const a0 = 1 + alpha / A;
  const a1 = -2 * cos0;
  const a2 = 1 - alpha / A;
  const w = (2 * Math.PI * freq) / sampleRate;
  const c1 = Math.cos(w);
  const c2 = Math.cos(2 * w);
  const s1 = Math.sin(w);
  const s2 = Math.sin(2 * w);
  const numR = b0 + b1 * c1 + b2 * c2;
  const numI = -(b1 * s1 + b2 * s2);
  const denR = a0 + a1 * c1 + a2 * c2;
  const denI = -(a1 * s1 + a2 * s2);
  const mag = Math.sqrt((numR * numR + numI * numI) / (denR * denR + denI * denI));
  if (!Number.isFinite(mag) || mag <= 0) return 0;
  return 20 * Math.log10(mag);
}

export function responseDb(gains: number[], sampleRate = 48000, points = 96): { freq: number; db: number }[] {
  const shaped = normalizeGains(gains);
  const nyquist = sampleRate / 2;
  const minF = 20;
  const maxF = Math.max(minF + 1, Math.min(20000, nyquist - 50));
  const out: { freq: number; db: number }[] = [];
  for (let i = 0; i < points; i++) {
    const t = points === 1 ? 0 : i / (points - 1);
    const freq = minF * (maxF / minF) ** t;
    let db = 0;
    for (let b = 0; b < EQ_BANDS.length; b++) {
      db += biquadMagDb(freq, EQ_BANDS[b], EQ_Q, shaped[b] ?? 0, sampleRate);
    }
    out.push({ freq, db });
  }
  return out;
}

export function bandLabel(freq: number): string {
  if (freq >= 1000) {
    const k = freq / 1000;
    return Number.isInteger(k) ? `${k}k` : `${k.toFixed(1)}k`;
  }
  return String(freq);
}
