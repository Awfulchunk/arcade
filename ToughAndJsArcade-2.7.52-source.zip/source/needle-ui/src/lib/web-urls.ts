const MEDIA_EXT =
  /\.(mp4|m4v|webm|mkv|mov|m4a|mp3|aac|ogg|opus|wav)(?:$|[/?#])/i;

function stripTrailingPunct(url: string): string {
  return url.replace(/[),.;!?]+$/g, "");
}

function withProtocol(raw: string): string {
  return /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
}

export function isPrivateHost(host: string): boolean {
  const h = host.replace(/^\[|\]$/g, "").toLowerCase();
  if (!h) return true;
  if (h === "localhost" || h.endsWith(".localhost")) return true;
  if (h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan")) return true;
  if (h === "0.0.0.0" || h === "::" || h === "::1") return true;
  if (/^(127\.|10\.|192\.168\.|0\.|169\.254\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(h)) return true;
  if (h.startsWith("fc") || h.startsWith("fd") || h.startsWith("fe80")) return true;
  return false;
}

export function isSafeWebUrl(value: string): boolean {
  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:") return false;
    if (parsed.username || parsed.password) return false;
    if (isPrivateHost(parsed.hostname)) return false;
    if (!parsed.hostname.includes(".")) return false;
    return true;
  } catch {
    return false;
  }
}

export function canonicalizeWebUrl(raw: string): string | null {
  try {
    const parsed = new URL(withProtocol(stripTrailingPunct(raw.trim())));
    parsed.hash = "";
    if (parsed.protocol === "http:") parsed.protocol = "https:";
    if (parsed.protocol !== "https:") return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

export function isDirectMediaUrl(url: string): boolean {
  try {
    return MEDIA_EXT.test(new URL(url).pathname);
  } catch {
    return false;
  }
}

export function displayWebHost(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url.slice(0, 32);
  }
}

export function parseWebUrls(text: string): string[] {
  const found: string[] = [];
  const seen = new Set<string>();
  const push = (raw: string) => {
    const url = canonicalizeWebUrl(raw);
    if (!url || seen.has(url) || !isSafeWebUrl(url)) return;
    seen.add(url);
    found.push(url);
  };

  const re = /https?:\/\/[^\s<>"'`\\]+/gi;
  for (const match of text.matchAll(re)) {
    push(match[0]);
  }

  for (const token of text.split(/[\s,;|]+/)) {
    const t = stripTrailingPunct(token.trim());
    if (!t) continue;
    if (/^https?:\/\//i.test(t)) push(t);
    else if (/^(www\.)?[a-z0-9-]+(\.[a-z0-9-]+)+[/:].+/i.test(t)) push(t);
  }

  return found;
}

export function mentionsUnsafeWeb(text: string): boolean {
  const re = /https?:\/\/[^\s<>"'`\\]+/gi;
  for (const match of text.matchAll(re)) {
    const url = canonicalizeWebUrl(match[0]);
    if (url && !isSafeWebUrl(url)) return true;
  }
  return false;
}
