/* Offline app: no server-side library. The crate lives in this phone's browser storage. */
export type LibraryFile = { name: string; size: number; mtime: number };
export const listLibrary = async (): Promise<LibraryFile[]> => [];
export const clearLibrary = async (): Promise<{ ok: boolean }> => ({ ok: true });
export const deleteLibraryFile = async (_: unknown): Promise<{ ok: boolean }> => ({ ok: true });
