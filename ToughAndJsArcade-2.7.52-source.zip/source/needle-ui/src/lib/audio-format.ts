export const AUDIO_FORMATS = ["mp3", "m4a", "wav", "ogg"] as const;
export type AudioFormat = (typeof AUDIO_FORMATS)[number];

export function audioFormatOf(value: unknown): AudioFormat {
  return value === "m4a" || value === "wav" || value === "ogg" || value === "mp3" ? value : "mp3";
}

export function fileExt(name: string): string {
  return name.split(".").pop()?.toLowerCase() || "";
}

export function withFormat(name: string, format: AudioFormat): string {
  const stem = name.replace(/\.[^.]+$/, "") || "audio";
  return `${stem}.${format}`;
}

/** yt-dlp calls ogg "vorbis". The file still ends in .ogg. */
export function ytdlpAudioFormat(format: AudioFormat): string {
  return format === "ogg" ? "vorbis" : format;
}
