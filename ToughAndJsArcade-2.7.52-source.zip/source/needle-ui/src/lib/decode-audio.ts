import { mimeForName } from "./crate-db";
import { serverAuth, serverFail, serverUrl } from "./server-base";

function retag(blob: Blob, name: string): Blob {
  const mime = mimeForName(name);
  if (blob.type && blob.type !== "application/octet-stream") return blob;
  return new Blob([blob], { type: mime });
}

async function tryDecode(ctx: BaseAudioContext, blob: Blob): Promise<AudioBuffer | null> {
  try {
    return await ctx.decodeAudioData((await blob.arrayBuffer()).slice(0));
  } catch {
    return null;
  }
}

async function transcodeBlob(blob: Blob, name: string): Promise<Blob> {
  const res = await fetch(serverUrl("/api/transcode"), {
    method: "POST",
    headers: {
      ...serverAuth(),
      "content-type": blob.type || "application/octet-stream",
      "x-needle-name": name,
    },
    body: blob,
  });
  if (!res.ok) {
    const text = (await res.text().catch(() => "")).trim();
    throw new Error(serverFail(res, text) || text || "Could not read that audio.");
  }
  return res.blob();
}

/** Browser decode, then ffmpeg wav if the m4a container cannot be read directly. */
export async function openAudio(blob: Blob, name: string): Promise<{ buffer: AudioBuffer; playable: Blob }> {
  const ctx = new AudioContext();
  try {
    const typed = retag(blob, name);
    let playable = typed;
    let buffer = await tryDecode(ctx, typed);
    if (!buffer) {
      playable = await transcodeBlob(typed, name);
      buffer = await tryDecode(ctx, playable);
    }
    if (!buffer) throw new Error("Could not read that audio.");
    return { buffer, playable };
  } finally {
    await ctx.close();
  }
}
