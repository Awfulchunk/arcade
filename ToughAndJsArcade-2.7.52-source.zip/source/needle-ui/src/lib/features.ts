// One switch for the link downloader (YouTube / web links).
// 2.7.50: back ON. Pulls now run on the phone itself (built-in engine); the home-PC server stays as a Settings option.
export const DOWNLOADER_ENABLED = true;
