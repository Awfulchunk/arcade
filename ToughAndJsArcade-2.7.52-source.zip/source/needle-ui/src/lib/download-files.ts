/** Save a file the browser already has. A fresh blob URL avoids "Couldn't fetch file". */
export function saveBlobFile(blob: Blob, name: string): void {
  if (typeof document === "undefined") return;
  const file = new File([blob], name, { type: "application/octet-stream" });
  const url = URL.createObjectURL(file);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.rel = "noopener";
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 120_000);
}

export function crateFileHrefs(
  names: string[],
  hrefFor?: (name: string) => string,
): { href: string; download: string }[] {
  return names
    .filter((name) => typeof name === "string" && name.length > 0)
    .map((name) => ({
      href: hrefFor?.(name) || `/api/downloads/${encodeURIComponent(name)}`,
      download: name,
    }));
}

/**
 * Fire a separate browser download for every file in the same user-gesture tick.
 * Delaying between clicks lets the browser treat later ones as pop-ups and drop them.
 */
export function downloadSeparateFiles(
  names: string[],
  hrefFor?: (name: string) => string,
): number {
  if (typeof document === "undefined") return 0;
  const items = crateFileHrefs(names, hrefFor);
  for (const item of items) {
    const link = document.createElement("a");
    link.href = item.href;
    link.download = item.download;
    link.rel = "noopener";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  return items.length;
}
