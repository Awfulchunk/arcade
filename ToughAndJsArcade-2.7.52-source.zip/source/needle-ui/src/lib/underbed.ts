import { crateListRecords, crateRemove, underbedListRecords, underbedPut, type CrateRecord } from "./crate-db.ts";

export function isArchiveAudio(name: string): boolean {
  return /\.(m4a|mp3|wav|ogg|flac)$/i.test(name);
}

export function stemKey(name: string): string {
  return name
    .replace(/\.[a-z0-9]+$/i, "")
    .replace(/_(\d+)$/, "")
    .toLowerCase();
}

export type PlacedFile = { name: string; mtime: number; place: "crate" | "underbed" };

/** Extras only. Keeps the underbed copy, then the newest file in a stem group. */
export function copiesToDrop(files: PlacedFile[]): PlacedFile[] {
  const groups = new Map<string, PlacedFile[]>();
  for (const file of files) {
    const key = stemKey(file.name);
    const list = groups.get(key);
    if (list) list.push(file);
    else groups.set(key, [file]);
  }
  const drop: PlacedFile[] = [];
  for (const list of groups.values()) {
    if (list.length < 2) continue;
    const sorted = [...list].sort((a, b) => {
      if (a.place !== b.place) return a.place === "underbed" ? -1 : 1;
      return b.mtime - a.mtime;
    });
    const keep = sorted[0];
    for (const file of list) {
      if (!keep || (file.name === keep.name && file.place === keep.place)) continue;
      drop.push(file);
    }
  }
  return drop;
}

export function mergeDeskRecords(crate: CrateRecord[], bed: CrateRecord[]): CrateRecord[] {
  const map = new Map<string, CrateRecord>();
  for (const row of bed) map.set(row.name, row);
  for (const row of crate) map.set(row.name, row);
  return [...map.values()].sort((a, b) => (b.mtime || 0) - (a.mtime || 0));
}

export async function archiveMissingFromCrate(): Promise<number> {
  const [crate, hidden] = await Promise.all([crateListRecords(), underbedListRecords()]);
  const have = new Set(hidden.map((row) => row.name));
  let added = 0;
  for (const row of crate) {
    if (!isArchiveAudio(row.name) || have.has(row.name)) continue;
    await underbedPut(row);
    added += 1;
  }
  return added;
}

export async function removeCrateCopy(name: string): Promise<void> {
  await crateRemove(name);
}
