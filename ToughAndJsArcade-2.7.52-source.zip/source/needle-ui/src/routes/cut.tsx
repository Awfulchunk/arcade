import { createFileRoute } from "@tanstack/react-router";
import { CutterDesk } from "@/components/cutter-desk";

export const Route = createFileRoute("/cut")({
  component: CutterDesk,
});
