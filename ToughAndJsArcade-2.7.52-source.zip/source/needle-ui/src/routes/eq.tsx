import { createFileRoute } from "@tanstack/react-router";
import { EqualizerDesk } from "@/components/equalizer-desk";

export const Route = createFileRoute("/eq")({
  component: EqualizerDesk,
});
