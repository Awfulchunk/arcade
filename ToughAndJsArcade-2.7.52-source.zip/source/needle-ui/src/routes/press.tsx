import scratchUrl from "@/scratch.jpg";
import { useEffect, useMemo, useRef, useState, type DragEvent, type FormEvent } from "react";
import {
  AudioLines,
  Check,
  Download,
  Film,
  Link2,
  Loader2,
  Pause,
  Play,
  RotateCcw,
  Settings2,
  Trash2,
  Upload,
  X,
  Youtube,
} from "lucide-react";
import { toast } from "sonner";
import { serverAuth, serverFail, serverUrl } from "@/lib/server-base";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { DeskNav } from "@/components/desk-nav";
import { VinylMark } from "@/components/vinyl-mark";
import { SettingsPanel } from "@/components/settings-panel";
import { NowPlaying } from "@/components/now-playing";
import { VideoStage } from "@/components/video-stage";
import {
  clearLibrary,
  deleteLibraryFile,
  listLibrary,
} from "@/lib/pull.functions";
import { parseYoutubeUrls, youtubeVideoId, mentionsBlockedYoutube } from "@/lib/youtube";
import { displayWebHost, parseWebUrls, mentionsUnsafeWeb } from "@/lib/web-urls";
import { cn, displayTrackName, formatBytes, isVideoFile } from "@/lib/utils";
import { playChime } from "@/lib/chime";
import { sortCrate, useSettings, type PullKind } from "@/lib/settings";
import { saveBlobFile } from "@/lib/download-files";
import { crateClear, crateListRecords, cratePut, crateRemove, mergeCrateFiles, mimeForName, typedBlob, underbedPut } from "@/lib/crate-db";
import { archiveMissingFromCrate, isArchiveAudio } from "@/lib/underbed";
import { pullFileToCrate } from "@/lib/client-pull";
import { DOWNLOADER_ENABLED } from "@/lib/features";
import { nameForUpload, uniqueUploadName, uploadByteCap } from "@/lib/upload-track";
import { AUDIO_FORMATS, fileExt, withFormat } from "@/lib/audio-format";
import { phoneEngineAvailable, phoneProbe, phonePullToCrate, type EngineOption } from "@/lib/phone-engine";
import { QualitySheet, type QualityAsk } from "@/components/quality-sheet";
import type { Bitrate } from "@/lib/settings";

/* crypto.randomUUID needs Chrome 92+; older Android WebViews (e.g. Android 8-11 without updates) lack it. */
function newJobId(): string {
  const c = globalThis.crypto as Crypto | undefined;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  const b = new Uint8Array(16);
  if (c && typeof c.getRandomValues === "function") c.getRandomValues(b);
  else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}


type LibraryFile = { name: string; size: number; mtime: number };
type PullJob = {
  id: string;
  url: string;
  status: "queued" | "running" | "done" | "error";
  progress: number;
  title?: string;
  filename?: string;
  error?: string;
  bitrate?: number;
  kind: PullKind;
  source: "youtube" | "web";
  quality?: number;
  adult?: boolean;
  /** 2.7.50 on-phone engine: the exact stream picked in the quality sheet */
  option?: string;
  optionLabel?: string;
  note?: string;
  audioFormat?: string;
  phone?: boolean;
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
};

const MAX_BATCH = 50;
const PULL_CONCURRENCY = 2;
const EMPTY_BANDS = [0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12];

export const Route = { useLoaderData: () => [] as LibraryFile[] };

export function Home() {
  const initialFiles = Route.useLoaderData();
  const { bitrate, kind, source, videoQuality, autoSweep, chime, sort, volume, adultMode, audioFormat, engine, set } =
    useSettings();
  const usePhone = engine === "phone" && phoneEngineAvailable();
  const [ask, setAsk] = useState<QualityAsk | null>(null);
  const askDone = useRef<((pick: { opt: EngineOption; bitrate: Bitrate } | null) => void) | null>(null);
  const askRetry = useRef<(() => void) | null>(null);
  const aborts = useRef<Record<string, AbortController>>({});
  const cancelledQueued = useRef<Set<string>>(new Set());
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [jobs, setJobs] = useState<PullJob[]>([]);
  const [files, setFiles] = useState<LibraryFile[]>(initialFiles);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [kindFilter, setKindFilter] = useState<"all" | PullKind>("all");
  const [confirmClear, setConfirmClear] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [playingName, setPlayingName] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentMs, setCurrentMs] = useState(0);
  const [durationMs, setDurationMs] = useState(0);
  const [crateUrls, setCrateUrls] = useState<Record<string, string>>({});
  const [loopOne, setLoopOne] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [bands, setBands] = useState<number[]>(EMPTY_BANDS);
  const primed = useRef(false);
  const doneCount = useRef(0);
  const errorCount = useRef(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const confirmTimer = useRef<number>(0);
  const loopOneRef = useRef(false);
  const shuffleRef = useRef(false);
  const playingNameRef = useRef<string | null>(null);
  const listedRef = useRef<LibraryFile[]>([]);
  const playFileRef = useRef<(name: string) => void>(() => {});
  const stepTrackRef = useRef<(delta: number) => void>(() => {});
  const stopPlayerRef = useRef<() => void>(() => {});
  const crateUrlsRef = useRef<Record<string, string>>({});
  const blobsRef = useRef<Record<string, Blob>>({});
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const hydrateWait = useRef(Promise.resolve());

  const detected = useMemo(
    () => (source === "web" ? parseWebUrls(text) : parseYoutubeUrls(text)),
    [text, source],
  );
  const pulling = jobs.some((job) => job.status === "queued" || job.status === "running");
  const mixedCrate = files.some((file) => isVideoFile(file.name)) && files.some((file) => !isVideoFile(file.name));
  const listed = useMemo(() => {
    const sorted = sortCrate(files, sort);
    const q = query.trim().toLowerCase();
    return sorted.filter((file) => {
      if (kindFilter === "video" && !isVideoFile(file.name)) return false;
      if (kindFilter === "audio" && isVideoFile(file.name)) return false;
      if (q && !file.name.toLowerCase().includes(q) && !displayTrackName(file.name).toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [files, sort, query, kindFilter]);
  const playingVideo = !!playingName && isVideoFile(playingName);

  loopOneRef.current = loopOne;
  shuffleRef.current = shuffle;
  playingNameRef.current = playingName;
  listedRef.current = listed;

  const mediaNode = () =>
    playingNameRef.current && isVideoFile(playingNameRef.current)
      ? videoRef.current
      : audioRef.current;

  const mediaSrc = (name: string) => crateUrls[name] || "";

  const hydrateCrate = () => {
    const run = async () => {
      const records = await crateListRecords();
      const nextUrls: Record<string, string> = {};
      const localFiles: LibraryFile[] = [];
      const prev = crateUrlsRef.current;
      const blobs: Record<string, Blob> = {};
      for (const rec of records) {
        const blob = typedBlob(rec.blob, rec.name);
        blobs[rec.name] = blob;
        if (prev[rec.name]) URL.revokeObjectURL(prev[rec.name]);
        nextUrls[rec.name] = URL.createObjectURL(blob);
        localFiles.push({ name: rec.name, size: rec.size || blob.size, mtime: rec.mtime || 0 });
      }
      for (const [name, url] of Object.entries(prev)) {
        if (!nextUrls[name]) URL.revokeObjectURL(url);
      }
      crateUrlsRef.current = nextUrls;
      blobsRef.current = blobs;
      setCrateUrls(nextUrls);
      setFiles(mergeCrateFiles(localFiles, []));
      void archiveMissingFromCrate();
    };
    const next = hydrateWait.current.then(run, run);
    hydrateWait.current = next.then(
      () => undefined,
      () => undefined,
    );
    return next;
  };

  useEffect(() => {
    void hydrateCrate();
  }, []);

  useEffect(() => {
    const done = jobs.filter((job) => job.status === "done").length;
    const failed = jobs.filter((job) => job.status === "error").length;
    if (!primed.current) {
      primed.current = true;
      doneCount.current = done;
      errorCount.current = failed;
      return;
    }
    if (done > doneCount.current) {
      const n = done - doneCount.current;
      const latest = [...jobs].reverse().find((job) => job.status === "done");
      const video = latest?.kind === "video";
      toast.success(
        n === 1
          ? video
            ? "Clip ready in the crate."
            : "Track ready in the crate."
          : `${n} files ready in the crate.`,
      );
      if (chime) playChime();
    }
    if (failed > errorCount.current) {
      const latest = [...jobs].reverse().find((job) => job.status === "error");
      toast.error(latest?.error || "A pull failed.");
    }
    doneCount.current = done;
    errorCount.current = failed;
    const settled = jobs.length > 0 && jobs.every((job) => job.status === "done" || job.status === "error");
    if (autoSweep && settled) {
      setJobs((prev) => prev.filter((job) => job.status !== "done" && job.status !== "error"));
    }
  }, [jobs, autoSweep, chime]);

  useEffect(() => {
    const audio = audioRef.current;
    const video = videoRef.current;
    if (audio) audio.volume = volume;
    if (video) video.volume = volume;
  }, [volume]);

  const playFile = (name: string) => {
    const video = isVideoFile(name);
    if (video) {
      if (playingNameRef.current === name) {
        const node = videoRef.current;
        if (!node) return;
        if (node.paused) void node.play().then(() => setIsPlaying(true), () => setIsPlaying(false));
        else {
          node.pause();
          setIsPlaying(false);
        }
        return;
      }
      audioRef.current?.pause();
      setCurrentMs(0);
      setDurationMs(0);
      setPlayingName(name);
      return;
    }
    const node = audioRef.current;
    if (!node) return;
    if (playingNameRef.current === name) {
      if (node.paused) void node.play().then(() => setIsPlaying(true), () => setIsPlaying(false));
      else {
        node.pause();
        setIsPlaying(false);
      }
      return;
    }
    const url = crateUrlsRef.current[name];
    if (!url) {
      toast.error("That song isn't stored on this phone. Upload it or pull it again.");
      return;
    }
    videoRef.current?.pause();
    node.src = url;
    node.volume = volume;
    setCurrentMs(0);
    setDurationMs(0);
    setPlayingName(name);
    void node.play().then(
      () => setIsPlaying(true),
      () => setIsPlaying(false),
    );
  };

  const stopPlayer = () => {
    for (const node of [audioRef.current, videoRef.current]) {
      if (!node) continue;
      node.pause();
      node.removeAttribute("src");
      node.load();
    }
    setPlayingName(null);
    setIsPlaying(false);
    setCurrentMs(0);
    setDurationMs(0);
    setBands(EMPTY_BANDS);
  };

  const stepTrack = (delta: number) => {
    const crate = listedRef.current;
    const current = playingNameRef.current;
    if (!current || crate.length === 0) return;
    if (shuffleRef.current && crate.length > 1) {
      const others = crate.filter((file) => file.name !== current);
      const next = others[Math.floor(Math.random() * others.length)];
      if (next) playFile(next.name);
      return;
    }
    const index = crate.findIndex((file) => file.name === current);
    const next = crate[(index + delta + crate.length) % crate.length];
    if (next) playFile(next.name);
  };

  playFileRef.current = playFile;
  stepTrackRef.current = stepTrack;
  stopPlayerRef.current = stopPlayer;

  const onEnded = () => {
    if (loopOneRef.current) {
      const node = mediaNode();
      if (!node) return;
      node.currentTime = 0;
      void node.play();
      return;
    }
    stepTrack(1);
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, select, [contenteditable]")) return;
      if (event.key === " " && playingNameRef.current) {
        event.preventDefault();
        playFileRef.current(playingNameRef.current);
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        stepTrackRef.current(1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        stepTrackRef.current(-1);
      } else if (event.key === "Escape") {
        stopPlayerRef.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy) return;
    const urls = source === "web" ? parseWebUrls(text) : parseYoutubeUrls(text);
    if (urls.length === 0) {
      const reason =
        source === "web"
          ? mentionsUnsafeWeb(text)
            ? "That link isn't allowed."
            : "Paste at least one https link from the web."
          : mentionsBlockedYoutube(text)
            ? "Playlists and channels are blocked. Paste video links."
            : "Paste at least one YouTube URL, or switch to Web.";
      toast.error(reason);
      return;
    }
    if (urls.length > MAX_BATCH) {
      toast.error(`Cap is ${MAX_BATCH} links per pull.`);
      return;
    }
    if (usePhone) {
      setBusy(true);
      try {
        await phoneSubmit(urls);
      } finally {
        setBusy(false);
      }
      return;
    }
    setBusy(true);
    const stamp = Date.now();
    const batch: PullJob[] = urls.map((url, index) => ({
      id: newJobId(),
      url,
      status: "queued",
      progress: 0,
      bitrate,
      kind,
      source,
      quality: videoQuality,
      adult: adultMode,
      audioFormat,
      createdAt: stamp + index,
    }));
    setJobs((prev) => [...prev, ...batch]);
    setText("");
    const patch = (id: string, next: Partial<PullJob>) => {
      setJobs((prev) => prev.map((job) => (job.id === id ? { ...job, ...next } : job)));
    };
    try {
      let cursor = 0;
      const workers = Array.from({ length: Math.min(PULL_CONCURRENCY, batch.length) }, async () => {
        while (true) {
          const job = batch[cursor];
          cursor += 1;
          if (!job) return;
          patch(job.id, { status: "running", progress: 8, startedAt: Date.now(), error: undefined });
          try {
            const pulled = await pullFileToCrate({
              url: job.url,
              kind: job.kind,
              source: job.source,
              bitrate: job.bitrate === 128 || job.bitrate === 256 ? job.bitrate : 192,
              quality: job.quality === 360 || job.quality === 1080 ? job.quality : 720,
              adult: adultMode,
              audioFormat,
            });
            patch(job.id, {
              status: "done",
              progress: 100,
              filename: pulled.filename,
              title: pulled.title,
              finishedAt: Date.now(),
            });
            await hydrateCrate();
          } catch (err) {
            patch(job.id, {
              status: "error",
              progress: 0,
              error: err instanceof Error ? err.message : "Pull failed.",
              finishedAt: Date.now(),
            });
          }
        }
      });
      await Promise.all(workers);
    } finally {
      setBusy(false);
    }
  };

  /* ---------- 2.7.50 on-phone engine: read each link, let Jay pick the real quality, then pull ---------- */
  const askQuality = (base: QualityAsk) =>
    new Promise<{ opt: EngineOption; bitrate: Bitrate } | null>((resolve) => {
      askDone.current = resolve;
      setAsk(base);
    });

  const closeAsk = (pick: { opt: EngineOption; bitrate: Bitrate } | null) => {
    const done = askDone.current;
    askDone.current = null;
    setAsk(null);
    done?.(pick);
  };

  const patchJob = (id: string, next: Partial<PullJob>) => {
    setJobs((prev) => prev.map((job) => (job.id === id ? { ...job, ...next } : job)));
  };

  const runPhoneJob = async (job: PullJob) => {
    cancelledQueued.current.delete(job.id);
    const ac = new AbortController();
    aborts.current[job.id] = ac;
    patchJob(job.id, { status: "running", progress: 1, startedAt: Date.now(), error: undefined, finishedAt: undefined });
    try {
      const pulled = await phonePullToCrate({
        url: job.url,
        kind: job.kind,
        option: job.option || "",
        format: (job.audioFormat as typeof audioFormat) || audioFormat,
        bitrate: job.bitrate || 192,
        signal: ac.signal,
        onProgress: (pct, _phase, note) => patchJob(job.id, { progress: pct, note }),
      });
      patchJob(job.id, { status: "done", progress: 100, note: "", filename: pulled.filename, title: pulled.title, finishedAt: Date.now() });
      await hydrateCrate();
    } catch (err) {
      patchJob(job.id, {
        status: "error",
        progress: 0,
        note: "",
        error: err instanceof Error ? err.message : "Pull failed.",
        finishedAt: Date.now(),
      });
    } finally {
      delete aborts.current[job.id];
    }
  };

  const phoneSubmit = async (urls: string[]) => {
    const picked: PullJob[] = [];
    const fmt = audioFormat;
    for (let index = 0; index < urls.length; index++) {
      const url = urls[index]!;
      const base: QualityAsk = { url, index, total: urls.length, kind, format: fmt, bitrate, cap: videoQuality, probe: null, error: null };
      const pending = askQuality(base);
      const ac = new AbortController();
      const read = () => {
        setAsk((cur) => (cur && cur.url === url && cur.index === index ? { ...cur, probe: null, error: null, note: "" } : cur));
        void phoneProbe(url, ac.signal, (note) =>
          setAsk((cur) => (cur && cur.url === url && cur.index === index && (cur.note || "") !== note ? { ...cur, note } : cur)),
        ).then(
          (probe) => setAsk((cur) => (cur && cur.url === url && cur.index === index ? { ...cur, probe } : cur)),
          (err) => setAsk((cur) => (cur && cur.url === url && cur.index === index ? { ...cur, error: err instanceof Error ? err.message : "Couldn't read that link." } : cur)),
        );
      };
      askRetry.current = read;
      read();
      const pick = await pending;
      askRetry.current = null;
      ac.abort();
      if (!pick) continue;
      const job: PullJob = {
        id: newJobId(),
        url,
        status: "queued",
        progress: 0,
        bitrate: pick.bitrate,
        kind,
        source,
        quality: pick.opt.height || undefined,
        adult: adultMode,
        audioFormat: fmt,
        option: pick.opt.id,
        optionLabel: pick.opt.label,
        phone: true,
        createdAt: Date.now() + index,
      };
      picked.push(job);
      setJobs((prev) => [...prev, job]);
    }
    if (picked.length === 0) return;
    setText("");
    let cursor = 0;
    const workers = Array.from({ length: Math.min(PULL_CONCURRENCY, picked.length) }, async () => {
      while (true) {
        const job = picked[cursor];
        cursor += 1;
        if (!job) return;
        if (cancelledQueued.current.has(job.id)) continue;
        await runPhoneJob(job);
      }
    });
    await Promise.all(workers);
  };

  const onCancelJob = (id: string) => {
    const ac = aborts.current[id];
    if (ac) ac.abort();
    else {
      cancelledQueued.current.add(id);
      patchJob(id, { status: "error", progress: 0, error: "Cancelled.", finishedAt: Date.now() });
    }
  };

  const onDelete = async (name: string) => {
    try {
      if (playingName === name) stopPlayer();
      await crateRemove(name).catch(() => undefined);
      await deleteLibraryFile({ data: { name } }).catch(() => undefined);
      await hydrateCrate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not remove file.");
    }
  };

  const onClearAll = async () => {
    if (!confirmClear) {
      setConfirmClear(true);
      window.clearTimeout(confirmTimer.current);
      confirmTimer.current = window.setTimeout(() => setConfirmClear(false), 4000);
      return;
    }
    window.clearTimeout(confirmTimer.current);
    setConfirmClear(false);
    try {
      stopPlayer();
      await crateClear().catch(() => undefined);
      await clearLibrary().catch(() => undefined);
      await hydrateCrate();
      toast.success("Crate emptied.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not empty the crate.");
    }
  };

  const savePhoneFile = async (name: string, blob: Blob) => {
    if (isVideoFile(name) || fileExt(name) === audioFormat || usePhone) {
      saveBlobFile(blob, name);
      return;
    }
    const res = await fetch(serverUrl("/api/convert"), {
      method: "POST",
      headers: {
        ...serverAuth(),
        "content-type": blob.type || "application/octet-stream",
        "x-needle-name": name,
        "x-needle-format": audioFormat,
        "x-needle-bitrate": String(bitrate),
      },
      body: blob,
    });
    if (!res.ok) {
      const text = (await res.text().catch(() => "")).trim();
      throw new Error(serverFail(res, text) || text || "Could not convert that audio.");
    }
    const out = await res.blob();
    const type =
      audioFormat === "mp3" ? "audio/mpeg" : audioFormat === "wav" ? "audio/wav" : audioFormat === "ogg" ? "audio/ogg" : "audio/mp4";
    saveBlobFile(new Blob([out], { type }), withFormat(name, audioFormat));
  };

  const onDownloadAll = async () => {
    const saved = files.filter((file) => blobsRef.current[file.name]);
    if (saved.length === 0) {
      toast.error("Nothing stored on this phone to save.");
      return;
    }
    for (const file of saved) {
      try {
        await savePhoneFile(file.name, blobsRef.current[file.name]!);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not save that file.");
        return;
      }
    }
    toast.success(saved.length === 1 ? "Saving that file." : `Saving ${saved.length} files — each on its own.`);
  };

  const onSweep = () => {
    setJobs((prev) => prev.filter((job) => job.status !== "done" && job.status !== "error"));
  };

  const runRetry = async (job: PullJob) => {
    if (job.phone && phoneEngineAvailable()) {
      await runPhoneJob(job);
      return;
    }
    const patch = (next: Partial<PullJob>) => {
      setJobs((prev) => prev.map((item) => (item.id === job.id ? { ...item, ...next } : item)));
    };
    patch({ status: "running", progress: 8, startedAt: Date.now(), error: undefined, finishedAt: undefined });
    try {
      const pulled = await pullFileToCrate({
        url: job.url,
        kind: job.kind,
        source: job.source,
        bitrate: job.bitrate === 128 || job.bitrate === 256 ? job.bitrate : 192,
        quality: job.quality === 360 || job.quality === 1080 ? job.quality : 720,
        adult: adultMode,
        audioFormat,
      });
      patch({
        status: "done",
        progress: 100,
        filename: pulled.filename,
        title: pulled.title,
        finishedAt: Date.now(),
      });
      await hydrateCrate();
    } catch (err) {
      patch({
        status: "error",
        progress: 0,
        error: err instanceof Error ? err.message : "Pull failed.",
        finishedAt: Date.now(),
      });
    }
  };

  const onRetry = async (id?: string) => {
    const targets = id
      ? jobs.filter((job) => job.id === id && job.status === "error")
      : jobs.filter((job) => job.status === "error");
    if (targets.length === 0) return;
    setBusy(true);
    try {
      let cursor = 0;
      const workers = Array.from({ length: Math.min(PULL_CONCURRENCY, targets.length) }, async () => {
        while (true) {
          const job = targets[cursor];
          cursor += 1;
          if (!job) return;
          await runRetry(job);
        }
      });
      await Promise.all(workers);
    } finally {
      setBusy(false);
    }
  };

  const absorbDrop = (event: DragEvent) => {
    event.preventDefault();
    setDragging(false);
    const files = [...event.dataTransfer.files];
    if (files.length > 0) {
      void saveUploads(files);
      return;
    }
    const dumped =
      event.dataTransfer.getData("text/uri-list") || event.dataTransfer.getData("text/plain");
    if (!dumped.trim()) return;
    setText((prev) => (prev.trim() ? `${prev.trim()}\n${dumped.trim()}` : dumped.trim()));
  };

  const saveUploads = async (list: File[]) => {
    const accepted = list
      .map((file) => ({ file, name: nameForUpload(file.name, file.type) }))
      .filter((item): item is { file: File; name: string } => Boolean(item.name));
    if (accepted.length === 0) {
      toast.error("Use a song or video file. m4a, mp3, wav, ogg, flac, or mp4.");
      return;
    }
    setUploading(true);
    try {
      const taken = new Set((await crateListRecords()).map((row) => row.name));
      let saved = 0;
      for (const item of accepted) {
        const base = item.name;
        if (item.file.size > uploadByteCap(base)) {
          toast.error(`${displayTrackName(base)} is too large.`);
          continue;
        }
        const bytes = await item.file.arrayBuffer();
        if (bytes.byteLength < 32) {
          toast.error(`${displayTrackName(base)} came through empty. Try it again.`);
          continue;
        }
        const name = uniqueUploadName(base, taken);
        taken.add(name);
        const mime = mimeForName(name);
        const blob = new Blob([bytes], { type: mime });
        const record = { name, size: blob.size, mtime: Date.now(), mime, blob };
        await cratePut(record);
        if (isArchiveAudio(name)) await underbedPut(record).catch(() => undefined);
        saved += 1;
      }
      await hydrateCrate();
      if (saved === 1) toast.success("Song saved on this phone.");
      else if (saved > 1) toast.success(`${saved} songs saved on this phone.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save that file.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const playRandom = () => {
    if (listed.length === 0) return;
    const pick = listed[Math.floor(Math.random() * listed.length)];
    if (pick) playFile(pick.name);
  };

  const retryable = jobs.filter((job) => job.status === "error").length;
  const pullLabel =
    detected.length > 1
      ? `Pull ${detected.length} ${kind === "video" ? "videos" : "tracks"}`
      : kind === "video"
        ? "Pull video"
        : "Pull audio";

  return (
    <main
      className={cn(
        "relative isolate min-h-dvh overflow-x-hidden px-4 py-8 sm:px-8 sm:py-12",
        playingName && !playingVideo && "pb-44",
        playingVideo && "pb-72",
      )}
    >
      <div className="relative mx-auto flex w-full max-w-5xl flex-col gap-10">
        <header className="flex items-start gap-4">
          <button
            type="button"
            onClick={playRandom}
            className="mt-1 shrink-0 rounded-full focus-visible:ring-2 focus-visible:ring-accent/40 focus-visible:outline-none"
            aria-label="Play a random file from the crate"
            disabled={listed.length === 0}
          >
            <VinylMark spinning={pulling || isPlaying} className="size-11 sm:size-12" />
          </button>
          <div className="min-w-0 flex-1">
            <DeskNav current="press" />
            <div className="flex flex-wrap items-end gap-2">
              <h1 className="font-display text-4xl font-medium tracking-tight text-fg sm:text-5xl">
                Needle
              </h1>
              {adultMode && (
                <Badge variant="accent" className="mb-1.5">
                  18+
                </Badge>
              )}
            </div>
            <p className="mt-2 max-w-xl text-sm text-muted sm:text-base">
              {DOWNLOADER_ENABLED ? (
                <>
                  YouTube or any web link. Pull audio as{" "}
                  <span className="font-mono text-fg">{audioFormat}</span> or video as{" "}
                  <span className="font-mono text-fg">mp4</span>. Upload a song you already have and it
                  stays in the crate. Download all saves each file on its own.
                </>
              ) : (
                <>Upload songs from this phone and they stay in the crate. Cut them, mix them, shape them in the equalizer. Download all saves each file on its own. The link downloader is off for now.</>
              )}
            </p>
          </div>
          <Button
            type="button"
            variant={settingsOpen ? "default" : "secondary"}
            size="icon"
            aria-pressed={settingsOpen}
            aria-label="Press settings"
            onClick={() => setSettingsOpen((open) => !open)}
          >
            <Settings2 />
          </Button>
        </header>

        <img
          src={scratchUrl}
          alt="Cute woman in retro clothes, the Needle cover"
          className="aspect-[16/9] w-full rounded-xl object-cover shadow-border"
        />

        <audio
          ref={audioRef}
          controls
          preload="auto"
          playsInline
          className="h-12 w-full"
          onTimeUpdate={(event) => setCurrentMs(event.currentTarget.currentTime * 1000)}
          onLoadedMetadata={(event) => setDurationMs((event.currentTarget.duration || 0) * 1000)}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={onEnded}
          onError={() => {
            if (!playingNameRef.current || isVideoFile(playingNameRef.current)) return;
            toast.error("This phone couldn't play that file.");
          }}
        />

        {settingsOpen && <SettingsPanel />}

        <section className="rounded-xl bg-surface p-4 shadow-border sm:p-5">
          <label
            className={cn(
              buttonVariants({ variant: "secondary" }),
              "relative mb-4 flex min-h-12 w-full cursor-pointer items-center justify-center",
              uploading && "pointer-events-none opacity-40",
            )}
          >
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="audio/*,video/*,.m4a,.mp3,.wav,.ogg,.flac,.aac,.mp4,.webm"
              className="absolute inset-0 z-10 h-full w-full cursor-pointer text-base opacity-[0.02]"
              aria-label="Upload songs from this phone"
              onChange={(event) => {
                const files = [...(event.target.files ?? [])];
                if (files.length) void saveUploads(files);
              }}
            />
            {uploading ? (
              <Loader2 className="animate-spin motion-reduce:animate-none" />
            ) : (
              <Upload />
            )}
            From this phone
          </label>
          {!DOWNLOADER_ENABLED && (
            <p className="rounded-lg bg-black/20 px-3 py-2 text-center text-sm text-muted" data-testid="downloader-off">
              Downloader is off for now. Upload songs from this phone; the cutter, equalizer and crate all work.
            </p>
          )}
          {DOWNLOADER_ENABLED && (
          <form onSubmit={onSubmit} className="flex flex-col gap-4">
            <label className="flex flex-col gap-2">
              <span className="text-sm font-medium text-fg">Links</span>
              <Textarea
                name="urls"
                required
                spellCheck={false}
                autoCapitalize="off"
                autoCorrect="off"
                placeholder={
                  source === "web"
                    ? "https://example.com/watch/...\nhttps://cdn.example.com/clip.mp4"
                    : "https://www.youtube.com/watch?v=...\nhttps://youtu.be/...\nhttps://youtu.be/..."
                }
                value={text}
                onChange={(e) => setText(e.target.value)}
                onDragOver={(event) => {
                  event.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={absorbDrop}
                className={cn("min-h-44", dragging && "ring-2 ring-accent/50")}
              />
            </label>
            {detected.length > 0 && (
              <ul className="flex flex-wrap gap-1.5" aria-label="Detected links">
                {detected.slice(0, 8).map((url) => {
                  const label =
                    source === "web"
                      ? displayWebHost(url)
                      : (youtubeVideoId(url) ?? url);
                  return (
                    <li key={url}>
                      <Badge className="font-mono normal-case tracking-normal">{label}</Badge>
                    </li>
                  );
                })}
                {detected.length > 8 && (
                  <li>
                    <Badge>+{detected.length - 8} more</Badge>
                  </li>
                )}
              </ul>
            )}
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <div
                  className="flex rounded-md bg-surface-2 p-1 shadow-border"
                  role="group"
                  aria-label="Source"
                >
                  <Button
                    type="button"
                    size="sm"
                    variant={source === "youtube" ? "default" : "ghost"}
                    onClick={() => set({ source: "youtube" })}
                    aria-pressed={source === "youtube"}
                  >
                    <Youtube />
                    YouTube
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={source === "web" ? "default" : "ghost"}
                    onClick={() => set({ source: "web", kind: "video" })}
                    aria-pressed={source === "web"}
                  >
                    <Link2 />
                    Web
                  </Button>
                </div>
                <div
                  className="flex rounded-md bg-surface-2 p-1 shadow-border"
                  role="group"
                  aria-label="Pull as"
                >
                  <Button
                    type="button"
                    size="sm"
                    variant={kind === "audio" ? "default" : "ghost"}
                    onClick={() => set({ kind: "audio" })}
                    aria-pressed={kind === "audio"}
                  >
                    <AudioLines />
                    Audio
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={kind === "video" ? "default" : "ghost"}
                    onClick={() => set({ kind: "video" })}
                    aria-pressed={kind === "video"}
                  >
                    <Film />
                    Video
                  </Button>
                </div>
                {kind === "audio" && (
                  <div className="flex rounded-md bg-surface-2 p-1 shadow-border" role="group" aria-label="Audio format">
                    {AUDIO_FORMATS.map((format) => (
                      <Button
                        key={format}
                        type="button"
                        size="sm"
                        variant={audioFormat === format ? "default" : "ghost"}
                        onClick={() => set({ audioFormat: format })}
                        aria-pressed={audioFormat === format}
                      >
                        {format}
                      </Button>
                    ))}
                  </div>
                )}
                <p className="text-sm text-muted">
                  {detected.length === 0
                    ? source === "web"
                      ? usePhone
                        ? "Paste a direct file link (.mp4, .mp3, .m4a, .webm…). Local and private hosts are blocked."
                        : "Paste page links or a direct .mp4. Local and private hosts are blocked."
                      : kind === "video"
                        ? adultMode
                          ? "YouTube video lands as mp4. Playlists are rejected."
                          : "YouTube video lands as mp4. R-rated titles need Adult mode."
                        : adultMode
                          ? `YouTube audio lands as ${audioFormat}. Playlists are rejected.`
                          : `YouTube audio lands as ${audioFormat}. Age-gated titles need Adult mode.`
                    : `${detected.length} ready to pull as ${kind}.`}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="ghost" onClick={() => setText("")} disabled={!text}>
                  Clear
                </Button>
                <Button type="submit" disabled={busy || detected.length === 0}>
                  {busy || pulling ? (
                    <Loader2 className="animate-spin motion-reduce:animate-none" />
                  ) : kind === "video" ? (
                    <Film />
                  ) : (
                    <AudioLines />
                  )}
                  {pullLabel}
                </Button>
              </div>
            </div>
          </form>
          )}
        </section>

        {jobs.length > 0 && (
          <section className="animate-rise flex flex-col gap-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-display text-xl font-medium tracking-tight">Queue</h2>
              <div className="flex flex-wrap items-center justify-end gap-1">
                {retryable > 0 && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => void onRetry()}>
                    <RotateCcw />
                    Retry failed
                  </Button>
                )}
                <Button type="button" variant="ghost" size="sm" onClick={onSweep}>
                  Clear finished
                </Button>
              </div>
            </div>
            <ul className="flex flex-col gap-2">
              {jobs.map((job) => (
                <JobRow
                  key={job.id}
                  job={job}
                  onRetry={() => void onRetry(job.id)}
                  onCancel={job.phone ? () => onCancelJob(job.id) : undefined}
                />
              ))}
            </ul>
          </section>
        )}

        <section className="flex flex-col gap-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="font-display text-xl font-medium tracking-tight">Crate</h2>
              <p className="text-sm text-muted">
                Play here, or save each file on its own — nothing gets mashed together.
              </p>
            </div>
            <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
              {files.length > 0 && (
                <>
                  <Button type="button" variant="secondary" onClick={onDownloadAll}>
                    <Download />
                    Download all
                  </Button>
                  <Button
                    type="button"
                    variant={confirmClear ? "destructive" : "ghost"}
                    onClick={() => void onClearAll()}
                  >
                    <Trash2 />
                    {confirmClear ? `Confirm ${files.length}` : "Clear all"}
                  </Button>
                </>
              )}
              <Badge>
                {files.length} file{files.length === 1 ? "" : "s"}
              </Badge>
            </div>
          </div>

          {mixedCrate && (
            <div className="flex flex-wrap gap-2" role="group" aria-label="Crate kind">
              {(
                [
                  ["all", "All"],
                  ["audio", "Audio"],
                  ["video", "Video"],
                ] as const
              ).map(([value, label]) => (
                <Button
                  key={value}
                  type="button"
                  size="sm"
                  variant={kindFilter === value ? "default" : "secondary"}
                  onClick={() => setKindFilter(value)}
                >
                  {label}
                </Button>
              ))}
            </div>
          )}

          {files.length > 3 && (
            <label className="flex flex-col gap-1">
              <span className="sr-only">Filter crate</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Filter crate…"
                className="h-11 rounded-md bg-surface px-3 text-sm text-fg shadow-border outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/40"
              />
            </label>
          )}

          {files.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border px-5 py-12 text-center">
              <p className="text-sm text-muted">Nothing in the crate yet.</p>
            </div>
          ) : listed.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border px-5 py-12 text-center">
              <p className="text-sm text-muted">No files match that filter.</p>
            </div>
          ) : (
            <ul className="overflow-hidden rounded-xl bg-surface shadow-border">
              {listed.map((file) => {
                const active = playingName === file.name;
                const video = isVideoFile(file.name);
                return (
                  <li
                    key={file.name}
                    className="flex items-center gap-3 border-b border-border px-4 py-3 last:border-b-0"
                  >
                    <button
                      type="button"
                      onClick={() => playFile(file.name)}
                      className="inline-flex size-11 min-h-11 shrink-0 items-center justify-center rounded-md text-muted transition-colors duration-quick hover:bg-surface-2 hover:text-fg"
                      aria-label={
                        active && isPlaying ? `Pause ${file.name}` : `Play ${file.name}`
                      }
                    >
                      {active && isPlaying ? (
                        <Pause className="size-4" />
                      ) : video ? (
                        <Film className="size-4" />
                      ) : (
                        <Play className="ml-0.5 size-4" />
                      )}
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={cn("truncate text-sm font-medium", active ? "text-accent" : "text-fg")}>
                        {displayTrackName(file.name)}
                      </p>
                      <p className="font-mono text-xs text-subtle tabular-nums">
                        {video ? "mp4" : fileExt(file.name) || audioFormat} · {formatBytes(file.size)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const blob = blobsRef.current[file.name];
                        if (!blob) {
                          toast.error("That song isn't stored on this phone.");
                          return;
                        }
                        void savePhoneFile(file.name, blob).catch((err) => {
                          toast.error(err instanceof Error ? err.message : "Could not save that file.");
                        });
                      }}
                      className={cn(
                        "inline-flex size-11 min-h-11 items-center justify-center rounded-md text-muted",
                        "transition-colors duration-quick hover:bg-surface-2 hover:text-fg",
                      )}
                      aria-label={`Download ${file.name}`}
                    >
                      <Download className="size-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => void onDelete(file.name)}
                      className="inline-flex size-11 min-h-11 items-center justify-center rounded-md text-muted transition-colors duration-quick hover:bg-bad/10 hover:text-bad"
                      aria-label={`Remove ${file.name}`}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>

      {playingName && playingVideo && (
        <VideoStage
          src={mediaSrc(playingName)}
          videoRef={videoRef}
          onTimeUpdate={setCurrentMs}
          onLoadedMetadata={setDurationMs}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={onEnded}
        />
      )}

      {playingName && (
        <NowPlaying
          track={{ name: playingName }}
          playing={isPlaying}
          currentMs={currentMs}
          durationMs={durationMs}
          bands={playingVideo ? EMPTY_BANDS : bands}
          loopOne={loopOne}
          shuffle={shuffle}
          onToggle={() => playFile(playingName)}
          onPrev={() => stepTrack(-1)}
          onNext={() => stepTrack(1)}
          onSeek={(ratio) => {
            const node = mediaNode();
            if (!node || !Number.isFinite(node.duration)) return;
            node.currentTime = ratio * node.duration;
          }}
          onClose={stopPlayer}
          onLoop={() => setLoopOne((value) => !value)}
          onShuffle={() => setShuffle((value) => !value)}
        />
      )}
      {ask && (
        <QualitySheet
          ask={ask}
          onPick={(opt, rate) => closeAsk({ opt, bitrate: rate })}
          onSkip={() => closeAsk(null)}
          onRetry={() => askRetry.current?.()}
          onBitrate={(b) => set({ bitrate: b })}
        />
      )}
    </main>
  );
}

function JobRow({ job, onRetry, onCancel }: { job: PullJob; onRetry: () => void; onCancel?: () => void }) {
  const label = job.title || job.url;
  const video = job.kind === "video";
  return (
    <li className="rounded-lg bg-surface px-4 py-3 shadow-border">
      <div className="flex items-start gap-3">
        <StatusIcon status={job.status} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-fg">{label}</p>
          {job.status === "error" && job.error ? (
            <p className="mt-1 text-sm leading-5 text-bad">{job.error}</p>
          ) : (
            <p className="mt-1 truncate font-mono text-xs text-subtle">
              {job.optionLabel ? `${job.optionLabel} · ` : ""}
              {job.url}
            </p>
          )}
          {job.status === "running" && job.note && <p className="mt-1 text-xs text-muted">{job.note}</p>}
          {job.status === "running" && <Progress value={job.progress} className="mt-3" />}
        </div>
        {onCancel && (job.status === "running" || job.status === "queued") && (
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex size-11 min-h-11 shrink-0 items-center justify-center rounded-md text-muted transition-colors duration-quick hover:bg-bad/10 hover:text-bad"
            aria-label={`Cancel ${label}`}
          >
            <X className="size-4" />
          </button>
        )}
        {job.status === "error" && (
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex size-11 min-h-11 shrink-0 items-center justify-center rounded-md text-muted transition-colors duration-quick hover:bg-surface-2 hover:text-fg"
            aria-label={`Retry ${label}`}
          >
            <RotateCcw className="size-4" />
          </button>
        )}
        <Badge className="shrink-0 capitalize">{video ? "video" : "audio"}</Badge>
        <Badge
          variant={job.status === "done" ? "ok" : job.status === "error" ? "bad" : "default"}
          className="shrink-0 capitalize tabular-nums"
        >
          {job.status === "running" ? `${Math.round(job.progress)}%` : job.status}
        </Badge>
      </div>
    </li>
  );
}

function StatusIcon({ status }: { status: PullJob["status"] }) {
  if (status === "running") {
    return (
      <Loader2 className="mt-0.5 size-4 shrink-0 animate-spin text-fg motion-reduce:animate-none" />
    );
  }
  if (status === "done") {
    return <Check className="mt-0.5 size-4 shrink-0 text-ok" />
  }
  if (status === "error") {
    return <X className="mt-0.5 size-4 shrink-0 text-bad" />;
  }
  return <span className="mt-1 size-2 shrink-0 rounded-full bg-subtle" />;
}
