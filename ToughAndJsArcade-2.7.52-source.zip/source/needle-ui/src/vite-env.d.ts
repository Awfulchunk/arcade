declare module "*.jpg" { const u: string; export default u; }
