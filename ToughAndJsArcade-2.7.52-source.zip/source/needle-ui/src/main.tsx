import { createRoot } from "react-dom/client";
import { createRootRoute, createRoute, createRouter, createMemoryHistory, Outlet, RouterProvider } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { BoothMenu } from "@/components/booth-menu";
import { CutterDesk } from "@/components/cutter-desk";
import { EqualizerDesk } from "@/components/equalizer-desk";
import { Home as PressDesk } from "@/routes/press";
import { AppErrorComponent } from "@/lib/error-component";
import "./styles.css";

const root = createRootRoute({
  component: () => (
    <>
      <Outlet />
      <Toaster theme="dark" position="bottom-center" toastOptions={{ className: "font-sans", style: { background: "var(--color-surface-2)", border: "1px solid var(--color-border)", color: "var(--color-fg)" } }} />
    </>
  ),
});
const idx = createRoute({ getParentRoute: () => root, path: "/", component: BoothMenu });
const cut = createRoute({ getParentRoute: () => root, path: "/cut", component: CutterDesk });
const eq = createRoute({ getParentRoute: () => root, path: "/eq", component: EqualizerDesk });
const press = createRoute({ getParentRoute: () => root, path: "/press", component: PressDesk });
const routeTree = root.addChildren([idx, cut, eq, press]);
const router = createRouter({ routeTree, history: createMemoryHistory({ initialEntries: [new URLSearchParams(location.search).get("p") || "/"] }), defaultErrorComponent: AppErrorComponent });
declare module "@tanstack/react-router" { interface Register { router: typeof router } }
(window as any).__needleRouter = router;
createRoot(document.getElementById("root")!).render(<RouterProvider router={router} />);
