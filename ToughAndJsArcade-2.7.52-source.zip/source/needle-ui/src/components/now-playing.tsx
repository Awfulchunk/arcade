import { Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward, X } from "lucide-react";
import { VinylMark } from "@/components/vinyl-mark";
import { Spectrum } from "@/components/spectrum";
import { displayTrackName, formatClock } from "@/lib/utils";
import { cn } from "@/lib/utils";

export type PlayingTrack = { name: string };

export function NowPlaying({
  track,
  playing,
  currentMs,
  durationMs,
  bands,
  loopOne,
  shuffle,
  onToggle,
  onPrev,
  onNext,
  onSeek,
  onClose,
  onLoop,
  onShuffle,
}: {
  track: PlayingTrack;
  playing: boolean;
  currentMs: number;
  durationMs: number;
  bands: number[];
  loopOne: boolean;
  shuffle: boolean;
  onToggle: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSeek: (ratio: number) => void;
  onClose: () => void;
  onLoop: () => void;
  onShuffle: () => void;
}) {
  const pct = durationMs > 0 ? Math.min(100, (currentMs / durationMs) * 100) : 0;
  const label = displayTrackName(track.name);

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 px-3 pb-3 sm:px-6">
      <div className="pointer-events-auto mx-auto flex max-w-5xl flex-col gap-2 rounded-xl bg-surface-2 p-3 shadow-soft sm:flex-row sm:items-center sm:gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <VinylMark spinning={playing} className="size-10 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-3">
              <p className="min-w-0 flex-1 truncate text-sm font-medium text-fg">{label}</p>
              <Spectrum bands={bands} active={playing} />
            </div>
            <div className="mt-1 flex items-center gap-2">
              <span className="font-mono text-xs text-subtle tabular-nums">
                {formatClock(currentMs)}
              </span>
              <input
                type="range"
                min={0}
                max={1000}
                value={Math.round(pct * 10)}
                aria-label="Seek"
                onChange={(event) => onSeek(Number(event.target.value) / 1000)}
                className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-surface accent-accent"
              />
              <span className="font-mono text-xs text-subtle tabular-nums">
                {formatClock(durationMs)}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-md text-muted hover:text-fg sm:hidden"
            aria-label="Close player"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="flex shrink-0 items-center justify-center">
          <button
            type="button"
            onClick={onShuffle}
            className={cn(
              "inline-flex size-11 items-center justify-center rounded-md",
              shuffle ? "text-accent" : "text-muted hover:text-fg",
            )}
            aria-pressed={shuffle}
            aria-label="Shuffle"
          >
            <Shuffle className="size-4" />
          </button>
          <button
            type="button"
            onClick={onPrev}
            className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
            aria-label="Previous track"
          >
            <SkipBack className="size-4" />
          </button>
          <button
            type="button"
            onClick={onToggle}
            className="inline-flex size-11 items-center justify-center rounded-md text-fg hover:bg-surface"
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? <Pause className="size-4" /> : <Play className="ml-0.5 size-4" />}
          </button>
          <button
            type="button"
            onClick={onNext}
            className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
            aria-label="Next track"
          >
            <SkipForward className="size-4" />
          </button>
          <button
            type="button"
            onClick={onLoop}
            className={cn(
              "inline-flex size-11 items-center justify-center rounded-md",
              loopOne ? "text-accent" : "text-muted hover:text-fg",
            )}
            aria-pressed={loopOne}
            aria-label={loopOne ? "Loop this track" : "Loop off"}
          >
            {loopOne ? <Repeat1 className="size-4" /> : <Repeat className="size-4" />}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="hidden size-11 items-center justify-center rounded-md text-muted hover:text-fg sm:inline-flex"
            aria-label="Close player"
          >
            <X className="size-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
