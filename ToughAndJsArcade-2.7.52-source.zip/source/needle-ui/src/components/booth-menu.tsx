import scratchUrl from "@/scratch.jpg";
import { Link } from "@tanstack/react-router";
import { AudioLines, Scissors, SlidersHorizontal } from "lucide-react";
import { VinylMark } from "@/components/vinyl-mark";

const CARDS = [
  {
    to: "/press",
    index: "01",
    kicker: "Pull",
    title: "Press",
    body: "YouTube or any web link. Audio as mp3, m4a, wav, or ogg. Video as mp4. Each file on its own.",
    icon: AudioLines,
  },
  {
    to: "/eq",
    index: "02",
    kicker: "Shape",
    title: "Equalizer",
    body: "Ten bands you can drag. Watch the curve, save a shape, hear it on a crate track.",
    icon: SlidersHorizontal,
  },
  {
    to: "/cut",
    index: "03",
    kicker: "Edit",
    title: "Cut",
    body: "Zoom into the wave until you can see the samples. Cut, copy, and paste the piece you want.",
    icon: Scissors,
  },
] as const;

export function BoothMenu() {
  return (
    <main className="relative isolate min-h-dvh overflow-x-hidden px-4 py-8 sm:px-8 sm:py-12">
      <div className="relative mx-auto flex w-full max-w-5xl flex-col gap-10">
        <header className="flex items-start gap-4">
          <VinylMark className="mt-1 size-11 shrink-0 sm:size-12" />
          <div>
            <p className="text-xs font-medium tracking-widest text-muted uppercase">Booth</p>
            <h1 className="font-display text-4xl font-medium tracking-tight text-fg sm:text-5xl">Needle</h1>
            <p className="mt-2 max-w-xl text-sm text-muted sm:text-base">
              Three desks. Pull a track, shape it, then cut the part you want to keep.
            </p>
          </div>
        </header>
        <img
          src={scratchUrl}
          alt="Cute woman in retro clothes, the Needle cover"
          className="aspect-[16/9] w-full rounded-xl object-cover shadow-border"
        />
        <ul className="grid gap-3 sm:grid-cols-3">
          {CARDS.map((card) => {
            const Icon = card.icon;
            return (
              <li key={card.to}>
                <Link
                  to={card.to}
                  className="flex h-full min-h-52 flex-col justify-between rounded-xl bg-surface p-5 shadow-border transition-shadow duration-fast ease-smooth hover:shadow-border-hover focus-visible:ring-2 focus-visible:ring-accent/40 focus-visible:outline-none"
                >
                  <div className="flex items-center justify-between text-muted">
                    <span className="font-mono text-xs">{card.index}</span>
                    <Icon className="size-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs font-medium tracking-widest text-subtle uppercase">{card.kicker}</p>
                    <h2 className="mt-1 font-display text-3xl font-medium tracking-tight text-fg">{card.title}</h2>
                    <p className="mt-2 text-sm text-muted">{card.body}</p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </main>
  );
}
