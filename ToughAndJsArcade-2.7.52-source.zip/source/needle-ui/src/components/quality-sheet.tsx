/* 2.7.50: pick the real quality for one link before it downloads (on-phone engine). Same look as the player bar. */
import { useEffect, useState } from "react";
import { Check, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn, formatBytes } from "@/lib/utils";
import { BITRATES, type Bitrate } from "@/lib/settings";
import type { AudioFormat } from "@/lib/audio-format";
import { defaultOption, engineOutputLabel, optionsFor, type EngineOption, type EngineProbe } from "@/lib/phone-engine";

export type QualityAsk = {
  url: string;
  index: number;
  total: number;
  kind: "audio" | "video";
  format: AudioFormat;
  bitrate: Bitrate;
  cap: number;
  probe: EngineProbe | null;
  error: string | null;
  note?: string;
};

function clock(sec: number): string {
  if (!(sec > 0)) return "";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function QualitySheet({
  ask,
  onPick,
  onSkip,
  onBitrate,
  onRetry,
}: {
  ask: QualityAsk;
  onPick: (opt: EngineOption, bitrate: Bitrate) => void;
  onSkip: () => void;
  onBitrate: (b: Bitrate) => void;
  onRetry: () => void;
}) {
  const opts = ask.probe ? optionsFor(ask.probe, ask.kind, ask.format) : [];
  const [sel, setSel] = useState<string | null>(null);
  const [rate, setRate] = useState<Bitrate>(ask.bitrate);
  useEffect(() => {
    setSel(ask.probe ? defaultOption(optionsFor(ask.probe, ask.kind, ask.format), ask.kind, ask.cap) : null);
    setRate(ask.bitrate);
  }, [ask.probe, ask.url, ask.kind, ask.format, ask.cap, ask.bitrate]);
  const chosen = opts.find((o) => o.id === sel);
  const needsRate = !!chosen && ask.kind === "audio" && ask.format === "mp3" && chosen.ext !== "mp3";
  const title = ask.probe?.title || ask.url;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 px-3 pb-3 sm:items-center" role="dialog" aria-label="Pick quality">
      <div className="animate-rise flex max-h-[88dvh] w-full max-w-lg flex-col gap-3 rounded-xl bg-surface-2 p-3 shadow-soft">
        <div className="flex items-start gap-2">
          <div className="min-w-0 flex-1">
            <p className="text-xs text-muted">
              {ask.total > 1 ? `Link ${ask.index + 1} of ${ask.total} · ` : ""}
              {ask.kind === "video" ? "Video" : `Audio as ${ask.format}`}
            </p>
            <p className="truncate text-sm font-medium text-fg">{title}</p>
            {ask.probe && (
              <p className="truncate font-mono text-xs text-subtle">
                {[ask.probe.uploader, clock(ask.probe.durationSec)].filter(Boolean).join(" · ")}
              </p>
            )}
          </div>
          <Button type="button" variant="ghost" size="icon" aria-label="Skip this link" onClick={onSkip}>
            <X />
          </Button>
        </div>

        {!ask.probe && !ask.error && (
          <p className="flex min-h-11 items-center gap-2 text-sm text-muted">
            <Loader2 className="size-4 animate-spin motion-reduce:animate-none" /> {ask.note || "Reading the link on this phone…"}
          </p>
        )}
        {ask.error && <p className="text-sm leading-5 text-bad">{ask.error}</p>}
        {ask.probe && opts.length === 0 && (
          <p className="text-sm leading-5 text-bad">
            {ask.kind === "video"
              ? "No phone-friendly (H.264) video quality was offered for this link."
              : ask.format === "m4a"
                ? "No AAC (.m4a) sound was offered. Pick mp3 or wav instead."
                : ask.format === "ogg"
                  ? "No Opus sound was offered, so a real .ogg isn't possible. Pick mp3 or wav instead."
                  : "No sound stream was offered for this link."}
          </p>
        )}

        {opts.length > 0 && (
          <ul className="flex min-h-0 flex-col gap-1.5 overflow-y-auto" aria-label="Qualities">
            {opts.map((o) => {
              const on = o.id === sel;
              return (
                <li key={o.id}>
                  <button
                    type="button"
                    onClick={() => setSel(o.id)}
                    aria-pressed={on}
                    className={cn(
                      "flex min-h-11 w-full items-center gap-3 rounded-md px-3 py-2 text-left transition-colors duration-quick",
                      on ? "bg-accent text-accent-fg" : "bg-surface text-fg shadow-border hover:bg-surface-2",
                    )}
                  >
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-medium">{o.label}</span>
                      <span className={cn("block text-xs leading-4", on ? "opacity-80" : "text-muted")}>{o.detail}</span>
                    </span>
                    <span className="shrink-0 font-mono text-xs tabular-nums">{o.bytes > 0 ? formatBytes(o.bytes) : "?"}</span>
                    {on && <Check className="size-4 shrink-0" />}
                  </button>
                </li>
              );
            })}
          </ul>
        )}

        {needsRate && (
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="MP3 bitrate">
            <span className="text-xs text-muted">MP3 bitrate</span>
            {BITRATES.map((b) => (
              <Button
                key={b}
                type="button"
                size="sm"
                className="h-11 min-h-11"
                variant={rate === b ? "default" : "secondary"}
                onClick={() => {
                  setRate(b);
                  onBitrate(b);
                }}
              >
                {b}k
              </Button>
            ))}
          </div>
        )}

        {chosen && <p className="text-xs text-muted">Lands in the crate as: {engineOutputLabel(ask.kind, ask.format, chosen, rate)}</p>}

        <div className="flex gap-2">
          <Button type="button" variant="ghost" className="flex-1" onClick={onSkip}>
            {ask.total > 1 ? "Skip" : "Cancel"}
          </Button>
          {ask.error ? (
            <Button type="button" className="flex-1" onClick={onRetry}>
              Try again
            </Button>
          ) : (
            <Button type="button" className="flex-1" disabled={!chosen} onClick={() => chosen && onPick(chosen, rate)}>
              Pull this
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
