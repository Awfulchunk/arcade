import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

const ITEMS = [
  { to: "/press", id: "press", label: "Press" },
  { to: "/eq", id: "eq", label: "Equalizer" },
  { to: "/cut", id: "cut", label: "Cut" },
] as const;

export function DeskNav({ current }: { current: (typeof ITEMS)[number]["id"] }) {
  return (
    <nav
      aria-label="Desks"
      className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-medium tracking-widest uppercase"
    >
      <Link to="/" className="text-subtle hover:text-fg">
        Booth
      </Link>
      <span aria-hidden="true" className="text-border">
        /
      </span>
      {ITEMS.map((item) => (
        <Link
          key={item.id}
          to={item.to}
          aria-current={item.id === current ? "page" : undefined}
          className={cn(item.id === current ? "text-fg" : "text-muted hover:text-fg")}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
