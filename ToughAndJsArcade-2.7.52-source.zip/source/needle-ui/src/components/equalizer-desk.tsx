import { lowEndDevice } from "@/lib/low-end";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Pause, Play, SlidersHorizontal } from "lucide-react";
import { toast } from "sonner";
import {
  BAR_BOARDS,
  BAR_COLORS,
  BAR_COUNTS,
  BAR_GLOWS,
  BAR_LOOK_KEY,
  BAR_MOTION,
  BAR_STYLES,
  BeatBars,
  DEFAULT_LOOK,
  MOTION_PLAIN,
  STYLE_PLAIN,
  readBarLook,
  type BarBoard,
  type BarLook,
  type BarStyle,
} from "@/components/beat-bars";
import { DeskNav } from "@/components/desk-nav";
import { Button } from "@/components/ui/button";
import {
  crateGet,
  crateListRecords,
  cratePut,
  underbedGet,
  underbedListRecords,
  type CrateRecord,
} from "@/lib/crate-db";
import { openAudio } from "@/lib/decode-audio";
import { encodeWav, lengthOf, makeClip, nextCrateName, safeStem, sliceClip, type Stereo } from "@/lib/audio-edit";
import {
  BAND_GUIDE,
  EQ_BANDS,
  EQ_Q,
  bandLabel,
  flatGains,
  normalizeGains,
  responseDb,
} from "@/lib/eq";
import { mergeDeskRecords } from "@/lib/underbed";
import { cn, displayTrackName } from "@/lib/utils";

function Ask({ open, onClick }: { open: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-expanded={open}
      aria-label="What this does"
      onClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
        onClick();
      }}
      className={cn(
        "inline-flex size-5 shrink-0 items-center justify-center rounded-full text-[11px] leading-none",
        open ? "bg-fg text-bg" : "text-muted ring-1 ring-white/20",
      )}
    >
      ?
    </button>
  );
}

const STYLE_NAME: Record<BarStyle, string> = {
  bars: "Bars",
  mirror: "Mirror",
  dots: "Dots",
  classic: "Classic",
  scope: "Scope",
  sparks: "Sparks",
  ribbon: "Ribbon",
  stairs: "Stairs",
};

const BOARD_NAME: Record<BarBoard, string> = {
  clean: "Clean",
  grid: "Grid",
  scan: "Scan",
};

function Fold({
  label,
  value,
  open,
  onToggle,
  note,
  children,
}: {
  label: string;
  value: string;
  open: boolean;
  onToggle: () => void;
  note: string;
  children: ReactNode;
}) {
  return (
    <div>
      <button
        type="button"
        aria-expanded={open}
        onClick={onToggle}
        className="flex w-full items-center justify-between rounded-lg bg-surface-2 px-3 py-2 text-left text-sm"
      >
        <span className="text-muted">{label}</span>
        <span className="font-medium text-fg">{value}</span>
      </button>
      {open && (
        <div className="mt-2 flex flex-col gap-2 px-1">
          <p className="text-xs text-muted">{note}</p>
          <div className="flex flex-wrap gap-2">{children}</div>
        </div>
      )}
    </div>
  );
}

type Graph = {
  ctx: AudioContext;
  audio: HTMLAudioElement;
  filters: BiquadFilterNode[];
  analyser: AnalyserNode;
};

function fromBuffer(buffer: AudioBuffer): Stereo {
  const channels: Float32Array[] = [];
  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(new Float32Array(buffer.getChannelData(i)));
  }
  return makeClip(channels, buffer.sampleRate);
}

async function renderEq(clip: Stereo, gains: number[]): Promise<Stereo> {
  const frames = lengthOf(clip);
  const offline = new OfflineAudioContext(Math.max(1, clip.channels.length), frames, clip.sampleRate);
  const buffer = offline.createBuffer(clip.channels.length || 1, frames, clip.sampleRate);
  clip.channels.forEach((ch, i) => buffer.getChannelData(i).set(ch));
  const source = offline.createBufferSource();
  source.buffer = buffer;
  let node: AudioNode = source;
  EQ_BANDS.forEach((freq, i) => {
    const filter = offline.createBiquadFilter();
    filter.type = "peaking";
    filter.frequency.value = freq;
    filter.Q.value = EQ_Q;
    filter.gain.value = gains[i] ?? 0;
    node.connect(filter);
    node = filter;
  });
  node.connect(offline.destination);
  source.start();
  return fromBuffer(await offline.startRendering());
}

export function EqualizerDesk() {
  const [records, setRecords] = useState<CrateRecord[]>([]);
  const [name, setName] = useState("");
  const [gains, setGains] = useState<number[]>(() => flatGains());
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [hint, setHint] = useState("");
  const [openGroup, setOpenGroup] = useState("");
  const [look, setLook] = useState<BarLook>(DEFAULT_LOOK);
  const graph = useRef<Graph | null>(null);
  const clipRef = useRef<Stereo | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const playerRef = useRef<HTMLAudioElement | null>(null);
  const [listenUrl, setListenUrl] = useState<string | null>(null);
  const gainsRef = useRef(gains);
  gainsRef.current = gains;

  const refreshRecords = async () => {
    const [crate, bed] = await Promise.all([crateListRecords(), underbedListRecords()]);
    setRecords(mergeDeskRecords(crate, bed));
  };

  useEffect(() => {
    void refreshRecords();
    setLook(readBarLook());
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const draw = () => {
      const width = canvas.clientWidth || 1;
      const height = canvas.clientHeight || 1;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const styles = getComputedStyle(canvas);
      ctx.fillStyle = styles.backgroundColor || "#1d2731";
      ctx.fillRect(0, 0, width, height);
      const fg = styles.color || "#eef3f7";
      const yFor = (db: number) => {
        const clamped = Math.max(-18, Math.min(18, db));
        return ((18 - clamped) / 36) * (height - 16) + 8;
      };
      ctx.globalAlpha = 0.2;
      ctx.strokeStyle = fg;
      ctx.beginPath();
      ctx.moveTo(0, yFor(0));
      ctx.lineTo(width, yFor(0));
      ctx.stroke();
      const curve = responseDb(
        gainsRef.current,
        clipRef.current?.sampleRate ?? 48000,
        Math.max(64, Math.round(width / 2)),
      );
      ctx.globalAlpha = 1;
      ctx.beginPath();
      curve.forEach((point, i) => {
        const x = (i / Math.max(1, curve.length - 1)) * width;
        const y = yFor(point.db);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.lineWidth = 2;
      ctx.strokeStyle = fg;
      ctx.stroke();
    };
    const raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [gains]);

  const applyGains = (next: number[]) => {
    normalizeGains(next).forEach((gain, i) => {
      const filter = graph.current?.filters[i];
      if (filter) filter.gain.value = gain;
    });
  };

  const ensureGraph = (audio: HTMLAudioElement) => {
    if (graph.current?.audio === audio) return graph.current;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    const source = ctx.createMediaElementSource(audio);
    const filters: BiquadFilterNode[] = [];
    let node: AudioNode = source;
    EQ_BANDS.forEach((freq, i) => {
      const filter = ctx.createBiquadFilter();
      filter.type = "peaking";
      filter.frequency.value = freq;
      filter.Q.value = EQ_Q;
      filter.gain.value = gainsRef.current[i] ?? 0;
      node.connect(filter);
      node = filter;
      filters.push(filter);
    });
    const analyser = ctx.createAnalyser();
    analyser.fftSize = lowEndDevice() ? 512 : 2048;
    analyser.smoothingTimeConstant = lowEndDevice() ? 0.6 : 0.45;
    analyser.minDecibels = -90;
    analyser.maxDecibels = -18;
    node.connect(analyser);
    analyser.connect(ctx.destination);
    graph.current = { ctx, audio, filters, analyser };
    return graph.current;
  };

  useEffect(() => {
    applyGains(gains);
  }, [gains]);

  const load = async (fileName: string) => {
    setError("");
    setPlaying(false);
    playerRef.current?.pause();
    const rec =
      records.find((row) => row.name === fileName) ??
      (await crateGet(fileName)) ??
      (await underbedGet(fileName));
    if (!rec) {
      setError("That song isn't stored on this phone.");
      return;
    }
    const url = URL.createObjectURL(rec.blob);
    setListenUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return url;
    });
    setName(fileName);
    void openAudio(rec.blob, rec.name)
      .then((opened) => {
        clipRef.current = fromBuffer(opened.buffer);
      })
      .catch(() => {
        clipRef.current = null;
      });
  };

  const arm = async () => {
    const audio = playerRef.current;
    if (!audio) return null;
    try {
      const live = ensureGraph(audio);
      await live.ctx.resume();
      return live;
    } catch {
      setError("This phone blocked the equalizer. Tap play once more.");
      return null;
    }
  };

  const toggle = async () => {
    const audio = playerRef.current;
    if (!audio || !listenUrl) return;
    if (!audio.paused) {
      audio.pause();
      setPlaying(false);
      return;
    }
    const live = await arm();
    if (!live) return;
    try {
      await audio.play();
      setPlaying(true);
    } catch {
      setError("Tap the player bar under the track list.");
    }
  };

  const changeLook = (patch: Partial<BarLook>) => {
    setLook((current) => {
      const next = { ...current, ...patch };
      localStorage.setItem(BAR_LOOK_KEY, JSON.stringify(next));
      return next;
    });
  };

  const save = async () => {
    const clip = clipRef.current;
    if (!clip) {
      toast.error("Pick a song and give it a second to load.");
      return;
    }
    setSaving(true);
    try {
      const shaped = await renderEq(clip, gains);
      const blob = encodeWav(shaped);
      const taken = new Set((await crateListRecords()).map((row) => row.name));
      const file = nextCrateName(`${safeStem(name || "needle")}_eq.wav`, taken);
      await cratePut({ name: file, size: blob.size, mtime: Date.now(), mime: "audio/wav", blob });
      await refreshRecords();
      toast.success(`${displayTrackName(file)} is in the crate.`);
    } catch {
      toast.error("Could not bake that curve.");
    } finally {
      setSaving(false);
    }
  };

  const ask = (id: string) => setHint((current) => (current === id ? "" : id));

  const cutFromPlayhead = async (seconds: number, tag: "hit" | "ring") => {
    const clip = clipRef.current;
    const audio = playerRef.current;
    if (!clip || !audio || !name) {
      toast.error("Pick a song and let it load.");
      return;
    }
    const start = Math.max(0, Math.floor(audio.currentTime * clip.sampleRate));
    const end = Math.min(lengthOf(clip), start + Math.floor(seconds * clip.sampleRate));
    if (end - start < clip.sampleRate * 0.2) {
      toast.error("Not enough song left from here.");
      return;
    }
    setSaving(true);
    try {
      const shaped = await renderEq(sliceClip(clip, start, end), gainsRef.current);
      const blob = encodeWav(shaped);
      const taken = new Set((await crateListRecords()).map((row) => row.name));
      const file = nextCrateName(`${safeStem(name)}_${tag}.wav`, taken);
      await cratePut({ name: file, size: blob.size, mtime: Date.now(), mime: "audio/wav", blob });
      await refreshRecords();
      toast.success(`${displayTrackName(file)} is on the board.`);
    } catch {
      toast.error("Could not cut that piece.");
    } finally {
      setSaving(false);
    }
  };

  const playPad = async (fileName: string) => {
    const rec = (await crateGet(fileName)) ?? (await underbedGet(fileName));
    if (!rec) return;
    playerRef.current?.pause();
    const url = URL.createObjectURL(rec.blob);
    const pad = new Audio(url);
    pad.onended = () => URL.revokeObjectURL(url);
    try {
      await pad.play();
    } catch {
      URL.revokeObjectURL(url);
      toast.error("Tap again to play that pad.");
    }
  };

  return (
    <main className="min-h-dvh overflow-x-hidden px-4 py-8 sm:px-8 sm:py-12">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-8">
        <header className="flex flex-col gap-3">
          <DeskNav current="eq" />
          <div className="flex items-end justify-between gap-4">
            <div>
              <h1 className="font-display text-4xl font-medium tracking-tight text-fg">Equalizer</h1>
              <p className="mt-2 max-w-xl text-sm text-muted">
                Up makes that part louder. Down makes it quieter. The middle is no change. You hear it while it plays.
              </p>
            </div>
            <SlidersHorizontal className="hidden size-8 text-muted sm:block" aria-hidden="true" />
          </div>
        </header>

        {records.length === 0 ? (
          <p className="rounded-xl bg-surface p-5 text-sm text-muted shadow-border">
            The crate is empty.{" "}
            <Link to="/press" className="text-fg underline">
              Pull a track
            </Link>{" "}
            first.
          </p>
        ) : (
          <div className="flex flex-wrap items-end gap-3">
            <label className="flex min-w-56 flex-1 flex-col gap-2 text-sm font-medium text-fg">
              Crate track
              <select
                className="h-11 rounded-md bg-surface px-3 text-fg shadow-border"
                value={name}
                onChange={(event) => void load(event.target.value)}
              >
                <option value="">Choose a file</option>
                {records.map((row) => (
                  <option key={row.name} value={row.name}>
                    {displayTrackName(row.name)}
                  </option>
                ))}
              </select>
            </label>
            <Button type="button" size="icon" aria-label={playing ? "Pause" : "Play"} disabled={!name} onClick={() => void toggle()}>
              {playing ? <Pause /> : <Play />}
            </Button>
          </div>
        )}

        <audio
          ref={playerRef}
          controls
          preload="auto"
          playsInline
          src={listenUrl ?? undefined}
          className="w-full"
          onPointerDown={() => void arm()}
          onPlay={() => {
            void arm();
            setPlaying(true);
          }}
          onPause={() => setPlaying(false)}
          onEnded={() => setPlaying(false)}
        />

        {error && <p className="rounded-lg bg-bad/15 px-3 py-2 text-sm text-bad">{error}</p>}

        <section className="flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-border sm:p-5">
          <h2 className="text-sm font-medium text-fg">Beat display</h2>
          <BeatBars
            playing={playing}
            look={look}
            getProbe={() => {
              const live = graph.current;
              return live ? { node: live.analyser, rate: live.ctx.sampleRate } : null;
            }}
          />
          <div className="flex flex-col gap-2 text-sm">
            <Fold
              label="How many"
              value={String(look.count)}
              open={openGroup === "count"}
              onToggle={() => setOpenGroup((current) => (current === "count" ? "" : "count"))}
              note="More lights, finer detail. Fewer lights, bigger jumps."
            >
              {BAR_COUNTS.map((count) => (
                <Button key={count} type="button" size="sm" variant={look.count === count ? "default" : "secondary"} onClick={() => changeLook({ count })}>
                  {count}
                </Button>
              ))}
            </Fold>
            <Fold
              label="Shape"
              value={STYLE_NAME[look.style]}
              open={openGroup === "style"}
              onToggle={() => setOpenGroup((current) => (current === "style" ? "" : "style"))}
              note={STYLE_PLAIN[look.style]}
            >
              {BAR_STYLES.map((style) => (
                <Button key={style} type="button" size="sm" variant={look.style === style ? "default" : "secondary"} onClick={() => changeLook({ style })}>
                  {STYLE_NAME[style]}
                </Button>
              ))}
            </Fold>
            <Fold
              label="Color"
              value={look.color}
              open={openGroup === "color"}
              onToggle={() => setOpenGroup((current) => (current === "color" ? "" : "color"))}
              note="The color of the lights."
            >
              {BAR_COLORS.map((color) => (
                <Button key={color} type="button" size="sm" variant={look.color === color ? "default" : "secondary"} onClick={() => changeLook({ color })}>
                  {color}
                </Button>
              ))}
            </Fold>
            <Fold
              label="Motion"
              value={look.motion}
              open={openGroup === "motion"}
              onToggle={() => setOpenGroup((current) => (current === "motion" ? "" : "motion"))}
              note={MOTION_PLAIN[look.motion]}
            >
              {BAR_MOTION.map((motion) => (
                <Button key={motion} type="button" size="sm" variant={look.motion === motion ? "default" : "secondary"} onClick={() => changeLook({ motion })}>
                  {motion}
                </Button>
              ))}
            </Fold>
            <Fold
              label="Glow"
              value={look.glow}
              open={openGroup === "glow"}
              onToggle={() => setOpenGroup((current) => (current === "glow" ? "" : "glow"))}
              note="Off is plain. Soft is a halo. Hot blooms on the loud parts."
            >
              {BAR_GLOWS.map((glow) => (
                <Button key={glow} type="button" size="sm" variant={look.glow === glow ? "default" : "secondary"} onClick={() => changeLook({ glow })}>
                  {glow}
                </Button>
              ))}
            </Fold>
            <Fold
              label="Board"
              value={BOARD_NAME[look.board]}
              open={openGroup === "board"}
              onToggle={() => setOpenGroup((current) => (current === "board" ? "" : "board"))}
              note="Clean is flat. Grid is graph paper. Scan is a line that sweeps down."
            >
              {BAR_BOARDS.map((board) => (
                <Button key={board} type="button" size="sm" variant={look.board === board ? "default" : "secondary"} onClick={() => changeLook({ board })}>
                  {BOARD_NAME[board]}
                </Button>
              ))}
            </Fold>
          </div>
        </section>

        <section className="flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-border sm:p-5">
          <h2 className="text-sm font-medium text-fg">Sound board</h2>
          <p className="text-sm text-muted">Cuts from where the song is playing, with the equalizer already on it.</p>
          <div className="flex flex-wrap gap-2">
            <Button type="button" size="sm" variant="secondary" disabled={!name || saving} onClick={() => void cutFromPlayhead(3, "hit")}>
              3s hit
            </Button>
            <Button type="button" size="sm" variant="secondary" disabled={!name || saving} onClick={() => void cutFromPlayhead(10, "hit")}>
              10s clip
            </Button>
            <Button type="button" size="sm" variant="secondary" disabled={!name || saving} onClick={() => void cutFromPlayhead(30, "ring")}>
              30s ringtone
            </Button>
          </div>
          {records.some((row) => /_(hit|ring)(?:_|$)/.test(row.name)) && (
            <div className="flex flex-wrap gap-2">
              {records
                .filter((row) => /_(hit|ring)(?:_|$)/.test(row.name))
                .map((row) => (
                  <Button key={row.name} type="button" size="sm" variant="secondary" onClick={() => void playPad(row.name)}>
                    {displayTrackName(row.name)}
                  </Button>
                ))}
            </div>
          )}
        </section>

        <section className="flex flex-col gap-5 rounded-xl bg-surface p-4 shadow-border sm:p-5">
          <canvas ref={canvasRef} className="h-44 w-full rounded-lg bg-surface-2 text-fg sm:h-56" aria-label="Equalizer curve" />
          {hint.startsWith("band:") && (
            <p className="text-sm text-fg">{BAND_GUIDE[Number(hint.slice(5))]?.plain}</p>
          )}
          <div className="flex gap-1 overflow-x-auto pb-1">
            {EQ_BANDS.map((freq, index) => (
              <div key={freq} className="flex min-w-14 flex-1 flex-col items-center gap-2">
                <span className="font-mono text-xs text-muted">
                  {(gains[index] ?? 0) > 0 ? `+${gains[index]}` : gains[index]}
                </span>
                <input
                  className="fader"
                  type="range"
                  min={-12}
                  max={12}
                  step={0.5}
                  value={gains[index] ?? 0}
                  aria-label={`${BAND_GUIDE[index]?.name ?? bandLabel(freq)}`}
                  onChange={(event) => {
                    const value = Number(event.target.value);
                    setGains((current) => current.map((gain, i) => (i === index ? value : gain)));
                  }}
                />
                <span className="inline-flex items-center gap-1 text-[11px] text-subtle">
                  {BAND_GUIDE[index]?.name}
                  <Ask open={hint === `band:${index}`} onClick={() => ask(`band:${index}`)} />
                </span>
              </div>
            ))}
          </div>
          <div>
            <Button type="button" disabled={!name || saving} onClick={() => void save()}>
              Save shaped audio
            </Button>
          </div>
        </section>
      </div>
    </main>
  );
}
