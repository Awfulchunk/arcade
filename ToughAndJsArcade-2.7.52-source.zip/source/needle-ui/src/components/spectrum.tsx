import { cn } from "@/lib/utils";

export function Spectrum({
  bands,
  active,
}: {
  bands: number[];
  active: boolean;
}) {
  return (
    <div className="flex h-8 items-end gap-0.5" aria-hidden="true">
      {bands.map((value, index) => (
        <span
          key={index}
          className={cn(
            "w-1 origin-bottom rounded-full bg-accent",
            "transition-transform duration-quick ease-smooth",
          )}
          style={{
            height: "100%",
            transform: `scaleY(${active ? Math.max(0.12, value) : 0.12})`,
            opacity: active ? 0.95 : 0.35,
          }}
        />
      ))}
    </div>
  );
}
