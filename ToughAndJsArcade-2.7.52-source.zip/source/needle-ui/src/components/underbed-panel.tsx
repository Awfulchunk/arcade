import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  crateListRecords,
  crateRemove,
  underbedClear,
  underbedListRecords,
  underbedRemove,
  type CrateRecord,
} from "@/lib/crate-db";
import { deleteLibraryFile } from "@/lib/pull.functions";
import { saveBlobFile } from "@/lib/download-files";
import { archiveMissingFromCrate, copiesToDrop, type PlacedFile } from "@/lib/underbed";
import { displayTrackName } from "@/lib/utils";

async function eraseEverywhere(names: string[]) {
  for (const name of names) {
    await underbedRemove(name).catch(() => undefined);
    await crateRemove(name).catch(() => undefined);
    await deleteLibraryFile({ data: { name } }).catch(() => undefined);
  }
}

export function UnderbedPanel() {
  const [rows, setRows] = useState<CrateRecord[]>([]);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [copies, setCopies] = useState<PlacedFile[] | null>(null);
  const [confirmAll, setConfirmAll] = useState(false);

  const refresh = async () => {
    await archiveMissingFromCrate().catch(() => 0);
    setRows(await underbedListRecords());
  };

  useEffect(() => {
    void refresh();
  }, []);

  const download = (list: CrateRecord[]) => {
    for (const row of list) saveBlobFile(row.blob, row.name);
  };

  const dropCopies = async () => {
    if (!copies) return;
    for (const file of copies) {
      if (file.place === "underbed") await eraseEverywhere([file.name]);
      else await crateRemove(file.name).catch(() => undefined);
    }
    setCopies(null);
    setPicked(new Set());
    await refresh();
    toast.success("Copies removed.");
  };

  const allPicked = rows.length > 0 && picked.size === rows.length;
  const selected = rows.filter((row) => picked.has(row.name));

  return (
    <div className="flex flex-col gap-3">
      <div>
        <p className="text-sm font-medium text-fg">Underbed</p>
        <p className="text-xs text-muted">
          A copy of every song pulled in Press. Deleting it here removes it from the whole app.
        </p>
      </div>
      {rows.length === 0 ? (
        <p className="text-xs text-muted">Nothing stored.</p>
      ) : (
        <ul className="flex max-h-64 flex-col gap-1 overflow-y-auto">
          {rows.map((row) => (
            <li key={row.name}>
              <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
                <input
                  type="checkbox"
                  className="size-4 accent-accent"
                  checked={picked.has(row.name)}
                  onChange={() => {
                    setPicked((current) => {
                      const next = new Set(current);
                      if (next.has(row.name)) next.delete(row.name);
                      else next.add(row.name);
                      return next;
                    });
                  }}
                />
                <span className="truncate">{displayTrackName(row.name)}</span>
              </label>
            </li>
          ))}
        </ul>
      )}
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          size="sm"
          variant="secondary"
          disabled={rows.length === 0}
          onClick={() => setPicked(allPicked ? new Set() : new Set(rows.map((row) => row.name)))}
        >
          {allPicked ? "Clear" : "Select all"}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="secondary"
          disabled={rows.length === 0}
          onClick={() => download(selected.length > 0 ? selected : rows)}
        >
          Download all
        </Button>
        <Button
          type="button"
          size="sm"
          variant="destructive"
          disabled={rows.length === 0}
          onClick={() => {
            if (!confirmAll) {
              setConfirmAll(true);
              window.setTimeout(() => setConfirmAll(false), 4000);
              return;
            }
            setConfirmAll(false);
            void eraseEverywhere(rows.map((row) => row.name)).then(async () => {
              await underbedClear().catch(() => undefined);
              setPicked(new Set());
              await refresh();
              toast.success("Underbed cleared.");
            });
          }}
        >
          {confirmAll ? "Confirm" : "Delete all"}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          disabled={selected.length === 0}
          onClick={() => {
            void eraseEverywhere(selected.map((row) => row.name)).then(async () => {
              setPicked(new Set());
              await refresh();
            });
          }}
        >
          Delete selected
        </Button>
        <Button
          type="button"
          size="sm"
          variant="secondary"
          onClick={() => {
            void (async () => {
              const [crate, bed] = await Promise.all([crateListRecords(), underbedListRecords()]);
              const hits = copiesToDrop([
                ...crate.map((row) => ({ name: row.name, mtime: row.mtime || 0, place: "crate" as const })),
                ...bed.map((row) => ({ name: row.name, mtime: row.mtime || 0, place: "underbed" as const })),
              ]);
              if (hits.length === 0) {
                setCopies(null);
                toast.success("No copies.");
                return;
              }
              setCopies(hits);
            })();
          }}
        >
          Find copies
        </Button>
      </div>
      {copies && copies.length > 0 && (
        <div className="rounded-lg bg-surface-2 p-3 shadow-border">
          <p className="text-sm text-fg">{copies.length} copies. The kept file stays in Underbed.</p>
          <ul className="mt-2 space-y-1 text-xs text-muted">
            {copies.slice(0, 8).map((file) => (
              <li key={`${file.place}:${file.name}`}>
                {file.place === "crate" ? "Crate" : "Underbed"} · {displayTrackName(file.name)}
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <Button type="button" size="sm" variant="destructive" onClick={() => void dropCopies()}>
              Delete copies
            </Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setCopies(null)}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
