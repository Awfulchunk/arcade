import { lowEndDevice } from "@/lib/low-end";
import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Download, Pause, Play, Redo2, Scissors, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { DeskNav } from "@/components/desk-nav";
import { WaveCanvas } from "@/components/wave-canvas";
import { Button } from "@/components/ui/button";
import { crateGet, crateListRecords, cratePut, underbedGet, underbedListRecords, type CrateRecord } from "@/lib/crate-db";
import { openAudio } from "@/lib/decode-audio";
import { mergeDeskRecords } from "@/lib/underbed";
import {
  dbToGain,
  encodeWav,
  formatPrecise,
  formatWindow,
  lengthOf,
  makeClip,
  nextCrateName,
  safeStem,
  sessionCopy,
  sessionCrop,
  sessionCut,
  sessionFade,
  sessionFrom,
  sessionGain,
  sessionPaste,
  sessionRedo,
  sessionUndo,
  type Session,
  type Stereo,
} from "@/lib/audio-edit";
import { displayTrackName } from "@/lib/utils";

const MAX_SECONDS = 20 * 60;

const PRESET_KEY = "needle-cut-presets";
const PIN_KEY = "needle-cut-pins";

type SavedSel = { id: string; track: string; start: number; end: number };
type Pin = { id: string; track: string; start: number; end: number };

function loadPins(): Pin[] {
  try {
    const raw = JSON.parse(localStorage.getItem(PIN_KEY) || "[]") as Pin[];
    if (!Array.isArray(raw)) return [];
    return raw.filter((row) => row && typeof row.start === "number");
  } catch {
    return [];
  }
}

function formatMs(samples: number, sampleRate: number): string {
  if (sampleRate <= 0) return "0:00.000";
  const msTotal = Math.max(0, Math.round((samples / sampleRate) * 1000));
  const m = Math.floor(msTotal / 60000);
  const s = Math.floor((msTotal % 60000) / 1000);
  const ms = msTotal % 1000;
  return `${m}:${s.toString().padStart(2, "0")}.${ms.toString().padStart(3, "0")}`;
}

function loadPresets(): SavedSel[] {
  try {
    const raw = JSON.parse(localStorage.getItem(PRESET_KEY) || "[]") as SavedSel[];
    if (!Array.isArray(raw)) return [];
    return raw.filter((row) => row && typeof row.start === "number" && typeof row.end === "number");
  } catch {
    return [];
  }
}

type Graph = {
  ctx: AudioContext;
  source: AudioBufferSourceNode | null;
  started: number;
  offset: number;
  stopAt: number;
  looping: boolean;
  loopFrom: number;
};

function fromBuffer(buffer: AudioBuffer): Stereo {
  const channels: Float32Array[] = [];
  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(new Float32Array(buffer.getChannelData(i)));
  }
  return makeClip(channels, buffer.sampleRate);
}

export function CutterDesk() {
  const [records, setRecords] = useState<CrateRecord[]>([]);
  const [name, setName] = useState("");
  const [session, setSession] = useState<Session | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [mode, setMode] = useState<"select" | "pan">("select");
  const [viewStart, setViewStart] = useState(0);
  const [viewSpan, setViewSpan] = useState(1);
  const [cursor, setCursor] = useState(0);
  const [selection, setSelection] = useState<{ start: number; end: number } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [listenUrl, setListenUrl] = useState<string | null>(null);
  const [gainDb, setGainDb] = useState(0);
  const [loopOn, setLoopOn] = useState(false);
  const [marksOn, setMarksOn] = useState(false);
  const [presets, setPresets] = useState<SavedSel[]>([]);
  const [pins, setPins] = useState<Pin[]>([]);
  const [presetId, setPresetId] = useState("");
  const selectionRef = useRef<{ start: number; end: number } | null>(null);
  const anchor = useRef(0);
  const dragging = useRef(false);
  const pan = useRef({ ratio: 0, viewStart: 0, span: 1 });
  const graph = useRef<Graph | null>(null);
  const sessionRef = useRef<Session | null>(null);
  const viewRef = useRef({ viewStart, viewSpan, mode });
  const stageRef = useRef<HTMLDivElement | null>(null);
  const edgeTimer = useRef(0);
  const markDrag = useRef<"start" | "end" | null>(null);
  const loopRef = useRef(false);
  const zoomedAt = useRef(0);
  sessionRef.current = session;
  selectionRef.current = selection;
  viewRef.current = { viewStart, viewSpan, mode };
  loopRef.current = loopOn;

  const refreshRecords = async () => {
    const [crate, bed] = await Promise.all([crateListRecords(), underbedListRecords()]);
    setRecords(mergeDeskRecords(crate, bed));
  };

  useEffect(() => {
    void refreshRecords();
    setPresets(loadPresets());
    setPins(loadPins());
  }, []);

  const stop = () => {
    const g = graph.current;
    if (!g) return;
    try {
      g.source?.stop();
    } catch {
      /* already stopped */
    }
    g.source = null;
    setPlaying(false);
  };

  const ensureGraph = () => {
    if (!graph.current) {
      graph.current = {
        ctx: new AudioContext(),
        source: null,
        started: 0,
        offset: 0,
        stopAt: Number.POSITIVE_INFINITY,
        looping: false,
        loopFrom: 0,
      };
    }
    return graph.current;
  };

  useEffect(() => () => {
    try {
      graph.current?.source?.stop();
    } catch {
      /* closed */
    }
    void graph.current?.ctx.close();
  }, []);

  useEffect(() => {
    if (!playing || !session) return;
    let frame = 0;
    let lastT = 0;
    const gap = lowEndDevice() ? 50 : 33;
    const tick = (now: number) => {
      if (now - lastT < gap) {
        frame = requestAnimationFrame(tick);
        return;
      }
      lastT = now;
      const g = graph.current;
      const current = sessionRef.current;
      if (!g?.source || !current) return;
      const rate = current.clip.sampleRate;
      const sample = Math.round((g.offset + g.ctx.currentTime - g.started) * rate);
      if (dragging.current) {
        frame = requestAnimationFrame(tick);
        return;
      }
      if (g.looping) {
        const span = Math.max(1, g.stopAt - g.loopFrom);
        const elapsed = sample - g.loopFrom;
        const wrapped = g.loopFrom + ((elapsed % span) + span) % span;
        setCursor(wrapped);
        frame = requestAnimationFrame(tick);
        return;
      }
      if (sample >= g.stopAt) {
        stop();
        setCursor(Math.min(g.stopAt, lengthOf(current.clip)));
        return;
      }
      setCursor(sample);
      setViewStart((start) => {
        const span = viewRef.current.viewSpan;
        const len = lengthOf(current.clip);
        if (g.looping) return start;
        if (performance.now() - zoomedAt.current < 900) return start;
        const edge = start + span * 0.8;
        if (sample < edge && sample > start) return start;
        const next = sample > edge ? start + span * 0.12 : start;
        return Math.max(0, Math.min(next, Math.max(0, len - span)));
      });
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, session]);

  const load = async (fileName: string) => {
    setLoading(true);
    setError("");
    stop();
    const rec =
      records.find((row) => row.name === fileName) ??
      (await crateGet(fileName)) ??
      (await underbedGet(fileName));
    if (!rec) {
      setError("That song isn't stored on this phone.");
      setLoading(false);
      return;
    }
    if (listenUrl) URL.revokeObjectURL(listenUrl);
    const url = URL.createObjectURL(rec.blob);
    setListenUrl(url);
    setName(fileName);
    try {
      const { buffer } = await openAudio(rec.blob, rec.name);
      if (buffer.duration > MAX_SECONDS) {
        throw new Error("long");
      }
      const clip = fromBuffer(buffer);
      const n = Math.max(1, lengthOf(clip));
      setSession(sessionFrom(clip));
      setName(fileName);
      setViewStart(0);
      setViewSpan(n);
      setCursor(0);
      setSelection(null);
      setGainDb(0);
    } catch (err) {
      setSession(null);
      setError(
        err instanceof Error && err.message === "long"
          ? "Too long to cut here. Keep it under 20 minutes. You can still play it below."
          : "The wave couldn't be built. You can still play the song below.",
      );
    } finally {
      setLoading(false);
    }
  };

  const zoomAt = (ratio: number, factor: number) => {
    const current = sessionRef.current;
    if (!current) return;
    const n = Math.max(1, lengthOf(current.clip));
    const minSpan = Math.min(n, Math.max(32, Math.round(current.clip.sampleRate * 0.008)));
    const span = viewRef.current.viewSpan;
    const start = viewRef.current.viewStart;
    const focus = start + ratio * span;
    const next = Math.max(minSpan, Math.min(n, span * factor));
    let origin = focus - ratio * next;
    if (origin < 0) origin = 0;
    if (origin + next > n) origin = Math.max(0, n - next);
    zoomedAt.current = performance.now();
    setViewStart(origin);
    setViewSpan(next);
  };

  const zoomToSample = (sample: number) => {
    const current = sessionRef.current;
    if (!current) return;
    const len = Math.max(1, lengthOf(current.clip));
    const windowSamples = Math.min(len, Math.max(Math.round(current.clip.sampleRate * 0.4), 64));
    const origin = Math.max(0, Math.min(sample - windowSamples / 2, Math.max(0, len - windowSamples)));
    zoomedAt.current = performance.now();
    setViewStart(origin);
    setViewSpan(windowSamples);
  };

  const onGesture = (gesture: { type: string; sample: number; ratio: number; factor: number }) => {
    const current = sessionRef.current;
    if (!current) return;
    if (gesture.type === "wheel" || gesture.type === "pinch") {
      zoomAt(gesture.ratio, gesture.factor);
      return;
    }
    if (gesture.type === "cancel") {
      dragging.current = false;
      window.clearInterval(edgeTimer.current);
      return;
    }
    const n = lengthOf(current.clip);
    const sample = Math.max(0, Math.min(n, gesture.sample));
    if (viewRef.current.mode === "pan") {
      if (gesture.type === "down") {
        pan.current = { ratio: gesture.ratio, viewStart: viewRef.current.viewStart, span: viewRef.current.viewSpan };
      }
      const grabbed = pan.current.viewStart + pan.current.ratio * pan.current.span;
      let origin = grabbed - gesture.ratio * pan.current.span;
      origin = Math.max(0, Math.min(origin, Math.max(0, n - pan.current.span)));
      setViewStart(origin);
      return;
    }
    if (gesture.type === "down") {
      if (viewRef.current.mode === "select" && marksOn) {
        pan.current = { ratio: gesture.ratio, viewStart: viewRef.current.viewStart, span: viewRef.current.viewSpan };
        return;
      }
      dragging.current = true;
      const existing = selectionRef.current;
      const span = viewRef.current.viewSpan;
      if (existing && existing.end > existing.start && sample >= existing.start - span * 0.04) {
        anchor.current = existing.start;
        setCursor(sample);
        setSelection({ start: existing.start, end: Math.max(existing.start + 1, sample) });
        return;
      }
      anchor.current = sample;
      setCursor(sample);
      setSelection({ start: sample, end: sample });
      return;
    }
    if (viewRef.current.mode === "select" && marksOn && !dragging.current) {
      const grabbed = pan.current.viewStart + pan.current.ratio * pan.current.span;
      let origin = grabbed - gesture.ratio * pan.current.span;
      origin = Math.max(0, Math.min(origin, Math.max(0, n - pan.current.span)));
      setViewStart(origin);
      return;
    }
    if (gesture.type === "move" && dragging.current) {
      setSelection({ start: anchor.current, end: sample });
      setCursor(sample);
      scrubEdge(gesture.ratio);
      return;
    }
    if (gesture.type === "up") {
      dragging.current = false;
      window.clearInterval(edgeTimer.current);
      if (marksOn) return;
      const pixel = viewRef.current.viewSpan / 480;
      if (Math.abs(sample - anchor.current) < pixel * 3) {
        setCursor(sample);
        return;
      }
      const start = Math.min(anchor.current, sample);
      const end = Math.max(anchor.current, sample);
      setSelection({ start, end });
      setCursor(end);
    }
  };

  const scrubEdge = (ratio: number) => {
    window.clearInterval(edgeTimer.current);
    if (ratio > 0.12 && ratio < 0.88) return;
    const dir = ratio >= 0.88 ? 1 : -1;
    edgeTimer.current = window.setInterval(() => {
      const current = sessionRef.current;
      if (!current) return;
      const len = lengthOf(current.clip);
      const span = viewRef.current.viewSpan;
      setViewStart((start) => {
        const next = Math.max(0, Math.min(start + dir * span * 0.08, Math.max(0, len - span)));
        if (dragging.current) {
          const edge = dir > 0 ? Math.min(len, next + span) : next;
          setSelection({ start: anchor.current, end: edge });
          setCursor(edge);
        } else if (markDrag.current) {
          const edge = dir > 0 ? Math.min(len, next + span) : next;
          const which = markDrag.current;
          setSelection((prev) => {
            if (!prev) return prev;
            const a = Math.min(prev.start, prev.end);
            const b = Math.max(prev.start, prev.end);
            if (which === "start") return { start: Math.max(0, Math.min(edge, b - 1)), end: b };
            return { start: a, end: Math.max(a + 1, Math.min(len, edge)) };
          });
        }
        return next;
      });
    }, 40);
  };

  const fitView = (start: number, end: number) => {
    const current = sessionRef.current;
    if (!current) return;
    const len = Math.max(1, lengthOf(current.clip));
    const pad = Math.max(current.clip.sampleRate * 0.05, (end - start) * 0.2);
    const span = Math.min(len, Math.max(end - start + pad * 2, 32));
    setViewSpan(span);
    setViewStart(Math.max(0, Math.min(start - pad, Math.max(0, len - span))));
  };

  const playFrom = async (sample: number, stopAt?: number) => {
    const current = sessionRef.current;
    if (!current || lengthOf(current.clip) === 0) return;
    const g = ensureGraph();
    await g.ctx.resume();
    try {
      g.source?.stop();
    } catch {
      /* already stopped */
    }
    const clip = current.clip;
    const buffer = g.ctx.createBuffer(clip.channels.length || 1, lengthOf(clip), clip.sampleRate);
    clip.channels.forEach((ch, i) => buffer.getChannelData(i).set(ch));
    const source = g.ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(g.ctx.destination);
    const offset = Math.max(0, sample) / clip.sampleRate;
    const looping = loopRef.current && stopAt !== undefined && stopAt > sample;
    if (looping && stopAt !== undefined) {
      source.loop = true;
      source.loopStart = offset;
      source.loopEnd = stopAt / clip.sampleRate;
    }
    source.start(0, offset);
    g.source = source;
    g.started = g.ctx.currentTime;
    g.offset = offset;
    g.stopAt = stopAt ?? lengthOf(clip);
    g.looping = looping;
    g.loopFrom = sample;
    source.onended = () => {
      if (graph.current?.source === source) setPlaying(false);
    };
    setPlaying(true);
    setCursor(sample);
  };

  const sel = selection
    ? { start: Math.min(selection.start, selection.end), end: Math.max(selection.start, selection.end) }
    : null;
  const hasSel = !!sel && sel.end > sel.start;

  const edit = (next: Session | null) => {
    if (!next || next === session) return;
    stop();
    setSession(next);
    const n = lengthOf(next.clip);
    setViewSpan((span) => Math.min(Math.max(span, 1), Math.max(1, n)));
    setViewStart((start) => Math.max(0, Math.min(start, Math.max(0, n - 1))));
  };

  const nudge = (edge: "start" | "end" | "cursor", samples: number) => {
    if (!session) return;
    const n = lengthOf(session.clip);
    const step = samples;
    if (edge === "cursor" || !sel) {
      setCursor((value) => Math.max(0, Math.min(n, value + step)));
      return;
    }
    setSelection({
      start: edge === "start" ? Math.max(0, Math.min(sel.end - 1, sel.start + step)) : sel.start,
      end: edge === "end" ? Math.max(sel.start + 1, Math.min(n, sel.end + step)) : sel.end,
    });
  };

  const save = async (download: boolean) => {
    if (!session) return;
    setSaving(true);
    try {
      const blob = encodeWav(session.clip);
      const taken = new Set((await crateListRecords()).map((row) => row.name));
      const file = nextCrateName(`${safeStem(name || "needle")}_cut.wav`, taken);
      await cratePut({
        name: file,
        size: blob.size,
        mtime: Date.now(),
        mime: "audio/wav",
        blob,
      });
      if (download) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = file;
        link.click();
        URL.revokeObjectURL(url);
      }
      setRecords(await crateListRecords());
      toast.success(`${displayTrackName(file)} is in the crate.`);
    } catch {
      toast.error("Could not save that cut.");
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) return;
      const current = sessionRef.current;
      if (!current) return;
      const meta = event.metaKey || event.ctrlKey;
      if (event.code === "Space") {
        event.preventDefault();
        if (graph.current?.source) stop();
        else void playFrom(cursor);
      } else if (meta && event.key.toLowerCase() === "z") {
        event.preventDefault();
        edit(event.shiftKey ? sessionRedo(current) : sessionUndo(current));
      } else if (meta && event.key.toLowerCase() === "c" && sel) {
        const current = sessionRef.current;
        if (current) setSession(sessionCopy(current, sel.start, sel.end));
      } else if (meta && event.key.toLowerCase() === "x" && sel) {
        event.preventDefault();
        const at = sel.start;
        edit(sessionCut(current, sel.start, sel.end));
        setSelection(null);
        setCursor(at);
      } else if (meta && event.key.toLowerCase() === "v") {
        event.preventDefault();
        edit(sessionPaste(current, cursor, sel));
        setSelection(null);
      } else if ((event.key === "Delete" || event.key === "Backspace") && sel) {
        event.preventDefault();
        const at = sel.start;
        edit(sessionCut(current, sel.start, sel.end));
        setSelection(null);
        setCursor(at);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cursor, sel]);

  const rate = session?.clip.sampleRate ?? 44100;
  const n = session ? lengthOf(session.clip) : 0;
  const pixelStep = Math.max(1, Math.round(viewSpan / 400));
  const step10 = Math.max(1, Math.round(rate * 0.01));

  const focusRatio = () => {
    if (!sel) return 0.5;
    const span = viewRef.current.viewSpan || 1;
    const mid = (sel.start + sel.end) / 2;
    return Math.min(1, Math.max(0, (mid - viewRef.current.viewStart) / span));
  };

  const toggleMarks = () => {
    if (marksOn) {
      setMarksOn(false);
      return;
    }
    if (!hasSel) {
      const a = Math.round(viewStart + viewSpan * 0.25);
      const b = Math.max(a + 1, Math.round(viewStart + viewSpan * 0.75));
      setSelection({ start: Math.max(0, a), end: Math.min(n, b) });
    }
    setMarksOn(true);
  };

  const moveMark = (edge: "start" | "end", clientX: number) => {
    const current = sessionRef.current;
    if (!current || !sel) return;
    const len = lengthOf(current.clip);
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    const ratio = rect.width <= 0 ? 0 : Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    const sample = Math.max(0, Math.min(len, Math.round(viewRef.current.viewStart + ratio * viewRef.current.viewSpan)));
    markDrag.current = edge;
    scrubEdge(ratio);
    if (edge === "start") setSelection({ start: Math.max(0, Math.min(sample, sel.end - 1)), end: sel.end });
    else setSelection({ start: sel.start, end: Math.max(sel.start + 1, Math.min(len, sample)) });
  };

  const releaseMark = () => {
    markDrag.current = null;
    window.clearInterval(edgeTimer.current);
  };

  const writePins = (next: Pin[]) => {
    setPins(next);
    localStorage.setItem(PIN_KEY, JSON.stringify(next));
  };

  const dropPin = () => {
    if (!name || !session) return;
    const start = hasSel && sel ? sel.start : cursor;
    const end = hasSel && sel ? sel.end : start;
    const row: Pin = { id: crypto.randomUUID(), track: name, start, end };
    writePins([row, ...pins.filter((item) => item.track !== name || Math.abs(item.start - start) > 8)].slice(0, 30));
    toast.success("Pinned. It stays until you delete it.");
  };

  const deletePin = (id: string) => {
    writePins(pins.filter((item) => item.id !== id));
  };

  const rememberPreset = () => {
    if (!sel || !name) return;
    const row: SavedSel = { id: crypto.randomUUID(), track: name, start: sel.start, end: sel.end };
    const next = [row, ...presets.filter((item) => item.id !== row.id)].slice(0, 24);
    setPresets(next);
    setPresetId(row.id);
    localStorage.setItem(PRESET_KEY, JSON.stringify(next));
    toast.success("Selection saved.");
  };

  const recallPreset = (id: string) => {
    setPresetId(id);
    const row = presets.find((item) => item.id === id);
    const current = sessionRef.current;
    if (!row || !current) return;
    const len = lengthOf(current.clip);
    const start = Math.max(0, Math.min(len - 1, Math.round(row.start)));
    const end = Math.max(start + 1, Math.min(len, Math.round(row.end)));
    setSelection({ start, end });
    setMarksOn(true);
    setCursor(start);
    fitView(start, end);
  };

  return (
    <main className="min-h-dvh overflow-x-hidden px-4 py-8 sm:px-8 sm:py-12">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-8">
        <header className="flex flex-col gap-3">
          <DeskNav current="cut" />
          <div className="flex items-end justify-between gap-4">
            <div>
              <h1 className="font-display text-4xl font-medium tracking-tight text-fg">Cut</h1>
              <p className="mt-2 max-w-xl text-sm text-muted">
                Zoom until the window is a few milliseconds. Drag a region, then cut, copy, or paste it.
              </p>
            </div>
            <Scissors className="hidden size-8 text-muted sm:block" aria-hidden="true" />
          </div>
        </header>

        {records.length === 0 ? (
          <p className="rounded-xl bg-surface p-5 text-sm text-muted shadow-border">
            The crate is empty.{" "}
            <Link to="/press" className="text-fg underline">
              Pull a track
            </Link>{" "}
            first.
          </p>
        ) : (
          <label className="flex flex-col gap-2 text-sm font-medium text-fg">
            Crate track
            <select
              className="h-11 rounded-md bg-surface px-3 text-fg shadow-border"
              value={name}
              onChange={(event) => void load(event.target.value)}
            >
              <option value="">Choose a file</option>
              {records.map((row) => (
                <option key={row.name} value={row.name}>
                  {displayTrackName(row.name)}
                </option>
              ))}
            </select>
          </label>
        )}

        {loading && <p className="text-sm text-muted">Reading audio…</p>}
        {listenUrl && !session && (
          <audio key={listenUrl} controls preload="auto" playsInline src={listenUrl} className="w-full" />
        )}
        {error && <p className="rounded-lg bg-bad/15 px-3 py-2 text-sm text-bad">{error}</p>}

        {session && (
          <section className="flex flex-col gap-3 rounded-xl bg-surface p-3 shadow-border sm:p-4">
            <div className="flex items-center gap-2 overflow-x-auto">
              <Button
                type="button"
                size="icon"
                aria-label={playing ? "Pause" : "Play"}
                onClick={() => {
                  if (playing) stop();
                  else if (loopOn && hasSel && sel) {
                    fitView(sel.start, sel.end);
                    void playFrom(sel.start, sel.end);
                  } else void playFrom(cursor);
                }}
              >
                {playing ? <Pause /> : <Play />}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="secondary"
                disabled={!hasSel}
                onClick={() => {
                  if (!sel) return;
                  fitView(sel.start, sel.end);
                  void playFrom(sel.start, sel.end);
                }}
              >
                Play selection
              </Button>
              <Button type="button" size="sm" variant={loopOn ? "default" : "secondary"} aria-pressed={loopOn} onClick={() => setLoopOn((on) => !on)}>
                Loop
              </Button>
              <Button type="button" size="sm" variant={mode === "select" ? "default" : "secondary"} onClick={() => setMode("select")}>
                Select
              </Button>
              <Button type="button" size="sm" variant={mode === "pan" ? "default" : "secondary"} onClick={() => setMode("pan")}>
                Pan
              </Button>
              <span className="shrink-0 font-mono text-xs text-fg">{formatMs(cursor, rate)}</span>
            </div>

            <div className="flex items-stretch gap-2">
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <div
                  className="relative h-10 rounded-md bg-surface-2"
                  onClick={(event) => {
                    const rect = event.currentTarget.getBoundingClientRect();
                    const ratio = rect.width <= 0 ? 0 : Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
                    const sample = Math.round(viewStart + ratio * viewSpan);
                    setCursor(Math.max(0, Math.min(n, sample)));
                  }}
                  aria-label="Song time in milliseconds"
                >
                  {rulerTicks(viewStart, viewSpan, rate).map((tick) => (
                    <span
                      key={tick.sample}
                      className="pointer-events-none absolute top-0 flex -translate-x-1/2 flex-col items-center"
                      style={{ left: `${tick.ratio * 100}%` }}
                    >
                      <span className="h-2 w-px bg-[#e4b23c]" />
                      <span className="font-mono text-[10px] leading-3 text-[#e4b23c]">{tick.label}</span>
                    </span>
                  ))}
                  {pins
                    .filter((pin) => pin.track === name)
                    .map((pin) => {
                      const ratio = (pin.start - viewStart) / viewSpan;
                      if (ratio < 0 || ratio > 1) return null;
                      return (
                        <button
                          key={pin.id}
                          type="button"
                          className="absolute bottom-0 z-10 size-3 -translate-x-1/2 rounded-full bg-[#e4b23c]"
                          style={{ left: `${ratio * 100}%` }}
                          aria-label={`Go to pin ${formatMs(pin.start, rate)}`}
                          onClick={(event) => {
                            event.stopPropagation();
                            zoomToSample(pin.start);
                            setCursor(pin.start);
                          }}
                        />
                      );
                    })}
                  <span
                    className="pointer-events-none absolute inset-y-0 w-px bg-fg"
                    style={{ left: `${Math.min(100, Math.max(0, ((cursor - viewStart) / Math.max(1, viewSpan)) * 100))}%` }}
                  />
                </div>
                <div ref={stageRef} className="relative min-w-0 overflow-hidden">
                  <WaveCanvas
                    clip={session.clip}
                    viewStart={viewStart}
                    viewSpan={viewSpan}
                    cursor={cursor}
                    selection={hasSel ? sel : null}
                    onGesture={onGesture}
                  />
                  {marksOn && sel && (
                    <>
                      <Mark n={1} gold sample={sel.start} viewStart={viewStart} viewSpan={viewSpan} onDrag={(x) => moveMark("start", x)} onUp={releaseMark} />
                      <Mark n={2} gold={false} sample={sel.end} viewStart={viewStart} viewSpan={viewSpan} onDrag={(x) => moveMark("end", x)} onUp={releaseMark} />
                    </>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    disabled={!hasSel}
                    onClick={() => sel && zoomToSample(sel.start)}
                    style={{ color: "#e4b23c" }}
                  >
                    1
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    disabled={!hasSel}
                    onClick={() => sel && zoomToSample(sel.end)}
                    style={{ color: "#e23b3b" }}
                  >
                    2
                  </Button>
                  <Button type="button" size="sm" variant="secondary" onClick={dropPin}>
                    Pin
                  </Button>
                </div>
                {pins.some((pin) => pin.track === name) && (
                  <div className="flex flex-wrap gap-2">
                    {pins
                      .filter((pin) => pin.track === name)
                      .map((pin) => (
                        <button
                          key={pin.id}
                          type="button"
                          className="rounded-full bg-surface-2 px-2 py-1 font-mono text-[11px] text-[#e4b23c]"
                          onClick={() => deletePin(pin.id)}
                        >
                          {formatMs(pin.start, rate)} ×
                        </button>
                      ))}
                  </div>
                )}
              </div>
              <Button
                type="button"
                variant={marksOn ? "default" : "secondary"}
                aria-pressed={marksOn}
                aria-label={marksOn ? "Hide arrows" : "Show arrows"}
                className="h-auto shrink-0 self-center px-3"
                onClick={toggleMarks}
              >
                <span className="flex flex-col items-center font-mono text-xs leading-tight">
                  <span style={{ color: "#e4b23c" }}>1▼</span>
                  <span style={{ color: "#e23b3b" }}>2▼</span>
                </span>
              </Button>
            </div>

            <div
              className="relative h-8 cursor-pointer overflow-hidden rounded-md bg-surface-2"
              onClick={(event) => {
                const rect = event.currentTarget.getBoundingClientRect();
                const ratio = rect.width <= 0 ? 0 : (event.clientX - rect.left) / rect.width;
                const span = viewSpan;
                const origin = Math.max(0, Math.min(Math.max(0, n - span), ratio * n - span / 2));
                setViewStart(origin);
              }}
              aria-label="Whole song. The box is what you are looking at."
            >
              {hasSel && sel && n > 0 && (
                <span
                  className="absolute inset-y-1 rounded-sm bg-ok/45"
                  style={{
                    left: `${(sel.start / n) * 100}%`,
                    width: `${Math.max(0.4, ((sel.end - sel.start) / n) * 100)}%`,
                  }}
                />
              )}
              {n > 0 && (
                <span
                  className="pointer-events-none absolute inset-y-0 border border-fg/70"
                  style={{
                    left: `${(viewStart / n) * 100}%`,
                    width: `${Math.max(0.6, (viewSpan / n) * 100)}%`,
                  }}
                />
              )}
            </div>

            {hasSel && sel && (sel.end < viewStart || sel.start > viewStart + viewSpan) && (
              <Button type="button" variant="secondary" size="sm" onClick={() => fitView(sel.start, sel.end)}>
                Back to selection
              </Button>
            )}

            {hasSel && sel && (
              <div className="flex flex-col gap-2 rounded-lg bg-surface-2 p-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm text-fg">This section</p>
                  <Button type="button" variant="secondary" size="sm" onClick={rememberPreset}>
                    Save as preset
                  </Button>
                </div>
                <div className="pointer-events-none">
                  <WaveCanvas
                    clip={session.clip}
                    viewStart={sel.start}
                    viewSpan={Math.max(1, sel.end - sel.start)}
                    cursor={cursor}
                    selection={null}
                    onGesture={() => undefined}
                    className="h-24 sm:h-28"
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={loopOn ? "default" : "secondary"}
                    aria-pressed={loopOn}
                    onClick={() => {
                      setLoopOn((on) => !on);
                      fitView(sel.start, sel.end);
                    }}
                  >
                    {loopOn ? "Looping this section" : "Loop this section"}
                  </Button>
                </div>
                {presets.filter((row) => row.track === name).length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {presets
                      .filter((row) => row.track === name)
                      .map((row) => (
                        <Button
                          key={row.id}
                          type="button"
                          size="sm"
                          variant={presetId === row.id ? "default" : "secondary"}
                          onClick={() => recallPreset(row.id)}
                        >
                          {formatPrecise(row.start, rate)}–{formatPrecise(row.end, rate)}
                        </Button>
                      ))}
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3">
              <label className="flex min-w-48 flex-1 items-center gap-3 text-xs text-muted">
                Zoom
                <input
                  type="range"
                  min={0}
                  max={1000}
                  value={zoomSlider(viewSpan, n, rate)}
                  aria-label="Zoom"
                  onChange={(event) => {
                    const minSpan = Math.min(n, Math.max(32, Math.round(rate * 0.008)));
                    const t = Number(event.target.value) / 1000;
                    const next = Math.exp(Math.log(minSpan) + t * (Math.log(n) - Math.log(minSpan)));
                    zoomAt(0.5, next / viewSpan);
                  }}
                  className="w-full"
                />
              </label>
              <span className="font-mono text-xs text-fg">Window {formatWindow(viewSpan, rate)}</span>
              <Button type="button" variant="secondary" size="sm" onClick={() => zoomAt(focusRatio(), 0.5)}>
                Closer
              </Button>
              <Button type="button" variant="secondary" size="sm" onClick={() => zoomAt(focusRatio(), 2)}>
                Wider
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  setViewStart(0);
                  setViewSpan(Math.max(1, n));
                }}
              >
                Fit
              </Button>
            </div>

            <p className="font-mono text-xs text-muted">
              {hasSel
                ? `Selection ${formatPrecise(sel.start, rate)} – ${formatPrecise(sel.end, rate)} · ${formatWindow(sel.end - sel.start, rate)} · ${(sel.end - sel.start).toLocaleString()} samples`
                : "Drag across the wave to select. A short tap only moves the playhead."}
            </p>

            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="secondary" size="sm" onClick={() => nudge("start", -pixelStep)} disabled={!hasSel}>
                Start −1px
              </Button>
              <Button type="button" variant="secondary" size="sm" onClick={() => nudge("start", pixelStep)} disabled={!hasSel}>
                Start +1px
              </Button>
              <Button type="button" variant="secondary" size="sm" onClick={() => nudge("end", -pixelStep)} disabled={!hasSel}>
                End −1px
              </Button>
              <Button type="button" variant="secondary" size="sm" onClick={() => nudge("end", pixelStep)} disabled={!hasSel}>
                End +1px
              </Button>
              <Button type="button" variant="ghost" size="sm" onClick={() => nudge("start", -step10)} disabled={!hasSel}>
                −10 ms
              </Button>
              <Button type="button" variant="ghost" size="sm" onClick={() => nudge("end", step10)} disabled={!hasSel}>
                +10 ms
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                disabled={!hasSel}
                onClick={() => {
                  if (!sel) return;
                  const at = sel.start;
                  edit(sessionCut(session, sel.start, sel.end));
                  setSelection(null);
                  setCursor(at);
                }}
              >
                Cut
              </Button>
              <Button
                type="button"
                disabled={!hasSel}
                onClick={() => {
                  if (!sel) return;
                  try {
                    const at = sel.start;
                    const current = sessionRef.current;
                    if (!current || !sel) return;
                    const next = sessionCrop(current, sel.start, sel.end);
                    if (next === session) {
                      toast.error("Drag a smaller piece. That selection is the whole song.");
                      return;
                    }
                    edit(next);
                    const kept = lengthOf(next.clip);
                    setSelection({ start: 0, end: kept });
                    setMarksOn(true);
                    setCursor(0);
                    setViewStart(0);
                    setViewSpan(Math.max(1, kept));
                    toast.success("Cropped to that section.");
                  } catch {
                    toast.error("Could not crop that. Try a shorter section.");
                  }
                }}
              >
                Crop
              </Button>
              <Button
                type="button"
                variant="secondary"
                disabled={!hasSel}
                onClick={() => {
                  const current = sessionRef.current;
                  if (!current || !sel) return;
                  const copied = sessionCopy(current, sel.start, sel.end);
                  if (!copied.clipboard || lengthOf(copied.clipboard) === 0) {
                    toast.error("That section is empty.");
                    return;
                  }
                  sessionRef.current = copied;
                  setSession(copied);
                  toast.success("Copied. Paste drops it between the arrows, or at the playhead.");
                }}
              >
                Copy
              </Button>
              <Button
                type="button"
                variant="secondary"
                disabled={!session.clipboard}
                onClick={() => {
                  const current = sessionRef.current;
                  if (!current?.clipboard || lengthOf(current.clipboard) === 0) {
                    toast.error("Copy a section first.");
                    return;
                  }
                  try {
                    const piece = lengthOf(current.clipboard);
                    const over = hasSel && sel ? sel : null;
                    const at = over ? over.start : cursor;
                    const next = sessionPaste(current, at, over);
                    if (next === current || lengthOf(next.clip) === 0) {
                      toast.error("Could not paste that.");
                      return;
                    }
                    edit(next);
                    const len = lengthOf(next.clip);
                    const start = Math.max(0, Math.min(Math.max(0, len - 1), Math.floor(at)));
                    const end = Math.max(start + 1, Math.min(len, start + piece));
                    setSelection({ start, end });
                    setMarksOn(true);
                    setCursor(start);
                    fitView(start, end);
                    toast.success(over ? "Pasted over that section." : "Pasted at the playhead.");
                  } catch {
                    toast.error("Could not paste that. The song may be too long for this phone.");
                  }
                }}
              >
                Paste
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label="Undo"
                disabled={session.undo.length === 0}
                onClick={() => edit(sessionUndo(session))}
              >
                <Undo2 />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label="Redo"
                disabled={session.redo.length === 0}
                onClick={() => edit(sessionRedo(session))}
              >
                <Redo2 />
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-2 text-xs text-muted">
                Gain {gainDb > 0 ? `+${gainDb}` : gainDb} dB
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={1}
                  value={gainDb}
                  aria-label="Selection gain"
                  onChange={(event) => setGainDb(Number(event.target.value))}
                />
              </label>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                disabled={!hasSel || gainDb === 0}
                onClick={() => sel && edit(sessionGain(session, sel.start, sel.end, dbToGain(gainDb)))}
              >
                Apply gain
              </Button>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                disabled={!hasSel}
                onClick={() => sel && edit(sessionFade(session, sel.start, sel.end, "in"))}
              >
                Fade in
              </Button>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                disabled={!hasSel}
                onClick={() => sel && edit(sessionFade(session, sel.start, sel.end, "out"))}
              >
                Fade out
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button type="button" disabled={saving || n === 0} onClick={() => void save(false)}>
                Save to crate
              </Button>
              <Button type="button" variant="secondary" disabled={saving || n === 0} onClick={() => void save(true)}>
                <Download />
                Download wav
              </Button>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

function rulerTicks(viewStart: number, viewSpan: number, rate: number): { sample: number; ratio: number; label: string }[] {
  if (viewSpan <= 0 || rate <= 0) return [];
  const ms = (viewSpan / rate) * 1000;
  const stepMs = ms < 250 ? 10 : ms < 900 ? 50 : ms < 4000 ? 100 : ms < 20000 ? 500 : ms < 90000 ? 1000 : 5000;
  const step = Math.max(1, Math.round((stepMs / 1000) * rate));
  const first = Math.ceil(viewStart / step) * step;
  const ticks: { sample: number; ratio: number; label: string }[] = [];
  for (let sample = first; sample < viewStart + viewSpan && ticks.length < 8; sample += step) {
    const ratio = (sample - viewStart) / viewSpan;
    if (ratio < 0.02 || ratio > 0.98) continue;
    ticks.push({ sample, ratio, label: formatMs(sample, rate) });
  }
  return ticks;
}

function zoomSlider(span: number, n: number, rate: number): number {
  const total = Math.max(1, n);
  const minSpan = Math.min(total, Math.max(32, Math.round(rate * 0.008)));
  if (total <= minSpan) return 1000;
  const t = (Math.log(Math.min(total, Math.max(minSpan, span))) - Math.log(minSpan)) / (Math.log(total) - Math.log(minSpan));
  return Math.round(Math.min(1, Math.max(0, t)) * 1000);
}

function Mark({
  n,
  gold,
  sample,
  viewStart,
  viewSpan,
  onDrag,
  onUp,
}: {
  n: 1 | 2;
  gold: boolean;
  sample: number;
  viewStart: number;
  viewSpan: number;
  onDrag: (clientX: number) => void;
  onUp: () => void;
}) {
  const ratio = viewSpan <= 0 ? 0 : (sample - viewStart) / viewSpan;
  if (ratio < 0 || ratio > 1) return null;
  const left = `${ratio * 100}%`;
  const ink = gold ? "#e4b23c" : "#e23b3b";
  return (
    <button
      type="button"
      aria-label={n === 1 ? "Arrow 1, selection start" : "Arrow 2, selection end"}
      className="absolute inset-y-0 z-20 flex -translate-x-1/2 flex-col items-center justify-start pt-1"
      style={{ left, touchAction: "none", width: 36 }}
      onPointerDown={(event) => {
        event.stopPropagation();
        event.currentTarget.setPointerCapture(event.pointerId);
      }}
      onPointerMove={(event) => {
        if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
        event.stopPropagation();
        onDrag(event.clientX);
      }}
      onPointerUp={(event) => {
        event.stopPropagation();
        onUp();
      }}
    >
      <span
        className="rounded px-1.5 font-mono text-[11px] font-bold leading-4 text-black"
        style={{ background: ink }}
      >
        {n}
      </span>
      <span
        aria-hidden="true"
        style={{
          width: 0,
          height: 0,
          borderLeft: "10px solid transparent",
          borderRight: "10px solid transparent",
          borderTop: `16px solid ${ink}`,
          filter: "drop-shadow(0 1px 0 rgba(0,0,0,0.6))",
        }}
      />
      <span aria-hidden="true" className="w-0.5 flex-1" style={{ background: ink }} />
    </button>
  );
}
