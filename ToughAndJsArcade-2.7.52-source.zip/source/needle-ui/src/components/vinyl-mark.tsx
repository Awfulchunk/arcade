import { cn } from "@/lib/utils";

export function VinylMark({
  className,
  spinning = false,
}: {
  className?: string;
  spinning?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 64 64"
      aria-hidden="true"
      className={cn(spinning && "animate-spin-slow motion-reduce:animate-none", className)}
    >
      <circle cx="32" cy="32" r="31" className="fill-fg" />
      <circle
        cx="32"
        cy="32"
        r="24"
        fill="none"
        className="stroke-bg"
        strokeWidth="0.7"
        opacity="0.28"
      />
      <circle
        cx="32"
        cy="32"
        r="18"
        fill="none"
        className="stroke-bg"
        strokeWidth="0.7"
        opacity="0.28"
      />
      <circle
        cx="32"
        cy="32"
        r="12"
        fill="none"
        className="stroke-bg"
        strokeWidth="0.7"
        opacity="0.28"
      />
      <circle cx="32" cy="32" r="5" className="fill-accent" />
      <circle cx="32" cy="32" r="1.6" className="fill-bg" />
    </svg>
  );
}
