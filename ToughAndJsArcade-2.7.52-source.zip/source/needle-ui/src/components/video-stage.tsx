import type { RefObject } from "react";

export function VideoStage({
  src,
  videoRef,
  onTimeUpdate,
  onLoadedMetadata,
  onPlay,
  onPause,
  onEnded,
}: {
  src: string;
  videoRef: RefObject<HTMLVideoElement | null>;
  onTimeUpdate: (ms: number) => void;
  onLoadedMetadata: (ms: number) => void;
  onPlay: () => void;
  onPause: () => void;
  onEnded: () => void;
}) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-28 z-30 px-3 sm:bottom-24 sm:px-6">
      <div className="pointer-events-auto mx-auto max-w-3xl overflow-hidden rounded-xl bg-bg shadow-soft">
        <video
          ref={videoRef}
          src={src}
          playsInline
          controls
          className="aspect-video w-full bg-bg"
          onTimeUpdate={(event) => onTimeUpdate(event.currentTarget.currentTime * 1000)}
          onLoadedMetadata={(event) => onLoadedMetadata(event.currentTarget.duration * 1000)}
          onPlay={onPlay}
          onPause={onPause}
          onEnded={onEnded}
        />
      </div>
    </div>
  );
}
