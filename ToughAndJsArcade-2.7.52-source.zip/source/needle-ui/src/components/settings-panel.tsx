import { useState } from "react";
import { BITRATES, VIDEO_QUALITIES, type CrateSort, useSettings } from "@/lib/settings";
import { AUDIO_FORMATS } from "@/lib/audio-format";
import { UnderbedPanel } from "@/components/underbed-panel";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { getServer, getToken, setServer, setToken, testServer } from "@/lib/server-base";
import { phoneEngineAvailable, phoneEngineInfo } from "@/lib/phone-engine";

function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className="relative inline-flex h-11 min-h-11 w-14 shrink-0 items-center justify-center"
    >
      <span
        className={cn(
          "relative h-7 w-11 rounded-full transition-colors duration-quick",
          checked ? "bg-accent" : "bg-surface-2 shadow-border",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 left-0.5 size-6 rounded-full bg-bg transition-transform duration-quick",
            checked && "translate-x-4",
          )}
        />
      </span>
    </button>
  );
}

export function SettingsPanel() {
  const { bitrate, videoQuality, autoSweep, chime, sort, bundleZip, volume, adultMode, audioFormat, engine, set } =
    useSettings();
  const phone = phoneEngineAvailable();
  const phoneInfo = phone ? phoneEngineInfo() : null;
  const [adultConfirm, setAdultConfirm] = useState(false);
  const [srv, setSrv] = useState(getServer());
  const [tok, setTok] = useState(getToken());
  const [showTok, setShowTok] = useState(false);
  const [srvMsg, setSrvMsg] = useState<{ ok: boolean; message: string } | null>(null);
  const [srvBusy, setSrvBusy] = useState(false);
  const adultShown = adultMode || adultConfirm;

  return (
    <section
      className="animate-rise rounded-xl bg-surface p-4 shadow-border sm:p-5"
      aria-label="Press settings"
    >
      <div className="flex flex-col gap-5">
        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">Download engine</p>
          <p className="text-xs text-muted">
            {phone
              ? phoneInfo && !phoneInfo.ok
                ? phoneInfo.why
                : "On this phone: YouTube, Shorts and direct file links download inside the app. No PC needed. Home-PC server: the old way, through the server script on your PC."
              : "On this phone needs the Tough & J's Arcade app. Here only the Home-PC server works."}
          </p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Download engine">
            {(
              [
                ["phone", "On this phone"],
                ["server", "Home-PC server"],
              ] as const
            ).map(([value, label]) => (
              <Button
                key={value}
                type="button"
                variant={engine === value ? "default" : "secondary"}
                aria-pressed={engine === value}
                disabled={value === "phone" && !phone}
                onClick={() => set({ engine: value })}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">Home-PC server address</p>
          <p className="text-xs text-muted">
            Only used in Home-PC server mode (and to convert a saved file to another format). Run the server script on your PC, same Wi-Fi, then type its address here, like http://192.168.1.20:8765. Cutting, the equalizer and the waveform work without it.
          </p>
          <input
            type="url"
            inputMode="url"
            value={srv}
            placeholder="http://192.168.1.20:8765"
            onChange={(e) => {
              setSrv(e.target.value);
              setServer(e.target.value);
            }}
            aria-label="Home-PC server address"
            className="h-11 rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-border"
          />
          <p className="text-sm font-medium text-fg">Home-PC server token</p>
          <p className="text-xs text-muted">
            The server prints this long secret the first time it runs. Paste it here. It stays on this phone only.
          </p>
          <input
            type={showTok ? "text" : "password"}
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            autoComplete="off"
            value={tok}
            placeholder="Token (64 characters)"
            onChange={(e) => {
              setTok(e.target.value);
              setToken(e.target.value);
            }}
            aria-label="Home-PC server token"
            className="h-11 rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-border"
          />
          <div className="flex gap-2">
            <Button type="button" variant="ghost" onClick={() => setShowTok((v) => !v)}>
              {showTok ? "Hide token" : "Show token"}
            </Button>
            <Button
              type="button"
              disabled={srvBusy}
              onClick={() => {
                setSrvBusy(true);
                setSrvMsg(null);
                void testServer(srv, tok).then(setSrvMsg).finally(() => setSrvBusy(false));
              }}
            >
              {srvBusy ? "Testing..." : "Test connection"}
            </Button>
          </div>
          {srvMsg ? (
            <p role="status" className={cn("text-sm", srvMsg.ok ? "text-ok" : "text-bad")}>
              {srvMsg.message}
            </p>
          ) : null}
        </div>
        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">File format</p>
          <p className="text-xs text-muted">
            mp3 plays on the phone. m4a is what was failing. New pulls and saves use this.
          </p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="File format">
            {AUDIO_FORMATS.map((format) => (
              <Button
                key={format}
                type="button"
                size="sm"
                variant={audioFormat === format ? "default" : "secondary"}
                onClick={() => set({ audioFormat: format })}
              >
                {format}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">Encode bitrate</p>
          <p className="text-xs text-muted">
            Used when an audio pull has to be remuxed. Copy-through stays lossless.
          </p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Encode bitrate">
            {BITRATES.map((rate) => (
              <Button
                key={rate}
                type="button"
                size="sm"
                variant={bitrate === rate ? "default" : "secondary"}
                onClick={() => set({ bitrate: rate })}
              >
                {rate}k
              </Button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">Video quality</p>
          <p className="text-xs text-muted">Cap for video pulls. Lower is smaller and faster.</p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Video quality">
            {VIDEO_QUALITIES.map((q) => (
              <Button
                key={q}
                type="button"
                size="sm"
                variant={videoQuality === q ? "default" : "secondary"}
                onClick={() => set({ videoQuality: q })}
              >
                {q}p
              </Button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-fg">Crate order</p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Crate order">
            {(
              [
                ["newest", "Newest"],
                ["name", "Name"],
                ["size", "Size"],
              ] as [CrateSort, string][]
            ).map(([value, label]) => (
              <Button
                key={value}
                type="button"
                size="sm"
                variant={sort === value ? "default" : "secondary"}
                onClick={() => set({ sort: value })}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        <label className="flex flex-col gap-2">
          <span className="text-sm font-medium text-fg">
            Playback volume
            <span className="ml-2 font-mono text-xs text-subtle tabular-nums">
              {Math.round(volume * 100)}%
            </span>
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(volume * 100)}
            aria-label="Playback volume"
            onChange={(event) => set({ volume: Number(event.target.value) / 100 })}
            className="h-11 w-full cursor-pointer"
          />
        </label>

        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-fg">Ready chime</p>
            <p className="text-xs text-muted">A short tone when a file lands in the crate.</p>
          </div>
          <Toggle checked={chime} onChange={(next) => set({ chime: next })} label="Ready chime" />
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-fg">Sweep finished jobs</p>
            <p className="text-xs text-muted">Clear the queue automatically after pulls settle.</p>
          </div>
          <Toggle
            checked={autoSweep}
            onChange={(next) => set({ autoSweep: next })}
            label="Sweep finished jobs"
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-fg">Bundle as zip</p>
            <p className="text-xs text-muted">
              Off by default: Download all saves each file on its own. On: one zip.
            </p>
          </div>
          <Toggle
            checked={bundleZip}
            onChange={(next) => set({ bundleZip: next })}
            label="Bundle as zip"
          />
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-fg">Adult mode</p>
              <p className="text-xs text-muted">
                Off by default. Unlocks R-rated and age-restricted titles after you confirm 18+.
              </p>
            </div>
            <Toggle
              checked={adultShown}
              onChange={(next) => {
                if (!next) {
                  set({ adultMode: false });
                  setAdultConfirm(false);
                  return;
                }
                if (adultMode) return;
                setAdultConfirm(true);
              }}
              label="Adult mode"
            />
          </div>
          {adultConfirm && !adultMode && (
            <div
              className="animate-rise rounded-lg bg-surface-2 p-3 shadow-border"
              role="group"
              aria-label="Confirm adult mode"
            >
              <p className="text-sm text-fg">
                Confirm you are 18 or older. This is for R-rated films and age-gated clips.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  type="button"
                  size="sm"
                  onClick={() => {
                    set({ adultMode: true });
                    setAdultConfirm(false);
                  }}
                >
                  I'm 18+
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => setAdultConfirm(false)}
                >
                  Not now
                </Button>
              </div>
            </div>
          )}
          {adultMode && (
            <p className="text-xs text-muted">
              Adult mode is on. Age-gated and R-rated titles can be pulled. Turn it off anytime.
            </p>
          )}
        </div>

        <UnderbedPanel />

        <p className="text-xs text-subtle">
          Space plays or pauses. Arrows skip. Esc closes the player. Click the vinyl for a random
          pick.
        </p>
      </div>
    </section>
  );
}
