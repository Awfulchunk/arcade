import { useEffect, useRef } from "react";
import { buildMips, lengthOf, spanPeaks, type Mip, type Stereo } from "@/lib/audio-edit";
import { cn } from "@/lib/utils";

type Gesture = {
  type: "down" | "move" | "up" | "wheel" | "pinch" | "cancel";
  sample: number;
  ratio: number;
  factor: number;
};

export function WaveCanvas({
  clip,
  viewStart,
  viewSpan,
  cursor,
  selection,
  onGesture,
  className,
}: {
  clip: Stereo;
  viewStart: number;
  viewSpan: number;
  cursor: number;
  selection: { start: number; end: number } | null;
  onGesture: (gesture: Gesture) => void;
  className?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mipsRef = useRef<Mip[]>([]);
  const pointers = useRef(new Map<number, number>());
  const pinch = useRef<{ dist: number; ratio: number } | null>(null);
  const zooming = useRef(false);
  const clipRef = useRef(clip);
  const viewRef = useRef({ viewStart, viewSpan });
  clipRef.current = clip;
  viewRef.current = { viewStart, viewSpan };

  useEffect(() => {
    mipsRef.current = buildMips(clip.channels[0] ?? new Float32Array(0));
  }, [clip]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const width = canvas.clientWidth || 1;
    const height = canvas.clientHeight || 1;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const styles = getComputedStyle(canvas);
    const fg = styles.color || "#eef3f7";
    const bg = styles.backgroundColor || "#1d2731";
    const ok = getComputedStyle(document.documentElement).getPropertyValue("--color-ok").trim() || "#7eae9a";
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);
    const channel = clip.channels[0] ?? new Float32Array(0);
    const peaks = spanPeaks(channel, mipsRef.current, viewStart, viewStart + viewSpan, width);
    const mid = height / 2;
    ctx.strokeStyle = fg;
    ctx.globalAlpha = 0.18;
    ctx.beginPath();
    ctx.moveTo(0, mid);
    ctx.lineTo(width, mid);
    ctx.stroke();
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    for (let x = 0; x < peaks.length; x++) {
      const peak = peaks[x]!;
      const y1 = mid - peak.max * (mid - 4);
      const y2 = mid - peak.min * (mid - 4);
      ctx.moveTo(x + 0.5, y1);
      ctx.lineTo(x + 0.5, Math.max(y1 + 1, y2));
    }
    ctx.stroke();
    if (selection) {
      const a = ((Math.min(selection.start, selection.end) - viewStart) / viewSpan) * width;
      const b = ((Math.max(selection.start, selection.end) - viewStart) / viewSpan) * width;
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = ok;
      ctx.fillRect(a, 0, Math.max(1, b - a), height);
    }
    const playX = ((cursor - viewStart) / viewSpan) * width;
    if (playX >= 0 && playX <= width) {
      ctx.globalAlpha = 1;
      ctx.strokeStyle = fg;
      ctx.beginPath();
      ctx.moveTo(playX + 0.5, 0);
      ctx.lineTo(playX + 0.5, height);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }, [clip, viewStart, viewSpan, cursor, selection]);

  const onGestureRef = useRef(onGesture);
  onGestureRef.current = onGesture;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const onWheel = (event: WheelEvent) => {
      if (pointers.current.size > 0) return;
      event.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const ratio = rect.width <= 0 ? 0 : Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
      const { viewStart: start, viewSpan: span } = viewRef.current;
      const sample = Math.round(start + ratio * span);
      const n = lengthOf(clipRef.current);
      onGestureRef.current({
        type: "wheel",
        sample: Math.max(0, Math.min(n, sample)),
        ratio,
        factor: event.deltaY < 0 ? 0.8 : 1.25,
      });
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => canvas.removeEventListener("wheel", onWheel);
  }, []);

  const sampleAt = (clientX: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { sample: 0, ratio: 0 };
    const rect = canvas.getBoundingClientRect();
    const ratio = rect.width <= 0 ? 0 : Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    const { viewStart: start, viewSpan: span } = viewRef.current;
    const sample = Math.round(start + ratio * span);
    const n = lengthOf(clipRef.current);
    return { sample: Math.max(0, Math.min(n, sample)), ratio };
  };

  return (
    <canvas
      ref={canvasRef}
      className={cn("h-44 w-full touch-none rounded-lg bg-surface-2 text-fg sm:h-56", className)}
      aria-label="Waveform. Drag to select. Scroll or pinch to zoom."
      onPointerDown={(event) => {
        event.currentTarget.setPointerCapture(event.pointerId);
        pointers.current.set(event.pointerId, event.clientX);
        if (pointers.current.size === 2) {
          zooming.current = true;
          const [a, b] = [...pointers.current.values()];
          const dist = Math.abs((a ?? 0) - (b ?? 0)) || 1;
          const mid = ((a ?? 0) + (b ?? 0)) / 2;
          const hit = sampleAt(mid);
          pinch.current = { dist, ratio: hit.ratio };
          onGesture({ type: "cancel", sample: hit.sample, ratio: hit.ratio, factor: 1 });
          return;
        }
        const hit = sampleAt(event.clientX);
        onGesture({ type: "down", sample: hit.sample, ratio: hit.ratio, factor: 1 });
      }}
      onPointerMove={(event) => {
        if (!pointers.current.has(event.pointerId)) return;
        pointers.current.set(event.pointerId, event.clientX);
        if (pointers.current.size >= 2 && pinch.current) {
          const [a, b] = [...pointers.current.values()];
          const dist = Math.abs((a ?? 0) - (b ?? 0)) || 1;
          const factor = pinch.current.dist / dist;
          if (Math.abs(factor - 1) < 0.04) return;
          const clamped = Math.min(1.08, Math.max(0.92, factor));
          pinch.current = { dist, ratio: pinch.current.ratio };
          onGesture({ type: "pinch", sample: 0, ratio: pinch.current.ratio, factor: clamped });
          return;
        }
        const hit = sampleAt(event.clientX);
        onGesture({ type: "move", sample: hit.sample, ratio: hit.ratio, factor: 1 });
      }}
      onPointerUp={(event) => {
        pointers.current.delete(event.pointerId);
        if (pointers.current.size < 2) pinch.current = null;
        if (zooming.current) {
          if (pointers.current.size === 0) zooming.current = false;
          return;
        }
        const hit = sampleAt(event.clientX);
        onGesture({ type: "up", sample: hit.sample, ratio: hit.ratio, factor: 1 });
      }}
      onPointerCancel={(event) => {
        pointers.current.delete(event.pointerId);
        pinch.current = null;
      }}
    />
  );
}
