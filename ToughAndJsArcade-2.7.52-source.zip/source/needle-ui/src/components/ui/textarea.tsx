import * as React from "react";
import { cn } from "@/lib/utils";

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      data-slot="textarea"
      className={cn(
        "flex min-h-40 w-full rounded-lg border border-border bg-surface-2 px-4 py-3 font-mono text-sm text-fg shadow-border",
        "placeholder:text-subtle placeholder:font-sans",
        "transition-[box-shadow,border-color] duration-quick ease-smooth",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

export { Textarea };
