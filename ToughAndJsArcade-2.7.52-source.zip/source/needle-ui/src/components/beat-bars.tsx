import { memo, useEffect, useRef } from "react";
import { lowEndDevice } from "@/lib/low-end";

export const BAR_COUNTS = [16, 24, 32, 48] as const;
export const BAR_STYLES = ["bars", "mirror", "dots", "classic", "scope", "sparks", "ribbon", "stairs"] as const;
export const BAR_COLORS = ["amber", "ice", "rose", "lime"] as const;
export const BAR_MOTION = ["soft", "normal", "wild"] as const;
export const BAR_GLOWS = ["off", "soft", "hot"] as const;
export const BAR_BOARDS = ["clean", "grid", "scan"] as const;

export type BarCount = (typeof BAR_COUNTS)[number];
export type BarStyle = (typeof BAR_STYLES)[number];
export type BarColor = (typeof BAR_COLORS)[number];
export type BarMotion = (typeof BAR_MOTION)[number];
export type BarGlow = (typeof BAR_GLOWS)[number];
export type BarBoard = (typeof BAR_BOARDS)[number];

export type BarLook = {
  count: BarCount;
  style: BarStyle;
  color: BarColor;
  motion: BarMotion;
  glow: BarGlow;
  board: BarBoard;
};

export type LiveProbe = { node: AnalyserNode; rate: number } | null;

export const BAR_LOOK_KEY = "needle-eq-bars";

export const DEFAULT_LOOK: BarLook = {
  count: 32,
  style: "classic",
  color: "lime",
  motion: "normal",
  glow: "soft",
  board: "clean",
};

export const STYLE_PLAIN: Record<BarStyle, string> = {
  bars: "Columns that rise from the bottom with the loud parts.",
  mirror: "Those columns, copied up and down from the middle.",
  dots: "A dot that jumps on the beat and falls back down.",
  classic: "Old computer lights. Left jumps on the kick, the middle on the voice and instruments, the right on the hats.",
  scope: "A glowing line, like an old green screen, that draws the sound wave.",
  sparks: "Little bursts that shoot up when that part of the song hits.",
  ribbon: "One smooth line that bends with the whole song.",
  stairs: "Blocky steps, like an old game, that climb on the beat.",
};

export const MOTION_PLAIN: Record<BarMotion, string> = {
  soft: "Glides. The peaks fall slowly.",
  normal: "Follows the song.",
  wild: "Snaps to the drums.",
};

const COLORS: Record<BarColor, string> = {
  amber: "#ffb000",
  ice: "#5ee7ff",
  rose: "#ff5d8f",
  lime: "#39ff14",
};

export function readBarLook(): BarLook {
  try {
    const raw = JSON.parse(localStorage.getItem(BAR_LOOK_KEY) || "") as Partial<BarLook>;
    const style = raw.style as BarStyle;
    return {
      count: BAR_COUNTS.includes(raw.count as BarCount) ? (raw.count as BarCount) : DEFAULT_LOOK.count,
      style: BAR_STYLES.includes(style) ? style : DEFAULT_LOOK.style,
      color: BAR_COLORS.includes(raw.color as BarColor) ? (raw.color as BarColor) : DEFAULT_LOOK.color,
      motion: BAR_MOTION.includes(raw.motion as BarMotion) ? (raw.motion as BarMotion) : DEFAULT_LOOK.motion,
      glow: BAR_GLOWS.includes(raw.glow as BarGlow) ? (raw.glow as BarGlow) : DEFAULT_LOOK.glow,
      board: BAR_BOARDS.includes(raw.board as BarBoard) ? (raw.board as BarBoard) : DEFAULT_LOOK.board,
    };
  } catch {
    return DEFAULT_LOOK;
  }
}

function bandLevel(freq: Uint8Array, index: number, count: number, rate: number): number {
  const nyquist = rate / 2;
  const min = 35;
  const max = Math.min(14000, nyquist * 0.92);
  const f0 = min * (max / min) ** (index / count);
  const f1 = min * (max / min) ** ((index + 1) / count);
  const i0 = Math.max(1, Math.floor((f0 / nyquist) * freq.length));
  const i1 = Math.min(freq.length, Math.max(i0 + 1, Math.ceil((f1 / nyquist) * freq.length)));
  let peak = 0;
  let sum = 0;
  for (let i = i0; i < i1; i++) {
    const v = freq[i] ?? 0;
    peak = Math.max(peak, v);
    sum += v;
  }
  const avg = sum / Math.max(1, i1 - i0);
  const mixed = (peak * 0.65 + avg * 0.35) / 255;
  const bassBoost = index < count * 0.22 ? 1.55 : index < count * 0.55 ? 1.2 : 1.05;
  return Math.min(1, mixed * bassBoost);
}

function BeatBarsImpl({
  playing,
  getProbe,
  look,
}: {
  playing: boolean;
  getProbe: () => LiveProbe;
  look: BarLook;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const probe = useRef(getProbe);
  probe.current = getProbe;
  const levels = useRef<number[]>([]);
  const peaks = useRef<number[]>([]);
  const dots = useRef<number[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let frame = 0;
    const hold = look.motion === "soft" ? 0.78 : look.motion === "wild" ? 0.28 : 0.55;
    const fall = look.motion === "soft" ? 0.008 : look.motion === "wild" ? 0.035 : 0.016;
    const freq = new Uint8Array(2048);
    const wave = new Uint8Array(2048);

    const low = lowEndDevice();
    const gap = low ? 45 : 16;
    let lastT = 0;
    const tick = (now: number) => {
      if (document.hidden || now - lastT < gap) {
        frame = requestAnimationFrame(tick);
        return;
      }
      lastT = now;
      const width = canvas.clientWidth || 1;
      const height = canvas.clientHeight || 1;
      const dpr = low ? 1 : Math.min(window.devicePixelRatio || 1, 2);
      if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
        canvas.width = Math.round(width * dpr);
        canvas.height = Math.round(height * dpr);
      }
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const ink = COLORS[look.color];
      const live = probe.current();
      const count = look.count;
      if (levels.current.length !== count) {
        levels.current = Array.from({ length: count }, () => 0);
        peaks.current = Array.from({ length: count }, () => 0);
        dots.current = Array.from({ length: count }, () => 0);
      }
      if (live && playing) {
        const bins = freq.subarray(0, live.node.frequencyBinCount);
        live.node.getByteFrequencyData(bins);
        if (look.style === "scope") live.node.getByteTimeDomainData(wave);
        for (let i = 0; i < count; i++) {
          const value = bandLevel(bins, i, count, live.rate || 48000);
          const prev = levels.current[i] ?? 0;
          levels.current[i] = prev * hold + value * (1 - hold);
          peaks.current[i] = Math.max(levels.current[i] ?? 0, (peaks.current[i] ?? 0) - fall);
          const dot = dots.current[i] ?? 0;
          dots.current[i] = value > dot ? value : dot * (look.motion === "wild" ? 0.9 : 0.96);
        }
      } else {
        for (let i = 0; i < count; i++) {
          levels.current[i] = (levels.current[i] ?? 0) * 0.9;
          peaks.current[i] = (peaks.current[i] ?? 0) * 0.96;
          dots.current[i] = (dots.current[i] ?? 0) * 0.94;
        }
      }

      ctx.fillStyle = "#141c24";
      ctx.fillRect(0, 0, width, height);
      paintBoard(ctx, width, height, look.board, ink, frame);
      ctx.shadowColor = ink;
      ctx.shadowBlur = low ? 0 : look.glow === "hot" ? 16 : look.glow === "soft" ? 6 : 0;

      if (look.style === "scope") drawScope(ctx, width, height, wave, ink, playing);
      else if (look.style === "classic") drawClassic(ctx, width, height, levels.current, peaks.current, ink);
      else if (look.style === "mirror") drawMirror(ctx, width, height, levels.current, ink);
      else if (look.style === "dots") drawDots(ctx, width, height, levels.current, dots.current, ink);
      else if (look.style === "sparks") drawSparks(ctx, width, height, levels.current, dots.current, ink);
      else if (look.style === "ribbon") drawRibbon(ctx, width, height, levels.current, ink);
      else if (look.style === "stairs") drawStairs(ctx, width, height, levels.current, ink);
      else drawBars(ctx, width, height, levels.current, ink);
      ctx.shadowBlur = 0;

      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, look.count, look.motion, look.style, look.color, look.glow, look.board]);

  return (
    <canvas
      ref={canvasRef}
      className="h-36 w-full rounded-lg sm:h-44"
      aria-label="Sound moving with the song"
    />
  );
}

export const BeatBars = memo(BeatBarsImpl, (a, b) => a.playing === b.playing && a.look === b.look);

function paintBoard(ctx: CanvasRenderingContext2D, width: number, height: number, board: BarBoard, ink: string, frame: number) {
  ctx.fillStyle = "#070b08";
  ctx.fillRect(0, 0, width, height);
  if (board === "grid") {
    ctx.globalAlpha = 0.16;
    ctx.strokeStyle = ink;
    ctx.beginPath();
    for (let y = 10; y < height; y += 14) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1;
  } else if (board === "scan") {
    const y = Math.abs(frame) % Math.max(1, height);
    ctx.fillStyle = ink;
    ctx.globalAlpha = 0.22;
    ctx.fillRect(0, y, width, 3);
    ctx.globalAlpha = 1;
  }
}

function drawSparks(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  dots: number[],
  ink: string,
) {
  const gap = 4;
  const bw = (width - gap * (levels.length + 1)) / levels.length;
  levels.forEach((level, i) => {
    const x = gap + i * (bw + gap) + bw / 2;
    const burst = dots[i] ?? level;
    for (let s = 0; s < 3; s++) {
      const lift = Math.max(0, burst - s * 0.18);
      const y = height - 8 - lift * (height - 16);
      ctx.globalAlpha = 1 - s * 0.28;
      ctx.fillStyle = ink;
      ctx.beginPath();
      ctx.arc(x, y, Math.max(1.5, (3 - s) + level * 2), 0, Math.PI * 2);
      ctx.fill();
    }
  });
  ctx.globalAlpha = 1;
}

function drawRibbon(ctx: CanvasRenderingContext2D, width: number, height: number, levels: number[], ink: string) {
  if (levels.length === 0) return;
  const step = width / levels.length;
  const yAt = (level: number) => height - 8 - level * (height - 16);
  ctx.beginPath();
  ctx.moveTo(0, yAt(levels[0] ?? 0));
  levels.forEach((level, i) => {
    const x = i * step + step / 2;
    const y = yAt(level);
    const prevX = i === 0 ? 0 : (i - 0.5) * step;
    const prevY = yAt(levels[i - 1] ?? level);
    ctx.quadraticCurveTo(prevX, prevY, x, y);
  });
  ctx.strokeStyle = ink;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.globalAlpha = 0.18;
  ctx.fillStyle = ink;
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawStairs(ctx: CanvasRenderingContext2D, width: number, height: number, levels: number[], ink: string) {
  const gap = 3;
  const bw = Math.max(4, (width - gap * (levels.length + 1)) / levels.length);
  const floors = 6;
  levels.forEach((level, i) => {
    const steps = Math.max(0, Math.round(level * floors));
    const x = gap + i * (bw + gap);
    for (let s = 0; s < steps; s++) {
      const h = (height - 12) / floors;
      ctx.fillStyle = ink;
      ctx.fillRect(x, height - 6 - (s + 1) * h, bw, h - 2);
    }
  });
}

function drawBars(ctx: CanvasRenderingContext2D, width: number, height: number, levels: number[], ink: string) {
  const gap = 3;
  const bw = Math.max(2, (width - gap * (levels.length + 1)) / levels.length);
  levels.forEach((level, i) => {
    const h = Math.max(2, level * (height - 10));
    roundRect(ctx, gap + i * (bw + gap), height - 6 - h, bw, h, Math.min(4, bw / 2), ink);
  });
}

function drawMirror(ctx: CanvasRenderingContext2D, width: number, height: number, levels: number[], ink: string) {
  const mid = height / 2;
  ctx.strokeStyle = ink;
  ctx.globalAlpha = 0.25;
  ctx.beginPath();
  ctx.moveTo(8, mid);
  ctx.lineTo(width - 8, mid);
  ctx.stroke();
  ctx.globalAlpha = 1;
  const gap = 4;
  const bw = Math.max(3, (width - gap * (levels.length + 1)) / levels.length);
  levels.forEach((level, i) => {
    const h = Math.max(2, level * (mid - 10));
    const x = gap + i * (bw + gap);
    roundRect(ctx, x, mid - h - 2, bw, h, Math.min(3, bw / 2), ink);
    ctx.globalAlpha = 0.55;
    roundRect(ctx, x, mid + 2, bw, h, Math.min(3, bw / 2), ink);
    ctx.globalAlpha = 1;
  });
}

function drawDots(ctx: CanvasRenderingContext2D, width: number, height: number, levels: number[], dots: number[], ink: string) {
  const gap = 4;
  const bw = (width - gap * (levels.length + 1)) / levels.length;
  levels.forEach((level, i) => {
    const x = gap + i * (bw + gap) + bw / 2;
    const travel = dots[i] ?? level;
    const y = height - 10 - travel * (height - 22);
    const trail = height - 10 - level * (height - 22);
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = ink;
    ctx.beginPath();
    ctx.arc(x, trail, Math.max(2, bw * 0.28), 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.beginPath();
    ctx.arc(x, y, Math.max(3, bw * 0.42 + level * 3), 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawClassic(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  peaks: number[],
  ink: string,
) {
  const labelH = 16;
  const top = 8;
  const bottom = height - labelH;
  const seg = 4;
  const segGap = 2;
  const slots = Math.max(4, Math.floor((bottom - top) / (seg + segGap)));
  const gap = 2;
  const bw = Math.max(2, (width - gap * (levels.length + 1)) / levels.length);
  levels.forEach((level, i) => {
    const lit = Math.round(level * slots);
    const peakSlot = Math.round((peaks[i] ?? level) * slots);
    const x = gap + i * (bw + gap);
    for (let s = 0; s < slots; s++) {
      const y = bottom - (s + 1) * (seg + segGap);
      const hot = s / slots;
      ctx.fillStyle = s < lit ? (hot > 0.82 ? "#ff3355" : hot > 0.62 ? "#ffe14a" : ink) : "rgba(255,255,255,0.06)";
      ctx.fillRect(x, y, bw, seg);
    }
    if (peakSlot > 0) {
      const y = bottom - peakSlot * (seg + segGap);
      ctx.fillStyle = "#f4fff4";
      ctx.fillRect(x, y, bw, 2);
    }
  });
  ctx.font = "10px ui-monospace, monospace";
  ctx.fillStyle = ink;
  ctx.globalAlpha = 0.8;
  ctx.fillText("KICK", 8, height - 4);
  ctx.fillText("VOICE", width / 2 - 18, height - 4);
  ctx.fillText("HATS", width - 36, height - 4);
  ctx.globalAlpha = 1;
}

function drawScope(ctx: CanvasRenderingContext2D, width: number, height: number, wave: Uint8Array, ink: string, playing: boolean) {
  ctx.strokeStyle = ink;
  ctx.lineWidth = 2;
  ctx.shadowColor = ink;
  ctx.shadowBlur = 8;
  ctx.beginPath();
  const mid = height / 2;
  const step = Math.max(1, Math.floor(wave.length / width));
  for (let x = 0; x < width; x++) {
    const sample = playing ? (wave[x * step] ?? 128) : 128 + Math.sin(x / 18) * 4;
    const y = mid + ((sample - 128) / 128) * (height * 0.42);
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.shadowBlur = 0;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  color: string,
) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();
}
