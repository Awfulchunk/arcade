import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import { resolve } from "node:path";
export default defineConfig({ base: "./", resolve: { alias: { "@": resolve(__dirname, "src") } }, plugins: [tailwindcss(), react(), viteSingleFile()], build: { target: "es2019", assetsInlineLimit: 100000000, chunkSizeWarningLimit: 99999 } });
