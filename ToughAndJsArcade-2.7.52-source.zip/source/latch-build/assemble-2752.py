"""Arcade 2.7.52: swap ONLY latch:latest (Latch v2.0 'VTR-1' UI) on top of the unpublished 2.7.51.
The 2.7.51 Latch (v1.1) is kept as latch:v11. Every other cartridge payload stays byte-for-byte as in 2.7.51."""
from pathlib import Path
import json,re,hashlib
root=Path('/workspace/game'); base=root/'build-needle/package-2.7.51'; stage=root/'build-needle/package-2.7.52'
src=(base/'tough-and-js-arcade.html').read_text()
assert hashlib.sha256(src.encode()).hexdigest()=='8b8a26e521f0c644191c4f5200e2e5ecf851be72342cd715becc14af5dc87b1c','2.7.51 bundle changed?!'
new=(root/'build-apps/latch-v2.0.html').read_text()
def slots(text):
    r={}
    for m in re.finditer(r'^"([^"\n]+)":\[',text,re.M):
        a=m.end()-1;b=text.index('].join("")',a)+len('].join("")');r[m[1]]=text[a:b]
    return r
before=slots(src); assert 'latch:latest' in before and 'latch:v11' not in before
old=before['latch:latest']
a=src.index('"latch:latest":')+len('"latch:latest":');b=a+len(old)
expr=json.dumps([new],ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+'.join("")'
out=src[:a]+expr+',\n"latch:v11":'+old+src[b:]
a=out.index('{"id":"latch","title":');obj,length=json.JSONDecoder().raw_decode(out[a:]);assert obj['id']=='latch'
prior=dict(next(v for v in obj['versions'] if v['id']=='latest'));prior.update(id='v11',name='v1.1 – ? on every button (2.7.51 and before)',desc='Latch as in 2.7.51: the older layout with a yellow ? beside every button.',**{'def':False})
obj['versions'].insert(len(obj['versions'])-1,prior)
cur=next(v for v in obj['versions'] if v['id']=='latest')
cur['name']='v2.0 – Latest (VTR-1 camcorder UI)'
cur['desc']='Tool, not a game. New camcorder-style layout: big viewfinder, transport + counter, filmstrip with drag handles, and four keys (CUT, LOOK, ADD, SAVE) that open simple tool tiles. Trim, bounce, join, crop, grade, stickers, end result, GIF/still/clip save, comic pages with bubbles. Hold any button for a tip; ? numbers the screen. Try sample clip built in. Nothing leaves the phone.'
out=out[:a]+json.dumps(obj,ensure_ascii=False,separators=(',',':'))+out[a+length:]
after=slots(out)
changed=[k for k,v in before.items() if after.get(k)!=v]
assert changed==['latch:latest'],changed
assert after['latch:v11']==old
assert ''.join(json.loads(after['latch:latest'][:-len('.join("")')]))==new
(stage/'tough-and-js-arcade.html').write_text(out)
info={'arcadeVersion':'2.7.52','versionCode':90,'latchVersion':'2.0','latchSHA256':hashlib.sha256(new.encode()).hexdigest(),'latchBytes':len(new.encode()),
 'bundleSHA256':hashlib.sha256(out.encode()).hexdigest(),'baseBundleSHA256 (2.7.51)':hashlib.sha256(src.encode()).hexdigest(),
 'cartridgeSlots':len(after),'unchangedSlots':len(before)-1,'newSlot':'latch:v11 (= 2.7.51 latch:latest, byte-identical)',
 'latchVersionsInPicker':[v['name'] for v in obj['versions']]}
(stage/'assembly-verification.json').write_text(json.dumps(info,indent=2,ensure_ascii=False));print(json.dumps(info,indent=2,ensure_ascii=False))
