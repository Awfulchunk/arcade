set -e
cd /workspace/game/build-apps/src-latch && bash /workspace/game/build-latch/build.sh /workspace/game/build-apps/latch-v2.0.html > /workspace/game/build-latch/evidence/build-latch.txt 2>&1
cd /workspace/game/build-needle/package-2.7.52
cp /workspace/game/build-needle/package-2.7.51/tough-and-js-arcade.html .
python3 /workspace/game/build-latch/assemble-2752.py > /workspace/game/build-latch/evidence/assemble-2752.txt
rm -f out/ToughAndJsArcade-2.7.52.apk out/ToughAndJsArcade-2.7.52.apk.idsig
./build-apk.sh > /workspace/game/build-latch/evidence/build-apk.txt 2>&1
cd /workspace/game/build-latch
PATH=/workspace/tools/jdk/bin:$PATH node verify-2752.cjs > evidence/verify-2752.txt || echo VERIFY-FAILED
cd test
unzip -p /workspace/game/build-needle/package-2.7.52/out/ToughAndJsArcade-2.7.52.apk assets/index.html > arcade/index-from-apk.html
rm -rf shots/360x800 shots/320x568 flow-360x800 flow-320x568
node screens.cjs 360x800 > screens-360.log 2>&1
node screens.cjs 320x568 > screens-320.log 2>&1
node flow.cjs 360x800 > flow-360.log 2>&1
node flow.cjs 320x568 > flow-320.log 2>&1
node arcade.cjs > arcade.log 2>&1
echo CHAIN-DONE
