#!/bin/bash
# Build Latch single-file HTML from build-apps/src-latch with build-latch/tool/node_modules. Usage: build.sh <out.html>
set -euo pipefail
S=/workspace/game/build-apps/src-latch; T=/workspace/game/build-latch/tool
ln -sfn $T/node_modules $S/node_modules
trap 'rm -f $S/node_modules' EXIT
cd $S && $T/node_modules/.bin/vite build -c vite.spa.config.ts --logLevel warn
cp $S/spa-dist/index.html "$1"; ls -la "$1"
