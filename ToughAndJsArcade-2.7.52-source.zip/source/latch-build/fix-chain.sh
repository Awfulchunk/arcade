set -e
# 2.7.52 fix pass chain: build Latch -> assemble on 2.7.51 -> old-WebView patch -> APK -> verify -> desktop tests
E=/workspace/game/build-latch/evidence; mkdir -p $E
cd /workspace/game/build-apps/src-latch && bash /workspace/game/build-latch/build.sh /workspace/game/build-apps/latch-v2.0.html > $E/build-latch.txt 2>&1
cd /workspace/game/build-needle/package-2.7.52
cp /workspace/game/build-needle/package-2.7.51/tough-and-js-arcade.html .
python3 /workspace/game/build-latch/assemble-2752.py > $E/assemble-2752.txt
node /workspace/game/build-latch/fix/patch-legacy.mjs tough-and-js-arcade.html > $E/patch-legacy.txt
rm -f out/ToughAndJsArcade-2.7.52.apk out/ToughAndJsArcade-2.7.52.apk.idsig
./build-apk.sh > $E/build-apk.txt 2>&1
cd /workspace/game/build-latch
PATH=/workspace/tools/jdk/bin:$PATH node verify-2752.cjs > $E/verify-2752.txt || echo VERIFY-FAILED
echo BUILD-DONE
