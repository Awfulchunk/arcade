Tough & J's Arcade update package — 2.7.39 (America/Los_Angeles)

Contents
1) arcade-html/tank-royal-rumble-2.5.5.html — TRR v2.5.5 (tree scrub, trees fall no tank dmg, soft PZ, zone minimap)
2) arcade-html/swarm-1.5.6.html — Swarm cone-vision hordes, denser for A03s, learning AI Custom-only
3) AI-Station/ — Godot project + AIStation-0.1.0.apk + NOTES (CODI owns look; target 4 small+3 mid top / 1 big bottom)

Install: https://awfulchunk.github.io/arcade/download.html → ToughAndJsArcade-2.7.39.apk
