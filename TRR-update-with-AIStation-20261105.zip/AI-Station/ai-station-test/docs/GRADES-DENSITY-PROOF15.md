# CODI grade — Density + real proof 15 (Cursor PR #3)
Date: 2026-10-28 (America/Los_Angeles)
Branch: cursor/density-rooms-rematch-36b0
PR: https://github.com/Awfulchunk/ai-station/pull/3
Commit: f93e1b0824033efb063618d5804d807b7890d335

## Proofs (md5 verified on disk from PR branch)
| file | md5 | notes |
| --- | --- | --- |
| 14-subbay-closed.png | 839d8c2641a66464034d96a04ed0f0af | sidecar MATCH; L/R strong orange ~232,76,4 balanced |
| 15-density-rooms.png | 048bca40132b396d1f284d0ba1d3c02b | **≠ 14** — zoomed cutaway; fake plate FIXED |
| 16-engine-room.png | ac75b64d2331e554425363e555deafb0 | sidecar MATCH; engine=RUNNING; fuel drop after launch spend |

Old fake 15 was md5 5567e361… (identical to old 14). CLOSED.

## Locks
- Two outer orange pontoons on 14/16: strong-orange L/R counts ~21789/21574, mean RGB ≈ (232,76,4). PASS vs (233,77,0) lock.
- Center gap water-leaning on bottom band. PASS silhouette vs proof-13.
- StationSim sole authority: room_power_readout.gd bind_sim + fuel_oil snapshot; no second ledger in BayDressing. PASS code review.
- self_test.gd retains SELF_TEST_OK path + meter checks.

## Density
- Room-band bright fill (p35+8 heuristic): 14 OLD 48.3% → 14 NEW 54.7%; zoomed 15 ≈ 58.4%.
- Unique colors in room band: 14 OLD 637 → 14 NEW 785.
- Ladder bay unique: 181 → 222.
- New: bay_dressing.gd, equipment_builder hooks, zoomed proof capture.
- vs Metal Slug / Fallout Shelter mock: IMPROVED, not claimed match. Jay visual stamp still wanted on look.

## Verdict
**PASS (scoped)** — fake proof 15 killed; pontoon/hatch silhouette held; StationSim meters wired; measurable densification. Not a soft look-done stamp vs mock. APK still held. Next: real sub missions into StationSim on dock.
