# PROGRESS 0.4.4 (copy of 0.4.3) 2026-11-15 16:29 PT (America/Los_Angeles)

2026-11-15 16:29 PT: Copied build-pixelwar043 -> build-pixelwar044. Jay t1139-t1141: mix 0.4.2 lane-fill/spread with 0.4.3 steady flow + interpolated motion; +10-15% pace; +15-20% default flow; ricochet travel WAY down (~1/3 or less) Ship with no tests as 2.7.67 / code 105. Screenshot of live 0.4.3 spray: jay-043-ricochet.jpg (pixels far out and wide from the lane after ricochets).

2026-11-15 16:35 PT: Plan:
- Hybrid hitbox: keep 0.4.3 steady per-path flow, dest-aware branches, path-following exit, render interpolation, AI memory. Blend lateral fill (50% golden-ratio + 50% 0.4.2 random), mid speed variation (spm 0.92-1.08), mid thin-lane packing, default density 5 (between 0.4.2's 7 and 0.4.3's 3).
- paceMax 24 -> 27 (+12.5% across the range).
- Default FLOW release 3 -> 5 (onField 244 -> 289, +18%, still 200-400 cap).
- Ricochet: takeoff speed * 0.33; fade when past max(lane + 14, 28% of leash) from the path OR after traveling 28% of the old leash from the bounce. Spray direction (rotv) kept; fade still gradual.
- Keys pixelwar.v44 with fallbacks from v43 so prefs/forms/custom/AI memory carry over. DELETE AI MEMORY clears both.

2026-11-15 16:35 PT: t1142 + t1143 folded into the hybrid flow before ship. The drawn path is a direction guide only, not a rail: no pull, hug, clump or snap toward the center line. Inside the hitbox, pixels move freely forward with their own slight lateral drift and wander, filling the full lane width; the edges are a hard bound (soft-reflect / clamp). Only ricochet sprays (pfree) and past-path-end strays may leave the hitbox, both on the short leash (~28% of the old 108, plus the 1/3 takeoff speed). Density no longer shrinks them onto the line (it only eases how much they wander). Release spreads across the full width.

2026-11-15 16:40 PT: t1148 — ricochet is a separate random chance per collision (not every hit sprays, and a "survive" miss no longer forces a bounce). Each spray gets a random heading in the outward hemisphere and a random takeoff speed in 0.15..0.38 of its current speed, still inside the short leash.
