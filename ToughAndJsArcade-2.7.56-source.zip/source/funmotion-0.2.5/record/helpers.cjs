const fs=require('fs');
const path=require('path');
const {playwright}=require('./pw-path.cjs');

const ROOT=path.resolve(__dirname,'..');
const HTML='file://'+ROOT+'/funmotion.html';
const OUT=path.join(ROOT,'video');
const SHOTS=path.join(ROOT,'shots');
const EVI=path.join(ROOT,'evidence');

function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

async function launch(opts){
  opts=opts||{};
  const pw=playwright();
  const browser=await pw.chromium.launch({
    channel: fs.existsSync('/usr/bin/google-chrome') ? 'chrome' : undefined,
    headless: opts.headless!==false,
    args:['--ignore-certificate-errors','--autoplay-policy=no-user-gesture-required']
  });
  const viewport=opts.viewport||{width:360,height:800};
  const ctx=await browser.newContext({
    viewport,
    deviceScaleFactor: opts.dpr||2,
    hasTouch:true,
    isMobile:true,
    recordVideo: opts.record===false? undefined : {dir: opts.videoDir||OUT, size:{width:viewport.width*(opts.dpr||2), height:viewport.height*(opts.dpr||2)}},
    acceptDownloads:true
  });
  const page=await ctx.newPage();
  page.on('pageerror', e=>console.error('PAGEERROR', e.message));
  page.on('console', m=>{ if(m.type()==='error') console.error('CONSOLE', m.text()); });
  await page.goto(HTML, {waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>typeof window.__FM==='function');
  if(opts.ripple!==false) await installRipple(page);
  return {pw,browser,ctx,page};
}

async function installRipple(page){
  await page.evaluate(()=>{
    if(window.__ripple) return;
    const d=document.createElement('div');
    d.id='recFinger';
    d.style.cssText='position:fixed;z-index:99999;width:28px;height:28px;margin:-14px 0 0 -14px;border-radius:50%;pointer-events:none;border:2px solid #000080;background:rgba(0,64,200,0.35);box-shadow:0 0 0 8px rgba(0,0,128,0.15);opacity:0;transition:opacity .12s;left:0;top:0';
    document.body.appendChild(d);
    window.__ripple=(x,y,ms)=>{
      d.style.left=x+'px'; d.style.top=y+'px'; d.style.opacity='1';
      clearTimeout(d._t); d._t=setTimeout(()=>{d.style.opacity='0';}, ms||280);
    };
  });
}

async function finger(page, x, y){
  await page.evaluate(([x,y])=>{ if(window.__ripple) window.__ripple(x,y,320); }, [x,y]);
}

async function tap(page, id, hold){
  const el=page.locator('#'+id);
  await el.waitFor({state:'visible'});
  const box=await el.boundingBox();
  if(!box) throw new Error('no box '+id);
  const x=box.x+box.width/2, y=box.y+box.height/2;
  await finger(page,x,y);
  if(hold){ await page.mouse.move(x,y); await page.mouse.down(); await sleep(hold); await page.mouse.up(); }
  else await page.mouse.click(x,y);
  await sleep(180);
}

async function tapText(page, selector, text){
  const loc=page.locator(selector).filter({hasText: text}).first();
  await loc.waitFor({state:'visible', timeout:8000});
  const box=await loc.boundingBox();
  if(!box) throw new Error('no text '+text);
  const x=box.x+box.width/2, y=box.y+box.height/2;
  await finger(page,x,y);
  await page.mouse.click(x,y);
  await sleep(200);
}

async function tool(page, name){
  /* click a toolGrid button whose strong text equals name */
  const loc=page.locator('#toolGrid button').filter({has: page.locator('strong',{hasText: new RegExp('^'+name+'$')})}).first();
  /* playwright hasText on strong may be looser; use evaluate click as fallback */
  const clicked=await page.evaluate((name)=>{
    const btns=[...document.querySelectorAll('#toolGrid button')];
    const b=btns.find(b=>(b.querySelector('strong')||b).textContent.trim()===name);
    if(!b) return null;
    const r=b.getBoundingClientRect();
    return {x:r.left+r.width/2,y:r.top+r.height/2};
  }, name);
  if(!clicked) throw new Error('tool not found '+name);
  await finger(page, clicked.x, clicked.y);
  await page.mouse.click(clicked.x, clicked.y);
  await sleep(220);
}

async function stageClick(page, sx, sy, opts){
  opts=opts||{};
  const p=await page.evaluate(([x,y])=>{
    const c=document.getElementById('canvas');
    const r=c.getBoundingClientRect();
    return {x:r.left+(x/720)*r.width, y:r.top+(y/1100)*r.height};
  }, [sx,sy]);
  await finger(page,p.x,p.y);
  if(opts.drag){
    const p2=await page.evaluate(([x,y])=>{
      const c=document.getElementById('canvas');
      const r=c.getBoundingClientRect();
      return {x:r.left+(x/720)*r.width, y:r.top+(y/1100)*r.height};
    }, [opts.drag[0], opts.drag[1]]);
    await page.mouse.move(p.x,p.y);
    await page.mouse.down();
    const steps=opts.steps||8;
    for(let i=1;i<=steps;i++){
      const t=i/steps;
      await page.mouse.move(p.x+(p2.x-p.x)*t, p.y+(p2.y-p.y)*t);
      await sleep(30);
    }
    await finger(page,p2.x,p2.y);
    await page.mouse.up();
  } else {
    await page.mouse.click(p.x,p.y);
  }
  await sleep(80);
}

async function joints(){
  /* used after evaluate */
}

async function getJoints(page){
  return page.evaluate(()=>{
    const o=(project.frame.objects||[]).find(o=>o.kind==='rig');
    return o?o.points.map(p=>({x:p.x,y:p.y})):null;
  });
}

class Log {
  constructor(){ this.t0=Date.now(); this.chapters=[]; this.captions=[]; }
  now(){ return (Date.now()-this.t0)/1000; }
  chapter(id,title){ const t=this.now(); this.chapters.push({id,title,start:+t.toFixed(3)}); console.log('CHAPTER', t.toFixed(2), id, title); }
  cap(text, dur){ const t=this.now(); this.captions.push({start:t, end:t+(dur||3.2), text}); console.log('CAP', t.toFixed(2), text); }
  dump(file){
    const ch=this.chapters.map((c,i)=>({...c, end: this.chapters[i+1]? this.chapters[i+1].start : this.now()}));
    fs.writeFileSync(file, JSON.stringify({duration:this.now(), chapters:ch, captions:this.captions},null,2));
  }
}

function toSrt(captions, file){
  const fmt=s=>{
    const ms=Math.max(0,Math.round(s*1000));
    const hh=String(Math.floor(ms/3600000)).padStart(2,'0');
    const mm=String(Math.floor(ms%3600000/60000)).padStart(2,'0');
    const ss=String(Math.floor(ms%60000/1000)).padStart(2,'0');
    const mmm=String(ms%1000).padStart(3,'0');
    return `${hh}:${mm}:${ss},${mmm}`;
  };
  let out='';
  captions.forEach((c,i)=>{
    out+=(i+1)+'\n'+fmt(c.start)+' --> '+fmt(c.end)+'\n'+c.text+'\n\n';
  });
  fs.writeFileSync(file,out);
}

module.exports={sleep,launch,tap,tapText,tool,stageClick,getJoints,finger,Log,toSrt,ROOT,HTML,OUT,SHOTS,EVI,installRipple};
