exports.playwright = function(){
  const paths=[
    '/usr/local/lib/pnpm/5/.pnpm/playwright@1.63.0-alpha-2026-08-31/node_modules/playwright',
    '/usr/local/lib/pnpm/5/.pnpm/node_modules/playwright',
    'playwright'
  ];
  for(const p of paths){ try{ return require(p); }catch(e){} }
  throw new Error('playwright not found');
};
