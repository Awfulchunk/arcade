const {spawn}=require('child_process');
const fs=require('fs');
const path=require('path');

/** Wall-clock CDP screencast: keep the last JPEG and emit it at a fixed fps so
    video duration matches the script clock used for captions/chapters. */
async function startCast(page, outFile, opts){
  opts=opts||{};
  const fps=opts.fps||16;
  const w=opts.width||720, h=opts.height||1600;
  fs.mkdirSync(path.dirname(outFile),{recursive:true});
  const ff=spawn('/usr/bin/ffmpeg',[
    '-y','-f','image2pipe','-framerate',String(fps),'-vcodec','mjpeg','-i','pipe:0',
    '-an','-c:v','libx264','-pix_fmt','yuv420p','-preset','veryfast','-crf','18',
    outFile
  ],{stdio:['pipe','pipe','pipe']});
  let err='';
  ff.stderr.on('data', d=>{ err+=d.toString(); });
  const done=new Promise((resolve,reject)=>{
    ff.on('close', code=>{ if(code===0) resolve(); else reject(new Error('ffmpeg '+code+'\n'+err.slice(-2000))); });
  });
  const sess=await page.context().newCDPSession(page);
  let last=null, frames=0, updates=0;
  sess.on('Page.screencastFrame', async ev=>{
    try{ last=Buffer.from(ev.data,'base64'); updates++; }catch(e){}
    try{ await sess.send('Page.screencastFrameAck',{sessionId:ev.sessionId}); }catch(e){}
  });
  await sess.send('Page.startScreencast',{format:'jpeg', quality: opts.quality||82, everyNthFrame:1, maxWidth:w, maxHeight:h});
  const tick=setInterval(()=>{
    if(last && ff.stdin && !ff.stdin.destroyed){
      try{ ff.stdin.write(last); frames++; }catch(e){}
    }
  }, 1000/fps);
  return {
    frames(){return frames;},
    updates(){return updates;},
    async stop(){
      clearInterval(tick);
      // flush a couple of last frames
      try{ if(last){ ff.stdin.write(last); ff.stdin.write(last); } }catch(e){}
      try{ await sess.send('Page.stopScreencast'); }catch(e){}
      try{ ff.stdin.end(); }catch(e){}
      await done;
      return {frames, updates, file:outFile, bytes:fs.existsSync(outFile)?fs.statSync(outFile).size:0};
    }
  };
}
module.exports={startCast};
