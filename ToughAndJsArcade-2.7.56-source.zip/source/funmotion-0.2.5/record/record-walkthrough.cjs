#!/usr/bin/env node
/* Record a real 360×800 FunMotion 0.2.5 stick-figure walkthrough. No faked UI. */
const fs=require('fs');
const path=require('path');
const {sleep,launch,tap,tool,stageClick,getJoints,Log,toSrt,ROOT,OUT,SHOTS,EVI}=require('./helpers.cjs');
const {startCast}=require('./screencast.cjs');

(async()=>{
  fs.mkdirSync(OUT,{recursive:true});
  fs.mkdirSync(SHOTS,{recursive:true});
  fs.mkdirSync(EVI,{recursive:true});
  const {browser,ctx,page}=await launch({viewport:{width:360,height:800},dpr:2,record:false});
  const raw=path.join(OUT,'walkthrough-raw.mp4');
  const cast=await startCast(page, raw, {fps:16,width:720,height:1600});
  const log=new Log();
  let duration=0;
  const shot=async n=>{ await page.screenshot({path:path.join(SHOTS,n+'.png')}); };
  try {

  async function closeDlg(){
    const open=await page.evaluate(()=>!!document.querySelector('dialog[open]'));
    if(open){
      const box=await page.evaluate(()=>{
        const b=document.querySelector('dialog[open] [data-close], dialog[open] .title button');
        if(!b) return null; const r=b.getBoundingClientRect(); return {x:r.left+r.width/2,y:r.top+r.height/2};
      });
      if(box){ await page.mouse.click(box.x,box.y); await sleep(200); }
      else { await page.keyboard.press('Escape'); await sleep(200); }
    }
  }

  // ---------- 1 Opening ----------
  log.chapter('open','Opening · COMP 1');
  log.cap('FunMotion is a flipbook studio in a COMP 1 window.', 5);
  await sleep(1600);
  await shot('01-boot');
  log.cap('File, Undo, Redo, Settings, and Tutorial sit in the title bar.', 4.5);
  await tap(page,'file'); await sleep(1400); await shot('02-file'); await closeDlg();
  await tap(page,'settings'); await sleep(1400); await closeDlg();
  log.cap('Tabs switch the workspace: Draw, Joints, Pose, and Frames.', 4.5);
  await page.locator('[data-tab="joints"]').click(); await sleep(700);
  await page.locator('[data-tab="pose"]').click(); await sleep(700);
  await page.locator('[data-tab="frames"]').click(); await sleep(700);
  await page.locator('[data-tab="draw"]').click(); await sleep(900);
  await sleep(Math.max(0, 18000 - log.now()*1000));

  // ---------- 2 Stick + red dots ----------
  log.chapter('figures','Stick figure + red dots');
  log.cap('Start with the default Stick figure. The red dots are its joints.', 5.5);
  await page.locator('[data-tab="pose"]').click(); await sleep(300);
  await tap(page,'context'); // may click first context btn; safer:
  await page.evaluate(()=>{ const b=document.querySelector('#context button'); if(b) b.click(); });
  await sleep(400);
  // Pose / Links drawer should be open; click Figures then Stick
  const opened=await page.evaluate(()=>{
    const dlg=document.getElementById('tools');
    return !!(dlg && dlg.open);
  });
  if(!opened){
    await page.evaluate(()=> { const b=[...document.querySelectorAll('#context button')].find(x=>/Pose|Links/.test(x.textContent)); if(b)b.click(); });
    await sleep(400);
  }
  // Figures
  try{ await tool(page,'Figures'); }catch(e){
    await page.evaluate(()=>{ const b=[...document.querySelectorAll('#toolGrid button')].find(x=>/Figures/.test(x.textContent)); if(b)b.click(); });
    await sleep(400);
  }
  await tool(page,'Stick');
  await sleep(800);
  await shot('03-stick');
  let j=await getJoints(page);
  if(!j) throw new Error('Stick was not added');
  log.cap('Drag a red dot to pose the stick. This arm is waving.', 4.5);
  await stageClick(page, j[4].x, j[4].y, {drag:[j[4].x+15, j[4].y-70], steps:10});
  await sleep(600);
  j=await getJoints(page);
  await stageClick(page, j[3].x, j[3].y, {drag:[j[3].x-20, j[3].y+20], steps:8});
  await sleep(800);
  await shot('04-posed');
  await sleep(Math.max(0, 36000 - log.now()*1000));

  // ---------- 3 Drawing ----------
  log.chapter('draw','Drawing tools');
  log.cap('Draw tools paint on the same page as the stick.', 4);
  await page.locator('[data-tab="draw"]').click(); await sleep(300);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Pencil|Brush|▾/.test(x.textContent)); if(b)b.click(); });
  await sleep(400);
  await tool(page,'Pencil');
  log.cap('Pencil makes a crisp freehand line — here, a cap for the stick.', 4);
  // hat over the head
  j=await getJoints(page);
  const head=j[0];
  await stageClick(page, head.x-30, head.y-20, {drag:[head.x+30, head.y-18], steps:10});
  await stageClick(page, head.x-28, head.y-18, {drag:[head.x, head.y-40], steps:8});
  await stageClick(page, head.x, head.y-40, {drag:[head.x+28, head.y-18], steps:8});
  await sleep(400);

  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Pencil|▾/.test(x.textContent)); if(b)b.click(); });
  await sleep(300);
  await tool(page,'Brush');
  log.cap('Brush is a rounded stroke. Line, Rectangle, and Ellipse make clean shapes.', 5);
  j=await getJoints(page);
  await stageClick(page, j[2].x-40, j[2].y+130, {drag:[j[2].x+40, j[2].y+130], steps:8}); // ground-ish
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')][0].click(); });
  await sleep(250); await tool(page,'Line');
  await stageClick(page, 200, 900, {drag:[520, 900], steps:8});
  await page.evaluate(()=>{ document.querySelectorAll('#context button')[0].click(); });
  await sleep(250); await tool(page,'Rectangle');
  await stageClick(page, 80, 820, {drag:[180, 980], steps:8});
  await page.evaluate(()=>{ document.querySelectorAll('#context button')[0].click(); });
  await sleep(250); await tool(page,'Ellipse');
  await stageClick(page, 540, 820, {drag:[660, 980], steps:8});
  await sleep(400);

  await page.evaluate(()=>{ document.querySelectorAll('#context button')[0].click(); });
  await sleep(250); await tool(page,'Fill');
  log.cap('Fill floods an enclosed shape. Eyedropper picks a color from the art.', 4.5);
  await stageClick(page, 130, 900);
  await page.evaluate(()=>{ document.querySelectorAll('#context button')[0].click(); });
  await sleep(250); await tool(page,'Eyedropper');
  await stageClick(page, 130, 900);
  await sleep(400);

  await page.evaluate(()=>{ document.querySelectorAll('#context button')[0].click(); });
  await sleep(250); await tool(page,'Eraser');
  log.cap('Eraser removes ink. Select, Move, Resize, and Rotate edit whole objects.', 5);
  await stageClick(page, 600, 850, {drag:[600, 950], steps:6});

  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Select|Edit/.test(x.textContent)); if(b)b.click(); });
  await sleep(300);
  await tool(page,'Select');
  await stageClick(page, 70, 800, {drag:[200, 1000], steps:8});
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#toolGrid button, #context button')].find(x=>x.textContent.includes('Move')); /* drawer may have closed */ });
  // reopen edit if needed
  const hasMove=await page.evaluate(()=>!!document.querySelector('dialog#tools[open]'));
  if(!hasMove){
    await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Select|Edit/.test(x.textContent)); if(b)b.click(); });
    await sleep(250);
  }
  try{ await tool(page,'Move'); }catch(e){ await page.evaluate(()=>{ if(typeof setTool==='function') setTool('move'); }); }
  await stageClick(page, 130, 900, {drag:[130, 860], steps:6});
  await shot('05-draw');
  await sleep(Math.max(0, 88000 - log.now()*1000));

  // ---------- 4 Rigging ----------
  log.chapter('rig','Rigging · attach, locks, dots');
  log.cap('Rigging binds ink to joints so posing bends the drawing.', 4.5);
  await page.locator('[data-tab="draw"]').click(); await sleep(200);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Pencil|▾|Brush/.test(x.textContent)); if(b)b.click(); });
  await sleep(250);
  try{ await tool(page,'Pencil'); }catch(e){ await page.evaluate(()=>setTool('pencil')); await closeDlg(); }
  j=await getJoints(page);
  // cape from neck down the left side
  await stageClick(page, j[1].x, j[1].y, {drag:[j[1].x-70, j[2].y+40], steps:12});
  await sleep(300);
  log.cap('Place dots on ink. Joint tools can Attach, Detach, or Pin a joint.', 5);
  await page.locator('[data-tab="joints"]').click(); await sleep(300);
  await tap(page,'freeDotTool');
  j=await getJoints(page);
  // place on the cape / near neck
  await stageClick(page, j[1].x-20, j[1].y+30);
  await sleep(400);
  await tap(page,'dotSettings');
  await sleep(300);
  try{ await tool(page,'Attach selected'); }catch(e){
    await page.evaluate(()=>{ const b=[...document.querySelectorAll('#toolGrid button')].find(x=>/Attach/.test(x.textContent)); if(b)b.click(); });
  }
  await sleep(600);
  await shot('06-attach');
  log.cap('The attach bar reports bound ink. Drag the joint and the stroke bends.', 5);
  // select the new dot and drag
  const dots=await page.evaluate(()=>project.frame.objects.map((o,i)=>({i,kind:o.kind,pts:o.points,bind:!!o.binding})));
  const placed=dots.filter(d=>d.kind==='dot');
  if(placed[0]) await stageClick(page, placed[0].pts[0].x, placed[0].pts[0].y, {drag:[placed[0].pts[0].x-40, placed[0].pts[0].y+30], steps:10});
  await sleep(700);
  log.cap('Links / Lock connects two dots and can hold a length.', 4.5);
  await page.locator('[data-tab="pose"]').click(); await sleep(250);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Pose|Links/.test(x.textContent)); if(b)b.click(); });
  await sleep(300);
  try{ await tool(page,'Links / Lock'); }catch(e){
    await page.evaluate(()=>{ const b=[...document.querySelectorAll('#toolGrid button')].find(x=>/Links/.test(x.textContent)); if(b)b.click(); });
  }
  await sleep(1200);
  await shot('07-links');
  await closeDlg();
  // t1005: move a whole drawing rigidly (all joints + Follow)
  log.cap('To move a whole drawing, multi-select every red joint and turn Follow on.', 5);
  await page.locator('[data-tab="pose"]').click(); await sleep(200);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Follow/.test(x.textContent)); if(b && !/ON/.test(b.textContent)) b.click(); });
  await sleep(400);
  // multi-select all stick joints via the API so the drag is a true group translate
  await page.evaluate(()=>{
    setTool('joints');
    const i=(project.frame.objects||[]).findIndex(o=>o.kind==='rig');
    if(i>=0) window.selectDotKeys(project.frame.objects[i].points.map((_,j)=>i+':'+j));
    window.setFollowFlag(true); render(); ui();
  });
  await sleep(500);
  let jAll=await getJoints(page);
  if(jAll){
    log.cap('Now drag — the stick (and attached ink) slides as one piece, with no bending.', 5);
    await stageClick(page, jAll[2].x, jAll[2].y, {drag:[jAll[2].x+50, jAll[2].y-10], steps:12});
    await sleep(800);
    await shot('07b-move-whole');
  }
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Follow/.test(x.textContent)); if(b && /ON/.test(b.textContent)) b.click(); });
  await sleep(Math.max(0, 140000 - log.now()*1000));

  // ---------- 5 Frames + onion ----------
  log.chapter('frames','Onion, frames, posing');
  log.cap('Ghost shows the previous pose. Next Frame copies the stick so you can pose the next step.', 5.5);
  await page.locator('[data-tab="frames"]').click(); await sleep(200);
  const ghostOff=await page.evaluate(()=>!project.settings.onion);
  if(ghostOff) await tap(page,'onion');
  await sleep(400);
  await shot('08-onion');
  // pose a walk across 3 new frames
  async function poseStep(k){
    const p=await getJoints(page);
    if(!p) return;
    const s=k===0?1:k===1?-1:0.4;
    await stageClick(page, p[4].x, p[4].y, {drag:[p[4].x+18*s, p[4].y-8], steps:6});
    await stageClick(page, p[3].x, p[3].y, {drag:[p[3].x-18*s, p[3].y-4], steps:6});
    await stageClick(page, p[6].x, p[6].y, {drag:[p[6].x+16*s, p[6].y+4], steps:6});
    await stageClick(page, p[5].x, p[5].y, {drag:[p[5].x-16*s, p[5].y+4], steps:6});
  }
  log.cap('Pose a step, then Save Pose + Next Frame. Repeat to build a walk.', 5);
  await page.locator('[data-tab="pose"]').click(); await sleep(200);
  await poseStep(0);
  await tap(page,'next');
  await sleep(700);
  await poseStep(1);
  await tap(page,'next');
  await sleep(700);
  await poseStep(2);
  await tap(page,'next');
  await sleep(600);
  await shot('09-frames');
  await sleep(Math.max(0, 180000 - log.now()*1000));

  // ---------- 6 Play ----------
  log.chapter('play','Playback');
  log.cap('Play flips through the frames. This is the stick figure walk.', 5);
  await tap(page,'play');
  await sleep(5000);
  await shot('10-play');
  // stop
  const playing=await page.evaluate(()=>!!window.__FM().playing);
  if(playing) await tap(page,'play');
  await sleep(Math.max(0, 198000 - log.now()*1000));

  // ---------- 7 View ----------
  log.chapter('view','Pan and zoom');
  log.cap('Zoom in with +, pan the paper, then Fit to see the whole page.', 5);
  await tap(page,'plus'); await sleep(400);
  await tap(page,'plus'); await sleep(400);
  await tap(page,'panRight'); await sleep(400);
  await tap(page,'panLeft'); await sleep(400);
  await tap(page,'plus'); await sleep(300);
  await tap(page,'minus'); await sleep(400);
  await shot('11-zoom');
  await tap(page,'fit'); await sleep(800);
  await sleep(Math.max(0, 216000 - log.now()*1000));

  // ---------- 8 Save / Open ----------
  log.chapter('file','Save and open');
  log.cap('File → Save project writes an editable JSON. Open brings it back.', 5);
  await tap(page,'file');
  await sleep(600);
  let saved=null;
  try{
    const [dl]=await Promise.all([
      page.waitForEvent('download',{timeout:8000}),
      page.click('#saveProject')
    ]);
    saved=path.join(OUT,'demo-stick.funmotion.json');
    await dl.saveAs(saved);
  }catch(e){ console.warn('save download', e.message); await page.click('#saveProject').catch(()=>{}); }
  await sleep(800);
  await closeDlg();
  log.cap('New project clears the stage. Open reloads the stick animation.', 4.5);
  await tap(page,'file'); await sleep(300);
  await page.click('#newProject'); await sleep(400);
  const yes=await page.$('#yes');
  if(yes) await page.click('#yes');
  await sleep(600);
  if(saved && fs.existsSync(saved)){
    await tap(page,'file'); await sleep(300);
    await page.setInputFiles('#loadIn', saved);
    await sleep(400);
    const yes2=await page.$('#yes');
    if(yes2) await page.click('#yes');
    await sleep(800);
  }
  await shot('12-open');
  await closeDlg();
  await sleep(Math.max(0, 234000 - log.now()*1000));

  // ---------- 9 Export ----------
  log.chapter('export','GIF and MP4 export');
  log.cap('Export GIF makes a real animated GIF of the stick walk.', 4.5);
  await tap(page,'file'); await sleep(400);
  try{
    const [dl]=await Promise.all([
      page.waitForEvent('download',{timeout:20000}),
      page.click('#gif')
    ]);
    await dl.saveAs(path.join(OUT,'demo-stick.gif'));
  }catch(e){ console.warn('gif', e.message); }
  await sleep(800);
  log.cap('Export video records MP4 when the browser supports it, otherwise WebM.', 5);
  await tap(page,'file'); await sleep(400);
  try{
    const [dl]=await Promise.all([
      page.waitForEvent('download',{timeout:25000}),
      page.click('#video')
    ]);
    const name=dl.suggestedFilename()||'demo-stick.mp4';
    await dl.saveAs(path.join(OUT,name));
  }catch(e){ console.warn('video export', e.message); }
  await sleep(800);
  await closeDlg();
  log.cap('Hold any tool for a looping demo. Tutorial plays this whole walkthrough.', 5);
  // show hold tip on Tutorial? better: open draw tools and hold Pencil
  await page.locator('[data-tab="draw"]').click(); await sleep(200);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('#context button')].find(x=>/Pencil|▾|Brush/.test(x.textContent)); if(b)b.click(); });
  await sleep(400);
  const pencil=await page.evaluate(()=>{
    const b=[...document.querySelectorAll('#toolGrid button')].find(x=>(x.querySelector('strong')||x).textContent.trim()==='Pencil');
    if(!b) return null; const r=b.getBoundingClientRect(); return {x:r.left+r.width/2,y:r.top+r.height/2};
  });
  if(pencil){
    await page.mouse.move(pencil.x,pencil.y);
    await page.mouse.down();
    await sleep(900);
    await page.mouse.up();
    await sleep(1800);
    await shot('13-holdtip');
    await page.click('#holdTipClose').catch(()=>{});
  }
  await closeDlg();
  await sleep(1200);
  await shot('14-end');

  duration=log.now();
  console.log('DURATION_S', duration.toFixed(2));
  log.dump(path.join(EVI,'walkthrough-log.json'));
  toSrt(log.captions, path.join(OUT,'captions.srt'));
  // default chapter sidecar (times from this run)
  const data=JSON.parse(fs.readFileSync(path.join(EVI,'walkthrough-log.json'),'utf8'));
  fs.writeFileSync(path.join(ROOT,'funmotion-tutorial-chapters.json'), JSON.stringify({chapters:data.chapters.map(c=>({id:c.id,title:c.title,start:+Number(c.start).toFixed(3)}))},null,2));

  } finally {
  if(!duration){ duration=log.now(); try{ log.dump(path.join(EVI,'walkthrough-log.json')); toSrt(log.captions, path.join(OUT,'captions.srt')); }catch(e){} }
  const castInfo=await cast.stop().catch(e=>{console.error('cast stop',e); return {error:String(e)};});
  console.log('RAW', raw, castInfo);
  await page.close();
  await ctx.close();
  await browser.close();
  fs.writeFileSync(path.join(EVI,'walkthrough-meta.json'), JSON.stringify({duration, raw:castInfo, errors:'see stdout'},null,2));
  if(duration<180 || duration>320){
    console.warn('DURATION_OUT_OF_RANGE (want 180-300s, hard max ~320 before re-time)', duration);
  }
  console.log('WALKTHROUGH_DONE');
  }
})().catch(e=>{ console.error('FAIL', e); process.exit(1); });
