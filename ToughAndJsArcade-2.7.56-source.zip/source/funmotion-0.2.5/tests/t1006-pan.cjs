const {launch,sleep,SHOTS}=require('../record/helpers.cjs');
const path=require('path');
const fs=require('fs');
const assert=require('assert');
(async()=>{
  fs.mkdirSync(SHOTS,{recursive:true});
  const {browser,page}=await launch({record:false,dpr:1,viewport:{width:360,height:800}});
  let n=0; const pass=(name)=>{n++; console.log('PASS',name)};
  const geo=()=>page.evaluate(()=>{
    const c=document.getElementById('canvas');
    return {pan:__FM().pan, zoom:__FM().zoom,
      left:parseFloat(c.style.left), top:parseFloat(c.style.top),
      h:Number(document.getElementById('horizontal').value),
      v:Number(document.getElementById('vertical').value)};
  });
  for(let i=0;i<6;i++) await page.click('#plus');
  await sleep(100);
  const g0=await geo();
  assert(Math.abs(g0.zoom-3.814697265625)<1e-6, 'zoom 381% (~384%)');
  pass('six + clicks reach ~381% (1.25^6); + zooms in');

  // Horizontal arrows: right arrow = drawing moves left = shows further right
  await page.click('#panRight');
  const gR=await geo();
  assert(Math.abs((gR.left-g0.left)+12)<0.01, 'right arrow dLeft='+(gR.left-g0.left));
  assert(gR.h>g0.h, 'right arrow moves scrollbar thumb right');
  pass('right arrow moves the drawing left (scrollbar: shows content further right)');
  await page.click('#panLeft');
  const gL=await geo();
  assert(Math.abs(gL.left-g0.left)<0.05, 'left arrow returns toward start');
  pass('left arrow moves the drawing right (shows content further left)');

  // Horizontal slider to the right
  const beforeS=await geo();
  await page.$eval('#horizontal', el=>{el.value='800'; el.dispatchEvent(new Event('input',{bubbles:true}));});
  await sleep(50);
  const afterS=await geo();
  assert(afterS.left<beforeS.left-10, 'slider right should reduce canvas left, got '+afterS.left+' from '+beforeS.left);
  assert(afterS.h>beforeS.h, 'slider value increased');
  pass('horizontal slider right moves the drawing left');

  // Click visual top/bottom of vertical scrollbar
  await page.click('#fit');
  for(let i=0;i<6;i++) await page.click('#plus');
  const vbox=await page.evaluate(()=>{const r=document.getElementById('vertical').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top,h:r.height};});
  await page.mouse.click(vbox.x, vbox.y+vbox.h*0.15);
  await sleep(80);
  const top=await geo();
  assert(top.pan.y>0, 'clicking the top of the vertical scrollbar should show upper paper (pan.y>0), got '+top.pan.y);
  pass('vertical scrollbar: click/thumb toward the top shows upper paper');
  await page.click('#fit');
  for(let i=0;i<6;i++) await page.click('#plus');
  await page.mouse.click(vbox.x, vbox.y+vbox.h*0.85);
  await sleep(80);
  const bot=await geo();
  assert(bot.pan.y<0, 'clicking the bottom should show lower paper (pan.y<0), got '+bot.pan.y);
  pass('vertical scrollbar: click/thumb toward the bottom shows lower paper');

  // Hand drag must still follow the finger (t949)
  await page.click('#fit');
  for(let i=0;i<6;i++) await page.click('#plus');
  await page.evaluate(()=>setTool('hand'));
  const b=await geo();
  const st=await page.evaluate(()=>{const r=document.getElementById('stage').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};});
  await page.mouse.move(st.x,st.y); await page.mouse.down(); await page.mouse.move(st.x+36,st.y); await page.mouse.up();
  await sleep(50);
  const a=await geo();
  assert(Math.abs((a.left-b.left)-36)<1, 'hand drag right should move paper right, dLeft='+(a.left-b.left));
  pass('hand / finger-drag pan still follows the finger (t949)');

  await page.screenshot({path:path.join(SHOTS,'t1006-pan-verified.png')});
  await browser.close();
  console.log(n+' t1006 pan tests passed');
})().catch(e=>{console.error(e); process.exit(1)});
