const fs=require('fs'),vm=require('vm'),assert=require('assert');
const HTML=require('path').resolve(__dirname,'../funmotion.html');
const h=fs.readFileSync(HTML,'utf8');
let b={Uint8Array,Uint8ClampedArray,console,Math,JSON,Set,Map};b.globalThis=b;vm.createContext(b);
vm.runInContext([...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(x=>x[1]).find(x=>x.includes('class MotionProject')),b);
const {MotionProject,applySkin}=b.FMCore;
let n=0;function test(name,f){f();console.log('PASS',name);n++}

function arrow(){
  const q=new MotionProject();
  const pts=[];
  for(let i=0;i<35;i++) pts.push({x:80+i*8,y:400});
  pts.push({x:80+34*8,y:400},{x:80+34*8-16,y:380},{x:80+35*8,y:400},{x:80+34*8-16,y:420},{x:80+34*8,y:400});
  q.add({kind:'path',points:pts,color:'#111111',width:4,opacity:1});
  for(const x of [80,160,240,320]) q.placeJoint({x,y:400},8);
  return q;
}
function relShape(pts, origin){
  return pts.map(p=>({x:p.x-origin.x,y:p.y-origin.y}));
}

test('multi-select all 4 joints + Follow drag translates every stroke point by the same delta (max error < 0.5 px)',()=>{
  const q=arrow();
  const before=q.frame.objects[0].points.map(p=>({x:p.x,y:p.y}));
  const shape0=relShape(before, before[0]);
  q.moveJoints(['1:0','2:0','3:0','4:0'], 30, 20, true);
  const after=q.frame.objects[0].points;
  const errs=after.map((p,i)=>Math.hypot(p.x-(before[i].x+30), p.y-(before[i].y+20)));
  const maxErr=Math.max(...errs);
  assert(maxErr<0.5, 'max point error '+maxErr);
  const shape1=relShape(after, after[0]);
  for(let i=0;i<shape0.length;i++){
    const e=Math.hypot(shape1[i].x-shape0[i].x, shape1[i].y-shape0[i].y);
    assert(e<0.5, 'shape changed at '+i+' err='+e);
  }
});

test('partial multi-select still bends: unselected joints keep their span from translating fully',()=>{
  const q=arrow();
  const before=q.frame.objects[0].points.map(p=>({x:p.x,y:p.y}));
  // move only the two tip-side joints; the base joints stay
  q.moveJoints(['3:0','4:0'], 0, 40, true);
  const after=q.frame.objects[0].points;
  const dy=after.map((p,i)=>p.y-before[i].y);
  assert(Math.abs(dy[0])<5, 'base should stay near rest, dy='+dy[0]);
  assert(Math.max(...dy)>20, 'ink near the moved joints should rise');
  const mid=dy.filter(v=>v>5 && v<35);
  assert(mid.length>0, 'shaft should contain intermediate (bent) deltas, got '+JSON.stringify(dy.filter((_,i)=>i%8===0)));
  const maxErrIfRigid=Math.max(...after.map((p,i)=>Math.hypot(p.x-before[i].x, p.y-(before[i].y+40))));
  assert(maxErrIfRigid>0.5, 'partial select must not be a rigid +40 translate, maxErr='+maxErrIfRigid);
});

test('Rotate +15° with all joints multi-selected rotates the stroke rigidly (max error < 0.5 px)',()=>{
  const q=arrow();
  const before=q.frame.objects[0].points.map(p=>({x:p.x,y:p.y}));
  const joints=q.frame.objects.filter(o=>o.kind==='dot'&&o.binding);
  const cx=joints.reduce((s,o)=>s+o.points[0].x,0)/joints.length;
  const cy=joints.reduce((s,o)=>s+o.points[0].y,0)/joints.length;
  const a=Math.PI/12, cos=Math.cos(a), sin=Math.sin(a);
  const rot=(p)=>({x:cx+(p.x-cx)*cos-(p.y-cy)*sin, y:cy+(p.x-cx)*sin+(p.y-cy)*cos});
  for(const j of joints){ Object.assign(j.points[0], rot(j.points[0])); }
  applySkin(q.frame);
  const after=q.frame.objects[0].points;
  const errs=after.map((p,i)=>{const q=rot(before[i]); return Math.hypot(p.x-q.x,p.y-q.y)});
  const maxErr=Math.max(...errs);
  assert(maxErr<0.5, 'rotate max error '+maxErr);
});

test('single-joint pose still uses falloff (far end does not rigidly follow)',()=>{
  const q=arrow();
  const before=q.frame.objects[0].points.map(p=>({x:p.x,y:p.y}));
  q.moveJoints(['4:0'], 0, 50, false);
  assert(Math.abs(q.frame.objects[0].points[0].y-before[0].y)<5, 'far base should stay');
  assert(q.frame.objects[0].points.some(p=>p.y>before[0].y+20), 'near tip joint ink should move');
});

console.log(n+' t1005 rigid-move tests passed');
