/* Node VM + intentionally nonvisual fake DOM/canvas. Tests actual event wiring,
   not browser layout, raster quality, video codecs, or touch on a real device. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('/workspace/game/build-funmotion-tutorial/funmotion.html','utf8');
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
class Classes{constructor(){this.a=new Set()}toggle(k,b){if(b===undefined)b=!this.a.has(k);b?this.a.add(k):this.a.delete(k)}contains(k){return this.a.has(k)}}
class Element{
 constructor(tag='div',id=''){this.tagName=tag;this.id=id;this.children=[];this.style={};this.dataset={};this.classList=new Classes();this.events={};this.open=false;this.width=720;this.height=1100;this.clientHeight=300;this.clientWidth=340;this.value='';this.files=[];this.disabled=false}
 append(...v){this.children.push(...v)}appendChild(v){this.append(v);return v}replaceChildren(...v){this.children=v}setAttribute(k,v){this[k]=v}addEventListener(n,f){this.events[n]=f}remove(){}showModal(){this.open=true}close(){this.open=false}click(){this.onclick?.({target:this})}setPointerCapture(){}matches(){return false}
 getBoundingClientRect(){let width=this.id==='canvas'?parseFloat(this.style.width)||340:340,height=this.id==='canvas'?parseFloat(this.style.height)||300:300;return {width,height,left:0,top:0}}
 getContext(){return context}toDataURL(){return 'data:image/png;base64,AAAA'}toBlob(f){f(new Blob(['png']))}
}
let context=new Proxy({getImageData(x,y,w,h){return{data:new Uint8ClampedArray(w*h*4).fill(255),width:w,height:h}},measureText(){return{width:20}}},{get(o,k){return k in o?o[k]:()=>{}}});
function launch(query=''){
 const els={};for(const m of html.matchAll(/<([\w-]+)[^>]*\bid="([^"]+)"[^>]*>/g))els[m[2]]=new Element(m[1],m[2]);
 const tabs=['draw','pose','frames','joints'].map(t=>{let b=new Element('button');b.dataset.tab=t;return b});
 const pans=['up','down','left','right'].map(t=>{let b=new Element('button');b.dataset.pan=t;return b});
 const closers=[...html.matchAll(/<button[^>]*data-close/g)].map(()=>new Element('button'));
 const dialogs=()=>Object.values(els).filter(e=>e.tagName==='dialog'&&e.open);
 const doc={body:new Element('body'),createElement:t=>new Element(t),getElementById:id=>{assert(els[id],'Missing element '+id);return els[id]},querySelectorAll:q=>q==='[data-tab]'?tabs:q==='[data-pan]'?pans:q==='[data-close]'?closers:q==='dialog[open]'?dialogs():[],querySelector:q=>q==='dialog[open]'?dialogs()[0]||null:null,addEventListener(){}};
 class Image{constructor(){this.complete=true;this.naturalWidth=720;this.width=720;this.height=1100}addEventListener(){}}
 let clock=0;const saved=[],scheduled=[],downloads=[];const originalCreate=doc.createElement;doc.createElement=t=>{let el=originalCreate(t);if(t==='a')el.click=()=>downloads.push(el.download);return el};
 const box={performance:{now:()=>clock},document:doc,console,Uint8Array,Uint8ClampedArray,Math,JSON,Set,Map,Blob,URL:{createObjectURL:b=>{saved.push(b);return'blob:test'},revokeObjectURL(){}},URLSearchParams,location:{search:query},Image,FileReader:class{},HTMLCanvasElement:Element,ResizeObserver:class{observe(){}},setTimeout:(f,ms)=>{if(ms<2000){clock+=ms;f()}return 1},clearTimeout(){},setInterval:f=>{scheduled.push(f);return 1},clearInterval(){},addEventListener(){}};box.window=box;box.globalThis=box;vm.createContext(box);for(const s of scripts)vm.runInContext(s,box);return{els,tabs,pans,box,saved,scheduled,downloads,click(id){assert(!els[id].disabled,'Disabled '+id);els[id].click()},state:()=>box.__FM(),tool(name){let b=els.toolGrid.children.find(b=>b.children[0]?.textContent===name);if(!b){let category=els.toolGrid.children.find(b=>b.children[0]?.textContent===(['Stick','Circle','Square','Triangle','Star'].includes(name)?'Figures':'Joint tools'));if(category){category.click();b=els.toolGrid.children.find(b=>b.children[0]?.textContent===name)}}if(!b&&name==='Joints')b=els.toolGrid.children.find(b=>b.children[0]?.textContent==='Select joint');if(!b&&name==='Dot')b=els.toolGrid.children.find(b=>b.children[0]?.textContent==='Place dots');assert(b,'Tool not found '+name);b.click()}};
}
function draw(env,a,b){const cv=env.els.canvas;const e=(x,y)=>({pointerId:1,button:0,clientX:x,clientY:y});cv.events.pointerdown(e(...a));cv.events.pointermove(e(...b));cv.events.pointerup(e(...b))}
module.exports={launch,draw};
if(require.main===module){
let count=0;function test(name,f){f();console.log('PASS',name);count++}

test('Setup groups animation and drawing rather than one scrolling list',()=>{let e=launch();e.click('settings');let content=e.els.setupContent;assert(content.children.filter(c=>c.tagName==='label').length<=4);assert(content.children[0].children.some(b=>b.textContent==='Drawing'));content.children[0].children.find(b=>b.textContent==='Drawing').click();assert(content.children.filter(c=>c.tagName==='label').length<=3)});
test('DOM boots blank and all fixed controls wire',()=>{let e=launch();assert.equal(e.state().objects,0);for(const id of ['file','settings','next','play','pan','plus','minus','undo','redo','prevFrame','nextExisting','onion'])assert.equal(typeof e.els[id].onclick,'function')});
test('pencil stroke next undo redo through actual handlers',()=>{let e=launch();draw(e,[40,40],[70,80]);assert.equal(e.state().objects,1);e.click('next');assert.equal(e.state().frames,2);assert.equal(e.state().objects,1);e.click('undo');assert.equal(e.state().frames,1);e.click('redo');assert.equal(e.state().frames,2)});
test('pan view and zoom wiring',()=>{let e=launch();e.click('plus');assert(e.state().zoom>1);e.click('pan');e.pans.find(b=>b.dataset.pan==='down').click();assert(e.state().pan.y<0);e.pans.find(b=>b.dataset.pan==='up').click();assert.equal(e.state().pan.y,0);e.click('fit');assert.equal(e.state().zoom,1)});
test('pose insert removable, free dots mode, joints',()=>{let e=launch();e.tabs[1].click();e.els.context.children[0].click();e.tool('Stick');assert.equal(e.state().objects,1);assert.equal(e.state().tool,'joints');e.tabs[0].click();e.els.context.children[2].click();e.tool('Delete');assert.equal(e.state().objects,0);e.click('undo');assert.equal(e.state().objects,1)});
test('every Draw tool selects and paints/selects without exceptions',()=>{let e=launch();for(const name of ['Pencil','Brush','Eraser','Line','Rectangle','Ellipse','Select','Move','Resize','Rotate','Eyedropper']){e.els.context.children[0].click();e.tool(name);draw(e,[40,40],[70,80])}assert(e.state().objects>=6)});
test('eyedropper updates both custom color and selected palette swatch',()=>{let e=launch();e.els.context.children[0].click();e.tool('Eyedropper');draw(e,[40,40],[40,40]);assert.equal(e.els.color.value,'#ffffff');assert(e.els.swatches.children.find(b=>b.style.background==='#ffffff').classList.contains('active'))});
test('pointer cancellation never commits unfinished strokes',()=>{let e=launch();let cv=e.els.canvas;cv.events.pointerdown({pointerId:1,button:0,clientX:50,clientY:50});cv.events.pointercancel();assert.equal(e.state().objects,0)});
test('fixture is opt-in; two frames with rig and rectangle',()=>{let e=launch('?proof=comp1');assert.equal(e.state().frames,2);assert.equal(e.state().objects,2);assert.equal(e.state().index,1)});
test('play cycles frame then stops',()=>{let e=launch('?proof=comp1');e.click('play');assert(e.state().playing);e.scheduled[0]();assert.equal(e.state().index,0);e.click('play');assert(!e.state().playing)});
test('project download is JSON not fake export',()=>{let e=launch('?proof=comp1');e.click('saveProject');assert.equal(e.saved[0].type,'application/json')});
test('visible button target declarations use CSS >=44 (not raster 2x mocks)',()=>{assert(/min-width:44px;min-height:44px/.test(html));assert(/#next\{[^}]*min-height:52px/.test(html));assert(!/overflow-x:auto/.test(html))});
// Produce a real, deterministic GIF for an independent Pillow decoder check.
let data1=new Uint8ClampedArray(20*20*4),data2=new Uint8ClampedArray(data1.length);for(let i=0;i<400;i++){data1.set([255,0,0,255],i*4);data2.set([0,255,0,255],i*4)}const e=launch();fs.writeFileSync(__dirname+'/fixture-real.gif',e.box.FMCore.encodeGIF(20,20,[data1,data2],8));
console.log(`${count} UI VM tests passed (nonvisual)`);

}
