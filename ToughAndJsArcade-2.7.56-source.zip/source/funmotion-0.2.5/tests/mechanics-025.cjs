const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('/workspace/game/build-funmotion-tutorial/funmotion.html','utf8');
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
const box={console,Uint8Array,Uint8ClampedArray,Math,JSON,Set,Map};box.globalThis=box;vm.createContext(box);
// Headless core must be independent of DOM.
const core=scripts.find(s=>s.includes('class MotionProject'));
assert(core,'Missing independently testable MotionProject core');vm.runInContext(core,box);
const {MotionProject,panView,floodPixels,fillMask,encodeGIF}=box.FMCore;
let passed=0;function test(name,f){f();console.log('PASS',name);passed++}
const obj=()=>({kind:'path',points:[{x:10,y:20},{x:30,y:40}],color:'#123456',width:4,opacity:1});
test('blank boot, no seeded figure',()=>assert.equal(new MotionProject().frame.objects.length,0));
test('add undo redo',()=>{let p=new MotionProject();p.add(obj());assert.equal(p.frame.objects.length,1);p.undo();assert.equal(p.frame.objects.length,0);p.redo();assert.equal(p.frame.objects.length,1)});
test('new edits invalidate redo',()=>{let p=new MotionProject();p.add(obj());p.undo();p.add(obj());assert.equal(p.redo(),false)});
test('next frame copies pose independently and leaves previous ghost source',()=>{let p=new MotionProject();p.add(obj());p.next();assert.equal(p.index,1);assert.equal(p.frames.length,2);p.frame.objects[0].points[0].x=99;assert.equal(p.frames[0].objects[0].points[0].x,10);assert.equal(p.previous,p.frames[0])});
test('solid off keeps rigs but does not copy freehand',()=>{let p=new MotionProject();p.add(obj());p.add({kind:'rig',points:[{x:1,y:1}],bones:[]});p.settings.solid=false;p.next();assert.equal(p.frame.objects.length,1);assert.equal(p.frame.objects[0].kind,'rig')});
test('next undo restores frame topology and edit index',()=>{let p=new MotionProject();p.next();p.undo();assert.equal(p.frames.length,1);assert.equal(p.index,0);p.redo();assert.equal(p.frames.length,2)});
test('delete selected removes stick completely and is undoable',()=>{let p=new MotionProject();p.add({kind:'rig',points:[{x:1,y:1}],bones:[]});p.remove([0]);assert.equal(p.frame.objects.length,0);p.undo();assert.equal(p.frame.objects.length,1)});
test('clear keeps animation frames',()=>{let p=new MotionProject();p.add(obj());p.next();p.clear();assert.equal(p.frame.objects.length,0);assert.equal(p.frames[0].objects.length,1)});
test('move resize rotate points including rig',()=>{let p=new MotionProject();p.add(obj());p.transform([0],'move',5,-5);assert.equal(p.frame.objects[0].points[0].x,15);p.transform([0],'scale',2);assert.equal(p.frame.objects[0].points[0].x,5);p.transform([0],'rotate',Math.PI);assert(Math.abs(p.frame.objects[0].points[0].x-45)<0.001)});
test('pan Down decreases canvas offset; Up increases it',()=>{assert.equal(panView({x:0,y:0},'down',40).y,-40);assert.equal(panView({x:0,y:0},'up',40).y,40);assert.equal(panView({x:0,y:0},'right',40).x,-40)});
test('flood respects boundary; no-op same color; opacity',()=>{let a=new Uint8ClampedArray([0,0,0,255,255,255,255,255,0,0,0,255]);assert.equal(floodPixels(a,3,1,0,0,[255,0,0,255]),1);assert.equal(a[8],0);assert.equal(floodPixels(a,3,1,0,0,[255,0,0,255]),0)});
test('JSON round trip preserves frames and validates malformed input atomically',()=>{let p=new MotionProject();p.add(obj());p.next();let q=new MotionProject();q.load(p.serialize());assert.equal(q.frames.length,2);let before=q.serialize();assert.throws(()=>q.load('{"frames":[]}'));assert.equal(q.serialize(),before);assert.throws(()=>q.load(JSON.stringify({format:'FunMotion',version:'0.2.0',frames:[{objects:[{kind:'path',points:[{x:null,y:2}]}]}]})))});
test('GIF is real GIF89a with animation extension and trailer',()=>{const data=new Uint8ClampedArray(4*4*4).fill(255);let gif=encodeGIF(4,4,[data,data],12);assert.equal(String.fromCharCode(...gif.slice(0,6)),'GIF89a');assert.equal(gif[gif.length-1],59);assert(Buffer.from(gif).includes(Buffer.from('NETSCAPE2.0')))});
test('fill creates transparent mask outside filled region, preserving onions and editable art',()=>{assert.equal(typeof fillMask,'function');let a=new Uint8ClampedArray([255,255,255,255,0,0,0,255]);let result=fillMask(a,2,1,0,0,[255,0,0,255]);assert.equal(result.count,1);assert.equal(result.data[3],255);assert.equal(result.data[7],0);assert.equal(a[0],255)});
test('malformed rig head and incomplete ellipse reject without corrupting document',()=>{let p=new MotionProject();for(const o of [{kind:'rig',points:[{x:1,y:1}],bones:[],head:5},{kind:'ellipse',points:[{x:1,y:1}]}]){assert.throws(()=>p.load(JSON.stringify({format:'FunMotion',frames:[{objects:[o]}]})))}});
test('large freehand selections transform without argument-spread overflow',()=>{let p=new MotionProject();let points=Array.from({length:150000},(_,i)=>({x:i%720,y:i%1100}));p.frame.objects=[{...obj(),points}];p.transform([0],'move',2,3);assert.equal(p.frame.objects[0].points[149999].x,149999%720+2)});
console.log(`${passed} mechanics tests passed`);
