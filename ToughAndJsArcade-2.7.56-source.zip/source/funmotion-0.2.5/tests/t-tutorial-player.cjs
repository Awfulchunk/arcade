const {playwright}=require('../record/pw-path.cjs');
const path=require('path');
const fs=require('fs');
const SHOTS=path.resolve(__dirname,'../shots');
fs.mkdirSync(SHOTS,{recursive:true});
const URL='file:///workspace/game/build-funmotion-tutorial/funmotion.html';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

async function runAt(page, size){
  const tag=size.width+'x'+size.height;
  await page.setViewportSize(size);
  await page.goto(URL,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>typeof window.__FM==='function');
  const boot=await page.evaluate(()=>__FM());
  if(boot.ver!=='0.2.5') throw new Error('version '+boot.ver);
  const btn=await page.evaluate(()=>{const b=document.getElementById('tutorial'); const r=b.getBoundingClientRect(); return {w:r.width,h:r.height,t:b.textContent,visible:r.width>0&&r.height>0};});
  if(!btn.visible) throw new Error('Tutorial button not visible at '+tag);
  await page.screenshot({path:path.join(SHOTS,'tutorial-button-'+tag+'.png')});

  await page.click('#tutorial');
  await sleep(400);
  const open=await page.evaluate(()=>__FM());
  if(!open.tutorialOpen) throw new Error('tutorial did not open');
  // wait for video metadata
  await page.waitForFunction(()=>{const v=document.getElementById('tutVideo'); return v && v.readyState>=1 && isFinite(v.duration) && v.duration>60;}, {timeout:15000});
  const meta=await page.evaluate(()=>{const v=document.getElementById('tutVideo'); return {dur:v.duration, paused:v.paused, w:v.videoWidth, h:v.videoHeight, chapters:__FM().chapters, scroll:document.documentElement.scrollHeight<=innerHeight+1};});
  if(meta.dur<180 || meta.dur>320) throw new Error('unexpected duration '+meta.dur);
  if(!meta.scroll) throw new Error('page scrolled at '+tag);
  // play (openTutorial may already have started it)
  await page.evaluate(()=>{ const v=document.getElementById('tutVideo'); v.muted=true; if(v.paused) return v.play().catch(e=>String(e)); });
  await sleep(800);
  let playing=await page.evaluate(()=>{const v=document.getElementById('tutVideo'); return {paused:v.paused, t:v.currentTime, err:v.error&&v.error.message};});
  if(playing.paused){
    await page.click('#tutPlay');
    await sleep(800);
    playing=await page.evaluate(()=>{const v=document.getElementById('tutVideo'); return {paused:v.paused, t:v.currentTime, err:v.error&&v.error.message};});
  }
  if(playing.paused) throw new Error('video did not play '+JSON.stringify(playing));
  await page.screenshot({path:path.join(SHOTS,'tutorial-player-'+tag+'.png')});
  // pause
  await page.click('#tutPlay');
  await sleep(200);
  // chapter jump: figures (index 1)
  await page.selectOption('#tutChapter', '1');
  await sleep(400);
  const atFig=await page.evaluate(()=>{const v=document.getElementById('tutVideo'); return {t:v.currentTime, ch:document.getElementById('tutChapter').value};});
  if(Math.abs(atFig.t-18)>1.5) throw new Error('chapter seek failed '+atFig.t);
  // Tools tab
  await page.locator('[data-tuttab="tools"]').click({force:true});
  await sleep(600);
  const tools=await page.evaluate(()=>{
    const cards=[...document.querySelectorAll('#tutToolGrid .tutCard')];
    return {tab:__FM().tutorialTab, n:cards.length, names:cards.map(c=>c.querySelector('strong')&&c.querySelector('strong').textContent), canvases:cards.filter(c=>c.querySelector('canvas')).length};
  });
  if(tools.tab!=='tools' || tools.n<1 || tools.canvases!==tools.n) throw new Error('tools tab '+JSON.stringify(tools));
  await page.screenshot({path:path.join(SHOTS,'tutorial-tools-'+tag+'.png')});
  // tap first tool — should jump to its chapter (pencil -> draw, start 36)
  await page.click('#tutToolGrid .tutCard');
  await sleep(500);
  const jumped=await page.evaluate(()=>{
    const v=document.getElementById('tutVideo');
    return {tab:__FM().tutorialTab, t:v.currentTime};
  });
  if(jumped.tab!=='watch') throw new Error('tap tool should jump to Watch');
  if(jumped.t<30 || jumped.t>50) throw new Error('pencil should jump to draw chapter ~36s, got '+jumped.t);
  // close
  await page.click('#tutorialClose');
  await sleep(200);
  const closed=await page.evaluate(()=>__FM());
  if(closed.tutorialOpen) throw new Error('did not close');
  // hold-tip
  await page.evaluate(()=>__FMHold.show('stick'));
  await sleep(500);
  const hold=await page.evaluate(()=>{
    const el=document.getElementById('holdTip');
    const r=el.getBoundingClientRect();
    return {open:__FM().holdOpen, tip:__FM().holdTip, w:r.width, h:r.height, y:r.y, vis:!!(el&&el.classList.contains('show')&&r.height>40)};
  });
  if(!hold.open || !hold.vis) throw new Error('hold tip missing '+JSON.stringify(hold));
  await page.screenshot({path:path.join(SHOTS,'tutorial-hold-'+tag+'.png')});
  await page.evaluate(()=>__FMHold.hide());
  // overflow check
  const ov=await page.evaluate(()=>({sh:document.documentElement.scrollHeight, ih:innerHeight, bh:document.body.scrollHeight}));
  if(ov.sh>ov.ih+2) throw new Error('page scroll '+JSON.stringify(ov));
  return {tag, btn, meta, playing, atFig, tools, jumped, hold, ov};
}

(async()=>{
  const pw=playwright();
  const browser=await pw.chromium.launch({channel:'chrome', headless:true, args:['--autoplay-policy=no-user-gesture-required','--allow-file-access-from-files']});
  const results=[];
  for(const size of [{width:360,height:800},{width:320,height:568}]){
    const page=await browser.newPage({viewport:size, hasTouch:true, isMobile:true});
    page.on('pageerror', e=>console.error('PAGEERROR', size, e.message));
    const r=await runAt(page, size);
    results.push(r);
    console.log('PASS player suite', r.tag, {dur:r.meta.dur, chapters:r.meta.chapters, cards:r.tools.n, jump:r.jumped.t, hold:r.hold.tip});
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.resolve(__dirname,'../evidence/tutorial-player.json'), JSON.stringify(results,null,2));
  console.log('TUTORIAL_PLAYER_OK', results.length);
})().catch(e=>{console.error(e); process.exit(1)});
