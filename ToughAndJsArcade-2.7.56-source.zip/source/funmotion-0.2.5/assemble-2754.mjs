// Arcade 2.7.54: swap ONLY funmotion:latest (FunMotion 0.2.5) on top of LIVE 2.7.53;
// the 2.7.53 FunMotion (0.2.4) is kept as funmotion:v024.
// Every other cartridge payload + legacy variant stays byte-for-byte as in 2.7.53.
// Old-WebView variant recomputed for the new funmotion:latest only.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const BASE = "/workspace/game/build-needle/package-2.7.53/tough-and-js-arcade.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "de9a2507bf0386b5d2ed0a19e274648028eca29fec160c5a98ebeb3a5cda9658", "2.7.53 bundle changed?!");
const NEW = fs.readFileSync("/workspace/game/build-funmotion-tutorial/funmotion.html", "utf8");
const OLD024 = fs.readFileSync("/workspace/game/build-funmotion-tutorial/backups/funmotion-0.2.4-COMP1.html", "utf8");
assert(sha(OLD024) === "9e77282138ba67bebb26c5001ae7aed49feaf6695d7a62c72d0e5dcd16fec8e4", "0.2.4 backup changed?!");
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const before = slots(src); assert(before["funmotion:latest"] && !before["funmotion:v024"], "slots");
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const G0 = GS(src); assert(G0["funmotion:latest"] === OLD024, "2.7.53 funmotion:latest != 0.2.4 backup");
const [a, b, oldExpr] = before["funmotion:latest"];
const expr = JSON.stringify([NEW]).replace(/<\//g, "<\\/") + '.join("")';
let out = src.slice(0, a) + expr + ',\n"funmotion:v024":' + oldExpr + src.slice(b);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const GAMES = JSON.parse(gLine.slice(12).replace(/;\s*$/, "")); assert(JSON.stringify(GAMES) === gLine.slice(12).replace(/;\s*$/, ""), "GAMES roundtrip");
const fm = GAMES.find((g) => g.id === "funmotion"); const cur = fm.versions.find((v) => v.id === "latest");
const prior = { ...cur, id: "v024", name: "v0.2.4 – Prior", def: false };
fm.versions.splice(fm.versions.length - 1, 0, prior);
cur.name = "v0.2.5 – Latest";
cur.desc = "Captioned stick-figure tutorial video, Tools-tab + hold-tip looping demos, rigid multi-select Follow move, scrollbar-correct pan; COMP 1 binding, onion, GIF/MP4 export retained.";
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const oldLeg = LEG["funmotion:latest"]; assert(oldLeg, "old funmotion legacy");
const rep = {}; const parts = legacyParts(NEW, rep); assert(rep.jsFail.length === 0, "legacy js fail " + rep.jsFail);
assert(joinParts(parts, NEW) === legacyHtml(NEW, {}), "parts mismatch");
const LEG2 = {}; for (const k of Object.keys(LEG)) { LEG2[k] = k === "funmotion:latest" ? parts : LEG[k]; if (k === "funmotion:latest") LEG2["funmotion:v024"] = oldLeg; }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]);
assert(JSON.stringify(changed) === '["funmotion:latest"]', "changed " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === '["funmotion:v024"]', "new slots");
const G1 = GS(out); assert(G1["funmotion:latest"] === NEW && G1["funmotion:v024"] === OLD024, "payloads");
for (const k of Object.keys(G0)) if (k !== "funmotion:latest") assert(G0[k] === G1[k], "payload changed " + k);
fs.writeFileSync(OUT, out);
const info = {
  arcadeVersion: "2.7.54", versionCode: 92, funmotionVersion: "0.2.5",
  funmotionSHA256: sha(NEW), funmotionBytes: Buffer.byteLength(NEW),
  funmotion024SHA256: sha(OLD024), funmotion024Bytes: Buffer.byteLength(OLD024),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out),
  baseBundleSHA256_2753: sha(src),
  cartridgeSlots: Object.keys(after).length,
  unchangedSlots: Object.keys(before).length - 1,
  newSlot: "funmotion:v024 (= 2.7.53 funmotion:latest, byte-identical)",
  legacy: { funmotionLatest: `css ${rep.css} js ${rep.js}`, keptOldVariantAs: "funmotion:v024", variants: Object.keys(LEG2).length },
  funmotionVersionsInPicker: fm.versions.map((v) => v.name + (v.def ? " (default)" : ""))
};
fs.writeFileSync(OUT.replace(/[^/]+$/, "assembly-verification.json"), JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
