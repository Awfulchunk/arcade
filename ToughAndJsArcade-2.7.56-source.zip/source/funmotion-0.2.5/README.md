# FunMotion 0.2.5 source (Arcade 2.7.54)

GPL offer accompanies the APK. This tree is FunMotion 0.2.5 and the tools used to patch it onto Arcade 2.7.53.

- `funmotion.html` — complete 0.2.5 COMP 1 cartridge (Tutorial player, Tools-tab + hold-tip demos, t1005 rigid multi-select, t1006 pan scrollbar).
- `backups/funmotion-0.2.4-COMP1.html` — locked 0.2.4, byte-identical to Arcade 2.7.53 `funmotion:latest`.
- `src/patch-025.py` — builds 0.2.5 from the 0.2.4 backup + tutorial CSS/HTML/JS + the two bug fixes.
- `src/tutorial.js`, `tutorial.css`, `tutorial.html` — player, chapters, looping tool demos, hold-tips.
- `assemble-2754.mjs` — swaps only `funmotion:latest` on the LIVE 2.7.53 bundle and keeps 0.2.4 as `funmotion:v024`.
- `tests/` — t1005, t1006, tutorial player, binding, mechanics, ui-vm.
- `record/` — headless walkthrough recorder (Playwright + CDP screencast).
- `video/` — captions and chapter metadata. The standalone MP4 is shipped next to the APK, not in this zip.

This zip does **not** include the Arcade signing keystore, KEYSTORE-INFO, the full 52 MB arcade bundle, or Latch. Latch payloads in 2.7.54 are unchanged from 2.7.53; their unlock code is not present here (so no placeholder was required).

Do not publish or push from these scripts; they assemble a local APK only.
