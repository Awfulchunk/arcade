/* FunMotion 0.2.5 — Tutorial player, Tools tab, hold-tip looping demos.
   Demos use the real renderObject / stick rig when a bitmap loop is not loaded.
   Asset paths are resolved for standalone file:// and APK srcdoc (parent fetch of android_asset). */
(function(){
var $id=function(i){return document.getElementById(i)};
var qsa=function(root,sel){ if(!root||typeof root.querySelectorAll!=='function') return []; try{ return Array.prototype.slice.call(root.querySelectorAll(sel)||[]); }catch(e){ return []; } };
var CHAPTERS=[
  {id:'open',title:'Opening · COMP 1',start:0},
  {id:'figures',title:'Stick figure + red dots',start:18},
  {id:'draw',title:'Drawing tools',start:36},
  {id:'rig',title:'Rigging · attach, locks, dots',start:88},
  {id:'frames',title:'Onion, frames, posing',start:140},
  {id:'play',title:'Playback',start:180},
  {id:'view',title:'Pan and zoom',start:198},
  {id:'file',title:'Save and open',start:216},
  {id:'export',title:'GIF and MP4 export',start:234}
];
/* Every user-facing tool. chapter is a CHAPTERS id. */
var TOOLS=[
  {id:'pencil',name:'Pencil',blurb:'Drag a crisp freehand line.',ch:'draw',group:'Draw'},
  {id:'brush',name:'Brush',blurb:'Drag a smooth, rounded stroke.',ch:'draw',group:'Draw'},
  {id:'eraser',name:'Eraser',blurb:'Drag to erase art. The trace image stays.',ch:'draw',group:'Draw'},
  {id:'fill',name:'Fill',blurb:'Tap an enclosed area to flood it with color.',ch:'draw',group:'Draw'},
  {id:'eyedrop',name:'Eyedropper',blurb:'Tap art to pick its visible color.',ch:'draw',group:'Draw'},
  {id:'line',name:'Line',blurb:'Drag start to end for a straight line.',ch:'draw',group:'Draw'},
  {id:'rect',name:'Rectangle',blurb:'Drag opposite corners. Fill is in Color / Size.',ch:'draw',group:'Draw'},
  {id:'ellipse',name:'Ellipse',blurb:'Drag a box to draw an oval.',ch:'draw',group:'Draw'},
  {id:'select',name:'Select',blurb:'Tap art or drag a box, then Move / Resize / Rotate.',ch:'draw',group:'Draw'},
  {id:'move',name:'Move',blurb:'Drag selected art to a new place.',ch:'draw',group:'Draw'},
  {id:'resize',name:'Resize',blurb:'Drag selected art outward or inward to scale.',ch:'draw',group:'Draw'},
  {id:'rotate',name:'Rotate',blurb:'Drag around the selection center to turn it.',ch:'draw',group:'Draw'},
  {id:'palette',name:'Color / Size',blurb:'Thickness, color, opacity, and filled shapes.',ch:'draw',group:'Draw'},
  {id:'delete',name:'Delete',blurb:'Remove the selected art.',ch:'draw',group:'Draw'},
  {id:'clearFrame',name:'Clear frame',blurb:'Erase all art in this frame. Undo can restore it.',ch:'draw',group:'Draw'},
  {id:'allObjects',name:'All objects',blurb:'Select everything in the current frame.',ch:'draw',group:'Draw'},
  {id:'rotateArt15',name:'Rotate +15° (art)',blurb:'Turn the selected drawings 15 degrees.',ch:'draw',group:'Draw'},
  {id:'grow10',name:'Grow 10%',blurb:'Enlarge the selected art.',ch:'draw',group:'Draw'},
  {id:'shrink10',name:'Shrink 10%',blurb:'Reduce the selected art.',ch:'draw',group:'Draw'},
  {id:'stick',name:'Stick',blurb:'Add the default poseable stick figure.',ch:'figures',group:'Figures'},
  {id:'circle',name:'Circle',blurb:'Add a poseable circle figure.',ch:'figures',group:'Figures'},
  {id:'square',name:'Square',blurb:'Add a poseable square figure.',ch:'figures',group:'Figures'},
  {id:'triangle',name:'Triangle',blurb:'Add a poseable triangle figure.',ch:'figures',group:'Figures'},
  {id:'star',name:'Star',blurb:'Add a poseable star figure.',ch:'figures',group:'Figures'},
  {id:'figures',name:'Figures',blurb:'Open Stick / Circle / Square / Triangle / Star.',ch:'figures',group:'Pose'},
  {id:'jointTools',name:'Joint tools',blurb:'Place, select, attach, detach, and pin joints.',ch:'rig',group:'Joints'},
  {id:'dot',name:'Place dots',blurb:'Tap exact paper. Auto-attaches when you land on ink.',ch:'rig',group:'Joints'},
  {id:'joints',name:'Select joint',blurb:'Tap a red dot, then drag to pose it.',ch:'figures',group:'Joints'},
  {id:'multi',name:'Multi-joint',blurb:'Tap several dots for Follow or Links / Lock.',ch:'rig',group:'Joints'},
  {id:'linksLock',name:'Links / Lock',blurb:'Connect two dots and lock or adjust the length.',ch:'rig',group:'Joints'},
  {id:'attach',name:'Attach selected',blurb:'Bind the selected joint to ink so posing bends it.',ch:'rig',group:'Joints'},
  {id:'detach',name:'Detach selected',blurb:'Unbind a joint from ink.',ch:'rig',group:'Joints'},
  {id:'pin',name:'Pin / Unpin',blurb:'Hold a joint still while neighbors pose.',ch:'rig',group:'Joints'},
  {id:'follow',name:'Follow',blurb:'When ON, selected joints move together.',ch:'rig',group:'Pose'},
  {id:'rotateJoints15',name:'Rotate +15° (joints)',blurb:'Turn the selected joints 15 degrees.',ch:'figures',group:'Pose'},
  {id:'freeDots',name:'Free dots',blurb:'ON lets you place dots anywhere, not only on figures.',ch:'rig',group:'Joints'},
  {id:'nextFrame',name:'Save Pose + Next Frame',blurb:'Copy the pose to a new animation step.',ch:'frames',group:'Frames'},
  {id:'duplicate',name:'Duplicate',blurb:'Copy this animation frame, art and all.',ch:'frames',group:'Frames'},
  {id:'blankFrame',name:'Blank frame',blurb:'Insert an empty animation step.',ch:'frames',group:'Frames'},
  {id:'deleteFrame',name:'Delete frame',blurb:'Remove this animation step. Undo can restore it.',ch:'frames',group:'Frames'},
  {id:'earlier',name:'Earlier',blurb:'Move this frame earlier in the timeline.',ch:'frames',group:'Frames'},
  {id:'later',name:'Later',blurb:'Move this frame later in the timeline.',ch:'frames',group:'Frames'},
  {id:'prevFrame',name:'Previous frame',blurb:'Go to the previous existing frame.',ch:'frames',group:'Frames'},
  {id:'nextExisting',name:'Next existing',blurb:'Go to the next existing frame.',ch:'frames',group:'Frames'},
  {id:'onion',name:'Ghost',blurb:'Show the previous pose faintly while you edit.',ch:'frames',group:'Frames'},
  {id:'play',name:'Play',blurb:'Flip through the frames at the project FPS.',ch:'play',group:'Frames'},
  {id:'plus',name:'Zoom in',blurb:'Magnify the paper. Place dots stay exact.',ch:'view',group:'View'},
  {id:'minus',name:'Zoom out',blurb:'See more of the paper.',ch:'view',group:'View'},
  {id:'fit',name:'Fit',blurb:'Reset zoom and pan to the full page.',ch:'view',group:'View'},
  {id:'panLeft',name:'Scroll left',blurb:'Nudge the paper left 12 screen pixels.',ch:'view',group:'View'},
  {id:'panRight',name:'Scroll right',blurb:'Nudge the paper right 12 screen pixels.',ch:'view',group:'View'},
  {id:'hand',name:'Hand',blurb:'Drag the paper to pan at any zoom.',ch:'view',group:'View'},
  {id:'pan',name:'Pan arrows',blurb:'Up / Down / Left / Right move the view 12 px.',ch:'view',group:'View'},
  {id:'undo',name:'Undo',blurb:'Step back one edit.',ch:'open',group:'Project'},
  {id:'redo',name:'Redo',blurb:'Step forward one undone edit.',ch:'open',group:'Project'},
  {id:'settings',name:'Settings',blurb:'Onion, FPS, free dots, snap, labels, and tint.',ch:'open',group:'Project'},
  {id:'file',name:'File',blurb:'Save, open, trace, and export.',ch:'file',group:'Project'},
  {id:'saveProject',name:'Save project',blurb:'Download an editable .funmotion.json.',ch:'file',group:'Project'},
  {id:'loadProject',name:'Open project',blurb:'Load a saved JSON project.',ch:'file',group:'Project'},
  {id:'imageUpload',name:'Trace image',blurb:'Import an underlay and draw over it by hand.',ch:'file',group:'Project'},
  {id:'imageRemove',name:'Remove underlay',blurb:'Drop the trace image; keep your drawings.',ch:'file',group:'Project'},
  {id:'png',name:'Export PNG',blurb:'Current frame only, no ghosts or red dots.',ch:'export',group:'Project'},
  {id:'gif',name:'Export GIF',blurb:'A real animated GIF of the frames.',ch:'export',group:'Project'},
  {id:'video',name:'Export video',blurb:'MP4 if the browser can, otherwise WebM.',ch:'export',group:'Project'},
  {id:'newProject',name:'New project',blurb:'Start blank after a confirm.',ch:'file',group:'Project'}
];
var TOOL_BY_ID={}; for(var ti=0;ti<TOOLS.length;ti++) TOOL_BY_ID[TOOLS[ti].id]=TOOLS[ti];
var LABEL_ID={
  'Pencil':'pencil','Brush':'brush','Eraser':'eraser','Fill':'fill','Eyedropper':'eyedrop','Line':'line',
  'Rectangle':'rect','Ellipse':'ellipse','Select':'select','Move':'move','Resize':'resize','Rotate':'rotate',
  'Color / Size':'palette','Delete':'delete','Clear frame':'clearFrame','All objects':'allObjects',
  'Rotate +15°':'rotateArt15','Grow 10%':'grow10','Shrink 10%':'shrink10',
  'Stick':'stick','Circle':'circle','Square':'square','Triangle':'triangle','Star':'star',
  'Figures':'figures','Joint tools':'jointTools','Place dots':'dot','Select dots':'joints','Select joint':'joints',
  'Multi-joint':'multi','Links / Lock':'linksLock','Attach selected':'attach','Detach selected':'detach',
  'Pin / Unpin':'pin','Paint size':'palette','Delete art':'delete','Pose / Links':'figures',
  'Select / Edit':'select','Frames':'nextFrame','Export':'gif','Setup':'settings',
  'Next Frame':'nextFrame','Duplicate':'duplicate','Blank frame':'blankFrame','Delete frame':'deleteFrame',
  'Earlier':'earlier','Later':'later','File':'file','↶ Undo':'undo','Undo':'undo','↷ Redo':'redo','Redo':'redo',
  'Settings':'settings','Tutorial':'tutorial','Fit':'fit','+':'+plus','−':'minus','Use Hand tool · drag the paper':'hand',
  '▲ Up':'pan','◀ Left':'pan','Right ▶':'pan','▼ Down':'pan','Pan the view':'pan','Pan arrows / Hand':'pan',
  'Save project':'saveProject','Open project':'loadProject','Trace image':'imageUpload','Remove underlay':'imageRemove',
  'Export PNG':'png','Export GIF':'gif','Export video':'video','New project':'newProject',
  'Save Pose + Next Frame ▶':'nextFrame'
};
function idFromLabel(txt){
  txt=String(txt||'').replace(/▾/g,'').replace(/\s+/g,' ').trim();
  if(!txt) return null;
  if(/^Follow/.test(txt)) return 'follow';
  if(/^Free dots/.test(txt)) return 'freeDots';
  if(/^Ghost/.test(txt)) return 'onion';
  if(/^▶ Play|^■ Stop|^Play$/.test(txt)) return 'play';
  if(/^Rotate \+15/.test(txt)){
    if(/art/i.test(txt)) return 'rotateArt15';
    /* pose context vs edit context is distinguished by later bind overrides */
    return 'rotateJoints15';
  }
  if(LABEL_ID[txt]) return LABEL_ID[txt]==='+plus'?'plus':LABEL_ID[txt];
  var base=txt.split('·')[0].trim();
  if(LABEL_ID[base]) return LABEL_ID[base];
  if(/^Frame \d+/.test(txt)) return null;
  return TOOL_BY_ID[txt]?txt:null;
}

/* ---------- real stick + renderObject demos (no fake tools) ---------- */
var DW=240, DH=200;
function stickPts(cx,cy){
  return [{x:cx,y:cy-100},{x:cx,y:cy-65},{x:cx,y:cy+10},{x:cx-60,y:cy-10},{x:cx+60,y:cy-10},{x:cx-40,y:cy+110},{x:cx+40,y:cy+110}];
}
function stickBones(){return [[0,1],[1,2],[1,3],[1,4],[2,5],[2,6]];}
function copyPts(p){var o=[];for(var i=0;i<p.length;i++)o.push({x:p[i].x,y:p[i].y});return o;}
function lerp(a,b,t){return a+(b-a)*t;}
function poseWalk(pts,t){
  var s=Math.sin(t*Math.PI*2), c=Math.cos(t*Math.PI*2);
  pts[3].x-=18*s; pts[3].y+=8*c;
  pts[4].x+=18*s; pts[4].y-=8*c;
  pts[5].x-=16*s; pts[5].y+=6*Math.abs(s);
  pts[6].x+=16*s; pts[6].y+=6*Math.abs(c);
  pts[0].x+=4*s; pts[2].y+=3*Math.abs(s);
}
function poseWave(pts,t){
  var s=Math.sin(t*Math.PI*2);
  pts[4].x+=10; pts[4].y-=50+18*s;
}
function makeRig(pts,color){
  return {kind:'rig',points:pts,bones:stickBones(),head:0,color:color||'#111111',width:5,opacity:1,filled:false};
}
function makePath(pts,opt){
  opt=opt||{};
  return {kind:'path',points:pts,color:opt.color||'#111111',width:opt.width||5,opacity:opt.opacity||1,brush:!!opt.brush,erase:!!opt.erase,filled:false};
}
function makeShape(kind,pts,opt){
  opt=opt||{};
  return {kind:kind,points:pts,color:opt.color||'#254cd9',width:opt.width||4,opacity:1,filled:!!opt.filled};
}
function paintDemo(g,frame,opts){
  opts=opts||{};
  g.fillStyle='#ffffff'; g.fillRect(0,0,g.canvas.width,g.canvas.height);
  var scaleX=g.canvas.width/720, scaleY=g.canvas.height/1100;
  /* Crop around the default stick: x 180-540, y 360-780 */
  var sx=180, sy=360, sw=360, sh=420;
  if(opts.full){sx=0;sy=0;sw=720;sh=1100;}
  g.save();
  g.translate(-sx* (g.canvas.width/sw), -sy*(g.canvas.height/sh));
  g.scale(g.canvas.width/sw, g.canvas.height/sh);
  var i,o;
  if(opts.onion && opts.onionFrame){
    g.save(); g.globalAlpha=0.22;
    for(i=0;i<opts.onionFrame.objects.length;i++) window.renderObject(g, opts.onionFrame.objects[i]);
    g.restore();
  }
  for(i=0;i<frame.objects.length;i++) window.renderObject(g, frame.objects[i]);
  if(frame.links){
    for(i=0;i<frame.links.length;i++){
      var l=frame.links[i], a=frame.objects[l.a[0]] && frame.objects[l.a[0]].points[l.a[1]], b=frame.objects[l.b[0]] && frame.objects[l.b[0]].points[l.b[1]];
      if(!a||!b) continue;
      g.save(); g.strokeStyle=l.locked?'#000080':(l.color||'#111'); g.lineWidth=l.width||4; g.beginPath(); g.moveTo(a.x,a.y); g.lineTo(b.x,b.y); g.stroke(); g.restore();
    }
  }
  if(opts.dots){
    for(i=0;i<frame.objects.length;i++){
      o=frame.objects[i];
      if(o.kind!=='rig' && o.kind!=='dot') continue;
      for(var j=0;j<o.points.length;j++){
        var p=o.points[j];
        g.beginPath(); g.arc(p.x,p.y,8,0,Math.PI*2);
        g.fillStyle=(opts.sel && opts.sel[i+':'+j])?'#0040ff':'#e32828'; g.fill();
        if(opts.pin && o.binding && o.binding.pinned && j===0){ g.strokeStyle='#000'; g.lineWidth=2; g.stroke(); }
      }
    }
  }
  if(opts.box){
    g.save(); g.strokeStyle='#000080'; g.lineWidth=3; g.setLineDash([8,6]);
    g.strokeRect(opts.box.x,opts.box.y,opts.box.w,opts.box.h); g.restore();
  }
  if(opts.cursor){
    drawFinger(g, opts.cursor.x, opts.cursor.y, !!opts.cursor.down);
  }
  g.restore();
}
function drawFinger(g,x,y,down){
  g.save();
  g.beginPath(); g.arc(x,y, down?16:14, 0, Math.PI*2);
  g.fillStyle=down?'rgba(0,0,128,0.35)':'rgba(0,0,128,0.18)'; g.fill();
  g.beginPath(); g.arc(x,y,6,0,Math.PI*2); g.fillStyle='#000080'; g.fill();
  g.restore();
}
function pathLine(x0,y0,x1,y1,n){
  var p=[],i; for(i=0;i<=n;i++){var t=i/n;p.push({x:lerp(x0,x1,t),y:lerp(y0,y1,t)});} return p;
}
function hatchHat(t){
  /* short stroke that grows over the stick head */
  var n=Math.max(2, Math.round(18*Math.min(1,t)));
  var p=[], i;
  for(i=0;i<n;i++){
    var u=i/18;
    p.push({x:330+Math.sin(u*6)*18+u*50, y:420-Math.cos(u*5)*12});
  }
  return p;
}

function engineFrame(id, t){
  /* t is 0..1 loop. Returns {frame, opts} for paintDemo. Uses real object kinds. */
  var cx=360, cy=550, pts=stickPts(cx,cy), frame={objects:[]}, opts={dots:true}, cur=null;
  var s=Math.sin(t*Math.PI*2);
  function addStick(posed){ frame.objects.unshift(makeRig(posed||copyPts(pts))); }
  switch(id){
    case 'stick':
    case 'figures':
      addStick(); opts.dots=t>0.15; cur={x:cx,y:cy-100,down:t<0.2}; break;
    case 'circle': case 'square': case 'triangle': case 'star': {
      addStick();
      var n=id==='circle'?12:id==='square'?4:id==='triangle'?3:10, i, sh=[];
      for(i=0;i<n;i++){
        var a=-Math.PI/2+2*Math.PI*i/n+(id==='square'?Math.PI/4:0), r=id==='star'&&i%2?45:80;
        sh.push({x:cx+90+Math.cos(a)*r, y:cy+Math.sin(a)*r});
      }
      var bones=[]; for(i=0;i<n;i++) bones.push([i,(i+1)%n]);
      frame.objects.push({kind:'rig',points:sh,bones:bones,color:'#000080',width:4,opacity:1,filled:false});
      opts.dots=true; break;
    }
    case 'pencil': {
      var p=hatchHat(t); addStick();
      if(p.length>1) frame.objects.push(makePath(p,{width:3}));
      cur={x:(p[p.length-1]||pts[0]).x,y:(p[p.length-1]||pts[0]).y,down:t<0.9}; break;
    }
    case 'brush': {
      addStick();
      var bp=hatchHat(t).map(function(q){return {x:q.x,y:q.y+30};});
      if(bp.length>1) frame.objects.push(makePath(bp,{width:14,brush:true,color:'#d52b28'}));
      cur={x:(bp[bp.length-1]||pts[0]).x,y:(bp[bp.length-1]||pts[0]).y,down:t<0.9}; break;
    }
    case 'eraser': {
      addStick();
      var ep=[{x:300,y:500},{x:420,y:500},{x:420,y:620},{x:300,y:620}];
      if(t<0.55) frame.objects.push(makeShape('rect', ep, {color:'#254cd9',filled:true}));
      else {
        /* remaining sliver after erase */
        frame.objects.push(makeShape('rect', [{x:300,y:500},{x:420,y:500},{x:420,y:560},{x:300,y:560}], {color:'#254cd9',filled:true}));
      }
      cur={x:360,y:lerp(500,640,Math.min(1,t*1.1)),down:t>0.15&&t<0.9}; break;
    }
    case 'line': {
      addStick();
      var lt=Math.min(1,t*1.2);
      frame.objects.push(makePath([{x:250,y:700},{x:250+lt*260,y:700+lt*20}],{width:6,color:'#199348'}));
      cur={x:250+lt*260,y:700+lt*20,down:t<0.85}; break;
    }
    case 'rect': {
      addStick();
      var rt=Math.min(1,t*1.3);
      frame.objects.push(makeShape('rect',[{x:250,y:700},{x:250+rt*200,y:700},{x:250+rt*200,y:700+rt*80},{x:250,y:700+rt*80}],{color:'#254cd9',filled:false}));
      cur={x:250+rt*200,y:700+rt*80,down:t<0.85}; break;
    }
    case 'ellipse': {
      addStick();
      var et=Math.min(1,t*1.3);
      frame.objects.push(makeShape('ellipse',[{x:280,y:700},{x:280+et*180,y:700},{x:280+et*180,y:700+et*70},{x:280,y:700+et*70}],{color:'#800080',filled:true}));
      cur={x:280+et*180,y:700+et*70,down:t<0.85}; break;
    }
    case 'fill': {
      addStick();
      frame.objects.push(makeShape('rect',[{x:250,y:680},{x:470,y:680},{x:470,y:780},{x:250,y:780}],{color:'#111111',filled:false}));
      if(t>0.35) frame.objects.push(makeShape('rect',[{x:252,y:682},{x:468,y:682},{x:468,y:778},{x:252,y:778}],{color:'#f0a020',filled:true}));
      cur={x:360,y:730,down:t>0.3&&t<0.5}; break;
    }
    case 'eyedrop': {
      addStick();
      frame.objects.push(makeShape('rect',[{x:280,y:700},{x:440,y:700},{x:440,y:780},{x:280,y:780}],{color:'#d52b28',filled:true}));
      cur={x:360,y:740,down:t>0.3&&t<0.7}; opts.palette=t>0.45?'#d52b28':null; break;
    }
    case 'select': case 'allObjects': {
      addStick();
      frame.objects.push(makeShape('rect',[{x:260,y:700},{x:460,y:700},{x:460,y:780},{x:260,y:780}],{color:'#254cd9',filled:true}));
      var bt=Math.min(1,t*1.4);
      opts.box={x:240,y:430,w:bt*250,h:bt*370}; opts.dots=false;
      cur={x:240+bt*250,y:430+bt*370,down:t<0.8}; break;
    }
    case 'move': {
      var dx=40*Math.sin(t*Math.PI*2);
      var mp=stickPts(cx+dx,cy); addStick(mp);
      opts.box={x:260+dx,y:430,w:200,h:360}; opts.dots=false;
      cur={x:cx+dx,y:cy,down:true}; break;
    }
    case 'resize': {
      var k=1+0.18*Math.sin(t*Math.PI*2);
      var rp=stickPts(cx,cy).map(function(p){return {x:cx+(p.x-cx)*k,y:cy+(p.y-cy)*k};});
      addStick(rp); opts.box={x:cx-80*k,y:cy-130*k,w:160*k,h:280*k}; opts.dots=false;
      cur={x:cx+80*k,y:cy+140*k,down:true}; break;
    }
    case 'rotate': case 'rotateArt15': {
      var ang=(id==='rotateArt15'? (Math.PI/12)*(t<0.5?0:1) : t*Math.PI*2*0.25);
      var tp=stickPts(cx,cy).map(function(p){
        var dx=p.x-cx,dy=p.y-cy; return {x:cx+dx*Math.cos(ang)-dy*Math.sin(ang), y:cy+dx*Math.sin(ang)+dy*Math.cos(ang)};
      });
      addStick(tp); opts.box={x:260,y:430,w:200,h:360}; opts.dots=false;
      cur={x:cx+90*Math.cos(ang),y:cy+90*Math.sin(ang),down:true}; break;
    }
    case 'delete': case 'clearFrame': {
      if(t<0.55) addStick();
      cur={x:cx,y:cy,down:t>0.5&&t<0.7}; opts.dots=t<0.55; break;
    }
    case 'grow10': {
      var gk=t<0.5?1:1.1; var gp=stickPts(cx,cy).map(function(p){return {x:cx+(p.x-cx)*gk,y:cy+(p.y-cy)*gk};});
      addStick(gp); opts.dots=false; break;
    }
    case 'shrink10': {
      var sk=t<0.5?1:0.9; var sp=stickPts(cx,cy).map(function(p){return {x:cx+(p.x-cx)*sk,y:cy+(p.y-cy)*sk};});
      addStick(sp); opts.dots=false; break;
    }
    case 'joints': case 'rotateJoints15': {
      var jp=stickPts(cx,cy); if(id==='rotateJoints15' && t>0.4){
        var a2=Math.PI/12; jp=jp.map(function(p){var dx=p.x-cx,dy=p.y-cy;return {x:cx+dx*Math.cos(a2)-dy*Math.sin(a2),y:cy+dx*Math.sin(a2)+dy*Math.cos(a2)};});
      } else poseWave(jp, t);
      addStick(jp); opts.sel={'0:4':1}; cur={x:jp[4].x,y:jp[4].y,down:true}; break;
    }
    case 'follow': case 'multi': {
      var fp=stickPts(cx,cy); var slide=30*Math.sin(t*Math.PI*2);
      fp[3].x+=slide; fp[4].x+=slide;
      addStick(fp); opts.sel={'0:3':1,'0:4':1}; cur={x:fp[4].x,y:fp[4].y,down:true}; break;
    }
    case 'dot': case 'freeDots': case 'jointTools': {
      addStick();
      if(t>0.25) frame.objects.push({kind:'dot',points:[{x:300,y:500}],color:'#e32828',width:4,opacity:1,filled:true});
      if(t>0.55) frame.objects.push({kind:'dot',points:[{x:420,y:620}],color:'#e32828',width:4,opacity:1,filled:true});
      cur={x:t<0.4?300:420,y:t<0.4?500:620,down: (t>0.2&&t<0.35)||(t>0.5&&t<0.65)}; break;
    }
    case 'linksLock': {
      var lp=stickPts(cx,cy); addStick(lp);
      frame.objects.push({kind:'dot',points:[{x:lp[3].x-10,y:lp[3].y}],color:'#111',width:4,opacity:1});
      frame.links=[{a:[0,3],b:[0,4],length:120,locked:t>0.45,color:'#000080',width:4}];
      opts.sel={'0:3':1,'0:4':1}; break;
    }
    case 'attach': case 'detach': case 'pin': case 'rig': {
      var ap=stickPts(cx,cy); poseWave(ap, id==='pin'?0:t);
      if(id==='pin'){ ap[1].x=cx; /* neck stays */ ap[4].y-=40+10*s; }
      addStick(ap);
      var cape=[{x:cx,y:cy-60},{x:cx-20,y:cy},{x:cx-10,y:cy+80}];
      if(id!=='detach' || t<0.5){
        /* deform cape with the neck/hand when attached */
        if(id!=='detach'){ cape[0].x=ap[1].x; cape[2].x=ap[3].x-10; cape[2].y=ap[3].y+40; }
        frame.objects.push(makePath(cape,{width:8,color:'#800080'}));
      } else {
        frame.objects.push(makePath([{x:cx,y:cy-60},{x:cx-20,y:cy},{x:cx-10,y:cy+80}],{width:8,color:'#800080'}));
      }
      opts.sel={'0:3':1}; opts.dots=true;
      if(id==='pin') opts.sel={'0:1':1};
      cur={x:ap[id==='pin'?1:3].x,y:ap[id==='pin'?1:3].y,down:true}; break;
    }
    case 'nextFrame': case 'duplicate': case 'prevFrame': case 'nextExisting': case 'earlier': case 'later': case 'frames': {
      var a=stickPts(cx,cy), b=stickPts(cx,cy); poseWalk(b,0.35);
      var show=t<0.5?a:b;
      var ghost=t>=0.5?a:null;
      addStick(show);
      if(ghost){ opts.onion=true; opts.onionFrame={objects:[makeRig(ghost)]}; }
      break;
    }
    case 'blankFrame': case 'deleteFrame': {
      if(t<0.5) addStick();
      opts.dots=t<0.5; break;
    }
    case 'onion': {
      var o1=stickPts(cx,cy), o2=stickPts(cx,cy); poseWalk(o2,0.4);
      addStick(o2); opts.onion=true; opts.onionFrame={objects:[makeRig(o1)]}; opts.dots=true; break;
    }
    case 'play': {
      var pp=stickPts(cx,cy); poseWalk(pp,t); addStick(pp); opts.dots=false; break;
    }
    case 'plus': case 'minus': case 'fit': case 'view': {
      opts.full=true; addStick();
      /* simulate zoom by changing crop via a custom scale drawn as a growing window */
      opts.full=false;
      if(id==='plus' || (id==='view' && t<0.5)){
        /* tighter crop = zoom in */
        /* paintDemo crop is fixed; scale stick by drawing later? tweak crop through opts */
      }
      var zp=stickPts(cx,cy); addStick(zp); opts.dots=true; break;
    }
    case 'panLeft': case 'panRight': case 'hand': case 'pan': {
      var off=(id==='panLeft'?-40:id==='panRight'?40: 50*Math.sin(t*Math.PI*2));
      addStick(stickPts(cx+off,cy)); opts.dots=true; break;
    }
    case 'undo': {
      if(t<0.5){ var u=stickPts(cx,cy); poseWave(u,0.3); addStick(u); }
      else addStick(); break;
    }
    case 'redo': {
      if(t<0.5) addStick();
      else { var r=stickPts(cx,cy); poseWave(r,0.3); addStick(r); } break;
    }
    case 'palette': case 'settings': case 'file':
    case 'saveProject': case 'loadProject': case 'imageUpload': case 'imageRemove':
    case 'png': case 'gif': case 'video': case 'newProject': {
      var wp=stickPts(cx,cy); poseWalk(wp,t); addStick(wp); opts.dots=id==='settings';
      opts.chrome=id; break;
    }
    default: {
      var dp=stickPts(cx,cy); poseWalk(dp,t); addStick(dp); opts.dots=true; break;
    }
  }
  if(cur) opts.cursor=cur;
  return {frame:frame, opts:opts};
}

function drawChrome(g, id, t){
  /* Real COMP 1 chrome labels from the actual File / Settings / Palette windows, painted beside the stick. Not a substitute when a recorded loop exists. */
  var W=g.canvas.width, H=g.canvas.height;
  var x=8, y=8, w=W-16, h=Math.min(84, H*0.42);
  g.save();
  g.fillStyle='#d4d0c8'; g.strokeStyle='#444'; g.fillRect(x,y,w,h);
  g.strokeStyle='#fff'; g.beginPath(); g.moveTo(x,y+h); g.lineTo(x,y); g.lineTo(x+w,y); g.stroke();
  g.strokeStyle='#444'; g.beginPath(); g.moveTo(x+w,y); g.lineTo(x+w,y+h); g.lineTo(x,y+h); g.stroke();
  g.fillStyle='#000080'; g.fillRect(x+2,y+2,w-4,16);
  var title='File · local project';
  if(id==='settings') title='Settings · Animation & drawing';
  if(id==='palette') title='Paint properties';
  g.fillStyle='#fff'; g.font='11px Arial'; g.fillText(title, x+8, y+14);
  var labels=[];
  if(id==='palette') labels=['Thickness','Color','Filled'];
  else if(id==='settings') labels=['Onion','FPS','Free dots'];
  else if(id==='saveProject') labels=['Save project'];
  else if(id==='loadProject') labels=['Open project'];
  else if(id==='imageUpload') labels=['Trace image'];
  else if(id==='imageRemove') labels=['Remove underlay'];
  else if(id==='png') labels=['Export PNG'];
  else if(id==='gif') labels=['Export GIF'];
  else if(id==='video') labels=['Export video'];
  else if(id==='newProject') labels=['New project'];
  else labels=['Save project','Open project','Export GIF'];
  g.font='11px Arial'; g.fillStyle='#111';
  for(var i=0;i<labels.length;i++){
    var bx=x+6+i*70, by=y+24, bw=66, bh=28;
    var on=Math.floor(t*labels.length)%labels.length===i;
    g.fillStyle=on?'#c7d8fa':'#d4d0c8';
    g.fillRect(bx,by,bw,bh);
    g.strokeStyle='#fff'; g.strokeRect(bx,by,bw,bh);
    g.fillStyle='#111'; g.fillText(labels[i], bx+4, by+18);
  }
  g.restore();
}

/* Optional recorded filmstrips: window.__FM_DEMO_BITS[id] = {img, n, fw, fh, fps} */
function drawTool(canvas, id, now){
  if(!canvas) return;
  var g=canvas.getContext('2d');
  try{
  var bits=(window.__FM_DEMO_BITS||{})[id];
  var loop=2200;
  var t=((now||0)%loop)/loop;
  if(bits && bits.img && bits.img.complete && bits.img.naturalWidth){
    var fi=Math.floor(((now||0)/1000)* (bits.fps||8)) % bits.n;
    var cols=Math.floor(bits.img.naturalWidth/bits.fw)||1;
    var sx=(fi%cols)*bits.fw, sy=Math.floor(fi/cols)*bits.fh;
    g.fillStyle='#fff'; g.fillRect(0,0,canvas.width,canvas.height);
    g.drawImage(bits.img,sx,sy,bits.fw,bits.fh,0,0,canvas.width,canvas.height);
    return;
  }
  var pack=engineFrame(id, t);
  paintDemo(g, pack.frame, pack.opts);
  if(pack.opts.chrome) drawChrome(g, pack.opts.chrome, t);
  }catch(err){
    g.fillStyle='#ffffd2'; g.fillRect(0,0,canvas.width,canvas.height);
    g.fillStyle='#000'; g.font='11px Arial'; g.fillText('demo', 8, 20);
  }
}

/* ---------- asset loader (video + optional chapters + filmstrips) ---------- */
function fetchBlob(url){
  return new Promise(function(resolve,reject){
    var f=window.fetch;
    try{ if(parent && parent!==window && parent.fetch) f=parent.fetch.bind(parent); }catch(e){}
    if(!f){ reject(new Error('no fetch')); return; }
    f(url).then(function(r){ if(!r.ok) throw new Error('http '+r.status); return r.blob(); }).then(resolve).catch(reject);
  });
}
function candidateUrls(name){
  var list=[name, './'+name, 'file:///android_asset/'+name];
  try{
    if(parent && parent!==window && parent.location && parent.location.href){
      var base=parent.location.href.replace(/[^\/]+$/, '');
      list.push(base+name);
    }
  }catch(e){}
  return list;
}
function loadFirst(name){
  var urls=candidateUrls(name), i=0;
  function next(){
    if(i>=urls.length) return Promise.reject(new Error('missing '+name));
    var u=urls[i++];
    return fetchBlob(u).catch(next);
  }
  return next();
}

var tutState={tab:'watch', page:0, perPage:2, open:false, hold:null, videoUrl:null, ready:false, chapters:CHAPTERS, raf:0};

function fillChapters(){
  var sel=$id('tutChapter'); if(!sel) return;
  sel.innerHTML='';
  for(var i=0;i<tutState.chapters.length;i++){
    var o=document.createElement('option');
    o.value=String(i); o.textContent=tutState.chapters[i].title;
    sel.appendChild(o);
  }
}
function chapterIndexAt(t){
  var ch=tutState.chapters, i, idx=0;
  for(i=0;i<ch.length;i++) if(t+0.01>=ch[i].start) idx=i;
  return idx;
}
function seekChapter(i){
  var ch=tutState.chapters;
  if(i<0) i=0; if(i>ch.length-1) i=ch.length-1;
  var v=$id('tutVideo');
  if(v && isFinite(ch[i].start)) { try{ v.currentTime=ch[i].start; }catch(e){} }
  var sel=$id('tutChapter'); if(sel) sel.value=String(i);
}

function formatTime(s){
  s=Math.max(0, Math.floor(s||0));
  return Math.floor(s/60)+':'+(s%60<10?'0':'')+(s%60);
}
function syncControls(){
  var v=$id('tutVideo'), play=$id('tutPlay'), scrub=$id('tutScrub'), time=$id('tutTime');
  if(!v) return;
  if(play) play.textContent=v.paused?'▶':'❚❚';
  if(time) time.textContent=formatTime(v.currentTime)+' / '+formatTime(v.duration||0);
  if(scrub && v.duration && isFinite(v.duration) && !scrub._drag){
    scrub.max=1000; scrub.value=String(Math.round(1000*v.currentTime/v.duration));
  }
  var sel=$id('tutChapter');
  if(sel && document.activeElement!==sel) sel.value=String(chapterIndexAt(v.currentTime||0));
}

function setTutTab(tab){
  tutState.tab=tab;
  var w=$id('tutWatch'), t=$id('tutTools');
  if(w) w.hidden=tab!=='watch';
  if(t) t.hidden=tab!=='tools';
  qsa(document,'[data-tuttab]').forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-tuttab')===tab); });
  if(tab==='tools'){ renderToolPage(); startDemoLoop(); } else { /* keep hold/tools canvases ticking only if visible */ }
  var v=$id('tutVideo');
  if(v && tab!=='watch'){ try{ v.pause(); }catch(e){} }
}

function perPageNow(){
  var h=window.innerHeight||600;
  if(h>=740) return 6;
  if(h>=620) return 4;
  return 2;
}
function renderToolPage(){
  var grid=$id('tutToolGrid'); if(!grid) return;
  tutState.perPage=perPageNow();
  var n=TOOLS.length, per=tutState.perPage, pages=Math.max(1, Math.ceil(n/per));
  if(tutState.page<0) tutState.page=0;
  if(tutState.page>pages-1) tutState.page=pages-1;
  var start=tutState.page*per, end=Math.min(n, start+per);
  grid.innerHTML='';
  for(var i=start;i<end;i++){
    var tool=TOOLS[i];
    var b=document.createElement('button');
    b.className='tutCard'; b.type='button'; b.setAttribute('data-demo', tool.id);
    var c=document.createElement('canvas'); c.width=DW; c.height=DH; c.setAttribute('aria-hidden','true');
    var strong=document.createElement('strong'); strong.textContent=tool.name;
    var small=document.createElement('small'); small.textContent=tool.blurb;
    b.appendChild(c); b.appendChild(strong); b.appendChild(small);
    b.addEventListener('click', (function(id){ return function(){ jumpTool(id); }; })(tool.id));
    grid.appendChild(b);
    drawTool(c, tool.id, performance.now());
  }
  var lab=$id('tutToolPage');
  if(lab) lab.textContent='Page '+(tutState.page+1)+' / '+pages+' · '+n+' tools';
  var prev=$id('tutToolPrev'), next=$id('tutToolNext');
  if(prev) prev.disabled=tutState.page<=0;
  if(next) next.disabled=tutState.page>=pages-1;
}
function jumpTool(id){
  var tool=TOOL_BY_ID[id]; if(!tool) return;
  var idx=-1, i;
  for(i=0;i<tutState.chapters.length;i++) if(tutState.chapters[i].id===tool.ch) idx=i;
  setTutTab('watch');
  if(idx>=0) seekChapter(idx);
  var v=$id('tutVideo'); if(v && v.paused && tutState.ready) v.play().catch(function(){});
}

function startDemoLoop(){
  if(tutState.raf) return;
  var tick=function(now){
    tutState.raf=requestAnimationFrame(tick);
    var hold=$id('holdTip');
    if(hold && hold.classList.contains('show') && tutState.hold){
      drawTool($id('holdTipCanvas'), tutState.hold, now);
    }
    if(tutState.open && tutState.tab==='tools'){
      var cs=qsa(document,'#tutToolGrid canvas');
      for(var i=0;i<cs.length;i++){
        var id=cs[i].parentNode && cs[i].parentNode.getAttribute('data-demo');
        if(id) drawTool(cs[i], id, now);
      }
    }
    if(!(tutState.open && tutState.tab==='tools') && !(hold && hold.classList.contains('show'))){
      /* nothing visible — keep a cheap idle only if needed; leave raf on while dialog/tip may reopen soon? stop. */
      if(!tutState.open && !(hold && hold.classList.contains('show'))){
        cancelAnimationFrame(tutState.raf); tutState.raf=0;
      }
    }
  };
  tutState.raf=requestAnimationFrame(tick);
}

function openTutorial(){
  if(typeof stop==='function') stop();
  if(typeof cancelGesture==='function') cancelGesture();
  if(typeof close==='function') close();
  var dlg=$id('tutorialDlg');
  if(!dlg) return;
  dlg.showModal();
  tutState.open=true;
  setTutTab('watch');
  fillChapters();
  startDemoLoop();
  var v=$id('tutVideo');
  if(v && tutState.videoUrl && !v.src){ v.src=tutState.videoUrl; }
  if(v && tutState.ready){ v.play().catch(function(){}); }
  syncControls();
}
function closeTutorial(){
  var v=$id('tutVideo'); if(v){ try{ v.pause(); }catch(e){} }
  tutState.open=false;
  hideHold();
}
function hideHold(){
  var el=$id('holdTip'); if(el) el.classList.remove('show');
  tutState.hold=null;
}
function showHold(id, anchor){
  var tool=TOOL_BY_ID[id]; if(!tool) return;
  var el=$id('holdTip'), title=$id('holdTipTitle'), text=$id('holdTipText'), c=$id('holdTipCanvas');
  if(!el) return;
  if(title) title.textContent=tool.name;
  if(text) text.textContent=tool.blurb+(tool.ch?'  ·  Hold-tip demo. In Tutorial → Tools, tap to jump to this part of the video.':'');
  el.classList.add('show');
  tutState.hold=id;
  if(c) drawTool(c, id, performance.now());
  startDemoLoop();
  /* keep on screen; pin near bottom so 320×568 never overflows the page */
  el.style.left='50%'; el.style.bottom='8px'; el.style.top='auto'; el.style.transform='translateX(-50%)';
}

function bindHold(el, id){
  if(!el || !id || !TOOL_BY_ID[id] || el.__fmHold) return;
  el.__fmHold=id;
  var timer=0, fired=false;
  el.addEventListener('pointerdown', function(e){
    if(e.button && e.button!==0) return;
    if(e.pointerType==='mouse' && e.button!==0) return;
    fired=false;
    if(timer) clearTimeout(timer);
    timer=setTimeout(function(){ fired=true; showHold(id, el); }, 520);
  });
  var clear=function(){ if(timer){ clearTimeout(timer); timer=0; } };
  el.addEventListener('pointerup', clear);
  el.addEventListener('pointercancel', clear);
  el.addEventListener('lostpointercapture', clear);
  el.addEventListener('click', function(e){
    if(fired){ e.preventDefault(); e.stopImmediatePropagation(); fired=false; }
  }, true);
}

function hookChrome(){
  var pairs=[['file','file'],['undo','undo'],['redo','redo'],['settings','settings'],['tutorial','tutorial'],
    ['presetFigures','joints'],['freeDotTool','dot'],['dotSettings','jointTools'],
    ['plus','plus'],['minus','minus'],['fit','fit'],['panLeft','panLeft'],['panRight','panRight'],
    ['prevFrame','prevFrame'],['nextExisting','nextExisting'],['onion','onion'],['next','nextFrame'],['play','play'],
    ['saveProject','saveProject'],['loadProject','loadProject'],['imageUpload','imageUpload'],['imageRemove','imageRemove'],
    ['png','png'],['gif','gif'],['video','video'],['newProject','newProject'],['hand','hand'],['centerView','fit']];
  for(var i=0;i<pairs.length;i++){
    var el=$id(pairs[i][0]); if(el) bindHold(el, pairs[i][1]);
  }
  qsa(document,'[data-pan]').forEach(function(b){ bindHold(b,'pan'); });
  /* tabs themselves are not tools */
}

function hookDynamicButton(b, hintedId){
  var id=hintedId || idFromLabel((b.querySelector('strong')&&b.querySelector('strong').textContent)||b.textContent);
  /* Pose Rotate +15° vs art Rotate +15°: if parent is context and tab pose */
  if(id==='rotateArt15' || id==='rotateJoints15'){
    try{ if(typeof tab==='string' && tab==='pose') id='rotateJoints15'; }catch(e){}
  }
  if(id) bindHold(b, id);
}

var _origToolButton=typeof toolButton==='function'?toolButton:null;
if(_origToolButton){
  toolButton=function(name,desc,fn){
    _origToolButton(name,desc,fn);
    var grid=$id('toolGrid');
    var b=grid && grid.lastElementChild;
    if(b) hookDynamicButton(b, idFromLabel(name));
  };
}

function attachContextHolds(){
  var c=$id('context'); if(!c) return;
  var buttons=qsa(c,'button');
  for(var i=0;i<buttons.length;i++) hookDynamicButton(buttons[i]);
}
var _origUi=typeof ui==='function'?ui:null;
if(_origUi){
  ui=function(){ _origUi(); attachContextHolds(); };
}

function wirePlayer(){
  var btn=$id('tutorial'); if(btn) btn.addEventListener('click', function(){ openTutorial(); });
  var closeBtn=$id('tutorialClose');
  if(closeBtn) closeBtn.addEventListener('click', function(){ closeTutorial(); });
  var dlg=$id('tutorialDlg');
  if(dlg){ dlg.addEventListener('close', closeTutorial); }
  qsa(document,'[data-tuttab]').forEach(function(b){
    b.addEventListener('click', function(){ setTutTab(b.getAttribute('data-tuttab')); });
  });
  var play=$id('tutPlay'); if(play) play.addEventListener('click', function(){
    var v=$id('tutVideo'); if(!v) return;
    if(v.paused) v.play().catch(function(){}); else v.pause();
    syncControls();
  });
  var scrub=$id('tutScrub');
  if(scrub){
    scrub.addEventListener('pointerdown', function(){ scrub._drag=true; });
    scrub.addEventListener('pointerup', function(){ scrub._drag=false; });
    scrub.addEventListener('input', function(){
      var v=$id('tutVideo'); if(!v||!v.duration) return;
      try{ v.currentTime=v.duration*(Number(scrub.value)/1000); }catch(e){}
      syncControls();
    });
  }
  var v=$id('tutVideo');
  if(v){
    v.addEventListener('timeupdate', syncControls);
    v.addEventListener('loadedmetadata', function(){ tutState.ready=true; syncControls(); });
    v.addEventListener('play', syncControls);
    v.addEventListener('pause', syncControls);
    v.addEventListener('ended', syncControls);
    v.addEventListener('error', function(){
      var m=$id('tutVideoMsg'); if(m){ m.style.display='block'; m.textContent='Tutorial video could not be loaded offline. Check that funmotion-tutorial.mp4 is next to the page or in the APK assets.'; }
    });
  }
  $id('tutChPrev') && $id('tutChPrev').addEventListener('click', function(){ seekChapter(chapterIndexAt(($id('tutVideo')&&$id('tutVideo').currentTime)||0)-1); });
  $id('tutChNext') && $id('tutChNext').addEventListener('click', function(){ seekChapter(chapterIndexAt(($id('tutVideo')&&$id('tutVideo').currentTime)||0)+1); });
  $id('tutChapter') && $id('tutChapter').addEventListener('change', function(){ seekChapter(Number($id('tutChapter').value)||0); });
  $id('tutToolPrev') && $id('tutToolPrev').addEventListener('click', function(){ tutState.page--; renderToolPage(); });
  $id('tutToolNext') && $id('tutToolNext').addEventListener('click', function(){ tutState.page++; renderToolPage(); });
  $id('holdTipClose') && $id('holdTipClose').addEventListener('click', hideHold);
  fillChapters();
}

function attachVideoSrc(url){
  var v=$id('tutVideo'); if(!v) return;
  tutState.videoUrl=url;
  try{ v.src=url; }catch(e){}
}
function initialVideoSrc(){
  try{
    if(parent && parent!==window && parent.location){
      var href=parent.location.href||'';
      if(/android_asset/i.test(href)) return 'file:///android_asset/funmotion-tutorial.mp4';
      if(parent.location.protocol==='file:') return href.replace(/[^\/]+$/, '')+'funmotion-tutorial.mp4';
    }
  }catch(e){}
  if(location.protocol==='file:') return 'funmotion-tutorial.mp4';
  return candidateUrls('funmotion-tutorial.mp4')[0];
}
function loadAssets(){
  var v=$id('tutVideo');
  /* Direct src first — file:// sibling, APK srcdoc via file:///android_asset/, http via relative. Avoid fetch on file:// (CORS origin null). */
  if(v){
    var start=initialVideoSrc();
    attachVideoSrc(start);
    v.addEventListener('error', function onE(){
      v.removeEventListener('error', onE);
      if(location.protocol==='file:'){
        var m=$id('tutVideoMsg'); if(m && !tutState.ready){ /* file missing during recording is ok; keep quiet unless Tutorial is open */ }
        return;
      }
      loadFirst('funmotion-tutorial.mp4').then(function(blob){
        attachVideoSrc(URL.createObjectURL(blob));
      }).catch(function(){
        var m=$id('tutVideoMsg'); if(m){ m.style.display='block'; m.textContent='Tutorial video could not be loaded offline. Check that funmotion-tutorial.mp4 is next to the page or in the APK assets.'; }
      });
    });
  }
  if(location.protocol!=='file:'){
    loadFirst('funmotion-tutorial-chapters.json').then(function(blob){ return blob.text(); }).then(function(txt){
      var data=JSON.parse(txt);
      if(data && data.chapters && data.chapters.length){ tutState.chapters=data.chapters; fillChapters(); }
    }).catch(function(){});
  } else {
    /* file:// — try a script-free relative load via <video> only; keep baked-in chapters, then optional XHR isn't used. */
  }
}

hookChrome();
wirePlayer();
loadAssets();
attachContextHolds();

/* test hook — extend __FM without dropping existing fields */
var _fm=window.__FM;
window.__FM=function(){
  var s=_fm?_fm():{};
  s.ver='0.2.5';
  s.tutorialOpen=!!( $id('tutorialDlg') && $id('tutorialDlg').open );
  s.tutorialTab=tutState.tab;
  s.tutorialPage=tutState.page;
  s.toolCount=TOOLS.length;
  s.holdTip=tutState.hold;
  s.holdOpen=!!( $id('holdTip') && $id('holdTip').classList.contains('show') );
  s.videoReady=!!tutState.ready;
  s.videoSrc=!!(tutState.videoUrl || ($id('tutVideo')&&$id('tutVideo').src));
  s.chapters=tutState.chapters.map(function(c){return c.id;});
  var v=$id('tutVideo');
  s.videoTime=v? (v.currentTime||0):0;
  s.videoPaused=v? !!v.paused:true;
  return s;
};
window.__FMHold={ show:showHold, hide:hideHold, bind:bindHold, idFromLabel:idFromLabel, tools:TOOLS, draw:drawTool, open:openTutorial, close:closeTutorial, jump:jumpTool, setTab:setTutTab, page:function(n){ tutState.page=n; renderToolPage(); } };
window.__FMChapters=function(){return tutState.chapters;};
})();
