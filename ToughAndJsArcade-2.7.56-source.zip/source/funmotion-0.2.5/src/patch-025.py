#!/usr/bin/env python3
"""Build FunMotion 0.2.5 from the locked 0.2.4 COMP 1 file + tutorial assets."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
src = (ROOT / "backups/funmotion-0.2.4-COMP1.html").read_text()
css = (ROOT / "src/tutorial.css").read_text()
js = (ROOT / "src/tutorial.js").read_text()
frag = (ROOT / "src/tutorial.html").read_text()
# split fragment: nav button vs the rest
assert '<button id="tutorial">' in frag
# 1) version strings
assert src.count("0.2.4") >= 3
out = src.replace("FunMotion 0.2.4 · COMP 1", "FunMotion 0.2.5 · COMP 1")
out = out.replace("COMP 1 · 0.2.4", "COMP 1 · 0.2.5")
out = out.replace("funmotion-0.2.4.funmotion.json", "funmotion-0.2.5.funmotion.json")
out = out.replace("ver:'0.2.4'", "ver:'0.2.5'")

# 1b) t1005: rigid skin when every joint of a stroke shares one translation or rotation.
# Root cause: rebuildSkin stores falloff weights that often sum to < 1. applySkin did
# rest + sum(w_i * delta_i), so a fully selected Follow/multi-select drag left mid-shaft
# and tips lagging (Jay's arrow curved). Single-joint and partial selects still use weights.
OLD_SKIN = "function applySkin(frame){const controls=new Map(frame.objects.filter(o=>o.binding).map(o=>[o.id,o]));for(const o of frame.objects){if(!o.skin)continue;o.points=o.skin.rest.map((p,i)=>{let x=p.x,y=p.y;for(const [id,w]of o.skin.weights[i]||[]){const c=controls.get(id);if(c&&!c.binding.pinned){x+=(c.points[0].x-c.binding.restX)*w;y+=(c.points[0].y-c.binding.restY)*w}}return{x,y}})}}"
NEW_SKIN = """function rigidSkinMap(pathControls){const cs=pathControls.filter(c=>c&&c.binding);if(cs.length<2)return null;const items=cs.map(c=>({rest:{x:c.binding.restX,y:c.binding.restY},cur:{x:c.points[0].x,y:c.points[0].y}}));const eps=0.0005;const d0={dx:items[0].cur.x-items[0].rest.x,dy:items[0].cur.y-items[0].rest.y};if(items.every(it=>Math.hypot((it.cur.x-it.rest.x)-d0.dx,(it.cur.y-it.rest.y)-d0.dy)<eps))return p=>({x:p.x+d0.dx,y:p.y+d0.dy});let a=items[0],b=items.find(it=>Math.hypot(it.rest.x-a.rest.x,it.rest.y-a.rest.y)>0.5);if(!b)return null;const ang=Math.atan2(b.cur.y-a.cur.y,b.cur.x-a.cur.x)-Math.atan2(b.rest.y-a.rest.y,b.rest.x-a.rest.x),cos=Math.cos(ang),sin=Math.sin(ang);const map=p=>({x:a.cur.x+(p.x-a.rest.x)*cos-(p.y-a.rest.y)*sin,y:a.cur.y+(p.x-a.rest.x)*sin+(p.y-a.rest.y)*cos});for(const it of items){const q=map(it.rest);if(Math.hypot(q.x-it.cur.x,q.y-it.cur.y)>0.5)return null}return map}
function applySkin(frame){const controls=new Map(frame.objects.filter(o=>o.binding).map(o=>[o.id,o]));for(const o of frame.objects){if(!o.skin)continue;const pathControls=frame.objects.filter(c=>c.binding&&c.binding.pathId===o.id);const rigid=rigidSkinMap(pathControls);if(rigid){o.points=o.skin.rest.map(p=>rigid(p));continue}o.points=o.skin.rest.map((p,i)=>{let x=p.x,y=p.y;for(const [id,w]of o.skin.weights[i]||[]){const c=controls.get(id);if(c&&!c.binding.pinned){x+=(c.points[0].x-c.binding.restX)*w;y+=(c.points[0].y-c.binding.restY)*w}}return{x,y}})}}"""
assert OLD_SKIN in out, "applySkin source changed"
out = out.replace(OLD_SKIN, NEW_SKIN, 1)


# 1c) t1006: the vertical paper scrollbar used writing-mode:vertical-lr with direction:rtl,
# which put high values at the TOP. Combined with pan.y=(.5-value/1000)*span that made
# "thumb at top / drag up" show LOWER paper (inverted scrollbar). Horizontal already
# matched scrollbar semantics (slider/arrow right moves the drawing left). Leave +/−
# zoom and hand-drag (t949) unchanged. Drop rtl so value 0 sits at the top.
OLD_V = "#vRail input{writing-mode:vertical-lr;direction:rtl;width:44px;min-height:44px;flex:1;cursor:ns-resize}"
NEW_V = "#vRail input{writing-mode:vertical-lr;direction:ltr;width:44px;min-height:44px;flex:1;cursor:ns-resize}"
assert OLD_V in out, "vRail input CSS changed"
out = out.replace(OLD_V, NEW_V, 1)

# 2) CSS before </style>
assert "</style>" in out
out = out.replace("</style>", css + "\n</style>", 1)
# 3) Tutorial nav button after Settings
old_nav = '<button id="settings">Settings</button></nav>'
new_nav = '<button id="settings">Settings</button><button id="tutorial">Tutorial</button></nav>'
assert old_nav in out
out = out.replace(old_nav, new_nav, 1)
# 4) dialogs + hold tip before the first <script> (after load inputs)
insert_html = frag.split('<button id="tutorial">Tutorial</button>', 1)[1].strip()
anchor = '<input id="fileIn" type="file" accept="image/*"><input id="loadIn" type="file" accept=".json,application/json">'
assert anchor in out
out = out.replace(anchor, anchor + "\n" + insert_html, 1)
# 5) JS inside the UI IIFE (second <script>), before its closing })();
#    so renderObject / toolButton / ui / project stay in scope.
needle = "})();\n</script>"
idx = out.rfind(needle)
assert idx > 0, "UI IIFE closer not found"
bridge = "window.renderObject=renderObject;window.artCanvas=artCanvas;window.frameCanvas=frameCanvas;window.project=project;window.setTool=setTool;window.addShape=addShape;window.toolDrawer=toolDrawer;window.render=render;window.ui=ui;window.setFollowFlag=function(v){follow=v};window.selectDotKeys=function(keys){dotSelection=new Set(keys)};\n"
out = out[:idx] + "\n" + bridge + js + "\n" + out[idx:]
dest = ROOT / "funmotion.html"
dest.write_text(out)
print(f"wrote {dest} bytes={len(out.encode())} from 0.2.4 {len(src.encode())}")
