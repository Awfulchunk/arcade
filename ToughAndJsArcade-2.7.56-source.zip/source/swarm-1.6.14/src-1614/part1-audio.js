// ---------------------------------------------------------------- 7) Audio 1.6.14: simple pixel/chiptune blips + quiet beat, same-frame, quiet master, voice cap
const A13=(function(){
 let AC=null,MAST=null,COMP=null,SFX=null,ZB=null,BEAT=null,AN=null;const BUF={},voices=[],loops={},PEND=[];
 const ST={shots:0,started:0,stolen:0,dropped:{},gunDropped:0,peakVoices:0,events:[],grunts:0,moans:0,groans:0,reloads:0,boom:0,maxOffsetMs:0,ui:0,shop:0,ammo:0,beat:0};
 const CAP=24,GCAP={minigun:8,fire:4,basic:6};
 const SET=()=>window.SWARM_SET||{audio:{master:.6,sfx:.7,music:.5,mute:0}};
 function ok(){const S=SET();return AC&&AC.state==="running"&&running&&!dead&&!document.hidden&&$("swSet")&&$("swSet").style.display!=="flex"&&!S.audio.mute&&S.audio.master>0;}
 let seed=12345;const rn=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
 function mk(dur,fn){const sr=AC.sampleRate,n=Math.max(1,Math.ceil(dur*sr)),d=new Float32Array(n);fn(d,sr,n);let pk=0;for(let i=0;i<n;i++)pk=Math.max(pk,Math.abs(d[i]));if(pk>0)for(let i=0;i<n;i++)d[i]/=pk;
   for(let i=0;i<Math.min(48,n);i++){d[i]*=i/48;d[n-1-i]*=i/48;}const b=AC.createBuffer(1,n,sr);b.getChannelData(0).set(d);return b;}
 function bq(type,f,q,sr){const w=2*Math.PI*f/sr,al=Math.sin(w)/(2*q),c=Math.cos(w);let b0,b1,b2,a0=1+al,a1=-2*c,a2=1-al;
   if(type==="bp"){b0=al;b1=0;b2=-al;}else if(type==="lp"){b0=(1-c)/2;b1=1-c;b2=(1-c)/2;}else{b0=(1+c)/2;b1=-(1+c);b2=(1+c)/2;}
   let x1=0,x2=0,y1=0,y2=0;return x=>{const y=(b0*x+b1*x1+b2*x2-a1*y1-a2*y2)/a0;x2=x1;x1=x;y2=y1;y1=y;return y;};}
 const env=(t,a,d)=>t<a?t/Math.max(1e-6,a):Math.exp(-(t-a)/d);
 const sq=ph=>((ph%1)<.5?1:-1);
 const tri=ph=>{const u=(ph%1+1)%1;return u<.5?u*4-1:3-u*4;};
 // tiny distinct blips: square / triangle / noise only
 function blip(o){return mk(o.len,(d,sr,n)=>{let ph=0;const lp=o.lp?bq("lp",o.lp,.8,sr):null,hp=o.hp?bq("hp",o.hp,1,sr):null;
   for(let i=0;i<n;i++){const t=i/sr;const f=o.f1+(o.f2-o.f1)*Math.min(1,t/(o.sl||o.len));ph+=f/sr;let w=0;
     if(o.wv==="sq")w=sq(ph);else if(o.wv==="tri")w=tri(ph);else if(o.wv==="nz")w=rn();else w=sq(ph)*.6+tri(ph)*.4;
     if(o.nz)w=w*(1-o.nz)+rn()*o.nz;if(lp)w=lp(w);if(hp)w=hp(w);
     d[i]=w*env(t,o.a||.002,o.d||.04)* (o.g||1);}});}
 const RECIPES={
  basic:  {len:.07,f1:196,f2:164,wv:"sq",a:.001,d:.04,g:1},
  minigun:{len:.03,f1:330,f2:300,wv:"sq",a:.0005,d:.016,g:1},
  shotgun:{len:.1,f1:200,f2:120,wv:"nz",lp:2200,hp:400,a:.001,d:.06,g:1},
  fire:   {len:.08,f1:140,f2:90,wv:"nz",lp:700,a:.004,d:.05,g:.8,nz:.2},
  rocket: {len:.16,f1:98,f2:55,wv:"sq",lp:900,a:.002,d:.1,g:1,nz:.35},
  laser:  {len:.1,f1:880,f2:440,wv:"tri",a:.001,d:.06,g:1},
  sniper: {len:.14,f1:660,f2:220,wv:"sq",hp:200,a:.0008,d:.08,g:1,nz:.15}
 };
 function build(){if(BUF.basic)return;for(const k in RECIPES){const r=RECIPES[k];BUF[k]=[0,1,2].map(v=>{seed=401+v*91+k.charCodeAt(0)*17;return blip(Object.assign({},r,{f1:r.f1*(1+v*.02),f2:r.f2*(1-v*.02)}));});}
  BUF.boom=[blip({len:.22,f1:70,f2:36,wv:"sq",lp:500,a:.003,d:.14,g:1,nz:.5})];
  BUF.reload=[mk(.18,(d,sr,n)=>{for(let i=0;i<n;i++){const t=i/sr;let x=0;if(t<.07)x=sq(1800*t)*env(t,.001,.02);if(t>=.08)x+=sq(1200*(t-.08))*env(t-.08,.001,.025)*.8;d[i]=x;}})];
  BUF.ammo=[mk(.16,(d,sr,n)=>{const fs=[523,659,784];for(let i=0;i<n;i++){const t=i/sr;let x=0;for(let k=0;k<3;k++)if(t>=k*.045)x+=sq(fs[k]*(t-k*.045))*env(t-k*.045,.001,.03);d[i]=x;}})];
  BUF.shop=[mk(.09,(d,sr,n)=>{for(let i=0;i<n;i++){const t=i/sr;d[i]=sq(880*t)*env(t,.001,.035)+tri(1320*t)*env(t,.001,.04)*.5;}})];
  BUF.ui=[mk(.04,(d,sr,n)=>{for(let i=0;i<n;i++){const t=i/sr;d[i]=sq(2000*t)*env(t,.0006,.014);}})];
  BUF.dry=[mk(.05,(d,sr,n)=>{const hp=bq("hp",2000,1,sr);for(let i=0;i<n;i++){const t=i/sr;d[i]=hp(rn())*env(t,.0005,.01);}})];
  BUF.suck=[blip({len:.2,f1:200,f2:80,wv:"tri",a:.005,d:.12,g:1})];
  BUF.grind=[blip({len:.12,f1:90,f2:70,wv:"sq",a:.002,d:.06,g:1,nz:.4})];
  BUF.hit=[blip({len:.04,f1:180,f2:140,wv:"sq",hp:300,a:.0005,d:.018,g:1,nz:.45})];
  BUF.death=[blip({len:.09,f1:220,f2:90,wv:"tri",a:.001,d:.055,g:1})];
  // 2-bar quiet 120 BPM pixel beat (kick + hat), looped
  BUF.beat=[mk(2,(d,sr,n)=>{const lp=bq("lp",180,.8,sr),hp=bq("hp",4000,1,sr);for(let i=0;i<n;i++){const t=i/sr,beat=t*2; // 4 beats / sec at 120 BPM, 8 beats in 2 s
    const b=beat%1,bar=(beat|0)%4;let x=0;
    if(b<.12)x+=lp(tri(70*t)+rn()*.15)*env(b,.002,.07)*(bar%2===0?1:.7);
    if(b>.5&&b<.56)x+=hp(rn())*env(b-.5,.0004,.02)*.35;
    if(b>.25&&b<.28)x+=hp(rn())*env(b-.25,.0004,.012)*.18;
    d[i]=x*.55;}})];}
 function init(){if(AC)return AC;try{AC=new (window.AudioContext||window.webkitAudioContext)({latencyHint:"interactive"});}catch(e){try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e2){return null;}}
  MAST=AC.createGain();COMP=AC.createDynamicsCompressor();COMP.threshold.value=-18;COMP.knee.value=12;COMP.ratio.value=3;COMP.attack.value=.005;COMP.release.value=.2;
  SFX=AC.createGain();ZB=AC.createGain();BEAT=AC.createGain();SFX.connect(MAST);ZB.connect(MAST);BEAT.connect(MAST);MAST.connect(COMP);COMP.connect(AC.destination);AN=AC.createAnalyser();AN.fftSize=2048;COMP.connect(AN);
  BEAT.gain.value=0;build();gains();return AC;}
 let gT=0;function gains(){if(!AC)return;const S=SET().audio,m=S.mute?0:S.master*.48,duck=(AC.currentTime-lastGun<.22)?.45:1;
  MAST.gain.setTargetAtTime(m,AC.currentTime,.02);SFX.gain.setTargetAtTime(S.sfx,AC.currentTime,.02);ZB.gain.setTargetAtTime(S.sfx*.85,AC.currentTime,.02);
  const want=ok()&&!between&&S.music>0?S.music*.16*duck:0;BEAT.gain.setTargetAtTime(want,AC.currentTime,.08);}
 addEventListener("pointerdown",()=>{const c=init();if(c&&c.state!=="running"&&c.resume)c.resume().catch(function(){});},{passive:true,capture:true});
 document.addEventListener("visibilitychange",()=>{if(document.hidden){stopAll();if(AC&&AC.suspend)AC.suspend();}else if(AC&&AC.resume)AC.resume().catch(function(){});});
 function prune(){const now=AC.currentTime;for(let i=voices.length-1;i>=0;i--)if(voices[i].end<=now)voices.splice(i,1);}
 function kill(v){try{v.g.gain.cancelScheduledValues(AC.currentTime);v.g.gain.setTargetAtTime(0,AC.currentTime,.004);v.s.stop(AC.currentTime+.03);}catch(e){}v.end=0;const i=voices.indexOf(v);if(i>=0)voices.splice(i,1);ST.stolen++;}
 let lastGun=-9;
 function play(name,o){if(!ok())return null;const set=BUF[name];if(!set)return null;o=o||{};prune();const pr=o.pr||2,grp=o.grp||name;
  const same=voices.filter(v=>v.grp===grp);if(GCAP[grp]&&same.length>=GCAP[grp])kill(same[0]);
  if(voices.length>=CAP){let vic=null;for(const v of voices)if(v.pr<=pr&&(!vic||v.pr<vic.pr||(v.pr===vic.pr&&v.t0<vic.t0)))vic=v;
    if(!vic){ST.dropped[name]=(ST.dropped[name]||0)+1;if(o.gun)ST.gunDropped++;return null;}kill(vic);}
  const b=set[(Math.random()*set.length)|0],s=AC.createBufferSource(),g=AC.createGain();s.buffer=b;const rate=(o.rate||1)*(1+(Math.random()-.5)*.04);s.playbackRate.value=rate;
  g.gain.value=o.g==null?.5:o.g;s.connect(g);let out=g;if(AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=clamp((o.x||0)/260,-.6,.6);g.connect(p);out=p;}
  out.connect(o.bus==="z"?ZB:SFX);const when=AC.currentTime;s.start(when);
  const v={s,g,pr,grp,t0:when,end:when+b.duration/rate+.02};voices.push(v);s.onended=function(){const i=voices.indexOf(v);if(i>=0)voices.splice(i,1);};
  ST.started++;ST.peakVoices=Math.max(ST.peakVoices,voices.length);
  const ev={n:name,callT:performance.now(),acNow:AC.currentTime,sched:when,lat:(AC.baseLatency||0)+(AC.outputLatency||0)};ST.events.push(ev);PEND.push(ev);if(ST.events.length>400)ST.events.shift();return v;}
 const GG={basic:.38,minigun:.26,shotgun:.5,fire:.28,rocket:.48,laser:.36,sniper:.52};
 function shot(id,x,src){ST.shots++;const sub=src!=="main";lastGun=AC?AC.currentTime:0;const v=play(id,{x,g:GG[id]*(sub?.45:1),pr:3,gun:1,grp:id});if(v&&ST.events.length)ST.events[ST.events.length-1].gun=1;}
 function beatOn(on){if(!AC)return;let L=loops.beat;if(!L){if(!BUF.beat)return;const s=AC.createBufferSource(),gg=AC.createGain();s.buffer=BUF.beat[0];s.loop=true;gg.gain.value=0;s.connect(gg);gg.connect(BEAT);s.start();L=loops.beat={s,g:gg};ST.beat=1;}
  L.g.gain.setTargetAtTime(on?1:0,AC.currentTime,.1);}
 function stopLoops(force){if(!AC)return;for(const k in loops){const L=loops[k];if(force)L.g.gain.setTargetAtTime(0,AC.currentTime,.05);}}
 function stopAll(){for(const v of voices.slice())try{v.s.stop();}catch(e){}voices.length=0;stopLoops(true);beatOn(0);}
 let hitT=0,hitN=0,lastStreak=0,streak=0,moanT=-9,lastSt=-1;
 function hit(e){if(!AC)return;const now=AC.currentTime;if(now-hitT>1){hitT=now;hitN=0;}if(hitN>=6||(e._gr13&&now-e._gr13<.3))return;hitN++;e._gr13=now;
  if(play("hit",{x:e.x,g:.18,pr:1.5,bus:"z",rate:e.big?.85:e.tiny?1.2:1}))ST.grunts++;}
 const CHORD=[1,1.122,1.26,1.498,1.682];
 function kill1(e){if(!AC)return;const now=AC.currentTime;streak=now-lastStreak<.8?streak+1:0;lastStreak=now;const st=Math.min(streak,4);
  ST.streak=Math.max(ST.streak||0,streak);if(now-moanT<.12&&st===lastSt)return;moanT=now;lastSt=st;
  if(play("death",{x:e.x,g:Math.min(.42,.2*Math.pow(1.15,st)),pr:2,bus:"z",grp:"moan",rate:CHORD[st]*(e.big?.8:1)}))ST.moans++;}
 function idle(dt){if(!ok()){beatOn(0);gains();return;}gains();beatOn(!between);}
 function sfxK(k){if(k==="boom"){ST.boom++;return play("boom",{g:.55,pr:3});}if(k==="suck")return play("suck",{g:.25,pr:1});if(k==="grind")return play("grind",{g:.25,pr:1});
  if(k==="reload"){ST.reloads++;return play("reload",{g:.4,pr:2});}if(k==="ammo"){ST.ammo++;return play("ammo",{g:.35,pr:2});}
  if(k==="shop"){ST.shop++;return play("shop",{g:.28,pr:1});}if(k==="ui"){ST.ui++;return play("ui",{g:.16,pr:1});}}
 return{drawn(now){for(const e of PEND)e.drawT=now;PEND.length=0;},init,play,shot,hit,kill:kill1,idle,stopAll,ST,ok,ctx:()=>AC,an:()=>AN,voices:()=>voices.length,CAP,sfx:sfxK,RECIPES};
})();
let FRAME_T=0;window.__A13=A13;
