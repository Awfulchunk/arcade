// ---------------------------------------------------------------- 10) Panel visuals 1.6.14: range ring, panic ring, tag HP% — while the panel is open, fade on close
const VIS14={a:0,last:{panicR:0,rangeR:0,gun:"basic",tag:null,alpha:0}};
function tickVis(dt){const want=PANEL13?1:0;const k=1-Math.exp(-(dt||0)*8);VIS14.a+=(want-VIS14.a)*k;if(!PANEL13&&VIS14.a<.01)VIS14.a=0;}
function rangeR14(){const w=curW();const g=w&&G13[w.id];return g?g.rng*CFG.range/100:0;}
function panicR14(){return CFG.panic>0?CFG.panic:0;}
function ring14(R,col,lw,dash,label,bright){if(R<=0)return;const a=VIS14.a*(bright?1:0.72);
 const px=1/Math.max(.2,VS);ctx.save();ctx.globalAlpha=a;ctx.strokeStyle=col;ctx.lineWidth=(lw||2)*px;if(dash&&dash.length)ctx.setLineDash(dash.map(function(d){return d*px;}));
 ctx.beginPath();ctx.arc(0,0,R,0,Math.PI*2);ctx.stroke();
 if(label){ctx.save();ctx.scale(1,1/KY);ctx.setLineDash([]);ctx.font="bold "+Math.max(9,11*px).toFixed(1)+"px monospace";ctx.textAlign="center";ctx.textBaseline="bottom";
  const x=0,y=-R-3*px;ctx.lineWidth=3*px;ctx.strokeStyle="rgba(0,0,0,"+(a*0.85)+")";ctx.strokeText(label,x,y);ctx.fillStyle=col;ctx.fillText(label,x,y);ctx.restore();}
 ctx.restore();}
function drawVis14(){const a=VIS14.a;const foc=FOC&&FOC.id;const w=curW();const rr=rangeR14(),pr=panicR14();
 VIS14.last={panicR:pr,rangeR:rr,gun:w&&w.id,tag:null,alpha:a,foc:foc||null};
 if(a<=0)return;
 if(rr>0)ring14(rr,"#ffe066",foc==="range"?1.8:1.2,foc==="range"?[]:[5,4],"RANGE "+Math.round(rr),foc==="range"||!foc);
 if(pr>0)ring14(pr,"#ff5a3a",foc==="panic"?2:1.3,foc==="panic"?[]:[4,4],"PANIC "+pr,foc==="panic");
 if(TAG13&&TAG13.e&&TAG13.e.hp>0){const e=TAG13.e,B=box13(e),k=depthK(e.y),top=B.top/k,hw=B.hw/k;
  const pct=e.max>0?clamp(e.hp/e.max,0,1):0,thr=CFG.tag/100;
  VIS14.last.tag={x:e.x,y:e.y,hp:e.hp,max:e.max,pct:pct,thr:thr};
  upright(e.x,e.y,function(){const y=e.y+top-11,x=e.x,bw=Math.max(16,hw*2);const hi=(foc==="tag"||!foc)?0.95:0.5;
   ctx.save();ctx.globalAlpha=a*hi;
   ctx.fillStyle="#000c";ctx.fillRect(x-bw/2-1,y-3,bw+2,6);
   ctx.fillStyle="#2a2030";ctx.fillRect(x-bw/2,y-2,bw,4);
   ctx.fillStyle=pct<=thr?"#ff5a3a":"#81ad78";ctx.fillRect(x-bw/2,y-2,bw*pct,4);
   const tx=x-bw/2+bw*thr;ctx.strokeStyle="#ffe066";ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(tx,y-4);ctx.lineTo(tx,y+3);ctx.stroke();
   ctx.font="bold 7px monospace";ctx.textAlign="center";ctx.fillStyle="#ffe066";ctx.fillText(CFG.tag+"%",x,y-6);
   ctx.restore();});}
}
{const _h=window.__drawHug13;window.__drawHug13=function(){drawVis14();if(_h)_h();};}
{const _o=openPanel;openPanel=function(o){const was=PANEL13;_o(o);if(PANEL13!==was)A13.sfx("ui");};}
{const _idle=A13.idle;A13.idle=function(real){_idle(real);tickVis(real);};}
document.addEventListener("click",function(e){let n=e.target;while(n&&n!==document){
  if(n.id==="ammo13Chip"){A13.sfx("ammo");return;}
  if(n.classList&&n.classList.contains("chip")&&n.closest&&n.closest("#shop")){A13.sfx("shop");return;}
  if(n.closest&&n.closest("#ai13")&&(n.classList&&(n.classList.contains("pm")||n.classList.contains("x")||n.classList.contains("au"))||(n.tagName==="BUTTON"&&n.closest(".pre")))){A13.sfx("ui");return;}
  n=n.parentNode;}},true);
function sampleRing14(kind){const r=kind==="panic"?panicR14():rangeR14();if(r<=0||VIS14.a<=0)return{r:r,alpha:VIS14.a,hit:0,peak:0,at:0,errAt:1e9};
 shake=0;const want=kind==="panic"?{r:255,g:90,b:58}:{r:255,g:224,b:102};
 const pad=8,dpr=DPR||(cv.width/cv.clientWidth),ang=-2.15;
 const [tx,ty]=toScreen(Math.cos(ang)*r,Math.sin(ang)*r);
 const x0=Math.round((tx-pad)*dpr),x1=Math.round((tx+pad)*dpr),y0=Math.round((ty-pad)*dpr),y1=Math.round((ty+pad)*dpr);
 const sx=Math.max(0,x0),sy=Math.max(0,y0),ex=Math.min(cv.width,x1),ey=Math.min(cv.height,y1);
 if(ex<=sx||ey<=sy)return{r:r,alpha:VIS14.a,hit:0,peak:0,at:0,errAt:1e9,clip:1,scr:{tx,ty,VS,TY,DPR:dpr}};
 try{const img=ctx.getImageData(sx,sy,ex-sx,ey-sy);let best=0,at=0,hit=0;
  for(let x=0;x<img.width;x++)for(let y=0;y<img.height;y++){const i=(y*img.width+x)*4,aa=img.data[i+3];if(aa<30)continue;
   const sc=(aa/255)*Math.max(0,1-(Math.abs(img.data[i]-want.r)+Math.abs(img.data[i+1]-want.g)+Math.abs(img.data[i+2]-want.b))/240);
   if(sc>0.28)hit++;if(sc>best){best=sc;const cssX=(sx+x)/dpr,cssY=(sy+y)/dpr;at=Math.hypot((cssX-CX)/VS,(cssY-TY)/(VS*KY));}}
  return{r:r,alpha:VIS14.a,hit:hit,peak:+best.toFixed(3),at:+at.toFixed(2),errAt:+Math.abs(at-r).toFixed(2),scr:{tx,ty}};
 }catch(err){return{r:r,alpha:VIS14.a,hit:0,peak:0,at:0,errAt:1e9,err:String(err)};}}
window.__vis14={alpha:function(){return VIS14.a;},panicR:panicR14,rangeR:rangeR14,tagHp:function(){return CFG.tag;},last:function(){return VIS14.last;},tick:tickVis,sample:sampleRing14};
