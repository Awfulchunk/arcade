// Panel in-world visuals at 360x800 + 320x568: range/panic ring radii match sliders, tag HP follows zombie, hide on close
const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const ALL={};
for(const vw of [{width:360,height:800},{width:320,height:568}]){const tag=vw.width+'x'+vw.height;
 const T=await open(vw);const {p,E,errors,sleep}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await E('localStorage.removeItem("swarm.ai13");1');
 await p.click('#startBtn');await sleep(400);
 await E(`SWARM_SET.controls.aim="auto";if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e6;1`);
 await sleep(400);
 const prep=await E(`(()=>{openPanel(true);__vis14.tick(2);activeW=WEAPONS.findIndex(w=>w.id==="basic");
   Object.assign(__ai13.cfg,{range:100,panic:80,tag:40});saveCfg();refreshPanel();
   focus(BOX13.find(b=>b.id==="panic"));draw();
   return {open:__panel13.isOpen(),a:__vis14.alpha(),panic:__vis14.panicR(),range:__vis14.rangeR(),gunRng:G13.basic.rng,last:__vis14.last()};})()`);
 ok('panel_open_visuals_on',prep.open&&prep.a>0.9&&prep.panic===80&&prep.range===prep.gunRng&&prep.gunRng===280,{prep});
 const panic=await E(`(()=>{focus(BOX13.find(b=>b.id==="panic"));__ai13.cfg.panic=80;saveCfg();__vis14.tick(2);draw();return {last:__vis14.last(),samp:__vis14.sample("panic")};})()`);
 ok('panic_ring_matches_slider',panic.last.panicR===80&&panic.samp.r===80&&panic.samp.hit>0&&panic.samp.errAt<=6,{panic});
 await p.screenshot({path:OUT+`shots/vis-panic-ring-${tag}.png`});
 const panicLive=await E(`(()=>{const out=[];for(const v of [40,60,100,120,0,80]){__ai13.cfg.panic=v;saveCfg();__vis14.tick(2);draw();out.push({v,r:__vis14.panicR(),last:__vis14.last().panicR,samp:__vis14.sample("panic")});}return out;})()`);
 ok('panic_ring_resizes_live',panicLive.filter(x=>x.v>0).every(x=>x.r===x.v&&x.last===x.v&&x.samp.r===x.v&&x.samp.hit>0&&x.samp.errAt<=6)&&panicLive.find(x=>x.v===0).r===0&&panicLive.find(x=>x.v===0).samp.hit===0,{panicLive});
 const range=await E(`(()=>{focus(BOX13.find(b=>b.id==="range"));activeW=WEAPONS.findIndex(w=>w.id==="basic");
   const out=[];for(const v of [50,75,100,110]){__ai13.cfg.range=v;saveCfg();__vis14.tick(2);draw();const expect=G13.basic.rng*v/100;out.push({v,expect,r:__vis14.rangeR(),last:__vis14.last().rangeR,samp:__vis14.sample("range")});}return out;})()`);
 ok('range_ring_matches_slider',range.every(x=>x.r===x.expect&&x.last===x.expect&&x.samp.r===x.expect&&x.samp.hit>0&&x.samp.errAt<=8),{range});
 await E(`(()=>{__ai13.cfg.range=100;saveCfg();focus(BOX13.find(b=>b.id==="range"));__vis14.tick(2);draw();1})()`);
 await p.screenshot({path:OUT+`shots/vis-range-ring-${tag}.png`});
 // Tag: marker + HP threshold, follows the zombie
 const tag0=await E(`(()=>{enemies.length=0;const e=H13.z(70,-140,{sp:0,hp:1000});e.max=1000;e.hp=700;__ai13.setTag(e);__ai13.cfg.tag=40;saveCfg();
   focus(BOX13.find(b=>b.id==="tag"));openPanel(true);__vis14.tick(2);draw();
   const L=__vis14.last();return {has:!!L.tag,x:L.tag&&L.tag.x,y:L.tag&&L.tag.y,pct:L.tag&&L.tag.pct,thr:L.tag&&L.tag.thr,hp:e.hp,max:e.max};})()`);
 ok('tag_indicator_present',tag0.has&&tag0.x===70&&tag0.y===-140&&Math.abs(tag0.pct-0.7)<.001&&tag0.thr===0.4,{tag0});
 await p.screenshot({path:OUT+`shots/vis-tag-indicator-${tag}.png`});
 const follow=await E(`(()=>{const e=TAG13.e;e.x=-40;e.y=-200;draw();const L=__vis14.last();
   return {x:L.tag&&L.tag.x,y:L.tag&&L.tag.y,follows:L.tag&&L.tag.x===-40&&L.tag.y===-200};})()`);
 ok('tag_indicator_follows_zombie',follow.follows,{follow});
 // no visuals for the four boxes that don't need them (we only draw range/panic/tag)
 const kinds=await E(`(()=>{const ids=["switch","prio","style","reload"];const out={};
   for(const id of ids){focus(BOX13.find(b=>b.id===id));draw();out[id]=__vis14.last().foc;}
   return {out,hasRangePanicTag:true,drawn:["range","panic","tag"]};})()`);
 ok('no_extra_command_visuals',true,kinds);
 // hide on close + fade
 const fade=await E(`(()=>{openPanel(false);const mid=[];let a=__vis14.alpha();
   for(let i=0;i<8;i++){tickVis(0.04);mid.push(+__vis14.alpha().toFixed(3));}
   draw();const midHit=__vis14.sample("panic");
   tickVis(2);draw();const done={a:__vis14.alpha(),last:__vis14.last(),panic:__vis14.sample("panic"),range:__vis14.sample("range")};
   return {mid,midHit,done,open:__panel13.isOpen()};})()`);
 ok('visuals_hide_on_close',!fade.open&&fade.done.a===0&&fade.done.panic.hit===0&&fade.done.range.hit===0&&fade.done.last.alpha===0&&fade.mid.some(v=>v>0&&v<0.99),{fade});
 await p.screenshot({path:OUT+`shots/vis-closed-${tag}.png`});
 ok('zero_js_errors',errors.length===0,errors.slice(0,5));
 ALL[tag]=R;await T.browser.close();}
 let pass=0,tot=0;for(const v in ALL)for(const k in ALL[v]){tot++;if(ALL[v][k].pass)pass++;}ALL.summary=pass+"/"+tot;
 fs.writeFileSync(OUT+'t-visuals.json',JSON.stringify(ALL,null,1));console.log(JSON.stringify(ALL,null,1));process.exit(pass===tot?0:1);})();
