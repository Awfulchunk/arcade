// panel GUI on 360x800 + 320x568: real taps, slow-mo measured, +/- placement, presets, save, TARGET vs SETTINGS overlap, tag by tap
const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const ALL={};
for(const vw of [{width:360,height:800},{width:320,height:568}]){const tag=vw.width+'x'+vw.height;
 const T=await open(vw);const {p,E,errors,sleep}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await E('localStorage.removeItem("swarm.ai13");1');
 await p.click('#startBtn');await sleep(300);
 await E(`SWARM_SET.controls.aim="auto";if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e6;1`);
 await sleep(1500);
 const tur=await E('(()=>{const r=cv.getBoundingClientRect();return {x:r.left+CX,y:r.top+TY-10*depthK(0)*VS}})()');
 // slow-mo baseline
 const rate=async()=>{const a=await E('t');await sleep(1000);const b=await E('t');return b-a;};
 const r0=await rate();
 await p.touchscreen.tap(tur.x,tur.y);await sleep(250);
 const isOpen=await E('__panel13.isOpen()');const r1=await rate();
 ok('tap_turret_opens',isOpen,{tap:tur});
 ok('slowmo_half',isOpen&&Math.abs(r1/r0-.5)<.08,{gameSecPerRealSec_closed:+r0.toFixed(3),open:+r1.toFixed(3),ratio:+(r1/r0).toFixed(3)});
 const geo=await E(`(()=>{const P=document.getElementById("ai13"),pr=P.getBoundingClientRect();const boxes=[...P.querySelectorAll(".box")].map(b=>{const pm=[...b.querySelectorAll(".pm")].map(x=>({t:x.textContent.trim(),x:Math.round(x.getBoundingClientRect().left)}));return {nm:b.querySelector(".nm").textContent,pm}});
   const rc=id=>{const e=document.getElementById(id);if(!e)return null;const r=e.getBoundingClientRect();return {l:r.left,t:r.top,r:r.right,b:r.bottom,vis:getComputedStyle(e).display!=="none"&&getComputedStyle(e).visibility!=="hidden"}};
   return {panel:{t:pr.top,b:pr.bottom,l:pr.left,r:pr.right},vh:innerHeight,vw:innerWidth,boxes,target:rc("tmodeBtn"),settings:rc("playSettings")}})()`);
 ok('seven_boxes',geo.boxes.length===7&&geo.boxes.map(b=>b.nm).join()==="WEAPON SWITCH,FIRE RANGE,TARGET PRIORITY,FIRE STYLE,PANIC MODE,TAG,RELOAD",geo.boxes.map(b=>b.nm));
 ok('plus_left_minus_right',geo.boxes.every(b=>b.pm.length===2&&/\+/.test(b.pm[0].t)&&/[−-]/.test(b.pm[1].t)&&b.pm[0].x<b.pm[1].x),geo.boxes.map(b=>b.pm.map(q=>q.t+"@"+q.x).join(" ")));
 ok('panel_in_viewport',geo.panel.b<=geo.vh+1&&geo.panel.t>=0&&geo.panel.l>=0&&geo.panel.r<=geo.vw+1,geo.panel);
 const ov=(a,b)=>a&&b&&a.vis&&b.vis&&!(a.r<=b.l||b.r<=a.l||a.b<=b.t||b.b<=a.t);
 ok('target_not_under_settings',geo.target&&geo.settings&&!ov(geo.target,geo.settings),{target:geo.target,settings:geo.settings});
 await p.screenshot({path:OUT+`shots/panel-open-${tag}.png`});
 // tap + on FIRE RANGE (box 2): value rises; − lowers; saved
 const pmXY=await E(`(()=>{const b=document.querySelectorAll("#ai13 .box")[1];b.scrollIntoView({block:"nearest"});const q=[...b.querySelectorAll(".pm")].map(x=>{const r=x.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2}});return q})()`);
 const v0=await E('__ai13.cfg.range');await p.touchscreen.tap(pmXY[0].x,pmXY[0].y);await sleep(150);const v1=await E('__ai13.cfg.range');
 await p.touchscreen.tap(pmXY[1].x,pmXY[1].y);await sleep(150);await p.touchscreen.tap(pmXY[1].x,pmXY[1].y);await sleep(150);const v2=await E('__ai13.cfg.range');
 const saved=await E('JSON.parse(localStorage.getItem("swarm.ai13")).range');
 ok('plus_minus_change_and_save',v1>v0&&v2<v1&&saved===v2,{v0,afterPlus:v1,afterMinusX2:v2,saved});
 // presets set all 7
 const pre={};for(const k of ["safe","bal","aggro"]){const xy=await E(`(()=>{const r=document.querySelector('#ai13 .pre button[data-p="${k}"]').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2}})()`);await p.touchscreen.tap(xy.x,xy.y);await sleep(150);
   pre[k]=await E(`(()=>{const P=__ai13.PRESET13["${k}"];return Object.keys(P).every(q=>__ai13.cfg[q]===P[q])&&JSON.stringify(JSON.parse(localStorage.getItem("swarm.ai13")))===JSON.stringify(__ai13.cfg)})()`);}
 ok('presets_set_all_and_save',pre.safe&&pre.bal&&pre.aggro,pre);
 // tap on empty field closes panel, slow-mo off
 await p.touchscreen.tap(vw.width-20,90);await sleep(200);const closed=!(await E('__panel13.isOpen()'));const r2=await rate();
 ok('tap_away_closes_and_full_speed',closed&&Math.abs(r2/r0-1)<.12,{closed,ratio:+(r2/r0).toFixed(3)});
 // tag by tapping a zombie
 const zxy=await E(`(()=>{const r=cv.getBoundingClientRect();const best=H13.z(70,-170,{sp:0,hp:5e4});window.__tg=best;for(const e of enemies)if(e!==best){}const B=box13(best);best.sp=0;best.spB=0;return {x:r.left+CX+best.x*VS,y:r.top+TY+best.y*KY*VS+(B.top+B.bot)/2*VS}})()`);
 if(zxy){await p.touchscreen.tap(zxy.x,zxy.y);await sleep(200);}
 const tg=await E('!!(TAG13&&TAG13.e)');ok('tap_zombie_tags',tg,{zxy});
 if(tg){await sleep(400);await p.screenshot({path:OUT+`shots/tag-marker-${tag}.png`});}
 // persisted after reload
 const cfgBefore=await E('JSON.stringify(__ai13.cfg)');await p.reload();await sleep(800);const cfgAfter=await E('JSON.stringify(__ai13.cfg)');
 ok('settings_persist_reload',cfgBefore===cfgAfter,{cfgAfter});
 ok('zero_js_errors',errors.length===0,errors.slice(0,5));
 ALL[tag]=R;await T.browser.close();}
let pass=0,tot=0;for(const v in ALL)for(const k in ALL[v]){tot++;if(ALL[v][k].pass)pass++;}ALL.summary=pass+"/"+tot;
fs.writeFileSync(OUT+'t-panel.json',JSON.stringify(ALL,null,1));console.log(JSON.stringify(ALL,null,1));})();
