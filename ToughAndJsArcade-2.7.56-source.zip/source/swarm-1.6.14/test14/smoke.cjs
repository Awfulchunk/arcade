const {open,OUT,fs}=require('./lib.cjs');
(async()=>{
 const T=await open();const {p,E,errors,sleep}=T;
 await p.click('#startBtn');await sleep(500);
 const info=await E(`({ver:VERSION,s13:__S13.ver,hasA13:!!__A13,hasVis:!!__vis14,recipes:Object.keys(__A13.RECIPES||{}),cap:__A13.CAP})`);
 await E(`SWARM_SET.controls.aim="auto";for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=1e9;openPanel(true);__vis14.tick(2);__ai13.cfg.panic=80;__ai13.cfg.range=100;draw();1`);
 const vis=await E(`({open:__panel13.isOpen(),a:__vis14.alpha(),panic:__vis14.panicR(),range:__vis14.rangeR(),sampP:__vis14.sample("panic"),sampR:__vis14.sample("range"),last:__vis14.last()})`);
 const ctx=await E('(()=>{const c=__A13.ctx();return c?c.state:"none"})()');
 console.log(JSON.stringify({info,ctx,vis,errors:errors.slice(0,8)},null,1));
 fs.writeFileSync(OUT+'smoke.json',JSON.stringify({info,ctx,vis,errors},null,1));
 await p.screenshot({path:OUT+'shots/smoke-panel.png'});
 await T.browser.close();
 process.exit(errors.length||!vis.open?1:0);
})();
