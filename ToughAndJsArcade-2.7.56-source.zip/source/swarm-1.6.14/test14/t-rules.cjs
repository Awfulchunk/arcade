// each panel rule actually drives the auto AI + tag flow + panic + reload + ammo soft-lock + rack rate/cap
const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const T=await open();const {p,E,errors}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await p.click('#startBtn');await T.sleep(200);
 const ALL='["minigun","shotgun","fire","rocket","laser","sniper"]';
 // 1 WEAPON SWITCH: OFF(10) -> never auto switches; 2s -> switches, never faster than 2s
 let r=await E(`(()=>{wave=1;H13.scene({guns:${ALL},cfg:{switch:10,panic:0},gun:"basic"});for(let i=0;i<40;i++)H13.z(-300+i*15,-200-(i%5)*20);H13.run(20);return __S13.log.filter(l=>l.why==="switch").length})()`);
 ok('switch_off',r===0,{switches:r});
 r=await E(`(()=>{H13.scene({guns:${ALL},cfg:{switch:2,panic:0},gun:"basic"});for(let i=0;i<40;i++)H13.z(-300+i*15,-200-(i%5)*20,{hp:400});for(let i=0;i<4;i++)H13.z(-40+i*25,-90);H13.run(20);const L=__S13.log.filter(l=>l.why==="switch");let minGap=99;for(let i=1;i<L.length;i++)minGap=Math.min(minGap,L[i].t-L[i-1].t);return {n:L.length,minGap:+minGap.toFixed(2),guns:[...new Set(L.map(l=>l.gun))]}})()`);
 ok('switch_2s',r.n>0&&r.minGap>=1.95,r);
 // 2 FIRE RANGE: no main shot at a target beyond range% x gun range
 r=await E(`(()=>{const out={};for(const pct of [50,110]){H13.scene({guns:[],cfg:{range:pct,panic:0,switch:10,prio:1},gun:"basic"});for(let i=0;i<12;i++)H13.z(-110+i*20,-200-(i%3)*30,{sp:0,hp:1e4});H13.run(8);const n1=__S13.sd.length;H13.z(0,-100,{sp:0,hp:1e4});H13.run(4);
   out[pct]={farShots:n1,maxD:Math.max(0,...__S13.sd.map(s=>s[1])),lim:Math.round(280*pct/100),totalShots:__S13.sd.length};}return out;})()`);
 ok('range',r[50].farShots===0&&r[50].totalShots>0&&r[50].maxD<=r[50].lim+12&&r[110].farShots>0,r);
 // 3 TARGET PRIORITY: pick per mode
 r=await E(`(()=>{const out={};const nm=["CORE-HUGGERS","NEAREST","FASTEST","WEAKEST","STRONGEST"];for(let m=0;m<5;m++){H13.scene({guns:[],cfg:{prio:m,panic:0,switch:10},gun:"basic"});
   const A=H13.z(0,-120,{sp:10,hp:900,max:900}),B=H13.z(-90,-160,{sp:60,hp:40,max:40}),C=H13.z(100,-200,{sp:25,hp:2000,max:2000}),D=H13.z(60,-70,{sp:40,hp:300,max:300});
   for(const e of [A,B,C,D]){e.spB=e.sp;}H13.run(.05);const tg=__ai13.AIS&&window.__S13?null:null;const T=eval("AIM_T13");out[nm[m]]=T===A?"A slow/near":T===B?"B fastest/weakest":T===C?"C strongest/far":T===D?"D nearest":"none";}return out;})()`);
 ok('priority',r.NEAREST==="D nearest"&&r.STRONGEST==="C strongest/far"&&r.WEAKEST==="B fastest/weakest"&&r.FASTEST==="B fastest/weakest"&&r["CORE-HUGGERS"]!=="none",r);
 // 4 FIRE STYLE: 0 = tight bursts (lower rate, narrow), 8 = full spray (fast, wide)
 r=await E(`(()=>{const out={};for(const s of [0,8]){H13.scene({guns:[],cfg:{style:s,panic:0,switch:10,reload:1},gun:"basic"});for(let i=0;i<20;i++)H13.z(-100+i*10,-220,{sp:0,hp:1e5});H13.run(10);out[s]={shots:__S13.fired.basic||0,spr:+eval("STYLE13").spr.toFixed(2)};}return out;})()`);
 ok('fire_style',r[8].shots>r[0].shots*1.25&&r[8].spr>r[0].spr,r);
 // 5 PANIC: every owned gun one at a time, STRONG->WEAK, skip empty; reversed order; ends when ring clear
 r=await E(`(()=>{const out={};for(const ord of [0,1]){H13.scene({guns:${ALL},cfg:{panic:80,order:ord,switch:10},gun:"basic"});am("sniper").mag=0;am("sniper").res=0;
   const e=H13.z(0,-60,{sp:0,hp:1e6,max:1e6});H13.z(0,-560,{sp:0,hp:1e9});for(let i=0;i<720;i++){e.x=0;e.y=-60;update(1/60);}const P=__S13.lastPanic;out[ord?"WEAK_STRONG":"STRONG_WEAK"]=P.seq.slice(0,8);e.hp=0;H13.run(1.5);out["ended"+ord]=!__ai13.AIS.panic;}return out;})()`);
 const SW=["rocket","shotgun","laser","minigun","fire","basic"];
 ok('panic',JSON.stringify(r.STRONG_WEAK.slice(0,6))===JSON.stringify(SW)&&JSON.stringify(r.WEAK_STRONG.slice(0,6))===JSON.stringify(SW.slice().reverse())&&r.ended0&&r.ended1&&r.STRONG_WEAK.indexOf("sniper")<0,r);
 // 6 TAG: orig -> th%, tagged -> th%, kill orig, kill tagged
 r=await E(`(()=>{H13.scene({guns:[],cfg:{tag:50,panic:0,switch:10,prio:1},gun:"basic"});const O=H13.z(0,-150,{sp:0,hp:600,max:600}),G=H13.z(120,-190,{sp:0,hp:600,max:600});H13.run(.1);__ai13.setTag(G);
   const seen=[];let lastPh=-1;for(let i=0;i<60*40;i++){update(1/60);const Tg=__ai13.tag();const ph=Tg?Tg.phase:"done";if(ph!==lastPh){seen.push({ph,O:Math.round(Math.max(0,O.hp)/6),G:Math.round(Math.max(0,G.hp)/6)});lastPh=ph;}if(!Tg)break;}
   return {seen,oDead:O.hp<=0,gDead:G.hp<=0}})()`);
 const ph=r.seen.map(s=>s.ph);
 ok('tag_flow',JSON.stringify(ph)===JSON.stringify([0,1,2,3,"done"])&&r.seen[1].O<=50&&r.seen[2].G<=50&&r.seen[2].O>0&&r.seen[3].O===0&&r.seen[3].G>0&&r.oDead&&r.gDead,r);
 r=await E(`(()=>{const out={};for(const tag of [null,1]){H13.scene({guns:[],cfg:{panic:0,switch:10,prio:1},gun:"basic"});const O=H13.z(0,-150,{sp:0,hp:600,max:600}),G=H13.z(120,-190,{sp:0,hp:600,max:600});if(tag)__ai13.setTag(G);H13.run(3);out[tag?"tag":"none"]={O:Math.round(O.hp),G:Math.round(G.hp)};}return out;})()`);
 ok('tag_none_no_effect',r.none.G===600&&r.none.O<600,r);
 // 7 RELOAD: early top-up (0) vs empty-then-swap (8)
 r=await E(`(()=>{const out={};for(const rl of [0,8]){H13.scene({guns:["minigun","laser"],cfg:{reload:rl,panic:0,switch:10},gun:"laser"});const e=H13.z(0,-200,{sp:0,hp:1e6});const L=[];for(let i=0;i<60*12;i++){update(1/60);const a=__am13.get("laser");if(a.rl>0&&(!L.length||L[L.length-1].t<eval("t")-1))L.push({t:eval("t"),mag:a.mag});}
   out[rl]={reloadsAtMag:L.map(x=>x.mag).slice(0,4),swaps:__S13.log.filter(l=>l.why==="empty→swap").length};}return out;})()`);
 ok('reload',r[0].reloadsAtMag.length&&r[0].reloadsAtMag.every(m=>m>0)&&r[8].swaps>0,r);
 // AMMO never soft-locks: everything dry except BASIC, auto + manual keep firing
 r=await E(`(()=>{const out={};for(const man of [0,1]){H13.scene({guns:${ALL},cfg:{panic:60,switch:3},gun:"rocket",manual:man});for(const id of __am13.owned())if(id!=="basic"){am(id).mag=0;am(id).res=0;}
   if(man){MAIN_INPUT.fire=true;}for(let i=0;i<25;i++)H13.z(-200+i*16,-150-(i%3)*30,{hp:300});const k0=kills;H13.run(25);MAIN_INPUT.fire=false;out[man?"manual":"auto"]={gun:WEAPONS[activeW].id,basicShots:__S13.fired.basic||0,kills:kills-k0,otherShots:Object.keys(__S13.fired).filter(k=>k!=="basic").length};}return out;})()`);
 ok('ammo_no_softlock',r.auto.basicShots>20&&r.manual.basicShots>20&&r.auto.gun==="basic"&&r.manual.gun==="basic",r);
 // AMMO RACK: rate + stacking + hard cap + max 3 + only during waves + a wave of firing still drains
 r=await E(`(()=>{const out={};H13.scene({guns:${ALL}});between=true;waveActive=false;credits=1e5;const pts=[[60,40],[-60,40],[0,90],[90,-60]];const muls=[];
   for(let k=0;k<4;k++){placeMode="ammorack";tryPlaceSlot(pts[k][0],pts[k][1]);const n=slots.filter(s=>s.build==="ammorack").length;
     between=false;waveActive=true;enemies.length=0;H13.z(0,-500,{sp:0,hp:1e9});am("minigun").res=0;H13.run(10,1/60);muls.push({racks:n,minigunPerSec:+(__am13.get("minigun").res/10).toFixed(3),mul:__S13.rackMul});between=true;waveActive=false;}
   out.muls=muls;am("minigun").res=0;H13.run(10);out.betweenWaves=__am13.get("minigun").res;
   between=false;waveActive=true;am("minigun").res=1e6;H13.run(1);out.capped=__am13.get("minigun").res;return out;})()`);
 const m=r.muls;
 ok('rack_rate_cap',Math.abs(m[0].minigunPerSec-1.0)<.05&&Math.abs(m[1].minigunPerSec-1.6)<.06&&Math.abs(m[2].minigunPerSec-2.0)<.06&&m[3].racks===3&&r.betweenWaves===0&&r.capped===900,r);
 r=await E(`(()=>{H13.scene({guns:["minigun"],cfg:{switch:10,panic:0},gun:"minigun"});between=true;waveActive=false;credits=1e5;for(const q of [[60,40],[-60,40],[0,90]]){placeMode="ammorack";tryPlaceSlot(q[0],q[1]);}between=false;waveActive=true;
   const r0=__am13.get("minigun").res+__am13.get("minigun").mag;for(let i=0;i<120;i++)H13.z(-300+(i%40)*15,-180-((i/40)|0)*40,{hp:250});H13.run(60);const a=__am13.get("minigun");return {start:r0,end:a.res+a.mag,fired:__S13.fired.minigun,regen60s:Math.round(60*.6*2.0)}})()`);
 ok('rack_not_op',r.end<r.start&&r.fired>r.regen60s*3,r);
 // AMMO shop buy
 r=await E(`(()=>{H13.scene({guns:${ALL}});between=true;waveActive=false;running=true;tab="WEAPONS";credits=500;am("rocket").res=0;buildShop();const c=document.getElementById("ammo13Chip");if(!c)return {chip:false};c.onclick();return {chip:true,credits,rocketRes:__am13.get("rocket").res,basicRes:__am13.get("basic").res===null||__am13.get("basic").res===Infinity}})()`);
 ok('ammo_shop',r.chip&&r.credits===410&&r.rocketRes===16,r);
 // 7/7/7 visible kit
 r=await E(`(()=>{const out={};running=true;between=true;for(const tb of ["DEFENSE","WEAPONS","ABILITIES"]){tab=tb;buildShop();out[tb]=[...document.querySelectorAll("#shop .chip")].filter(c=>c.style.display!=="none"&&!c.classList.contains("go")&&c.id!=="ammo13Chip").map(c=>c.querySelector(".nm").dataset.raw||c.querySelector(".nm").textContent);}return out;})()`);
 ok('kit_777',r.DEFENSE.length===7&&r.WEAPONS.length===7&&r.ABILITIES.length===7&&r.DEFENSE.indexOf("AMMO RACK")>=0&&r.DEFENSE.indexOf("PITFALL")<0,r);
 R.errors=errors;const pass=Object.values(R).filter(x=>x&&x.pass).length,tot=Object.keys(R).length-1;R.summary=pass+"/"+tot;
 fs.writeFileSync(OUT+'t-rules.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1));await T.browser.close();})();
