window.H13={
 scene(o){o=o||{};resetRun();running=true;between=false;dead=false;waveActive=true;toSpawn=0;hp=maxHp=o.hp||1e9;enemies.length=0;bullets.length=0;
  SWARM_SET.controls.aim=o.manual?"manual":"auto";for(const w of WEAPONS)if(!w.hidden13)w.locked=(o.guns&&o.guns.indexOf(w.id)<0&&w.id!=="basic")?1:0;
  Object.assign(__ai13.cfg,__ai13.DEF13,o.cfg||{});__ai13.setTag(null);__ai13.AIS.panic=null;__S13.log.length=0;__S13.sd=[];__S13.fired={};
  if(o.gun){activeW=WEAPONS.findIndex(w=>w.id===o.gun);}return true;},
 z(x,y,o){spawnOne();const e=enemies[enemies.length-1];o=o||{};if(!o.keep)for(const k of ["tiny","skitter","stitcher","lantern","armored","shield","twin","twinCol","howler","bloater","boomer","spitter","spitface","gnasher","tick","dragger","crawler","curt","curtbrute","ashheart","zz","hide","flank","big","brute"])e[k]=false;e.kind=o.kind||"zombie";
  e.x=x;e.y=y;Object.assign(e,o);if(o.hp)e.max=o.hp;if(o.sp!=null)e.spB=o.sp;return e;},
 run(sec,dt,drawEvery){dt=dt||1/60;const n=Math.round(sec/dt);for(let i=0;i<n;i++){update(dt);if(drawEvery&&i%drawEvery===0)draw();if(dead)break;}return n;},
};
