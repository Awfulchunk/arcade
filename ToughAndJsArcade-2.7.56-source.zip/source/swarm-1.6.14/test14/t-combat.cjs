// huggers (0 invulnerable), flash == damage, long autoplay 0 JS errors (update + draw)
const {open,OUT,fs}=require('./lib.cjs');
(async()=>{const T=await open();const {p,E,errors}=T;const R={};const ok=(k,c,info)=>{R[k]={pass:!!c,info};};
 await p.click('#startBtn');await T.sleep(200);
 const GUNS=["basic","minigun","shotgun","fire","rocket","laser","sniper"];
 // A) every angle x body type x gun: a lone hugger at the ring must take damage
 let r=await E(`(()=>{const out={},fails=[];const types=[["zombie",{}],["crawler",{kind:"runner",crawler:true,keep:1}],["brute",{kind:"mutant",brute:true,keep:1}],["tiny",{tiny:true,keep:1}]];
  for(const g of ${JSON.stringify(GUNS)}){let n=0,hit=0;for(const [tn,to] of types)for(let k=0;k<16;k++){const a=k/16*6.283;H13.scene({guns:[g],cfg:{switch:10,panic:0,prio:0},gun:g});am(g).res=1e5;
     const e=H13.z(Math.cos(a)*16,Math.sin(a)*16,Object.assign({hp:1e5,sp:20},to));H13.z(0,-560,{sp:0,hp:1e9});aim=a+Math.PI;let f0=-1;
     for(let i=0;i<60*4;i++){update(1/60);if(e.hp<1e5)break;}n++;if(e.hp<1e5)hit++;else fails.push([g,tn,k,Math.round(Math.hypot(e.x,e.y)),__S13.fired[g]||0]);}
   out[g]=hit+"/"+n;}return {out,fails:fails.slice(0,20),nFail:fails.length}})()`);
 ok('hugger_every_angle',r.nFail===0,r);
 // B) crowd stress: 40 mixed huggers (wave-8 mix incl. specials), all guns, AI: every hugger the AI aims at takes damage (no "invulnerable"), ring gets cleared
 r=await E(`(()=>{H13.scene({guns:${JSON.stringify(GUNS.slice(1))},cfg:{panic:60}});wave=8;for(const id of __am13.owned())am(id).res=1e5;const L=[];for(let i=0;i<40;i++){const a=i/40*6.283;spawnOne();const e=enemies[enemies.length-1];e.x=Math.cos(a)*(20+i%3*8);e.y=Math.sin(a)*(20+i%3*8);if(!e.limbstack)e.hp=e.max=150;L.push(e);}H13.z(0,-560,{sp:0,hp:1e9});
  const st=new Map();let worst=0,worstShots=0;const inv=new Set(),kinds={};let tClear=-1;for(let i=0;i<60*60;i++){const sh0=__S13.shots;update(1/60);const dsh=__S13.shots-sh0;if(i%4==0)draw();const e=eval("AIM_T13");
   if(e&&e.hp>0&&Math.hypot(e.x,e.y)<13+e.r*.45+14){let s=st.get(e);if(!s){s={t:0,hp:e.hp,n:0};st.set(e,s);}if(e.hp<s.hp){s.t=0;s.n=0;s.hp=e.hp;}else{s.t+=1/60;s.n+=dsh;worst=Math.max(worst,s.t);worstShots=Math.max(worstShots,s.n);if(s.n>=6){inv.add(e);}}}
   if(tClear<0&&!L.some(e=>e.hp>0&&enemies.indexOf(e)>=0))tClear=i/60;}
  for(const e of inv){const k=Object.keys(e).filter(k=>e[k]===true||e[k]===1).join(",");kinds[k]=(kinds[k]||0)+1;}
  return {worstAimedUntouchedSec:+worst.toFixed(2),worstShotsWithoutDamage:worstShots,invulnerable:inv.size,kinds,ringClearedAtSec:tClear,leftAlive:L.filter(e=>e.hp>0&&enemies.indexOf(e)>=0).length}})()`);
 ok('hugger_crowd_stress',r.invulnerable===0&&r.leftAlive===0,r);
 // C) flash == damage + long run: waves 1..12 auto, real spawns, all guns, ammo buys + racks, draw every 3rd frame
 r=await E(`(()=>{resetRun();running=true;dead=false;SWARM_SET.controls.aim="auto";Object.assign(__ai13.cfg,__ai13.DEF13);for(const w of WEAPONS)if(!w.hidden13)w.locked=0;hp=maxHp=5000;
  between=true;waveActive=false;credits=1e5;for(const q of [[70,40],[-70,40]]){placeMode="ammorack";tryPlaceSlot(q[0],q[1]);}
  const nd=[];let healedSame=0,flashNoDmg=0,flashes=0,frames=0,waves=0;const prev=new Map();
  for(let w=1;w<=12;w++){wave=w;for(let k=0;k<900&&between;k++){startWave();if(between)update(1/60);}waves++;for(let i=0;i<60*240&&!between&&!dead;i++){for(const e of enemies)prev.set(e,[e.hp,e.hit||0]);update(1/60);frames++;if(i%3==0)draw();
     for(const e of enemies){const q=prev.get(e);if(!q)continue;if((e.hit||0)>q[1]+.01){flashes++;if(e.hp>q[0]){healedSame++;}else if(!(e.hp<q[0])){flashNoDmg++;if(nd.length<5)nd.push({hp0:q[0],hp:e.hp,max:e.max,hit0:q[1],hit:e.hit,flags:Object.keys(e).filter(k=>e[k]===true||e[k]===1).join(","),d:Math.round(Math.hypot(e.x,e.y))});}}}prev.clear();}
   if(dead)break;if(between){credits+=500;tab="WEAPONS";buildShop();const c=document.getElementById("ammo13Chip");if(c)c.onclick();}}
  return {nd,healedSameFrame_notCounted:healedSame,waves,wave,frames,dead,flashes,flashNoDmg,kills,dodges:__S13.dodge||0,shots:__S13.shots,pb:__S13.pb,ammoBuys:__S13.ammoBuys||0}})()`);
 ok('flash_equals_damage',r.flashes>100&&r.flashNoDmg===0,r);
 R.errors=errors.slice(0,20);ok('zero_js_errors',errors.length===0,{n:errors.length});
 const pass=Object.values(R).filter(x=>x&&x.pass).length,tot=Object.values(R).filter(x=>x&&x.pass!=null).length;R.summary=pass+"/"+tot;
 fs.writeFileSync(OUT+'t-combat.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1).slice(0,4000));await T.browser.close();})();
