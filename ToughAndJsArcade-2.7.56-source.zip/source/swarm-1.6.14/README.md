# Swarm 1.6.14 source (GPL)

This tree is the Swarm 1.6.14 cartridge, the 1.6.13 base it was patched from, `src-1614/` (chiptune audio + panel visuals), `build-1614.py`, tests, and the Arcade 2.7.55 assemble/verify scripts.

It does **not** include the signing keystore, KEYSTORE-INFO, the full arcade bundle, or Latch. Latch payloads in Arcade 2.7.55 are unchanged from 2.7.54; the Latch unlock code is not in this zip.

Build the cartridge with `python3 build-1614.py` (expects the 1.6.13 base at the backup path recorded in the script, or adjust). The arcade assemble script is documented in `ship14/assemble-2755.mjs` and runs on top of unpublished Arcade 2.7.54.
