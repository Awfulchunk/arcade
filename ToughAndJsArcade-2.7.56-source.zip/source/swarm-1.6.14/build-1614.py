#!/usr/bin/env python3
# Swarm 1.6.14 builder: exact-match patches on the final 1.6.13 swarm.html
import hashlib, os
D = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(D, "backups/pre-1614-20261110-2321/swarm.html")
src = open(BASE, encoding="utf-8").read()
h = hashlib.sha256(src.encode()).hexdigest()
assert h == "08ad0ceabd68ff635a350dff66453a5882df62e6dcf4545b52bcad9aa82b5a81", "base is not 1.6.13 final: " + h

def rep(old, new, count=1):
    global src
    n = src.count(old)
    assert n == count, (old[:80], n)
    src = src.replace(old, new)

rep('const VERSION="1.6.13";', 'const VERSION="1.6.14";')
rep('const S13=window.__S13={ver:"1.6.13",', 'const S13=window.__S13={ver:"1.6.14",')
rep('/* ===== 1.6.13: 7/7/7 kit, ammo + AMMO RACK, turret AI panel, hugger/hit fixes, audio engine ===== */',
    '/* ===== 1.6.14: pixel/chiptune audio + quiet beat, turret panel range/panic/tag visuals (on 1.6.13) ===== */')
rep('A13.play("reload",{g:.4})', 'A13.sfx("ammo")')

a0 = src.find("const A13=(function(){")
a1 = src.find("let FRAME_T=0;window.__A13=A13;")
assert a0 > 0 and a1 > a0
audio = open(os.path.join(D, "src-1614/part1-audio.js"), encoding="utf-8").read()
if not audio.endswith("\n"):
    audio += "\n"
# part1 already includes const A13 ... window.__A13=A13;
src = src[:a0] + audio + src[a1 + len("let FRAME_T=0;window.__A13=A13;"):]

# drop leftover blank-then-comment already there
vis = open(os.path.join(D, "src-1614/part2-visuals.js"), encoding="utf-8").read()
if not vis.endswith("\n"):
    vis += "\n"
rep("/*__T13__*/", vis + "/*__T13__*/")

out = os.path.join(D, "swarm.html")
open(out, "w", encoding="utf-8").write(src)
b = src.encode()
print("wrote", out, len(b), hashlib.sha256(b).hexdigest())
assert 'const VERSION="1.6.14"' in src
assert "window.__vis14" in src
assert "BUF.beat" in src
assert 'const VERSION="1.6.13"' not in src
