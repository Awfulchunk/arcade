// Arcade 2.7.55: swap ONLY swarm:latest (Swarm 1.6.14) on top of unpublished 2.7.54;
// the 2.7.54 Swarm (1.6.13) is kept as swarm:v1613. FunMotion 0.2.5 + tutorial assets stay byte-identical.
// Every other cartridge payload + legacy variant stays byte-for-byte as in 2.7.54.
// Old-WebView variant recomputed for the new swarm:latest only.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const BASE = "/workspace/game/build-swarm/package-2.7.55/base-2.7.54.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "cc6515533058f73daf9aee9677604a1e87a284dafcfca7cb47ea024ae261228b", "2.7.54 bundle changed?!");
const NEW = fs.readFileSync("/workspace/game/build-swarm/swarm.html", "utf8");
const OLD1613 = fs.readFileSync("/workspace/game/build-swarm/backups/pre-1614-20261110-2321/swarm.html", "utf8");
assert(sha(OLD1613) === "08ad0ceabd68ff635a350dff66453a5882df62e6dcf4545b52bcad9aa82b5a81", "1.6.13 backup changed?!");
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const before = slots(src); assert(before["swarm:latest"] && !before["swarm:v1613"], "slots");
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const G0 = GS(src); assert(G0["swarm:latest"] === OLD1613, "2.7.54 swarm:latest != 1.6.13 backup");
assert(G0["funmotion:latest"] && G0["funmotion:v024"], "funmotion slots missing");
const [a, b, oldExpr] = before["swarm:latest"];
const expr = JSON.stringify([NEW]).replace(/<\//g, "<\\/") + '.join("")';
let out = src.slice(0, a) + expr + ',\n"swarm:v1613":' + oldExpr + src.slice(b);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const GAMES = JSON.parse(gLine.slice(12).replace(/;\s*$/, "")); assert(JSON.stringify(GAMES) === gLine.slice(12).replace(/;\s*$/, ""), "GAMES roundtrip");
const sw = GAMES.find((g) => g.id === "swarm"); const cur = sw.versions.find((v) => v.id === "latest");
const prior = { ...cur, id: "v1613", name: "v1.6.13 – Prior", def: false };
sw.versions.splice(sw.versions.length - 1, 0, prior);
cur.name = "v1.6.14 – Latest";
cur.desc = "Simple pixel/chiptune gun and UI sounds with a quiet background beat. Tap the main turret for its AI panel (slow-mo): fire-range and panic rings plus a tag HP% marker appear on the field while you adjust them. 7 guns, 7 defenses, 7 abilities, ammo + AMMO RACK retained.";
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const oldLeg = LEG["swarm:latest"]; assert(oldLeg, "old swarm legacy");
const rep = {}; const parts = legacyParts(NEW, rep); assert(rep.jsFail.length === 0, "legacy js fail " + rep.jsFail);
assert(joinParts(parts, NEW) === legacyHtml(NEW, {}), "parts mismatch");
const LEG2 = {}; for (const k of Object.keys(LEG)) { LEG2[k] = k === "swarm:latest" ? parts : LEG[k]; if (k === "swarm:latest") LEG2["swarm:v1613"] = oldLeg; }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]);
assert(JSON.stringify(changed) === '["swarm:latest"]', "changed " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === '["swarm:v1613"]', "new slots");
const G1 = GS(out); assert(G1["swarm:latest"] === NEW && G1["swarm:v1613"] === OLD1613, "payloads");
for (const k of Object.keys(G0)) if (k !== "swarm:latest") assert(G0[k] === G1[k], "payload changed " + k);
assert(G1["funmotion:latest"] === G0["funmotion:latest"] && G1["funmotion:v024"] === G0["funmotion:v024"], "funmotion must be unchanged");
fs.writeFileSync(OUT, out);
const info = {
  arcadeVersion: "2.7.55", versionCode: 93, swarmVersion: "1.6.14",
  swarmSHA256: sha(NEW), swarmBytes: Buffer.byteLength(NEW),
  swarm1613SHA256: sha(OLD1613), swarm1613Bytes: Buffer.byteLength(OLD1613),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out),
  baseBundleSHA256_2754: sha(src),
  cartridgeSlots: Object.keys(after).length,
  unchangedSlots: Object.keys(before).length - 1,
  newSlot: "swarm:v1613 (= 2.7.54 swarm:latest, byte-identical 1.6.13)",
  funmotionLatestUnchanged: true,
  funmotionV024Unchanged: true,
  legacy: { swarmLatest: `css ${rep.css} js ${rep.js}`, keptOldVariantAs: "swarm:v1613", variants: Object.keys(LEG2).length },
  swarmVersionsInPicker: sw.versions.map((v) => v.name + (v.def ? " (default)" : ""))
};
fs.writeFileSync(OUT.replace(/[^/]+$/, "assembly-verification.json"), JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
