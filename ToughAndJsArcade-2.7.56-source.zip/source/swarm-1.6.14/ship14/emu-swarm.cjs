// WebView 83 emulator: Swarm 1.6.14 + panel visuals, 7 guns, v1.6.13 kept, 0 JS errors.
const connect=require('/workspace/game/build-latch/fix/cdp.cjs');const {execSync}=require('child_process');const fs=require('fs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));const OUT=__dirname+'/emu-2755/';const ADB='/workspace/tools/sdk/platform-tools/adb';
fs.mkdirSync(OUT,{recursive:true});
const shot=n=>execSync(`${ADB} exec-out screencap -p > ${OUT}${n}.png`);
(async()=>{
 let c=await connect(9333);const R={};
 // hook srcdoc before any launch (same injection as 1.6.13)
 await c.ev(`(()=>{ window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";v=v.split('/*__T13__*/').join('window.__EV13=c=>eval(c);').split('sample:sampleRing14}').join('sample:sampleRing14};window.__EV13=c=>eval(c)').split('ctx.restore()}})()})();').join('ctx.restore()}window.__EV13=c=>eval(c);})()})();');v=/<head[^>]*>/i.test(v)?v.replace(/<head[^>]*>/i,m=>m+inj):inj+v;d.set.call(this,v);},get(){return d.get.call(this);}});return 1})()`);
 R.shell=JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:navigator.userAgent,chrome:(navigator.userAgent.match(/Chrome\\/[0-9.]+/)||[])[0],swarmVersions:ARCADE.GAMES.find(g=>g.id==='swarm').versions.slice(-4).map(v=>v.id+(v.def?'*':''))})`));
 const launch=async(ver)=>{if(await c.ev("ARCADE.inGame")){await c.ev("ARCADE.back(),1");await sleep(4000);}const n0=c.ctx.length;
   await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='swarm');${ver?`ARCADE.launch(i,'${ver}')`:'ARCADE.launchCard(i)'};const e=document.getElementById('game');e.style.top='0';e.style.left='0';e.style.width='100%';e.style.height='100%';return 1})()`);
   await sleep(10000);
   const fresh=c.ctx.slice(n0).filter(x=>x.auxData&&x.auxData.isDefault);
   for(const cx of fresh.slice().reverse()){try{const t=await c.ev("typeof __EV13",cx.id);if(t==='function')return cx;}catch(e){}}
   return fresh.pop();};
 const cx=await launch(null);if(!cx){R.error='no swarm context';console.log(JSON.stringify(R,null,1));process.exit(1);}
 const E=async(js)=>c.ev('__EV13('+JSON.stringify(js)+')',cx.id);
 R.hook=await c.ev("typeof __EV13",cx.id);
 R.boot=JSON.parse(await E(`JSON.stringify({ver:typeof VERSION!=='undefined'?VERSION:(window.__S13&&__S13.ver),errs:window.__errs,legacyPrelude:typeof window.__tjGap,panel:!!window.__panel13,a13:!!window.__A13,vis:!!window.__vis14})`));
 shot('01-title');
 await E(`(()=>{document.getElementById('startBtn').click();return 1})()`);await sleep(1500);
 await E(`(()=>{SWARM_SET.controls.aim='auto';if(window.__mainControls)__mainControls();for(const w of WEAPONS)if(!w.hidden13)w.locked=0;return 1})()`);
 await sleep(3000);shot('02-wave-auto');
 const rate=async()=>{const a=JSON.parse(await E(`JSON.stringify([t,performance.now()])`));await sleep(3000);const b=JSON.parse(await E(`JSON.stringify([t,performance.now()])`));return (b[0]-a[0])/((b[1]-a[1])/1000);};
 const r0=await rate();
 await E(`(()=>{openPanel(true);__ai13.cfg.panic=80;__ai13.cfg.range=100;saveCfg();focus(BOX13.find(b=>b.id==='panic'));__vis14.tick(2);shake=0;draw();return 1})()`);
 await sleep(800);shot('03-panel-visuals');
 R.vis=JSON.parse(await E(`JSON.stringify({open:__panel13.isOpen(),a:__vis14.alpha(),panic:__vis14.panicR(),range:__vis14.rangeR(),sampP:__vis14.sample('panic'),sampR:__vis14.sample('range')})`));
 const r1=await rate();
 await E(`(()=>{openPanel(false);__vis14.tick(2);draw();return 1})()`);
 R.visClosed=JSON.parse(await E(`JSON.stringify({open:__panel13.isOpen(),a:__vis14.alpha(),hitP:__vis14.sample('panic').hit,hitR:__vis14.sample('range').hit})`));
 R.slowmo={closed:+r0.toFixed(3),open:+r1.toFixed(3),ratio:+(r1/r0).toFixed(3)};
 R.guns={};for(const g of ['basic','minigun','shotgun','fire','rocket','laser','sniper']){
  await E(`(()=>{if(between){between=false;}__ai13.set('switch',10);__ai13.set('panic',0);activeW=WEAPONS.findIndex(w=>w.id==='${g}');const a=am('${g}');if(a&&a.res!=null){a.res=Math.max(a.res,999);}for(let i=0;i<6;i++){spawnOne();const e=enemies[enemies.length-1];e.x=-90+i*36;e.y=-140-(i%2)*30;e.hp=e.max=400;e.sp=0;e.spB=0;}__S13.fired={};return 1})()`);
  await sleep(5000);R.guns[g]=JSON.parse(await E(`JSON.stringify(__S13.fired['${g}']||0)`));
  if(g==='minigun'||g==='laser')shot('04-gun-'+g);
 }
 R.after=JSON.parse(await E(`JSON.stringify({errs:window.__errs,hp:Math.round(hp),wave,huggers:__S13.huggers})`));
 R.v1613='skipped';try{const cx2=await launch('v1613');if(cx2){R.v1613=JSON.parse(await c.ev(`JSON.stringify({ver:(document.documentElement.innerHTML.match(/VERSION\\s*=\\s*["']([\\d.]+)/)||[])[1],hook:typeof __EV13,errs:window.__errs||[]})`,cx2.id));
  try{await c.ev(`__EV13('document.getElementById("startBtn")&&document.getElementById("startBtn").click(),1')`,cx2.id)}catch(e){}
  await sleep(4000);shot('05-swarm-v1613');}}catch(e){R.v1613='ERR '+e.message.slice(0,160);}
 if(await c.ev("ARCADE.inGame"))await c.ev("ARCADE.back(),1");
 const wv83=/Chrome\/83/.test(R.shell.ua||R.shell.chrome||'')||/83\.0\.4103/.test(R.shell.ua||'');
 R.webview83=wv83;
 R.pass=R.boot.ver==='1.6.14'&&R.hook==='function'&&(!R.boot.errs||R.boot.errs.length===0)&&(!R.after.errs||R.after.errs.length===0)&&Math.abs(R.slowmo.ratio-.5)<.2&&Object.entries(R.guns).every(([g,n])=>n>0)&&R.vis&&R.vis.open&&R.vis.panic===80&&R.visClosed&&R.visClosed.a===0&&R.v1613&&R.v1613.ver==='1.6.13'&&wv83;
 fs.writeFileSync(OUT+'emu-swarm.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1));c.close();process.exit(R.pass?0:1);
})().catch(e=>{console.error('ERR',e.message.slice(0,500));process.exit(1);});
