# Latch 2.1 source (Tough & J's Arcade 2.7.56) — GPL-3.0
- latch-ui/: the Latch React/TSX app (VTR-1 UI + the new Owner's Manual: src/components/bench/manual.tsx, manual-pages.ts, src/manual.css, src/assets/manual-fonts).
- manual/: generator that turns the approved paper mock into the 9 manual pages (gen-manual.mjs), subset OFL fonts, the mock.
- latch-build/build.sh: vite single-file build (chrome80 target). ship-2.7.56/: assemble on 2.7.55, verify, tests, emulator script.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.55).
- The Latch unlock code is NOT included: src/lib/bench/model.ts has `REPLACE-WITH-UNLOCK-CODE`. Put your own value there to build.
- Signing keys are not included.
