// Latch 2.1: the VTR-1 Owner's Manual. A paper book over the recorder (MENU › MANUAL). 9 fixed pages, no scrolling:
// swipe the page, tap the arrows, or tap a Contents line. CLOSE (or Esc on a keyboard) puts the recorder back exactly as it was.
import { useEffect, useLayoutEffect, useRef, useState, type PointerEvent as RPointerEvent } from "react";
import { MANUAL_PAGES } from "@/components/bench/manual-pages";
import "../../manual.css";

const N = MANUAL_PAGES.length;

export function Manual(props: { onClose: () => void; start?: number }) {
  const [cur, setCur] = useState(Math.max(0, Math.min(N - 1, props.start ?? 0)));
  const [anim, setAnim] = useState<"" | "n" | "p">("");
  const curRef = useRef(cur);
  curRef.current = cur;
  const rootRef = useRef<HTMLDivElement>(null);
  const shieldRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(props.onClose);
  closeRef.current = props.onClose;
  const swipe = useRef({ on: false, x: 0, y: 0, id: -1, swallow: 0 });

  // Touch taps act on pointerup: Chrome can drop the click of a quick tap right after a swipe, so a page-turn tap never goes missing.
  // the click that follows a handled pointerup (same gesture) is skipped; any new pointerdown clears it,
  // so a slow phone (click arriving late) never double-turns and a dropped click never blocks the next tap.
  const tapAt = useRef<{ el: Element | null }>({ el: null });
  const justTapped = (el: Element | null) => {
    if (!el || tapAt.current.el !== el) return false;
    tapAt.current.el = null;
    return true;
  };
  const inside = (e: { clientX: number; clientY: number; currentTarget: Element }) => {
    const r = e.currentTarget.getBoundingClientRect();
    return e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
  };
  const tapProps = (fn: () => void) => ({
    onPointerUp: (e: RPointerEvent<HTMLButtonElement>) => {
      if (e.pointerType === "mouse" || e.currentTarget.disabled || !inside(e)) return;
      tapAt.current = { el: e.currentTarget };
      fn();
    },
    onClick: (e: { currentTarget: Element }) => {
      if (justTapped(e.currentTarget)) return;
      fn();
    },
  });

  const go = (i: number) => {
    const to = Math.max(0, Math.min(N - 1, i));
    const from = curRef.current;
    if (to === from) return;
    curRef.current = to;
    setAnim(to > from ? "n" : "p");
    setCur(to);
  };

  // Sit right under the recorder's top bar (whatever its height is), and make the bar inert while the book is open.
  useLayoutEffect(() => {
    const place = () => {
      const root = rootRef.current;
      const bar = root?.parentElement?.querySelector<HTMLElement>(":scope > .bar");
      if (!root || !bar) return;
      const h = bar.offsetTop + bar.offsetHeight;
      root.style.top = `${h}px`;
      if (shieldRef.current) shieldRef.current.style.height = `${h}px`;
    };
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, []);

  // Keys go to the book, not to the recorder underneath (Space would toggle play there).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      e.stopImmediatePropagation();
      if (k === "ArrowRight" || k === "PageDown") go(curRef.current + 1);
      else if (k === "ArrowLeft" || k === "PageUp") go(curRef.current - 1);
      else if (k === "Home") go(0);
      else if (k === "End") go(N - 1);
      else if (k === "Escape") closeRef.current();
      else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  // Swipe: one horizontal stroke = one page. Taps still reach the Contents lines.
  useEffect(() => {
    const up = (e: PointerEvent) => {
      const s = swipe.current;
      if (!s.on || e.pointerId !== s.id) return;
      s.on = false;
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2) {
        s.swallow = 1; // the click this swipe may still fire (even late, on a slow phone) must not land on the new page
        go(curRef.current + (dx < 0 ? 1 : -1));
      } else if (e.pointerType !== "mouse" && Math.abs(dx) < 12 && Math.abs(dy) < 12) {
        const t = (e.target as Element | null)?.closest?.(".lman .lm-pages [data-go]");
        if (t) {
          tapAt.current = { el: t };
          go(Number(t.getAttribute("data-go")) - 1);
        }
      }
    };
    const cancel = () => {
      swipe.current.on = false;
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", cancel);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", cancel);
    };
  }, []);

  const pg = MANUAL_PAGES[cur];
  return (
    <>
      <div className="lman-shield" ref={shieldRef} aria-hidden onPointerDown={(e) => e.stopPropagation()} />
      <div className="lman" onPointerDownCapture={() => {
          tapAt.current.el = null;
          swipe.current.swallow = 0;
        }} ref={rootRef} role="dialog" aria-label="VTR-1 Owner’s Manual" data-page={cur + 1}>
        <div className="lm-sheet">
          <div className="lm-edges" aria-hidden>
            <i />
            <i />
          </div>
          <div className="lm-head">
            <div className="lm-ttl">VTR-1 · Owner’s Manual</div>
            <button type="button" className="lm-close" aria-label="Close manual" data-manual-close="" onClick={() => closeRef.current()}>
              × CLOSE
            </button>
          </div>
          <div
            className="lm-pages"
            onPointerDown={(e) => {
              swipe.current = { ...swipe.current, on: true, x: e.clientX, y: e.clientY, id: e.pointerId };
            }}
            onClickCapture={(e) => {
              if (swipe.current.swallow) {
                swipe.current.swallow = 0;
                e.stopPropagation();
                e.preventDefault();
                return;
              }
              const t = (e.target as Element).closest?.("[data-go]");
              if (justTapped(t)) return;
              if (t) go(Number(t.getAttribute("data-go")) - 1);
            }}
          >
            <section
              key={pg.n}
              className={`lm-pg ${pg.cls} lm-on${anim ? ` lm-in-${anim}` : ""}`}
              data-p={pg.n}
              data-name={pg.name}
              onAnimationEnd={() => setAnim("")}
              dangerouslySetInnerHTML={{ __html: pg.html }}
            />
          </div>
          <div className="lm-foot">
            <button type="button" className="lm-nav" aria-label="Previous page" data-manual-prev="" disabled={cur === 0} {...tapProps(() => go(curRef.current - 1))}>
              <svg viewBox="0 0 24 24">
                <path d="M15 5 8 12l7 7" />
              </svg>
            </button>
            <div className="lm-meta">
              <div>
                VTR-1 · <b data-manual-counter="">p.{cur + 1}</b>
              </div>
              <div className="lm-dots">
                {MANUAL_PAGES.map((p, i) => (
                  <i key={p.n} className={i === cur ? "lm-on" : ""} />
                ))}
              </div>
            </div>
            <button type="button" className="lm-nav" aria-label="Next page" data-manual-next="" disabled={cur === N - 1} {...tapProps(() => go(curRef.current + 1))}>
              <svg viewBox="0 0 24 24">
                <path d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
