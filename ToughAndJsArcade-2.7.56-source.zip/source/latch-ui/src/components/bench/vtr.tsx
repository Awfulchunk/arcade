// Latch VTR-1 shared parts: top bar, side-scroll rows with cues, fader, mode keys, hold-for-tip balloons and the ? Guide.
import { createContext, useContext, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, Ellipsis, HelpCircle, Undo2, X } from "lucide-react";

export const LATCH_VERSION = "2.1";

export const GuideCtx = createContext<{ guide: boolean; setGuide: (on: boolean) => void }>({ guide: false, setGuide: () => {} });

export function Bar(props: {
  page: "clip" | "page";
  onClip: () => void;
  onPage: () => void;
  canUndo: boolean;
  onUndo: () => void;
  onMenu: () => void;
  lit?: boolean;
  undoTip?: string;
}) {
  const { guide, setGuide } = useContext(GuideCtx);
  return (
    <div className="bar">
      <button
        type="button"
        className="k"
        aria-label="Undo"
        disabled={!props.canUndo}
        data-tip={props.undoTip ?? "Undo|Takes back your last cut, crop, grade or sticker move. Tap again to redo it."}
        data-guide="1"
        data-gl="Undo last change"
        onClick={props.onUndo}
      >
        <Undo2 className="ico" />
      </button>
      <div className="sw" role="tablist" data-guide="2" data-gl="Clip ⇄ comic page">
        <button type="button" role="tab" aria-selected={props.page === "clip"} className={props.page === "clip" ? "on" : ""} data-tip="Clip|Edit one video, GIF or still." onClick={props.onClip}>
          CLIP
        </button>
        <button type="button" role="tab" aria-selected={props.page === "page"} className={props.page === "page" ? "on" : ""} data-tip="Page|Lay stills into a comic, manga or webtoon page with bubbles." onClick={props.onPage}>
          PAGE
        </button>
      </div>
      <button
        type="button"
        className={`k${guide ? " on" : ""}`}
        aria-label="Guide"
        aria-pressed={guide}
        data-tip="Guide|Numbers every part of the screen. While it is on, tapping a button explains it instead of running it."
        data-tip-pass=""
        onClick={() => setGuide(!guide)}
      >
        <HelpCircle className="ico" />
      </button>
      <button type="button" className="k" aria-label="Menu" data-tip="Menu|Open another clip, Lock or unlock Assist, the owner’s manual." onClick={props.onMenu}>
        <Ellipsis className="ico" />
        {props.lit ? <span className="led" /> : null}
      </button>
    </div>
  );
}

/** A sideways-scrolling row. Fades plus arrow cues appear on the side that has more. */
export function HS(props: { children: ReactNode; label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [cue, setCue] = useState({ l: false, r: false });
  const update = () => {
    const el = ref.current;
    if (!el) return;
    const l = el.scrollLeft > 2;
    const r = el.scrollLeft + el.clientWidth < el.scrollWidth - 2;
    setCue((c) => (c.l === l && c.r === r ? c : { l, r }));
  };
  useLayoutEffect(update);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div className={`hs${cue.l ? " cl" : ""}${cue.r ? " cr" : ""}`} aria-label={props.label}>
      <div className="in" ref={ref} onScroll={update}>
        {props.children}
      </div>
      <span className="cue l" aria-hidden>
        <ChevronLeft className="ico" />
      </span>
      <span className="cue r" aria-hidden>
        <ChevronRight className="ico" />
      </span>
    </div>
  );
}

/** Vertical scroll body for a tool panel, with a "MORE" fade at the bottom while there is more below. */
export function Body(props: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [more, setMore] = useState(false);
  const update = () => {
    const el = ref.current;
    if (!el) return;
    const m = el.scrollTop + el.clientHeight < el.scrollHeight - 4;
    setMore((x) => (x === m ? x : m));
  };
  useLayoutEffect(update);
  return (
    <div className="dwrap">
      <div className="dbody" ref={ref} onScroll={update}>
        {props.children}
      </div>
      {more ? <span className="more">MORE ▾</span> : null}
    </div>
  );
}

export function Fader(props: {
  label: string;
  min: number;
  max: number;
  step: number;
  value: number;
  display: string;
  onChange: (n: number) => void;
  arm?: () => void;
}) {
  const drag = useRef({ x: 0, y: 0, block: false, armed: false });
  return (
    <div className="fd">
      <label>{props.label}</label>
      <input
        type="range"
        aria-label={props.label}
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        onPointerDown={(e) => {
          drag.current = { x: e.clientX, y: e.clientY, block: false, armed: false };
        }}
        onPointerMove={(e) => {
          const dx = Math.abs(e.clientX - drag.current.x);
          const dy = Math.abs(e.clientY - drag.current.y);
          if (dy > 8 && dy > dx) drag.current.block = true;
        }}
        onChange={(e) => {
          if (drag.current.block) {
            e.currentTarget.value = String(props.value);
            return;
          }
          if (!drag.current.armed) {
            drag.current.armed = true;
            props.arm?.();
          }
          props.onChange(Number(e.target.value));
        }}
      />
      <span className="val">{props.display}</span>
    </div>
  );
}

export function ModeKey(props: { n: string; label: string; icon: ReactNode; on?: boolean; hot?: boolean; tip: string; disabled?: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      className={`mk${props.on ? " on" : ""}${props.hot ? " hot" : ""}`}
      aria-pressed={!!props.on}
      aria-label={props.label}
      data-tip={props.tip}
      disabled={props.disabled}
      onClick={props.onClick}
    >
      <span className="n">{props.n}</span>
      {props.hot ? null : <span className="led" />}
      {props.icon}
      <b>{props.label}</b>
    </button>
  );
}

export function Sheet(props: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <>
      <div className="scrim" onClick={props.onClose} />
      <div className="sheet" role="dialog" aria-label={props.title}>
        <div className="dh">
          <span className="tag">
            <b>{props.title}</b>
          </span>
          <button type="button" className="done" onClick={props.onClose} aria-label="Close">
            <X className="ico sm" /> CLOSE
          </button>
        </div>
        {props.children}
      </div>
    </>
  );
}

export function ColorBars() {
  const c = ["#c0c0c0", "#c0c000", "#00c0c0", "#00c000", "#c000c0", "#c00000", "#0000c0"];
  return (
    <div className="bars" aria-hidden>
      {c.map((x) => (
        <i key={x} style={{ background: x }} />
      ))}
    </div>
  );
}

export function Brackets() {
  return (
    <>
      <span className="brk a" />
      <span className="brk b" />
      <span className="brk c" />
      <span className="brk d" />
    </>
  );
}

type Balloon = { title: string; text: string; x: number; y: number; tx: number; up: boolean };
type Mark = { n: string; label: string; x: number; y: number };

const visible = (el: Element) => {
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && (el as HTMLElement).offsetParent !== null;
};

/** Global help layer. Hold any [data-tip] control for ~0.45 s to see its balloon (the tap is then swallowed).
 *  With the Guide on, numbered markers sit on [data-guide] parts, a legend sits over the tool drawer (never over the
 *  preview), and taps explain instead of acting. */
export function Tips() {
  const { guide, setGuide } = useContext(GuideCtx);
  const guideRef = useRef(guide);
  guideRef.current = guide;
  const [balloon, setBalloon] = useState<Balloon | null>(null);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [legend, setLegend] = useState<{ left: number; width: number; top: number; height: number } | null>(null);
  const hideTimer = useRef(0);

  useEffect(() => {
    let timer = 0;
    let sx = 0;
    let sy = 0;
    let swallow = false;
    const show = (el: HTMLElement) => {
      const raw = el.getAttribute("data-tip") || "";
      const [title, text] = raw.split("|");
      const r = el.getBoundingClientRect();
      const W = window.innerWidth;
      const w = Math.min(240, W - 16);
      const cx = r.left + r.width / 2;
      const x = Math.max(8, Math.min(W - w - 8, cx - w / 2));
      const up = r.top > 110;
      const y = up ? r.top - 10 : r.bottom + 10;
      setBalloon({ title: title ?? "", text: text ?? "", x, y, tx: Math.max(10, Math.min(w - 24, cx - x - 7)), up });
      window.clearTimeout(hideTimer.current);
      hideTimer.current = window.setTimeout(() => setBalloon(null), guideRef.current ? 6000 : 3800);
    };
    const tipOf = (t: EventTarget | null) => (t instanceof Element ? (t.closest("[data-tip]") as HTMLElement | null) : null);
    const down = (e: PointerEvent) => {
      window.clearTimeout(timer);
      swallow = false;
      const el = tipOf(e.target);
      if (!guideRef.current) setBalloon(null);
      if (!el) return;
      sx = e.clientX;
      sy = e.clientY;
      timer = window.setTimeout(() => {
        swallow = true;
        navigator.vibrate?.(8);
        show(el);
      }, 450);
    };
    const move = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - sx, e.clientY - sy) > 10) window.clearTimeout(timer);
    };
    const up = () => window.clearTimeout(timer);
    const click = (e: MouseEvent) => {
      if (swallow) {
        swallow = false;
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (!guideRef.current) return;
      const el = tipOf(e.target);
      if (!el || el.hasAttribute("data-tip-pass")) return;
      e.preventDefault();
      e.stopPropagation();
      show(el);
    };
    const menu = (e: Event) => {
      if (tipOf(e.target)) e.preventDefault();
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("pointermove", move, true);
    document.addEventListener("pointerup", up, true);
    document.addEventListener("pointercancel", up, true);
    document.addEventListener("click", click, true);
    document.addEventListener("contextmenu", menu, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("pointermove", move, true);
      document.removeEventListener("pointerup", up, true);
      document.removeEventListener("pointercancel", up, true);
      document.removeEventListener("click", click, true);
      document.removeEventListener("contextmenu", menu, true);
    };
  }, []);

  useEffect(() => {
    if (!guide) {
      setMarks([]);
      setLegend(null);
      setBalloon(null);
      return;
    }
    const layout = () => {
      const els = [...document.querySelectorAll<HTMLElement>("[data-guide]")].filter(visible);
      const next: Mark[] = els.map((el) => {
        const r = el.getBoundingClientRect();
        const kind = el.getAttribute("data-gpos") || "tr";
        const x = kind === "br" ? r.right - 30 : kind === "tc" ? r.left + r.width / 2 - 12 : r.right - 20;
        const y = kind === "br" ? r.bottom - 34 : r.top - 6;
        return { n: el.getAttribute("data-guide") || "", label: el.getAttribute("data-gl") || "", x: Math.max(2, Math.min(window.innerWidth - 26, x)), y: Math.max(2, y) };
      });
      next.sort((a, b) => Number(a.n) - Number(b.n));
      setMarks((m) => (JSON.stringify(m) === JSON.stringify(next) ? m : next));
      const vf = [...document.querySelectorAll(".vf")].find(visible);
      const foot = [...document.querySelectorAll(".modes, .slot")].find(visible);
      const vb = vf?.getBoundingClientRect();
      const fb = foot?.getBoundingClientRect();
      let top = vb ? vb.bottom + 4 : 60;
      let bottom = fb ? fb.top - 2 : window.innerHeight - 70;
      if (bottom - top < 120) {
        // Not enough room between the picture and the footer.
        const empty = !!vf?.querySelector(".notape");
        if (empty) top = Math.max(56, bottom - 220); // nothing to see yet: sit over the colour bars
        else bottom = window.innerHeight - 4; // keep the picture clear; cover the footer instead
      }
      const app = [...document.querySelectorAll(".vtr")].find(visible)?.getBoundingClientRect();
      const left = (app?.left ?? 0) + 8;
      const width = (app?.width ?? window.innerWidth) - 16;
      const L = { left, width, top: Math.round(top), height: Math.max(80, Math.round(bottom - top)) };
      setLegend((p) => (p && p.left === L.left && p.width === L.width && p.top === L.top && p.height === L.height ? p : L));
    };
    layout();
    const iv = window.setInterval(layout, 400);
    window.addEventListener("resize", layout);
    return () => {
      window.clearInterval(iv);
      window.removeEventListener("resize", layout);
    };
  }, [guide]);

  return (
    <>
      {marks.map((m) => (
        <span key={m.n + m.label} className="gm" style={{ left: m.x, top: m.y }}>
          {m.n}
        </span>
      ))}
      {guide && legend ? (
        <div className="legend" style={{ left: legend.left, width: legend.width, top: legend.top, maxHeight: legend.height }} role="dialog" aria-label="Guide">
          <div className="lh">
            <span>GUIDE ON</span>
            <button type="button" data-tip-pass="" onClick={() => setGuide(false)} aria-label="Close guide">
              <X className="ico sm" /> CLOSE
            </button>
          </div>
          <ol>
            {marks.map((m) => (
              <li key={m.n + m.label}>
                <b>{m.n}</b>
                {m.label}
              </li>
            ))}
          </ol>
          <p>Tap any button now to read what it does (nothing runs). With the guide off, just hold a button for a tip.</p>
        </div>
      ) : null}
      {balloon ? (
        <div
          className={`balloon ${balloon.up ? "up" : "down"}`}
          role="tooltip"
          style={
            {
              left: balloon.x,
              top: balloon.y,
              transform: balloon.up ? "translateY(-100%)" : undefined,
              "--tx": `${balloon.tx}px`,
            } as React.CSSProperties
          }
        >
          <b>{balloon.title}</b>
          {balloon.text}
        </div>
      ) : null}
    </>
  );
}
