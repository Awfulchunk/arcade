import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowLeftRight,
  ArrowRight,
  ArrowUp,
  BookOpen,
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  Crop as CropIcon,
  Download,
  Eraser,
  FilePlus2,
  Film,
  FlipHorizontal,
  GalleryHorizontal,
  Image as ImageIcon,
  ImagePlus,
  LayoutGrid,
  Lock,
  LockOpen,
  Pause,
  PictureInPicture2,
  Play,
  Plus,
  Repeat,
  RotateCw,
  Scissors,
  SkipBack,
  SkipForward,
  Sticker as StickerIcon,
  SunMedium,
  Trash2,
  Type,
  Upload,
  Volume2,
  VolumeX,
  Wand2,
} from "lucide-react";
import { Bar, Body, Brackets, ColorBars, Fader, HS, LATCH_VERSION, ModeKey, Sheet } from "@/components/bench/vtr";
import { Manual } from "@/components/bench/manual";
import { sampleFile } from "@/lib/bench/sample";
import { paintStage, renderCrop, type Fit } from "@/lib/bench/draw";
import { exportClip, exportGif, exportStill, seek, type Look } from "@/lib/bench/export";
import { suggestCrop, suggestGrade } from "@/lib/bench/assist";
import { classifyFile, closeGif, decodeGif, frameAt, type GifClip } from "@/lib/bench/gif";
import {
  eraseAt,
  fromView,
  hitCaption,
  hitSticker,
  makeMask,
  stickerUV,
  toView,
  type Caption,
  type Dress,
  type Sticker,
  type StickerAsset,
} from "@/lib/bench/overlay";
import {
  ASPECTS,
  DEFAULT_ADJ,
  FULL,
  PRESETS,
  accepts,
  clamp,
  cropPixels,
  fitAspect,
  fmt,
  frameRatio,
  gifBudget,
  moveCrop,
  readOpen,
  resizeFree,
  resizeLocked,
  writeOpen,
  type Adj,
  type Crop,
  type Motion,
  type Scene,
  type Shape,
} from "@/lib/bench/model";

type Media =
  | { kind: "image"; name: string; w: number; h: number }
  | { kind: "video" | "gif"; name: string; w: number; h: number; duration: number };

type Held = {
  kind: "image" | "video" | "gif";
  w: number;
  h: number;
  duration: number;
  url?: string;
  image?: HTMLImageElement;
  video?: HTMLVideoElement;
  gif?: GifClip;
};

type Snap = { id: string; tool: string; name: string; data: string };
type UndoSnap = {
  crop: Crop;
  ratio: number | null;
  rot: number;
  flip: boolean;
  adj: Adj;
  straight: number;
  shape: Shape;
  inPoint: number;
  outPoint: number;
  stickers: Sticker[];
  captions: Caption[];
  scenes: Scene[];
};

type Tab = "trim" | "bounce" | "crop" | "grade" | "lay" | "scenes" | "save" | "assist";
type Handle = "move" | "nw" | "ne" | "sw" | "se";
type Sel = { kind: "sticker" | "text"; id: string } | null;


export function Editor({ onComic }: { onComic?: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const stickerRef = useRef<HTMLInputElement>(null);
  const assetsRef = useRef(new Map<string, StickerAsset>());
  const onionBuf = useRef<HTMLCanvasElement | null>(null);
  const onionTime = useRef(-1);
  const gifRef = useRef<GifClip | null>(null);
  const gifClock = useRef(0);
  const dirRef = useRef(1);
  const pongRef = useRef({ i: 0, debt: 0 });
  // 2.0 fix: bounce/reverse play from a frame cache (no seeks per frame, smooth on long-keyframe clips).
  const pongCache = useRef<{ key: string; start: number; end: number; step: number; frames: (HTMLCanvasElement | null)[]; ready: boolean } | null>(null);
  const pongClock = useRef(-1);
  // Last raw video frame drawn (small), so Grade thumbnails never wait on a seek.
  const lastFrame = useRef<HTMLCanvasElement | null>(null);
  const lastFrameAt = useRef(0);
  const smoothBuf = useRef<HTMLCanvasElement | null>(null);
  const pipRef = useRef<HTMLCanvasElement>(null);
  const pipOnRef = useRef(false);
  const joinRef = useRef<HTMLInputElement>(null);
  const transBuf = useRef<HTMLCanvasElement | null>(null);
  const scenesRef = useRef<Scene[]>([]);
  const heldRef = useRef(new Map<string, Held>());
  const reelRef = useRef({ on: false, index: 0, local: 0, fade: 0, fadeDur: 0.3, mode: "fade" as "cut" | "fade" | "dip" });
  const playingRef = useRef(false);
  const scrollGuard = useRef({ x: 0, y: 0, moved: false });
  const urlRef = useRef<string | null>(null);
  const fitRef = useRef<Fit>({ dx: 0, dy: 0, dw: 0, dh: 0 });
  const mediaRef = useRef<Media | null>(null);
  const editRef = useRef({
    rot: 0,
    flip: false,
    adj: DEFAULT_ADJ,
    straight: 0,
    crop: FULL as Crop,
    shape: "none" as Shape,
    stickers: [] as Sticker[],
    captions: [] as Caption[],
    onion: false,
    slowMid: 0,
    speed: 1,
    slower: false,
    reverse: false,
    pingpong: false,
    smooth: false,
    bounceSmooth: 0.45,
    bounceEase: 0,
    bounceSpeed: 1,
    bounceAt: 1,
    blend: 0,
  });
  const inRef = useRef(0);
  const outRef = useRef(0);
  const loopRef = useRef(true);
  const holdTimer = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const stripGen = useRef(0);

  const [media, setMedia] = useState<Media | null>(null);
  const [crop, setCrop] = useState<Crop>(FULL);
  const [ratio, setRatio] = useState<number | null>(null);
  const [rot, setRot] = useState(0);
  const [flip, setFlip] = useState(false);
  const [adj, setAdj] = useState<Adj>(DEFAULT_ADJ);
  const [tab, setTab] = useState<Tab>("trim");
  const [time, setTime] = useState(0);
  const [inPoint, setInPoint] = useState(0);
  const [outPoint, setOutPoint] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loopOn, setLoopOn] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [muted, setMuted] = useState(true);
  const [fit, setFit] = useState<Fit>({ dx: 0, dy: 0, dw: 0, dh: 0 });
  const [thumbs, setThumbs] = useState<string[]>([]);
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [note, setNote] = useState("");
  const [job, setJob] = useState<{ label: string; pct: number } | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [draft, setDraft] = useState("");
  const [fps, setFps] = useState(10);
  const [linger, setLinger] = useState(0);
  const [smooth, setSmooth] = useState(false);
  const [slower, setSlower] = useState(false);
  const [reverse, setReverse] = useState(false);
  const [pingpong, setPingpong] = useState(false);
  const [straight, setStraight] = useState(0);
  const [shape, setShape] = useState<Shape>("none");
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [captions, setCaptions] = useState<Caption[]>([]);
  const [sel, setSel] = useState<Sel>(null);
  const [tool, setTool] = useState<"place" | "erase" | "pick">("place");
  const [onion, setOnion] = useState(false);
  const [slowMid, setSlowMid] = useState(0);
  const [holdAt, setHoldAt] = useState<number | null>(null);
  const [holdMs, setHoldMs] = useState(280);
  const [edge, setEdge] = useState(360);
  const [involve, setInvolve] = useState(5);
  const [jobs, setJobs] = useState({ light: true, shade: true, blend: true, color: false });
  const [help, setHelp] = useState(false);
  const bookRef = useRef(false);
  bookRef.current = help;
  const [openPanel, setOpenPanel] = useState(false);
  const [pipOn, setPipOn] = useState(false);
  const [reelOn, setReelOn] = useState(false);
  const [bounceSmooth, setBounceSmooth] = useState(0.45);
  const [bounceEase, setBounceEase] = useState(0);
  const [bounceSpeed, setBounceSpeed] = useState(1);
  const [bounceAt, setBounceAt] = useState(1);
  const [joinTrans, setJoinTrans] = useState<"cut" | "fade" | "dip">("fade");
  const [joinMs, setJoinMs] = useState(280);
  const [snaps, setSnaps] = useState<Snap[]>([]);
  const undoRef = useRef<UndoSnap | null>(null);
  const trimArm = useRef(false);
  const [canUndo, setCanUndo] = useState(false);
  const [group, setGroup] = useState<"cut" | "look" | "add">("cut");
  const [menu, setMenu] = useState(false);
  const [hint, setHint] = useState(false);
  const [toastOn, setToastOn] = useState(false);
  const [gradeKey, setGradeKey] = useState<keyof Adj>("light");
  const [cutSel, setCutSel] = useState<"in" | "out">("in");
  const [preThumbs, setPreThumbs] = useState<Record<string, string>>({});
  const tlRef = useRef<HTMLDivElement>(null);
  const thumbWant = useRef(false);
  const thumbSrc = useRef<HTMLCanvasElement | null>(null);

  mediaRef.current = media;
  playingRef.current = playing;
  editRef.current = {
    rot,
    flip,
    adj,
    straight,
    crop,
    shape,
    stickers,
    captions,
    onion,
    slowMid,
    speed,
    slower,
    reverse,
    pingpong,
    smooth,
    bounceSmooth,
    bounceEase,
    bounceSpeed,
    bounceAt,
    blend: unlocked && jobs.blend ? involve / 10 : 0,
  };
  inRef.current = inPoint;
  outRef.current = outPoint;
  loopRef.current = loopOn;
  scenesRef.current = scenes;
  reelRef.current.on = reelOn;
  pipOnRef.current = pipOn;

  useEffect(() => {
    setUnlocked(readOpen());
    try {
      const raw = localStorage.getItem("lt.snaps");
      if (raw) setSnaps(JSON.parse(raw) as Snap[]);
    } catch {
      /* ignore broken snaps */
    }
  }, []);

  useEffect(() => {
    let raf = 0;
    let last = 0;
    let stamp = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      // 2.1: the Owner's Manual covers the picture and playback is paused, so skip the paint (keeps page turns smooth on an A03s)
      if (bookRef.current) {
        stamp = now;
        return;
      }
      if (!stamp) stamp = now;
      const dt = Math.min(0.05, (now - stamp) / 1000);
      stamp = now;
      const canvas = canvasRef.current;
      const stage = stageRef.current;
      if (!canvas || !stage) return;
      const rect = stage.getBoundingClientRect();
      if (rect.width < 2 || rect.height < 2) return;
      const m = mediaRef.current;
      const ctx = canvas.getContext("2d");
      if (!m) {
        if (ctx) {
          canvas.width = Math.max(1, Math.round(rect.width));
          canvas.height = Math.max(1, Math.round(rect.height));
          ctx.fillStyle = "#0c100e";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        return;
      }
      const stEarly = editRef.current;
      const playRate = Math.max(0.15, (stEarly.speed || 1) * (stEarly.slower ? 0.5 : 1));
      const start = inRef.current;
      const end = Math.max(start + 0.05, outRef.current);
      const bounceAt = Math.min(1, Math.max(0.2, stEarly.bounceAt || 1));
      const turn = start + (end - start) * bounceAt;
      const eased = (clock: number, from: number, to: number, base: number) => {
        let step = base * (stEarly.pingpong ? stEarly.bounceSpeed || 1 : 1);
        const ease = stEarly.bounceEase || 0;
        if (stEarly.pingpong && ease > 0.02) {
          const span = Math.max(0.05, to - from);
          const u = Math.min(1, Math.max(0, (clock - from) / span));
          const endWeight = Math.min(u, 1 - u);
          const dip = 1 - ease * 0.28 * Math.exp(-(endWeight * endWeight) / 0.04);
          step *= Math.max(0.78, dip);
        }
        return step;
      };
      const reflect = (clock: number, step: number, dir: number, from: number, to: number) => {
        let t = clock;
        let d = dir >= 0 ? 1 : -1;
        let left = Math.max(0, step);
        for (let i = 0; i < 6 && left > 0.00001; i++) {
          if (d > 0) {
            const room = to - t;
            if (left <= room) {
              t += left;
              left = 0;
            } else {
              left -= Math.max(0, room);
              t = to;
              d = -1;
            }
          } else {
            const room = t - from;
            if (left <= room) {
              t -= left;
              left = 0;
            } else {
              left -= Math.max(0, room);
              t = from;
              d = 1;
            }
          }
        }
        if (t > to) t = to;
        if (t < from) t = from;
        return { t, d };
      };
      const reelDrive = reelRef.current.on && scenesRef.current.length > 1 && playingRef.current;
      if (!reelDrive && m.kind === "gif" && playingRef.current && gifRef.current) {
        const step = eased(gifClock.current, start, stEarly.pingpong ? turn : end, dt * playRate);
        if (stEarly.pingpong) {
          const clip = gifRef.current;
          const stamps = clip.stamps;
          const span = Math.max(0.02, clip.duration);
          const indexAt = (t: number) => {
            let i = 0;
            const capped = Math.min(Math.max(t, 0), span - 0.0001);
            while (i < stamps.length - 1 && (stamps[i + 1] ?? 0) <= capped) i += 1;
            return i;
          };
          const startI = indexAt(start);
          let endI = indexAt(Math.max(start, turn - 0.0001));
          if (endI < startI) endI = startI;
          const delayOf = (i: number) => Math.max(0.02, (stamps[i + 1] ?? span) - (stamps[i] ?? 0));
          const p = pongRef.current;
          const shown = indexAt(gifClock.current);
          if (p.i < startI || p.i > endI || Math.abs(shown - p.i) > 1) {
            p.i = Math.min(endI, Math.max(startI, shown));
            p.debt = 0;
          }
          p.debt += step;
          if (p.debt >= delayOf(p.i)) {
            p.debt = 0;
            if (dirRef.current >= 0) {
              if (p.i >= endI) {
                dirRef.current = -1;
                p.i = Math.max(startI, endI - 1);
              } else p.i += 1;
            } else if (p.i <= startI) {
              dirRef.current = 1;
              p.i = Math.min(endI, startI + 1);
            } else p.i -= 1;
          }
          gifClock.current = stamps[p.i] ?? start;
        } else if (stEarly.reverse) {
          gifClock.current -= step;
          if (gifClock.current <= start) {
            if (loopRef.current) gifClock.current = end - 0.001;
            else {
              gifClock.current = start;
              playingRef.current = false;
              setPlaying(false);
            }
          }
        } else {
          dirRef.current = 1;
          gifClock.current += step;
          if (gifClock.current >= end - 0.001) {
            if (loopRef.current) gifClock.current = start;
            else {
              gifClock.current = end - 0.001;
              playingRef.current = false;
              setPlaying(false);
            }
          }
        }
      }
      // 2.0: read readiness before the bounce driver seeks, or the frame check below never passes while bouncing.
      const readyBefore = !!videoRef.current && videoRef.current.readyState >= 2;
      let cached: HTMLCanvasElement | null = null;
      const pc = pongCache.current;
      const cacheOK = !!pc && pc.ready && Math.abs(pc.start - start) < 0.01 && Math.abs(pc.end - end) < 0.01;
      if (!(playingRef.current && (stEarly.reverse || stEarly.pingpong))) pongClock.current = -1;
      if (!reelDrive && m.kind === "video" && playingRef.current && videoRef.current && (stEarly.reverse || stEarly.pingpong)) {
        const driven = videoRef.current;
        if (!driven.paused) driven.pause();
        if (cacheOK && pongClock.current < 0) pongClock.current = Math.min(end, Math.max(start, driven.currentTime));
        const clock = cacheOK ? pongClock.current : driven.currentTime;
        const step = eased(clock, start, stEarly.pingpong ? turn : end, dt * playRate);
        let t = clock;
        if (stEarly.pingpong) {
          const next = reflect(t, step, dirRef.current, start, turn);
          t = next.t;
          dirRef.current = next.d;
        } else {
          t -= step;
          if (t <= start) {
            if (loopRef.current) t = end - 0.02;
            else {
              t = start;
              playingRef.current = false;
              setPlaying(false);
            }
          }
        }
        if (cacheOK && pc) {
          pongClock.current = t;
          const fi = Math.min(pc.frames.length - 1, Math.max(0, Math.round((t - pc.start) / pc.step)));
          cached = pc.frames[fi] ?? null;
          // keep the real video loosely in step (not needed for display), so pausing lands near the same frame
          if (!driven.seeking && Math.abs(driven.currentTime - t) > 0.35) driven.currentTime = t;
        }
        // 2.0: wait for the previous seek to land, so long-GOP clips still show frames while bouncing.
        else if (Number.isFinite(t) && !driven.seeking && Math.abs(driven.currentTime - t) > 0.004) driven.currentTime = t;
      }
      if (reelDrive) {
        const reel = reelRef.current;
        const list = scenesRef.current;
        const sc = list[reel.index % list.length];
        if (sc) {
          reel.local += dt * playRate;
          const span = Math.max(0.05, sc.outPoint - sc.inPoint);
          if (reel.local >= span) {
            const shot = canvasRef.current;
            if (shot && shot.width > 2) {
              if (!transBuf.current) transBuf.current = document.createElement("canvas");
              const b = transBuf.current;
              if (b.width !== shot.width || b.height !== shot.height) {
                b.width = shot.width;
                b.height = shot.height;
              }
              b.getContext("2d")?.drawImage(shot, 0, 0);
            }
            reel.index = (reel.index + 1) % list.length;
            const next = list[reel.index];
            const mode = next?.transition ?? "cut";
            reel.mode = mode;
            reel.fadeDur = mode === "cut" ? 0 : Math.max(0.08, (next?.transMs ?? 280) / 1000);
            reel.fade = reel.fadeDur;
            reel.local = 0;
          }
          const cur = list[reel.index % list.length];
          if (cur) {
            const at = cur.inPoint + Math.min(reel.local, Math.max(0.001, cur.outPoint - cur.inPoint));
            if (!cur.sourceId) {
              if (m.kind === "gif") gifClock.current = at;
              else if (videoRef.current && Math.abs(videoRef.current.currentTime - at) > 0.05) {
                if (!videoRef.current.paused) videoRef.current.pause();
                videoRef.current.currentTime = at;
              }
            }
            editRef.current = {
              ...editRef.current,
              crop: cur.crop,
              adj: cur.adj,
              rot: cur.rot,
              flip: cur.flip,
              straight: cur.straight ?? 0,
              shape: cur.shape ?? "none",
              stickers: cur.sourceId ? [] : editRef.current.stickers,
              captions: cur.sourceId ? [] : editRef.current.captions,
            };
          }
        }
      }
      let source: CanvasImageSource | null =
        m.kind === "video"
          ? cached || videoRef.current
          : m.kind === "gif" && gifRef.current
            ? frameAt(gifRef.current, gifClock.current)
            : m.kind === "image"
              ? imageRef.current
              : null;
      let natW = m.w;
      let natH = m.h;
      if (reelDrive) {
        const cur = scenesRef.current[reelRef.current.index % Math.max(1, scenesRef.current.length)];
        if (cur?.sourceId) {
          const held = heldRef.current.get(cur.sourceId);
          const at = cur.inPoint + reelRef.current.local;
          if (held?.kind === "gif" && held.gif) {
            source = frameAt(held.gif, at);
            natW = held.w;
            natH = held.h;
          } else if (held?.kind === "image" && held.image) {
            source = held.image;
            natW = held.w;
            natH = held.h;
          } else if (held?.kind === "video" && held.video) {
            if (Math.abs(held.video.currentTime - at) > 0.08) held.video.currentTime = at;
            if (held.video.readyState >= 2) source = held.video;
            natW = held.w;
            natH = held.h;
          }
        }
      }
      if (!source) return;
      if (!reelDrive && !cached && m.kind === "video" && videoRef.current && videoRef.current.readyState < 2 && !readyBefore) return;
      if (!reelDrive && m.kind === "video" && (thumbWant.current || now - lastFrameAt.current > 700)) {
        // small copy of the frame on screen: Grade thumbnails use it at once instead of waiting on a seek
        lastFrameAt.current = now;
        const k = Math.min(1, 200 / Math.max(natW, natH));
        const lf = lastFrame.current || (lastFrame.current = document.createElement("canvas"));
        const w = Math.max(1, Math.round(natW * k)), h = Math.max(1, Math.round(natH * k));
        if (lf.width !== w || lf.height !== h) {
          lf.width = w;
          lf.height = h;
        }
        try {
          lf.getContext("2d")?.drawImage(source, 0, 0, w, h);
        } catch {
          /* not drawable yet */
        }
      }
      const st = editRef.current;
      if (thumbWant.current && m.kind === "video") {
        // Grade preset thumbnails: grab a small raw frame the moment one is on screen.
        const k = Math.min(1, 200 / Math.max(natW, natH));
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(natW * k));
        c.height = Math.max(1, Math.round(natH * k));
        c.getContext("2d")?.drawImage(source, 0, 0, c.width, c.height);
        thumbSrc.current = c;
        thumbWant.current = false;
      }
      const dress: Dress = {
        straight: st.straight,
        flip: st.flip,
        shape: st.shape,
        stickers: st.stickers,
        captions: st.captions,
        assets: assetsRef.current,
        blend: st.blend,
      };
      let underlay: HTMLCanvasElement | null = null;
      const mixAmt = st.smooth ? Math.max(0.35, st.bounceSmooth || 0.55) : st.pingpong ? st.bounceSmooth : 0;
      if (mixAmt > 0.02 && smoothBuf.current && smoothBuf.current.width > 2) underlay = smoothBuf.current;
      else if (st.onion && m.kind === "video" && onionBuf.current && onionBuf.current.width > 2) underlay = onionBuf.current;
      const next = paintStage(
        canvas,
        source,
        natW,
        natH,
        rect.width,
        rect.height,
        st.rot,
        st.flip,
        st.adj,
        st.crop,
        dress,
        underlay,
        mixAmt || 0.55,
      );
      const prev = fitRef.current;
      fitRef.current = next;
      if (reelRef.current.fade > 0 && transBuf.current) {
        const fadeCtx = canvas.getContext("2d");
        const a = Math.min(1, reelRef.current.fade / Math.max(0.05, reelRef.current.fadeDur));
        if (fadeCtx) {
          if (reelRef.current.mode === "dip") {
            fadeCtx.fillStyle = `rgba(16,20,26,${a})`;
            fadeCtx.fillRect(0, 0, canvas.width, canvas.height);
          } else if (reelRef.current.mode === "fade") {
            fadeCtx.save();
            fadeCtx.globalAlpha = a;
            fadeCtx.drawImage(transBuf.current, 0, 0, canvas.width, canvas.height);
            fadeCtx.restore();
          }
        }
        reelRef.current.fade = Math.max(0, reelRef.current.fade - dt);
      }
      const pip = pipRef.current;
      if (pipOnRef.current && pip) {
        const cropNow = editRef.current.crop;
        const size = cropPixels(natW, natH, editRef.current.rot, cropNow, 176);
        if (pip.width !== size.w || pip.height !== size.h) {
          pip.width = size.w;
          pip.height = size.h;
        }
        renderCrop(pip, source, natW, natH, editRef.current.rot, editRef.current.flip, cropNow, editRef.current.adj, dress);
      }
      if (
        Math.abs(prev.dx - next.dx) > 0.5 ||
        Math.abs(prev.dy - next.dy) > 0.5 ||
        Math.abs(prev.dw - next.dw) > 0.5 ||
        Math.abs(prev.dh - next.dh) > 0.5
      ) {
        setFit(next);
      }
      const v = videoRef.current;
      if (m.kind === "video" && v && now - last > 90) {
        last = now;
        const manual = st.reverse || st.pingpong;
        if (!manual && !v.paused) {
          const span = Math.max(0.05, outRef.current - inRef.current);
          const u = (v.currentTime - inRef.current) / span;
          const bell = Math.exp(-((u - 0.5) * (u - 0.5)) / 0.05);
          const rate = (st.slower ? 0.5 : 1) * (st.slowMid > 0 ? st.speed / (1 + st.slowMid * bell * 2) : st.speed);
          if (Math.abs(v.playbackRate - rate) > 0.04) v.playbackRate = Math.max(0.15, rate);
        }
        if (!manual && !v.paused && v.currentTime >= outRef.current - 0.03) {
          if (loopRef.current) v.currentTime = inRef.current;
          else {
            v.pause();
            setPlaying(false);
          }
        }
        setTime((prevTime) => (Math.abs(prevTime - v.currentTime) > 0.04 ? v.currentTime : prevTime));
      }
      if (m.kind === "gif" && now - last > 90) {
        last = now;
        const t = gifClock.current;
        setTime((prevTime) => (Math.abs(prevTime - t) > 0.04 ? t : prevTime));
      }
      if (st.onion && m.kind === "video" && v && v.videoWidth > 2 && Math.abs(v.currentTime - onionTime.current) > 0.12) {
        if (!onionBuf.current) onionBuf.current = document.createElement("canvas");
        const buf = onionBuf.current;
        const bw = Math.min(320, v.videoWidth);
        const bh = Math.max(1, Math.round((bw * v.videoHeight) / v.videoWidth));
        if (buf.width !== bw || buf.height !== bh) {
          buf.width = bw;
          buf.height = bh;
        }
        buf.getContext("2d")?.drawImage(v, 0, 0, bw, bh);
        onionTime.current = v.currentTime;
      }
      if ((st.smooth || mixAmt > 0.02) && source) {
        if (!smoothBuf.current) smoothBuf.current = document.createElement("canvas");
        const buf = smoothBuf.current;
        const bw = Math.min(240, m.w);
        const bh = Math.max(1, Math.round((bw * m.h) / Math.max(1, m.w)));
        if (buf.width !== bw || buf.height !== bh) {
          buf.width = bw;
          buf.height = bh;
        }
        buf.getContext("2d")?.drawImage(source, 0, 0, bw, bh);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    return () => {
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      closeGif(gifRef.current);
      for (const held of heldRef.current.values()) {
        closeGif(held.gif ?? null);
        if (held.url) URL.revokeObjectURL(held.url);
      }
      heldRef.current.clear();
    };
  }, []);

  function pick() {
    fileRef.current?.click();
  }

  async function buildStrip(url: string, duration: number) {
    const gen = ++stripGen.current;
    if (!(duration > 0)) return;
    const v = document.createElement("video");
    v.src = url;
    v.muted = true;
    v.playsInline = true;
    await new Promise<void>((resolve) => {
      v.onloadeddata = () => resolve();
      v.onerror = () => resolve();
    });
    if (stripGen.current !== gen || !v.videoWidth) return;
    const c = document.createElement("canvas");
    c.width = 96;
    c.height = 54;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const next: string[] = [];
    const n = 8;
    for (let i = 0; i < n; i++) {
      if (stripGen.current !== gen) return;
      await seek(v, (duration * (i + 0.5)) / n);
      ctx.drawImage(v, 0, 0, 96, 54);
      next.push(c.toDataURL("image/jpeg", 0.7));
    }
    if (stripGen.current === gen) setThumbs(next);
  }

  function dropGif() {
    closeGif(gifRef.current);
    gifRef.current = null;
    gifClock.current = 0;
  }

  function dropHeld() {
    for (const held of heldRef.current.values()) {
      closeGif(held.gif ?? null);
      if (held.video) {
        held.video.pause();
        held.video.removeAttribute("src");
        held.video.load();
      }
      if (held.url) URL.revokeObjectURL(held.url);
    }
    heldRef.current.clear();
  }

  function loadStill(url: string, name: string) {
    const img = new Image();
    img.onload = () => {
      imageRef.current = img;
      const v = videoRef.current;
      if (v) {
        v.removeAttribute("src");
        v.load();
      }
      setMedia({ kind: "image", name, w: img.naturalWidth, h: img.naturalHeight });
      setOpenPanel(false);
      setGroup("look");
      setPlaying(false);
    };
    img.onerror = () => setNote("That still won't open.");
    img.src = url;
  }

  async function loadFile(file: File) {
    const kind = await classifyFile(file);
    if (!kind) {
      setNote("Use a video or a still.");
      return;
    }
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    const url = URL.createObjectURL(file);
    urlRef.current = url;
    setNote("");
    setThumbs([]);
    setScenes([]);
    undoRef.current = null;
    setCanUndo(false);
    setCrop(FULL);
    setRatio(null);
    setRot(0);
    setFlip(false);
    setAdj(DEFAULT_ADJ);
    setPlaying(false);
    setReelOn(false);
    reelRef.current.on = false;
    dropHeld();
    setSpeed(1);
    setStraight(0);
    setShape("none");
    setStickers([]);
    setCaptions([]);
    setSel(null);
    setTool("place");
    setOnion(false);
    setSlowMid(0);
    setHoldAt(null);
    onionTime.current = -1;
    dropGif();
    for (const asset of assetsRef.current.values()) URL.revokeObjectURL(asset.url);
    assetsRef.current.clear();
    if (kind === "gif") {
      setNote("Reading the GIF…");
      const clip = await decodeGif(file);
      if (!clip) {
        setNote("Couldn't play that GIF, so it opened as a still.");
        loadStill(url, file.name);
        return;
      }
      gifRef.current = clip;
      imageRef.current = null;
      const v = videoRef.current;
      if (v) {
        v.pause();
        v.removeAttribute("src");
        v.load();
      }
      setMedia({ kind: "gif", name: file.name, w: clip.w, h: clip.h, duration: clip.duration });
      setInPoint(0);
      setOutPoint(clip.duration);
      setTime(0);
      gifClock.current = 0;
      setLoopOn(true);
      setPlaying(true);
      setOpenPanel(false);
      setGroup("cut");
      const c = document.createElement("canvas");
      c.width = 96;
      c.height = 54;
      const ctx = c.getContext("2d");
      const thumbsNext: string[] = [];
      if (ctx) {
        const step = Math.max(1, Math.floor(clip.frames.length / 8));
        for (let i = 0; i < clip.frames.length && thumbsNext.length < 8; i += step) {
          ctx.drawImage(clip.frames[i]!, 0, 0, 96, 54);
          thumbsNext.push(c.toDataURL("image/jpeg", 0.7));
        }
        setThumbs(thumbsNext);
      }
      setNote("GIF is playing. Loop is on.");
      return;
    }
    if (kind === "image") {
      loadStill(url, file.name);
      return;
    }
    const v = videoRef.current;
    if (!v) return;
    imageRef.current = null;
    const onMeta = () => {
      v.removeEventListener("loadedmetadata", onMeta);
      const duration = Number.isFinite(v.duration) ? v.duration : 0;
      if (!v.videoWidth || !(duration > 0)) {
        setNote("That clip won't play here. Try mp4 or webm.");
        return;
      }
      setMedia({ kind: "video", name: file.name, w: v.videoWidth, h: v.videoHeight, duration });
      setInPoint(0);
      setOutPoint(duration);
      setTime(0);
      setLoopOn(true);
      setOpenPanel(false);
      setGroup("cut");
      v.muted = true;
      setMuted(true);
      void v.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
      void buildStrip(url, duration);
    };
    v.addEventListener("loadedmetadata", onMeta);
    v.onerror = () => setNote("That clip won't play here. Try mp4 or webm.");
    v.src = url;
    v.load();
  }

  function drivenPlay() {
    return reverse || pingpong;
  }

  // 2.1 Owner's Manual: pause while the book is open, resume on close only if it was playing. Nothing else changes.
  const manualResume = useRef(false);
  // Really moving right now? A plain video asks the element (it can end on its own); GIF / bounce / reverse use the clock.
  function running() {
    if (!media || media.kind === "image") return false;
    if (media.kind === "video" && !drivenPlay()) {
      const v = videoRef.current;
      return !!v && !v.paused && !v.ended;
    }
    return playing;
  }
  function openManual() {
    manualResume.current = running();
    if (manualResume.current) togglePlay();
    setHelp(true);
  }
  function closeManual() {
    setHelp(false);
    if (manualResume.current) {
      manualResume.current = false;
      togglePlay();
    }
  }

  function togglePlay() {
    const manual = drivenPlay();
    if (media?.kind === "gif" || (media?.kind === "video" && manual)) {
      if (playing) {
        videoRef.current?.pause();
        setPlaying(false);
        return;
      }
      if (media.kind === "gif") {
        if (reverse && !pingpong) {
          if (gifClock.current <= inPoint + 0.02) gifClock.current = Math.max(inPoint, outPoint - 0.02);
        } else if (gifClock.current < inPoint || gifClock.current >= outPoint - 0.02) gifClock.current = inPoint;
      } else {
        const v = videoRef.current;
        if (!v) return;
        v.pause();
        if (reverse && !pingpong && v.currentTime <= inPoint + 0.05) v.currentTime = Math.max(inPoint, outPoint - 0.05);
        else if (!pingpong && (v.currentTime < inPoint || v.currentTime >= outPoint - 0.015)) v.currentTime = inPoint;
      }
      setPlaying(true);
      return;
    }
    const v = videoRef.current;
    if (!v || media?.kind !== "video") return;
    if (v.paused) {
      if (v.currentTime < inPoint || v.currentTime >= outPoint - 0.015) v.currentTime = inPoint;
      v.playbackRate = Math.max(0.15, speed * (slower ? 0.5 : 1));
      void v.play().catch(() => {
        v.muted = true;
        setMuted(true);
        void v.play();
      });
      setPlaying(true);
    } else {
      v.pause();
      setPlaying(false);
    }
  }

  function setBounce(on: boolean) {
    setPingpong(on);
    if (on) {
      setReverse(false);
      dirRef.current = 1;
      if (media && media.kind !== "image") setPlaying(true);
      setNote("Bounce is on. It plays to the end, then back.");
    } else setNote("Bounce is off.");
  }

  function setBackward(on: boolean) {
    setReverse(on);
    if (on) {
      setPingpong(false);
      dirRef.current = -1;
      if (media && media.kind !== "image") setPlaying(true);
      setNote("Reverse is on. Watch it play backward.");
    } else setNote("Reverse is off.");
  }

  function setSoften(on: boolean) {
    setSmooth(on);
    setNote(on ? "Smooth is on. Each frame blends with the one before it." : "Smooth is off.");
  }

  function setHalf(on: boolean) {
    setSlower(on);
    setNote(on ? "Slower is on. Half speed, on the picture and in the GIF." : "Slower is off.");
  }

  function jump(t: number) {
    if (!media || media.kind === "image") return;
    const next = clamp(t, 0, media.duration);
    if (media.kind === "gif") {
      gifClock.current = next;
      setTime(next);
      return;
    }
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = next;
    setTime(next);
  }

  function playhead() {
    if (media?.kind === "gif") return gifClock.current;
    if (media?.kind === "video" && videoRef.current) return videoRef.current.currentTime;
    return time;
  }

  function stampIn() {
    if (!media || media.kind === "image") return;
    remember();
    const t = playhead();
    setInPoint(clamp(Math.min(t, outPoint - 1 / 30), 0, media.duration));
  }

  function stampOut() {
    if (!media || media.kind === "image") return;
    remember();
    const t = playhead();
    setOutPoint(clamp(Math.max(t, inPoint + 1 / 30), 0, media.duration));
  }

  function stepFrame(frames: number) {
    if (!media || media.kind === "image" || frames === 0) return;
    if (media.kind === "gif" && gifRef.current) {
      const stamps = gifRef.current.stamps;
      const t = playhead();
      let i = 0;
      while (i < stamps.length - 1 && (stamps[i + 1] ?? 0) <= t + 0.0005) i += 1;
      const j = Math.min(stamps.length - 1, Math.max(0, i + frames));
      jump(stamps[j] ?? t);
      return;
    }
    jump(playhead() + frames / 30);
  }

  function nudgeCut(which: "in" | "out", frames: number) {
    if (!media || media.kind === "image" || frames === 0) return;
    remember();
    let delta = frames / 30;
    if (media.kind === "gif" && gifRef.current && gifRef.current.stamps.length > 1) {
      const stamps = gifRef.current.stamps;
      const i = Math.min(stamps.length - 2, Math.max(0, Math.round((playhead() / media.duration) * (stamps.length - 1))));
      const gap = Math.abs((stamps[i + 1] ?? 0) - (stamps[i] ?? 0)) || 1 / 30;
      delta = frames * gap;
    }
    const minSpan = 1 / 30;
    if (which === "in") setInPoint(clamp(Math.min(inPoint + delta, outPoint - minSpan), 0, media.duration));
    else setOutPoint(clamp(Math.max(outPoint + delta, inPoint + minSpan), 0, media.duration));
  }

  function takeSnap(): UndoSnap {
    return {
      crop: { ...crop },
      ratio,
      rot,
      flip,
      adj: { ...adj },
      straight,
      shape,
      inPoint,
      outPoint,
      stickers: stickers.map((s) => ({ ...s })),
      captions: captions.map((c) => ({ ...c })),
      scenes: scenes.map((s) => ({ ...s, crop: { ...s.crop }, adj: { ...s.adj } })),
    };
  }

  function remember() {
    undoRef.current = takeSnap();
    setCanUndo(true);
  }

  function applyUndo(s: UndoSnap) {
    setCrop(s.crop);
    setRatio(s.ratio);
    setRot(s.rot);
    setFlip(s.flip);
    setAdj(s.adj);
    setStraight(s.straight);
    setShape(s.shape);
    setInPoint(s.inPoint);
    setOutPoint(s.outPoint);
    setStickers(s.stickers);
    setCaptions(s.captions);
    setScenes(s.scenes);
  }

  function undo() {
    const prev = undoRef.current;
    if (!prev) {
      setNote("Nothing to undo.");
      return;
    }
    const now = takeSnap();
    applyUndo(prev);
    undoRef.current = now;
    setNote("Undone.");
  }

  function splitHere() {
    if (!media || media.kind === "image") {
      setNote("Open a video or a GIF to split.");
      return;
    }
    const t = clamp(playhead(), 0, media.duration);
    const minGap = 1 / 30;
    const idx = scenes.findIndex((s) => !s.sourceId && t > s.inPoint + minGap && t < s.outPoint - minGap);
    if (idx < 0 && (t <= inPoint + minGap || t >= outPoint - minGap)) {
      setNote("Put the playhead between the in and the out, then split.");
      return;
    }
    remember();
    if (idx >= 0) {
      const sc = scenes[idx]!;
      const left: Scene = { ...sc, outPoint: t, crop: { ...sc.crop }, adj: { ...sc.adj } };
      const right: Scene = {
        ...sc,
        id: crypto.randomUUID(),
        name: `${sc.name} split`,
        inPoint: t,
        crop: { ...sc.crop },
        adj: { ...sc.adj },
        transition: joinTrans,
        transMs: joinMs,
      };
      setScenes((list) => [...list.slice(0, idx), left, right, ...list.slice(idx + 1)]);
    } else {
      const piece = (name: string, inn: number, out: number, transition: "cut" | "fade" | "dip"): Scene => ({
        id: crypto.randomUUID(),
        name,
        inPoint: inn,
        outPoint: out,
        crop: { ...crop },
        adj: { ...adj },
        rot,
        flip,
        ratio,
        straight,
        shape,
        transition,
        transMs: joinMs,
      });
      const n = scenes.length;
      setScenes((list) => [
        ...list,
        piece(n === 0 ? "Before" : `Before ${n + 1}`, inPoint, t, n === 0 ? "cut" : joinTrans),
        piece(n === 0 ? "After" : `After ${n + 1}`, t, outPoint, joinTrans),
      ]);
    }
    showPanel("scenes");
    setNote("Split. The second piece uses the join transition.");
  }

  const api = useRef({ toggle: () => {}, stampIn: () => {}, stampOut: () => {}, undo: () => {} });
  api.current.toggle = togglePlay;
  api.current.stampIn = stampIn;
  api.current.stampOut = stampOut;
  api.current.undo = undo;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === " ") {
        e.preventDefault();
        api.current.toggle();
      } else if (e.key === "i" || e.key === "I") api.current.stampIn();
      else if (e.key === "o" || e.key === "O") api.current.stampOut();
      else if ((e.key === "z" || e.key === "Z") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        api.current.undo();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function beginDrag(e: React.PointerEvent, handle: Handle) {
    if (!media) return;
    remember();
    e.preventDefault();
    e.stopPropagation();
    const start = { ...crop };
    const px = e.clientX;
    const py = e.clientY;
    const frame = frameRatio(media.w, media.h, rot);
    const locked = ratio;
    const onMove = (ev: PointerEvent) => {
      const box = fitRef.current;
      if (box.dw < 2) return;
      const dx = (ev.clientX - px) / box.dw;
      const dy = (ev.clientY - py) / box.dh;
      if (handle === "move") setCrop(moveCrop(start, dx, dy));
      else if (locked == null) setCrop(resizeFree(start, dx, dy, handle));
      else setCrop(resizeLocked(start, dx, dy, handle, locked, frame));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }

  function aspectNow() {
    const box = fitRef.current;
    return box.dh > 2 ? box.dw / box.dh : 1;
  }

  function normFrom(ev: { clientX: number; clientY: number }) {
    const stage = stageRef.current;
    if (!stage) return null;
    const rect = stage.getBoundingClientRect();
    const box = fitRef.current;
    if (box.dw < 2 || box.dh < 2) return null;
    return {
      nx: (ev.clientX - rect.left - box.dx) / box.dw,
      ny: (ev.clientY - rect.top - box.dy) / box.dh,
    };
  }

  function topHit(nx: number, ny: number): Sel {
    const aspect = aspectNow();
    for (let i = captions.length - 1; i >= 0; i--) {
      const cap = captions[i]!;
      if (hitCaption(cap, nx, ny, straight, flip, aspect)) return { kind: "text", id: cap.id };
    }
    for (let i = stickers.length - 1; i >= 0; i--) {
      const st = stickers[i]!;
      const asset = assetsRef.current.get(st.id);
      if (asset && hitSticker(st, asset, nx, ny, straight, flip, aspect)) return { kind: "sticker", id: st.id };
    }
    return null;
  }

  function onStageDown(e: React.PointerEvent) {
    if (!media) return;
    if ((e.target as HTMLElement).closest("[data-handle]")) return;
    const pt = normFrom(e);
    if (!pt) return;
    if (tool === "pick") {
      e.preventDefault();
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const x = Math.min(canvas.width - 1, Math.max(0, Math.floor(((e.clientX - rect.left) / rect.width) * canvas.width)));
      const y = Math.min(canvas.height - 1, Math.max(0, Math.floor(((e.clientY - rect.top) / rect.height) * canvas.height)));
      const px = canvas.getContext("2d")?.getImageData(x, y, 1, 1).data;
      if (!px) return;
      const color = `rgb(${px[0] ?? 0}, ${px[1] ?? 0}, ${px[2] ?? 0})`;
      if (sel?.kind === "sticker") {
        setStickers((list) => list.map((s) => (s.id === sel.id ? { ...s, tintColor: color, tint: Math.max(s.tint, 0.55) } : s)));
        setNote("Tint taken from that spot.");
      } else if (sel?.kind === "text") {
        setCaptions((list) => list.map((c) => (c.id === sel.id ? { ...c, color } : c)));
        setNote("Color taken from that spot.");
      } else setNote("Select a sticker or a line first.");
      setTool("place");
      return;
    }
    if (tool === "erase" && sel?.kind === "sticker") {
      e.preventDefault();
      const stamp = (ev: { clientX: number; clientY: number }) => {
        const p = normFrom(ev);
        const st = stickers.find((s) => s.id === sel.id);
        const asset = st && assetsRef.current.get(st.id);
        if (!p || !st || !asset) return;
        const uv = stickerUV(st, asset, p.nx, p.ny, straight, flip, aspectNow());
        if (!uv) return;
        eraseAt(asset, uv.u, uv.v, 0.09);
      };
      stamp(e);
      const move = (ev: PointerEvent) => stamp(ev);
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
      return;
    }
    const hit = topHit(pt.nx, pt.ny);
    if (hit) {
      e.preventDefault();
      remember();
      setSel(hit);
      showPanel("lay");
      const item = hit.kind === "sticker" ? stickers.find((s) => s.id === hit.id) : captions.find((c) => c.id === hit.id);
      if (!item) return;
      const view = toView(item.x, item.y, straight, flip);
      const move = (ev: PointerEvent) => {
        const p = normFrom(ev);
        if (!p) return;
        const next = fromView(view.x + (p.nx - pt.nx), view.y + (p.ny - pt.ny), straight, flip);
        const x = clamp(next.x, -0.15, 1.15);
        const y = clamp(next.y, -0.15, 1.15);
        if (hit.kind === "sticker") setStickers((list) => list.map((s) => (s.id === hit.id ? { ...s, x, y } : s)));
        else setCaptions((list) => list.map((c) => (c.id === hit.id ? { ...c, x, y } : c)));
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
      return;
    }
    const inside = pt.nx >= crop.x && pt.ny >= crop.y && pt.nx <= crop.x + crop.w && pt.ny <= crop.y + crop.h;
    if (inside) beginDrag(e, "move");
  }

  function addStickerFile(file: File) {
    if (!file.type.startsWith("image/") && !/\.(png|webp|jpe?g|gif)$/i.test(file.name)) {
      setNote("Use a PNG sticker.");
      return;
    }
    if (stickers.length >= 8) {
      setNote("Eight stickers is the limit.");
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const id = crypto.randomUUID();
      remember();
      assetsRef.current.set(id, { img, mask: makeMask(img), url, rev: 0, cacheKey: "", cache: null });
      setStickers((list) => [
        ...list,
        { id, name: file.name, x: 0.5, y: 0.5, scale: 0.34, rot: 0, bend: 0, tint: 0, tintColor: "#f3efe6", shadow: 0 },
      ]);
      setSel({ kind: "sticker", id });
      showPanel("lay");
      setTool("place");
    };
    img.onerror = () => setNote("That sticker won't open.");
    img.src = url;
  }

  function addCaption() {
    if (captions.length >= 4) {
      setNote("Four lines is the limit.");
      return;
    }
    remember();
    const id = crypto.randomUUID();
    setCaptions((list) => [...list, { id, text: "Text", x: 0.5, y: 0.82, size: 0.06, color: "#f3efe6" }]);
    setSel({ kind: "text", id });
    showPanel("lay");
  }

  function removeSel() {
    if (!sel) return;
    remember();
    if (sel.kind === "sticker") {
      setStickers((list) => list.filter((s) => s.id !== sel.id));
    } else setCaptions((list) => list.filter((c) => c.id !== sel.id));
    setSel(null);
    setTool("place");
  }

  function motionNow(): Motion {
    return { smooth, slower, reverse, pingpong };
  }

  function dressNow(): Dress {
    return { straight, flip, shape, stickers, captions, assets: assetsRef.current, blend: unlocked && jobs.blend ? involve / 10 : 0 };
  }

  function lookNow(): Look {
    return { rot, flip, crop, adj, dress: dressNow() };
  }

  function motionLine() {
    const bits = [smooth && "smoothed", slower && "slower", reverse && "reversed", pingpong && "ping-pong"].filter(Boolean);
    return bits.length ? `GIF saved. ${bits.join(", ")}.` : "GIF saved.";
  }

  function frameReady() {
    if (!media) return false;
    if (media.kind === "image") return Boolean(imageRef.current);
    if (media.kind === "gif") return Boolean(gifRef.current?.frames.length);
    return Boolean(videoRef.current && videoRef.current.readyState >= 2);
  }

  function readLight() {
    const source = sourceNow();
    if (!media || !source || !frameReady() || job) {
      setNote("Need a frame on screen first.");
      return;
    }
    const next = suggestGrade(source, media.w, media.h, rot, flip, crop);
    if (!next) {
      setNote("Couldn't read that frame.");
      return;
    }
    setAdj((a) => ({ ...a, ...next }));
    showPanel("grade");
    setNote("Light read from this frame.");
  }

  function findSubject() {
    const source = sourceNow();
    if (!media || !source || !frameReady() || job) {
      setNote("Need a frame on screen first.");
      return;
    }
    const next = suggestCrop(source, media.w, media.h, rot, flip, ratio);
    if (!next) {
      setNote("Couldn't read that frame.");
      return;
    }
    if (next.w > 0.97 && next.h > 0.97) {
      setCrop(FULL);
      setNote("Nothing stood out in this frame.");
      return;
    }
    setCrop(next);
    showPanel("crop");
    setNote("Crop moved to the busiest part of the frame.");
  }

  function sourceNow(): CanvasImageSource | null {
    if (!media) return null;
    if (media.kind === "video") return videoRef.current;
    if (media.kind === "gif" && gifRef.current) return frameAt(gifRef.current, gifClock.current);
    return imageRef.current;
  }

  async function saveStill() {
    const source = sourceNow();
    if (!media || !source || job) return;
    setJob({ label: "Still", pct: 0.4 });
    try {
      await exportStill(source, media.w, media.h, lookNow(), media.name);
      setNote("Still saved.");
    } catch {
      setNote("Couldn't save that still.");
    } finally {
      setJob(null);
    }
  }

  function toggleLoop() {
    setLoopOn((on) => !on);
  }

  async function saveGif(over?: Scene) {
    if (!media || media.kind === "image" || job) return;
    const v = videoRef.current;
    if (media.kind === "video" && !v) return;
    const look: Look = over
      ? {
          rot: over.rot,
          flip: over.flip,
          crop: over.crop,
          adj: over.adj,
          dress: { ...dressNow(), straight: over.straight, shape: over.shape, flip: over.flip },
        }
      : lookNow();
    const start = over?.inPoint ?? inPoint;
    const span = (over?.outPoint ?? outPoint) - start;
    const end = start + span * (pingpong && !over ? bounceAt : 1);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setJob({ label: "GIF", pct: 0 });
    const resume = media.kind === "gif" && playing;
    if (v && media.kind === "video") v.pause();
    setPlaying(false);
    const restore = media.kind === "gif" ? gifClock.current : (v?.currentTime ?? 0);
    try {
      const result = await exportGif({
        video: media.kind === "video" ? (v ?? undefined) : undefined,
        paintAt:
          media.kind === "gif"
            ? (t) => (gifRef.current ? frameAt(gifRef.current, t) : null)
            : undefined,
        natW: media.w,
        natH: media.h,
        look,
        inPoint: start,
        outPoint: end,
        fps: Math.max(6, Math.round(fps * (pingpong ? bounceSpeed : 1))),
        linger: unlocked ? linger : 0,
        motion: { ...motionNow(), smooth: smooth || (pingpong && bounceSmooth > 0.12) },
        timing: { slowMid, holdAt, holdMs },
        edge,
        forever: loopOn,
        open: unlocked,
        filename: media.name,
        signal: ctrl.signal,
        onProgress: (pct) => setJob({ label: "GIF", pct }),
      });
      const cap = gifBudget(unlocked).maxSpan;
      setNote(result === "clamped" ? `Kept the first ${cap}s.` : motionLine());
    } catch (err) {
      setNote(err instanceof DOMException && err.name === "AbortError" ? "Stopped." : "Couldn't build that GIF.");
    } finally {
      if (media.kind === "gif") gifClock.current = restore;
      else if (v) await seek(v, restore);
      if (resume) setPlaying(true);
      setJob(null);
      abortRef.current = null;
    }
  }

  async function saveClip() {
    const v = videoRef.current;
    if (!media || media.kind !== "video" || !v || job) return;
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setJob({ label: "Clip", pct: 0.2 });
    const restore = v.currentTime;
    try {
      await exportClip({
        video: v,
        natW: media.w,
        natH: media.h,
        look: lookNow(),
        inPoint,
        outPoint,
        filename: media.name,
        signal: ctrl.signal,
      });
      setNote("Clip saved. Picture, plus sound when the browser allows it.");
    } catch {
      setNote(ctrl.signal.aborted ? "Stopped." : "Couldn't record that clip. Try a GIF.");
    } finally {
      await seek(v, restore);
      setPlaying(false);
      setJob(null);
      abortRef.current = null;
    }
  }

  function holdStart() {
    window.clearTimeout(holdTimer.current);
    holdTimer.current = window.setTimeout(() => {
      if (unlocked) {
        setUnlocked(false);
        writeOpen(false);
        setAdj((a) => ({ ...a, glow: 0, clarity: 0 }));
        setLinger(0);
        setFps((n) => Math.min(n, 10));
        navigator.vibrate?.(12);
      } else {
        setDraft("");
        setSheet(true);
      }
    }, 700);
  }

  function holdEnd() {
    window.clearTimeout(holdTimer.current);
  }

  function submitMark(e: React.FormEvent) {
    e.preventDefault();
    if (accepts(draft)) {
      setUnlocked(true);
      writeOpen(true);
      setSheet(false);
      setDraft("");
      setNote("Unlocked. Assist is under LOOK.");
      navigator.vibrate?.(12);
    } else {
      setDraft("");
    }
  }

  function lockDown() {
    setUnlocked(false);
    writeOpen(false);
    setAdj((a) => ({ ...a, glow: 0, clarity: 0 }));
    setLinger(0);
    setFps((n) => Math.min(n, 10));
  }

  function onLockClick() {
    if (unlocked) {
      lockDown();
      return;
    }
    setDraft("");
    setSheet(true);
  }

  function toggleJob(key: "light" | "shade" | "blend" | "color") {
    if (!unlocked) {
      onLockClick();
      return;
    }
    setJobs((j) => ({ ...j, [key]: !j[key] }));
  }

  function runAssist() {
    if (!unlocked) {
      onLockClick();
      return;
    }
    const source = sourceNow();
    if (!media || !source || !frameReady() || job) {
      setNote("Need a frame on screen first.");
      return;
    }
    if (!jobs.light && !jobs.shade && !jobs.blend && !jobs.color) {
      setNote("Pick what it helps with.");
      return;
    }
    const t = involve / 10;
    const toward = (a: number, b: number) => a + (b - a) * t;
    if (jobs.light || jobs.color) {
      const next = suggestGrade(source, media.w, media.h, rot, flip, crop);
      if (next) {
        setAdj((a) => ({
          ...a,
          light: jobs.light ? toward(a.light, next.light) : a.light,
          contrast: jobs.light ? toward(a.contrast, next.contrast) : a.contrast,
          warmth: jobs.light ? toward(a.warmth, next.warmth) : a.warmth,
          color: jobs.color ? toward(a.color, next.color) : a.color,
        }));
      }
    }
    const tint = new Map<string, { tintColor: string; tint: number }>();
    if (jobs.blend && stickers.length > 0) {
      const canvas = document.createElement("canvas");
      const aspect = frameRatio(media.w, media.h, rot);
      canvas.width = 180;
      canvas.height = Math.max(8, Math.round(180 / Math.max(0.2, aspect)));
      renderCrop(canvas, source, media.w, media.h, rot, flip, FULL, adj, {
        straight,
        flip,
        shape: "none",
        stickers: [],
        captions: [],
        assets: assetsRef.current,
        blend: 0,
      });
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (ctx) {
        for (const s of stickers) {
          const at = toView(s.x, s.y, straight, flip);
          const x = Math.min(canvas.width - 1, Math.max(0, Math.floor(at.x * canvas.width)));
          const y = Math.min(canvas.height - 1, Math.max(0, Math.floor(at.y * canvas.height)));
          const px = ctx.getImageData(x, y, 1, 1).data;
          tint.set(s.id, {
            tintColor: `rgb(${px[0] ?? 0}, ${px[1] ?? 0}, ${px[2] ?? 0})`,
            tint: toward(s.tint, 0.2 + 0.65 * t),
          });
        }
      }
    }
    if (jobs.shade || tint.size > 0) {
      setStickers((list) =>
        list.map((s) => {
          const hit = tint.get(s.id);
          return {
            ...s,
            shadow: jobs.shade ? toward(s.shadow, 0.15 + 0.7 * t) : s.shadow,
            tint: hit ? hit.tint : s.tint,
            tintColor: hit ? hit.tintColor : s.tintColor,
          };
        }),
      );
    }
    if (jobs.shade) setAdj((a) => ({ ...a, falloff: toward(a.falloff, 0.12 + 0.5 * t) }));
    const names = [jobs.light && "lighting", jobs.shade && "shading", jobs.blend && "blend", jobs.color && "color"].filter(Boolean);
    setNote(names.length ? `Assist ${involve}: ${names.join(", ")}.` : "Pick what it helps with.");
  }

  function armScroll(e: React.PointerEvent) {
    const target = e.target as HTMLElement | null;
    if (target?.closest("input, textarea")) return;
    scrollGuard.current = { x: e.clientX, y: e.clientY, moved: false };
  }

  function moveScroll(e: React.PointerEvent) {
    const g = scrollGuard.current;
    if (Math.hypot(e.clientX - g.x, e.clientY - g.y) > 8) g.moved = true;
  }

  function eatScrollClick(e: React.MouseEvent) {
    if (!scrollGuard.current.moved) return;
    e.preventDefault();
    e.stopPropagation();
    scrollGuard.current.moved = false;
  }

  function showPanel(id: Tab) {
    setTab(id);
    setOpenPanel(true);
  }

  function togglePanel(id: Tab) {
    if (!media) {
      setNote("Open a clip first.");
      return;
    }
    if ((id === "trim" || id === "bounce" || id === "scenes") && media.kind === "image") {
      setNote(id === "scenes" ? "Join needs a video or a GIF." : "That tool is for a video or a GIF.");
      return;
    }
    if (openPanel && tab === id) setOpenPanel(false);
    else showPanel(id);
  }

  function writeSnaps(next: Snap[]) {
    setSnaps(next);
    try {
      localStorage.setItem("lt.snaps", JSON.stringify(next));
    } catch {
      /* private mode */
    }
  }

  function keepSnap(tool: string) {
    const payload =
      tool === "bounce"
        ? { bounceSmooth, bounceEase, bounceSpeed, bounceAt, pingpong, smooth, slower, reverse }
        : tool === "crop"
          ? { crop, ratio, rot, flip, straight, shape }
          : tool === "grade"
            ? { adj }
            : tool === "trim"
              ? { inPoint, outPoint, speed, loopOn, slowMid, holdAt, holdMs, smooth, slower, reverse, pingpong }
              : tool === "save"
                ? { loopOn, edge, fps, linger }
                : tool === "join"
                  ? { joinTrans, joinMs, scenes }
                  : { captions, stickers };
    const n = snaps.filter((s) => s.tool === tool).length + 1;
    const next = [{ id: crypto.randomUUID(), tool, name: String(n), data: JSON.stringify(payload) }, ...snaps].slice(0, 16);
    writeSnaps(next);
    setNote(`Kept ${tool} ${n}.`);
  }

  function applySnap(snap: Snap) {
    let data: Record<string, unknown>;
    try {
      data = JSON.parse(snap.data) as Record<string, unknown>;
    } catch {
      setNote("That keep won't open.");
      return;
    }
    const num = (key: string) => (typeof data[key] === "number" ? (data[key] as number) : null);
    const bool = (key: string) => (typeof data[key] === "boolean" ? (data[key] as boolean) : null);
    if (snap.tool === "bounce") {
      const smoothN = num("bounceSmooth");
      const easeN = num("bounceEase");
      const speedN = num("bounceSpeed");
      const atN = num("bounceAt");
      const ping = bool("pingpong");
      const soft = bool("smooth");
      const half = bool("slower");
      const back = bool("reverse");
      if (smoothN != null) setBounceSmooth(smoothN);
      if (easeN != null) setBounceEase(easeN);
      if (speedN != null) setBounceSpeed(speedN);
      if (atN != null) setBounceAt(atN);
      if (soft != null) setSmooth(soft);
      if (half != null) setSlower(half);
      if (back != null) setReverse(back);
      if (ping != null) {
        setPingpong(ping);
        if (ping) {
          setReverse(false);
          dirRef.current = 1;
          if (media && media.kind !== "image") setPlaying(true);
        }
      }
    } else if (snap.tool === "crop") {
      if (data.crop && typeof data.crop === "object") setCrop(data.crop as Crop);
      if ("ratio" in data) setRatio((data.ratio as number | null) ?? null);
      const rotN = num("rot");
      const strN = num("straight");
      const flipB = bool("flip");
      if (rotN != null) setRot(rotN);
      if (flipB != null) setFlip(flipB);
      if (strN != null) setStraight(strN);
      if (data.shape === "none" || data.shape === "circle" || data.shape === "soft" || data.shape === "frame") setShape(data.shape);
    } else if (snap.tool === "grade") {
      if (data.adj && typeof data.adj === "object") setAdj(data.adj as Adj);
    } else if (snap.tool === "trim") {
      const inn = num("inPoint");
      const out = num("outPoint");
      const rate = num("speed");
      const mid = num("slowMid");
      const hold = num("holdMs");
      const loop = bool("loopOn");
      if (inn != null) setInPoint(inn);
      if (out != null) setOutPoint(out);
      if (rate != null) setSpeed(rate);
      if (mid != null) setSlowMid(mid);
      if (hold != null) setHoldMs(hold);
      if (loop != null) setLoopOn(loop);
      if ("holdAt" in data) setHoldAt(typeof data.holdAt === "number" ? data.holdAt : null);
      const soft = bool("smooth");
      const half = bool("slower");
      const back = bool("reverse");
      const ping = bool("pingpong");
      if (soft != null) setSmooth(soft);
      if (half != null) setSlower(half);
      if (back != null) setReverse(back);
      if (ping != null) setPingpong(ping);
    } else if (snap.tool === "save") {
      const loop = bool("loopOn");
      const edgeN = num("edge");
      const fpsN = num("fps");
      const lingerN = num("linger");
      if (loop != null) setLoopOn(loop);
      if (edgeN != null) setEdge(edgeN);
      if (fpsN != null) setFps(fpsN);
      if (lingerN != null) setLinger(lingerN);
    } else if (snap.tool === "join") {
      if (data.joinTrans === "cut" || data.joinTrans === "fade" || data.joinTrans === "dip") setJoinTrans(data.joinTrans);
      const ms = num("joinMs");
      if (ms != null) setJoinMs(ms);
      if (Array.isArray(data.scenes)) setScenes(data.scenes as Scene[]);
    } else if (snap.tool === "lay") {
      if (Array.isArray(data.captions)) setCaptions(data.captions as Caption[]);
      if (Array.isArray(data.stickers)) {
        const saved = data.stickers as Sticker[];
        setStickers((list) => list.map((s) => saved.find((hit) => hit.id === s.id) ?? s));
      }
    }
    setNote(`Applied ${snap.tool} ${snap.name}.`);
  }

  function pushScene(sourceId: string | undefined, name: string, inn: number, out: number) {
    setScenes((list) => [
      ...list,
      {
        id: crypto.randomUUID(),
        name,
        inPoint: inn,
        outPoint: out,
        crop: sourceId ? FULL : crop,
        adj: sourceId ? DEFAULT_ADJ : adj,
        rot: sourceId ? 0 : rot,
        flip: sourceId ? false : flip,
        ratio: sourceId ? null : ratio,
        straight: sourceId ? 0 : straight,
        shape: sourceId ? "none" : shape,
        transition: list.length === 0 ? "cut" : joinTrans,
        transMs: joinMs,
        sourceId,
      },
    ]);
    showPanel("scenes");
  }

  async function addJoinFile(file: File) {
    if (!media) {
      setNote("Open a clip first.");
      return;
    }
    const kind = await classifyFile(file);
    if (!kind) {
      setNote("Use a video, a GIF, or a still.");
      return;
    }
    const id = crypto.randomUUID();
    if (kind === "gif") {
      const clip = await decodeGif(file);
      if (!clip) {
        setNote("Couldn't read that GIF.");
        return;
      }
      heldRef.current.set(id, { kind: "gif", w: clip.w, h: clip.h, duration: clip.duration, gif: clip });
      pushScene(id, file.name, 0, clip.duration);
      setNote("Clip added. Play the join to see the transition.");
      return;
    }
    const url = URL.createObjectURL(file);
    if (kind === "image") {
      const img = new Image();
      img.onload = () => {
        heldRef.current.set(id, { kind: "image", w: img.naturalWidth, h: img.naturalHeight, duration: 1.2, image: img, url });
        pushScene(id, file.name, 0, 1.2);
        setNote("Still added for 1.2s. Play the join to see it.");
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        setNote("That still won't open.");
      };
      img.src = url;
      return;
    }
    const v = document.createElement("video");
    v.muted = true;
    v.playsInline = true;
    v.preload = "auto";
    v.onloadedmetadata = () => {
      const duration = Number.isFinite(v.duration) ? v.duration : 0;
      if (!v.videoWidth || !(duration > 0)) {
        URL.revokeObjectURL(url);
        setNote("That clip won't play here.");
        return;
      }
      heldRef.current.set(id, { kind: "video", w: v.videoWidth, h: v.videoHeight, duration, video: v, url });
      pushScene(id, file.name, 0, duration);
      setNote("Clip added. Play the join, then save it.");
    };
    v.onerror = () => {
      URL.revokeObjectURL(url);
      setNote("That clip won't play here.");
    };
    v.src = url;
  }

  function playJoined() {
    if (scenes.length < 2) {
      setNote("Keep this scene, then add another clip.");
      return;
    }
    if (reelOn) {
      reelRef.current.on = false;
      setReelOn(false);
      setPlaying(false);
      videoRef.current?.pause();
      setNote("Join stopped.");
      return;
    }
    videoRef.current?.pause();
    reelRef.current = { on: true, index: 0, local: 0, fade: 0, fadeDur: 0.28, mode: scenes[1]?.transition ?? joinTrans };
    setReelOn(true);
    setPlaying(true);
    setPipOn(true);
    setNote("Playing the join. End result is the crop.");
  }

  async function frameForScene(sc: Scene, local: number) {
    const at = sc.inPoint + Math.max(0, local);
    if (sc.sourceId) {
      const held = heldRef.current.get(sc.sourceId);
      if (!held) return null;
      if (held.kind === "gif" && held.gif) {
        const source = frameAt(held.gif, at);
        return source ? { source, w: held.w, h: held.h } : null;
      }
      if (held.kind === "image" && held.image) return { source: held.image, w: held.w, h: held.h };
      if (held.kind === "video" && held.video) {
        await seek(held.video, Math.min(at, Math.max(0, held.duration - 0.02)));
        if (held.video.readyState < 2) return null;
        return { source: held.video, w: held.w, h: held.h };
      }
      return null;
    }
    if (!media) return null;
    if (media.kind === "gif" && gifRef.current) {
      const source = frameAt(gifRef.current, at);
      return source ? { source, w: media.w, h: media.h } : null;
    }
    if (media.kind === "image" && imageRef.current) return { source: imageRef.current, w: media.w, h: media.h };
    if (media.kind === "video" && videoRef.current) {
      await seek(videoRef.current, Math.min(at, Math.max(0, media.duration - 0.02)));
      if (videoRef.current.readyState < 2) return null;
      return { source: videoRef.current, w: media.w, h: media.h };
    }
    return null;
  }

  async function saveJoined() {
    if (!media || job) return;
    if (scenes.length < 2) {
      setNote("Keep two scenes, or add another clip.");
      return;
    }
    const budget = gifBudget(unlocked);
    const fpsN = Math.min(Math.max(6, fps), budget.maxFps);
    const capEdge = Math.min(edge, budget.maxEdge);
    const first = scenes[0]!;
    const lead = first.sourceId ? heldRef.current.get(first.sourceId) : null;
    const fw = lead?.w ?? media.w;
    const fh = lead?.h ?? media.h;
    const size = cropPixels(fw, fh, first.rot, first.crop, capEdge);
    const segs: { scene: Scene; start: number; dur: number }[] = [];
    let cursor = 0;
    for (const sc of scenes) {
      const dur = Math.max(0.12, sc.outPoint - sc.inPoint);
      segs.push({ scene: sc, start: cursor, dur });
      cursor += dur;
    }
    const total = Math.min(cursor, budget.maxSpan);
    const times: number[] = [];
    for (let t = 0; t < total - 0.01 && times.length < budget.maxFrames; t += 1 / fpsN) times.push(t);
    if (!times.length) times.push(0);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setJob({ label: "Join", pct: 0 });
    setPlaying(false);
    setReelOn(false);
    reelRef.current.on = false;
    videoRef.current?.pause();
    const restore = media.kind === "gif" ? gifClock.current : (videoRef.current?.currentTime ?? 0);
    const baked: HTMLCanvasElement[] = [];
    try {
      let prev: HTMLCanvasElement | null = null;
      for (let i = 0; i < times.length; i++) {
        if (ctrl.signal.aborted) throw new DOMException("aborted", "AbortError");
        const t = times[i]!;
        let seg = segs[0]!;
        for (const s of segs) if (t >= s.start) seg = s;
        const local = Math.min(t - seg.start, Math.max(0, seg.scene.outPoint - seg.scene.inPoint - 0.001));
        const hit = await frameForScene(seg.scene, local);
        if (!hit) throw new Error("frame");
        const frame = document.createElement("canvas");
        frame.width = size.w;
        frame.height = size.h;
        const dress: Dress = {
          straight: seg.scene.straight ?? 0,
          flip: seg.scene.flip,
          shape: seg.scene.shape ?? "none",
          stickers: seg.scene.sourceId ? [] : stickers,
          captions: seg.scene.sourceId ? [] : captions,
          assets: assetsRef.current,
          blend: 0,
        };
        renderCrop(frame, hit.source, hit.w, hit.h, seg.scene.rot, seg.scene.flip, seg.scene.crop, seg.scene.adj, dress);
        const mode = seg.scene.transition ?? "cut";
        const fadeDur = mode === "cut" ? 0 : Math.max(0.08, (seg.scene.transMs ?? joinMs) / 1000);
        if (prev && fadeDur > 0 && local < fadeDur) {
          const a = 1 - local / fadeDur;
          const ctx = frame.getContext("2d");
          if (ctx) {
            if (mode === "dip") {
              ctx.fillStyle = `rgba(16,21,28,${a})`;
              ctx.fillRect(0, 0, frame.width, frame.height);
            } else {
              ctx.save();
              ctx.globalAlpha = a;
              ctx.drawImage(prev, 0, 0);
              ctx.restore();
            }
          }
        }
        baked.push(frame);
        prev = frame;
        setJob({ label: "Join", pct: ((i + 1) / times.length) * 0.85 });
      }
      await exportGif({
        paintAt: (t) => {
          let idx = 0;
          let best = 1e9;
          for (let i = 0; i < times.length; i++) {
            const d = Math.abs((times[i] ?? 0) - t);
            if (d < best) {
              best = d;
              idx = i;
            }
          }
          return baked[idx] ?? null;
        },
        baked: true,
        natW: size.w,
        natH: size.h,
        look: { rot: 0, flip: false, crop: FULL, adj: DEFAULT_ADJ, dress: null },
        inPoint: 0,
        outPoint: Math.max(0.05, total),
        fps: fpsN,
        linger: 0,
        motion: { smooth: false, slower: false, reverse: false, pingpong: false },
        timing: { slowMid: 0, holdAt: null, holdMs: 0 },
        edge: Math.max(size.w, size.h),
        forever: loopOn,
        open: unlocked,
        filename: `${media.name.replace(/\.\w+$/, "")}-join`,
        signal: ctrl.signal,
        onProgress: (pct) => setJob({ label: "Join", pct: 0.85 + pct * 0.15 }),
      });
      setNote(loopOn ? "Joined GIF saved. It loops." : "Joined GIF saved. It plays once.");
    } catch (err) {
      setNote(err instanceof DOMException && err.name === "AbortError" ? "Stopped." : "Couldn't save that join.");
    } finally {
      if (media.kind === "gif") gifClock.current = restore;
      else if (videoRef.current) await seek(videoRef.current, restore);
      setJob(null);
      abortRef.current = null;
    }
  }

  useEffect(() => {
    if (!note) return;
    setToastOn(true);
    const t = window.setTimeout(() => setToastOn(false), 3500);
    return () => window.clearTimeout(t);
  }, [note]);

  useEffect(() => {
    if (!media) return;
    try {
      if (!localStorage.getItem("lt.holdtip")) setHint(true);
    } catch {
      setHint(true);
    }
  }, [media]);

  // Bounce/reverse frame cache: play a hidden copy of the clip forward once and keep small frames of the cut.
  useEffect(() => {
    pongCache.current = null;
    pongClock.current = -1;
    if (!media || media.kind !== "video" || !(pingpong || reverse) || !urlRef.current) return;
    const url = urlRef.current;
    const start = inPoint;
    const end = Math.max(start + 0.05, outPoint);
    const span = end - start;
    if (span > 30) return; // very long cuts keep the seek driver
    const n = Math.max(2, Math.min(120, Math.ceil(span * 24)));
    const step = span / (n - 1);
    const key = `${url}|${start.toFixed(3)}|${end.toFixed(3)}`;
    let dead = false;
    let raf = 0;
    const v = document.createElement("video");
    const stopV = () => {
      cancelAnimationFrame(raf);
      v.pause();
      v.removeAttribute("src");
      v.load();
    };
    const timer = window.setTimeout(async () => {
      v.muted = true;
      v.playsInline = true;
      v.preload = "auto";
      v.src = url;
      await new Promise<void>((resolve) => {
        v.onloadeddata = () => resolve();
        v.onerror = () => resolve();
      });
      if (dead || !v.videoWidth) return stopV();
      const k = Math.min(1, 320 / Math.max(v.videoWidth, v.videoHeight));
      const w = Math.max(2, Math.round(v.videoWidth * k));
      const h = Math.max(2, Math.round(v.videoHeight * k));
      const frames: (HTMLCanvasElement | null)[] = new Array(n).fill(null);
      const grab = (i: number) => {
        if (i < 0 || i >= n || frames[i]) return;
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        c.getContext("2d")?.drawImage(v, 0, 0, w, h);
        frames[i] = c;
      };
      await seek(v, start);
      if (dead) return stopV();
      grab(0);
      const finish = () => {
        // fill any gaps with the nearest grabbed frame
        let lastF: HTMLCanvasElement | null = null;
        for (let i = 0; i < n; i++) frames[i] ? (lastF = frames[i]) : (frames[i] = lastF);
        for (let i = n - 1; i >= 0; i--) if (frames[i]) lastF = frames[i]; else frames[i] = lastF;
        if (!dead && frames.every(Boolean)) pongCache.current = { key, start, end, step, frames, ready: true };
        stopV();
      };
      const t0 = performance.now();
      const tick = () => {
        if (dead) return stopV();
        const ct = v.currentTime;
        grab(Math.round((ct - start) / step));
        if (ct >= end - step * 0.5 || v.ended || performance.now() - t0 > span * 3000 + 8000) return finish();
        raf = requestAnimationFrame(tick);
      };
      v.playbackRate = span > 4 ? 2 : 1;
      try {
        await v.play();
        raf = requestAnimationFrame(tick);
      } catch {
        // no autoplay: fall back to stepping with seeks (slower, still off the main video)
        for (let i = 1; i < n && !dead; i++) {
          await seek(v, start + i * step);
          grab(i);
        }
        finish();
      }
    }, 350);
    return () => {
      dead = true;
      window.clearTimeout(timer);
      stopV();
    };
  }, [media, pingpong, reverse, inPoint, outPoint]);

  const cropKey = `${crop.x.toFixed(3)},${crop.y.toFixed(3)},${crop.w.toFixed(3)},${crop.h.toFixed(3)}`;
  useEffect(() => {
    if (!media || !openPanel || tab !== "grade") return;
    let tries = 0;
    let id = 0;
    const isVideo = media.kind === "video";
    if (isVideo) {
      thumbSrc.current = null;
      thumbWant.current = true;
    }
    const run = () => {
      const source = isVideo ? thumbSrc.current || lastFrame.current : sourceNow();
      if (!source || (!isVideo && !frameReady())) {
        if (++tries < 80) id = window.setTimeout(run, 150);
        return;
      }
      const next: Record<string, string> = {};
      const c = document.createElement("canvas");
      c.width = 58;
      c.height = 56;
      for (const p of PRESETS) {
        try {
          renderCrop(c, source, media.w, media.h, rot, flip, crop, p.adj, null);
          next[p.id] = c.toDataURL("image/jpeg", 0.7);
        } catch {
          /* tainted or not ready */
        }
      }
      if (Object.keys(next).length) setPreThumbs(next);
      else if (++tries < 80) id = window.setTimeout(run, 150);
    };
    id = window.setTimeout(run, 120);
    return () => {
      window.clearTimeout(id);
      thumbWant.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [media, openPanel, tab, rot, flip, cropKey]);

  const pixels = media ? cropPixels(media.w, media.h, rot, crop, 1600) : null;
  const motionMedia = media != null && media.kind !== "image";
  const panelTitle =
    tab === "trim" ? "Trim" : tab === "bounce" ? "Bounce" : tab === "crop" ? "Crop" : tab === "grade" ? "Grade" : tab === "lay" ? "Lay" : tab === "scenes" ? "Join" : "Save";

  const box =
    fit.dw > 2
      ? {
          left: fit.dx + crop.x * fit.dw,
          top: fit.dy + crop.y * fit.dh,
          width: Math.max(8, crop.w * fit.dw),
          height: Math.max(8, crop.h * fit.dh),
        }
      : null;

  function KeepRow(props: { tool: string }) {
    const mine = snaps.filter((s) => s.tool === props.tool).slice(0, 6);
    return (
      <HS label="Kept settings">
        <button
          type="button"
          className="chip sq"
          data-tip="Keep|Stores this tool's settings on this phone. Tap a number later to put them back."
          onClick={() => keepSnap(props.tool)}
        >
          <Bookmark className="ico sm" /> Keep
        </button>
        {mine.map((s) => (
          <button key={s.id} type="button" className="chip sq" data-tip={`Kept ${s.tool} ${s.name}|Puts those ${s.tool} settings back.`} onClick={() => applySnap(s)}>
            {s.name}
          </button>
        ))}
      </HS>
    );
  }

  const groupOf = (t: Tab): "cut" | "look" | "add" | "save" =>
    t === "trim" || t === "bounce" || t === "scenes" ? "cut" : t === "crop" || t === "grade" || t === "assist" ? "look" : t === "lay" ? "add" : "save";
  const activeKey = media && openPanel ? groupOf(tab) : group;
  const toolOpen = media && openPanel ? tab : null;
  const isStill = media?.kind === "image";
  const cropOn = crop.x > 0.0005 || crop.y > 0.0005 || crop.w < 0.9995 || crop.h < 0.9995;
  const lookOn = (Object.keys(DEFAULT_ADJ) as (keyof Adj)[]).some((k) => Math.abs(adj[k] - DEFAULT_ADJ[k]) > 0.001);
  const ratioLabel = ASPECTS.find((a) => a.ratio === ratio)?.label ?? "Free";
  const sizeLabel = edge === 240 ? "S" : edge === 480 ? "L" : "M";
  const flags = [pingpong && "BOUNCE", reverse && "REV", slower && "SLOW", smooth && "SMOOTH"].filter(Boolean).join(" ");

  function closeTool() {
    const g = groupOf(tab);
    if (g !== "save") setGroup(g);
    setOpenPanel(false);
  }

  function pressMode(g: "cut" | "look" | "add" | "save") {
    if (!media) {
      setNote("Insert a clip first.");
      return;
    }
    if (g === "save") {
      togglePanel("save");
      return;
    }
    setGroup(g);
    setOpenPanel(false);
  }

  function togglePip() {
    if (!media) {
      setNote("Open a clip first.");
      return;
    }
    setPipOn((on) => {
      setNote(on ? "End result hidden." : "End result is the crop you would save.");
      return !on;
    });
  }

  function pressPlay() {
    if (!motionMedia) {
      setNote("Open a video or a GIF to play.");
      return;
    }
    if (reelOn && playing) {
      reelRef.current.on = false;
      setReelOn(false);
    }
    togglePlay();
  }

  function trySample() {
    void loadFile(sampleFile());
  }

  function tlTime(clientX: number) {
    const el = tlRef.current;
    if (!el || !media || media.kind === "image") return 0;
    const r = el.getBoundingClientRect();
    return clamp((clientX - r.left) / Math.max(1, r.width), 0, 1) * media.duration;
  }

  function scrubDown(e: React.PointerEvent<HTMLDivElement>) {
    if (!motionMedia) return;
    jump(tlTime(e.clientX));
    const move = (ev: PointerEvent) => jump(tlTime(ev.clientX));
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  function handleDown(e: React.PointerEvent, which: "in" | "out") {
    if (!media || media.kind === "image") return;
    e.preventDefault();
    e.stopPropagation();
    setCutSel(which);
    let armed = false;
    const min = 1 / 30;
    const dur = media.duration;
    const move = (ev: PointerEvent) => {
      if (!armed) {
        armed = true;
        remember();
      }
      const t = tlTime(ev.clientX);
      if (which === "in") setInPoint(clamp(Math.min(t, outRef.current - min), 0, dur));
      else setOutPoint(clamp(Math.max(t, inRef.current + min), 0, dur));
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  const GRADE_KEYS: { key: keyof Adj; label: string; min: number; max: number; step: number; show: (n: number) => string; studio?: boolean }[] = [
    { key: "light", label: "Light", min: 0.4, max: 1.8, step: 0.01, show: (n) => n.toFixed(2) },
    { key: "contrast", label: "Contrast", min: 0.5, max: 1.8, step: 0.01, show: (n) => n.toFixed(2) },
    { key: "color", label: "Color", min: 0, max: 2, step: 0.01, show: (n) => n.toFixed(2) },
    { key: "tint", label: "Tint", min: -40, max: 40, step: 1, show: (n) => `${Math.round(n)}°` },
    { key: "warmth", label: "Warmth", min: 0, max: 1, step: 0.01, show: (n) => `${Math.round(n * 100)}` },
    { key: "soft", label: "Soft", min: 0, max: 2, step: 0.01, show: (n) => n.toFixed(2) },
    { key: "falloff", label: "Falloff", min: 0, max: 0.85, step: 0.01, show: (n) => `${Math.round(n * 100)}` },
    { key: "glow", label: "Glow", min: 0, max: 1, step: 0.01, show: (n) => `${Math.round(n * 100)}`, studio: true },
    { key: "clarity", label: "Clarity", min: 0, max: 1, step: 0.01, show: (n) => `${Math.round(n * 100)}`, studio: true },
  ];
  const gradeKeys = GRADE_KEYS.filter((g) => !g.studio || unlocked);
  const gk = gradeKeys.find((g) => g.key === gradeKey) ?? gradeKeys[0]!;

  type TileDef = { id: Tab | "end"; label: string; desc: string; icon: React.ReactNode; on: boolean; dim?: boolean };
  const TILES: Record<"cut" | "look" | "add", TileDef[]> = {
    cut: [
      { id: "trim", label: "Trim", desc: "Keep only the good part", icon: <Scissors className="ico" />, on: !!media && media.kind !== "image" && (inPoint > 0.001 || outPoint < media.duration - 0.001), dim: isStill },
      { id: "bounce", label: "Bounce", desc: "Plays forward, then back", icon: <ArrowLeftRight className="ico" />, on: pingpong, dim: isStill },
      { id: "scenes", label: "Join", desc: "Glue scenes and clips", icon: <GalleryHorizontal className="ico" />, on: scenes.length > 0, dim: isStill },
    ],
    look: [
      { id: "crop", label: "Crop", desc: "Frame it: 9:16, 1:1, turn", icon: <CropIcon className="ico" />, on: cropOn || rot !== 0 || flip || straight !== 0 || shape !== "none" },
      { id: "grade", label: "Grade", desc: "Light, color, mood", icon: <SunMedium className="ico" />, on: lookOn },
      ...(unlocked ? [{ id: "assist" as Tab, label: "Assist", desc: "Reads the frame, moves sliders", icon: <Wand2 className="ico" />, on: false }] : []),
    ],
    add: [
      { id: "lay", label: "Stickers", desc: "Stickers and text you place", icon: <StickerIcon className="ico" />, on: stickers.length + captions.length > 0 },
      { id: "end", label: "End result", desc: "See the crop you will save", icon: <PictureInPicture2 className="ico" />, on: pipOn },
    ],
  };
  const TIPS: Record<string, string> = {
    trim: "Trim|Mark where the cut starts and ends. Drag the yellow ends on the timeline, or nudge one frame at a time.",
    bounce: "Bounce|Plays forward, then back, on the picture and in the saved GIF.",
    scenes: "Join|Split at the playhead or keep this cut as a scene, add more clips, then fade, dip or cut between them.",
    crop: "Crop|Drag the frame; corners resize it. Pick 9:16, 1:1 and more, turn, mirror, straighten.",
    grade: "Grade|One-tap looks, then fine-tune light, contrast, color, tint, warmth.",
    assist: "Assist|Reads this frame and moves the sliders for you. It does not redraw the picture.",
    lay: "Stickers|Add a PNG sticker or a line of text. Drag it on the picture; erase bits that should hide behind hair.",
    end: "End result|A small picture of exactly what you would save. Tap again to hide it.",
  };
  const TITLES: Record<Tab, string> = { trim: "TRIM", bounce: "BOUNCE", scenes: "JOIN", crop: "CROP", grade: "GRADE", assist: "ASSIST", lay: "STICKERS", save: "SAVE" };
  const KEYTAG = { cut: "01 CUT", look: "02 LOOK", add: "03 ADD", save: "SAVE" } as const;

  return (
    <main
      className={`vtr${toolOpen === "grade" || toolOpen === "crop" || toolOpen === "lay" || toolOpen === "assist" ? " compact" : ""}`}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        const file = e.dataTransfer.files?.[0];
        if (file) void loadFile(file);
      }}
    >
      <input
        ref={fileRef}
        className="clip-input"
        type="file"
        accept="video/*,image/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void loadFile(file);
        }}
      />
      <input
        ref={stickerRef}
        className="clip-input"
        type="file"
        accept="image/png,image/webp,image/jpeg"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) addStickerFile(file);
        }}
      />
      <input
        ref={joinRef}
        className="clip-input"
        type="file"
        accept="video/*,image/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void addJoinFile(file);
        }}
      />

      <Bar page="clip" onClip={() => {}} onPage={() => onComic?.()} canUndo={canUndo} onUndo={undo} onMenu={() => setMenu(true)} lit={unlocked} />

      <div className="vfwrap">
        <div className="vf" data-guide="3" data-gl={media ? "What you will save" : "Preview screen"} data-gpos="br">
          <div ref={stageRef} className="stage" onPointerDown={onStageDown}>
            <video ref={videoRef} playsInline muted={muted} preload="auto" style={media?.kind === "video" ? undefined : { visibility: "hidden" }} />
            {media ? <canvas ref={canvasRef} className="pic" /> : null}
            {media && box && (toolOpen === "crop" || cropOn) ? (
              <div className={`cropbox${toolOpen === "crop" ? "" : " quiet"}`} style={{ left: box.left, top: box.top, width: box.width, height: box.height }}>
                {toolOpen === "crop"
                  ? (["nw", "ne", "sw", "se"] as const).map((h) => (
                      <button key={h} type="button" data-handle={h} aria-label={`Resize ${h}`} className={`hdl ${h}`} onPointerDown={(e) => beginDrag(e, h)}>
                        <i />
                      </button>
                    ))
                  : null}
              </div>
            ) : null}
            {pipOn && media ? (
              <div className="pip" onPointerDown={(e) => e.stopPropagation()}>
                <header>
                  <span>END RESULT</span>
                  <button type="button" onClick={() => setPipOn(false)} data-tip="Hide|Hides the end-result picture.">
                    HIDE
                  </button>
                </header>
                <canvas ref={pipRef} />
              </div>
            ) : null}
          </div>
          {!media ? (
            <>
              <ColorBars />
              <div className="notape">
                <b>NO CLIP</b>
                <span>INSERT BELOW ▼</span>
              </div>
            </>
          ) : null}
          <Brackets />
          {media ? (
            <>
              <div className="osd otl">
                <span className={`dot${playing ? "" : " red"}`} />
                {job ? `SAVING ${Math.round(job.pct * 100)}%` : toolOpen ? TITLES[toolOpen] : isStill ? "STILL" : playing ? "PLAY" : "STBY"}
              </div>
              <div className="osd otr">
                {ratioLabel.toUpperCase()}
                <small>
                  {media.kind.toUpperCase()} · {sizeLabel}
                  {unlocked ? " · ASSIST" : ""}
                </small>
              </div>
              <div className="osd obl">
                {isStill ? `${pixels?.w ?? media.w}×${pixels?.h ?? media.h}` : fmt(time)}
                <small>{media.name}</small>
              </div>
              <div className="osd obr">
                {isStill ? "PNG" : toolOpen === "trim" ? `IN ${fmt(inPoint)}` : fmt(Math.max(0, outPoint - inPoint))}
                <small>{toolOpen === "trim" ? `OUT ${fmt(outPoint)}` : flags || (isStill ? "STILL" : loopOn ? "LOOP" : "ONCE")}</small>
              </div>
            </>
          ) : (
            <>
              <div className="osd otl">
                <span className="dot red" />
                STBY
              </div>
              <div className="osd otr">-- : --</div>
              <div className="osd obl">0:00.00</div>
              <div className="osd obr">ON-PHONE</div>
            </>
          )}
          {toastOn && note && !job ? <div className="toast">{note}</div> : null}
          {job ? (
            <div className="job" role="status">
              <span>{job.label.toUpperCase()}</span>
              <span className="meter">
                <i style={{ width: `${Math.round(job.pct * 100)}%` }} />
              </span>
              <span>{Math.round(job.pct * 100)}%</span>
              <button type="button" data-tip="Stop|Stops writing the file." onClick={() => abortRef.current?.abort()}>
                STOP
              </button>
            </div>
          ) : null}
          {hint && media && !job ? (
            <div className="hint" role="note">
              <span>Hold any button for a tip.</span>
              <button
                type="button"
                data-tip-pass=""
                onClick={() => {
                  setHint(false);
                  try {
                    localStorage.setItem("lt.holdtip", "1");
                  } catch {
                    /* private mode */
                  }
                }}
              >
                GOT IT
              </button>
            </div>
          ) : null}
        </div>
      </div>

      {media && media.kind !== "image" ? (
        <div className="deck">
          <div className="trans">
            <button type="button" className="k" aria-label="Back one frame" data-tip="Frame back|One frame back. In Trim, −10 jumps further." onClick={() => stepFrame(-1)}>
              <SkipBack className="ico" />
            </button>
            <button
              type="button"
              className={`play${playing ? " on" : ""}`}
              aria-label={playing ? "Pause" : "Play"}
              data-tip="Play|Plays the cut with bounce, speed and grade, the way it will save."
              data-guide="4"
              data-gl="Play · frame step"
              onClick={pressPlay}
            >
              {playing ? <Pause className="ico" /> : <Play className="ico" />}
            </button>
            <button type="button" className="k" aria-label="Forward one frame" data-tip="Frame forward|One frame on." onClick={() => stepFrame(1)}>
              <SkipForward className="ico" />
            </button>
            <div className="lcd" aria-label="Time">
              <span>{fmt(time)}</span>
              <em aria-label="Length">{fmt(media.duration)}</em>
            </div>
            {media.kind === "video" ? (
              <button
                type="button"
                className="k"
                aria-label={muted ? "Sound on" : "Sound off"}
                data-tip="Sound|Mutes the preview. A saved clip keeps its sound when the phone allows it."
                onClick={() => {
                  const v = videoRef.current;
                  if (!v) return;
                  v.muted = !v.muted;
                  setMuted(v.muted);
                }}
              >
                {muted ? <VolumeX className="ico" /> : <Volume2 className="ico" />}
              </button>
            ) : (
              <button type="button" className={`k${loopOn ? " on" : ""}`} aria-label="Loop" aria-pressed={loopOn} data-tip="Loop|On: the GIF repeats forever. Off: it plays once." onClick={toggleLoop}>
                <Repeat className="ico" />
              </button>
            )}
          </div>
          <div className="tl" ref={tlRef} onPointerDown={scrubDown} data-guide="5" data-gl="Timeline: drag; yellow ends trim">
            <div className="ruler">
              <span>0s</span>
              <span>{(media.duration * 0.25).toFixed(1)}</span>
              <span>{(media.duration * 0.5).toFixed(1)}</span>
              <span>{(media.duration * 0.75).toFixed(1)}</span>
              <span>{media.duration.toFixed(1)}</span>
            </div>
            <div className="strip">
              {(thumbs.length ? thumbs : new Array<string>(8).fill("")).map((src, i) => (
                <i key={i} className={src ? "" : "blank"} style={src ? { backgroundImage: `url(${src})` } : undefined} />
              ))}
            </div>
            <div className="shade" style={{ left: 0, width: `${(inPoint / media.duration) * 100}%` }} />
            <div className="shade" style={{ right: 0, width: `${(1 - outPoint / media.duration) * 100}%` }} />
            <div className="inout" style={{ left: `${(inPoint / media.duration) * 100}%`, right: `${(1 - outPoint / media.duration) * 100}%` }} />
            <button
              type="button"
              className={`hand${toolOpen === "trim" && cutSel === "in" ? " sel" : ""}`}
              style={{ left: `${(inPoint / media.duration) * 100}%` }}
              aria-label="In point"
              data-tip="In point|Drag to where the saved part starts."
              onPointerDown={(e) => handleDown(e, "in")}
              onClick={() => setCutSel("in")}
            >
              <ChevronLeft className="ico sm" />
            </button>
            <button
              type="button"
              className={`hand${toolOpen === "trim" && cutSel === "out" ? " sel" : ""}`}
              style={{ left: `${(outPoint / media.duration) * 100}%` }}
              aria-label="Out point"
              data-tip="Out point|Drag to where the saved part ends."
              onPointerDown={(e) => handleDown(e, "out")}
              onClick={() => setCutSel("out")}
            >
              <ChevronRight className="ico sm" />
            </button>
            <div className="ph" style={{ left: `${(Math.min(time, media.duration) / media.duration) * 100}%` }} />
          </div>
        </div>
      ) : null}

      {media ? (
        <div className="drawer">
          {!toolOpen ? (
            <>
              <div className="dh">
                <span className="tag">
                  <b>{KEYTAG[group]}</b> · PICK A TOOL
                </span>
                {isStill && group === "cut" ? <span className="tag">STILLS: LOOK / ADD</span> : null}
              </div>
              <div className="tiles">
                {TILES[group].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className="tile"
                    style={t.dim ? { opacity: 0.45 } : undefined}
                    data-tool={t.id}
                    data-tip={TIPS[t.id]}
                    onClick={() => (t.id === "end" ? togglePip() : togglePanel(t.id as Tab))}
                  >
                    <span className={`led${t.on ? " on" : ""}`} />
                    {t.icon}
                    <b>{t.label}</b>
                    <span className="ds">{t.desc}</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="dh">
                <span className="tag">
                  {KEYTAG[groupOf(toolOpen)]} › <b>{TITLES[toolOpen]}</b>
                </span>
                <button type="button" className="done" data-done="" onClick={closeTool} data-tip="Done|Closes this tool. Your changes stay.">
                  <Check className="ico sm" /> DONE
                </button>
              </div>
              <Body>
                {toolOpen === "trim" && media.kind !== "image" ? (
                  <>
                    <div className="row">
                      <button type="button" className="nudge" aria-label="Nudge back one frame" data-tip="Nudge|Moves the outlined point one frame earlier." onClick={() => nudgeCut(cutSel, -1)}>
                        −1
                      </button>
                      <button type="button" className={`read${cutSel === "in" ? " sel" : ""}`} data-tip="In|Tap to pick the start; the nudges move it." onClick={() => setCutSel("in")}>
                        <small>IN</small>
                        {fmt(inPoint)}
                      </button>
                      <button type="button" className={`read${cutSel === "out" ? " sel" : ""}`} data-tip="Out|Tap to pick the end; the nudges move it." onClick={() => setCutSel("out")}>
                        <small>OUT</small>
                        {fmt(outPoint)}
                      </button>
                      <button type="button" className="nudge" aria-label="Nudge on one frame" data-tip="Nudge|Moves the outlined point one frame later." onClick={() => nudgeCut(cutSel, 1)}>
                        +1
                      </button>
                    </div>
                    <HS label="Trim actions">
                      <button type="button" className="chip sq" data-tip="In here|Puts the start at the playhead (key I)." onClick={stampIn}>
                        <ChevronLeft className="ico sm" /> In here
                      </button>
                      <button type="button" className="chip sq" data-tip="Out here|Puts the end at the playhead (key O)." onClick={stampOut}>
                        Out here <ChevronRight className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" data-tip="Split|Cuts the clip in two at the playhead, ready for Join." onClick={splitHere}>
                        <Scissors className="ico sm" /> Split
                      </button>
                      <button type="button" className="chip sq" data-tip="−10|Moves the outlined point ten frames earlier." onClick={() => nudgeCut(cutSel, -10)}>
                        −10
                      </button>
                      <button type="button" className="chip sq" data-tip="+10|Moves the outlined point ten frames later." onClick={() => nudgeCut(cutSel, 10)}>
                        +10
                      </button>
                      <button type="button" className={`chip sq${loopOn ? " on" : ""}`} aria-pressed={loopOn} data-tip="Loop|On: repeats. Off: plays once, in the preview and the GIF." onClick={toggleLoop}>
                        <Repeat className="ico sm" /> Loop
                      </button>
                    </HS>
                    <div className="p">Cut is {fmt(Math.max(0, outPoint - inPoint))} long.</div>
                    <div className="sep">SPEED</div>
                    <div className="grid4">
                      {[0.5, 1, 1.5, 2].map((rate) => (
                        <button
                          key={rate}
                          type="button"
                          className={`chip sq${speed === rate ? " on" : ""}`}
                          data-tip={`${rate}×|Playback speed, in the preview and the saved GIF.`}
                          onClick={() => {
                            setSpeed(rate);
                            if (videoRef.current) videoRef.current.playbackRate = rate;
                          }}
                        >
                          {rate}×
                        </button>
                      ))}
                    </div>
                    <div className="grid4">
                      {(
                        [
                          ["Smooth", smooth, () => setSoften(!smooth), "Smooth|Blends each frame with the one before it."],
                          ["Slower", slower, () => setHalf(!slower), "Slower|Half speed, on the picture and in the GIF."],
                          ["Reverse", reverse, () => setBackward(!reverse), "Reverse|Plays only backward."],
                          ["Bounce", pingpong, () => setBounce(!pingpong), "Bounce|Forward, then back."],
                        ] as const
                      ).map(([label, on, toggle, tip]) => (
                        <button key={label} type="button" aria-pressed={on} className={`chip sq${on ? " on" : ""}`} data-tip={tip} onClick={toggle}>
                          {label}
                        </button>
                      ))}
                    </div>
                    <button
                      type="button"
                      className={`chip sq wide${holdAt != null ? " on" : ""}`}
                      data-tip="Hold here|Pauses on this frame for a moment each loop."
                      onClick={() => setHoldAt((t) => (t == null ? time : null))}
                    >
                      {holdAt == null ? "Hold on this frame" : `Holding at ${fmt(holdAt)} (tap to drop)`}
                    </button>
                    {holdAt != null ? <Slider label="Hold" min={40} max={800} step={20} value={holdMs} display={`${holdMs} ms`} onChange={setHoldMs} /> : null}
                    <Slider label="Slow mid" min={0} max={1} step={0.01} value={slowMid} display={`${Math.round(slowMid * 100)}`} onChange={setSlowMid} />
                    <div className="sep">GIF SIZE</div>
                    <div className="grid3">
                      {(
                        [
                          [240, "S · 240"],
                          [360, "M · 360"],
                          [480, "L · 480"],
                        ] as const
                      ).map(([px, label]) => (
                        <button key={px} type="button" className={`chip sq${edge === px ? " on" : ""}`} data-tip={`${label}|Longest side of the saved GIF, in pixels.`} onClick={() => setEdge(px)}>
                          {label}
                        </button>
                      ))}
                    </div>
                    <Slider
                      label="Frames/s"
                      min={6}
                      max={unlocked ? 16 : 10}
                      step={1}
                      value={Math.min(fps, unlocked ? 16 : 10)}
                      display={`${Math.round(Math.min(fps, unlocked ? 16 : 10))}`}
                      onChange={setFps}
                    />
                    {unlocked ? <Slider label="Linger" min={0} max={500} step={10} value={linger} display={`${linger} ms`} onChange={setLinger} /> : null}
                    <KeepRow tool="trim" />
                  </>
                ) : null}

                {toolOpen === "bounce" && media.kind !== "image" ? (
                  <>
                    <button type="button" className={`chip sq wide${pingpong ? " on" : ""}`} aria-pressed={pingpong} data-tip="Bounce|Turns forward-then-back on or off." onClick={() => setBounce(!pingpong)}>
                      <ArrowLeftRight className="ico sm" /> {pingpong ? "Bounce on" : "Bounce off"}
                    </button>
                    <Slider label="Smooth" min={0} max={1} step={0.01} value={bounceSmooth} display={`${Math.round(bounceSmooth * 100)}`} onChange={setBounceSmooth} />
                    <Slider label="Transition" min={0} max={1} step={0.01} value={bounceEase} display={`${Math.round(bounceEase * 100)}`} onChange={setBounceEase} />
                    <Slider label="Speed" min={0.4} max={2} step={0.05} value={bounceSpeed} display={`${bounceSpeed.toFixed(2)}×`} onChange={setBounceSpeed} />
                    <Slider label="Turn at" min={0.2} max={1} step={0.01} value={bounceAt} display={bounceAt >= 0.99 ? "End" : `${Math.round(bounceAt * 100)}%`} onChange={setBounceAt} />
                    <p className="p">Transition 0 is the seamless turn. Turn at is where it heads back.</p>
                    <KeepRow tool="bounce" />
                  </>
                ) : null}

                {toolOpen === "crop" ? (
                  <>
                    <HS label="Aspect">
                      {ASPECTS.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          className={`chip sq${ratio === item.ratio ? " on" : ""}`}
                          data-ratio={item.id}
                          data-tip={`${item.label}|${item.ratio == null ? "Any shape; drag the corners." : "Locks the frame to " + item.label + "."}`}
                          onClick={() => {
                            remember();
                            setRatio(item.ratio);
                            if (item.ratio != null) setCrop(fitAspect(item.ratio, frameRatio(media.w, media.h, rot)));
                            else setCrop(FULL);
                          }}
                        >
                          {item.label}
                        </button>
                      ))}
                    </HS>
                    <HS label="Turn and shape">
                      <button
                        type="button"
                        className="chip sq"
                        data-tip="Turn|Rotates a quarter turn."
                        onClick={() => {
                          remember();
                          const next = (rot + 1) % 4;
                          setRot(next);
                          if (ratio != null) setCrop(fitAspect(ratio, frameRatio(media.w, media.h, next)));
                        }}
                      >
                        <RotateCw className="ico sm" /> Turn
                      </button>
                      <button
                        type="button"
                        className={`chip sq${flip ? " on" : ""}`}
                        data-tip="Mirror|Flips left and right."
                        onClick={() => {
                          remember();
                          setFlip((v) => !v);
                        }}
                      >
                        <FlipHorizontal className="ico sm" /> Mirror
                      </button>
                      {(
                        [
                          ["none", "Full"],
                          ["circle", "Circle"],
                          ["soft", "Soft"],
                          ["frame", "Frame"],
                        ] as const
                      ).map(([id, label]) => (
                        <button key={id} type="button" className={`chip sq${shape === id ? " on" : ""}`} data-tip={`${label}|Shape of the saved picture.`} onClick={() => setShape(id)}>
                          {label}
                        </button>
                      ))}
                      <button
                        type="button"
                        className="chip sq"
                        data-tip="Reset|Back to the full, unturned frame."
                        onClick={() => {
                          remember();
                          setCrop(FULL);
                          setRatio(null);
                          setRot(0);
                          setFlip(false);
                          setStraight(0);
                          setShape("none");
                        }}
                      >
                        Reset
                      </button>
                    </HS>
                    <Slider label="Straight" min={-15} max={15} step={0.1} value={straight} display={`${straight.toFixed(1)}°`} onChange={setStraight} arm={remember} />
                    <div className="grid4">
                      <button type="button" className="chip sq" aria-label="Move left" data-tip="Left|Moves the frame 0.3% left." onClick={() => setCrop((c) => moveCrop(c, -0.003, 0))}>
                        <ArrowLeft className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Move right" data-tip="Right|Moves the frame 0.3% right." onClick={() => setCrop((c) => moveCrop(c, 0.003, 0))}>
                        <ArrowRight className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Move up" data-tip="Up|Moves the frame 0.3% up." onClick={() => setCrop((c) => moveCrop(c, 0, -0.003))}>
                        <ArrowUp className="ico sm" />
                      </button>
                      <button type="button" className="chip sq" aria-label="Move down" data-tip="Down|Moves the frame 0.3% down." onClick={() => setCrop((c) => moveCrop(c, 0, 0.003))}>
                        <ArrowDown className="ico sm" />
                      </button>
                    </div>
                    <Slider label="Left" min={0} max={Math.max(0.001, 1 - crop.w)} step={0.001} value={crop.x} display={`${(crop.x * 100).toFixed(1)}%`} arm={remember} onChange={(n) => setCrop((c) => ({ ...c, x: clamp(n, 0, 1 - c.w) }))} />
                    <Slider label="Top" min={0} max={Math.max(0.001, 1 - crop.h)} step={0.001} value={crop.y} display={`${(crop.y * 100).toFixed(1)}%`} arm={remember} onChange={(n) => setCrop((c) => ({ ...c, y: clamp(n, 0, 1 - c.h) }))} />
                    <Slider label="Width" min={0.08} max={Math.max(0.08, 1 - crop.x)} step={0.001} value={crop.w} display={`${(crop.w * 100).toFixed(1)}%`} arm={remember} onChange={(n) => setCrop((c) => ({ ...c, w: clamp(n, 0.08, 1 - c.x) }))} />
                    <Slider label="Height" min={0.08} max={Math.max(0.08, 1 - crop.y)} step={0.001} value={crop.h} display={`${(crop.h * 100).toFixed(1)}%`} arm={remember} onChange={(n) => setCrop((c) => ({ ...c, h: clamp(n, 0.08, 1 - c.y) }))} />
                    {unlocked ? (
                      <button type="button" className="chip sq wide" data-tip="Find subject|Moves the crop onto the subject." onClick={findSubject}>
                        Find subject
                      </button>
                    ) : null}
                    <KeepRow tool="crop" />
                  </>
                ) : null}

                {toolOpen === "grade" ? (
                  <>
                    <HS label="Looks">
                      {PRESETS.filter((p) => !p.studio || unlocked).map((p) => {
                        const on = (Object.keys(p.adj) as (keyof Adj)[]).every((k) => Math.abs(p.adj[k] - adj[k]) < 0.001);
                        return (
                          <button
                            key={p.id}
                            type="button"
                            className={`pre${on ? " on" : ""}`}
                            data-pre={p.id}
                            data-tip={`${p.label}|One-tap look. The slider below fine-tunes it.`}
                            onClick={() => {
                              remember();
                              setAdj(p.adj);
                            }}
                          >
                            {preThumbs[p.id] ? <img src={preThumbs[p.id]} alt="" /> : null}
                            <span>{p.label.toUpperCase()}</span>
                          </button>
                        );
                      })}
                    </HS>
                    <HS label="Adjust">
                      {gradeKeys.map((g) => (
                        <button key={g.key} type="button" className={`chip${gk.key === g.key ? " on" : ""}`} data-adj={g.key} data-tip={`${g.label}|Picks which setting the slider below moves.`} onClick={() => setGradeKey(g.key)}>
                          {g.label}
                        </button>
                      ))}
                    </HS>
                    <Slider label={gk.label} min={gk.min} max={gk.max} step={gk.step} value={adj[gk.key]} display={gk.show(adj[gk.key])} arm={remember} onChange={(n) => setAdj((a) => ({ ...a, [gk.key]: n }))} />
                    <div className="row">
                      <button
                        type="button"
                        className="chip sq"
                        data-tip="Reset look|Back to the untouched picture."
                        onClick={() => {
                          remember();
                          setAdj(DEFAULT_ADJ);
                        }}
                      >
                        Reset
                      </button>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <KeepRow tool="grade" />
                      </div>
                    </div>
                  </>
                ) : null}

                {toolOpen === "assist" ? (
                  <>
                    <Slider label="Involve" min={1} max={10} step={1} value={involve} display={`${involve}`} onChange={setInvolve} />
                    <div className="grid4">
                      {(
                        [
                          ["light", "Light"],
                          ["shade", "Shade"],
                          ["blend", "Blend"],
                          ["color", "Color"],
                        ] as const
                      ).map(([key, label]) => (
                        <button key={key} type="button" aria-pressed={jobs[key]} className={`chip sq${jobs[key] ? " on" : ""}`} data-tip={`${label}|What Assist is allowed to help with.`} onClick={() => toggleJob(key)}>
                          {label}
                        </button>
                      ))}
                    </div>
                    <div className="grid3">
                      <button type="button" className="chip sq hot" data-tip="Apply|Reads this frame and moves the sliders." onClick={runAssist}>
                        Apply
                      </button>
                      <button type="button" className="chip sq" data-tip="Read light|Reports how bright this frame is." onClick={readLight}>
                        Read light
                      </button>
                      <button type="button" className="chip sq" data-tip="Find subject|Moves the crop onto the subject." onClick={findSubject}>
                        Subject
                      </button>
                    </div>
                    <button type="button" className="chip sq wide" data-tip="Lock|Hides Assist and the studio extras again." onClick={lockDown}>
                      <Lock className="ico sm" /> Lock assist
                    </button>
                  </>
                ) : null}

                {toolOpen === "lay" ? (
                  <>
                    <HS label="Add">
                      <button type="button" className="chip sq" data-tip="Sticker|Pick a PNG from this phone and place it." onClick={() => stickerRef.current?.click()}>
                        <ImagePlus className="ico sm" /> Sticker
                      </button>
                      <button type="button" className="chip sq" data-tip="Text|Adds a line of text you can drag." onClick={addCaption}>
                        <Type className="ico sm" /> Text
                      </button>
                      {media.kind === "video" ? (
                        <button type="button" className={`chip sq${onion ? " on" : ""}`} data-tip="Onion|Shows the frame before, faintly, to line things up." onClick={() => setOnion((v) => !v)}>
                          Onion
                        </button>
                      ) : null}
                    </HS>
                    {stickers.length + captions.length > 0 ? (
                      <HS label="Placed">
                        {stickers.map((st) => (
                          <button
                            key={st.id}
                            type="button"
                            className={`chip sq${sel?.id === st.id ? " on" : ""}`}
                            data-tip="Sticker|Selects it. Drag it on the picture."
                            onClick={() => {
                              setSel({ kind: "sticker", id: st.id });
                              setTool("place");
                            }}
                          >
                            {st.name.slice(0, 14)}
                          </button>
                        ))}
                        {captions.map((cap) => (
                          <button key={cap.id} type="button" className={`chip sq${sel?.id === cap.id ? " on" : ""}`} data-tip="Text|Selects it. Drag it on the picture." onClick={() => setSel({ kind: "text", id: cap.id })}>
                            “{(cap.text || "Text").slice(0, 12)}”
                          </button>
                        ))}
                      </HS>
                    ) : (
                      <p className="p">You place it. Drag to move. Erase what should hide under hair or a collar.</p>
                    )}
                    {sel?.kind === "sticker"
                      ? stickers
                          .filter((st) => st.id === sel.id)
                          .map((st) => (
                            <div key={st.id} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                              <div className="grid3">
                                <button type="button" className={`chip sq${tool === "pick" ? " on" : ""}`} data-tip="Pick|Tap the picture to take a tint color from it." onClick={() => setTool("pick")}>
                                  Pick
                                </button>
                                <button type="button" className={`chip sq${tool === "erase" ? " on" : ""}`} data-tip="Erase|Rub out parts of the sticker on the picture." onClick={() => setTool((t) => (t === "erase" ? "place" : "erase"))}>
                                  <Eraser className="ico sm" /> Erase
                                </button>
                                <button type="button" className="chip sq" aria-label="Remove sticker" data-tip="Remove|Deletes this sticker." onClick={removeSel}>
                                  <Trash2 className="ico sm" />
                                </button>
                              </div>
                              <Slider label="Size" min={0.08} max={0.9} step={0.01} value={st.scale} display={st.scale.toFixed(2)} onChange={(n) => setStickers((list) => list.map((s) => (s.id === st.id ? { ...s, scale: n } : s)))} />
                              <Slider label="Turn" min={-180} max={180} step={1} value={st.rot} display={`${Math.round(st.rot)}°`} onChange={(n) => setStickers((list) => list.map((s) => (s.id === st.id ? { ...s, rot: n } : s)))} />
                              <Slider label="Bend" min={-1} max={1} step={0.01} value={st.bend} display={st.bend.toFixed(2)} onChange={(n) => setStickers((list) => list.map((s) => (s.id === st.id ? { ...s, bend: n } : s)))} />
                              <Slider label="Tint" min={0} max={1} step={0.01} value={st.tint} display={`${Math.round(st.tint * 100)}`} onChange={(n) => setStickers((list) => list.map((s) => (s.id === st.id ? { ...s, tint: n } : s)))} />
                              <Slider label="Shadow" min={0} max={1} step={0.01} value={st.shadow} display={`${Math.round(st.shadow * 100)}`} onChange={(n) => setStickers((list) => list.map((s) => (s.id === st.id ? { ...s, shadow: n } : s)))} />
                            </div>
                          ))
                      : null}
                    {sel?.kind === "text"
                      ? captions
                          .filter((cap) => cap.id === sel.id)
                          .map((cap) => (
                            <div key={cap.id} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                              <input
                                className="txt"
                                value={cap.text}
                                maxLength={48}
                                aria-label="Line"
                                onChange={(e) => setCaptions((list) => list.map((c) => (c.id === cap.id ? { ...c, text: e.target.value } : c)))}
                              />
                              <Slider label="Size" min={0.03} max={0.16} step={0.005} value={cap.size} display={cap.size.toFixed(2)} onChange={(n) => setCaptions((list) => list.map((c) => (c.id === cap.id ? { ...c, size: n } : c)))} />
                              <HS label="Text color">
                                {(
                                  [
                                    ["#e7eef6", "Light"],
                                    ["#10151c", "Ink"],
                                    ["#c5d4e4", "Accent"],
                                    ["#ffffff", "White"],
                                  ] as const
                                ).map(([color, label]) => (
                                  <button
                                    key={color}
                                    type="button"
                                    aria-label={label}
                                    data-tip={`${label}|Text color.`}
                                    className={`swatch${cap.color === color ? " on" : ""}`}
                                    style={{ background: color }}
                                    onClick={() => setCaptions((list) => list.map((c) => (c.id === cap.id ? { ...c, color } : c)))}
                                  />
                                ))}
                                <button type="button" className={`chip sq${tool === "pick" ? " on" : ""}`} data-tip="Pick|Tap the picture to take the text color from it." onClick={() => setTool("pick")}>
                                  Pick
                                </button>
                                <button type="button" className="chip sq" aria-label="Remove text" data-tip="Remove|Deletes this line." onClick={removeSel}>
                                  <Trash2 className="ico sm" />
                                </button>
                              </HS>
                            </div>
                          ))
                      : null}
                    <KeepRow tool="lay" />
                  </>
                ) : null}

                {toolOpen === "scenes" && media.kind !== "image" ? (
                  <>
                    <div className="grid2">
                      <button
                        type="button"
                        className="chip sq hot"
                        data-tip="Keep scene|Stores the current in/out, crop and grade as the next scene."
                        onClick={() => {
                          remember();
                          const n = scenes.length + 1;
                          setScenes((list) => [
                            ...list,
                            {
                              id: crypto.randomUUID(),
                              name: `Scene ${n}`,
                              inPoint,
                              outPoint,
                              crop,
                              adj,
                              rot,
                              flip,
                              ratio,
                              straight,
                              shape,
                              transition: list.length === 0 ? "cut" : joinTrans,
                              transMs: joinMs,
                            },
                          ]);
                        }}
                      >
                        <Plus className="ico sm" /> Keep scene
                      </button>
                      <button type="button" className="chip sq" data-tip="Split here|Cuts at the playhead into two scenes." onClick={splitHere}>
                        <Scissors className="ico sm" /> Split here
                      </button>
                      <button type="button" className="chip sq" data-tip="Add clip|Adds another video or GIF from this phone as a scene." onClick={() => joinRef.current?.click()}>
                        <FilePlus2 className="ico sm" /> Add clip
                      </button>
                      <button type="button" className={`chip sq${reelOn ? " on" : ""}`} data-tip="Play join|Plays every scene in a row with the transitions." onClick={playJoined}>
                        {reelOn ? <Pause className="ico sm" /> : <Play className="ico sm" />} {reelOn ? "Stop join" : "Play join"}
                      </button>
                    </div>
                    <HS label="Transition">
                      {(
                        [
                          ["cut", "Cut", "Cut|Instant change between scenes."],
                          ["fade", "Fade", "Fade|Blends one scene into the next."],
                          ["dip", "Dip", "Dip|Goes dark between scenes."],
                        ] as const
                      ).map(([id, label, tip]) => (
                        <button key={id} type="button" className={`chip sq${joinTrans === id ? " on" : ""}`} data-tip={tip} onClick={() => setJoinTrans(id)}>
                          {label}
                        </button>
                      ))}
                    </HS>
                    {joinTrans !== "cut" ? <Slider label="Blend" min={80} max={800} step={20} value={joinMs} display={`${joinMs} ms`} onChange={setJoinMs} /> : null}
                    {scenes.length === 0 ? <p className="p">Split at the playhead, or keep this cut, then add another clip.</p> : null}
                    {scenes.map((scene) => (
                      <div key={scene.id} className="scene">
                        <button
                          type="button"
                          className="nm"
                          data-tip="Scene|Loads this scene's in/out, crop and grade."
                          onClick={() => {
                            if (scene.sourceId) {
                              setNote("That clip plays inside the join.");
                              return;
                            }
                            setInPoint(scene.inPoint);
                            setOutPoint(scene.outPoint);
                            setCrop(scene.crop);
                            setAdj(scene.adj);
                            setRot(scene.rot);
                            setFlip(scene.flip);
                            setRatio(scene.ratio);
                            setStraight(scene.straight ?? 0);
                            setShape(scene.shape ?? "none");
                            if (scene.transition) setJoinTrans(scene.transition);
                            if (scene.transMs) setJoinMs(scene.transMs);
                            jump(scene.inPoint);
                          }}
                        >
                          <b>{scene.name}</b>
                          <span>
                            {fmt(scene.inPoint)} – {fmt(scene.outPoint)}
                            {scene.transition && scene.transition !== "cut" ? ` · ${scene.transition}` : ""}
                          </span>
                        </button>
                        {scene.sourceId ? null : (
                          <button type="button" className="chip" data-tip="GIF|Saves just this scene as a GIF." onClick={() => void saveGif(scene)}>
                            GIF
                          </button>
                        )}
                        <button
                          type="button"
                          className="chip"
                          data-tip="Look|Copies this scene's grade onto the clip."
                          onClick={() => {
                            setAdj(scene.adj);
                            setNote("Grade copied.");
                          }}
                        >
                          Look
                        </button>
                        <button
                          type="button"
                          className="chip"
                          aria-label="Drop scene"
                          data-tip="Drop|Removes this scene."
                          onClick={() => {
                            remember();
                            setScenes((list) => list.filter((s) => s.id !== scene.id));
                          }}
                        >
                          <Trash2 className="ico sm" />
                        </button>
                      </div>
                    ))}
                    {scenes.length > 1 ? (
                      <button type="button" className="chip sq hot wide" data-save-join="" data-tip="Save joined GIF|Writes every scene, with transitions, into one GIF." onClick={() => void saveJoined()}>
                        <Download className="ico sm" /> Save joined GIF
                      </button>
                    ) : null}
                    <KeepRow tool="join" />
                  </>
                ) : null}

                {toolOpen === "save" ? (
                  <>
                    <div className={media.kind === "video" ? "grid3" : "grid2"}>
                      {media.kind !== "image" ? (
                        <button type="button" className="chip sq hot" data-save-gif="" data-tip="Save GIF|The cut, crop, grade, loop and bounce, in one GIF." onClick={() => void saveGif()}>
                          <Download className="ico sm" /> GIF
                        </button>
                      ) : null}
                      <button type="button" className={`chip sq${media.kind === "image" ? " hot" : ""}`} data-save-still="" data-tip="Save still|This one frame as a PNG picture." onClick={() => void saveStill()}>
                        <ImageIcon className="ico sm" /> Still
                      </button>
                      {media.kind === "video" ? (
                        <button type="button" className="chip sq" data-tip="Save clip|A short video, with sound when the phone allows it." onClick={() => void saveClip()}>
                          <Film className="ico sm" /> Clip
                        </button>
                      ) : null}
                      {media.kind === "image" ? (
                        <button type="button" className={`chip sq${pipOn ? " on" : ""}`} data-tip="End result|Shows exactly what will be written." onClick={togglePip}>
                          <PictureInPicture2 className="ico sm" /> Preview
                        </button>
                      ) : null}
                    </div>
                    {media.kind !== "image" ? (
                      <button type="button" className={`chip sq wide${loopOn ? " on" : ""}`} aria-pressed={loopOn} data-tip="Loop|Loop forever, or play once." onClick={toggleLoop}>
                        <Repeat className="ico sm" /> {loopOn ? "Loop forever" : "Play once"}
                      </button>
                    ) : null}
                    <div className="grid3">
                      {(
                        [
                          [240, "S · 240"],
                          [360, "M · 360"],
                          [480, "L · 480"],
                        ] as const
                      ).map(([px, label]) => (
                        <button key={px} type="button" className={`chip sq${edge === px ? " on" : ""}`} data-tip={`${label}|Longest side of the saved file, in pixels.`} onClick={() => setEdge(px)}>
                          {label}
                        </button>
                      ))}
                    </div>
                    <p className="p">Saves to this phone only. Turn on End result (ADD) to see the crop before it writes.</p>
                    <KeepRow tool="save" />
                  </>
                ) : null}
              </Body>
            </>
          )}
        </div>
      ) : null}

      {media ? (
        <div className="modes" data-guide="6" data-gl="Tool groups + SAVE">
          <ModeKey n="01" label="CUT" icon={<Scissors className="ico" />} on={activeKey === "cut"} tip="Cut|Trim, Bounce and Join." onClick={() => pressMode("cut")} />
          <ModeKey n="02" label="LOOK" icon={<SunMedium className="ico" />} on={activeKey === "look"} tip="Look|Crop and Grade." onClick={() => pressMode("look")} />
          <ModeKey n="03" label="ADD" icon={<StickerIcon className="ico" />} on={activeKey === "add"} tip="Add|Stickers, text and the End result preview." onClick={() => pressMode("add")} />
          <ModeKey n="REC" label="SAVE" hot on={activeKey === "save"} icon={<Download className="ico" />} tip="Save|GIF, still or clip. Saves to this phone only." onClick={() => pressMode("save")} />
        </div>
      ) : (
        <div className="slot">
          <button type="button" className="insert" data-tip="Insert a clip|Pick a video, GIF or photo from this phone." data-guide="4" data-gl="Start here: pick a clip" data-gpos="tc" onClick={pick}>
            <span className="ib">
              <Upload className="ico" />
            </span>
            <span>
              <b>Insert a clip</b>
              <span>Video, GIF or still from your phone</span>
            </span>
          </button>
          <div className="alts" data-guide="5" data-gl="Or a comic page / a sample">
            <button type="button" className="alt" data-tip="Comic page|Lay stills into a comic, manga or webtoon page." onClick={() => onComic?.()}>
              <LayoutGrid className="ico sm" /> Comic page
            </button>
            <button type="button" className="alt" data-sample="" data-tip="Try sample|Opens a tiny built-in GIF so you can try every tool." onClick={trySample}>
              <Play className="ico sm" /> Try sample
            </button>
          </div>
          <div className="steps">
            <span>
              <i>1</i> INSERT
            </span>
            <span>→</span>
            <span>
              <i>2</i> CUT · LOOK · ADD
            </span>
            <span>→</span>
            <span>
              <i>3</i> SAVE
            </span>
          </div>
          <div className="privacy">Nothing leaves this phone.</div>
        </div>
      )}

      <p className="clip-input" aria-live="polite" data-note="">
        {note}
      </p>

      {menu ? (
        <Sheet title="MENU" onClose={() => setMenu(false)}>
          <div className="tiles">
            <button
              type="button"
              className="tile"
              data-tip="Open clip|Swap in another video, GIF or still."
              onClick={() => {
                setMenu(false);
                pick();
              }}
            >
              <Upload className="ico" />
              <b>Open clip</b>
              <span className="ds">Swap the tape</span>
            </button>
            <button
              type="button"
              className="tile"
              data-lock=""
              data-tip={unlocked ? "Lock|Hides Assist and the studio extras." : "Unlock|Type the code to show Assist and the studio extras."}
              onClick={() => {
                setMenu(false);
                onLockClick();
              }}
            >
              {unlocked ? <LockOpen className="ico" /> : <Lock className="ico" />}
              <b>{unlocked ? "Lock" : "Unlock"}</b>
              <span className="ds">{unlocked ? "Assist is on" : "Assist code"}</span>
            </button>
            <button
              type="button"
              className="tile"
              data-tip="Manual|The VTR-1 owner’s manual: every key, how to cut, look, add and save."
              data-manual-open=""
              onClick={() => {
                setMenu(false);
                openManual();
              }}
            >
              <BookOpen className="ico" />
              <b>Manual</b>
              <span className="ds">Owner’s manual</span>
            </button>
          </div>
          <p className="p" style={{ marginTop: 8 }}>
            Latch {LATCH_VERSION} · VTR-1. Nothing leaves this phone.
          </p>
        </Sheet>
      ) : null}

      {help ? <Manual onClose={closeManual} /> : null}

      {sheet ? (
        <>
          <div className="scrim" onClick={() => setSheet(false)} />
          <form className="lockform" onSubmit={submitMark}>
            <input
              autoFocus
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Escape") setSheet(false);
              }}
              autoCapitalize="characters"
              autoCorrect="off"
              autoComplete="off"
              spellCheck={false}
              enterKeyHint="done"
              aria-label="Mark"
            />
            <button type="submit" className="k" aria-label="Done">
              <Check className="ico" />
            </button>
          </form>
        </>
      ) : null}
    </main>
  );
}

const Slider = Fader;
