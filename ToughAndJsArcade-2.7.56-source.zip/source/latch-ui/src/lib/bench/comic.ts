import { saveFile } from "@/lib/bench/save-file";
export type ComicFormat = "webtoon" | "manga" | "comic";
export type BubbleKind = "speech" | "thought" | "caption" | "shout";
export type FitMode = "whole" | "fill";

export type ComicBubble = {
  id: string;
  kind: BubbleKind;
  text: string;
  x: number;
  y: number;
};

export type DrawPanel = {
  id: string;
  img: HTMLImageElement;
  w: number;
  h: number;
  bubbles: ComicBubble[];
};

export type PageCell = { id: string; x: number; y: number; w: number; h: number };
export type PageBubble = { panelId: string; id: string; x: number; y: number; w: number; h: number };
export type PageLayout = { pageW: number; pageH: number; cells: PageCell[]; bubbles: PageBubble[] };

const PAGE_W = 900;
const INK = "#111111";
const PAPER = "#f3efe4";

export function readingOrder<T extends { id: string; order: number; added: number }>(items: T[], queue: string[]): T[] {
  if (queue.length === 0) return [...items].sort((a, b) => a.order - b.order || a.added - b.added);
  const rank = new Map(queue.map((id, i) => [id, i]));
  return [...items].sort((a, b) => {
    const ra = rank.has(a.id) ? (rank.get(a.id) as number) : 1000 + a.order;
    const rb = rank.has(b.id) ? (rank.get(b.id) as number) : 1000 + b.order;
    return ra - rb || a.added - b.added;
  });
}

function clamp(n: number, a: number, b: number) {
  return Math.min(b, Math.max(a, n));
}

export function placePanels(items: { id: string; w: number; h: number }[], format: ComicFormat, colsWanted: number): {
  pageW: number;
  pageH: number;
  cells: PageCell[];
} {
  const pageW = PAGE_W;
  const frame = 18;
  const margin = 26;
  const gutter = 14;
  const cols = format === "webtoon" ? 1 : clamp(colsWanted, 2, 3);
  const inner = pageW - frame * 2 - margin * 2;
  const cellW = (inner - gutter * (cols - 1)) / cols;
  const rtl = format === "manga";
  const rowCount = Math.max(1, Math.ceil(items.length / cols) || 1);
  const slots = items.map((item, i) => {
    const row = Math.floor(i / cols);
    const k = i % cols;
    const col = rtl ? cols - 1 - k : k;
    const aspect = Math.max(0.2, item.w / Math.max(1, item.h));
    const natural = cellW / aspect;
    const h = format === "webtoon" ? clamp(natural, cellW * 0.5, cellW * 1.85) : clamp(natural, cellW * 0.78, cellW * 1.15);
    return { id: item.id, row, col, h };
  });
  const rowH: number[] = [];
  for (let r = 0; r < rowCount; r++) {
    const hs = slots.filter((s) => s.row === r).map((s) => s.h);
    rowH[r] = hs.length ? Math.max(...hs) : cellW;
  }
  const rowY: number[] = [];
  let y = frame + margin;
  for (let r = 0; r < rowCount; r++) {
    rowY[r] = y;
    y += (rowH[r] ?? cellW) + gutter;
  }
  const pageH = Math.max(280, y - gutter + margin + frame);
  const cells = slots.map((s) => ({
    id: s.id,
    x: frame + margin + s.col * (cellW + gutter),
    y: rowY[s.row] ?? frame,
    w: cellW,
    h: rowH[s.row] ?? cellW,
  }));
  return { pageW, pageH, cells };
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const clean = (text.replace(/\s+/g, " ").trim() || "…").slice(0, 180);
  const lines: string[] = [];
  let line = "";
  const pieces = (word: string) => {
    if (ctx.measureText(word).width <= maxW) return [word];
    const parts: string[] = [];
    let chunk = "";
    for (const ch of word) {
      const next = chunk + ch;
      if (ctx.measureText(next).width > maxW && chunk) {
        parts.push(chunk);
        chunk = ch;
      } else chunk = next;
    }
    if (chunk) parts.push(chunk);
    return parts;
  };
  for (const word of clean.split(" ")) {
    for (const part of pieces(word)) {
      const test = line ? `${line} ${part}` : part;
      if (line && ctx.measureText(test).width > maxW) {
        lines.push(line);
        line = part;
      } else line = test;
    }
  }
  if (line) lines.push(line);
  if (lines.length <= 5) return lines.length ? lines : ["…"];
  const cut = lines.slice(0, 5);
  const last = cut[4] ?? "";
  cut[4] = last.length > 2 ? `${last.slice(0, -1)}…` : "…";
  return cut;
}

function fontFor(kind: BubbleKind) {
  if (kind === "caption") return "500 26px Outfit, ui-sans-serif, sans-serif";
  if (kind === "shout") return "700 32px Outfit, ui-sans-serif, sans-serif";
  if (kind === "thought") return "500 30px Outfit, ui-sans-serif, sans-serif";
  return "500 32px Outfit, ui-sans-serif, sans-serif";
}

function drawImageFit(ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, w: number, h: number, fit: FitMode) {
  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;
  if (!iw || !ih) return;
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();
  ctx.fillStyle = "#161616";
  ctx.fillRect(x, y, w, h);
  if (fit === "fill") {
    const ir = iw / ih;
    const cr = w / h;
    let sx = 0;
    let sy = 0;
    let sw = iw;
    let sh = ih;
    if (ir > cr) {
      sw = ih * cr;
      sx = (iw - sw) / 2;
    } else {
      sh = iw / cr;
      sy = (ih - sh) / 2;
    }
    ctx.drawImage(img, sx, sy, sw, sh, x, y, w, h);
  } else {
    const ir = iw / ih;
    const cr = w / h;
    let dw = w;
    let dh = h;
    if (ir > cr) dh = w / ir;
    else dw = h * ir;
    ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }
  ctx.restore();
}

function drawBubble(
  ctx: CanvasRenderingContext2D,
  cell: PageCell,
  bubble: ComicBubble,
  active: boolean,
): PageBubble {
  const kind = bubble.kind;
  ctx.font = fontFor(kind);
  const padX = 18;
  const lineH = kind === "caption" ? 32 : 40;
  const maxW = Math.min(cell.w * 0.78, 540);
  const shown = kind === "shout" ? bubble.text.toUpperCase() : bubble.text;
  const lines = wrapLines(ctx, shown, maxW - padX * 2);
  const textW = Math.max(48, ...lines.map((ln) => ctx.measureText(ln).width));
  const bw = Math.min(maxW, textW + padX * 2);
  const bh = lines.length * lineH + (kind === "caption" ? 16 : 22);
  let x = cell.x + cell.w * bubble.x - bw / 2;
  let y = cell.y + cell.h * bubble.y - bh / 2;
  x = clamp(x, cell.x + 8, cell.x + cell.w - bw - 8);
  y = clamp(y, cell.y + 8, cell.y + cell.h - bh - 8);

  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.fillStyle = kind === "caption" ? "#fff4cc" : "#ffffff";
  ctx.strokeStyle = INK;
  ctx.lineWidth = active ? 7 : kind === "shout" ? 5 : 3.5;

  if (kind === "caption") {
    ctx.fillRect(x, y, bw, bh);
    ctx.strokeRect(x + 1.5, y + 1.5, bw - 3, bh - 3);
  } else if (kind === "shout") {
    const cx = x + bw / 2;
    const cy = y + bh / 2;
    const rx = bw / 2 + 10;
    const ry = bh / 2 + 10;
    const spikes = 14;
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const a = (i / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const radX = i % 2 === 0 ? rx : rx * 0.76;
      const radY = i % 2 === 0 ? ry : ry * 0.7;
      const px = cx + Math.cos(a) * radX;
      const py = cy + Math.sin(a) * radY;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else {
    const cx = x + bw / 2;
    const cy = y + bh / 2;
    ctx.beginPath();
    ctx.ellipse(cx, cy, bw / 2, bh / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    if (kind === "speech") {
      const tipX = x + bw * 0.28;
      const baseY = y + bh - 6;
      ctx.beginPath();
      ctx.moveTo(tipX - 16, baseY);
      ctx.lineTo(tipX + 14, baseY);
      ctx.lineTo(tipX - 6, baseY + 22);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(tipX - 16, baseY);
      ctx.lineTo(tipX - 6, baseY + 22);
      ctx.lineTo(tipX + 14, baseY);
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(tipX - 14, baseY - 6, 26, 10);
    } else {
      const dots = [
        { dx: 22, dy: bh + 6, r: 7 },
        { dx: 10, dy: bh + 18, r: 4.5 },
        { dx: 4, dy: bh + 28, r: 2.5 },
      ];
      for (const d of dots) {
        ctx.beginPath();
        ctx.arc(x + d.dx, y + d.dy, d.r, 0, Math.PI * 2);
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.stroke();
      }
    }
  }

  ctx.fillStyle = INK;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = fontFor(kind);
  const top = y + (bh - lines.length * lineH) / 2 + lineH / 2;
  lines.forEach((ln, i) => ctx.fillText(ln, x + bw / 2, top + i * lineH));
  return { panelId: cell.id, id: bubble.id, x, y, w: bw, h: bh };
}

export type PaintOpts = {
  badges: boolean;
  activeId: string | null;
  activeBubble: string | null;
  fit: FitMode;
};

export function paintComic(ctx: CanvasRenderingContext2D, panels: DrawPanel[], placed: ReturnType<typeof placePanels>, opts: PaintOpts): PageLayout {
  const { pageW, pageH, cells } = placed;
  ctx.fillStyle = PAPER;
  ctx.fillRect(0, 0, pageW, pageH);
  ctx.fillStyle = INK;
  ctx.fillRect(0, 0, pageW, 10);
  ctx.fillRect(0, pageH - 10, pageW, 10);
  ctx.fillRect(0, 0, 10, pageH);
  ctx.fillRect(pageW - 10, 0, 10, pageH);

  const byId = new Map(panels.map((p) => [p.id, p]));
  cells.forEach((cell, index) => {
    const panel = byId.get(cell.id);
    if (!panel) return;
    drawImageFit(ctx, panel.img, cell.x, cell.y, cell.w, cell.h, opts.fit);
    ctx.strokeStyle = INK;
    ctx.lineWidth = opts.activeId === cell.id ? 8 : 4;
    ctx.strokeRect(cell.x + 2, cell.y + 2, cell.w - 4, cell.h - 4);
    if (opts.badges) {
      const s = 36;
      ctx.fillStyle = INK;
      ctx.fillRect(cell.x, cell.y, s, s);
      ctx.fillStyle = "#ffffff";
      ctx.font = "600 20px Outfit, ui-sans-serif, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(index + 1), cell.x + s / 2, cell.y + s / 2 + 1);
    }
  });

  const bubbles: PageBubble[] = [];
  for (const cell of cells) {
    const panel = byId.get(cell.id);
    if (!panel) continue;
    for (const bubble of panel.bubbles) {
      bubbles.push(drawBubble(ctx, cell, bubble, opts.activeBubble === bubble.id));
    }
  }
  return { pageW, pageH, cells, bubbles };
}

function sizeAndPaint(
  canvas: HTMLCanvasElement,
  panels: DrawPanel[],
  format: ComicFormat,
  cols: number,
  fit: FitMode,
  scale: number,
  opts: Omit<PaintOpts, "fit">,
): PageLayout {
  const placed = placePanels(
    panels.map((p) => ({ id: p.id, w: p.w, h: p.h })),
    format,
    cols,
  );
  canvas.width = Math.max(1, Math.round(placed.pageW * scale));
  canvas.height = Math.max(1, Math.round(placed.pageH * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) return { ...placed, bubbles: [] };
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  return paintComic(ctx, panels, placed, { ...opts, fit });
}

export function drawComicPreview(
  canvas: HTMLCanvasElement,
  panels: DrawPanel[],
  format: ComicFormat,
  cols: number,
  cssWidth: number,
  opts: PaintOpts,
): PageLayout {
  const placed = placePanels(
    panels.map((p) => ({ id: p.id, w: p.w, h: p.h })),
    format,
    cols,
  );
  const dpr = placed.pageH > 5000 ? 1 : Math.min(2, typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1);
  const scale = (cssWidth / placed.pageW) * dpr;
  const layout = sizeAndPaint(canvas, panels, format, cols, opts.fit, scale, opts);
  canvas.style.width = `${cssWidth}px`;
  canvas.style.height = `${placed.pageH * (cssWidth / placed.pageW)}px`;
  return layout;
}


export async function exportComic(panels: DrawPanel[], format: ComicFormat, cols: number, fit: FitMode) {
  const placed = placePanels(
    panels.map((p) => ({ id: p.id, w: p.w, h: p.h })),
    format,
    cols,
  );
  const canvas = document.createElement("canvas");
  const scale = placed.pageH > 6000 ? 1 : 2;
  sizeAndPaint(canvas, panels, format, cols, fit, scale, { badges: false, activeId: null, activeBubble: null });
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("empty"))), "image/png");
  });
  const name = format === "webtoon" ? "latch-webtoon.png" : format === "manga" ? "latch-manga.png" : "latch-comic.png";
  await saveFile(blob, name);
}
