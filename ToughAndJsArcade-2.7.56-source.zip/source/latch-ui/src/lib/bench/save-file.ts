// Latch 2.1: one way out for every saved file.
// In the Tough & J's Arcade APK the page can't download blob: links, so write straight through the app's
// TJApp save bridge (Downloads/ToughAndJs), checked by byte count. In a browser, use a normal download link.
type Bridge = {
  beginSave(name: string, mime: string): boolean;
  saveChunk(b64: string): boolean;
  endSave(): string;
  endSaveChecked?(expected: string): string;
};

function bridge(): Bridge | null {
  const pick = (w: unknown): Bridge | null => {
    try {
      const t = (w as { TJApp?: Bridge } | null)?.TJApp;
      return t && typeof t.beginSave === "function" ? t : null;
    } catch {
      return null;
    }
  };
  return pick(window) || (window.parent !== window ? pick(window.parent) : null);
}

const CHUNK = 786432;

async function viaBridge(T: Bridge, blob: Blob, filename: string) {
  if (!T.beginSave(filename, blob.type || "application/octet-stream")) {
    throw new Error("The phone is still writing the last file. Try again in a moment.");
  }
  try {
    for (let o = 0; o < blob.size; o += CHUNK) {
      const u = new Uint8Array(await blob.slice(o, o + CHUNK).arrayBuffer());
      let s = "";
      for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192) as unknown as number[]);
      if (!T.saveChunk(btoa(s))) throw new Error("chunk");
    }
  } catch {
    try {
      if (T.endSaveChecked) T.endSaveChecked("-1");
      else T.endSave();
    } catch {
      /* already closed */
    }
    throw new Error("Couldn't save that file on this phone.");
  }
  const r = T.endSaveChecked ? T.endSaveChecked(String(blob.size)) : T.endSave();
  if (r !== "ok") throw new Error("Couldn't save that file on this phone.");
}

export async function saveFile(blob: Blob, filename: string) {
  const T = bridge();
  if (T) return viaBridge(T, blob, filename);
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = filename;
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  window.setTimeout(() => a.remove(), 0);
  window.setTimeout(() => URL.revokeObjectURL(url), 30000);
}
