// Latch 2.1: turn the approved paper-manual mock (mock-approved.html, Jay t1010) into Latch source.
// Output: src/components/bench/manual-pages.ts (9 page bodies, classes prefixed lm-) + src/manual.css (scoped, no flex gap, no inset).
// Only deliberate change vs the mock: Fig. 1 leaders 7-10 rerouted so no leader crosses another control.
import fs from "node:fs";
const D = "/workspace/game/build-latch/manual", S = "/workspace/game/build-apps/src-latch/src";
const mock = fs.readFileSync(D + "/mock-approved.html", "utf8");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const pre = (cls) => cls.split(/\s+/).filter(Boolean).map((c) => "lm-" + c).join(" ");
// ---------- pages ----------
const re = /<section class="([^"]+)" data-p="(\d)" data-name="([^"]+)">([\s\S]*?)<\/section>/g; let m; const pages = [];
while ((m = re.exec(mock))) {
  let body = m[4].replace(/<!--[\s\S]*?-->/g, "");
  body = body.replace(/class="([^"]+)"/g, (_, c) => `class="${pre(c)}"`).replace(/id="dot"/g, 'id="lm-dot"').replace(/url\(#dot\)/g, "url(#lm-dot)");
  body = body.replace(/PlexCond/g, "LmPlex").replace(/\n\s+/g, "\n").trim();
  pages.push({ n: +m[2], name: m[3].replace(/&amp;/g, "&"), cls: pre(m[1].replace(/\bon\b/, "")), html: body });
}
assert(pages.length === 9 && pages.map((p) => p.n).join("") === "123456789", "9 pages");
// ---------- Fig. 1 controls page: tag shapes / leaders / badges, reroute 7-10 ----------
let c = pages[2].html; const R = (a, b) => { assert(c.split(a).length === 2, "unique: " + a); c = c.replace(a, b); };
const ctl = [
  [1, '<rect x="88" y="36" width="18" height="18" rx="2"'], [2, '<rect x="112" y="36" width="80" height="18" rx="9"'], [3, '<circle cx="208" cy="45" r="8"'],
  [4, '<rect x="222" y="36" width="18" height="18" rx="2"'], [5, '<rect x="84" y="64" width="168" height="154" rx="8"'], [6, '<rect x="84" y="226" width="22" height="22" rx="2"/>'],
  [7, '<rect x="110" y="226" width="36" height="22" rx="2"'], [8, '<rect x="150" y="226" width="22" height="22" rx="2"/>'], [9, '<rect x="176" y="228" width="46" height="18" rx="2"/>'],
  [10, '<rect x="226" y="226" width="22" height="22" rx="2"/>'], [11, '<rect x="88" y="256" width="160" height="34" rx="3"'], [12, '<rect x="84" y="308" width="42" height="70" rx="4"'],
  [13, '<rect x="130" y="308" width="42" height="70" rx="4"'], [14, '<rect x="176" y="308" width="42" height="70" rx="4"'], [15, '<rect x="222" y="308" width="30" height="70" rx="4"'],
];
for (const [n, s] of ctl) R(s, s.replace(/^<(rect|circle) /, `<$1 data-ctl="${n}" `));
const leads = [
  [1, "M88 45 H 56"], [2, "M152 36 V 14"], [3, "M208 37 V 14"], [4, "M240 45 H 280"], [5, "M84 140 H 56"], [6, "M84 237 H 56"],
  [7, "M128 226 V 218 H 56", "M128 226 V 220 H 56"], [8, "M172 237 H 280", "M161 248 V 253 H 280"], [9, "M222 228 V 218 H 280", "M199 228 V 220 H 280"],
  [10, "M237 248 V 258 H 280", "M248 236 H 280"], [11, "M88 276 H 56"], [12, "M105 378 V 428 H 56"], [13, "M151 378 V 414"], [14, "M197 378 V 436"], [15, "M237 378 V 414 H 280"],
];
for (const [n, a, b] of leads) R(`<path d="${a}"/>`, `<path data-lead="${n}" d="${b || a}"/>`);
// badges: [n, cx, cy, newCy, label] (text y = cy + 3.3; the caption text moves with the badge)
const badges = [[1, 48, 45], [2, 152, 14], [3, 208, 14], [4, 288, 45], [5, 48, 140], [6, 48, 237], [7, 48, 218, 220], [8, 288, 237, 253], [9, 288, 218, 220], [10, 288, 258, 236], [11, 48, 276], [12, 48, 428], [13, 151, 422], [14, 197, 444], [15, 288, 414]];
for (const [n, x, y, ny] of badges) {
  R(`<circle cx="${x}" cy="${y}" r="8" fill="#b21418"/>`, `<circle data-badge="${n}" cx="${x}" cy="${ny ?? y}" r="8" fill="#b21418"/>`);
  if (ny !== undefined) { const ty = (y + 3.3).toFixed(1), nty = (ny + 3.3).toFixed(1); R(`<text x="${x}" y="${ty}" text-anchor="middle"`, `<text x="${x}" y="${nty}" text-anchor="middle"`); }
}
R('<text x="4" y="221.3" font-size="8" fill="#16120f">Play</text>', '<text data-cap="7" x="4" y="223.3" font-size="8" fill="#16120f">Play</text>');
R('<text x="300" y="233" font-size="8" fill="#16120f">Fwd</text>', '<text data-cap="8" x="300" y="256.3" font-size="8" fill="#16120f">Fwd</text>');
R('<text x="300" y="221.3" font-size="8" fill="#16120f">Time</text>', '<text data-cap="9" x="300" y="223.3" font-size="8" fill="#16120f">Time</text>');
R('<text x="300" y="261.3" font-size="8" fill="#16120f">Loop</text>', '<text data-cap="10" x="300" y="239.3" font-size="8" fill="#16120f">Loop</text>');
// readability: callout captions 8 -> 9 units, sub-captions 6.5 -> 8 (only inside the badge/caption group)
{ const g0 = c.indexOf('<g font-family="LmPlex,sans-serif" font-weight="700">'); assert(g0 > 0, "caption group"); const g1 = c.indexOf("</g>", g0);
  const grp = c.slice(g0, g1).replace(/font-size="8" fill="#16120f"/g, 'font-size="9" fill="#16120f"').replace(/font-size="6.5" fill="#6a5e4a"/g, 'font-size="8" fill="#6a5e4a"');
  c = c.slice(0, g0) + grp.replace('<g font-family="LmPlex,sans-serif" font-weight="700">', '<g data-callouts="1" font-family="LmPlex,sans-serif" font-weight="700">') + c.slice(g1); }
// tighter viewBox (the drawing spans y 6..452): about 4% larger on short phones, nothing cut
R('viewBox="0 0 336 470"', 'viewBox="0 4 336 452"');
pages[2].html = c;
// cover: this book now really opens from MENU > MANUAL; version on the plate is not in the mock, keep text as approved.
const ts = `// GENERATED by build-latch/manual/gen-manual.mjs from the approved mock (Jay t1010). Do not hand-edit; re-run the generator.
export type ManualPage = { n: number; name: string; cls: string; html: string };
export const MANUAL_PAGES: ManualPage[] = ${JSON.stringify(pages, null, 1)};
`;
fs.writeFileSync(S + "/components/bench/manual-pages.ts", ts);
// ---------- CSS ----------
let css = mock.split("<style>")[1].split("</style>")[0];
css = css.replace(/@font-face\{[^}]*\}\n?/g, "");
const DROP = /^(html,body|\.phone|\.bar|\.k|\.k svg|\.sw|\.sw span|\.sw span\.on|\.sw span\.on i|\.toast|\.toast\.on|\*)$/;
const out = []; let depth = 0;
// tiny CSS walker: rules + @media blocks
const walk = (src) => {
  const res = []; let i = 0;
  while (i < src.length) {
    const open = src.indexOf("{", i); if (open < 0) break;
    const sel = src.slice(i, open).trim();
    if (sel.startsWith("@media")) { let d = 1, j = open + 1; while (d) { if (src[j] === "{") d++; else if (src[j] === "}") d--; j++; } res.push({ media: sel, body: walk(src.slice(open + 1, j - 1)) }); i = j; continue; }
    const close = src.indexOf("}", open); res.push({ sel, decl: src.slice(open + 1, close) }); i = close + 1;
  }
  return res;
};
const fix = (sel, decl) => {
  if (DROP.test(sel)) return null;
  if (sel === ":root") sel = ".lman";
  else sel = sel.split(",").map((s) => ".lman " + s.trim().replace(/\.([a-zA-Z][\w-]*)/g, ".lm-$1")).join(",");
  decl = decl.replace(/\binset:0/g, "top:0;right:0;bottom:0;left:0");
  return sel + "{" + decl.trim() + "}";
};
const emit = (rules) => rules.map((r) => (r.media ? r.media + "{\n" + emit(r.body) + "\n}" : fix(r.sel, r.decl))).filter(Boolean).join("\n");
css = emit(walk(css));
// flex gap -> margins (old WebView 83 has no flex gap; also keeps the legacy gap shim idle)
const GAPS = [];
css = css.replace(/([^{}\n]+)\{([^{}]*)\}/g, (all, sel, decl) => {
  const g = /(?:^|;)\s*gap:([^;]+)/.exec(decl); if (!g || /grid/.test(decl) && !/display:flex/.test(decl)) return all;
  GAPS.push(sel.trim() + " => " + g[1]); return all; // reported, rewritten below by hand-table
});
fs.writeFileSync(D + "/gaps.txt", GAPS.join("\n") + "\n");
fs.writeFileSync(D + "/manual.raw.css", css + "\n");
console.log("pages", pages.map((p) => p.n + ":" + p.name + ":" + p.html.length).join(" "), "css", css.length, "flex-gaps", GAPS.length);
