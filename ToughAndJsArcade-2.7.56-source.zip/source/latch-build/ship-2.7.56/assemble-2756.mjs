// Arcade 2.7.56: swap ONLY latch:latest (Latch 2.1, VTR-1 Owner's Manual) on top of unpublished 2.7.55;
// the 2.7.55 Latch (2.0) is kept as latch:v20, latch:v11 and latch:v1 stay. Every other cartridge payload + legacy variant byte-for-byte.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const BASE = "/workspace/game/build-latch/package-2.7.56/base-2.7.55.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "19606b2b4ef4060b14047f89a5313fae1934956edbde745b304b22382476dbb1", "2.7.55 bundle changed?!");
const NEW = fs.readFileSync("/workspace/game/build-apps/latch-v2.1.html", "utf8");
const OLD20 = fs.readFileSync("/workspace/game/build-apps/latch-v2.0.html", "utf8");
assert(sha(OLD20) === "5dc0215e5d60f68b1c0469ce5f166b7b98d0574368a8855568ab4488e7969856", "2.0 file changed?!");
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const before = slots(src); assert(before["latch:latest"] && before["latch:v11"] && !before["latch:v20"], "slots");
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const G0 = GS(src); assert(G0["latch:latest"] === OLD20, "2.7.55 latch:latest != Latch 2.0 file");
const [a, b, oldExpr] = before["latch:latest"];
const expr = JSON.stringify([NEW]).replace(/<\//g, "<\\/") + '.join("")';
let out = src.slice(0, a) + expr + ',\n"latch:v20":' + oldExpr + src.slice(b);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const GAMES = JSON.parse(gLine.slice(12).replace(/;\s*$/, "")); assert(JSON.stringify(GAMES) === gLine.slice(12).replace(/;\s*$/, ""), "GAMES roundtrip");
const la = GAMES.find((g) => g.id === "latch"); const cur = la.versions.find((v) => v.id === "latest");
const prior = { ...cur, id: "v20", name: "v2.0 – VTR-1 (2.7.52–2.7.55)", desc: "Latch 2.0 as in 2.7.52–2.7.55: the VTR-1 camcorder UI with the plain-list manual.", def: false };
la.versions.splice(la.versions.length - 1, 0, prior);
cur.name = "v2.1 – Latest (VTR-1 + Owner’s Manual)";
cur.desc = "Tool, not a game. VTR-1 camcorder layout: big viewfinder, transport + counter, filmstrip with drag handles, and four keys (CUT, LOOK, ADD, SAVE). New in 2.1: a paper Owner’s Manual under MENU › MANUAL, 9 pages you swipe or tap (Controls diagram with all 15 keys numbered, Cut, Look, Add, Save, Settings, Troubleshooting). Closing it puts the recorder back as it was. Hold any button for a tip; ? numbers the screen. Nothing leaves the phone.";
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const oldLeg = LEG["latch:latest"]; assert(oldLeg, "old latch legacy");
const rep = {}; const parts = legacyParts(NEW, rep); assert(rep.jsFail.length === 0, "legacy js fail " + rep.jsFail);
assert(joinParts(parts, NEW) === legacyHtml(NEW, {}), "parts mismatch");
const LEG2 = {}; for (const k of Object.keys(LEG)) { LEG2[k] = k === "latch:latest" ? parts : LEG[k]; if (k === "latch:latest") LEG2["latch:v20"] = oldLeg; }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]);
assert(JSON.stringify(changed) === '["latch:latest"]', "changed " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === '["latch:v20"]', "new slots");
const G1 = GS(out); assert(G1["latch:latest"] === NEW && G1["latch:v20"] === OLD20, "payloads");
for (const k of Object.keys(G0)) if (k !== "latch:latest") assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (k !== "latch:latest") assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
fs.writeFileSync(OUT, out);
const info = {
  arcadeVersion: "2.7.56", versionCode: 94, latchVersion: "2.1",
  latchSHA256: sha(NEW), latchBytes: Buffer.byteLength(NEW),
  latch20SHA256: sha(OLD20), latch20Bytes: Buffer.byteLength(OLD20),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), baseBundleSHA256_2755: sha(src),
  cartridgeSlots: Object.keys(after).length, unchangedSlots: Object.keys(before).length - 1,
  newSlot: "latch:v20 (= 2.7.55 latch:latest, byte-identical Latch 2.0)",
  funmotionLatestSHA256: sha(G1["funmotion:latest"]), swarmLatestSHA256: sha(G1["swarm:latest"]),
  legacy: { latchLatest: `css ${rep.css} js ${rep.js}`, keptOldVariantAs: "latch:v20", variants: Object.keys(LEG2).length },
  latchVersionsInPicker: la.versions.map((v) => v.name + (v.def ? " (default)" : "")),
};
fs.writeFileSync(OUT.replace(/[^/]+$/, "assembly-verification.json"), JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
