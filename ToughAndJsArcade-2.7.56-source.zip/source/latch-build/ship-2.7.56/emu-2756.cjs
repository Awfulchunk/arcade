// Pass 4 — WebView 83 emulator (Android 11, Chrome 83.0.4103.120, software rendering): the installed 2.7.56 APK.
// Latch 2.1 legacy build, MENU › MANUAL with REAL adb taps + swipes through all 9 pages, close, state back, quick cut + GIF save to Downloads.
const connect = require("/workspace/game/build-latch/fix/cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const ADB = "/workspace/tools/sdk/platform-tools/adb";
const OUT = process.argv[2] || __dirname + "/emu"; fs.mkdirSync(OUT, { recursive: true });
const sh = (c) => execSync(`${ADB} ${c}`).toString();
const shot = (n) => execSync(`${ADB} exec-out screencap -p > ${OUT}/${n}.png`);
(async () => {
  let c; for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d === undefined ? "" : d).slice(0, 320)); };
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const shell = JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:(navigator.userAgent.match(/Chrome\\/[\\d.]+/)||[''])[0],dpr:devicePixelRatio,latch:ARCADE.GAMES.find(g=>g.id==='latch').versions.map(v=>v.id+(v.def?'*':''))})`));
  ok("APK shell on WebView 83, legacy builds picked, Latch picker has v2.1 default + v20 kept", shell.legacy && /Chrome\/83/.test(shell.ua) && shell.latch.join() === "v1,v11,v20,latest*", shell);
  if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(2000); }
  const n0 = c.ctx.length;
  await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='latch');ARCADE.launchCard(i);return 1})()`); await sleep(12000);
  let cx; for (let i = 0; i < 20 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); }
  if (!cx) throw new Error("no Latch frame");
  const ev = (e) => c.ev(e, cx.id); const J = async (e) => JSON.parse(await ev(`JSON.stringify(${e})`));
  // screen coordinates of an element inside the game iframe (WebView is full-screen at 0,0)
  const pt = async (sel, fx = 0.5, fy = 0.5) => { const r = await J(`(()=>{const e=[...document.querySelectorAll(${JSON.stringify(sel)})].find(e=>e.getClientRects().length);if(!e)return null;const b=e.getBoundingClientRect();return {x:b.left+b.width*${fx},y:b.top+b.height*${fy}}})()`); if (!r) throw new Error("not visible " + sel); const f = await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`); const o = JSON.parse(f); return { x: Math.round((o.x + r.x) * shell.dpr), y: Math.round((o.y + r.y) * shell.dpr) }; };
  const atap = async (sel, wait = 1500) => { const p = await pt(sel); sh(`shell input tap ${p.x} ${p.y}`); await sleep(wait); return p; };
  const env = await J(`{vtr:!!document.querySelector('main.vtr'),gapShim:!!window.__tjGap,legacyPrelude:/TJ legacy prelude/.test(document.documentElement.innerHTML),ver:/Latch 2\\.1|"2\\.1"/.test(document.documentElement.innerHTML),book:!!document.querySelector('.lman'),errs:window.__errs}`);
  ok("Latch 2.1 opens (legacy variant: prelude + flex-gap shim), 0 errors", env.vtr && env.legacyPrelude && env.errs.length === 0, env);
  if (await J(`!!document.querySelector('.hint')`)) await atap(".hint button");
  await atap("[data-sample]", 6000);
  const osd0 = await J(`(document.querySelector('.osd.obl')||{}).textContent||''`);
  ok("sample clip loaded (real tap)", /sample/i.test(osd0), osd0);
  // pause with the real Play key so the before/after state is comparable (the sample is a GIF: OSD time tells if it runs)
  const OSD = `(document.querySelector('.osd.obl')||{}).textContent||''`;
  const runs = async () => { const a = await J(OSD); await sleep(1200); return a !== (await J(OSD)); };
  const wasRunning = await runs(); if (wasRunning) await atap(".play", 2000);
  const playing0 = await runs();
  shot("01-latch-2.1");
  const SNAP = `(()=>{const m=document.querySelector('main.vtr');const c=m.cloneNode(true);c.querySelectorAll('.lman,.lman-shield').forEach(e=>e.remove());return {len:c.innerHTML.length,h:(()=>{let h=0;const s=c.innerHTML.replace(/\\d+:\\d+\\.\\d+/g,'T');for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h})(),osd:(document.querySelector('.osd.obl')||{}).textContent,leds:[...document.querySelectorAll('.led.on')].length}})()`;
  const s0 = await J(SNAP);
  // MENU › MANUAL with real taps
  await atap(".bar [aria-label=Menu]", 2500); shot("02-menu");
  const tile = await J(`!!document.querySelector('[data-manual-open]')`);
  await atap("[data-manual-open]", 3000);
  let m = await J(`(()=>{const m=document.querySelector('.lman');return m&&{page:+m.dataset.page,counter:m.querySelector('[data-manual-counter]').textContent,name:m.querySelector('.lm-pg.lm-on').dataset.name}})()`);
  ok("MENU › MANUAL opens the book at p.1 Cover (real taps)", tile && m && m.page === 1, m);
  shot("03-manual-p1");
  // real swipes through all 9 pages
  const box = await J(`(()=>{const b=document.querySelector('.lman .lm-pages').getBoundingClientRect();return {l:b.left,t:b.top,w:b.width,h:b.height}})()`);
  const o = JSON.parse(await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`));
  const X = (f) => Math.round((o.x + box.l + box.w * f) * shell.dpr), Y = Math.round((o.y + box.t + box.h * 0.55) * shell.dpr);
  const seq = [];
  for (let i = 2; i <= 9; i++) { sh(`shell input swipe ${X(0.85)} ${Y} ${X(0.15)} ${Y} 220`); await sleep(2200); const q = await J(`+document.querySelector('.lman').dataset.page`); seq.push(q); shot(`04-manual-p${q}`); }
  const osdBook = await J(OSD); ok("recorder stays paused behind the book (counter held while reading)", osdBook === s0.osd, { before: s0.osd, inBook: osdBook });
  ok("8 real swipes walk p.1 → p.9, one page each", seq.join() === "2,3,4,5,6,7,8,9", seq.join());
  const fit = await J(`(()=>{const out=[];const pg=document.querySelector('.lman .lm-pg.lm-on');const b=pg.getBoundingClientRect();return {sh:pg.scrollHeight,ch:pg.clientHeight,docScroll:document.scrollingElement.scrollHeight<=innerHeight+1}})()`);
  ok("p.9 fits (no scrolling) on WebView 83", fit.sh <= fit.ch + 1 && fit.docScroll, fit);
  // tap back with the real Prev key, then a Contents jump by real tap
  const back = []; for (let i = 0; i < 7; i++) { await atap("[data-manual-prev]", 1800); back.push(await J(`+document.querySelector('.lman').dataset.page`)); }
  ok("real taps on Prev walk p.9 → p.2", back.join() === "8,7,6,5,4,3,2", back.join());
  shot("05-manual-contents");
  await atap('.lman .lm-toc [data-go="3"]', 2200); const cj = await J(`+document.querySelector('.lman').dataset.page`);
  ok("real tap on a Contents line jumps (→ p.3 Controls)", cj === 3, cj); shot("06-manual-controls");
  // Controls diagram callouts render with legacy fonts/svg
  const fig = await J(`(()=>{const s=document.querySelector('.lman .lm-on svg');const b=document.querySelectorAll('.lman [data-badge]').length;const r=s&&s.getBoundingClientRect();return {svg:!!s,badges:b,w:r&&Math.round(r.width),h:r&&Math.round(r.height),fonts:document.fonts?[...document.fonts].filter(f=>/^Lm/.test(f.family)&&f.status==='loaded').length:-1}})()`);
  ok("Controls page: Fig. 1 with 15 numbered callouts, manual fonts loaded", fig.svg && fig.badges === 15 && fig.fonts >= 3, fig);
  // swipe back right twice (real) then close with the real CLOSE key
  sh(`shell input swipe ${X(0.15)} ${Y} ${X(0.85)} ${Y} 220`); await sleep(2200);
  const sb = await J(`+document.querySelector('.lman').dataset.page`); ok("real swipe right turns back (p.3 → p.2)", sb === 2, sb);
  await atap("[data-manual-close]", 2500);
  const s1 = await J(SNAP); const gone = await J(`!document.querySelector('.lman,.lman-shield')`);
  const playing1 = await runs();
  ok("CLOSE (real tap): book gone, recorder back as it was (DOM hash, OSD, LEDs; playing state same as before)", gone && s0.h === s1.h && s0.osd === s1.osd && s0.leds === s1.leds && playing0 === playing1, { s0, s1, playing0, playing1 });
  shot("07-closed");
  // quick cut: CUT key → Trim → Out −10 → Done, all real taps
  const hasTrim = await J(`!!document.querySelector('[data-tool=trim]')&&document.querySelector('[data-tool=trim]').getClientRects().length>0`);
  if (!hasTrim) { await ev(`(()=>{const k=[...document.querySelectorAll('.mk')].find(e=>/CUT/.test(e.textContent));k&&k.setAttribute('data-emu-cut','');return 1})()`); await atap("[data-emu-cut]", 1800); }
  await atap("[data-tool=trim]", 2000);
  const RD = `[...document.querySelectorAll('.drawer .read')].map(e=>e.textContent).join(' ')`;
  const r0 = await J(RD);
  await atap('.drawer [data-tip^="Out|"]', 1500); await atap('.drawer [data-tip^="−10|"]', 1500);
  const r1 = await J(RD);
  shot("08-cut-trim"); await atap("[data-done]", 1800);
  const trimLed = await J(`!!document.querySelector('[data-tool=trim] .led.on')`);
  ok("quick cut (real taps): Out −10 frames changes the readout, Done, TRIM LED on", r0 !== r1 && trimLed, { r0, r1, trimLed });
  // save GIF through the APK bridge into Downloads/ToughAndJs
  const before = sh(`shell ls /sdcard/Download/ToughAndJs/ 2>/dev/null || true`).split(/\n/).map((x) => x.trim()).filter(Boolean);
  const saveKey = await J(`(()=>{const k=[...document.querySelectorAll('.mk')].find(e=>/SAVE/.test(e.textContent));if(!k)return null;const b=k.getBoundingClientRect();return true})()`);
  if (saveKey) { await ev(`(()=>{const k=[...document.querySelectorAll('.mk')].find(e=>/SAVE/.test(e.textContent));k.setAttribute('data-emu-save','');return 1})()`); await atap("[data-emu-save]", 2500); }
  shot("09-save-sheet");
  await atap("[data-save-gif]", 1000);
  // wait for a new .gif whose size is > 0 and stable (the app writes it in chunks, then checks the byte count)
  let added = [], last = -1; for (let i = 0; i < 90; i++) { await sleep(2000); const now = sh(`shell ls /sdcard/Download/ToughAndJs/ 2>/dev/null || true`).split(/\n/).map((x) => x.trim()).filter(Boolean); const nw = now.filter((f) => !before.includes(f) && /\.gif$/i.test(f)); if (!nw.length) continue; const sz = +sh(`shell stat -c %s "/sdcard/Download/ToughAndJs/${nw[0]}"`).trim(); if (sz > 0 && sz === last) { added = nw; break; } last = sz; }
  shot("10-saved");
  let gifInfo = null; if (added.length) { const f = added[0]; execSync(`${ADB} pull "/sdcard/Download/ToughAndJs/${f}" ${OUT}/emu-saved.gif`); const b = fs.readFileSync(`${OUT}/emu-saved.gif`); gifInfo = { file: f, bytes: b.length, magic: b.slice(0, 6).toString(), frames: (b.toString("latin1").match(/\x21\xF9\x04/g) || []).length }; }
  ok("SAVE › GIF (real taps) writes a valid animated GIF to Download/ToughAndJs on the device", gifInfo && /^GIF8/.test(gifInfo.magic) && gifInfo.frames > 1 && gifInfo.bytes > 1000, gifInfo);
  const errs = await J(`window.__errs`); ok("0 JS errors in Latch 2.1 on WebView 83 (whole run)", errs.length === 0, errs);
  if (await J(`!!document.querySelector('[data-done]')`)) await atap("[data-done]", 1000).catch(() => {});
  fs.writeFileSync(`${OUT}/emu-2756.json`, JSON.stringify({ shell, R }, null, 1));
  console.log(`emu-2756: ${R.filter((r) => r.pass).length}/${R.length} pass`); c.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); process.exit(1); });
