// PASS 2 — layout / GUI at one viewport: every page screenshotted; nothing clipped, nothing overlapping, text readable,
// fonts really loaded, and Fig. 1's 15 callouts land on the right drawn control AND match the real Latch control layout.
const { open, tap, sleep, A, fs, LATCH, man, NAMES } = require("./lib2756.cjs");
const VP = (process.argv[2] || "360x800").split("x").map(Number);
const OUT = process.argv[3] || `out/layout-${VP[0]}x${VP[1]}`; fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const { b, p, errs } = await open(LATCH, VP);
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d: typeof d === "string" ? d : JSON.stringify(d) }); console.log(v ? "PASS" : "FAIL", n, typeof d === "string" ? d : JSON.stringify(d).slice(0, 400)); };
  const ev = (f, ...a) => p.evaluate(f, ...a);
  await ev(() => localStorage.clear()); await p.reload(); await sleep(700);
  // a GIF tape, so the real transport shows the Loop key (#10) like Fig. 1
  const [inp] = await p.$$("main.vtr input[type=file]"); await inp.uploadFile(A("anim.gif")); await sleep(2500);
  if (await ev(() => !!document.querySelector(".hint"))) await tap(p, ".hint button");
  // real control boxes on the recorder
  const REAL = await ev(() => {
    const vis = (e) => e && e.getClientRects().length;
    const q = (s, t) => [...document.querySelectorAll(s)].filter(vis).find((e) => !t || e.textContent.includes(t));
    const sel = { 1: [".bar [aria-label=Undo]"], 2: [".bar .sw"], 3: [".bar [aria-label=Guide]"], 4: [".bar [aria-label=Menu]"], 5: [".vf"], 6: ['[aria-label="Back one frame"]'], 7: [".trans .play"], 8: ['[aria-label="Forward one frame"]'], 9: [".lcd"], 10: [".trans [aria-label=Loop]"], 11: [".tl"], 12: [".mk", "CUT"], 13: [".mk", "LOOK"], 14: [".mk", "ADD"], 15: [".mk", "SAVE"] };
    const o = {}; for (const [n, [s, t]] of Object.entries(sel)) { const e = q(s, t); if (e) { const r = e.getBoundingClientRect(); o[n] = { x: r.left, y: r.top, w: r.width, h: r.height }; } }
    return o;
  });
  ok("all 15 Fig. 1 controls exist on the real recorder (GIF tape)", Object.keys(REAL).length === 15, Object.keys(REAL).join(","));
  await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-manual-open]"); await sleep(500);
  await ev(() => document.fonts.ready);
  const fontsOk = await ev(() => ["700 12px LmPlex", "600 12px LmPlex", "400 12px LmBebas", "600 12px LmSrc", "700 12px LmSrc"].map((f) => [f, document.fonts.check(f)]));
  // check the actual faces were downloaded (not just "no font needed")
  const loaded = await ev(() => [...document.fonts].filter((f) => /^Lm/.test(f.family) && f.status === "loaded").map((f) => f.family + " " + f.weight));
  ok("manual fonts loaded (Bebas, Plex Cond 600/700, Source Sans 600/700)", fontsOk.every((x) => x[1]) && loaded.length >= 5, loaded.join(", "));
  let minHtml = 99, minSvg = 99, minCap = 99; const sum = [];
  for (let i = 0; i < 9; i++) {
    const m = await man(p); await sleep(260);
    await p.screenshot({ path: `${OUT}/${String(i + 1).padStart(2, "0")}-${NAMES[i].toLowerCase().replace(/[^a-z]+/g, "-")}.png` });
    const a = await ev(() => {
      const root = document.querySelector(".lman"); const pg = root.querySelector(".lm-pg.lm-on"); const P = pg.getBoundingClientRect();
      const head = root.querySelector(".lm-head").getBoundingClientRect(), foot = root.querySelector(".lm-foot").getBoundingClientRect(), bar = document.querySelector(".bar").getBoundingClientRect(), R0 = root.getBoundingClientRect();
      const clip = []; const texts = []; let minH = 99; const small = [];
      const inSvg = (e) => !!e.closest("svg");
      for (const e of pg.querySelectorAll("*")) {
        const r = e.getBoundingClientRect(); if (!r.width && !r.height) continue;
        // svg internals are checked separately (viewBox fit)
        if ((!inSvg(e) || e.tagName === "svg") && getComputedStyle(e).display !== "inline") { if (r.left < P.left - 0.5 || r.right > P.right + 0.5 || r.top < P.top - 0.5 || r.bottom > P.bottom + 0.5) clip.push((e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className) + "<" + e.tagName + "> " + [r.left, r.top, r.right, r.bottom].map((x) => x.toFixed(1)).join(",")); }
      }
      // text line boxes (precise, per text node) for overlap + readability
      const tw = document.createTreeWalker(pg, NodeFilter.SHOW_TEXT); let tn; let id = 0;
      while ((tn = tw.nextNode())) {
        if (!tn.textContent.trim()) continue; const el = tn.parentElement; const cs = getComputedStyle(el);
        const rg = document.createRange(); rg.selectNodeContents(tn); const rects = [...rg.getClientRects()].filter((r) => r.width > 0.5 && r.height > 0.5);
        let px = parseFloat(cs.fontSize);
        if (inSvg(el)) { const svg = el.closest("svg"); const vb = svg.viewBox.baseVal; const sr = svg.getBoundingClientRect(); const sc = Math.min(sr.width / vb.width, sr.height / vb.height); px = parseFloat(el.getAttribute("font-size") || cs.fontSize) * sc; }
        else minH = Math.min(minH, px);
        // ink box: the glyphs' real ascent/descent from the baseline (line boxes of tight display type overlap by design)
        const ctx = (window.__mc || (window.__mc = document.createElement("canvas").getContext("2d")));
        ctx.font = `${cs.fontWeight} ${px}px ${cs.fontFamily}`; const mt = ctx.measureText(tn.textContent.trim());
        const mine = id++; for (const r of rects) { const base = inSvg(el) ? r.bottom - (r.height - (mt.fontBoundingBoxAscent + mt.fontBoundingBoxDescent)) / 2 - mt.fontBoundingBoxDescent : r.top + (r.height - (mt.fontBoundingBoxAscent + mt.fontBoundingBoxDescent)) / 2 + mt.fontBoundingBoxAscent;
          texts.push({ id: mine, svg: inSvg(el), t: tn.textContent.trim().slice(0, 18), x0: r.left, y0: base - mt.actualBoundingBoxAscent, x1: r.right, y1: base + mt.actualBoundingBoxDescent, lx0: r.left, ly0: r.top, ly1: r.bottom, px }); }
        if (!inSvg(el) && px < 9) small.push(tn.textContent.trim().slice(0, 18) + " " + px);
      }
      for (const t of texts) if (!t.svg && (t.y0 < P.top - 0.5 || t.y1 > P.bottom + 0.5 || t.x0 < P.left - 0.5 || t.x1 > P.right + 0.5)) clip.push("text ink: " + t.t);
      // overlaps between different text nodes (HTML and SVG separately and across)
      const ov = [];
      for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
        const A = texts[i], B = texts[j]; if (A.id === B.id) continue;
        const w = Math.min(A.x1, B.x1) - Math.max(A.x0, B.x0), h = Math.min(A.y1, B.y1) - Math.max(A.y0, B.y0);
        // line boxes include leading; demand a real glyph-area clash (> 30% of the smaller line height and > 1.5px wide)
        if (w > 1 && h > 0.5) ov.push(A.t + " × " + B.t + " " + w.toFixed(1) + "x" + h.toFixed(1));
      }
      // svg fit: everything drawn inside its viewBox
      const svgOut = [];
      for (const svg of pg.querySelectorAll("svg")) { const vb = svg.viewBox.baseVal; if (!vb || !vb.width) continue; for (const g of svg.querySelectorAll("text,rect,circle,path")) { if (g.closest("defs,marker")) continue; let bb; try { bb = g.getBBox(); } catch (e) { continue; } if (bb.x < vb.x - 0.6 || bb.y < vb.y - 0.6 || bb.x + bb.width > vb.x + vb.width + 0.6 || bb.y + bb.height > vb.y + vb.height + 0.6) svgOut.push(g.tagName + " " + (g.textContent || g.getAttribute("d") || "").slice(0, 14)); } }
      // Fig. 1 callout captions/badges must be readable; drawing decoration (OSD lettering inside the line art) is reported only
      const capMin = Math.min(99, ...[...pg.querySelectorAll("[data-callouts] text")].map((el) => { const svg = el.closest("svg"); const vb = svg.viewBox.baseVal; const sr = svg.getBoundingClientRect(); return parseFloat(el.getAttribute("font-size")) * Math.min(sr.width / vb.width, sr.height / vb.height); }));
      const svgMin = Math.min(99, ...texts.filter((t) => t.svg).map((t) => t.px));
      // block-level overlap between sibling boxes (cards, chips, rows, tiles)
      const boxOv = [];
      for (const par of pg.querySelectorAll("*")) { if (inSvg(par)) continue; const kids = [...par.children].filter((k) => (!inSvg(k) || k.tagName === "svg") && getComputedStyle(k).display !== "inline").map((k) => [k, k.getBoundingClientRect()]).filter(([, r]) => r.width > 1 && r.height > 1 && getComputedStyle(par).display !== "inline"); for (let i = 0; i < kids.length; i++) for (let j = i + 1; j < kids.length; j++) { const a = kids[i][1], c = kids[j][1]; const w = Math.min(a.right, c.right) - Math.max(a.left, c.left), h = Math.min(a.bottom, c.bottom) - Math.max(a.top, c.top); if (w > 1 && h > 1) boxOv.push(kids[i][0].tagName + "." + kids[i][0].className + " × " + kids[j][0].className); } }
      const tap = [...root.querySelectorAll("button")].filter((e) => e.getClientRects().length).map((e) => { const r = e.getBoundingClientRect(); return [e.getAttribute("aria-label") || e.textContent.trim().slice(0, 12), Math.round(r.width), Math.round(r.height)]; });
      const frame = { barBottom: bar.bottom, rootTop: R0.top, rootBottom: R0.bottom, vh: innerHeight, headBottom: head.bottom, pgTop: P.top, pgBottom: P.bottom, footTop: foot.top, footBottom: foot.bottom, vw: innerWidth, rootL: R0.left, rootR: R0.right };
      return { clip, ov, svgOut, small, minH, svgMin, capMin, boxOv, tap, frame, sh: pg.scrollHeight, ch: pg.clientHeight };
    });
    minHtml = Math.min(minHtml, a.minH); if (a.svgMin < 99) minSvg = Math.min(minSvg, a.svgMin); if (a.capMin < 99) minCap = Math.min(minCap, a.capMin);
    const f = a.frame; const frameOk = Math.abs(f.rootTop - f.barBottom) < 1.5 && Math.abs(f.rootBottom - f.vh) < 1 && f.headBottom <= f.pgTop + 0.5 && f.pgBottom <= f.footTop + 0.5 && f.footBottom <= f.vh + 0.5 && f.rootL >= -0.5 && f.rootR <= f.vw + 0.5;
    const bad = a.clip.length + a.ov.length + a.svgOut.length + a.boxOv.length + (a.sh > a.ch + 1 ? 1 : 0) + (frameOk ? 0 : 1) + a.small.length;
    sum.push({ page: i + 1, name: NAMES[i], clipped: a.clip.length, textOverlaps: a.ov.length, boxOverlaps: a.boxOv.length, svgOutside: a.svgOut.length, smallText: a.small.length, minHtmlPx: a.minH === 99 ? null : +a.minH.toFixed(1), minSvgPx: a.svgMin === 99 ? null : +a.svgMin.toFixed(2), fits: a.sh <= a.ch + 1, frameOk });
    ok(`p.${i + 1} ${NAMES[i]}: not clipped, no overlaps, fits, framed under the bar, text ≥ 9px`, m.page === i + 1 && bad === 0, { clip: a.clip.slice(0, 3), ov: a.ov.slice(0, 4), box: a.boxOv.slice(0, 3), svg: a.svgOut.slice(0, 3), small: a.small.slice(0, 3), fits: [a.sh, a.ch], frame: frameOk ? "ok" : f });
    if (i === 0) { const t = a.tap; ok("CLOSE + page arrows are finger-sized (≥ 34 px tall, ≥ 38 px wide arrows)", t.every(([n, w, h]) => h >= 30 && (/page/.test(n) ? w >= 38 && h >= 34 : true)), t); }
    if (i === 2) {
      // ---- Fig. 1 callouts ----
      const c = await ev(() => {
        const svg = document.querySelector(".lman .lm-pg.lm-on svg");
        const bb = (e) => { const b = e.getBBox(); return { x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height }; };
        const out = {}; for (let n = 1; n <= 15; n++) {
          const ctl = svg.querySelector(`[data-ctl="${n}"]`), lead = svg.querySelector(`[data-lead="${n}"]`), badge = svg.querySelector(`[data-badge="${n}"]`);
          const d = lead.getAttribute("d").trim().split(/\s*(?=[MVHL])/); let x = 0, y = 0; const pts = [];
          for (const s of d) { const k = s[0], v = s.slice(1).trim().split(/[\s,]+/).map(Number); if (k === "M" || k === "L") { x = v[0]; y = v[1]; } else if (k === "H") x = v[0]; else if (k === "V") y = v[0]; pts.push([x, y]); }
          const lbl = badge.nextElementSibling; const cap = lbl && lbl.nextElementSibling;
          out[n] = { ctl: bb(ctl), pts, badge: { cx: +badge.getAttribute("cx"), cy: +badge.getAttribute("cy"), r: +badge.getAttribute("r") }, num: lbl && lbl.textContent, cap: cap && cap.textContent, capBox: cap && bb(cap), numBox: lbl && bb(lbl) };
        }
        const body = bb(svg.querySelector('rect[x="76"][y="24"]'));
        return { out, body };
      });
      const C = c.out; const fails = []; const N = Object.keys(C).map(Number);
      const onEdge = (pt, b) => pt[0] >= b.x0 - 1.5 && pt[0] <= b.x1 + 1.5 && pt[1] >= b.y0 - 1.5 && pt[1] <= b.y1 + 1.5 && (Math.abs(pt[0] - b.x0) < 1.5 || Math.abs(pt[0] - b.x1) < 1.5 || Math.abs(pt[1] - b.y0) < 1.5 || Math.abs(pt[1] - b.y1) < 1.5);
      const segHitsBox = (a, b2, bx) => { const s = 0.75; const X0 = bx.x0 + s, X1 = bx.x1 - s, Y0 = bx.y0 + s, Y1 = bx.y1 - s; if (a[1] === b2[1]) { const y = a[1]; return y > Y0 && y < Y1 && Math.max(a[0], b2[0]) > X0 && Math.min(a[0], b2[0]) < X1; } if (a[0] === b2[0]) { const x = a[0]; return x > X0 && x < X1 && Math.max(a[1], b2[1]) > Y0 && Math.min(a[1], b2[1]) < Y1; } return false; };
      const segX = (a, b2, c2, d2) => { const o = (p, q, r) => Math.sign((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])); return o(a, b2, c2) * o(a, b2, d2) < 0 && o(c2, d2, a) * o(c2, d2, b2) < 0; };
      let starts = 0, ends = 0, nums = 0, clear = 0;
      for (const n of N) {
        const L = C[n]; const st = L.pts[0], en = L.pts[L.pts.length - 1];
        if (onEdge(st, L.ctl)) starts++; else fails.push(`#${n} start ${st} not on its control`);
        const dist = Math.hypot(en[0] - L.badge.cx, en[1] - L.badge.cy); if (dist <= L.badge.r + 1.5) ends++; else fails.push(`#${n} end ${en} misses badge (${dist.toFixed(1)})`);
        if (L.num === String(n)) nums++; else fails.push(`#${n} badge reads ${L.num}`);
        let cross = []; for (let k = 0; k < L.pts.length - 1; k++) { for (const m2 of N) if (m2 !== n && segHitsBox(L.pts[k], L.pts[k + 1], C[m2].ctl)) cross.push("ctl" + m2); for (const m2 of N) if (m2 !== n) for (let q = 0; q < C[m2].pts.length - 1; q++) if (segX(L.pts[k], L.pts[k + 1], C[m2].pts[q], C[m2].pts[q + 1])) cross.push("lead" + m2); }
        if (!cross.length) clear++; else fails.push(`#${n} leader crosses ${[...new Set(cross)]}`);
      }
      ok("Fig. 1: 15/15 leaders start on their own drawn control", starts === 15, fails.filter((f) => /start/.test(f)));
      ok("Fig. 1: 15/15 leaders end in their numbered badge, badges read 1–15", ends === 15 && nums === 15, fails.filter((f) => /end|reads/.test(f)));
      ok("Fig. 1: 15/15 leaders cross no other control and no other leader", clear === 15, fails.filter((f) => /cross/.test(f)));
      // badges + captions don't overlap each other or the drawn unit
      const boxes = []; for (const n of N) { const B = C[n].badge; boxes.push({ k: "badge" + n, x0: B.cx - B.r, y0: B.cy - B.r, x1: B.cx + B.r, y1: B.cy + B.r }); if (C[n].capBox) boxes.push({ k: "cap" + n + ":" + C[n].cap, ...C[n].capBox }); }
      const bov = []; for (let i2 = 0; i2 < boxes.length; i2++) for (let j = i2 + 1; j < boxes.length; j++) { const a2 = boxes[i2], d2 = boxes[j]; const w = Math.min(a2.x1, d2.x1) - Math.max(a2.x0, d2.x0), h = Math.min(a2.y1, d2.y1) - Math.max(a2.y0, d2.y0); if (w > 0.6 && h > 0.6) bov.push(a2.k + "×" + d2.k); }
      const onBody = boxes.filter((x) => /^cap/.test(x.k) && x.x1 > c.body.x0 + 0.5 && x.x0 < c.body.x1 - 0.5 && x.y1 > c.body.y0 + 0.5 && x.y0 < c.body.y1 - 0.5).map((x) => x.k);
      ok("Fig. 1: no badge/caption overlaps another; no caption sits on the drawn unit", bov.length === 0 && onBody.length === 0, { bov, onBody });
      // the drawing matches the REAL recorder: same left/right and above/below order for every pair of controls
      const cen = (b) => [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2]; const rc = (r) => [r.x + r.w / 2, r.y + r.h / 2];
      let pairs = 0, agree = 0; const dis = [];
      // normalise both to their unit: drawing = body rect; real = recorder width x (bar top .. mode keys bottom)
      const RW = Math.max(...N.map((n) => REAL[n].x + REAL[n].w)) - Math.min(...N.map((n) => REAL[n].x)), RX = Math.min(...N.map((n) => REAL[n].x));
      const RT = REAL[1].y, RH = Math.max(...N.map((n) => REAL[n].y + REAL[n].h)) - RT;
      const FX = Math.min(...N.map((n) => C[n].ctl.x0)), FW = Math.max(...N.map((n) => C[n].ctl.x1)) - FX, FT = C[1].ctl.y0, FH = Math.max(...N.map((n) => C[n].ctl.y1)) - FT;
      const nf = (n) => [(cen(C[n].ctl)[0] - FX) / FW, (cen(C[n].ctl)[1] - FT) / FH], nr = (n) => [(rc(REAL[n])[0] - RX) / RW, (rc(REAL[n])[1] - RT) / RH];
      const posErr = N.map((n) => [n, +Math.hypot(nf(n)[0] - nr(n)[0], nf(n)[1] - nr(n)[1]).toFixed(3)]); const maxErr = Math.max(...posErr.map((x) => x[1]));
      for (const i2 of N) for (const j of N) if (i2 < j) {
        const [dx, dy] = [nf(j)[0] - nf(i2)[0], nf(j)[1] - nf(i2)[1]]; const [rx, ry] = [nr(j)[0] - nr(i2)[0], nr(j)[1] - nr(i2)[1]];
        for (const [a2, r2, ax] of [[dx, rx, "x"], [dy, ry, "y"]]) { if (Math.abs(r2) < 0.08) continue; pairs++; if (Math.sign(a2) === Math.sign(r2) && Math.abs(a2) > 0.005) agree++; else dis.push(`${i2}-${j} ${ax} fig ${a2.toFixed(2)} real ${r2.toFixed(2)}`); }
      }
      ok("Fig. 1 layout matches the real recorder (left/right + above/below for every pair ≥ 8% apart)", pairs > 100 && agree === pairs, { pairs, agree, dis: dis.slice(0, 6) });
      ok("Fig. 1 each control within 0.15 (normalised) of its real spot", maxErr <= 0.15, { maxErr, posErr });
      fs.writeFileSync(`${OUT}/fig1-callouts.json`, JSON.stringify({ C, REAL, fails, pairs, agree }, null, 1));
    }
    if (i < 8) { await tap(p, "[data-manual-next]"); await sleep(200); }
  }
  ok(`readable: smallest HTML text ${minHtml.toFixed(1)} px (≥ 9), smallest Fig. 1 callout text ${minCap.toFixed(2)} px (≥ 6.5); drawing decoration min ${minSvg.toFixed(2)} px (info)`, minHtml >= 9 && minCap >= 6.5, { minHtml, minCap, decorationMin: minSvg });
  // CLOSE toast/crop sanity: the recorder behind is fully covered below the bar (no recorder control peeks out)
  const peek = await ev(() => { const R0 = document.querySelector(".lman").getBoundingClientRect(); const pts = []; for (let y = R0.top + 4; y < R0.bottom - 2; y += 23) for (let x = 6; x < innerWidth - 4; x += 29) { const e = document.elementFromPoint(x, y); if (e && !e.closest(".lman")) pts.push([x, y, e.className]); } return pts.slice(0, 5); });
  ok("book covers the recorder below the bar (no control peeks through)", peek.length === 0, peek);
  ok("0 JS errors", errs.length === 0, errs.join("; "));
  fs.writeFileSync(`${OUT}/layout.json`, JSON.stringify({ R, sum }, null, 1));
  console.table(sum);
  console.log(`layout ${VP.join("x")}: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
