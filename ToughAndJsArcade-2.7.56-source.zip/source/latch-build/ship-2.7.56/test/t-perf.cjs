// A03s profile (low-end throttle): 360x800 @ DPR 2 (A03s screen), CPU throttled 6x. Frame gaps while turning pages
// by real touch swipes and taps; first (cold) pass and second (warm) pass. Headless Chrome, not a phone.
const { open, tap, sleep, fs, LATCH, touchSwipe, touchTap, man, pagesBox } = require("./lib2756.cjs");
const RATE = +(process.argv[2] || 6); const OUT = process.argv[3] || "out/perf-a03s"; fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--allow-file-access-from-files"] });
  const { p, errs } = await open(LATCH, [360, 800], { browser: b });
  await p.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const s = await p.target().createCDPSession(); await s.send("Emulation.setCPUThrottlingRate", { rate: RATE });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d: JSON.stringify(d) }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d)); };
  // load a clip so the recorder is busy underneath, like real use
  const { A } = require("/workspace/game/build-latch/test/lib.cjs");
  const [inp] = await p.$$("main.vtr input[type=file]"); await inp.uploadFile(A("clip.mp4")); await sleep(3500);
  if (await p.evaluate(() => !!document.querySelector(".hint"))) await tap(p, ".hint button");
  const t0 = Date.now(); await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-manual-open]");
  await p.waitForSelector(".lman"); const openMs = Date.now() - t0;
  const startRec = () => p.evaluate(() => { window.__fr = []; let last = performance.now(); window.__run = true; const f = (t) => { window.__fr.push(t - last); last = t; if (window.__run) requestAnimationFrame(f); }; requestAnimationFrame(f); window.__turns = []; window.__mo && window.__mo.disconnect(); window.__mo = new MutationObserver(() => { const pg = document.querySelector(".lman")?.dataset.page; const t = performance.now(); requestAnimationFrame(() => requestAnimationFrame(() => window.__turns.push({ pg, paintMs: performance.now() - t }))); }); window.__mo.observe(document.querySelector(".lman"), { attributes: true, attributeFilter: ["data-page"] }); });
  const stopRec = () => p.evaluate(() => { window.__run = false; return { fr: window.__fr.slice(2), turns: window.__turns }; });
  const stats = (a) => { const x = a.slice().sort((m, n) => m - n); const q = (k) => x[Math.min(x.length - 1, Math.floor(k * x.length))]; return { frames: x.length, p50: +q(0.5).toFixed(1), p95: +q(0.95).toFixed(1), max: +x[x.length - 1].toFixed(1), over50: x.filter((v) => v > 50).length, over100: x.filter((v) => v > 100).length }; };
  const res = {};
  for (const pass of ["cold", "warm"]) {
    await startRec(); const bx = await pagesBox(p); const y = bx.y + bx.h * 0.5;
    let landed = 0; const seq = [];
    for (let i = 0; i < 8; i++) { await touchSwipe(p, bx.x + bx.w * 0.85, y, bx.x + bx.w * 0.15, y, 10); await sleep(250); { const q = await man(p); seq.push(q.page); if (q.page === i + 2) landed++; } }
    for (let i = 0; i < 8; i++) { await touchTap(p, "[data-manual-prev]"); await sleep(250); { const q = await man(p); seq.push(q.page); if (q.page === 8 - i) landed++; } }
    await sleep(200); const r = await stopRec(); const pg = await man(p);
    res[pass] = { ...stats(r.fr), turns: landed, seq, measuredTurns: r.turns.length, paintP95: +stats(r.turns.map((t) => t.paintMs)).p95, paintMax: +Math.max(...r.turns.map((t) => t.paintMs)).toFixed(1), endPage: pg.page };
  }
  await p.screenshot({ path: `${OUT}/a03s-p1.png` });
  console.log(JSON.stringify({ rate: RATE, openMs, ...res }, null, 1));
  for (const k of ["cold", "warm"]) {
    const r = res[k];
    ok(`${k}: 16 page turns all landed (8 swipes + 8 taps)`, r.turns === 16 && r.endPage === 1, { turns: r.turns, seq: r.seq });
    ok(`${k}: frame gap p95 ≤ 34 ms (≥ 30 fps) while turning`, r.p95 <= 34, { p50: r.p50, p95: r.p95 });
    ok(`${k}: no big drops — 0 frames > 100 ms, ≤ 3 frames > 50 ms`, r.over100 === 0 && r.over50 <= 3, { over50: r.over50, over100: r.over100, max: r.max });
    ok(`${k}: turn → painted p95 ≤ 120 ms`, r.paintP95 <= 120, { paintP95: r.paintP95, paintMax: r.paintMax });
  }
  ok("open from menu ≤ 1500 ms at 6x throttle", openMs <= 1500, { openMs });
  ok("0 JS errors", errs.length === 0, errs);
  fs.writeFileSync(`${OUT}/perf.json`, JSON.stringify({ rate: RATE, viewport: "360x800@2x", openMs, res, R }, null, 1));
  console.log(`perf: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
