// APK save path (headless): a fake TJApp bridge like the APK's; SAVE › GIF / Still / comic PNG must write
// through beginSave/saveChunk/endSaveChecked with the exact byte count, and never fall back to a download link.
const { open, tap, sleep, fs, LATCH } = require("./lib2756.cjs");
(async () => {
  const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--allow-file-access-from-files"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d).slice(0, 300)); };
  const { p, errs } = await open(LATCH, [360, 800], { browser: b });
  await p.evaluateOnNewDocument(() => {
    window.__saves = []; let cur = null;
    window.TJApp = { beginSave(n, m) { if (cur) return false; cur = { n, m, b64: [], bytes: 0 }; return true; }, saveChunk(s) { if (!cur) return false; cur.b64.push(s); cur.bytes += atob(s).length; return true; },
      endSave() { if (!cur) return "fail"; __saves.push({ ...cur, how: "endSave" }); cur = null; return "ok"; },
      endSaveChecked(e) { if (!cur) return "bad"; const good = String(cur.bytes) === e; __saves.push({ ...cur, how: "checked", expected: e, good }); cur = null; return good ? "ok" : "bad"; } };
    window.__anchorClicks = 0; const o = HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click = function () { if (this.download) window.__anchorClicks++; return o.call(this); };
  });
  await p.reload(); await sleep(900);
  if (await p.evaluate(() => !!document.querySelector(".hint"))) await tap(p, ".hint button");
  await tap(p, "[data-sample]"); await sleep(1500);
  const mk = (t) => p.evaluate((t) => { const k = [...document.querySelectorAll(".mk")].find((e) => e.textContent.includes(t)); k.click(); }, t);
  await mk("SAVE"); await sleep(400);
  await tap(p, "[data-save-gif]"); for (let i = 0; i < 60 && (await p.evaluate(() => __saves.length)) < 1; i++) await sleep(500);
  await tap(p, "[data-save-still]"); for (let i = 0; i < 60 && (await p.evaluate(() => __saves.length)) < 2; i++) await sleep(500);
  const s = await p.evaluate(() => __saves.map((x) => { const bin = x.b64.map(atob).join(""); return { n: x.n, m: x.m, bytes: x.bytes, how: x.how, good: x.good, expected: x.expected, magic: bin.slice(0, 6).replace(/[^\x20-\x7e]/g, "."), frames: (bin.match(/\x21\xF9\x04/g) || []).length }; }));
  const gif = s.find((x) => /\.gif$/.test(x.n)), png = s.find((x) => /\.png$/.test(x.n));
  ok("GIF goes through the app bridge, byte count checked, valid animated GIF", gif && gif.how === "checked" && gif.good && /^GIF8/.test(gif.magic) && gif.frames > 1 && gif.m === "image/gif", gif);
  ok("Still PNG goes through the app bridge, byte count checked", png && png.how === "checked" && png.good && /PNG/.test(png.magic), png);
  ok("no download-link fallback used when the bridge exists (no double save)", (await p.evaluate(() => __anchorClicks)) === 0 && s.length === 2, { anchorClicks: await p.evaluate(() => __anchorClicks), saves: s.length });
  ok("0 JS errors", errs.length === 0, errs);
  console.log(`bridge: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
