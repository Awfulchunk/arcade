// Real loaded-clip flow at 360x800: every tool does its job, saves decode.
const { open, tap, tip, sleep, A, fs } = require("/workspace/game/build-latch/test/lib.cjs");
const VP = (process.argv[2] || "360x800").split("x").map(Number);
const URL_ = process.argv[3] || "file:///workspace/game/build-latch/ship2756/test/latch-2.1-from-apk.html";
const dir = `/workspace/game/build-latch/ship2756/test/out/reg-flow-${VP[0]}x${VP[1]}`; fs.mkdirSync(dir, { recursive: true });
const MARK = /const MARK = "([^"]+)"/.exec(fs.readFileSync("/workspace/game/build-apps/src-latch/src/lib/bench/model.ts", "utf8"))[1];
(async () => {
  const { b, p, errs } = await open(URL_, VP);
  const R = []; let n = 0;
  const ok = (name, pass, detail = "") => { R.push({ name, pass: !!pass, detail }); console.log(pass ? "PASS" : "FAIL", name, detail); };
  const shot = (name) => p.screenshot({ path: `${dir}/${String(++n).padStart(2, "0")}-${name}.png` });
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const has = (sel) => ev((s) => [...document.querySelectorAll(s)].some((e) => e.getClientRects().length && getComputedStyle(e).visibility !== "hidden"), sel);
  const txt = (sel) => ev((s) => [...document.querySelectorAll(s)].filter((e) => e.getClientRects().length).map((e) => e.textContent.trim()).join(" | "), sel);
  const led = (t) => ev((t) => !!document.querySelector(`[data-tool=${t}] .led.on`), t);
  const done = () => tap(p, "[data-done]");
  const inputs = async () => p.$$("main.vtr input[type=file]");
  const waitDl = async (pred, ms = 90000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const d = await ev(() => window.__dl.map((x) => ({ name: x.name, type: x.type, size: x.size }))); const i = d.findIndex(pred); if (i >= 0) return ev((i) => window.__dl[i], i); await sleep(500); } return null; };
  const saveDl = (d, f) => { fs.writeFileSync(`${dir}/${f}`, Buffer.from(d.data, "base64")); return `${dir}/${f}`; };
  const step = async (name, fn) => { try { await fn(); } catch (e) { ok(name, false, "threw " + e.message); } };

  await ev(() => localStorage.clear()); await p.reload(); await sleep(700);
  // load a real video
  await step("load mp4", async () => {
    const [main] = await inputs(); await main.uploadFile(A("clip.mp4")); await sleep(2500);
    ok("load mp4", await has("video, canvas.pic"), await txt(".osd.otr"));
  });
  await step("first-run hint", async () => {
    ok("first-run hint shows", await has(".hint")); await shot("hint");
    await tap(p, ".hint button"); ok("hint dismiss + remembered", !(await has(".hint")) && (await ev(() => localStorage.getItem("lt.holdtip"))) != null);
  });
  await step("play", async () => {
    const t0 = await txt(".lcd"); await sleep(800); const t1 = await txt(".lcd");
    ok("playing advances LCD", t0 !== t1, `${t0} -> ${t1}`);
    const paused0 = await ev(() => document.querySelector("video").paused);
    await tap(p, ".play"); const paused1 = await ev(() => document.querySelector("video").paused);
    ok("play key toggles playback", paused0 !== paused1, `paused ${paused0} -> ${paused1}`);
    if (paused1) { const a = await txt(".lcd"); await sleep(600); ok("paused LCD holds", a === (await txt(".lcd")), a); }
    await tap(p, ".play");
  });
  await step("trim", async () => {
    await tap(p, "[data-tool=trim]"); await shot("trim");
    const before = await txt(".drawer .read");
    await tap(p, `.drawer ${tip("Out")}`); await tap(p, `.drawer [data-tip^="−10|"]`); await tap(p, `.drawer [data-tip^="−10|"]`);
    const after = await txt(".drawer .read");
    ok("trim: out nudged -20 frames", before !== after, `${before} -> ${after}`);
    // drag the IN handle on the filmstrip
    const h = await ev(() => { const r = document.querySelector(".hand").getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
    await p.mouse.move(h.x, h.y); await p.mouse.down(); for (let i = 1; i <= 8; i++) { await p.mouse.move(h.x + i * 8, h.y); await sleep(20); } await p.mouse.up(); await sleep(300);
    const dragged = await txt(".drawer .read");
    ok("trim: IN handle drag moves in point", dragged !== after, dragged);
    await done(); ok("trim LED on", await led("trim"));
  });
  await step("bounce", async () => {
    await tap(p, "[data-tool=bounce]"); await tap(p, `.drawer ${tip("Bounce")}`); await shot("bounce");
    await done(); ok("bounce on (LED)", await led("bounce"));
  });
  await step("join", async () => {
    await tap(p, "[data-tool=scenes]"); await tap(p, `.drawer ${tip("Keep scene")}`);
    const [, , join] = await inputs(); await join.uploadFile(A("clip2.mp4")); await sleep(2500);
    const cnt = await ev(() => document.querySelectorAll(".drawer .scene").length); await shot("join");
    ok("join: kept scene + added clip", cnt >= 2, `scenes=${cnt}`);
    await done(); ok("join LED on", await led("scenes"));
  });
  await step("crop", async () => {
    await tap(p, ".mk", "LOOK"); await tap(p, "[data-tool=crop]");
    const before = await txt(".osd.otr"); await tap(p, '[data-ratio="1:1"]'); await sleep(300); const after = await txt(".osd.otr"); await shot("crop");
    ok("crop 1:1 changes output size", before !== after && /1:1/.test(after), `${before} -> ${after}`);
    await tap(p, `.drawer ${tip("Turn")}`); await tap(p, `.drawer ${tip("Turn")}`); await tap(p, `.drawer ${tip("Turn")}`); await tap(p, `.drawer ${tip("Turn")}`);
    await done(); ok("crop LED on", await led("crop"));
  });
  await step("grade + undo", async () => {
    await tap(p, "[data-tool=grade]");
    let thumbs = 0; for (let i = 0; i < 40 && thumbs < 3; i++) { await sleep(250); thumbs = await ev(() => [...document.querySelectorAll("[data-pre] img")].filter((i) => i.src.startsWith("data:")).length); }
    ok("grade: live preset thumbnails", thumbs >= 3, `thumbs=${thumbs}`);
    const onBefore = await ev(() => document.querySelector("[data-pre].on")?.getAttribute("data-pre") || "");
    await tap(p, "[data-pre]:nth-child(3)"); const on1 = await ev(() => document.querySelector("[data-pre].on")?.getAttribute("data-pre") || "");
    ok("grade preset applies", on1 && on1 !== onBefore, `${onBefore} -> ${on1}`);
    await tap(p, ".bar [aria-label=Undo]"); const on2 = await ev(() => document.querySelector("[data-pre].on")?.getAttribute("data-pre") || "");
    ok("undo restores previous look", on2 === onBefore, `after undo: ${on2}`);
    await tap(p, "[data-pre]:nth-child(3)");
    await tap(p, "[data-adj=warm], [data-adj]:nth-child(5)"); const lbl = await txt(".drawer .fd label");
    ok("grade: adjustment chip picks fader", !!lbl, lbl);
    const vf = await ev(() => Math.round(document.querySelector(".vf").getBoundingClientRect().height));
    await shot("grade"); await done(); ok("grade LED on", await led("grade"), `vf=${vf}px`);
  });
  await step("stickers", async () => {
    await tap(p, ".mk", "ADD"); await tap(p, "[data-tool=lay]");
    const [, st] = await inputs(); await st.uploadFile(A("sticker.png")); await sleep(1200);
    await tap(p, `.drawer ${tip("Text")}`, "Text"); await sleep(300);
    const placed = await ev(() => [...document.querySelectorAll('.drawer [aria-label="Placed"] button')].length); await shot("stickers");
    ok("stickers: sticker + text placed", placed >= 2, `placed=${placed}`);
    await done(); ok("stickers LED on", await led("lay"));
  });
  await step("end result", async () => {
    await tap(p, "[data-tool=end]"); ok("end result pip shows", await has(".pip")); await shot("end");
  });
  await step("save gif", async () => {
    await tap(p, ".mk", "SAVE"); await shot("save");
    await tap(p, "[data-save-gif]"); await sleep(800); await shot("saving");
    const d = await waitDl((x) => /\.gif$/.test(x.name));
    ok("GIF saved", !!d, d ? `${d.name} ${d.size}B` : "no download");
    if (d) R.gif = saveDl(d, "saved.gif");
    await tap(p, "[data-save-still]"); const s = await waitDl((x) => /\.png$/.test(x.name), 20000);
    ok("still PNG saved", !!s, s ? `${s.name} ${s.size}B` : ""); if (s) R.png = saveDl(s, "saved-still.png");
    if (await has("[data-save-join]")) { await tap(p, "[data-save-join]"); const j = await waitDl((x) => /\.gif$/.test(x.name) && x.name !== d?.name || (window, false), 1); }
  });
  await step("save joined gif", async () => {
    const n0 = await ev(() => window.__dl.length);
    if (!(await has("[data-save-join]"))) { await done().catch(() => {}); await tap(p, ".mk", "CUT"); await tap(p, "[data-tool=scenes]"); }
    await tap(p, "[data-save-join]");
    let j = null; const t0 = Date.now(); while (Date.now() - t0 < 120000) { const l = await ev(() => window.__dl.length); if (l > n0 + 0) { const all = await ev(() => window.__dl.map((x) => x.name)); if (all.slice(n0).some((x) => /\.gif$/.test(x))) { j = await ev((n0) => window.__dl.slice(n0).find((x) => /\.gif$/.test(x.name)), n0); break; } } await sleep(500); }
    ok("joined GIF saved", !!j, j ? `${j.name} ${j.size}B` : ""); if (j) R.join = saveDl(j, "saved-join.gif");
    await done().catch(() => {});
  });
  await step("lock / assist", async () => {
    await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-lock]"); await sleep(200);
    ok("unlock form opens", await has(".lockform input"));
    await p.keyboard.type(MARK); await p.keyboard.press("Enter"); await sleep(400);
    await tap(p, ".mk", "LOOK"); ok("assist tile appears after unlock", await has("[data-tool=assist]"));
    await tap(p, "[data-tool=assist]"); await tap(p, `.drawer ${tip("Apply")}`); const note = await txt("[data-note]"); await shot("assist");
    ok("assist applies", /assist/i.test(note), note);
    await done();
    await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-lock]"); await sleep(300);
    ok("lock hides assist", !(await has("[data-tool=assist]")));
  });
  await step("guide", async () => {
    await tap(p, '.bar [aria-label=Guide]'); const marks = await ev(() => document.querySelectorAll(".gm").length);
    ok("guide markers shown", marks >= 5, `markers=${marks}`);
    const tag0 = await txt(".drawer .dh .tag"); await tap(p, ".mk", "SAVE"); const tag1 = await txt(".drawer .dh .tag");
    ok("guide: tap explains, does not act", (await has(".balloon")) && tag0 === tag1, tag1);
    const lv = await ev(() => { const l = document.querySelector(".legend").getBoundingClientRect(), v = document.querySelector(".vf").getBoundingClientRect(); return l.top >= v.bottom - 1; });
    ok("guide legend clear of preview", lv); await shot("guide");
    await tap(p, ".legend .lh button"); ok("guide closes", !(await has(".legend")));
  });
  await step("hold tip", async () => {
    const tag0 = await txt(".drawer .dh .tag"); await tap(p, ".mk", "CUT", 750);
    const bal = await txt(".balloon"); const tag1 = await txt(".drawer .dh .tag"); await shot("holdtip");
    ok("hold shows tip and swallows tap", !!bal && tag0 === tag1, bal.slice(0, 50));
    await sleep(300); await tap(p, ".mk", "CUT"); ok("normal tap still acts", /CUT/.test(await txt(".drawer .dh .tag")));
  });
  await step("comic", async () => {
    await tap(p, ".sw button", "PAGE"); await sleep(300);
    const inp = await p.$("main.vtr input[accept='image/*'][multiple]"); await inp.uploadFile(A("pic1.jpg"), A("pic2.jpg"), A("pic3.jpg")); await sleep(1500);
    ok("comic: 3 pictures in", (await ev(() => document.querySelectorAll(".slots .s").length)) === 3);
    if (!(await has("[data-done]")) || !/ORDER/.test(await txt(".drawer .dh .tag"))) { if (await has("[data-done]")) await done(); await tap(p, "[data-tool=order]"); }
    const src0 = await ev(() => [...document.querySelectorAll(".slots .s img")].map((i) => i.src.slice(-12)).join());
    await tap(p, ".slots .s:nth-child(3)"); await tap(p, ".slots .s:nth-child(3)"); await tap(p, ".slots .s:nth-child(3)");
    const src1 = await ev(() => [...document.querySelectorAll(".slots .s img")].map((i) => i.src.slice(-12)).join());
    ok("comic: order taps reorder", src0 !== src1);
    await done(); await tap(p, "[data-tool=bubbles]"); await tap(p, ".slots .s");
    await tap(p, ".drawer [data-bub=shout]"); await tap(p, ".drawer .txt"); await p.keyboard.type("Latch it!"); await tap(p, `.drawer ${tip("Add bubble")}`);
    ok("comic: bubble added", (await ev(() => [...document.querySelectorAll('.drawer [aria-label="Bubbles"] button')].length)) >= 1);
    await tap(p, '.drawer [aria-label="Nudge right"]'); await shot("comic-bubble");
    await done(); await tap(p, "[data-tool=format]"); await tap(p, "[data-fmt=manga]"); await shot("comic-manga"); await done();
    const n0 = await ev(() => window.__dl.length); await tap(p, ".mk", "SAVE");
    let d = null; for (let i = 0; i < 40 && !d; i++) { await sleep(500); d = await ev((n0) => window.__dl.slice(n0).find((x) => /\.png$/.test(x.name)) || null, n0); }
    ok("comic page PNG saved", !!d, d ? `${d.name} ${d.size}B` : ""); if (d) R.comic = saveDl(d, "saved-comic.png");
    await tap(p, ".sw button", "CLIP");
  });
  await step("still image + reload", async () => {
    const [main] = await inputs(); await main.uploadFile(A("pic1.jpg")); await sleep(1500);
    ok("still opens on LOOK", /LOOK/.test(await txt(".drawer .dh .tag")), await txt(".drawer .dh .tag"));
    await p.reload(); await sleep(700); await tap(p, "[data-sample]"); await sleep(1200);
    ok("hint not shown again", !(await has(".hint")));
    ok("sample clip loads", /sample/i.test(await txt(".osd")), await txt(".osd.obl"));
  });
  ok("0 JS errors", errs.length === 0, errs.join(" ; "));
  fs.writeFileSync(`${dir}/flow.json`, JSON.stringify({ results: R, files: { gif: R.gif, png: R.png, join: R.join, comic: R.comic }, jsErrors: errs }, null, 1));
  console.log(`flow ${VP.join("x")}: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close();
})();
