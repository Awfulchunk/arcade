// Every screen and tool at one viewport: 0 JS errors, no page scroll, tap targets >= 44px.
const { open, tap, tip, audit, sleep, A, fs } = require("/workspace/game/build-latch/test/lib.cjs");
const [W, H] = process.argv[2].split("x").map(Number);
const URL_ = process.argv[3] || "file:///workspace/game/build-latch/ship2756/test/latch-2.1-from-apk.html";
const dir = `/workspace/game/build-latch/ship2756/test/out/reg-screens-${W}x${H}`; fs.mkdirSync(dir, { recursive: true });
const MARK = /const MARK = "([^"]+)"/.exec(fs.readFileSync("/workspace/game/build-apps/src-latch/src/lib/bench/model.ts", "utf8"))[1];
(async () => {
  const { b, p, errs } = await open(URL_, [W, H]);
  const R = [];
  const step = async (name, fn) => { try { if (fn) await fn(); R.push(await audit(p, name, dir)); } catch (e) { R.push({ name, fail: String(e.message || e) }); } };
  const done = () => tap(p, "[data-done]");
  const closeSheet = () => tap(p, ".sheet .done");
  await step("01-empty");
  await step("02-empty-guide", () => tap(p, '[aria-label*="uide"]'));
  await step("02b-empty-guide-explain", () => tap(p, tip("Insert a clip")));
  await tap(p, ".legend .lh button");
  await step("03-menu", () => tap(p, '.bar [aria-label=Menu]'));
  // 2.1: MENU › MANUAL is now the paper book (9 pages); audit every page, then close it with its own CLOSE key
  await step("04-manual", () => tap(p, tip("Manual")));
  for (let i = 2; i <= 9; i++) await step(`04-manual-p${i}`, () => tap(p, "[data-manual-next]"));
  await tap(p, "[data-manual-close]");
  await step("05-loaded-hint", () => tap(p, "[data-sample]").then(() => sleep(1500)));
  await step("06-cut-tiles", () => tap(p, ".hint button"));
  for (const t of ["trim", "bounce", "scenes"]) { await step(`07-cut-${t}`, () => tap(p, `[data-tool=${t}]`)); await done(); }
  await step("08-look-tiles", () => tap(p, ".mk", "LOOK"));
  for (const t of ["crop", "grade"]) { await step(`09-look-${t}`, () => tap(p, `[data-tool=${t}]`)); if (t === "grade") await step("09-look-grade-more", () => p.evaluate(() => { const d = document.querySelector(".dbody"); d && (d.scrollTop = d.scrollHeight); })); await done(); }
  await step("10-add-tiles", () => tap(p, ".mk", "ADD"));
  await step("11-add-lay", () => tap(p, "[data-tool=lay]"));
  await step("11b-lay-text", () => tap(p, tip("Text"), "Text"));
  await done();
  await step("12-add-end", () => tap(p, "[data-tool=end]"));
  await tap(p, "[data-tool=end]");
  await step("13-save", () => tap(p, ".mk", "SAVE"));
  await done();
  await step("14-lockform", async () => { await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-lock]"); });
  await p.keyboard.type(MARK); await p.keyboard.press("Enter"); await sleep(300);
  await step("15-assist", async () => { await tap(p, ".mk", "LOOK"); await tap(p, "[data-tool=assist]"); });
  await done();
  await step("16-guide-grade", async () => { await tap(p, "[data-tool=grade]"); await tap(p, '[aria-label*="uide"]'); });
  await step("16b-guide-explain", () => tap(p, ".mk", "SAVE"));
  await tap(p, ".legend .lh button"); await done();
  await step("17-hold-tip", () => tap(p, ".mk", "SAVE", 750));
  await step("18-comic-empty", () => tap(p, ".sw button", "PAGE"));
  await step("19-comic-loaded", async () => { const inp = await p.$("main.vtr input[accept='image/*'][multiple]"); await inp.uploadFile(A("pic1.jpg"), A("pic2.jpg"), A("pic3.jpg")); await sleep(1500); });
  for (const t of ["format", "bubbles", "order"]) { await step(`20-comic-${t}`, async () => { if (await p.$("[data-done]")) await done().catch(() => {}); await tap(p, `[data-tool=${t}]`); if (t === "bubbles") await tap(p, ".slots .s"); }); await done(); }
  await step("21-comic-menu", () => tap(p, ".bar [aria-label=Menu]"));
  await closeSheet();
  await step("22-comic-guide", () => tap(p, '[aria-label*="uide"]'));
  await tap(p, ".legend .lh button");
  await step("23-back-clip", () => tap(p, ".sw button", "CLIP"));
  const bad = R.filter((r) => r.fail || !r.noPageScroll || r.small.length || r.offscreen.length || r.legOverVf || r.qmarks);
  const out = { viewport: `${W}x${H}`, url: URL_, screens: R.length, failing: bad.length, jsErrors: errs, results: R };
  fs.writeFileSync(`${dir}/screens.json`, JSON.stringify(out, null, 1));
  console.log(`${W}x${H}: screens ${R.length}, failing ${bad.length}, jsErrors ${errs.length}`);
  for (const r of bad) console.log(" -", r.name, r.fail || "", r.noPageScroll === false ? "SCROLL " + JSON.stringify(r.scroll) : "", r.small?.length ? "SMALL " + r.small.join("; ") : "", r.offscreen?.length ? "OFF " + r.offscreen.join(",") : "", r.legOverVf ? "LEGEND-OVER-VF" : "");
  for (const e of errs) console.log(" ERR", e);
  console.log("grade vfH/picH:", R.filter((r) => /grade/.test(r.name)).map((r) => `${r.name}:${r.vfH}/${r.picH}`).join(" "));
  await b.close();
})();
