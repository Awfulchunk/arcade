// Latch 2.0 fixes: (A) GIF opens animated with ImageDecoder removed (JS decoder path), bounces + saves;
// (B) bounce on a long-keyframe clip (one keyframe, 8s, 720x1280): frames shown per second + longest stall; (C) Grade thumbs time.
const { open, tap, tip, sleep, A, fs } = require("/workspace/game/build-latch/test/lib.cjs");
const URL_ = process.argv[2] || "file:///workspace/game/build-latch/ship2756/test/latch-2.1-from-apk.html";
const dir = process.argv[3] || "gifbounce"; fs.mkdirSync(dir, { recursive: true });
const NOID = process.argv[4] !== "keepdecoder";
(async () => {
  const R = []; const ok = (name, pass, detail = "") => { R.push({ name, pass: !!pass, detail }); console.log(pass ? "PASS" : "FAIL", name, detail); };
  const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
  const browser = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required", "--allow-file-access-from-files"] });
  const run = async (fn) => { const { p, errs } = await open("about:blank", [360, 800], { browser }); if (NOID) await p.evaluateOnNewDocument(() => { delete window.ImageDecoder; }); await p.goto(URL_); await sleep(800); await p.evaluate(() => localStorage.setItem("lt.holdtip", "1")); await p.reload(); await sleep(800); await fn(p); return errs; };
  const hash = (p) => p.evaluate(() => { const c = [...document.querySelectorAll(".vf canvas")].find((e) => e.width > 10); if (!c) return "none"; const s = document.createElement("canvas"); s.width = 24; s.height = 24; const x = s.getContext("2d"); x.drawImage(c, 0, 0, 24, 24); const d = x.getImageData(0, 0, 24, 24).data; let h = 0; for (let i = 0; i < d.length; i += 3) h = (h * 31 + d[i]) >>> 0; return String(h); });
  const watch = async (p, ms) => { const seen = []; const t0 = Date.now(); let last = null, lastChange = Date.now(), stall = 0, changes = 0; while (Date.now() - t0 < ms) { const h = await hash(p); if (h !== last) { if (last !== null) { changes++; stall = Math.max(stall, Date.now() - lastChange); } lastChange = Date.now(); last = h; } seen.push(h); await sleep(15); } stall = Math.max(stall, Date.now() - lastChange); return { changesPerSec: +(changes / (ms / 1000)).toFixed(1), distinct: new Set(seen).size, longestStallMs: stall }; };
  // A) GIF
  const errsA = await run(async (p) => {
    ok("A: ImageDecoder removed (JS decoder path)", NOID ? await p.evaluate(() => typeof window.ImageDecoder === "undefined") : true, NOID ? "" : "kept");
    const [inp] = await p.$$("main.vtr input[type=file]"); await inp.uploadFile(A("anim.gif")); await sleep(2500);
    const kind = await p.evaluate(() => document.querySelector(".osd.otr")?.textContent || "");
    const w = await watch(p, 2000); await p.screenshot({ path: `${dir}/A-gif-open.png` });
    ok("A: GIF animates on open", w.distinct >= 8, JSON.stringify(w) + " " + kind);
    await tap(p, "[data-tool=bounce]"); await tap(p, `.drawer ${tip("Bounce")}`); await tap(p, "[data-done]");
    const wb = await watch(p, 2000); ok("A: GIF bounce plays", wb.distinct >= 8, JSON.stringify(wb));
    await tap(p, ".mk", "SAVE"); await sleep(300); await tap(p, "[data-tool=save]").catch(() => {});
    await sleep(400); await tap(p, "[data-save-gif]");
    let d = null; for (let i = 0; i < 120 && !d; i++) { await sleep(500); d = await p.evaluate(() => window.__dl.find((x) => /\.gif$/.test(x.name)) || null); }
    if (d) fs.writeFileSync(`${dir}/A-saved-from-gif.gif`, Buffer.from(d.data, "base64"));
    ok("A: GIF re-saved as GIF", !!d, d ? `${d.name} ${d.size}B` : "no download");
  });
  // B) long-keyframe bounce
  const errsB = await run(async (p) => {
    const [inp] = await p.$$("main.vtr input[type=file]"); await inp.uploadFile(A("clip-longgop.mp4")); await sleep(3000);
    await tap(p, "[data-tool=bounce]"); await tap(p, `.drawer ${tip("Bounce")}`); await tap(p, "[data-done]");
    await sleep(500); const early = await watch(p, 1500);
    await sleep(4500); // let the frame cache fill (8s cut at 2x)
    const w = await watch(p, 4000); await p.screenshot({ path: `${dir}/B-bounce-longgop.png` });
    const cache = await p.evaluate(() => !!document.querySelector("video"));
    ok("B: long-keyframe bounce smooth (>=15 changes/s, no stall > 250ms)", w.changesPerSec >= 15 && w.longestStallMs <= 250, `first 1.5s ${JSON.stringify(early)} | after cache ${JSON.stringify(w)}`);
    // C) grade thumbs while bouncing
    await tap(p, ".mk", "LOOK"); const t0 = Date.now(); await tap(p, "[data-tool=grade]");
    let th = 0; while (Date.now() - t0 < 10000 && th < 3) { th = await p.evaluate(() => [...document.querySelectorAll("[data-pre] img")].filter((i) => i.src.startsWith("data:")).length); if (th < 3) await sleep(50); }
    ok("C: Grade thumbs while bouncing", th >= 3, `${th} thumbs in ${Date.now() - t0}ms (incl. tap ~300ms)`); await p.screenshot({ path: `${dir}/C-grade-thumbs.png` });
  });
  const errs = [...errsA, ...errsB].filter((e) => !/favicon/.test(e));
  ok("0 JS errors", errs.length === 0, errs.slice(0, 3).join(" | "));
  fs.writeFileSync(`${dir}/gifbounce.json`, JSON.stringify({ url: URL_, noImageDecoder: NOID, results: R, errs }, null, 1));
  console.log(`${R.filter((r) => r.pass).length}/${R.length} passed`); await browser.close(); process.exit(0);
})().catch((e) => { console.error("ERR", e.message); process.exit(1); });
