// PASS 1 — headless functional: open from MENU, all 9 pages by swipe (mouse + touch) and by tap, counter, Contents jumps,
// close/Esc restores the exact recorder state, playback pause/resume, 50x open/close spam with no leaks, 0 JS errors.
const { open, tap, tip, sleep, A, fs, LATCH, mouseSwipe, touchSwipe, touchTap, man, pagesBox, NAMES } = require("./lib2756.cjs");
const VP = (process.argv[2] || "360x800").split("x").map(Number);
const OUT = process.argv[3] || `out/func-${VP[0]}x${VP[1]}`; fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const { b, p, errs } = await open(LATCH, VP);
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d: typeof d === "string" ? d : JSON.stringify(d) }); console.log(v ? "PASS" : "FAIL", n, typeof d === "string" ? d : JSON.stringify(d).slice(0, 300)); };
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const step = async (n, fn) => { try { await fn(); } catch (e) { ok(n, false, "threw " + e.message); } };
  await ev(() => localStorage.clear()); await p.reload(); await sleep(700);
  // ---- a real clip with real edits, so there is state to keep ----
  const [inp] = await p.$$("main.vtr input[type=file]"); await inp.uploadFile(A("clip.mp4")); await sleep(2500);
  if (await ev(() => !!document.querySelector(".hint"))) await tap(p, ".hint button");
  await tap(p, "[data-tool=trim]"); await tap(p, `.drawer ${tip("Out")}`); await tap(p, `.drawer [data-tip^="−10|"]`); await tap(p, "[data-done]");
  await tap(p, ".mk", "LOOK"); await tap(p, "[data-tool=crop]"); await tap(p, '[data-ratio="1:1"]'); await tap(p, "[data-done]");
  await tap(p, "[data-tool=grade]"); await sleep(800); await tap(p, "[data-pre]:nth-child(3)"); await tap(p, "[data-done]");
  const SNAP = () => ev(() => {
    const v = document.querySelector("video"); const main = document.querySelector("main.vtr");
    const cv = document.querySelector("canvas.pic"); let px = ""; try { const s = document.createElement("canvas"); s.width = 32; s.height = 32; s.getContext("2d").drawImage(cv, 0, 0, 32, 32); const d = s.getContext("2d").getImageData(0, 0, 32, 32).data; let h = 0; for (let i = 0; i < d.length; i++) h = (h * 31 + d[i]) >>> 0; px = String(h); } catch (e) { px = "err"; }
    const clone = main.cloneNode(true); clone.querySelectorAll(".lman,.lman-shield").forEach((e) => e.remove());
    return { html: clone.innerHTML, len: clone.innerHTML.length, t: v.currentTime, paused: v.paused, muted: v.muted, rate: v.playbackRate, src: v.src.slice(0, 40), px, leds: [...document.querySelectorAll("[data-tool] .led.on")].map((e) => e.closest("[data-tool]").dataset.tool), otr: document.querySelector(".osd.otr").textContent, undo: !document.querySelector(".bar [aria-label=Undo]").disabled, ls: JSON.stringify(localStorage) };
  });
  const openMan = async () => { await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-manual-open]"); await sleep(250); };
  const closeMan = async () => { await tap(p, "[data-manual-close]"); await sleep(250); };

  // ---- A: paused state: open/close must leave the recorder byte-identical ----
  await step("paused restore", async () => {
    // settle: play, then pause mid-cut, and wait until two snapshots 800 ms apart agree
    if (await ev(() => document.querySelector("video").paused)) await tap(p, ".play"); await sleep(500);
    if (!(await ev(() => document.querySelector("video").paused))) await tap(p, ".play");
    let s0 = await SNAP(); for (let i = 0; i < 10; i++) { await sleep(800); const s = await SNAP(); if (s.html === s0.html && s.t === s0.t && s.px === s0.px) break; s0 = s; }
    ok("recorder settled + paused before opening", s0.paused, { t: s0.t });
    await openMan(); const m = await man(p);
    ok("MENU › MANUAL opens the book", m && m.page === 1, m);
    await p.screenshot({ path: `${OUT}/01-open.png` });
    await closeMan(); const s1 = await SNAP();
    ok("close: book gone", !(await ev(() => !!document.querySelector(".lman,.lman-shield"))));
    ok("close (paused): recorder DOM byte-identical", s0.html === s1.html, { before: s0.len, after: s1.len });
    ok("close (paused): video time, paused, muted, rate identical", s0.t === s1.t && s1.paused && s0.muted === s1.muted && s0.rate === s1.rate, { t0: s0.t, t1: s1.t });
    ok("close (paused): picture pixels + LEDs + crop + undo + storage identical", s0.px === s1.px && JSON.stringify(s0.leds) === JSON.stringify(s1.leds) && s0.otr === s1.otr && s0.undo === s1.undo && s0.ls === s1.ls, { px: [s0.px, s1.px], leds: s1.leds, otr: s1.otr });
  });
  // ---- B: playing state: pause while open, resume on close from the same spot ----
  await step("playing restore", async () => {
    await tap(p, ".play"); await sleep(500);
    const pl = await ev(() => { const v = document.querySelector("video"); return !v.paused && !v.ended; });
    await openMan(); const t0 = await ev(() => document.querySelector("video").currentTime); const pz = await ev(() => document.querySelector("video").paused);
    await sleep(1200); const t1 = await ev(() => document.querySelector("video").currentTime);
    ok("open while playing: playback pauses, time holds while reading", pl && pz && t0 === t1, { wasPlaying: pl, pausedInBook: pz, t0, t1 });
    await p.keyboard.press(" "); await sleep(300);
    ok("Space inside the book does not toggle the recorder", await ev(() => document.querySelector("video").paused));
    await closeMan(); await sleep(150); const r = await ev(() => ({ paused: document.querySelector("video").paused, t: document.querySelector("video").currentTime }));
    // the cut's own rule: a resume at/after the OUT point starts again at IN (as the Play key does)
    const io = await ev(() => { const d = document.querySelector("video").duration; return [...document.querySelectorAll(".hand")].map((h) => (parseFloat(h.style.left) / 100) * d); });
    const atOut = t0 >= io[1] - 0.02;
    ok("close: playback resumes from where it paused", !r.paused && (atOut ? r.t < io[0] + 0.6 : r.t >= t0 - 0.05 && r.t < t0 + 1.0), { t0, after: r.t, inOut: io, atOut });
    // sample for 600 ms: time keeps moving (a wrap at OUT back to IN counts: the clip loops)
    const adv = await ev(async () => { const v = document.querySelector("video"); const seen = new Set(); let fwd = 0, wraps = 0, last = v.currentTime; for (let i = 0; i < 12; i++) { await new Promise((q) => setTimeout(q, 50)); const t = v.currentTime; if (t > last) fwd++; else if (t < last) wraps++; seen.add(t); last = t; } return { distinct: seen.size, fwd, wraps, paused: v.paused }; });
    ok("close: playback keeps advancing", !adv.paused && adv.distinct >= 4 && adv.fwd >= 3, { t: r.t, ...adv });
    await tap(p, ".play"); await sleep(300);
  });
  // ---- C: arrows/tap through all 9 pages, counter + dots + disabled ends ----
  await step("tap nav", async () => {
    await openMan(); const seen = []; let good = 0;
    for (let i = 0; i < 9; i++) { const m = await man(p); seen.push(m.page + ":" + m.name); if (m.page === i + 1 && m.p === i + 1 && m.name === NAMES[i] && m.counter === `p.${i + 1}` && m.dotOn === i && m.dots === 9 && m.shown === 1 && m.prevDis === (i === 0) && m.nextDis === (i === 8)) good++; if (i < 8) await tap(p, "[data-manual-next]"); }
    ok("Next arrow reaches all 9 pages; counter, dots, one page shown, end arrows disabled", good === 9, seen.join(" "));
    await tap(p, "[data-manual-next]"); ok("Next at p.9 stays on p.9", (await man(p)).page === 9);
    let back = 0; for (let i = 8; i > 0; i--) { await tap(p, "[data-manual-prev]"); const m = await man(p); if (m.page === i && m.counter === `p.${i}`) back++; }
    ok("Prev arrow walks 9 → 1", back === 8, `${back}/8`);
    // touch taps on the arrows too
    let tt = 0; for (let i = 1; i <= 8; i++) { await touchTap(p, "[data-manual-next]"); if ((await man(p)).page === i + 1) tt++; }
    ok("Touch taps on Next reach p.9", tt === 8, `${tt}/8`);
    for (let i = 0; i < 8; i++) await touchTap(p, "[data-manual-prev]");
    ok("Touch taps on Prev back to p.1", (await man(p)).page === 1);
  });
  // ---- D: swipe (mouse pointer + real touch) ----
  await step("swipe", async () => {
    const bx = await pagesBox(p); const y = bx.y + bx.h * 0.55, xa = bx.x + bx.w * 0.8, xb = bx.x + bx.w * 0.2;
    let n = 0; const tr = [];
    for (let i = 1; i <= 8; i++) { await mouseSwipe(p, xa, y, xb, y); const m = await man(p); tr.push(m.page); if (m.page === i + 1 && m.counter === `p.${i + 1}`) n++; }
    ok("Mouse swipe left x8 → p.9 (one page per swipe)", n === 8, tr.join(","));
    await mouseSwipe(p, xa, y, xb, y); ok("Swipe past the last page stays on p.9", (await man(p)).page === 9);
    n = 0; tr.length = 0; for (let i = 8; i >= 1; i--) { await touchSwipe(p, xb, y, xa, y); const m = await man(p); tr.push(m.page); if (m.page === i) n++; }
    ok("Touch swipe right x8 → p.1", n === 8, tr.join(","));
    await touchSwipe(p, xb, y, xa, y); ok("Swipe before the first page stays on p.1", (await man(p)).page === 1);
    n = 0; tr.length = 0; for (let i = 1; i <= 8; i++) { await touchSwipe(p, xa, y, xb, y); const m = await man(p); tr.push(m.page); if (m.page === i + 1) n++; }
    ok("Touch swipe left x8 → p.9", n === 8, tr.join(","));
    for (let i = 0; i < 8; i++) await touchSwipe(p, xb, y, xa, y);
    await touchSwipe(p, bx.x + bx.w / 2, bx.y + bx.h * 0.25, bx.x + bx.w / 2 + 10, bx.y + bx.h * 0.85);
    ok("Vertical drag does not turn the page", (await man(p)).page === 1);
    await touchSwipe(p, xa, y, xa - 20, y); ok("Short 20px nudge does not turn the page", (await man(p)).page === 1);
  });
  // ---- E: no endless scrolling ----
  await step("no scroll", async () => {
    let bad = []; for (let i = 0; i < 9; i++) { await ev((i) => { document.querySelector(".lman").dispatchEvent(new KeyboardEvent("keydown", { key: "Home", bubbles: true })); }, i); }
    await p.keyboard.press("Home"); await sleep(200);
    for (let i = 0; i < 9; i++) {
      const bx = await pagesBox(p); await p.mouse.move(bx.x + bx.w / 2, bx.y + bx.h / 2); await p.mouse.wheel({ deltaY: 900 }); await sleep(120);
      const s = await ev(() => { const pg = document.querySelector(".lman .lm-pg.lm-on"); const ps = document.querySelector(".lman .lm-pages"); return { st: pg.scrollTop + ps.scrollTop + document.scrollingElement.scrollTop + document.querySelector("main.vtr").scrollTop, sh: pg.scrollHeight, ch: pg.clientHeight, sw: pg.scrollWidth, cw: pg.clientWidth }; });
      if (s.st !== 0 || s.sh > s.ch + 1 || s.sw > s.cw + 1) bad.push(i + 1 + ":" + JSON.stringify(s));
      await p.keyboard.press("ArrowRight"); await sleep(220);
    }
    ok("Every page fits: nothing scrolls (wheel 900px on each of 9 pages)", bad.length === 0, bad.join(" ") || "9/9 fixed");
    ok("Keyboard ArrowRight walks to p.9", (await man(p)).page === 9);
  });
  // ---- F: Contents jumps ----
  await step("contents", async () => {
    await p.keyboard.press("Home"); await sleep(150); await tap(p, "[data-manual-next]");
    const lines = await ev(() => [...document.querySelectorAll(".lman .lm-toc [data-go]")].map((b) => ({ go: +b.dataset.go, t: b.querySelector(".lm-t").textContent, pg: b.querySelector(".lm-pgs").textContent })));
    let good = 0; const got = [];
    for (let k = 0; k < lines.length; k++) {
      await tap(p, `.lman .lm-toc [data-go="${lines[k].go}"]`); const m = await man(p); got.push(`${lines[k].t}→p.${m.page} ${m.name}`);
      if (m.page === lines[k].go && +lines[k].pg === lines[k].go && m.name === NAMES[lines[k].go - 1] && m.counter === `p.${lines[k].go}`) good++;
      await p.keyboard.press("Home"); await sleep(120); await touchTap(p, "[data-manual-next]");
    }
    ok("Contents: 7 lines, each jumps to its printed page", lines.length === 7 && good === 7, got.join(" | "));
    // touch tap on a contents line
    await touchTap(p, '.lman .lm-toc [data-go="9"]'); ok("Contents line works with a touch tap (→ p.9)", (await man(p)).page === 9);
    // a swipe that starts on a contents line turns one page and does not also jump
    await p.keyboard.press("Home"); await sleep(120); await tap(p, "[data-manual-next]");
    const r = await ev(() => { const e = document.querySelector('.lman .lm-toc [data-go="5"]').getBoundingClientRect(); return { x: e.left + e.width * 0.8, y: e.top + e.height / 2, x2: e.left + e.width * 0.15 }; });
    await touchSwipe(p, r.x, r.y, r.x2, r.y); const m = await man(p);
    ok("Swipe starting on a Contents line turns exactly one page (p.2 → p.3), no jump", m.page === 3, m);
    // quick touch tap right after a swipe must not be dropped (Chrome can eat that click; buttons act on pointerup)
    const bx = await pagesBox(p); const yy = bx.y + bx.h / 2; const quick = [];
    for (let i = 0; i < 4; i++) { await touchSwipe(p, bx.x + bx.w * 0.85, yy, bx.x + bx.w * 0.15, yy); await touchTap(p, "[data-manual-prev]"); quick.push((await man(p)).page); }
    ok("Touch tap on Prev straight after a swipe always lands (4/4, back to the same page)", quick.every((v) => v === 3), quick.join(","));
    // one touch tap on a Contents line jumps exactly once (pointerup + click are not doubled)
    await p.keyboard.press("Home"); await sleep(120); await tap(p, "[data-manual-next]");
    await touchTap(p, '.lman .lm-toc [data-go="4"]'); await sleep(300); const j = await man(p);
    ok("Touch tap on a Contents line jumps once (→ p.4, no extra turn)", j.page === 4, j);
    // touch tap on Next twice quickly = exactly two pages
    await p.keyboard.press("Home"); await sleep(120); await touchTap(p, "[data-manual-next]"); await touchTap(p, "[data-manual-next]"); await sleep(300);
    ok("Two touch taps on Next = exactly two pages (no doubled pointerup+click)", (await man(p)).page === 3, await man(p));
    // slow phone: the click arrives 1 s after the pointerup → still one page; a pointerup whose click never comes does not block the next tap
    await p.keyboard.press("Home"); await sleep(120);
    const late = await ev(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const b = document.querySelector("[data-manual-next]"); const r = b.getBoundingClientRect(); const o = { bubbles: true, cancelable: true, pointerType: "touch", pointerId: 7, isPrimary: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
      b.dispatchEvent(new PointerEvent("pointerdown", o)); b.dispatchEvent(new PointerEvent("pointerup", o)); await w(1000); b.click(); await w(250); const a = +document.querySelector(".lman").dataset.page;
      b.dispatchEvent(new PointerEvent("pointerdown", o)); b.dispatchEvent(new PointerEvent("pointerup", o)); await w(250); /* click dropped */ b.dispatchEvent(new PointerEvent("pointerdown", o)); b.dispatchEvent(new PointerEvent("pointerup", o)); await w(150); b.click(); await w(250); return [a, +document.querySelector(".lman").dataset.page]; });
    // slow phone: a swipe's own click arriving late (0.8 s) must not land on the Contents page it just turned to
    await p.keyboard.press("Home"); await sleep(150); { const bx2 = await pagesBox(p); const y2 = bx2.y + bx2.h / 2; await touchSwipe(p, bx2.x + bx2.w * 0.85, y2, bx2.x + bx2.w * 0.15, y2); }
    const lateSwipe = await ev(async () => { await new Promise((r) => setTimeout(r, 800)); const a = +document.querySelector(".lman").dataset.page; const l = document.querySelector('.lman .lm-toc [data-go="9"]'); if (l) l.click(); await new Promise((r) => setTimeout(r, 300)); return [a, +document.querySelector(".lman").dataset.page]; });
    ok("Late click after a swipe does not jump from Contents (stays p.2)", lateSwipe[0] === 2 && lateSwipe[1] === 2, lateSwipe.join(" → "));
    ok("Late click (1 s after pointerup) does not double-turn; a dropped click does not eat the next tap", late[0] === 2 && late[1] === 4, late.join(" → "));
  });
  // ---- G: bar is inert while open; Esc closes ----
  await step("inert + esc", async () => {
    await tap(p, ".bar [aria-label=Menu]").catch(() => {});
    ok("Recorder top bar is inert while the book is open (no MENU behind it)", (await ev(() => !document.querySelector(".sheet[aria-label=MENU]"))) && !!(await man(p)));
    await p.keyboard.press("Escape"); await sleep(250);
    ok("Esc closes the book", !(await man(p)));
    await openMan(); ok("Re-open starts at the Cover (p.1)", (await man(p)).page === 1); await closeMan();
  });
  // ---- H: 50x open/close spam, leaks ----
  await step("spam", async () => {
    const s = await p.target().createCDPSession(); await s.send("HeapProfiler.enable");
    const meter = async () => { await s.send("HeapProfiler.collectGarbage"); await sleep(150); await s.send("HeapProfiler.collectGarbage"); const d = await s.send("Memory.getDOMCounters"); const h = await s.send("Runtime.getHeapUsage"); const wl = await ev(() => document.querySelectorAll("*").length); return { nodes: d.nodes, listeners: d.jsEventListeners, docs: d.documents, heap: h.usedSize, els: wl }; };
    for (let i = 0; i < 5; i++) { await openMan(); await tap(p, "[data-manual-next]"); await closeMan(); }
    const m0 = await meter(); const s0 = await SNAP(); const e0 = errs.length; let opened = 0, closed = 0;
    const t0 = Date.now();
    for (let i = 0; i < 50; i++) {
      await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-manual-open]");
      if ((await man(p))?.page === 1) opened++;
      if (i % 2) await touchTap(p, "[data-manual-next]"); else { const bx = await pagesBox(p); await touchSwipe(p, bx.x + bx.w * 0.8, bx.y + bx.h / 2, bx.x + bx.w * 0.2, bx.y + bx.h / 2, 4); }
      if (i % 3 === 0) await p.keyboard.press("Escape"); else await tap(p, "[data-manual-close]");
      await sleep(30); if (!(await man(p))) closed++;
    }
    const m1 = await meter(); const s1 = await SNAP();
    ok("Spam 50x: opened 50/50 at p.1, closed 50/50 (CLOSE + Esc mix)", opened === 50 && closed === 50, { opened, closed, secs: ((Date.now() - t0) / 1000).toFixed(1) });
    ok("Spam 50x: no leftover book / shield / scrim nodes", await ev(() => !document.querySelector(".lman,.lman-shield,.scrim")));
    ok("Spam 50x: DOM nodes and JS listeners back to baseline (after GC)", m1.els === m0.els && m1.listeners <= m0.listeners && m1.nodes <= m0.nodes + 60, { before: m0, after: m1 });
    ok("Spam 50x: heap growth < 1.5 MB after GC", m1.heap - m0.heap < 1.5e6, { growthKB: Math.round((m1.heap - m0.heap) / 1024) });
    ok("Spam 50x: recorder state identical afterwards", s0.html === s1.html && s0.t === s1.t && s0.px === s1.px, { t: [s0.t, s1.t] });
    ok("Spam 50x: 0 new JS errors", errs.length === e0, errs.slice(e0).join("; "));
  });
  // ---- B2: a video that stopped by itself must not be started (or moved) by opening the book ----
  await step("ended video", async () => {
    await ev(() => { const v = document.querySelector("video"); v.pause(); });
    await sleep(300); const s0 = await SNAP();
    await openMan(); const inBook = await ev(() => document.querySelector("video").paused); await closeMan(); await sleep(200); const s1 = await SNAP();
    ok("stopped-by-itself video: book neither starts nor moves it", inBook && s1.paused && s0.t === s1.t, { t0: s0.t, t1: s1.t });
  });
  // ---- I: comic PAGE side opens the same book at Add & Page ----
  await step("comic", async () => {
    await tap(p, ".bar .sw button", "PAGE"); await sleep(500);
    await tap(p, ".bar [aria-label=Menu]"); await tap(p, "[data-manual-open]"); const m = await man(p);
    await p.screenshot({ path: `${OUT}/02-comic-open.png` });
    ok("PAGE side: MENU › MANUAL opens the book at p.6 Add & Page", m && m.page === 6 && m.name === "Add & Page", m);
    await tap(p, "[data-manual-close]"); ok("PAGE side: close returns to the page editor", !(await man(p)) && (await ev(() => [...document.querySelectorAll(".sw button.on")].some((b) => b.getClientRects().length && b.textContent.includes("PAGE")))));
    await tap(p, ".bar .sw button", "CLIP"); await sleep(400);
  });
  ok("Version label reads Latch 2.1", await ev(async () => { document.querySelector(".bar [aria-label=Menu]").click(); await new Promise((r) => setTimeout(r, 200)); const t = document.querySelector(".sheet").textContent; document.querySelector(".sheet .done").click(); return /Latch 2\.1 · VTR-1/.test(t); }));
  ok("0 JS errors (whole run)", errs.length === 0, errs.join("; "));
  fs.writeFileSync(`${OUT}/func.json`, JSON.stringify(R, null, 1));
  console.log(`func ${VP.join("x")}: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
