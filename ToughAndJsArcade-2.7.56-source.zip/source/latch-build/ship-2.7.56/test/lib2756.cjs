// Shared helpers for the Latch 2.1 manual tests (2.7.56). Builds on build-latch/test/lib.cjs (same browser, hooks, tap()).
const L = require("/workspace/game/build-latch/test/lib.cjs");
const { sleep } = L;
const LATCH = "file:///workspace/game/build-latch/ship2756/test/latch-2.1-from-apk.html";
// real pointer swipe with the mouse (pointerType mouse)
async function mouseSwipe(p, x0, y0, x1, y1, steps = 8) { await p.mouse.move(x0, y0); await p.mouse.down(); for (let i = 1; i <= steps; i++) { await p.mouse.move(x0 + ((x1 - x0) * i) / steps, y0 + ((y1 - y0) * i) / steps); await sleep(12); } await p.mouse.up(); await sleep(260); }
// real touch swipe (pointerType touch) through CDP Input.dispatchTouchEvent
async function touchSwipe(p, x0, y0, x1, y1, steps = 8) {
  const s = p.__cdp || (p.__cdp = await p.target().createCDPSession());
  await s.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: x0, y: y0 }] });
  for (let i = 1; i <= steps; i++) { await s.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: x0 + ((x1 - x0) * i) / steps, y: y0 + ((y1 - y0) * i) / steps }] }); await sleep(12); }
  await s.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] }); await sleep(260);
}
async function touchTap(p, sel) {
  const pt = await p.evaluate((s) => { const e = [...document.querySelectorAll(s)].find((e) => e.getClientRects().length); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }, sel);
  if (!pt) throw new Error("not found " + sel);
  const s = p.__cdp || (p.__cdp = await p.target().createCDPSession());
  await s.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [pt] }); await sleep(40);
  await s.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] }); await sleep(260);
}
const man = (p) => p.evaluate(() => { const m = document.querySelector(".lman"); if (!m) return null; const s = m.querySelector(".lm-pg.lm-on"); const dots = [...m.querySelectorAll(".lm-dots i")]; return { page: +m.dataset.page, name: s && s.dataset.name, p: s && +s.dataset.p, counter: m.querySelector("[data-manual-counter]").textContent, dotOn: dots.findIndex((d) => d.classList.contains("lm-on")), dots: dots.length, prevDis: m.querySelector("[data-manual-prev]").disabled, nextDis: m.querySelector("[data-manual-next]").disabled, shown: m.querySelectorAll(".lm-pg").length }; });
const pagesBox = (p) => p.evaluate(() => { const r = document.querySelector(".lman .lm-pages").getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; });
const NAMES = ["Cover", "Contents", "Controls", "Insert & Cut", "Look", "Add & Page", "Save", "Settings", "Troubleshooting"];
module.exports = { ...L, LATCH, mouseSwipe, touchSwipe, touchTap, man, pagesBox, NAMES };
