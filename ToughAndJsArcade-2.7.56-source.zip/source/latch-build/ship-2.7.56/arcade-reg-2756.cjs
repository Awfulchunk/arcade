// Arcade 2.7.56 bundle (taken out of the APK): FunMotion 0.2.5, Needle, Latch 2.1 + kept 2.0/1.1/1, Swarm 1.6.14 + kept 1.6.13. 0 JS errors.
const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy-no-user-gesture-required", "--autoplay-policy=no-user-gesture-required", "--allow-file-access-from-files"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, d); };
  const page = async () => {
    const p = await b.newPage(); const errs = [];
    p.on("pageerror", (e) => errs.push("shell: " + e.message));
    await p.setViewport({ width: 360, height: 800, isMobile: true, hasTouch: true });
    await p.evaluateOnNewDocument(() => {
      const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc");
      Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } });
    });
    await p.goto("file:///workspace/game/build-latch/ship2756/test/index-from-apk.html"); await sleep(1500);
    return { p, errs };
  };
  const { p, errs } = await page();
  await p.screenshot({ path: "/workspace/game/build-latch/ship2756/test/out/arcade-reg/00-menu.png" });
  const info = await p.evaluate(() => {
    const latch = GAMES.find((x) => x.id === "latch");
    const sw = GAMES.find((x) => x.id === "swarm");
    const fm = GAMES.find((x) => x.id === "funmotion");
    return {
      latch: latch.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      swarm: sw.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      funmotion: fm.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      has: ["funmotion", "needle", "latch", "swarm"].map((id) => GAMES.findIndex((x) => x.id === id))
    };
  });
  ok("GAMES has funmotion, needle, latch, swarm", info.has.every((i) => i >= 0), JSON.stringify(info.has));
  ok("Latch picker v1 / v1.1 / v2.0 kept / v2.1 default", info.latch.length === 4 && /^latest=v2\.1.*\(default\)/.test(info.latch[3]) && /^v20=v2\.0/.test(info.latch[2]) && !/default/.test(info.latch[2]) && /^v11=v1\.1/.test(info.latch[1]) && /^v1=/.test(info.latch[0]), info.latch.join(" | "));
  ok("FunMotion picker v0.2.5 latest (default) + v024 kept", info.funmotion.some((s) => /^latest=v0\.2\.5.*\(default\)/.test(s)) && info.funmotion.some((s) => /^v024=v0\.2\.4/.test(s)), info.funmotion.join(" | "));
  ok("Swarm picker v1.6.14 latest (default) + v1613 kept", info.swarm.some((s) => /^latest=v1\.6\.14.*\(default\)/.test(s)) && info.swarm.some((s) => /^v1613=v1\.6\.13/.test(s)), info.swarm.slice(-4).join(" | "));
  const run = async (id, verId, check, shot) => {
    await p.evaluate((id, verId) => { const i = GAMES.findIndex((g) => g.id === id); const G = GAMES[i]; if (verId) ARCADE.launch(i, verId); else ARCADE.launchCard(i); }, id, verId);
    await sleep(3500);
    const fr = p.frames().find((f) => f !== p.mainFrame());
    let res = { loaded: false };
    if (fr) res = await fr.evaluate(check).catch((e) => ({ loaded: false, err: e.message }));
    const ferrs = fr ? await fr.evaluate(() => window.__errs || ["no capture"]).catch(() => ["eval failed"]) : ["no frame"];
    await p.screenshot({ path: `/workspace/game/build-latch/ship2756/test/out/arcade-reg/${shot}.png` });
    ok(`${id}${verId ? ":" + verId : ""} launches, 0 JS errors`, res.loaded && ferrs.length === 0, JSON.stringify({ ...res, errs: ferrs }).slice(0, 400));
    await p.evaluate(() => ARCADE.back()); await sleep(800);
    return fr;
  };
  await run("funmotion", null, () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, ver: (document.documentElement.innerHTML.match(/0\.2\.\d/) || [])[0], tutorial: /Tutorial/i.test(document.body.innerText) || !!document.querySelector("[data-tutorial],#tutorial,button") && [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01-funmotion");
  await run("funmotion", "v024", () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, tutorial: [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01b-funmotion-v024");
  await run("needle", null, () => ({ loaded: document.body.innerText.length > 20, text: document.body.innerText.slice(0, 60) }), "02-needle");
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "latch"); ARCADE.launchCard(i); }); await sleep(2500);
  let fr = p.frames().find((f) => f !== p.mainFrame());
  const v2 = await fr.evaluate(async () => { const vtr = !!document.querySelector("main.vtr"); const book = !!document.querySelector("[data-manual-open]") || /Owner/.test(document.documentElement.innerHTML); const qm = document.querySelectorAll(".qm").length; const s = document.querySelector("[data-sample]"); if (s) s.click(); await new Promise((r) => setTimeout(r, 1800)); return { vtr, qm, pic: !!document.querySelector(".vf canvas.pic"), osd: document.querySelector(".osd.obl") && document.querySelector(".osd.obl").textContent, ver: document.body.innerText.includes("VTR"), book }; });
  const e2 = await fr.evaluate(() => window.__errs);
  await p.screenshot({ path: "/workspace/game/build-latch/ship2756/test/out/arcade-reg/03-latch-v2.1.png" });
  ok("latch v2.1 (default) = VTR-1 UI with the Owner's Manual, no ? badges, 0 errors", v2.vtr && v2.book && v2.qm === 0 && e2.length === 0, JSON.stringify({ ...v2, errs: e2 }));
  // open the book inside the real arcade frame: MENU > MANUAL, turn a page, close
  const bk = await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); document.querySelector(".bar [aria-label=Menu]").click(); await w(300); const t = document.querySelector("[data-manual-open]"); if (!t) return { opened: false }; t.click(); await w(400); const m = document.querySelector(".lman"); const p1 = m && m.dataset.page; document.querySelector("[data-manual-next]").click(); await w(300); const p2 = m && m.dataset.page; document.querySelector("[data-manual-close]").click(); await w(300); return { opened: !!m, p1, p2, closed: !document.querySelector(".lman"), ver: /Latch 2\.1/.test(document.documentElement.innerHTML) }; });
  await p.screenshot({ path: "/workspace/game/build-latch/ship2756/test/out/arcade-reg/03b-latch-v2.1-after-book.png" });
  ok("latch v2.1 in the arcade: MENU › MANUAL opens p.1, Next → p.2, CLOSE closes", bk.opened && bk.p1 === "1" && bk.p2 === "2" && bk.closed, JSON.stringify(bk));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await run("latch", "v20", () => ({ loaded: !!document.querySelector("main.vtr") && document.querySelectorAll(".qm").length === 0 && !/data-manual-open|lman/.test(document.documentElement.innerHTML), vtr: !!document.querySelector("main.vtr") }), "03c-latch-v2.0-kept");
  await run("latch", "v11", () => ({ loaded: document.querySelectorAll(".qm").length > 5 && !document.querySelector("main.vtr"), qm: document.querySelectorAll(".qm").length }), "04-latch-v1.1");
  await run("latch", "v1", () => ({ loaded: document.body.innerText.length > 20 && !document.querySelector("main.vtr") }), "05-latch-v1");
  const swc = () => ({ loaded: !!document.querySelector("canvas"), ver: (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1] });
  await run("swarm", null, swc, "07-swarm-latest");
  await run("swarm", "v1613", swc, "08-swarm-v1613");
  // confirm versions from last two runs by a dedicated eval
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launchCard(i); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const latestVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const lerr = await fr.evaluate(() => window.__errs);
  ok("swarm latest is 1.6.14", latestVer === "1.6.14" && lerr.length === 0, JSON.stringify({ latestVer, errs: lerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launch(i, "v1613"); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const oldVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const oerr = await fr.evaluate(() => window.__errs);
  ok("swarm v1613 is 1.6.13", oldVer === "1.6.13" && oerr.length === 0, JSON.stringify({ oldVer, errs: oerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  ok("arcade shell 0 JS errors", errs.length === 0, errs.join("; "));
  fs.writeFileSync("/workspace/game/build-latch/ship2756/test/out/arcade-reg/arcade.json", JSON.stringify(R, null, 1));
  console.log(`arcade: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close();
  process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
