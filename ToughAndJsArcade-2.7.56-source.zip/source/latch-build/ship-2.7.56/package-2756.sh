#!/bin/bash
# Stage the finished-ship folder for Arcade 2.7.56 / Latch 2.1. Never prints the unlock code.
set -euo pipefail
D=/workspace/game/requests/finished-ship/latch-manual-arcade-2.7.56
BL=/workspace/game/build-latch; S=$BL/ship2756; T=$S/test; P=$BL/package-2.7.56; L=/workspace/game/build-apps/src-latch
OLD55=/workspace/game/requests/finished-ship/swarm-1.6.14-arcade-2.7.55
rm -rf $D; mkdir -p $D/{screenshots,licenses,test-evidence}
cp $P/out/ToughAndJsArcade-2.7.56.apk $D/
# (the standalone built html is not shipped: the APK carries it)
# ---- source zip (GPL), unlock code placeholdered ----
Z=/tmp/latch21src; rm -rf $Z; mkdir -p $Z/Latch-2.1-source/{latch-ui,manual,latch-build,ship-2.7.56,old-webview,android-app}
R=$Z/Latch-2.1-source
cp -r $L/src $L/spa $R/latch-ui/; cp $L/vite.spa.config.ts $L/tsconfig.vtr.json $R/latch-ui/
cp $BL/tool/package.json $R/latch-ui/toolchain-package.json 2>/dev/null || true
python3 - "$R/latch-ui/src/lib/bench/model.ts" <<'PY'
import re,sys
p=sys.argv[1]; s=open(p).read()
n=len(re.findall(r'const MARK = "[^"]*";',s)); assert n==1
s=re.sub(r'const MARK = "[^"]*";','const MARK = "REPLACE-WITH-UNLOCK-CODE"; // the real code is not published',s); open(p,'w').write(s); print("placeholdered MARK in model.ts")
PY
cp -r $BL/manual/gen-manual.mjs $BL/manual/fonts $BL/manual/mock-approved.html $BL/manual/gaps.txt $R/manual/
cp $BL/build.sh $R/latch-build/
cp $S/build-2756.sh $S/assemble-2756.mjs $S/verify-2756.cjs $S/arcade-reg-2756.cjs $S/emu-2756.cjs $S/run-emu.sh $S/package-2756.sh $R/ship-2.7.56/
mkdir -p $R/ship-2.7.56/test/reg; cp $T/lib2756.cjs $T/t-func.cjs $T/t-layout.cjs $T/t-perf.cjs $T/t-bridge.cjs $R/ship-2.7.56/test/; cp $T/reg/*.cjs $R/ship-2.7.56/test/reg/
cp $BL/fix/legacy-css.mjs $BL/fix/legacy-html.mjs $BL/fix/legacy-prelude.js $BL/fix/cdp.cjs $R/old-webview/ 2>/dev/null || true
cp $P/app/AndroidManifest.xml $P/build-apk.sh $R/android-app/; cp -r $P/app/src $R/android-app/src
cat > $R/README.md <<'MD'
# Latch 2.1 source (Tough & J's Arcade 2.7.56) — GPL-3.0
- latch-ui/: the Latch React/TSX app (VTR-1 UI + the new Owner's Manual: src/components/bench/manual.tsx, manual-pages.ts, src/manual.css, src/assets/manual-fonts).
- manual/: generator that turns the approved paper mock into the 9 manual pages (gen-manual.mjs), subset OFL fonts, the mock.
- latch-build/build.sh: vite single-file build (chrome80 target). ship-2.7.56/: assemble on 2.7.55, verify, tests, emulator script.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.55).
- The Latch unlock code is NOT included: src/lib/bench/model.ts has `REPLACE-WITH-UNLOCK-CODE`. Put your own value there to build.
- Signing keys are not included.
MD
rm -f $D/Latch-2.1-source.zip; (cd $Z && python3 -c "import shutil; shutil.make_archive(\"$D/Latch-2.1-source\", \"zip\", \".\", \"Latch-2.1-source\")")
# ---- licenses ----
cp -r $OLD55/licenses/* $D/licenses/
cp $BL/manual/fonts/OFL-1.1-manual-fonts.txt $D/licenses/
echo staged
