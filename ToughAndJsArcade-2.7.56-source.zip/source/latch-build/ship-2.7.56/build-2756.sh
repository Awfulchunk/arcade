#!/bin/bash
# Full 2.7.56 build: manual pages -> Latch 2.1 html -> arcade bundle (on top of 2.7.55 from its finished-ship APK) -> signed APK -> extract for tests.
set -euo pipefail
export PATH=/workspace/tools/jdk/bin:$PATH
L=/workspace/game/build-latch; P=$L/package-2.7.56; S=$L/ship2756
node $L/manual/gen-manual.mjs > $S/out/gen-manual.log
bash $L/build.sh /workspace/game/build-apps/latch-v2.1.html
rm -rf /tmp/b55 && mkdir -p /tmp/b55 && (cd /tmp/b55 && unzip -q /workspace/game/requests/finished-ship/swarm-1.6.14-arcade-2.7.55/ToughAndJsArcade-2.7.55.apk assets/index.html)
cp /tmp/b55/assets/index.html $P/base-2.7.55.html
node $S/assemble-2756.mjs $S/out/index.html > $S/out/assemble.log
cp $S/out/index.html $P/tough-and-js-arcade.html
rm -f $P/out/ToughAndJsArcade-2.7.56.apk $P/out/ToughAndJsArcade-2.7.56.apk.idsig
(cd $P && ./build-apk.sh) > $S/out/build-apk.log 2>&1
rm -rf /tmp/a56 && mkdir /tmp/a56 && (cd /tmp/a56 && unzip -q $P/out/ToughAndJsArcade-2.7.56.apk assets/index.html)
cp /tmp/a56/assets/index.html $S/test/index-from-apk.html
node -e 'const fs=require("fs"),vm=require("vm");const t=fs.readFileSync(process.argv[1],"utf8");const i=t.indexOf("const GAME_SRC="),j=t.indexOf("// END_PACKED_GAME_SRC");fs.writeFileSync(process.argv[2],vm.runInNewContext(t.slice(i,j)+"\nGAME_SRC;")["latch:latest"])' $S/test/index-from-apk.html $S/test/latch-2.1-from-apk.html
cmp $S/test/latch-2.1-from-apk.html /workspace/game/build-apps/latch-v2.1.html
cmp $S/test/index-from-apk.html $S/out/index.html
sha256sum $P/out/ToughAndJsArcade-2.7.56.apk $S/test/index-from-apk.html $S/test/latch-2.1-from-apk.html | tee $S/evidence/tested-artifacts.sha256
