#!/bin/bash
export PATH=/workspace/tools/sdk/platform-tools:$PATH; cd /workspace/game/build-latch/ship2756
adb shell 'rm -rf /sdcard/Download/ToughAndJs'; adb shell am force-stop com.toughandj.arcade; adb shell am start -n com.toughandj.arcade/.MainActivity >/dev/null; sleep 25
PID=$(adb shell pidof com.toughandj.arcade | tr -d '\r'); adb forward --remove-all; adb forward tcp:9333 localabstract:webview_devtools_remote_$PID >/dev/null
rm -rf emu; adb logcat -c; timeout 900 node emu-2756.cjs emu > evidence/pass4-emu.log 2>&1; echo "EMU rc=$?"
adb logcat -d | grep -E "TJArcade" | grep -iE "save" > evidence/pass4-emu-logcat-saves.txt; echo DONE
