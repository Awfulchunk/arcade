# Tough & J's Arcade 2.7.56 (versionCode 94) — source (GPL-3.0)

2.7.56 is cumulative over 2.7.53:
- FunMotion 0.2.5 + in-app tool tutorial (from unpublished 2.7.54) — source/funmotion-0.2.5/
- Swarm: Last Stand 1.6.14 SFX/beat + turret panel visuals (from unpublished 2.7.55) — source/swarm-1.6.14/
- Latch 2.1 with the VTR-1 Owner's Manual + APK save-bridge fix — source/latch-ui/, source/latch-manual/, source/latch-build/ship-2.7.56/
- Needle, engine, Android wrapper, old-WebView transforms: source/needle-ui, source/engine, source/android-app, source/old-webview

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
