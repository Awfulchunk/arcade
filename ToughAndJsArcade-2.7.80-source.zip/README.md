# Tough & J's Arcade 2.7.80 (versionCode 118) — source (GPL-3.0)

2.7.80 is cumulative over 2.7.79 (everything else unchanged):
- Pixel War 0.5.2 is now `pixelwar:latest` (default). Each path's FLOW is exactly how many pixels it has. MAIN FLOW (up to 5000) is everything the circle sends, branch FLOW comes out of it, and the SHARE coin-flip is gone (SHARE and AUTO SHARE are hidden; the old modes are in Custom Game). A new CIRCLE OUT slider (500-5000, default 3000) sets the per-side cap for both sides. A new CLUMP SHOT button fires about 40 pool pixels down the main path as a tight, fast, tougher clump (15 s cooldown); Pixie uses it through a book rule. 0.5.1 is kept as `pixelwar:v051`. Source: source/pixel-war/arcade-2.7.80/ (game file, FEATURES-052.md, AI-RULES.md, PROGRESS-052.md, tools/patch052*.py, tests/, logs/).
- Papa Potato 2.0.3 is now `papa-potato:latest` (default). The SHIPPING machine's intake is now a slot on its kitchen-facing side. Papa stands on the kitchen floor facing that slot, with a clear gap and no overlap with the box, and tosses each potato from his hand into it. The machine still carries potatoes through to the wash side and spits them into the pool. The starter bed moved two tiles left. 2.0.2 is kept as `papa-potato:v202`. Source: source/papa-potato/2.0.3/ (src, test, build.sh, FEATURES-203.md).
- Ship scripts: source/arcade-2.7.80/.

From 2.7.79:
- Papa Potato 2.0.2 is now `papa-potato:latest` (default). Papa stands on the kitchen floor in front of the SHIPPING machine and tosses potatoes into it (2c at the drop, about 4c more after the wash). The canal ends in a SHIP DRAIN, a FLOW ON/OFF tap (map + menu button) backs the canal up or lets it run, and two new canal machines (AUTO CLEANER, SORTER) need power and can jam. DRYER and BUBBLER are in CUSTOM GAME (off by default). 2.0.1 is kept as `papa-potato:v201`. Source: source/papa-potato/2.0.2/ (src, test, build.sh, FEATURES-202.md, PROGRESS-202.md).
- Ship scripts: source/arcade-2.7.79/.

From 2.7.78:
- Papa Potato 2.0.1 is now `papa-potato:latest` (default). Papa is a robot chef with a screen face, and the puke is gone completely. The 0.4.11 raw pile is back (80 potatoes, with a return pipe), the X-ray drops potatoes into the pool, and they wait there for Papa. You start with an empty room, and the pool and canal sit flush with the tiles. New: AUTO MODE (offline progress at up to 50%, with a While You Were Gone report), Papa's wants and cosmetic hats. Same save as 2.0.0. 2.0.0 is kept as `papa-potato:v200`. Source: source/papa-potato/2.0.1/ (src/ is sim.js, away.js, draw.js, radio.js, head.html and ui/game.js; build.sh; test/; FEATURES-201.md).
- Pixel War 0.5.1 is now `pixelwar:latest` (default). A new EFFECTS setting has OFF, LOW (the default, with calmer collision sparks and burns) and HIGH (the 0.5.0 look). The match itself is unchanged. 0.5.0 is kept as `pixelwar:v050`. Source: source/pixel-war/arcade-2.7.78/ (game file, FEATURES-051.md, AI-RULES.md, logs/ with patch051.py and tests).
- Ship scripts: source/arcade-2.7.78/.

From 2.7.77:
- Papa Potato 2.0.0 is now `papa-potato:latest` (default): a full rework with a corner-iso view, one continuous map (kitchen plus wash room), belts, machines, power and jams, dirty and clean potatoes, and a new save key. 0.4.11 is kept as `papa-potato:v0411`. Source: source/papa-potato/2.0.0/ (src/ is sim.js, draw.js, radio.js, head.html and ui/game.js; build.sh; test/; FEATURES-2.md).
- Pixel War 0.5.0 is now `pixelwar:latest` (default): a 3000 on-field cap, slightly faster pace, 5-notch pixel size, a new look, Pixie's merged memory and PixieBrain. 0.4.15 is kept as `pixelwar:v0415`. Source: source/pixel-war/arcade-2.7.77/ (game file, patch tools, diff from 0.4.15, FEATURES-05.md, AI-RULES.md, pixie-brain/, tests).
- Ship scripts: source/arcade-2.7.77/.

From 2.7.76:
- Pixel War 0.4.15 is now `pixelwar:latest` (default): big pixels clearly win straight fights in real play (packing counts flow, quarter-point HP/damage, steeper size tables, size edge and shove, 0.9x count cost). 0.4.14 is kept as `pixelwar:v0414`. Source: source/pixel-war/arcade-2.7.76/ (game files, diff, AI-RULES.md, FEATURES-0415.md, tests). Ship scripts: source/arcade-2.7.76/.

From 2.7.75:
- Swarm 1.6.16 is now `swarm:latest` (default). 1.6.15 is kept as `swarm:v1615`; v1614, v1613 and older unchanged. Source: source/swarm-1.6.16/ (patch tools + diff from 1.6.15). Ship scripts: source/arcade-2.7.75/.
- From 2.7.74: Pixel War 0.4.14 latest (v0412, v0413 kept), Papa Potato 0.4.11 latest (v0410 kept). Sources: source/pixel-war/arcade-2.7.74/, source/papa-potato/0.4.11/.
- Unchanged otherwise: Latch 2.1, FunMotion 0.2.5, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
