# Apply the 2.7.80 changes to the Pages checkout (/workspace/site). Only download.html is edited; the other pages are copied in whole.
import shutil
B='/workspace/game/build-ship2780'
p='/workspace/site/download.html';s=open(p,encoding='utf-8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,('not unique',a[:80],s.count(a)); s=s.replace(a,b)
rep('<p><a href="ToughAndJsArcade-2.7.78.apk">Older: 2.7.78 APK</a> · ','<p><a href="ToughAndJsArcade-2.7.79.apk">Older: 2.7.79 APK</a> · <a href="ToughAndJsArcade-2.7.78.apk">2.7.78 APK</a> · ')
rep('<p>New in <b>2.7.79</b>:','<p>New in <b>2.7.80</b>: <b>Pixel War 0.5.2</b>: every path\'s FLOW is now exactly how many pixels it has. Your MAIN FLOW (up to 5000) is everything your circle sends, and each branch\'s FLOW comes out of it, with no more SHARE coin-flip. A new CIRCLE OUT slider (500 to 5000, default 3000) sets the most pixels per side, the same for you and Pixie. A new CLUMP SHOT button fires about 40 pixels down your main path as one tight, fast, tougher clump, with a 15-second cooldown. Pixie has it too. <b>Papa Potato 2.0.3</b>: SHIPPING now has an intake slot on its kitchen side. Papa stands on the kitchen floor in front of it and tosses each potato in from his hand, and the machine still sends them through to the wash-side pool. Pixel War 0.5.1 and Papa Potato 2.0.2 stay playable.</p>\n<p>New in <b>2.7.79</b>:')
rep('<a href="ToughAndJsArcade-2.7.79.apk" download>Download Android APK (2.7.79)</a>\n<a class="o" href="ToughAndJsArcade-2.7.79-source.zip" download>Source code (GPL-3)</a>\n',
    '<a href="ToughAndJsArcade-2.7.80.apk" download>Download Android APK (2.7.80)</a>\n<a class="o" href="ToughAndJsArcade-2.7.80-source.zip" download>Source code (GPL-3)</a>\n')
rep('<a class="p" href="pixel-war.html">Pixel War 0.5.1</a>\n','<a class="p" href="pixel-war.html">Pixel War 0.5.2</a>\n<a class="p" href="pixel-war-v051.html">Pixel War 0.5.1 (older)</a>\n')
rep('<a class="p" href="papa-potato.html">Papa Potato 2.0.2</a>\n','<a class="p" href="papa-potato.html">Papa Potato 2.0.3</a>\n<a class="p" href="papa-potato-v202.html">Papa Potato 2.0.2 (older)</a>\n')
rep('<a class="o" href="ToughAndJsArcade-2.7.78.apk" download>Arcade APK 2.7.78 (older)</a>','<a class="o" href="ToughAndJsArcade-2.7.79.apk" download>Arcade APK 2.7.79 (older)</a>\n<a class="o" href="ToughAndJsArcade-2.7.79-source.zip" download>Source code 2.7.79 (older)</a>\n<a class="o" href="ToughAndJsArcade-2.7.78.apk" download>Arcade APK 2.7.78 (older)</a>')
open(p,'w',encoding='utf-8').write(s);print('download.html ok')
S='/workspace/site/'
shutil.copy(S+'papa-potato.html',S+'papa-potato-v202.html')   # old latest (2.0.2) kept as its own page
shutil.copy(S+'pixel-war.html',S+'pixel-war-v051.html')       # old latest (0.5.1) kept as its own page
shutil.copy('/workspace/game/requests/finished-ship/papa-potato-2.0.3-test/papa-potato-2.0.3.html',S+'papa-potato.html')
shutil.copy('/workspace/game/requests/finished-ship/pixelwar-0.5.2-test/pixel-war-0.5.2.html',S+'pixel-war.html')
shutil.copy(B+'/release/index.html',S+'index.html');shutil.copy(B+'/release/index.html',S+'tough-and-js-arcade.html')
shutil.copy(B+'/package-2.7.80/release/ToughAndJsArcade-2.7.80.apk',S);shutil.copy(B+'/release/ToughAndJsArcade-2.7.80-source.zip',S)
print('files ok')
