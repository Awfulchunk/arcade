// Headless Chrome: launch new + kept slots (and a few unchanged) from the assembled 2.7.80 shell.
const fs = require("fs"), path = require("path");
const deps = require("/workspace/game/tough-tools/lib/deps.cjs");
const pp = require(deps.puppeteer);
const chrome = deps.chrome;
const SHELL = process.argv[2] || "/workspace/game/build-ship2780/release/index.html";
const OUT = process.argv[3] || "/workspace/game/build-ship2780/release/headless-launch.log";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const JOBS = [
  ["pixelwar", "latest", "PIXEL WAR 0.5.2"],
  ["pixelwar", "v051", "PIXEL WAR 0.5.1"],
  ["pixelwar", "v050", "PIXEL WAR 0.5.0"],
  ["pixelwar", "v0415", "PIXEL WAR 0.4.15"],
  ["pixelwar", "v0414", "PIXEL WAR 0.4.14"],
  ["pixelwar", "v0413", "PIXEL WAR 0.4.13"],
  ["papa-potato", "latest", "VERSION=2.0.3"],
  ["papa-potato", "v202", "Papa Potato 2.0.2"],
  ["papa-potato", "v201", "Papa Potato 2.0.1"],
  ["papa-potato", "v200", "Papa Potato 2.0.0"],
  ["papa-potato", "v0411", "Papa Potato 0.4.11"],
  ["papa-potato", "v0410", "Papa Potato 0.4.10"],
  ["swarm", "latest", "Swarm: Last Stand"],
  ["swarm", "v1615", "Swarm: Last Stand"],
  ["funmotion", null, "FunMotion"],
  ["latch", null, "Latch"],
];
(async () => {
  const browser = await pp.launch({ executablePath: chrome, headless: "new", args: ["--no-sandbox", "--allow-file-access-from-files"] });
  const lines = []; let ok = true;
  for (const [gid, ver, expect] of JOBS) {
    const ctx = await browser.createBrowserContext();
    const page = await ctx.newPage();
    const errs = [];
    page.on("pageerror", (e) => errs.push("pageerror: " + String(e.message || e).split("\n")[0].slice(0, 200)));
    await page.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await page.goto("file://" + SHELL, { waitUntil: "load", timeout: 60000 });
    await page.waitForFunction(() => window.ARCADE && ARCADE.GAMES && ARCADE.GAMES.length, { timeout: 30000 });
    const r = await page.evaluate((gid, ver) => {
      const i = ARCADE.GAMES.findIndex((g) => g.id === gid);
      if (i < 0) return "nogame";
      try { ARCADE.launch(i, ver || undefined); } catch (e) { return "throw:" + e.message; }
      return "ok";
    }, gid, ver);
    if (r !== "ok") { lines.push(`${gid} ${ver} FAIL launch ${r}`); ok = false; await ctx.close(); continue; }
    await page.waitForFunction(() => {
      try { const f = ARCADE.frame(); return ARCADE.inGame && f && f.contentDocument && f.contentDocument.readyState === "complete" && f.classList.contains("on"); }
      catch (e) { return false; }
    }, { timeout: 25000 }).catch(() => {});
    await sleep(2000);
    const info = await page.evaluate(() => {
      const f = ARCADE.frame(); const d = f && f.contentDocument;
      const title = (d && d.title) + " " + ((d && /VERSION="([0-9.]+)"/.exec(d.documentElement.outerHTML)||[])[0]||"").replace(/"/g,"");
      const frErrs = (f && f.contentWindow && f.contentWindow.__errs) || [];
      return { inGame: !!ARCADE.inGame, on: !!(f && f.classList.contains("on")), title, rs: d && d.readyState, iframeErrs: frErrs };
    });
    // FunMotion missing tutorial MP4 is expected outside the APK
    const ignore = (s) => /ERR_FILE_NOT_FOUND|Failed to load resource/.test(s);
    const bad = errs.filter((e) => !ignore(e)).concat((info.iframeErrs || []).filter((e) => !ignore(String(e))));
    const titleOk = info.title && info.title.indexOf(expect) >= 0;
    const pass = info.inGame && info.on && info.rs === "complete" && titleOk && bad.length === 0;
    if (!pass) ok = false;
    const line = `${gid} ${ver || "null"} ${pass ? "ok" : "FAIL"} ${JSON.stringify({ inGame: info.inGame, on: info.on, title: info.title, rs: info.rs })} errs ${JSON.stringify(errs.concat(info.iframeErrs || []))}`;
    if (gid === "papa-potato" && ver === "latest" || gid === "pixelwar" && ver === "latest") await page.screenshot({ path: require("path").dirname(OUT) + "/arcade-" + gid + "-latest.png" });
    lines.push(line); console.log(line);
    await ctx.close();
  }
  await browser.close();
  fs.writeFileSync(OUT, lines.join("\n") + "\n");
  console.log(ok ? "HEADLESS ALL OK" : "HEADLESS FAIL");
  process.exit(ok ? 0 : 1);
})().catch((e) => { console.error("ERR", e.stack || e); process.exit(1); });
