// Arcade 2.7.80 = published 2.7.79 bundle + papa-potato:latest 2.0.3 (new v202=2.0.2) + pixelwar:latest 0.5.2 (new v051=0.5.1). Everything else byte-identical.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2780", R = B + "/release", BASE = R + "/base-2779.html", OUT = process.argv[2] || R + "/index.html";
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "1834155bd4a3a2aac6f089c7b4b207397b35fc93111b5477dcaa4391818b1df3", "2.7.79 base hash");
const rd = (f) => fs.readFileSync(f, "utf8");
const PAPA3 = "/workspace/game/requests/finished-ship/papa-potato-2.0.3-test/papa-potato-2.0.3.html", PAPA3SHA = "3095f503f5d0c457e7295fb8462a2efedf3c408f34276327866d17cd2b9eb025";
const PW = "/workspace/game/requests/finished-ship/pixelwar-0.5.2-test/pixel-war-0.5.2.html", PWSHA = fs.readFileSync(PW + ".sha256", "utf8").trim().split(/\s+/)[0];
const JOBS = [
 { card: "papa-potato", newKey: "v202", html: rd(PAPA3), hsha: PAPA3SHA, oldSha: "d79d4fdcda8062d6e2a42fd7f8e3f329928e4d6eb9baa822b809a9ef577a221b",
   oldName: "v2.0.2 – canal drain, FLOW tap, auto cleaner, sorter (2.7.79)", name: "v2.0.3 – Latest (Papa feeds the shipping slot from the kitchen floor)",
   desc: "Papa Potato 2.0.3. Papa now stands on the real kitchen floor right in front of the SHIPPING machine's kitchen-side slot, faces it with his back to you, and tosses each potato from his hand into the slot. He never overlaps the machine at any zoom, and the SHIPPING sign stays clear. The machine still carries every potato through the wall and spits it into the wash-room pool, where they pile up until Papa goes in to wash them. The starter bed moved two tiles left so it does not hide him (older saves move it when that spot is free). Everything else is as in 2.0.2: the canal SHIP DRAIN, the FLOW tap, the AUTO CLEANER and SORTER. Your 2.0.2 save carries over. 2.0.2, 2.0.1, 2.0.0, 0.4.11 and older stay playable.",
   order: null, orderEnd: "v0411,v200,v201,latest" },
 { card: "pixelwar", newKey: "v051", html: rd(PW), hsha: PWSHA, oldSha: "6b097e93cfe225be9eb77a997c7b6aeb8655c29dbdb8defce7b57f7c28dae516",
   oldName: "v0.5.1 – calmer collision effects, EFFECTS setting (2.7.78)", name: "v0.5.2 – Latest (FLOW-only branches, CIRCLE OUT 500-5000, CLUMP SHOT)",
   desc: "Pixel War 0.5.2. Branches are simple now: every path's FLOW is exactly how many pixels it has on the field. Your MAIN FLOW (now up to 5000) is everything your circle sends out, and each branch's FLOW comes out of it, so the main lane gets what is left. There is no SHARE coin-flip any more, so the first branch you draw no longer gets extra. New CIRCLE OUT slider (500 to 5000, default 3000): the most pixels on the field per side, the same for you and Pixie; turn it down if your phone slows. New CLUMP SHOT button: about 40 of your pool pixels fly straight down your main path as one tight, fast, tougher clump (cyan for you, gold for Pixie), with a 15-second cooldown ring. Pixie has the same button and rules. SHARE, other clump sizes, cooldowns and tap-to-aim are in CUSTOM GAME. 0.5.1, 0.5.0 and older stay playable.",
   order: null, orderEnd: "v0415,v050,latest" },
];
for (const j of JOBS) { assert(sha(j.html) === j.hsha, "staged html sha " + j.card); for (const x of j.extra || []) assert(sha(x.html) === x.hsha, "extra sha " + x.key); }
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
const before = slots(src); const NB = Object.keys(before).length; assert(NB === 187, "187 slots before, got " + NB);
const G0 = GS(src);
for (const j of JOBS) { j.KL = j.card + ":latest"; j.KN = j.card + ":" + j.newKey; assert(before[j.KL] && !before[j.KN], "slot state " + j.card); j.old = G0[j.KL];
  assert(sha(j.old) === j.oldSha, "live latest = previous version " + j.card); for (const x of j.extra || []) { x.K = j.card + ":" + x.key; assert(!before[x.K], "extra slot free " + x.K); } }
let out = src; for (const j of [...JOBS].sort((a, b) => before[b.KL][0] - before[a.KL][0])) out = out.slice(0, before[j.KL][0]) + ex(j.html) + out.slice(before[j.KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + JOBS.map((j) => ',\n"' + j.KN + '":' + ex(j.old) + (j.extra || []).map((x) => ',\n"' + x.K + '":' + ex(x.html)).join("")).join("") + out.slice(ei);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
for (const j of JOBS) { const g = GAMES.find((x) => x.id === j.card); const ids = g.versions.map((v) => v.id);
  if (j.order) assert(ids.join() === j.order, "card versions before " + j.card + " " + ids); if (j.orderEnd) assert(ids.join().endsWith(j.orderEnd), "card end " + j.card + " " + ids);
  assert(ids[ids.length - 1] === "latest" && !ids.includes(j.newKey), "latest last " + j.card);
  const L = g.versions[g.versions.length - 1]; const kept = { ...L, id: j.newKey, name: j.oldName, def: false }; const lat = { ...L, name: j.name, desc: j.desc, def: true };
  const extras = (j.extra || []).map((x) => ({ ...L, id: x.key, name: x.name, desc: x.desc, def: false }));
  g.versions = [...g.versions.slice(0, -1), kept, ...extras, lat]; if (j.tagline) g.tagline = j.tagline; }
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + (gLine.slice(12).match(/;\s*$/) || [""])[0] + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lJson = out.slice(lA + 1, lE).slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const LEG2 = { ...LEG };
const lp = (h, tag) => { const r = {}, p = legacyParts(h, r); assert(r.jsFail.length === 0, "legacy js fail " + tag + " " + JSON.stringify(r.jsFail).slice(0, 300)); assert(joinParts(p, h) === legacyHtml(h, {}), "parts mismatch " + tag); return p; };
for (const j of JOBS) { const pn = lp(j.html, "new " + j.card); const ro = {}, po = legacyParts(j.old, ro); assert(ro.jsFail.length === 0, "legacy js fail old " + j.card);
  assert(JSON.stringify(LEG[j.KL]) === JSON.stringify(po), "old legacy latest == old parts " + j.card);
  LEG2[j.KL] = pn; LEG2[j.KN] = po; for (const x of j.extra || []) LEG2[x.K] = lp(x.html, "extra " + x.K); }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out); const added = JOBS.flatMap((j) => [j.KN, ...(j.extra || []).map((x) => x.K)]); assert(Object.keys(after).length === NB + added.length, "slots after " + Object.keys(after).length);
const changed = JOBS.map((j) => j.KL);
for (const k of Object.keys(before)) if (!changed.includes(k)) assert(after[k][2] === before[k][2], "slot text changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k]).sort()) === JSON.stringify([...added].sort()), "only new slots");
const G1 = GS(out); for (const j of JOBS) { assert(G1[j.KL] === j.html && G1[j.KN] === j.old, "payloads " + j.card); for (const x of j.extra || []) assert(G1[x.K] === x.html, "extra payload " + x.K); }
for (const k of Object.keys(G0)) if (!changed.includes(k)) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (!changed.includes(k)) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
const cards = JOBS.map((j) => j.card);
assert(JSON.stringify(GAMES.filter((g) => !cards.includes(g.id))) === JSON.stringify(base.filter((g) => !cards.includes(g.id))), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
for (const j of JOBS) { const a = GAMES.find((g) => g.id === j.card), b = base.find((g) => g.id === j.card); const { versions: va, ...ra } = a, { versions: vb, ...rb } = b; if (j.tagline) { assert(ra.tagline === j.tagline, "tagline " + j.card); ra.tagline = rb.tagline; } assert(JSON.stringify(ra) === JSON.stringify(rb), "card fields " + j.card);
  const n = 2 + (j.extra || []).length; assert(JSON.stringify(va.slice(0, -n)) === JSON.stringify(vb.slice(0, -1)), "older versions untouched " + j.card); }
fs.writeFileSync(OUT, out);
fs.writeFileSync(R + "/index.assemble.json", JSON.stringify({ base: sha(src), out: sha(out), bytes: Buffer.byteLength(out), slotsBefore: NB, slotsAfter: Object.keys(after).length, added, latest: Object.fromEntries(JOBS.map((j) => [j.KL, j.hsha])) }, null, 1));
console.log("ASSEMBLE OK", sha(out), Object.keys(after).length, "slots; added", added.join(", "));
