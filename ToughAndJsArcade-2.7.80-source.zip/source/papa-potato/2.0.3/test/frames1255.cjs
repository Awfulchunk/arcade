const L=require("./lib.cjs");const fs=require("fs");
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:1});
for(const f of ["scenes.js","hardtests.js","hardmech.js"])await p.addScriptTag({content:fs.readFileSync(__dirname+"/"+f,"utf8")});
await p.evaluate(()=>{__tt.manual=true;});
for(const z of [0.72,1.35]){const urls=await p.evaluate((z)=>{var H=HT.H,s=H.fresh(101);s.s.coins=99;s.buyItem("roomKey");var F=PP2T.S.FIX,st=F.dropStand,pp=s.s.papa;pp.x=st.x;pp.y=st.y;pp.path=[];pp.moving=false;
 var out=[],info=[];[0,0.15,0.3,0.45,0.6,0.75,0.9,1].forEach(function(f){pp.task={type:"drop",stage:"act",t:f*0.45,via:"scan",target:null};var c=s.tgtCenter(pp.task);s.facePt(c[0],c[1]);if(!pp.hold.length)pp.hold.push(-1);
  var cv=document.createElement("canvas");cv.width=900;cv.height=1000;H.bbRender(cv,s,12.2,15.1,z);var q=PPDraw.tossPos(s,f);info.push(f+":"+(q?q.x.toFixed(0)+","+q.y.toFixed(0)+(q.M?" mouth "+q.M[0].toFixed(0)+","+q.M[1].toFixed(0):""):"-"));
  var w=Math.round(150*z),h=Math.round(120*z),c2=document.createElement("canvas");c2.width=w;c2.height=h;c2.getContext("2d").drawImage(cv,440-w*0.45,(z>1?400:440)-h*0.5,w,h,0,0,w,h);out.push(c2.toDataURL());});
 return {out:out,info:info};},z);
 urls.out.forEach((u,i)=>fs.writeFileSync(`/tmp/fr${z}-${i}.png`,Buffer.from(u.split(",")[1],"base64")));console.log(z,urls.info.join(" | "));}
console.log("errs",JSON.stringify(errs));await b.close();})();
