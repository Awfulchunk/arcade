// 2.0.2 staging screenshots (real play; forced states are named in the log) + While-You-Were-Gone reports
const L=require("./lib.cjs");const fs=require("fs");const OUT=process.env.SHOTS||"/tmp/stage202";fs.mkdirSync(OUT,{recursive:true});
async function until(p,cond,max,st){for(let i=0;i<max;i++){if(await p.evaluate(cond))return i;await p.evaluate(s=>__tt.step(s),st||5);}return -1;}
/* steps the sim frame by frame and feeds its events to the particle system exactly like the live loop (pumpEvents + stepParts) */
async function pumpUntil(p,cond,maxFrames,after){return p.evaluate((c,m,af)=>{var s=PP2T.sim(),f=new Function("e","return ("+c+")(e);"),hit=-1,ev=null;
  for(var i=0;i<m+af;i++){s.step(PP2T.S.DT);for(var k=0;k<s.events.length;k++){var e=s.events[k];PPDraw.emit(e);if(hit<0&&f(e)){hit=i;ev=e;}}s.events=[];PPDraw.stepParts(PP2T.S.DT);if(hit>=0&&i-hit>=af)break;}
  return {frame:hit,ev:ev};},cond.toString(),maxFrames,after||0);}
async function hideToast(p){await p.evaluate(()=>{document.getElementById("toast").className="off";});}
async function papaShot(p,name,z,w,h){await p.evaluate(z=>{var q=PP2T.sim().s.papa;PP2T.setCam(q.x,q.y,z);document.getElementById("toast").className="off";},z);await L.sleep(160);
  const r=await p.evaluate(()=>{var q=PP2T.sim().s.papa;var a=PP2T.project(q.x,q.y,0);var c=document.getElementById("cv").getBoundingClientRect();return [a[0]+c.left,a[1]+c.top];});
  w=w||300;h=h||360;await p.screenshot({path:OUT+"/"+name+".png",clip:{x:Math.max(0,Math.min(360-w,r[0]-w/2)),y:Math.max(0,r[1]-h*0.82),width:w,height:h}});console.log("shot",name);}
async function full(p,name,cam){if(cam)await p.evaluate(c=>PP2T.setCam(c[0],c[1],c[2]),cam);await hideToast(p);await L.sleep(250);await p.screenshot({path:OUT+"/"+name+".png"});console.log("shot",name);}
async function canvasShot(p,name,cam){await p.evaluate(c=>{PP2T.setCam(c[0],c[1],c[2]);var e=document.getElementById("toast");e.className="off";e.style.visibility="hidden";var w=document.getElementById("wantB");if(w)w.style.visibility="hidden";},cam);await L.sleep(200);
  const r=await p.evaluate(()=>{var c=document.getElementById("cv").getBoundingClientRect();return [c.left,c.top,c.width,c.height];});await p.screenshot({path:OUT+"/"+name+".png",clip:{x:r[0],y:r[1],width:r[2],height:r[3]}});await p.evaluate(()=>{document.getElementById("toast").style.visibility="";var w=document.getElementById("wantB");if(w)w.style.visibility="";});console.log("shot",name);}
async function btnShot(p,name){const e=await p.$("#bFlow");await e.screenshot({path:OUT+"/"+name+".png"});console.log("shot",name);}
async function fresh(b,seed){const {p,errs}=await L.open(b,[360,800],{dpr:2});await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});await p.evaluate(s=>{__tt.manual=true;__tt.setSeed(s);},seed);return {p,errs};}
(async()=>{const b=await L.browser();const E=[];const log={};
 let {p,errs}=await fresh(b,3);log.startObjs=await p.evaluate(()=>PP2T.sim().s.objs.map(o=>o.id+"@"+o.x+","+o.y));
 await full(p,"01-empty-starting-room",[6.5,11.5,0.5]);await canvasShot(p,"01b-kitchen-start-closer",[8,14,0.75]);
 await papaShot(p,"02-papa-closeup-2x",2.0,340,400);
 log.peel=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="peel"&&t.stage==="act"&&t.t>0.4;},900);await papaShot(p,"03-papa-peeling",1.7);
 log.dropNoKey=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="drop"&&t.stage==="act"&&t.t>0.15;},1500,2);
 await canvasShot(p,"04-shipping-machine-kitchen-side",[12.6,14.6,1.7]);
 await canvasShot(p,"05-raw-pile",[7,21.5,1.1]);await canvasShot(p,"05b-raw-pile-close",[5,22,1.8]);await canvasShot(p,"05c-pile-return-chute-west-end",[3.2,21.2,1.35]);
 E.push(...errs);await p.close();
 ({p,errs}=await fresh(b,5));await p.evaluate(()=>{var s=SC.rich();s.setBox("deliver",0);s.setBox("pool",0);});
 log.dropKey=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="drop"&&t.stage==="act"&&t.t>0.15;},3000,2);await canvasShot(p,"06-papa-drops-into-kitchen-side",[12.4,15.2,1.35]);await canvasShot(p,"06d-papa-in-front-of-shipping-DEFAULT-zoom",[12.4,15.2,0.72]);await canvasShot(p,"06z-papa-in-front-of-shipping-ZOOMED-OUT",[12.4,15.2,0.38]);await full(p,"06f-papa-in-front-of-shipping-full-screen-default-zoom",[12.4,15.2,0.72]);
 log.papaAtDrop=await p.evaluate(()=>{var q=PP2T.sim().s.papa;return [q.x,q.y];});
 log.dropCoin=await pumpUntil(p,e=>e.e==="coin"&&e.via==="drop",3000,24);await canvasShot(p,"06b-coin-popup-at-drop-plus-2c",[13,14.8,1.5]);
 log.spit=await until(p,()=>PP2T.sim().s.pots.some(q=>q.m==="scan"&&q.t>0.95&&q.t<1.1),6000,1);await canvasShot(p,"07-potato-out-of-wash-side-into-pool",[16.4,14.4,2.0]);
 log.wait=await until(p,()=>PP2T.sim().poolCount()>=16,9000,10);log.poolN=await p.evaluate(()=>PP2T.sim().poolCount());log.papaRoomWhilePiling=await p.evaluate(()=>PP2T.sim().s.papa.where);
 await canvasShot(p,"08-pool-pile-waiting",[17.6,13.6,1.4]);await canvasShot(p,"08b-wall-machine-both-sides",[14.5,13.5,0.95]);
 await p.evaluate(()=>PP2T.sim().setBox("pool",3));log.goesIn=await until(p,()=>PP2T.sim().s.stats.poolRuns>=1,6000,5);await papaShot(p,"09-papa-goes-in-and-scoops",1.4,340,380);
 log.holeCoin=await pumpUntil(p,e=>e.e==="coin"&&e.via==="hole"&&e.tot>=6,60*400,24);await canvasShot(p,"09b-coin-popup-after-wash-plus-4c",[25.2,1.2,1.4]);
 E.push(...errs);await p.close();
 /* 2.0.2 t1242: canal end drain, FLOW tap off with a backed-up canal, AUTO CLEANER with a potato inside, SORTER sending a dirty one back (real play: Papa tosses pool potatoes) */
 ({p,errs}=await fresh(b,9));log.canalSetup=await p.evaluate(()=>{var s=SC.rich();s.buyItem("roomKey");s.setBox("deliver",0);s.setBox("pool",2);s.buyItem("generator");var g=s.place("generator",21,9,0);
   s.buyItem("canalCleaner");var c=s.place("canalCleaner",22,15,0);s.buyItem("sorter");var so=s.place("sorter",25,9,0);s.calcPower();return [g.ok,c.ok,so.ok];});
 log.inCleaner=await until(p,()=>{var s=PP2T.sim(),m=s.canalMachs().filter(x=>x.o.id==="canalCleaner")[0];return m&&s.s.pots.some(q=>q.m==="canal"&&q.c>m.a+0.3&&q.c<m.b-0.3);},12000,2);
 await canvasShot(p,"21-auto-cleaner-potato-passing-through",[22.2,14.6,2.0]);
 log.drainShip=await pumpUntil(p,e=>e.e==="coin"&&e.via==="hole",60*240,10);await canvasShot(p,"19-canal-end-ship-drain",[25.0,1.3,1.6]);
 await p.evaluate(()=>{var s=PP2T.sim(),o=s.s.objs.filter(x=>x.id==="canalCleaner")[0];o.on=0;s.setBox("scrub",0);});log.sortBack=await pumpUntil(p,e=>e.e==="sortBack",60*300,20);await canvasShot(p,"22-sorter-sends-dirty-back-to-pool",[24.4,9.4,1.8]);
 await p.evaluate(()=>{var s=PP2T.sim(),o=s.s.objs.filter(x=>x.id==="canalCleaner")[0];o.on=1;s.setBox("scrub",1);});
 await p.evaluate(()=>{PP2T.setCam(24,14.5,1.4);});await L.sleep(120);const gp=await p.evaluate(()=>PP2T.project(24.5,15.5,0.3));await L.touchTapXY(p,gp[0],gp[1]);await L.sleep(100);log.flowOffByTap=await p.evaluate(()=>PP2T.sim().s.flowOff);
 log.backedUp=await until(p,()=>{var s=PP2T.sim(),ga=s.gateC();return s.s.pots.filter(q=>q.m==="canal"&&q.c<ga).length>=8;},6000,5);log.queued=await p.evaluate(()=>{var s=PP2T.sim(),ga=s.gateC();return s.s.pots.filter(q=>q.m==="canal"&&q.c<ga).length;});log.canalN=await p.evaluate(()=>PP2T.sim().s.pots.filter(q=>q.m==="canal").length);
 await canvasShot(p,"20-flow-tap-off-canal-backed-up",[22.4,14.2,1.45]);await canvasShot(p,"24b-flow-label-OFF-closeup-map",[24.3,15.0,1.7]);await btnShot(p,"24d-flow-button-OFF-menu");await full(p,"20b-flow-off-button-and-canal",[22.6,12.5,0.9]);
 await p.evaluate(()=>{PP2T.setCam(24,14.5,1.4);});await L.sleep(120);const gp2=await p.evaluate(()=>PP2T.project(24.5,15.5,0.3));await L.touchTapXY(p,gp2[0],gp2[1]);await L.sleep(100);log.flowOnByTap=await p.evaluate(()=>PP2T.sim().s.flowOff);await p.evaluate(()=>__tt.step(240));await canvasShot(p,"20c-flow-on-again-canal-moving",[22.4,14.2,1.45]);await canvasShot(p,"24a-flow-label-ON-closeup-map",[24.3,15.0,1.7]);await btnShot(p,"24c-flow-button-ON-menu");
 await p.evaluate(()=>{document.querySelector('.nb[data-n="help"]').click();});await L.sleep(200);await p.screenshot({path:OUT+"/23-custom-game-in-help.png"});await p.evaluate(()=>{document.getElementById("sheetX").click();});
 E.push(...errs);await p.close();
 ({p,errs}=await fresh(b,7));await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=99;s.buyItem("broomDustpan");});await p.evaluate(()=>__tt.step(60));
 log.broomStart=await p.evaluate(()=>PP2T.sim().s.papa.broomHeld);await canvasShot(p,"10-broom-parked-on-wall",[11.6,-1.4,1.7]);
 await p.evaluate(()=>{var s=PP2T.sim();for(var i=0;i<30;i++)s.addPeel(5+(i%6)*0.4,12+((i/6)|0)*0.4);s.setBox("clean",10);});
 log.sweep=await until(p,()=>{var s=PP2T.sim(),t=s.s.papa.task;return t&&t.type==="sweep"&&t.stage==="act"&&s.s.papa.broomHeld;},2000,2);await papaShot(p,"11-sweeping-with-broom",1.7);
 log.park=await until(p,()=>{var s=PP2T.sim();return !s.s.papa.broomHeld&&s.s.peels.length<=10;},6000,5);log.peelingAfter=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="peel"&&t.stage==="act";},3000,5);
 await canvasShot(p,"12-broom-parked-again-papa-peeling",[10,6,0.9]);
 E.push(...errs);await p.close();
 ({p,errs}=await fresh(b,11));await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=99;s.buyItem("calendar");s.place("calendar",3.5,0.5,0);});
 await canvasShot(p,"13-calendar-still",[1.4,-2.2,1.7]);
 log.calBoundary=await p.evaluate(()=>{var s=PP2T.sim().s,day=Math.floor((s.t*2+480)/1440);return (1440*(day+1)-480)/2-s.t;});
 await p.evaluate(n=>__tt.step(n),Math.max(0,Math.floor((log.calBoundary-1.5)*60)));
 log.calFlip=await until(p,()=>{var s=PP2T.sim().s;return s.calFlipT>=0&&s.t-s.calFlipT>=0.3&&s.t-s.calFlipT<0.6;},400,3);await canvasShot(p,"14-calendar-mid-flip-at-day-change",[1.4,-2.2,1.7]);
 await p.evaluate(()=>__tt.step(300));await canvasShot(p,"15-calendar-still-after-flip",[1.4,-2.2,1.7]);
 log.calFlipT=await p.evaluate(()=>PP2T.sim().s.calFlipT);
 E.push(...errs);await p.close();
 ({p,errs}=await fresh(b,13));await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=99;s.s.level=3;s.buyItem("radio");s.place("radio",3,5,0);s.setBox("radio",1);s.s.coins=2;s.s.want={id:"stDisco",kind:"station",name:"DISCO SPUD STATION",price:12,t0:s.s.t};});
 await p.evaluate(()=>__tt.step(5));await full(p,"16-papa-wants-disco-station",[5,8,0.8]);
 await L.touchTap(p,'.nb[data-n="radio"]');await L.sleep(300);await p.screenshot({path:OUT+"/16b-radio-menu-disco-locked.png"});console.log("shot radio locked");
 log.radioLockedTxt=await p.evaluate(()=>{var e=document.getElementById("ovl");return e?e.innerText.replace(/\s+/g," ").slice(0,400):"";});
 await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=12;s.giveWant(false);});await L.touchTap(p,'#sheetX');await L.sleep(250);await L.touchTap(p,'.nb[data-n="radio"]');await L.sleep(300);
 await p.screenshot({path:OUT+"/16c-radio-menu-disco-earned.png"});console.log("shot radio earned");log.radioOwnedTxt=await p.evaluate(()=>{var e=document.getElementById("ovl");return e?e.innerText.replace(/\s+/g," ").slice(0,400):"";});log.radioSt=await p.evaluate(()=>PP2T.sim().s.decor.radioSt);
 E.push(...errs);await p.close();
 const now=Date.UTC(2026,10,26,4,0,0);
 for(const [n,sec] of [["1m",60],["5m",300],["1h",3600],["8h",8*3600],["3d",3*86400],["30d",30*86400],["backward",-3600]]){
  ({p,errs}=await fresh(b,21));
  await p.evaluate(()=>{var s=SC.rich();s.setBox("deliver",0);s.buyItem("radio");s.place("radio",3,5,0);s.buyItem("catBed");s.place("catBed",2,12,0);s.s.coins=40;});
  await p.evaluate(()=>__tt.step(1200));
  const r=await p.evaluate((now,sa)=>{var r=PP2T.awayAt(now,sa);var x=PP2T.sim().s.lastAway;return x?{away:x.awayTxt,coins:x.coins,earned:x.earned,spent:x.spent,peeled:x.peeled,shipped:x.shipped,naps:x.naps,meals:x.meals,jams:x.jams,eff:x.eff,workShare:x.workShare,bought:x.bought,wants:x.wants,backward:x.backward}:null;},now,now-sec*1000);
  log["away-"+n]=r;await L.sleep(400);await p.screenshot({path:OUT+"/17-while-you-were-gone-"+n+".png"});console.log("away",n,JSON.stringify(r).slice(0,300));
  E.push(...errs);await p.close();}
 fs.writeFileSync(OUT+"/stage-log.json",JSON.stringify({log,errors:E},null,1));console.log("LOG",JSON.stringify(log).slice(0,1500));console.log("ERRORS",JSON.stringify(E));await b.close();})();
