(function(){var T=HT.T,H=HT.H,S=HT.S;
function R(ok,d){return {pass:!!ok,d:d};}
T("mech:basic-loop grab-peel-ship (wall SHIPPING machine, no key)",function(sd){var s=H.fresh(sd);var n=H.run(s,240,function(s){return s.s.shipped>=4;});return R(n>0&&s.s.coins>=8&&s.s.stats.peeled>=4,"shipped "+s.s.shipped+" coins "+s.s.coins+" peeled "+s.s.stats.peeled+" in "+(n/60).toFixed(0)+"s");});
T("mech:eat order + auto eat",function(sd){var s=H.fresh(sd);s.s.food=3;s.s.papa.hunger=30;s.order("eat");var n=H.run(s,30,function(s){return s.s.food===2;});var h1=s.s.papa.hunger;
  s.setBox("eat",40);s.s.papa.hunger=35;var n2=H.run(s,40,function(s){return s.s.food===1;});return R(n>0&&n2>0&&h1>=80,"order ate (hunger "+h1.toFixed(0)+"), auto ate under 40");});
T("mech:no puke at all (eating when full just tops out at 100)",function(sd){var s=H.fresh(sd);s.s.food=3;s.s.papa.hunger=85;s.order("eat");var mx=0;H.run(s,30,function(s){mx=Math.max(mx,s.s.papa.hunger);return false;});
  var keys=JSON.stringify(s.s)+JSON.stringify(Object.keys(PP2T.sim().constructor.prototype))+JSON.stringify(S.ITEMS)+JSON.stringify(S.COMMANDS);return R(mx<=100.001&&s.s.food===2&&!/puke/i.test(keys)&&s.s.puke===undefined,"ate at 85 -> max hunger "+mx.toFixed(1)+", no puke state, task, stat or text");});
T("mech:nap sets sack down + picks it up (never sleeps with it)",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("carrySack");s.s.papa.energy=20;s.setBox("wake",60);s.order("nap");var bad=0,ly=0;
  var n=H.run(s,120,function(s){var t=s.s.papa.task;if(t&&t.type==="nap"&&t.lying){ly=1;if(s.s.papa.sack.on)bad++;}return ly&&t&&t.type!=="nap";});var sx=s.s.papa.sack.x,sy=s.s.papa.sack.y,w=s.walkable(Math.floor(sx),Math.floor(sy));
  var m=H.run(s,60,function(s){return s.s.papa.sack.on;});return R(ly&&bad===0&&w&&m>0&&s.s.stats.sackDowns>=1,"lying "+ly+", frames with sack on in bed "+bad+", sack set at "+sx+","+sy+" (free tile), picked up again "+(m>0));});
T("mech:doze when out of energy (no NAP set)",function(sd){var s=H.fresh(sd);s.s.papa.energy=0.3;var n=H.run(s,10,function(s){var t=s.s.papa.task;return t&&t.type==="doze";});var e0=s.s.papa.energy;H.run(s,5);return R(n>0&&s.s.papa.energy>e0,"dozed, energy "+e0.toFixed(1)+" -> "+s.s.papa.energy.toFixed(1));});
T("mech:sweep peels + broom only in his hands",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("broomDustpan");for(var i=0;i<40;i++)s.addPeel(3+(i%8)*0.4,12+((i/8)|0)*0.4);s.setBox("clean",10);var sweeping=0;
  var n=H.run(s,90,function(s){var t=s.s.papa.task;if(t&&t.type==="sweep"&&t.stage==="act")sweeping++;return s.s.peels.length<=10;});return R(n>0&&sweeping>0&&s.s.equip.broomDustpan,"40 peels -> "+s.s.peels.length+" in "+(n/60).toFixed(0)+"s (broom equipped)");});
T("mech:rinse hands at the table sink",function(sd){var s=H.fresh(sd);s.s.papa.hands=10;s.setBox("rinse",30);var n=H.run(s,30,function(s){return s.s.papa.hands>=99;});return R(n>0,"hands 10 -> "+s.s.papa.hands.toFixed(0));});
T("mech:door locked without key, open with key",function(sd){var s=H.fresh(sd);var a=s.walkable(14,3),r=s.route(s.spotsFor(s.objsOf("tub")[0]));s.s.coins=99;s.buyItem("roomKey");var b=s.walkable(14,3),r2=s.route(s.spotsFor(s.objsOf("tub")[0]));return R(!a&&!r&&b&&r2,"locked: no route; key: route "+(r2?r2.path.length:0)+" steps");});
T("mech:SHIPPING machine -> pool (waits) -> Papa scoops -> tub -> canal -> ship hole",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.setBox("deliver",0);s.setBox("pool",2);var hole=0,inPool=0;
  var n=H.run(s,500,function(s){inPool=Math.max(inPool,s.s.pots.filter(function(q){return q.m==="pool";}).length);s.events.forEach(function(e){if(e.e==="coin"&&e.via==="hole")hole++;});s.events=[];return hole>=2;});
  return R(n>0&&s.s.stats.poolRuns>=2&&inPool>=1,"pool held up to "+inPool+", Papa scooped "+s.s.stats.poolRuns+"x, 2 shipped through the hole in "+(n/60).toFixed(0)+"s");});
T("mech:pool potatoes WAIT there until Papa comes (EMPTY POOL AT)",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.setBox("pool",0);__tt.flood(5);var orig=s.s.pots.filter(function(q){return q.m==="pool";}),ids=orig.map(function(q){return q.u;}),d0=orig.map(function(q){return q.d;}).join(",");
  H.run(s,90);var left=s.s.pots.filter(function(q){return q.m==="pool"&&ids.indexOf(q.u)>=0;}),d1=left.map(function(q){return q.d;}).join(",");var held=left.length===5&&d0===d1&&s.s.stats.poolRuns===0;
  s.setBox("pool",3);var n=H.run(s,240,function(s){return s.s.pots.filter(function(q){return q.m==="pool";}).length===0;});
  return R(held&&n>0&&s.s.stats.poolRuns>=5,"OFF: 5 stayed 90 s untouched (dirt unchanged); at 3 he came and scooped all 5 ("+s.s.stats.poolRuns+" scoops) in "+(n/60).toFixed(0)+"s");});
T("mech:raw pile is finite and potatoes come back down the return pipe",function(sd){var s=H.fresh(sd);var p0=s.s.pile,bad=0,minP=99,rets=0,landed=0;
  H.run(s,240,function(s){var tot=s.s.pile+s.s.ret.length+s.s.pots.length;if(tot!==S.C.potTotal)bad++;minP=Math.min(minP,s.s.pile);if(s.s.ret.length)rets=1;s.events.forEach(function(e){if(e.e==="land")landed+=e.n;});s.events=[];return false;});
  return R(p0===S.C.potTotal&&p0===852&&bad===0&&minP<p0&&rets&&landed>0,"start "+p0+" (the full 0.4.11 mound); pile + returning + in play stayed "+S.C.potTotal+" every frame; pile low "+minP+"; "+landed+" landed back from the pipe");});
T("mech:empty starting room (no machines, belts or generators)",function(sd){var s=H.fresh(sd);var ids=s.s.objs.map(function(o){return o.id;}).sort().join(",");var m=s.s.objs.filter(function(o){return S.isMach(o.id)||o.id==="belt"||o.id==="generator";}).length;
  return R(ids==="bed,cooler,table,tub"&&m===0&&!Object.keys(s.s.inv).some(function(k){return s.s.inv[k]>0;}),"start objects: "+ids+" (the basic furniture he needs); machines "+m);});
T("mech:Papa WANTS something + you GET IT for him",function(sd){var s=H.fresh(sd);s.s.coins=99;s.s.papa.hunger=90;var n=H.run(s,60,function(s){if(!s.s.want&&s.s.wantT>1)s.s.wantT=0.02;return !!s.s.want;});var w=s.s.want,m0=s.moodCalc();
  if(!w)return R(false,"no want formed");var c0=s.s.coins,r=s.giveWant(false);var got=w.kind==="food"?s.s.food>=1:(s.wearing(w.id)&&s.s.owned[w.id]===1);
  return R(n>0&&r.ok&&got&&s.s.coins===c0-w.price&&s.moodCalc()>m0&&!s.s.want&&s.s.papa.wantFlash>0,"wanted "+w.name+" ("+w.price+"c), got it, mood "+m0+" -> "+s.moodCalc()+", next want later ("+Math.round(s.s.wantT)+"s)");});
T("mech:hungry Papa with no food wants a snack",function(sd){var s=H.fresh(sd);s.s.food=0;s.s.papa.hunger=30;s.s.wantT=0.02;H.run(s,1);var w=s.s.want;return R(w&&w.id==="snack","want: "+(w?w.name:"none"));});
T("mech:accessories swap (one hat at a time, shades + bow tie)",function(sd){var s=H.rich(sd);["beanie","topHat","sunglasses","bowTie"].forEach(function(i){s.buyItem(i);});var a1=JSON.stringify(s.s.acc);s.wear("beanie",true);var a2=s.s.acc.hat;s.wear("beanie",false);var a3=s.s.acc.hat;
  var str=s.saveStr();s.reset(sd);s.load(str);var a4=JSON.stringify(s.s.acc);return R(a2==="beanie"&&a3==="chef"&&s.s.acc.glasses===1&&s.s.acc.bow===1&&a4===JSON.stringify({hat:"chef",glasses:1,bow:1,toy:0}),"after buying "+a1+"; beanie on "+a2+", off "+a3+"; saved+loaded "+a4);});
T("mech:save keeps the waiting pool, the pile, wants and the look",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.buyItem("sunglasses");__tt.flood(4);s.s.want={id:"bowTie",kind:"acc",name:"BOW TIE",price:6,t0:0};var c0=s.s.coins;
  var str=s.saveStr();s.reset(sd);s.load(str);var pool=s.s.pots.filter(function(q){return q.m==="pool";}).length;return R(pool===4&&s.s.coins===c0&&s.s.want&&s.s.want.id==="bowTie"&&s.s.acc.glasses===1&&s.s.pile+s.s.pots.length<=S.C.potTotal,"pool "+pool+" back in the pool (not paid out), coins "+s.s.coins+", want "+(s.s.want&&s.s.want.id)+", pile "+s.s.pile);});
function awayRun(sd,sec,setup){var s=H.fresh(sd);s.s.coins=500;s.buyItem("roomKey");s.setBox("deliver",1);s.buyItem("carrySack");if(setup)setup(s);H.run(s,60);s.s.food=3;var c0=s.s.coins,now=Date.UTC(2026,10,26,10,0,0),t0=performance.now();var r=PPAway.run(s,now,now-sec*1000,sd);return {s:s,r:r,ms:performance.now()-t0,c0:c0};}
T("mech:AUTO MODE 1 min / 1 h / 8 h / 3 days / 30 days (unlimited, under 1 s each, at most 50%)",function(sd){var out=[],ok=true;[["1m",60],["1h",3600],["8h",28800],["3d",259200],["30d",2592000]].forEach(function(a){var x=awayRun(sd,a[1]),r=x.r;
    var good=r&&x.ms<1000&&r.eff<=0.5001&&x.s.s.coins===x.c0+r.coins&&isFinite(x.s.s.papa.hunger)&&r.timeline.length>=1;if(!good)ok=false;out.push(a[0]+": +"+r.coins+"c, "+r.peeled+" peeled, "+r.shipped+" shipped, "+r.naps+" naps, "+r.meals+" meals, "+r.jams+" jams, eff "+r.eff+", "+Math.round(x.ms)+"ms");});
  return R(ok,out.join(" | "));});
T("mech:AUTO MODE backward clock counts as zero",function(sd){var s=H.fresh(sd);var c0=s.s.coins,now=Date.UTC(2026,10,26,10,0,0);var r=PPAway.run(s,now,now+3*3600e3,sd);return R(r&&r.backward&&r.away===0&&s.s.coins===c0,"backward: "+JSON.stringify({backward:r&&r.backward,away:r&&r.away,coins:s.s.coins-c0}));});
T("mech:AUTO MODE varies by seed (bursty), machines jam while he relaxes",function(sd){var res=[],jams=0;for(var k=1;k<=8;k++){var x=awayRun(sd*100+k,8*3600,function(s){s.s.level=3;s.s.coins=2000;s.buyItem("hopper");s.place("hopper",6,18,0);s.buyItem("radio");s.place("radio",3,5,0);});res.push(x.r.coins);jams+=x.r.jams;}
  var mn=Math.min.apply(null,res),mx=Math.max.apply(null,res),uniq={};res.forEach(function(v){uniq[v]=1;});return R(Object.keys(uniq).length>=5&&mx>mn&&jams>0,"8 h away, 8 seeds: coins "+res.join(", ")+"; jams "+jams);});
T("mech:AUTO MODE: Papa works for what he wants, buys it, relaxes",function(sd){var x=awayRun(sd,3*86400),r=x.r;var bought=r.wants.filter(function(w){return /bought/.test(w);});
  return R(bought.length>0&&/then /.test(bought[0])&&r.bought.length>0&&r.bought.every(function(n){var it=S.ITEMS.filter(function(i){return i.name===n;})[0];return it&&x.s.s.owned[it.id]>0;}),"e.g. "+bought.slice(0,2).join(" / ")+"; new on Papa: "+r.bought.join(", "));});
T("mech:CARRY through door, scrub at tub, toss, 5c",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.buyItem("carrySack");s.setBox("deliver",2);var five=0;
  var n=H.run(s,500,function(s){s.events.forEach(function(e){if(e.e==="coin"&&e.v>=5)five++;});s.events=[];return five>=2;});return R(n>0&&s.s.stats.doorTrips>=1&&s.s.stats.scrubbed>=2,"door trips "+s.s.stats.doorTrips+", scrubbed "+s.s.stats.scrubbed+", 5c sales "+five);});
T("mech:player brush cleans pool/canal/tub potatoes",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");__tt.flood(3);var q=s.s.pots.filter(function(p){return p.m==="pool";})[0];var d0=q.d;var k=0;while(q.d>0.15&&k<10){s.brush(q.x,q.y,0.2);k++;}
  var tub=s.objsOf("tub")[0],t=s.newPot(1,"tub");t.o=tub.u;tub.q.push(t.u);s.layout();var k2=0;while(t.d>0.15&&k2<10){s.brush(t.x,t.y,0.2);k2++;}return R(q.d<=0.15&&t.d<=0.15&&s.s.stats.brushed>=2,"pool potato clean after "+k+" passes, tub potato after "+k2);});
function line(s){var out=[];s.s.coins=99999;s.s.level=5;s.buyItem("belt",20);s.buyItem("belt",20);s.buyItem("belt",20);s.buyItem("hopper");s.buyItem("autoPeeler");s.buyItem("washer");s.buyItem("generator");s.buyItem("generator");s.buyUp("gen");s.buyUp("gen");
  var L=function(r,m){if(!r.ok)out.push(m+":"+r.why);return r;};L(s.place("hopper",6,18,3),"h");for(var y=17;y>=15;y--)L(s.place("belt",6,y,3),"b");L(s.place("autoPeeler",6,12,3),"ap");L(s.place("belt",6,11,0),"b");L(s.place("belt",7,11,0),"b");L(s.place("belt",8,11,3),"b");L(s.place("belt",8,10,3),"b");
  L(s.place("washer",8,7,3),"w");for(var x2=8;x2<=11;x2++)L(s.place("belt",x2,6,0),"b");for(var y2=6;y2<=13;y2++)L(s.place("belt",12,y2,1),"b");L(s.place("belt",12,14,0),"b");L(s.place("generator",10,13,0),"g");L(s.place("generator",10,2,0),"g");return out;}
T("mech:belt line hopper -> auto peeler -> washer -> wall SHIPPING machine",function(sd){var s=H.fresh(sd);var e=line(s);s.setBox("fix",1);var clean=0;var n=H.run(s,300,function(s){s.events.forEach(function(ev){if(ev.e==="coin"&&ev.via==="chute"&&ev.v>=4)clean++;});s.events=[];return clean>=3;});
  var st=s.s.stats;return R(!e.length&&n>0&&st.machPeeled>=3&&st.drumWashed>=3,"placement errs "+e.length+" "+e.join(",")+"; machine peeled "+st.machPeeled+", drum washed "+st.drumWashed+", clean chute sales "+clean+", belt moves "+st.beltMoved+", jams "+st.jams+" fixed "+st.fixed);});
T("mech:tap a belt to turn it",function(sd){var s=H.rich(sd);s.buyItem("belt",1);var o=s.place("belt",3,5,0).o;var dirs=[o.r];for(var i=0;i<4;i++){s.rotate(o.u);dirs.push(o.r);}return R(dirs.join(",")==="0,1,2,3,0","directions "+dirs.join(","));});
T("mech:power: unpowered belt stops, generator powers, over capacity",function(sd){var s=H.rich(sd);s.buyItem("belt",20);var b=s.place("belt",8,15,0).o;var q=s.newPot(0,"belt");q.o=b.u;q.p=0;H.run(s,2);var p0=q.p;
  s.buyItem("generator");s.place("generator",10,16,0);H.run(s,0.4);var p1=q.p;s.calcPower();var src=s.power.src.filter(function(x){return x.id==="generator";})[0];
  for(var x=2;x<13;x++)for(var y=12;y<15;y++)s.place("belt",x,y,0);s.calcPower();var unp=s.s.objs.filter(function(o){return o.id==="belt"&&!s.powered(o);}).length;return R(p0===0&&p1>0&&src.used<=src.cap&&unp>0,"no power: potato stayed at "+p0+"; with generator moved to "+p1.toFixed(2)+"; load "+src.used+"/"+src.cap+", "+unp+" belts over capacity stay off");});
T("mech:jam + FIX JAMS auto + FIX button",function(sd){var s=H.fresh(sd);line(s);H.run(s,20);var ap=s.objsOf("autoPeeler")[0];ap.jam=1;s.setBox("fix",1);var n=H.run(s,60,function(){return !ap.jam;});
  s.setBox("fix",0);ap.jam=1;H.run(s,10);var still=ap.jam;s.sendFix(ap.u);var m=H.run(s,60,function(){return !ap.jam;});return R(n>0&&still&&m>0,"auto fix in "+(n/60).toFixed(1)+"s; with FIX JAMS off it stays jammed; FIX order cleared it in "+(m/60).toFixed(1)+"s");});
T("mech:machine ON/OFF",function(sd){var s=H.fresh(sd);line(s);H.run(s,15);var hp=s.objsOf("hopper")[0];s.machToggle(hp.u);var f0=hp.fed|0;H.run(s,10);var f1=hp.fed|0;s.machToggle(hp.u);H.run(s,10);return R(hp.on===1&&f1===f0&&(hp.fed|0)>f1,"off: fed stayed "+f0+"; on again: "+(hp.fed|0));});
T("mech:placement rules (pile, water, doorway, block, rug under furniture, wall snap)",function(sd){var s=H.rich(sd);s.buyItem("roomKey");["fan","rug","clock","bookshelf"].forEach(function(i){s.buyItem(i);});var r=[];
  r.push(!s.canPlace("fan",2,20,0).ok);r.push(!s.canPlace("fan",18,13,0).ok);r.push(!s.canPlace("fan",13,3,0).ok);r.push(!s.canPlace("fan",15,4,0).ok);
  r.push(s.canPlace("rug",5,9,0).ok);var w=s.place("clock",13.5,0.5,0);r.push(w.ok&&w.o.wall&&w.o.x!==13);
  /* try to box in the cooler with fans: the last one must be refused */
  s.s.coins=99999;var refused=0,why="",ids=["lamp","plant","radio","aquarium"];ids.forEach(function(i){s.buyItem(i);});var cool=s.objsOf("cooler")[0];S.around(S.fp(cool)).forEach(function(t,k){var c=s.place(ids[k],t[0],t[1],0);if(!c.ok&&/block/.test(c.why)){refused++;why=c.why;}});
  r.push(refused>0&&H.reachAll(s).length===0);return R(r.every(Boolean),"pile/water/doorway refused, rug under the table ok, clock snapped off the broom spot, boxing in the cooler refused "+refused+"x ("+why+"), all reachable "+r.join(","));});
T("mech:save + load round trip, bad save ignored",function(sd){var s=H.fresh(sd);line(s);H.run(s,30);var str=s.saveStr(),o=JSON.parse(str);var n0=s.s.objs.length,c0=o.coins;
  s.reset(sd);var ok=s.load(str);var n1=s.s.objs.length;var bad=s.load("{garbage");var bad2=s.load(JSON.stringify({v:1,coins:"x",objs:[{id:"hopper",x:-50,y:9999},{id:"fan",x:2,y:20}]}));
  return R(ok&&n1===n0&&s.s.coins>=0&&!bad&&bad2&&s.s.objs.every(function(q){return q.x>=0&&q.y>=0;}),"objects "+n0+" -> "+n1+", coins kept "+c0+", garbage rejected, out-of-map objects refused");});
T("mech:levels lock and unlock shop items",function(sd){var s=H.fresh(sd);s.s.coins=5000;var a=s.buyItem("autoPeeler");var lv=0;while(s.buyLevel().ok)lv++;var b=s.buyItem("autoPeeler");return R(!a.ok&&lv===4&&b.ok&&s.s.level===5,"LV1 refused ("+a.why+"), bought 4 levels, then ok");});
T("mech:mood meter rises with decor, drops with mess",function(sd){var s=H.rich(sd);var m0=s.moodCalc();["clock","calendar","plant","poster"].forEach(function(i){s.buyItem(i);s.place(i,i==="plant"?3:1.5,i==="plant"?4:0.5,0);});var m1=s.moodCalc();for(var i=0;i<60;i++)s.addPeel(4+(i%6)*0.3,14+((i/6)|0)*0.3);var m2=s.moodCalc();return R(m1>m0&&m2<m1,"mood "+m0+" -> "+m1+" with decor -> "+m2+" with 60 peels");});
T("mech:radio on/off + stations",function(sd){var s=H.rich(sd);s.buyItem("radio");var r=s.place("radio",3,4,0);s.setBox("radio",1);s.s.decor.radioSt=1;var w=s.workMul();s.setBox("radio",0);var w2=s.workMul();return R(r.ok&&w>w2,"work x"+w.toFixed(3)+" on vs x"+w2.toFixed(3)+" off");});
T("mech:cat wanders and naps",function(sd){var s=H.rich(sd);s.buyItem("catBed");s.place("catBed",4,16,0);var pos=[],st={};H.run(s,90,function(s){st[s.s.cat.st]=1;if(s.s.tick%300===0)pos.push(Math.round(s.s.cat.x)+","+Math.round(s.s.cat.y));return false;});var uniq={};pos.forEach(function(p){uniq[p]=1;});return R(Object.keys(uniq).length>=2&&st.walk,"cat states "+Object.keys(st).join("/")+", spots "+Object.keys(uniq).length);});
T("mech:TV watch restores energy",function(sd){var s=H.rich(sd);s.buyItem("tvArmchair");var r=s.place("tvArmchair",8,19,0);if(!r.ok)r=s.place("tvArmchair",2,10,0);s.setBox("tv",1);s.setBox("watch",50);s.s.papa.energy=30;var sat=0;H.run(s,40,function(s){var t=s.s.papa.task;if(t&&t.type==="watch"&&t.sit)sat=1;return sat&&s.s.papa.energy>40;});return R(r.ok&&sat&&s.s.papa.energy>35,"sat in the armchair, energy "+s.s.papa.energy.toFixed(0));});
T("mech:plant watering",function(sd){var s=H.rich(sd);s.buyItem("plant");s.place("plant",3,4,0);s.s.plant.dry=80;s.setBox("water",50);var n=H.run(s,60,function(s){return s.s.plant.dry<5;});return R(n>0,"watered in "+(n/60).toFixed(0)+"s");});
T("mech:TOSS clean tub potatoes and tub belt-out",function(sd){var s=H.rich(sd);s.buyItem("roomKey");var tub=s.objsOf("tub")[0];for(var i=0;i<3;i++){var q=s.newPot(1,"tub");q.d=0;q.o=tub.u;tub.q.push(q.u);}var n=H.run(s,60,function(){return tub.q.length===0;});return R(n>0,"he took the clean ones out and tossed them into the canal in "+(n/60).toFixed(0)+"s");});
T("mech:sack carry capacity",function(sd){var s=H.rich(sd);var c1=s.carryCap();s.buyItem("carrySack");var c2=s.carryCap();s.buyUp("bag");var c3=s.carryCap();return R(c1===1&&c2===3&&c3===4,"hands "+c1+", sack "+c2+", bigger sack "+c3);});
T("mech:upgrades all buyable to max",function(sd){var s=H.rich(sd);var bad=[];S.UPS.forEach(function(u){for(var i=0;i<u.max;i++){var r=s.buyUp(u.id);if(!r.ok)bad.push(u.id);}if(s.buyUp(u.id).ok)bad.push(u.id+" over max");});return R(!bad.length,bad.join(",")||"all 11 upgrades maxed, none past max");});
T("mech:long soak 20 min no NaN / caps held",function(sd){var s=H.fresh(sd);line(s);s.buyItem("roomKey");s.setBox("deliver",1);s.setBox("eat",40);s.setBox("nap",25);s.setBox("clean",30);s.s.food=9;var bad=0;
  for(var i=0;i<20*60*60;i++){s.step(1/60);if(i%600===0){var st=JSON.stringify(s.s,function(k,v){return typeof v==="number"&&!isFinite(v)?"BAD":v;});if(st.indexOf('"BAD"')>=0)bad++;if(s.s.pots.length>S.POT_CAP||s.s.peels.length>S.PEEL_CAP)bad++;}}s.events=[];
  return R(!bad&&s.s.shipped>50,"20 min game time: shipped "+s.s.shipped+", coins "+s.s.coins+", pots "+s.s.pots.length+", peels "+s.s.peels.length+", bad "+bad);});
})();
/* ---------------- 2.0.2 checks ---------------- */
(function(){var T=HT.T,H=HT.H,S=HT.S;function R(ok,d){return {pass:!!ok,d:d};}
function poolN(s){return s.s.pots.filter(function(q){return q.m==="pool";}).length;}
T("202:wall SHIPPING machine -> pool pile waits until Papa goes into the wash room",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.setBox("deliver",0);s.setBox("pool",0);
  var drops=0,scanSeen=0,spat=0,via={},poolMax=0,inWash=0;
  H.run(s,240,function(s){s.events.forEach(function(e){if(e.e==="coin")via[e.via]=(via[e.via]|0)+1;});s.events=[];s.s.pots.forEach(function(q){if(q.m==="scan"){scanSeen=1;if(q.t>=0.75)spat=1;}});poolMax=Math.max(poolMax,poolN(s));if(S.roomOf(Math.floor(s.s.papa.x),Math.floor(s.s.papa.y))==="w")inWash++;return poolN(s)>=8;});
  var n8=poolN(s),runs0=s.s.stats.poolRuns,coinsOff=Object.keys(via).length;
  s.setBox("pool",3);var n=H.run(s,300,function(s){return s.s.stats.poolRuns>=3;});
  return R(scanSeen&&spat&&n8>=8&&runs0===0&&inWash===0&&n>0,"with POOL: potatoes went in the kitchen side, came out the wash side ("+(spat?"spat into the pool":"never seen")+"); pool piled up to "+n8+" while he stayed in the kitchen ("+inWash+" frames in wash room, 0 scoops, coins paid "+JSON.stringify(via)+"); EMPTY POOL AT 3 -> he went in and scooped "+s.s.stats.poolRuns+"x in "+(n/60).toFixed(0)+"s");});
T("202:pay (Jay t1240): 2c the moment he drops one in the machine, about 4c more when it is finished in the wash room",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");s.setBox("deliver",0);s.setBox("pool",0);
  var drops=[],bad=0;H.run(s,200,function(s){s.events.forEach(function(e){if(e.e==="coin"&&e.via==="drop"){drops.push(e.v);}});s.events=[];return drops.length>=3;});
  var c0=s.s.coins,pq=s.s.pots.filter(function(q){return q.m==="pool"||q.m==="scan";}),allPre=pq.length>0&&pq.every(function(q){return q.pre===2;});
  /* save mid-pool: pre-paid potatoes are not paid twice; an old (not pre-paid) pool potato keeps its full value */
  var o=JSON.parse(s.saveStr());var okSave=o.coins===c0&&Array.isArray(o.poolPre)&&o.poolPre.length===o.pool.length&&o.poolPre.every(function(v){return v===1;});
  var old=JSON.parse(JSON.stringify(o));delete old.poolPre;s.reset(sd);s.load(JSON.stringify(old));var mig=s.s.pots.filter(function(q){return q.m==="pool";}),migNoPre=mig.length>0&&mig.every(function(q){return !q.pre;});
  s.reset(sd);s.load(JSON.stringify(o));var re=s.s.pots.filter(function(q){return q.m==="pool";}),rePre=re.length>0&&re.every(function(q){return q.pre===2;});
  /* a finished clean one pays +4 at the hole (6c in all); a dirty one pays less */
  var q=re[0];q.k=1;q.d=0;var cA=s.s.coins;s.events=[];s.ship(q,"hole");var hole=s.s.coins-cA,ev=s.events.filter(function(e){return e.e==="coin";})[0]||{};
  var q2=re[1];q2.d=1;var cB=s.s.coins;s.ship(q2,"hole");var holeDirty=s.s.coins-cB;
  /* the real flow: let him go in and finish them; every hole payout for a pre-paid potato shows its total */
  s.setBox("pool",1);var holes=[];H.run(s,400,function(s){s.events.forEach(function(e){if(e.e==="coin"&&e.via==="hole")holes.push(e.v+"/"+e.tot);});s.events=[];return holes.length>=3;});
  return R(drops.length>=3&&drops.every(function(v){return v===2;})&&allPre&&okSave&&migNoPre&&rePre&&hole===4&&ev.tot===6&&ev.via==="hole"&&holeDirty<4&&holes.length>=1,
    "drop popups "+JSON.stringify(drops)+" (+2c each, paid at once); pool potatoes pre-paid "+allPre+"; save keeps coins "+c0+" and poolPre "+JSON.stringify(o.poolPre)+"; old save without poolPre -> full value later "+migNoPre+"; reload keeps pre-paid "+rePre+"; clean at the hole +"+hole+"c (total "+ev.tot+"c), dirty at the hole +"+holeDirty+"c; real run hole payouts v/total "+JSON.stringify(holes));});
T("202:Papa is drawn in front of the wall SHIPPING machine, never ghosted behind it (Jay t1240)",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");var p=s.s.papa;p.task=null;p.path=[];p.moving=false;
  /* t1244: the starter bed sits beside the drop spot and its white sheet matches his white coat, which hides pixels from this diff; move it away for the measurement (this checks the SHIPPING machine never ghosts him) */
  var bedO=s.s.objs.filter(function(o){return o.id==="bed";})[0],bedXY=bedO?[bedO.x,bedO.y]:null;if(bedO){bedO.x=2;bedO.y=2;}
  function vis(x,y){var px=[];for(var k=0;k<2;k++){p.x=k?x:2.2;p.y=k?y:1.2;p.dir=1;PPDraw.parts.length=0;for(var w=0;w<3;w++)H.render(s,x,y,1.5,5);px.push(H.canvas.getContext("2d").getImageData(0,0,360,400).data.slice());}
    var n=0;for(var i=0;i<px[0].length;i+=4){if(Math.abs(px[0][i]-px[1][i])+Math.abs(px[0][i+1]-px[1][i+1])+Math.abs(px[0][i+2]-px[1][i+2])>60)n++;}return n;}
  var ref=vis(7.5,10.5),out=[],ok=ref>800;[[PP2T.S.FIX.dropStand.x,PP2T.S.FIX.dropStand.y],[13.5,17.5,1],[12.6,16.6,1],[12.2,13.6,2],[11.6,15.2,2]].forEach(function(c){var n=vis(c[0],c[1]),r=n/ref,gh=PPDraw.lastHid;out.push(c.join(",")+": "+(r*100).toFixed(0)+"%"+(gh?" GHOSTED":" solid"));if(r<(c[2]===2?0.40:0.85)||(!c[2]&&gh))ok=false;});
  return R(ok,"Papa pixels at the machine vs open floor ("+ref+"px; drop spot must be solid (not ghosted) and 85%+, walking past 85%, behind the box 40%+ (2.0.3: the raised SHIPPING sign is drawn over everything); drop stand "+PP2T.S.FIX.dropStand.x+","+PP2T.S.FIX.dropStand.y+"; the old ghosted build gave 87/88%): "+out.join(" | "));});
/* ---- 2.0.2 t1244: Papa's screen box never overlaps the SHIPPING machine's screen box at the drop spot, at every zoom ---- */
function BB(){var cv=document.createElement("canvas");cv.width=900;cv.height=1000;return cv;}
H.bbRender=function(cv,s,cx,cy,z){var R0=Math.random,sd=12345;Math.random=function(){sd=(sd*16807)%2147483647;return sd/2147483647;};PPDraw.parts.length=0;var c=cv.getContext("2d");for(var w=0;w<4;w++){sd=12345;c.setTransform(1,0,0,1,0,0);c.fillStyle="#000";c.fillRect(0,0,cv.width,cv.height);
  PPDraw.render(c,s,{w:cv.width,h:cv.height,z:z,cx:cx,cy:cy,t:5,dpr:1,edit:false,ghost:null,sel:0,showPower:false});}Math.random=R0;PPDraw.parts.length=0;return c.getImageData(0,0,cv.width,cv.height).data;};
H.bbDiff=function(a,b,W){var x0=1e9,y0=1e9,x1=-1,y1=-1,n=0;for(var i=0;i<a.length;i+=4){if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>40){var p=i/4,x=p%W,y=(p-x)/W;n++;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}return n?{x0:x0,y0:y0,x1:x1,y1:y1,n:n}:null;};
H.papaBoxBB=function(s,z,spot){var cv=BB(),p=s.s.papa;p.path=[];p.moving=false;p.x=spot[0];p.y=spot[1];
  p.task={type:"drop",stage:"act",t:0.2,via:"scan",target:null};s.facePt(13.5,15.2);if(!p.hold.length)p.hold.push(-1);
  var cx=13.6,cy=16.4,D=PPDraw;PPDraw.parts.length=0;D.dbgHide={papa:1,toss:1};var noP=H.bbRender(cv,s,cx,cy,z);D.dbgHide={toss:1};var withP=H.bbRender(cv,s,cx,cy,z);
  D.dbgHide={papa:1,shipK:1,toss:1};var noB=H.bbRender(cv,s,cx,cy,z);D.dbgHide=null;
  /* Papa: everything his sprite adds except his floor shadow (shadow pixels stay dark); the box: everything the kitchen-side machine draws */
  var pb=H.bbDiff(noP,withP,cv.width),bb=H.bbDiff(noB,noP,cv.width);
  var clip=pb&&bb&&(pb.x0<=0||pb.y0<=0||pb.x1>=cv.width-1||pb.y1>=cv.height-1||bb.x0<=0||bb.y0<=0||bb.x1>=cv.width-1||bb.y1>=cv.height-1);
  var ov=pb&&bb?Math.max(0,Math.min(pb.x1,bb.x1)-Math.max(pb.x0,bb.x0)+1)*Math.max(0,Math.min(pb.y1,bb.y1)-Math.max(pb.y0,bb.y0)+1):-1;
  p.task=null;p.hold=p.hold.filter(function(u){return u!==-1;});return {pb:pb,bb:bb,ov:ov,clip:clip};};
/* 2.0.3 t1246: the t1244 "zero overlap" rule put him off to the side, beside the bed (wrong). Replaced by: he stands right in front of the LABELED face */
/* 2.0.3 t1253: Papa on real floor out from the kitchen-facing (-x) face, facing the intake slot squarely; ZERO sprite-pixel overlap with the box (pixel masks), a visible floor gap, slot drawn on that face, sign readable; every zoom */
H.mask=function(a,b){var m=new Uint8Array(a.length/4);for(var i=0,j=0;i<a.length;i+=4,j++)if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>40)m[j]=1;return m;};
H.papaBox=function(s,z,cx,cy){var cv=BB(),Dd=PPDraw,r=function(h){Dd.dbgHide=h;var d=H.bbRender(cv,s,cx,cy,z);return d;};
  /* Papa alone (box hidden so nothing covers him) and the box alone (Papa hidden); the toss potato is hidden in both */
  var a=r({shipK:1,toss:1}),b=r({shipK:1,papa:1,toss:1}),c=r({papa:1,toss:1}),full=r({toss:1}),hidAt=Dd.lastHid;Dd.dbgHide=null;
  return {W:cv.width,Hh:cv.height,pm:H.mask(a,b),bm:H.mask(c,b),full:full,c:c,hid:hidAt};};
T("203:t1253 Papa drops from real kitchen floor out from the intake face: feet tile is floor, faces the slot face squarely, ZERO sprite-pixel overlap with the box and a visible floor gap, slot drawn on that face, sign readable, at every zoom",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("roomKey");
  var F=PP2T.S.FIX,st=F.dropStand,ok=true,out=[],spot=s.spotsFor("scanK")[0],p=s.s.papa;
  var floor=s.walkable(Math.floor(st.x),Math.floor(st.y))&&PP2T.S.roomOf(Math.floor(st.x),Math.floor(st.y))==="k"&&Math.floor(st.x)===spot[0]&&Math.floor(st.y)===spot[1];
  p.path=[];p.moving=false;p.x=st.x;p.y=st.y;p.task={type:"drop",stage:"act",t:0.2,via:"scan",target:null};var c=s.tgtCenter(p.task);s.facePt(c[0],c[1]);if(!p.hold.length)p.hold.push(-1);
  /* faces +x (the -x face of the box at x 13.05) and squarely: same y as the face centre (15.0) and the slot */
  var faces=p.dir===0&&Math.abs(st.y-15.0)<0.05&&Math.abs(F.slot.y-15.0)<0.05&&F.slot.x<13.05&&F.slot.x>12.6&&c[0]===F.slot.x;
  if(!floor||!faces)ok=false;
  [0.38,0.5,0.72,0.9,1.1,1.35,1.5,1.7].forEach(function(z){var cx=12.6,cy=15.2,m=H.papaBox(s,z,cx,cy),W=m.W,ov=0,np=0,nb=0,i,gap=1e9;
    for(i=0;i<m.pm.length;i++){if(m.pm[i])np++;if(m.bm[i])nb++;if(m.pm[i]&&m.bm[i])ov++;}
    /* gap: shortest screen distance between a Papa pixel and a box pixel (edge pixels, coarse 1px scan within 40px) */
    var R2=Math.ceil(40*z)+4;for(i=0;i<m.pm.length;i++){if(!m.pm[i])continue;var x=i%W,y=(i/W)|0;if(m.pm[i-1]&&m.pm[i+1]&&m.pm[i-W]&&m.pm[i+W])continue;
      for(var dy=-R2;dy<=R2;dy++)for(var dx=-R2;dx<=R2;dx++){var q=(y+dy)*W+x+dx;if(q<0||q>=m.bm.length||!m.bm[q])continue;var dd=Math.sqrt(dx*dx+dy*dy);if(dd<gap)gap=dd;}}
    var needGap=Math.max(3,6*z),gapOk=gap>=needGap;
    /* slot drawn on that face: a dark mouth inside the box mask, left of the box body's left screen corner + above, i.e. on the kitchen-facing side, and nothing of Papa on it */
    var Xs=function(x,y){return W/2+((x-y)-(cx-cy))*32*z;},Ys=function(x,y,h){return m.Hh/2+((x+y)-(cx+cy))*16*z-(h||0)*50*z;};
    var sx=Math.round(Xs(F.slot.x,F.slot.y)),sy=Math.round(Ys(F.slot.x,F.slot.y,F.slot.h)),dark=0;for(var yy=sy-3;yy<=sy+3;yy++)for(var xx=sx-3;xx<=sx+3;xx++){var k=(yy*W+xx)*4;if(m.c[k]+m.c[k+1]+m.c[k+2]<120&&m.bm[yy*W+xx])dark++;}
    var slotOk=dark>=(z<0.5?6:10);
    var drawn=!m.hid&&np>200;
    if(!(ov===0&&gapOk&&slotOk&&drawn))ok=false;
    out.push("z"+z+": overlap "+ov+" px (Papa "+np+", box "+nb+"), gap "+(gap===1e9?"none":gap.toFixed(1))+"px (need "+needGap.toFixed(1)+") "+gapOk+", slot dark px "+dark+" "+slotOk+", visible "+drawn);});
  /* t1255: the toss starts in his hand and ends in the slot mouth (screen px), frames in between move toward the mouth */
  var q0=PPDraw.tossPos(s,0),hb=PPDraw._dropHB,q1=PPDraw.tossPos(s,1),qm=PPDraw.tossPos(s,0.65),tossOk=!!(q0&&q1&&qm&&q1.M)&&Math.abs(q1.x-q1.M[0])<1&&Math.abs(q1.y-q1.M[1])<1&&qm.x>q0.x&&qm.x<q1.x;
  if(!tossOk)ok=false;out.push("toss: hand "+(q0?q0.x.toFixed(0)+","+q0.y.toFixed(0):"-")+" -> mid "+(qm?qm.x.toFixed(0)+","+qm.y.toFixed(0):"-")+" -> end "+(q1?q1.x.toFixed(0)+","+q1.y.toFixed(0)+" mouth "+q1.M[0].toFixed(0)+","+q1.M[1].toFixed(0):"-")+" "+tossOk);
  p.task=null;p.hold=p.hold.filter(function(u){return u!==-1;});
  return R(ok,"stand "+st.x+","+st.y+" tile "+spot+" floor "+floor+"; faces dir "+p.dir+" toward slot "+F.slot.x+","+F.slot.y+" "+faces+"; "+out.join(" | "));});
T("202:t1244 an order given while Papa's sack is on the floor is not lost (NAP goes to bed, EAT keeps the order)",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("carrySack");var p=s.s.papa;p.energy=60;
  p.sack.on=false;p.sack.x=7.5;p.sack.y=12.5;s.order("nap");H.run(s,3,function(){return false;});var t=p.task,napOk=!!(t&&t.type==="nap");
  p.task=null;p.path=[];p.sack.on=false;p.sack.x=7.5;p.sack.y=12.5;s.s.food=3;s.order("eat");H.run(s,0.2,function(){return false;});var t2=p.task,keep=!!(t2&&(t2.type==="pickSack"&&p.order==="eat"||t2.type==="eat"));
  return R(napOk&&keep,"NAP with the sack down -> task "+(t?t.type+"/"+t.stage:"none")+"; EAT with the sack down -> task "+(t2?t2.type:"none")+", order kept "+p.order);});
/* ---- 2.0.2 t1242: drop spot, canal outlet, FLOW tap, canal machines ---- */
function W2(sd){var s=H.rich(sd);s.buyItem("roomKey");s.setBox("deliver",0);s.setBox("pool",0);s.s.flowOff=0;s.events=[];return s;}
function cpot(s,c,d){var q=s.newPot(1,"pool");q.d=d==null?1:d;q.m="canal";q.c=c;var ps=s.canalPos(c);q.x=ps.x;q.y=ps.y;return q;}
function genNear(s){s.buyItem("generator");var r=s.place("generator",22,10,0);s.calcPower();return r.ok;}
function holeCoins(s){var v=[];s.events.forEach(function(e){if(e.e==="coin"&&e.via==="hole")v.push(e.v);});s.events=[];return v;}
T("202:t1242/t1253 Papa: ONE drop spot (tile 10,15 on the kitchen floor out from the intake face, kept clear); machine tiles unwalkable; spot kept clear",function(sd){var s=H.fresh(sd);
  var sp=JSON.stringify(s.spotsFor("scanK")),wk=[s.walkable(13,14),s.walkable(13,15),s.walkable(10,15)];s.s.coins=999;s.s.level=5;s.buyItem("plant");var pl=s.canPlace("plant",10,15,0);
  var drops=0,bad=0,pos={};H.run(s,240,function(s){var t=s.s.papa.task;if(t&&t.type==="drop"&&t.stage==="act"){drops++;var k=Math.floor(s.s.papa.x)+","+Math.floor(s.s.papa.y);pos[k]=(pos[k]|0)+1;if(Math.abs(s.s.papa.x-PP2T.S.FIX.dropStand.x)>0.01||Math.abs(s.s.papa.y-PP2T.S.FIX.dropStand.y)>0.01)bad++;}return s.s.shipped>=4;});
  /* a 2.0.1 save with a fan on the new drop spot: the fan goes to INV */
  var s2=H.rich(sd);s2.buyItem("fan");var o=JSON.parse(s2.saveStr());o.ver="2.0.1";o.objs.push({id:"fan",x:10,y:15,r:0});s2.reset(sd);s2.load(JSON.stringify(o));var onSpot=s2.s.objs.filter(function(q){return q.x===10&&q.y===15&&q.id==="fan";}).length;
  return R(sp==="[[10,15]]"&&!wk[0]&&!wk[1]&&wk[2]&&!pl.ok&&drops>0&&bad===0&&onSpot===0&&(s2.s.inv.fan|0)>=1,"spots "+sp+"; walkable machine tiles "+wk[0]+","+wk[1]+", front "+wk[2]+"; plant on the spot: "+(pl.ok?"allowed":pl.why)+"; drop frames "+drops+" at "+JSON.stringify(pos)+"; migrated fan on the spot -> map "+onSpot+", INV "+(s2.s.inv.fan|0));});
T("202:t1242/t1253 Papa drawn solid on the floor at the drop stand (no ghost, nothing drawn over him)",function(sd){var s=H.fresh(sd);var p=s.s.papa;p.task=null;p.path=[];p.moving=false;
  /* t1244: the starter bed sits beside the drop spot and its white sheet matches his white coat, which hides pixels from this diff; move it away for the measurement (this checks the SHIPPING machine never ghosts him) */
  var bedO=s.s.objs.filter(function(o){return o.id==="bed";})[0],bedXY=bedO?[bedO.x,bedO.y]:null;if(bedO){bedO.x=2;bedO.y=2;}
  function vis(x,y){var px=[];for(var k=0;k<2;k++){p.x=k?x:2.2;p.y=k?y:1.2;p.dir=1;PPDraw.parts.length=0;for(var w=0;w<3;w++)H.render(s,x,y,1.5,5);px.push(H.canvas.getContext("2d").getImageData(0,0,360,400).data.slice());}
    var n=0;for(var i=0;i<px[0].length;i+=4){if(Math.abs(px[0][i]-px[1][i])+Math.abs(px[0][i+1]-px[1][i+1])+Math.abs(px[0][i+2]-px[1][i+2])>60)n++;}return n;}
  var F=PP2T.S.FIX,ref=vis(7.5,10.5),at=vis(F.dropStand.x,F.dropStand.y),gh=PPDraw.lastHid,r=at/ref;
  /* depth: at the spot his sort key is above both machine halves, so the box is drawn first and he stands in front of it */
  return R(r>=0.85&&!gh,"Papa pixels at the drop stand "+F.dropStand.x+","+F.dropStand.y+": "+(r*100).toFixed(0)+"% of open floor, "+(gh?"GHOSTED":"solid, not ghosted"));});
T("202:t1242 canal ends in a ship drain (not the wall): potatoes are sold at the drain, the wall doorway is gone",function(sd){var s=W2(sd);var q=cpot(s,18,0);var minY=99,lastC=0;
  H.run(s,30,function(s){if(q.m==="canal"){minY=Math.min(minY,q.y);lastC=q.c;}return s.s.pots.indexOf(q)<0;});var v=holeCoins(s),ok=s.s.pots.indexOf(q)<0;
  var dr=S.FIX.drain;return R(ok&&minY>=0.45&&v.length===1&&v[0]===5&&S.isCanal(dr.x,dr.y)&&!PPDraw.wallHole,"sold at the drain: "+ok+", last canal y "+minY.toFixed(2)+" (drain centre 0.5, wall 0), paid "+JSON.stringify(v)+"; wall doorway drawn: "+!!PPDraw.wallHole);});
T("202:t1242 FLOW OFF holds (nothing moves, nothing sold, queue backs up behind the gate), FLOW ON sells them all",function(sd){var s=W2(sd);var far=[cpot(s,8,0),cpot(s,12,0),cpot(s,16,0)];s.setFlow(false);var c0=far.map(function(q){return q.c;});
  H.run(s,20);var moved=far.some(function(q,i){return Math.abs(q.c-c0[i])>1e-6;}),sold=holeCoins(s).length;
  /* toss 20 in at the head while the gate is down */
  var head=[];for(var i=0;i<20;i++){if(!s.canalFull()){var q=s.newPot(1,"pool");q.d=0;s.toWater(q,20.5,15.5);head.push(q);}H.run(s,0.3);}
  var hc=head.map(function(q){return q.c;}).sort(function(a,b){return a-b;}),gap=9;for(i=1;i<hc.length;i++)gap=Math.min(gap,hc[i]-hc[i-1]);var ga=s.gateC(),past=hc.filter(function(c){return c>ga;}).length,full=s.canalFull();
  s.setFlow(true);var all=far.concat(head),n=H.run(s,90,function(s){return all.every(function(q){return s.s.pots.indexOf(q)<0;});});var paid=holeCoins(s);
  return R(!moved&&sold===0&&head.length>=10&&gap>=0.29&&past===0&&full&&n>0&&paid.length===all.length,"OFF: far potatoes moved "+moved+", sold "+sold+"; "+head.length+" tossed at the head queued (min gap "+gap.toFixed(2)+", past the gate "+past+", canal full "+full+"); ON: all "+paid.length+"/"+all.length+" sold in "+(n/60).toFixed(1)+"s");});
T("202:t1242 AUTO CLEANER: potatoes pass through slowly, come out clean still in the canal, pay 1c less, no Papa time",function(sd){var s=W2(sd);genNear(s);s.s.inv.canalCleaner=0;s.buyItem("canalCleaner");var pr=s.place("canalCleaner",22,15,0);s.calcPower();var o=pr.o;
  var q=cpot(s,0.4,1),cm=s.canalMachs()[0],tin=0,dIn=null,dOut=null,mOut=null,sc0=s.s.stats.scrubbed;
  H.run(s,60,function(s){if(q.m==="canal"&&q.c>=cm.a&&q.c<cm.b){tin+=1/60;if(dIn==null)dIn=q.d;}if(dOut==null&&q.c>=cm.b+0.2&&q.m==="canal"){dOut=q.d;mOut=q.m;}return s.s.pots.indexOf(q)<0;});
  var v=holeCoins(s);var q2=cpot(s,0.4,1),tin2=0;o.on=0;H.run(s,60,function(s){if(q2.m==="canal"&&q2.c>=cm.a&&q2.c<cm.b)tin2+=1/60;return s.s.pots.indexOf(q2)<0;});var v2=holeCoins(s);
  return R(pr.ok&&o.pw===1&&dIn>0.5&&dOut!==null&&dOut<=0.15&&mOut==="canal"&&q.ac===1&&tin>tin2*2&&v[0]===4&&v2[0]<4&&s.s.stats.scrubbed===sc0,"placed "+pr.ok+" powered "+o.pw+"; in dirt "+(dIn||0).toFixed(2)+" -> out "+(dOut==null?"?":dOut.toFixed(2))+" still in the "+mOut+"; "+tin.toFixed(1)+"s inside (off: "+tin2.toFixed(1)+"s); paid "+JSON.stringify(v)+" (hand-clean pays 5), switched off: dirty one paid "+JSON.stringify(v2)+"; Papa scrubs "+(s.s.stats.scrubbed-sc0));});
T("202:t1242 SORTER: dirty/bad potatoes back to the pool, good ones continue to the drain",function(sd){var s=W2(sd);genNear(s);s.buyItem("sorter");var pr=s.place("sorter",23,15,0);s.calcPower();
  var dirty=cpot(s,0.4,1),clean=cpot(s,1.2,0),bad=cpot(s,2.0,0);bad.sl=1;H.run(s,60,function(s){return s.s.pots.indexOf(clean)<0&&dirty.m!=="canal"&&bad.m!=="canal";});var v=holeCoins(s);
  return R(pr.ok&&dirty.m==="pool"&&bad.m==="pool"&&s.s.pots.indexOf(clean)<0&&v.length===1&&v[0]===5&&s.s.stats.sorted===2,"dirty -> "+dirty.m+", bad -> "+bad.m+", clean sold "+(s.s.pots.indexOf(clean)<0)+" paid "+JSON.stringify(v)+", sorted "+s.s.stats.sorted);});
T("202:t1242 canal machines need power and jam like the others (jam blocks the canal, FIX JAMS clears it)",function(sd){var s=W2(sd);s.buyItem("canalCleaner");var pr=s.place("canalCleaner",23,15,0);s.calcPower();var o=pr.o;
  var q=cpot(s,0.4,1);H.run(s,40,function(s){return s.s.pots.indexOf(q)<0;});var v=holeCoins(s),pw0=o.pw,noPow=o.pw===0&&!q.ac;
  genNear(s);s.calcPower();s.setBox("fix",0);var rng=s.rng;s.rng=function(){return 0;};var q2=cpot(s,0.4,1);H.run(s,8,function(s){return o.jam;});s.rng=rng;var jammed=!!o.jam,jams=s.s.stats.jams;
  var q3=cpot(s,0.2,0);H.run(s,15);var cm=s.canalMachs()[0],held=q3.m==="canal"&&q3.c<=cm.a&&s.s.pots.indexOf(q2)>=0,c3=q3.c;
  s.setBox("fix",1);var n=H.run(s,120,function(s){return !o.jam;});var n2=H.run(s,60,function(s){return s.s.pots.indexOf(q3)<0&&s.s.pots.indexOf(q2)<0;});
  return R(pr.ok&&noPow&&v.length===1&&jammed&&jams>=1&&held&&n>0&&n2>0,"no power: powered "+pw0+", passed through dirty, paid "+JSON.stringify(v)+"; with power + bad luck: jammed "+jammed+" (jams "+jams+"); jam blocks: next potato waits at c "+c3.toFixed(2)+" (entry "+cm.a.toFixed(2)+"); FIX JAMS cleared it in "+(n/60).toFixed(1)+"s, then both sold");});
T("202:t1242 placement: canal machines only on canal tiles (not the drain, gate or corner); nothing pre-placed",function(sd){var s=W2(sd);s.buyItem("sorter");var a=[s.canPlace("sorter",22,14,0),s.canPlace("sorter",25,0,0),s.canPlace("sorter",S.FIX.gate.x,S.FIX.gate.y,0),s.canPlace("sorter",25,15,0),s.canPlace("sorter",25,6,0),s.canPlace("sorter",20,15,0)];
  var f=H.fresh(sd),pre=f.s.objs.filter(function(o){return S.isCanalM(o.id);}).length;
  return R(!a[0].ok&&!a[1].ok&&!a[2].ok&&!a[3].ok&&a[4].ok&&a[5].ok&&pre===0,a.map(function(r){return r.ok?"ok":r.why;}).join(" | ")+"; pre-placed canal machines "+pre);});
T("202:t1242 CUSTOM GAME: DRYER and BUBBLER only when turned on; dryer +1c, bubbler cleans fast; saved",function(sd){var s=W2(sd);genNear(s);s.s.coins=99999;var lock=s.buyItem("dryer");s.s.inv.dryer=1;var lock2=s.place("dryer",23,15,0);s.s.inv.dryer=0;
  s.setCustom("dryer",1);s.setCustom("bubbler",1);s.buyItem("dryer");var pd=s.place("dryer",23,15,0);s.buyItem("bubbler");var pb=s.place("bubbler",21,15,0);s.calcPower();
  var q=cpot(s,0.4,1),cm=s.canalMachs().filter(function(m){return m.o.id==="bubbler";})[0],tin=0;H.run(s,60,function(s){if(q.m==="canal"&&q.c>=cm.a&&q.c<cm.b)tin+=1/60;return s.s.pots.indexOf(q)<0;});var v=holeCoins(s);
  var o=JSON.parse(s.saveStr());s.reset(sd);s.load(JSON.stringify(o));var kept=s.s.custom.dryer===1&&s.s.custom.bubbler===1&&s.s.objs.filter(function(x){return S.isCanalM(x.id);}).length===2;
  return R(!lock.ok&&!lock2.ok&&pd.ok&&pb.ok&&q.ac===1&&q.dry===1&&v[0]===5&&tin<2.5&&kept,"before CUSTOM GAME: buy "+(lock.ok?"allowed?!":lock.why)+", place "+(lock2.ok?"allowed?!":lock2.why)+"; after: dryer "+pd.ok+", bubbler "+pb.ok+"; bubbler pass "+tin.toFixed(1)+"s, cleaned "+(q.ac===1)+", dried "+(q.dry===1)+", paid "+JSON.stringify(v)+" (auto-clean 4 + dry 1); kept after save/load "+kept);});
T("202:t1242 FLOW + canal machines survive save/load; FLOW OFF in AUTO MODE pays less (drop only)",function(sd){var s=W2(sd);genNear(s);s.buyItem("sorter");s.place("sorter",23,15,0);s.setFlow(false);var o=JSON.parse(s.saveStr());s.reset(sd);s.load(JSON.stringify(o));
  var ok=s.s.flowOff===1&&s.s.objs.some(function(x){return x.id==="sorter"&&x.x===23&&x.y===15;});s.setFlow(true);var o2=JSON.parse(s.saveStr());s.reset(sd);s.load(JSON.stringify(o2));
  var onKept=s.s.flowOff===0;var now=Date.UTC(2026,10,26,10,0,0),a1=W2(sd);var r1=PPAway.run(a1,now,now-3600*1000,sd),a2=W2(sd);a2.setFlow(false);var r2=PPAway.run(a2,now,now-3600*1000,sd);
  return R(ok&&onKept&&r1&&r2&&r2.coins<r1.coins,"flow off kept "+ok+", flow on kept "+onKept+"; AUTO MODE 1h: FLOW ON +"+(r1?r1.coins:"?")+"c vs FLOW OFF +"+(r2?r2.coins:"?")+"c");});
T("202:no key -> the wall machine ships right away (early income), SHIP DIRTY same",function(sd){var s=H.fresh(sd);var via={};H.run(s,200,function(s){s.events.forEach(function(e){if(e.e==="coin")via[e.via]=(via[e.via]|0)+1;});s.events=[];return (via.chute|0)>=3;});
  var a=via.chute|0,p0=poolN(s);var s2=H.fresh(sd);s2.s.coins=99;s2.buyItem("roomKey");s2.setBox("deliver",1);var v2={};H.run(s2,200,function(s){s.events.forEach(function(e){if(e.e==="coin")v2[e.via]=(v2[e.via]|0)+1;});s.events=[];return (v2.chute|0)>=3;});
  return R(a>=3&&p0===0&&(v2.chute|0)>=3&&poolN(s2)===0,"no key: "+a+" shipped through the wall machine, pool "+p0+"; key + SHIP DIRTY: "+(v2.chute|0)+" shipped, pool "+poolN(s2));});
T("202:no pre-placed machines: fresh game + migrated 2.0.1 save; no X-RAY / old SHIP drawn",function(sd){var s=H.fresh(sd);var ids=s.s.objs.map(function(o){return o.id;}).sort().join(",");
  var o=JSON.parse(s.saveStr());o.ver="2.0.1";o.pile=80;o.box.deliver=1;o.coins=123;var s2=H.fresh(sd);s2.load(JSON.stringify(o));var ids2=s2.s.objs.map(function(q){return q.id;}).sort().join(",");
  /* every text the renderer writes in one frame */
  var c=document.createElement("canvas");c.width=360;c.height=400;var g=c.getContext("2d"),seen={},ft=g.fillText;g.fillText=function(t){seen[String(t)]=1;return ft.apply(g,arguments);};
  [[12,13,0.6],[6,20,0.8],[16,14,1]].forEach(function(v){PPDraw.render(g,s2,{w:360,h:400,z:v[2],cx:v[0],cy:v[1],t:3,dpr:1,edit:false,ghost:null,sel:0,showPower:false});});var txt=Object.keys(seen).join("|");
  var ok=ids==="bed,cooler,table,tub"&&ids2===ids&&s2.s.pile===852&&s2.s.box.deliver===0&&s2.s.coins===123&&!/X-RAY/.test(txt)&&seen.SHIPPING&&!seen["SHIP"+String.fromCharCode(32)+"\u25B6"]&&S.FIX.chute.w===0;
  return R(ok,"fresh: "+ids+"; migrated 2.0.1: "+ids2+", pile 80 -> "+s2.s.pile+", SHIP DIRTY -> POOL ("+s2.s.box.deliver+"), coins kept "+s2.s.coins+"; drawn labels: "+txt.slice(0,160));});
T("202:migrated save: player furniture on the new pile spot goes to INV, nothing deleted",function(sd){var s=H.rich(sd);s.buyItem("fan");var r=s.place("fan",3,17,0);var o=JSON.parse(s.saveStr());o.ver="2.0.1";o.pile=80;
  o.objs.forEach(function(q){if(q.id==="fan"){q.y=21;}});var s2=H.fresh(sd);s2.load(JSON.stringify(o));var onMap=s2.s.objs.filter(function(q){return q.id==="fan";}).length,inv=s2.s.inv.fan|0;
  return R(r.ok&&onMap+inv===1&&inv===1,"fan saved at y21 (now pile) -> on map "+onMap+", in INV "+inv);});
T("202:calendar stays still and flips once when the in-game day changes",function(sd){var s=H.rich(sd);s.buyItem("calendar");var w=s.place("calendar",3.5,0.5,0);var flips=0,last=s.s.calFlipT;
  var dayLen=720;H.run(s,dayLen*1.1,function(s){if(s.s.calFlipT!==last){flips++;last=s.s.calFlipT;}return false;});
  var f=s.s.calFlipT;s.s.calFlipT=s.s.t-5;var pp=s.s.papa,px=pp.x,py=pp.y;pp.x=12.5;pp.y=18.5;pp.task=null;var still=H.animates(s,w.o,true);pp.x=px;pp.y=py;s.s.calFlipT=s.s.t;var mid=H.animates(s,w.o,true);s.s.calFlipT=f;
  return R(w.ok&&flips===1&&still<=30&&mid>30,"one in-game day ("+Math.round(dayLen*1.1)+"s) -> "+flips+" flip; idle: "+still+"px change; during the flip: "+mid+"px");});
T("202:radio-station want: Papa peels for DISCO SPUD, gets it, RADIO plays it",function(sd){var s=H.fresh(sd);s.s.coins=0;s.s.level=3;s.s.owned.radio=1;var got=null;
  for(var k=0;k<40&&!got;k++){var w=s.pickWant();if(w&&w.kind==="station")got=w;}
  if(!got)return R(false,"no station want in 40 picks");s.s.want=got;s.s.coins=got.price-1;var r0=s.giveWant(false);s.s.coins=got.price;var r=s.giveWant(false);
  var own=s.s.owned.stDisco|0,st=s.s.decor.radioSt,again=s.wantables().filter(function(i){return i.cat==="station";}).length;var sv=s.saveStr();
  var s3=H.fresh(sd);var none=s3.wantables().filter(function(i){return i.cat==="station";}).length;s3.load(sv);var kept=s3.s.decor.radioSt;
  return R(!r0.ok&&r.ok&&own===1&&st===3&&none===0&&again===0&&kept===3,"wanted "+got.name+" ("+got.price+"c): refused at "+(got.price-1)+"c, bought at "+got.price+"c, radio tuned to station "+st+", kept after save/load ("+kept+"); no radio = no station want ("+none+"); not wanted again ("+again+")");});
T("202:AUTO MODE short trips pay a small guaranteed minimum (still under 50%)",function(sd){var out=[],ok=true;[["1m",60],["2m",120],["5m",300],["30s",30]].forEach(function(a){
    var s=H.fresh(sd);s.s.papa.energy=5;s.s.papa.hunger=20;s.s.food=0;var c0=s.s.coins,now=Date.UTC(2026,10,26,10,0,0),r=PPAway.run(s,now,now-a[1]*1000,sd);var got=r?r.coins:0;
    var need=a[1]>=60;var good=r?(r.eff<=0.5001&&(!need||got>=1)&&s.s.coins===c0+got):!need;if(!good)ok=false;out.push(a[0]+": +"+got+"c"+(r?", work "+Math.round((r.workShare||0)*100)+"%, eff "+r.eff:" (too short, no report)"));});
  return R(ok,"tired, hungry, no food (worst case): "+out.join(" | "));});
T("202:broom only in his hands while sweeping, parked on the wall otherwise",function(sd){var s=H.fresh(sd);s.s.coins=99;s.buyItem("broomDustpan");H.run(s,20);var held0=s.s.papa.broomHeld;
  for(var i=0;i<30;i++)s.addPeel(3+(i%6)*0.4,12+((i/6)|0)*0.4);s.setBox("clean",10);var heldSweep=0,sweepNo=0,heldOther=0,got=0,parked=0;
  var n=H.run(s,200,function(s){var p=s.s.papa,t=p.task;s.events.forEach(function(e){if(e.e==="broom"){if(e.on)got++;else parked++;}});s.events=[];
    if(t&&t.type==="sweep"&&t.stage==="act"){if(p.broomHeld)heldSweep++;else sweepNo++;}if(t&&(t.type==="peel"||t.type==="eat"||t.type==="nap")&&p.broomHeld)heldOther++;return parked>=1&&!p.broomHeld&&s.s.peels.length<=10;});
  return R(held0===0&&got>=1&&parked>=1&&heldSweep>0&&sweepNo===0&&heldOther===0&&n>0,"start: on the wall ("+held0+"); fetched "+got+"x, swept "+heldSweep+" frames with it in hand ("+sweepNo+" without), parked back "+parked+"x, held while peeling/eating/napping "+heldOther+" frames");});
T("203:t1253 starter bed: new games put it at 8,16; a 2.0.2 save with the bed on 10,16 moves it to 8,16 only when that spot is free",function(sd){var s=H.fresh(sd),b0=s.s.objs.filter(function(o){return o.id==="bed";})[0];
  var o=JSON.parse(s.saveStr());o.ver="2.0.2";o.objs.forEach(function(q){if(q.id==="bed"){q.x=10;q.y=16;q.r=0;}});s.reset(sd);s.load(JSON.stringify(o));var b1=s.s.objs.filter(function(q){return q.id==="bed";})[0];
  var s2=H.rich(sd);s2.buyItem("fan");var o2=JSON.parse(s2.saveStr());o2.ver="2.0.2";o2.objs.forEach(function(q){if(q.id==="bed"){q.x=10;q.y=16;q.r=0;}});o2.objs.push({id:"fan",x:8,y:17,r:0});s2.reset(sd);s2.load(JSON.stringify(o2));var b2=s2.s.objs.filter(function(q){return q.id==="bed";})[0],fan=s2.s.objs.filter(function(q){return q.id==="fan"&&q.x===8&&q.y===17;}).length;
  return R(b0.x===8&&b0.y===16&&b1.x===8&&b1.y===16&&b2.x===10&&b2.y===16&&fan===1,"new "+b0.x+","+b0.y+"; old save free -> "+b1.x+","+b1.y+"; old save with a fan on 8,17 -> bed "+b2.x+","+b2.y+", fan kept "+fan);});
})();
