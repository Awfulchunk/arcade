# Tough & J's Arcade 2.7.72 (versionCode 110) — source (GPL-3.0)

2.7.72 is cumulative over 2.7.71 (everything else unchanged):
- Pixel War 0.4.10 is now `pixelwar:latest` (default). 0.4.9 is kept as `pixelwar:v049`; v047, v046, v045, v044, v043, v042, v041, v03 unchanged. Source: source/pixel-war/arcade-2.7.72/.
- Papa Potato 0.4.9 is now `papa-potato:latest`. 0.4.2 is kept as `papa-potato:v042`; v041, v03, v02, v01 unchanged. Source: source/papa-potato/0.4.9/.
- Swarm is unchanged (1.6.15 remains `swarm:latest`; 1.6.14 is `swarm:v1614`).
- Unchanged otherwise: Latch 2.1, FunMotion 0.2.5, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
