# Pixel War 0.4.3 source (Tough & J's Arcade 2.7.66) — GPL-3.0
- game/pixel-war-0.4.2.html: the whole game is this one file (no build step). Plain-words HUD, prep with attack path + defense line, live branches in the match (own colour/meter, per-path sliders), slow flow, leash fade, sparkle + ricochet effects, free SANDBOX, shapes hidden (code kept under CUSTOM GAME). Save keys `pixelwar.v42*`. Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.1.html: kept as `pixelwar:v041`; game/pixel-war-0.3.html: `pixelwar:v03`.
- arcade-2.7.65/: assemble-2765.mjs (replaces the latest slot, adds v041, asserts everything else byte-identical) and verify-2765.cjs (checks the signed APK against 2.7.64).
- tests/ (mech, mech2-4, buff, ui, ui2, soft042, perf, hits042, contact), patch/ lint, MISSING.md (audit of every requested item), PROGRESS.md.
- No signing keys and no Latch code are included.

- 0.4.3 (game/pixel-war-0.4.3.html, `pixelwar:latest`): steady even release with 200-400 pixels per side on the field (FLOW slider per path), smooth exit/end/ricochet flight, smoothed defense line, render interpolation, smarter AI with persistent memory (key pixelwar.v43.aimem, DELETE AI MEMORY in the menu). 0.4.2 is game/pixel-war-0.4.2.html (`pixelwar:v042`). Note: the test files in tests/ were NOT re-run for 0.4.3 (some expectations predate the new flow model).
