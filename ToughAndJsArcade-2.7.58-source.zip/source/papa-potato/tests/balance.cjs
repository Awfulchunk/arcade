// Balance sim: auto-buyer (buys when food<2 and affordable), several setting profiles, 3 game-hours.
const S = require("../src/sim.js");
function prof(name, pace, eat, nap, clean, mins) {
  const sim = S.fresh(11); sim.setBox("pace", pace); sim.setBox("eat", eat); sim.setBox("nap", nap); sim.setBox("clean", clean);
  const rows = []; let lastE = 0, lastB = 0;
  for (let step = 0; step < mins * 600; step++) { // 0.1 s
    sim.step(0.1);
    if (step % 10 === 0 && sim.s.food < 2) sim.buyFood();
    if (step % 6000 === 5999) { const st = sim.s.stats; const m = (step + 1) / 600; rows.push({ m, earnedPerMin: +((st.earned - lastE) / 10).toFixed(2), bought: st.bought - lastB, price: sim.price(), coins: sim.s.coins, lazy: +(100 * st.lazyTime / sim.s.t).toFixed(0), peels: sim.s.peels, food: sim.s.food }); lastE = st.earned; lastB = st.bought; }
  }
  const st = sim.s.stats;
  return { name, rows, net: +((st.earned - st.spent) / mins).toFixed(2), gross: +(st.earned / mins).toFixed(2), spent: +(st.spent / mins).toFixed(2), clean: +(100 * st.cleanTime / sim.s.t).toFixed(1), wait: +(100 * st.waitTime / sim.s.t).toFixed(1), firstBuy: st.firstBuyT, lazy: +(100 * st.lazyTime / sim.s.t).toFixed(0), bought: st.bought, endPrice: sim.price(), peeled: st.peeled };
}
const out = [];
for (const [n, p, e, na, c] of [["steady e30 n25 clean20", 2, 30, 25, 20], ["steady clean OFF", 2, 30, 25, 0], ["steady clean 5", 2, 30, 25, 5], ["steady clean 10", 2, 30, 25, 10], ["steady clean 30", 2, 30, 25, 30], ["steady clean 60", 2, 30, 25, 60], ["brisk clean20", 3, 30, 25, 20], ["grind clean20", 4, 30, 25, 20], ["chill clean20", 0, 30, 25, 20], ["all OFF", 2, 0, 0, 0]]) out.push(prof(n, p, e, na, c, 180));
for (const o of out) console.log(o.name.padEnd(24), "gross", o.gross, "spent", o.spent, "NET", o.net, "c/min | cleaning", o.clean + "%", "waiting", o.wait + "%", "lazy", o.lazy + "%", "bought", o.bought, "end price", o.endPrice, "firstBuy", +o.firstBuy.toFixed(0) + "s", "peeled", o.peeled);
console.log("\nsteady clean20 by 10 min blocks (earned/min, bought, price, coins):");
console.log(out[0].rows.slice(0, 18).map((r) => `${r.m}m: ${r.earnedPerMin} e/min, ${r.bought} bought, ${r.price}c, coins ${r.coins}, peels ${r.peels}`).join("\n"));
require("fs").writeFileSync(process.argv[2] || "/tmp/balance02.json", JSON.stringify(out, null, 1));
