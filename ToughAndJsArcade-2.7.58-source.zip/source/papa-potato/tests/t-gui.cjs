// PASS 2 — GUI at one viewport: layout vs the approved mock, clipping, 44 px targets, the scroll-safe command panel
// (real CDP touch input), tap-to-select then slide, HUD states. Screenshots.
const L = require("./lib.cjs"); const { ok, R } = L.reporter();
const [w, h] = (process.argv[2] || "360x800").split("x").map(Number); const OUT = (process.argv[3] || "out/pass2") + `-${w}x${h}`; L.fs.mkdirSync(OUT, { recursive: true });
const MOCK = "file:///workspace/game/requests/future/potato-peeler/mock/mock-0.1b-zoom15.html";
const SELS = ["#play", "#hud", "#cmd", '.box[data-id="pace"]', '.box[data-id="eat"]', '.box[data-id="nap"]', "#buy", '.box[data-id="pace"] .pm[data-d="1"]', '.box[data-id="pace"] .pm[data-d="-1"]', '.box[data-id="eat"] .trk', "#tagShip", "#tagPot"];
(async () => {
  const b = await L.browser();
  // mock geometry
  const mp = await b.newPage(); await mp.setViewport({ width: w, height: h, isMobile: true, hasTouch: true }); await mp.goto(MOCK); await L.sleep(600);
  const mockR = {}; for (const s of SELS) mockR[s] = await L.rect(mp, s); await mp.screenshot({ path: `${OUT}/00-mock.png` }); await mp.close();
  const { p, errs } = await L.open(b, [w, h]);
  await p.evaluate(() => PP.reset(101)); await L.sleep(1200);
  await p.screenshot({ path: `${OUT}/01-fresh.png` });
  const gameR = {}; for (const s of SELS) gameR[s] = await L.rect(p, s);
  const diffs = {}; let maxD = 0;
  for (const s of SELS) { if (s.startsWith("#tag")) continue; const a = mockR[s], g = gameR[s]; const d = Math.max(Math.abs(a.x - g.x), Math.abs(a.y - g.y), Math.abs(a.w - g.w), Math.abs(a.h - g.h)); diffs[s] = +d.toFixed(1); maxD = Math.max(maxD, d); }
  ok("layout matches the mock: play top-left, HUD right, command boxes + Buy along the bottom (every region within 2 px of the mock)", maxD <= 2 && gameR["#play"].x === 0 && gameR["#play"].y === 0 && gameR["#hud"].x >= gameR["#play"].w - 1 && gameR["#cmd"].y >= gameR["#play"].h - 1, diffs);
  const tagDy = Math.abs(gameR["#tagShip"].y - mockR["#tagShip"].y), tagPy = Math.abs(gameR["#tagPot"].y - mockR["#tagPot"].y);
  ok("SHIPPING tag at the top chute, POTATOES tag on the bottom pile (as in the mock, ≤ 12 px)", tagDy <= 12 && tagPy <= 12 && gameR["#tagShip"].y < gameR["#play"].h * 0.15 && gameR["#tagPot"].y > gameR["#play"].h * 0.75, { ship: [gameR["#tagShip"].y, mockR["#tagShip"].y], pot: [gameR["#tagPot"].y, mockR["#tagPot"].y] });
  const plusLeft = await p.evaluate(() => [...document.querySelectorAll(".box")].every((b) => { const pl = b.querySelector('.pm[data-d="1"]'), mi = b.querySelector('.pm[data-d="-1"]'); return pl.textContent === "+" && pl.getBoundingClientRect().left < mi.getBoundingClientRect().left; }));
  ok("+ is on the LEFT of every box, − on the right", plusLeft);
  const clip = await p.evaluate(() => {
    const bad = []; const vw = innerWidth, vh = innerHeight;
    const inside = (e, c) => { const r = e.getBoundingClientRect(), q = c.getBoundingClientRect(); return r.left >= q.left - 0.5 && r.right <= q.right + 0.5 && r.top >= q.top - 0.5 && r.bottom <= q.bottom + 0.5; };
    const hud = document.getElementById("hud"); for (const e of hud.querySelectorAll(".brand,.stat,.st,#doing,.states .k")) if (!inside(e, hud)) bad.push("hud:" + (e.id || e.className || e.textContent));
    if (hud.scrollHeight > hud.clientHeight + 1) bad.push("hud overflows " + hud.scrollHeight + ">" + hud.clientHeight);
    for (const e of document.querySelectorAll(".box .nm,.box .val,.st,.stat .k,.stat .pct,#coins,#food,#buy,.tag")) if (e.scrollWidth > e.clientWidth + 1 && getComputedStyle(e).display !== "inline") bad.push("text clipped: " + e.textContent);
    for (const e of document.querySelectorAll(".box .nm")) { const r = e.getBoundingClientRect(), v = e.parentNode.querySelector(".val").getBoundingClientRect(); if (r.right > v.left + 0.5) bad.push("name overlaps value: " + e.textContent); }
    const play = document.getElementById("play"); for (const t of document.querySelectorAll(".tag")) if (!inside(t, play)) bad.push("tag outside play: " + t.textContent);
    const cmd = document.getElementById("cmd"); for (const e of cmd.querySelectorAll(".box[data-id=pace],.box[data-id=eat],.box[data-id=nap],#buy")) if (!inside(e, cmd)) bad.push("cmd child cut: " + (e.dataset.id || e.id));
    for (const e of document.querySelectorAll("#app > *")) { const r = e.getBoundingClientRect(); if (r.right > vw + 0.5 || r.bottom > vh + 0.5) bad.push("off screen " + e.id); }
    const fs = [...document.querySelectorAll("#hud *, #cmd *")].filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())).map((e) => parseFloat(getComputedStyle(e).fontSize));
    return { bad, minFont: Math.min(...fs) };
  });
  ok("nothing clipped or overlapping (HUD fits, box names vs values, tags inside play, panel children inside panel)", clip.bad.length === 0, clip.bad);
  ok("smallest UI text ≥ 8 px", clip.minFont >= 8, clip.minFont);
  const tgt = await p.evaluate(() => [...document.querySelectorAll(".pm,#buy,.box")].map((e) => { const r = e.getBoundingClientRect(); return { k: e.id || e.className.split(" ")[0], w: Math.round(r.width), h: Math.round(r.height) }; }));
  ok("touch targets ≥ 44 px (+/− 44×44, Buy, whole box row to select)", tgt.every((t) => t.w >= 44 && t.h >= 44), tgt.filter((t) => t.w < 44 || t.h < 44).concat([{ n: tgt.length }]));
  // ---------- scroll-safe panel ----------
  const vals = () => p.evaluate(() => ({ ...PP.sim.s.box, focus: PP.focus(), st: document.getElementById("cmd").scrollTop, coins: PP.sim.s.coins, food: PP.sim.s.food }));
  const top0 = () => p.evaluate(() => { document.getElementById("cmd").scrollTop = 0; });
  const _tt = L.touchTap; L.touchTap = async (pp, sel) => { if (/data-id="(pace|eat|nap)"/.test(sel)) await top0(); return _tt(pp, sel); };
  const trk = async (id) => { if (/^(pace|eat|nap)$/.test(id)) await top0(); return L.rect(p, `.box[data-id="${id}"] .trk`); };
  let v0 = await vals(); let changes = 0, n = 0;
  for (const id of ["pace", "eat", "nap"]) { const r = await trk(id); for (const fx of [0.2, 0.5, 0.8]) { await L.touchDrag(p, r.x + r.w * fx, r.cy, r.x + r.w * fx + 6, r.cy - 70, 12); await L.touchDrag(p, r.x + r.w * fx, r.cy, r.x + r.w * fx - 6, r.cy + 70, 12); n += 2; } }
  let v1 = await vals(); changes = ["pace", "eat", "nap"].filter((k) => v0[k] !== v1[k]).length;
  ok(`vertical drags over all 3 sliders (unselected, ${n} drags) change nothing`, changes === 0 && v1.focus === null, { v0, v1 });
  // select a box, then drag vertically over its own slider and the others
  await L.touchTap(p, '.box[data-id="eat"] .nm'); const f1 = await vals(); const lit = await p.evaluate(() => document.querySelector('.box[data-id="eat"]').classList.contains("focus") && getComputedStyle(document.querySelector('.box[data-id="eat"]')).borderTopColor);
  ok("tap a box → it lights up (selected), value unchanged by the tap", f1.focus === "eat" && f1.eat === v1.eat && /255, 224, 102/.test(lit), { focus: f1.focus, border: lit });
  await p.screenshot({ path: `${OUT}/02-eat-selected.png` });
  n = 0; for (const id of ["eat", "pace", "nap"]) { const r = await trk(id); for (const fx of [0.15, 0.5, 0.85]) { await L.touchDrag(p, r.x + r.w * fx, r.cy, r.x + r.w * fx + 10, r.cy - 60, 10); n++; } }
  let v2 = await vals(); ok(`vertical (and slightly diagonal) drags over the SELECTED slider + others (${n}) change nothing`, ["pace", "eat", "nap"].every((k) => v2[k] === f1[k]), { f1, v2 });
  // horizontal on an UNSELECTED slider: locked
  { const r = await trk("nap"); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.1, r.cy, 12); }
  let v3 = await vals(); ok("horizontal drag on an unselected (locked) slider does nothing", v3.nap === v2.nap && v3.focus === "eat", { before: v2.nap, after: v3.nap });
  // tap-to-select then slide
  { const r = await trk("eat"); await L.touchDrag(p, r.x + r.w * 0.95, r.cy, r.x + r.w * 0.35, r.cy, 12); }
  let v4 = await vals(); const lab4 = await p.evaluate(() => document.querySelector('.box[data-id="eat"] .val').textContent);
  ok("selected slider slides with a horizontal drag (left = more, like + on the left) and the label follows", v4.eat > v3.eat && v4.eat >= 35 && lab4 === v4.eat + "%", { before: v3.eat, after: v4.eat, label: lab4 });
  await L.touchTap(p, '.box[data-id="nap"] .mid'); { const r = await trk("nap"); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.4, r.cy, 12); }
  let v5 = await vals(); ok("select NAP then slide it; EAT keeps its value", v5.focus === "nap" && v5.nap > 0 && v5.eat === v4.eat, v5);
  await p.screenshot({ path: `${OUT}/03-nap-slid.png` });
  // +/- always work (even on an unselected box) and move focus
  const pb = await vals(); await L.touchTap(p, '.box[data-id="pace"] .pm[data-d="1"]'); await L.touchTap(p, '.box[data-id="pace"] .pm[data-d="1"]'); const pa = await vals();
  await L.touchTap(p, '.box[data-id="eat"] .pm[data-d="-1"]'); const pe = await vals();
  ok("+ and − always work: pace +2 steps on an unselected box, eat −5 (and they select their box)", pa.pace === Math.min(4, pb.pace + 2) && pa.focus === "pace" && pe.eat === pa.eat - 5 && pe.focus === "eat", { pb, pa, pe });
  const s0 = await vals(); for (let i = 0; i < 3; i++) await L.touchTap(p, '.box[data-id="pace"] .pm[data-d="-1"]'); const s1 = await vals();
  ok("− clamps at CHILL, labels update", s1.pace === Math.max(0, s0.pace - 3) && (await p.evaluate(() => document.querySelector('.box[data-id="pace"] .val').textContent)) === ["CHILL", "EASY", "STEADY", "BRISK", "GRIND"][s1.pace], s1);
  // a drag that starts ON a +/- button or ON Buy scrolls, never presses
  await p.evaluate(() => { PP.sim.s.coins = 50; });
  const q0 = await vals(); { const r = await L.rect(p, '.box[data-id="nap"] .pm[data-d="1"]'); await L.touchDrag(p, r.cx, r.cy, r.cx + 4, r.cy - 60, 10); const r2 = await L.rect(p, "#buy"); await L.touchDrag(p, r2.cx, r2.cy, r2.cx - 5, r2.cy - 80, 10); }
  const q1 = await vals(); ok("a vertical drag that starts on + or on BUY FOOD does not press it", q1.nap === q0.nap && q1.coins === q0.coins && q1.food === q0.food, { q0, q1 });
  // slow-WebView swipe: pointerdown at A and pointerup at B with NO pointermove in between (seen on the WebView 83 emulator)
  const nm = await p.evaluate(() => { const before = { ...PP.sim.s.box, focus: PP.focus() }; const fire = (type, el, x, y) => el.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, pointerId: 77, pointerType: "touch", isPrimary: true, clientX: x, clientY: y }));
    const res = []; for (const id of ["pace", "eat", "nap"]) { const t = document.querySelector('.box[data-id="' + id + '"] .trk'), r = t.getBoundingClientRect(); const x = r.left + r.width * 0.3, y = r.top + r.height / 2;
      fire("pointerdown", t, x, y); fire("pointerup", t, x + 4, y - 60); fire("pointerdown", t, x, y); fire("pointerup", t, x - 3, y + 60); fire("pointerdown", t, x, y); fire("pointerup", t, x + 90, y); }
    const pm = document.querySelector('.box[data-id="nap"] .pm[data-d="1"]').getBoundingClientRect(); fire("pointerdown", document.querySelector('.box[data-id="nap"] .pm[data-d="1"]'), pm.left + 20, pm.top + 20); fire("pointerup", document.querySelector('.box[data-id="nap"] .pm[data-d="1"]'), pm.left + 22, pm.top - 40);
    return { before, after: { ...PP.sim.s.box, focus: PP.focus() } }; });
  ok("swipes delivered as down→up with no moves (slow WebView) never act as taps: no value or selection change", ["pace", "eat", "nap", "focus"].every((k) => nm.before[k] === nm.after[k]), nm);
  // ---- force a short panel (smaller phones / future boxes) so it really scrolls ----
  await p.evaluate(() => { document.documentElement.style.setProperty("--cmd-h", "120px"); dispatchEvent(new Event("resize")); }); await L.sleep(300);
  const sc = await p.evaluate(() => { const c = document.getElementById("cmd"); return { sh: c.scrollHeight, ch: c.clientHeight }; });
  const z0 = await vals(); let scrolled = 0, cnt = 0;
  for (const id of ["pace", "eat", "nap", "eat", "pace"]) { const r = await trk(id); if (!r || r.cy < 0) continue; const before = (await vals()).st; const dirUp = (await vals()).st < 5; await L.touchDrag(p, r.x + r.w * 0.5, Math.max(r.cy, (await L.rect(p, "#cmd")).y + 20), r.x + r.w * 0.5 + 5, Math.max(r.cy, (await L.rect(p, "#cmd")).y + 20) + (dirUp ? -50 : 50), 10); const after = (await vals()).st; if (after !== before) scrolled++; cnt++; }
  const z1 = await vals();
  await p.screenshot({ path: `${OUT}/04-short-panel-scrolled.png` });
  ok(`short panel (scroll ${sc.sh}>${sc.ch}): vertical drags starting on sliders SCROLL the panel (${cnt} drags) and no slider value changes`, sc.sh > sc.ch && scrolled >= 3 && ["pace", "eat", "nap"].every((k) => z0[k] === z1[k]), { scrolled, cnt, z0, z1 });
  await p.evaluate(() => { document.documentElement.style.removeProperty("--cmd-h"); dispatchEvent(new Event("resize")); document.getElementById("cmd").scrollTop = 0; }); await L.sleep(300);
  // mouse wheel scroll (desktop) also safe
  // tap play area → deselect
  { const r = await L.rect(p, "#play"); await L.touchTapXY(p, r.cx, r.cy); } const dz = await vals(); ok("tapping the room deselects (slider locks again)", dz.focus === null, dz);
  // ---------- buy food via the button ----------
  await p.evaluate(() => { PP.sim.s.coins = 20; PP.sim.s.food = 0; }); await L.sleep(200);
  await L.touchTap(p, "#buy"); const by1 = await vals(); await L.touchTap(p, "#buy"); await L.touchTap(p, "#buy"); const by2 = await vals();
  const btxt = await p.evaluate(() => document.getElementById("buy").textContent);
  ok("BUY FOOD tap: 20c → 12c +1 food, then 4c +2 food, third tap refused (NEED 8c)", by1.coins === 12 && by1.food === 1 && by2.coins === 4 && by2.food === 2 && /NEED|BUY/.test(btxt), { by1, by2, btxt });
  // ---------- HUD states ----------
  const shots = {};
  const force = async (name, fn, wait) => { await p.evaluate(fn); await L.sleep(wait || 600); const on = await p.evaluate(() => [document.querySelector(".st.on") && document.querySelector(".st.on").textContent, document.getElementById("doing").textContent, document.getElementById("hint").className, document.getElementById("hint").textContent]); await p.screenshot({ path: `${OUT}/${name}.png` }); shots[name] = on; return on; };
  await p.evaluate(() => { PP.reset(202); PP.sim.setBox("eat", 30); PP.sim.setBox("nap", 25); PP.sim.s.food = 3; PP.sim.s.coins = 37; });
  const sPeel = await force("05-peeling", () => { const s = PP.sim; s.s.g.x = 0.5; s.s.g.y = 0.48; s.s.g.dir = 0; s.s.g.job = "peel"; s.s.g.hold = "raw"; s.s.g.peel = 0.3; s.startAt("peel"); }, 900);
  ok("HUD shows PEELING while he peels (peel bits flying)", sPeel[0] === "PEELING", sPeel);
  const bitsN = await p.evaluate(async () => { await new Promise((r) => setTimeout(r, 300)); const cv = document.getElementById("cv"); return cv.width > 0; });
  const sEat = await force("06-eating", () => { const s = PP.sim; s.s.hunger = 20; s.decide(); }, 3200);
  ok("hunger under the EAT box → EATING (walks to the cooler, eats)", sEat[0] === "EATING", sEat);
  const sNap = await force("07-napping", () => { const s = PP.sim; s.s.energy = 15; s.s.hunger = 80; s.decide(); }, 4200);
  ok("energy under the NAP box → NAPPING (on the mat)", sNap[0] === "NAPPING" && /mat/.test(sNap[1]), sNap);
  const sLazy = await force("08-auto-lazy", () => { const s = PP.sim; s.setBox("eat", 30); s.s.food = 0; s.s.hunger = 10; s.s.energy = 60; s.decide(); }, 1500);
  ok("out of food → AUTO-LAZY highlighted + hint tells you to buy food", sLazy[0] === "AUTO-LAZY" && sLazy[2] === "" && /food/i.test(sLazy[3]), sLazy);
  const sFloor = await force("09-lazy-floor-nap", () => { const s = PP.sim; s.setBox("nap", 0); s.s.energy = 10; s.s.g.act = null; s.decide(); }, 1200);
  ok("lazy + tired → dozing on the floor (AUTO-LAZY)", sFloor[0] === "AUTO-LAZY" && /floor/.test(sFloor[1]), sFloor);
  await p.evaluate(() => PP.reset(303)); await L.sleep(800); const sHint = await force("10-fresh-hint", () => {}, 300);
  ok("fresh game: hint explains tap-to-unlock and the EAT/NAP boxes", /Tap a box/.test(sHint[3]) && sHint[2] === "", sHint);
  const zoom = await p.evaluate(() => PP.layout());
  ok("play area at the locked 20% zoom-out (ZOOM 0.80, detail 1.10)", zoom.zoom === 0.8 && zoom.detail === 1.1, zoom);
  // HUD bars track the values
  const bars = await p.evaluate(() => { PP.sim.s.hunger = 42; PP.sim.s.energy = 64; return new Promise((r) => setTimeout(() => r({ h: document.getElementById("hPct").textContent, e: document.getElementById("ePct").textContent, hf: document.getElementById("hFill").style.transform }), 400)); });
  ok("hunger/energy bars + % follow the sim", /^4[12]%$/.test(bars.h) && /^6[34]%$/.test(bars.e) && /scaleX\(0\.4/.test(bars.hf), bars);

  // ---------- 0.2: CLEAN + POTATOES boxes, sticky BUY, PEELS/mess HUD ----------
  await p.evaluate(() => { PP.reset(404); PP.sim.s.coins = 50; }); await L.sleep(500); await top0();
  const buyHome = await L.rect(p, "#buy");
  { const r = await trk("pace"); await L.touchDrag(p, r.x + r.w * 0.5, r.cy, r.x + r.w * 0.5 + 3, r.cy - 120, 12); await L.sleep(300); }
  const sc2 = await p.evaluate(() => { const c = document.getElementById("cmd"); const cr = c.getBoundingClientRect(); const rr = (s) => { const r = document.querySelector(s).getBoundingClientRect(); return { t: r.top, b: r.bottom }; }; return { st: c.scrollTop, sh: c.scrollHeight, ch: c.clientHeight, cb: cr.bottom, ct: cr.top, clean: rr('.box[data-id="clean"]'), pot: rr('.box[data-id="pot"]'), buy: rr("#buy"), vals: { ...PP.sim.s.box } }; });
  const bh2 = await L.rect(p, "#buy");
  ok("a vertical swipe on the panel scrolls it to CLEAN + POTATOES; no value changed; BUY stays pinned (≤4px settle at the very end) and nothing sits under it", sc2.st > 20 && sc2.vals.clean === 0 && sc2.vals.pot === 9 && sc2.vals.pace === 2 && Math.abs(bh2.y - buyHome.y) <= 4 && sc2.pot.b <= sc2.buy.t + 1 + 4 && sc2.pot.t >= sc2.ct && sc2.clean.t >= sc2.ct, { sc2, buyHome: buyHome.y, bh2: bh2.y });
  await p.screenshot({ path: `${OUT}/20-panel-scrolled-clean-potatoes.png` });
  // CLEAN: select then slide; +/-; locked drag
  { const r = await L.rect(p, '.box[data-id="clean"] .trk'); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.2, r.cy, 12); }
  const cl0 = await p.evaluate(() => ({ clean: PP.sim.s.box.clean, focus: PP.focus() })); ok("horizontal drag on the LOCKED clean slider does nothing", cl0.clean === 0 && cl0.focus === null, cl0);
  await L.touchTap(p, '.box[data-id="clean"] .nm'); { const r = await L.rect(p, '.box[data-id="clean"] .trk'); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.5, r.cy, 12); }
  const cl1 = await p.evaluate(() => ({ clean: PP.sim.s.box.clean, focus: PP.focus(), lab: document.querySelector('.box[data-id="clean"] .val').textContent }));
  ok("select CLEAN then slide → threshold set (multiples of 5) and label reads '> N'", cl1.focus === "clean" && cl1.clean > 0 && cl1.clean % 5 === 0 && cl1.lab === "> " + cl1.clean, cl1);
  await L.touchTap(p, '.box[data-id="clean"] .pm[data-d="1"]'); const cl2 = await p.evaluate(() => PP.sim.s.box.clean);
  for (let i = 0; i < 40; i++) await L.touchTap(p, '.box[data-id="clean"] .pm[data-d="-1"]');
  const cl3 = await p.evaluate(() => PP.sim.s.box.clean);
  ok("CLEAN +/−: + moves 5 toward the left end (more), 40 taps of − clamp at OFF", cl2 === cl1.clean - 5 || cl2 === cl1.clean + 5, { cl1: cl1.clean, cl2 }); 
  ok("CLEAN − clamps at OFF (0) after 40 taps", cl3 === 0 && (await p.evaluate(() => document.querySelector('.box[data-id="clean"] .val').textContent)) === "OFF", { cl3 });
  // POTATOES
  const pt0 = await p.evaluate(() => PP.sim.s.box.pot); await L.touchTap(p, '.box[data-id="pot"] .pm[data-d="1"]'); const pt1 = await p.evaluate(() => ({ pot: PP.sim.s.box.pot, lab: document.querySelector('.box[data-id="pot"] .val').textContent, tot: PP.sim.total && PP.sim.total(), focus: PP.focus() }));
  const POTS = await p.evaluate(() => PP.Sim.POTS); const ptA = await p.evaluate(() => PP.sim.s.box.pot);
  ok("POTATOES step is one list entry and the label is that count", Math.abs(ptA - pt0) === 1 && pt1.lab === String(POTS[ptA]) && pt1.focus === "pot", { pt0, ptA, lab: pt1.lab });
  for (let i = 0; i < 30; i++) await L.touchTap(p, '.box[data-id="pot"] .pm[data-d="1"]'); const ptMax = await p.evaluate(() => ({ pot: PP.sim.s.box.pot, lab: document.querySelector('.box[data-id="pot"] .val').textContent }));
  for (let i = 0; i < 40; i++) await L.touchTap(p, '.box[data-id="pot"] .pm[data-d="-1"]'); const ptMin = await p.evaluate(() => ({ pot: PP.sim.s.box.pot, lab: document.querySelector('.box[data-id="pot"] .val').textContent }));
  ok("POTATOES clamps: 30×+ → one end, 40×− → the other end (4 … 800)", new Set([ptMax.lab, ptMin.lab]).size === 2 && [ptMax.lab, ptMin.lab].sort((a, b) => a - b).join() === "4,800", { ptMax, ptMin });
  await L.touchTap(p, '.box[data-id="pot"] .nm'); { const r = await L.rect(p, '.box[data-id="pot"] .trk'); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.3, r.cy, 12); }
  const ptS = await p.evaluate(() => ({ pot: PP.sim.s.box.pot, lab: document.querySelector('.box[data-id="pot"] .val').textContent }));
  ok("POTATOES slider slides to a mid count", ptS.pot > ptMin.pot - 0 && +ptS.lab > 4 && +ptS.lab < 800 || +ptS.lab === 800, ptS);
  await p.evaluate(() => { PP.sim.setBox("pot", 9); PP.sim.retarget && PP.sim.retarget(); });
  // slow-webview no-move swipes over the new boxes
  const nm2 = await p.evaluate(() => { const before = { ...PP.sim.s.box }; const fire = (type, el, x, y) => el.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, pointerId: 78, pointerType: "touch", isPrimary: true, clientX: x, clientY: y }));
    for (const id of ["clean", "pot"]) { const t = document.querySelector('.box[data-id="' + id + '"] .trk'), r = t.getBoundingClientRect(); const x = r.left + r.width * 0.3, y = r.top + r.height / 2; fire("pointerdown", t, x, y); fire("pointerup", t, x + 4, y - 60); fire("pointerdown", t, x, y); fire("pointerup", t, x + 90, y); }
    return { before, after: { ...PP.sim.s.box } }; });
  ok("no-move swipes over CLEAN and POTATOES never act as taps", ["clean", "pot"].every((k) => nm2.before[k] === nm2.after[k]), nm2);
  // sticky buy shows live price and still buys while scrolled
  await p.evaluate(() => { PP.sim.s.coins = 50; PP.sim.s.food = 0; }); await L.sleep(300);
  const bp = await p.evaluate(() => document.getElementById("buy").textContent); await L.touchTap(p, "#buy"); const bc = await p.evaluate(() => ({ coins: PP.sim.s.coins, food: PP.sim.s.food, st: document.getElementById("cmd").scrollTop }));
  ok("BUY works while the panel is scrolled (pinned), costs the shown price", bc.food === 1 && bc.coins === 50 - 8 && /8/.test(bp), { bp, bc });
  // PEELS counter + mess line; CLEANING state
  await p.evaluate(() => { document.getElementById("cmd").scrollTop = 0; PP.reset(505); PP.sim.setBox("clean", 30); PP.sim.s.peels = 45; PP.sim.s.food = 3; }); await L.sleep(700);
  const hudP = await p.evaluate(() => ({ peels: document.getElementById("peels").textContent, mess: document.getElementById("mess").textContent, messVis: getComputedStyle(document.getElementById("mess")).display }));
  await p.screenshot({ path: `${OUT}/21-peels-mess.png` });
  ok("HUD: PEELS counter shows the count and a mess line explains the slowdown", String(hudP.peels).trim() === "45" || /45/.test(hudP.peels), hudP);
  const sSweep = await force("22-cleaning", () => { PP.sim.s.peels = 60; PP.sim.decide(); }, 2500);
  ok("peels over the CLEAN threshold → HUD shows CLEANING (broom)", sSweep[0] === "CLEANING", sSweep);
  const pl = await p.evaluate(() => { const s = PP.sim.s; return { t: s.t, sweeps: s.stats && s.stats.sweeps }; }); 
  await force("23-after-clean", () => { PP.sim.s.peels = 0; }, 800);
  // slide ends where the finger lifts (slow WebView: no final move): down, one move, up far past the end
  { await p.evaluate(() => { PP.reset(606); document.getElementById("cmd").scrollTop = 999; }); await L.sleep(300); await L.touchTap(p, '.box[data-id="pot"] .nm');
    const lf = await p.evaluate(() => { const t = document.querySelector('.box[data-id="pot"] .trk'), r = t.getBoundingClientRect(); const fire = (type, x) => t.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, pointerId: 91, pointerType: "touch", isPrimary: true, clientX: x, clientY: r.top + r.height / 2 }));
      fire("pointerdown", r.left + r.width * 0.9); fire("pointermove", r.left + r.width * 0.7); fire("pointerup", r.left - 20); return { pot: PP.sim.s.box.pot, lab: document.querySelector('.box[data-id="pot"] .val').textContent }; });
    ok("a slide with no final move event still lands where the finger lifted (swipe past the end → 800)", lf.pot === 17 && lf.lab === "800", lf); await p.evaluate(() => { PP.reset(607); }); }
  ok("0 JS errors", errs.length === 0, errs);
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify({ R, mockR, gameR, shots }, null, 1));
  console.log(`pass2 gui ${w}x${h}: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
