// PASS 1 — Mechanics sim. Runs the real game file in headless Chrome and fast-forwards the SAME PPSim code
// (dt = 0.05 s, the live step) for 40 min of game time per box setting, with an instrumented decide().
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const OUT = process.argv[2] || "out/pass1"; L.fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [360, 800]);
  const res = await p.evaluate(() => {
    const S = PP.Sim, C = S.C, out = {};
    function runCfg(name, box, opt) {
      opt = opt || {}; const s = S.fresh(opt.seed || 11); Object.assign(s.s.box, box); if (opt.food != null) s.s.food = opt.food; if (opt.coins != null) s.s.coins = opt.coins;
      const T = opt.T || 2400, h = 0.05; const r = { name, box: JSON.stringify(box), violations: [], maxActDur: 0, maxActKind: "", windowsNoPeel: 0, minH: 100, minE: 100, wakeE: [], eatStarts: 0, napStarts: 0, lazyEnter: 0, lazyWithFood: 0, coinNeg: 0, sloppyCoins: 0, cleanCoins: 0, lazyCoinsClean: 0 };
      let act = null, actT = 0, lastPeeled = 0, winT = 0, wasLazy = false;
      for (let i = 0; i < T / h; i++) {
        const before = s.s.g.act; const pk = s.s.stats.peeled;
        s.step(h);
        if (opt.autobuy && s.s.food < 2) s.buyFood();
        const st = s.s, g = st.g, a = g.act;
        // events
        while (st.ev.length) { const e = st.ev.shift(); if (e.k === "coin") { if (e.sloppy) r.sloppyCoins++; else r.cleanCoins++; if (e.v !== (e.sloppy ? C.sloppyValue : C.value)) r.violations.push("coin value " + e.v); } }
        if (a !== before && a) {
          // a new decision was made at this step: check it against the needs
          const n = s.needState();
          if (a.t === "walk" && a.then === "eat") { r.eatStarts++; if (!(box.eat > 0 && st.hunger < box.eat && st.food > 0)) r.violations.push("eat w/o need t=" + st.t.toFixed(1)); }
          if (a.t === "walk" && a.then === "nap") { r.napStarts++; if (!(box.nap > 0 && st.energy < box.nap)) r.violations.push("nap w/o need t=" + st.t.toFixed(1)); }
          if (a.t === "walk" && /grab|peel|drop/.test(a.then)) { if (n.wantEat) r.violations.push("worked while wantEat t=" + st.t.toFixed(1)); if (n.wantNap) r.violations.push("worked while wantNap t=" + st.t.toFixed(1)); }
          if (before && before.t === "nap") r.wakeE.push(st.energy);
          if (/^(walk|lazynap|idle)$/.test(a.t) && g.lazy !== n.lazy && !(a.t === "walk" && (a.then === "eat" || a.then === "nap"))) r.violations.push("lazy flag mismatch t=" + st.t.toFixed(1));
        }
        if (g.lazy && !wasLazy) r.lazyEnter++; wasLazy = g.lazy;
        if (g.lazy && st.food > 0 && box.eat > 0 && box.nap > 0) r.lazyWithFood++;
        if (a === act) { actT += h; if (actT > r.maxActDur) { r.maxActDur = actT; r.maxActKind = a ? a.t : "none"; } } else { act = a; actT = 0; }
        if (!a) r.violations.push("no activity");
        r.minH = Math.min(r.minH, st.hunger); r.minE = Math.min(r.minE, st.energy);
        if (st.coins < 0 || st.hunger < 0 || st.hunger > 100 || st.energy < 0 || st.energy > 100 || !isFinite(g.x + g.y)) r.violations.push("range t=" + st.t.toFixed(1));
        winT += h; if (winT >= 180) { if (st.stats.peeled === lastPeeled) r.windowsNoPeel++; lastPeeled = st.stats.peeled; winT = 0; }
      }
      const st = s.s.stats;
      Object.assign(r, { T, coins: s.s.coins, food: s.s.food, peeled: st.peeled, meals: st.meals, naps: st.naps, lazyNaps: st.lazyNaps, lazyPct: +(st.lazyTime / T * 100).toFixed(1), firstBuy: +st.firstBuyT.toFixed(1), cpm: +(st.earned / T * 60).toFixed(2), netpm: +((st.earned - st.spent) / T * 60).toFixed(2), minH: +r.minH.toFixed(1), minE: +r.minE.toFixed(1), wakeMin: r.wakeE.length ? +Math.min(...r.wakeE).toFixed(1) : null, maxActDur: +r.maxActDur.toFixed(1) });
      r.violations = r.violations.slice(0, 5).concat(r.violations.length > 5 ? ["…" + r.violations.length] : []); delete r.wakeE; return r;
    }
    out.cfgs = [
      runCfg("chill sane", { pace: 0, eat: 30, nap: 25 }, { autobuy: 1 }),
      runCfg("easy sane", { pace: 1, eat: 35, nap: 30 }, { autobuy: 1, seed: 2 }),
      runCfg("steady sane", { pace: 2, eat: 30, nap: 25 }, { autobuy: 1, seed: 3 }),
      runCfg("brisk sane", { pace: 3, eat: 40, nap: 30 }, { autobuy: 1, seed: 4 }),
      runCfg("grind sane", { pace: 4, eat: 30, nap: 25 }, { autobuy: 1, seed: 5 }),
      runCfg("grind max boxes", { pace: 4, eat: 70, nap: 70 }, { autobuy: 1, seed: 6 }),
      runCfg("steady min boxes", { pace: 2, eat: 5, nap: 5 }, { autobuy: 1, seed: 7 }),
      runCfg("all unset (fresh)", { pace: 2, eat: 0, nap: 0 }, { seed: 8 }),
      runCfg("eat set, food never bought", { pace: 2, eat: 30, nap: 25 }, { seed: 9 }),
      runCfg("eat set, nap unset", { pace: 3, eat: 30, nap: 0 }, { autobuy: 1, seed: 10 }),
      runCfg("eat unset, nap set", { pace: 2, eat: 0, nap: 30 }, { seed: 12 }),
    ];
    // fresh player, buys food the moment they can (sane boxes set at t=0)
    out.firstBuy = [1, 2, 3, 4, 5, 6].map((seed) => { const s = S.fresh(seed); s.s.box.eat = 30; s.s.box.nap = 25; let t = 0; while (s.buyFood() !== "ok" && t < 600) { s.step(0.05); t += 0.05; } return +t.toFixed(1); });
    // auto-lazy specifics: no food + eat set
    { const s = S.fresh(21); s.s.box.eat = 40; s.s.box.nap = 25; s.s.food = 0; s.s.hunger = 41; let lazyAt = -1; for (let i = 0; i < 2000 && lazyAt < 0; i++) { s.step(0.05); if (s.s.g.lazy) lazyAt = s.s.t; }
      const lz = { lazyAt: +lazyAt.toFixed(1), hunger: +s.s.hunger.toFixed(1), state: s.stateName(), spd: s.spd() };
      s.run(300, 0.05); lz.sloppy = s.s.stats.peeled > 0; const c0 = s.s.coins; s.s.coins = Math.max(s.s.coins, 8); lz.buy = s.buyFood(); let wentEat = false, ate = false; for (let i = 0; i < 400; i++) { s.step(0.05); const a = s.s.g.act; if (a && a.t === "walk" && a.then === "eat") wentEat = true; if (s.s.stats.meals > 0) { ate = true; break; } }
      lz.wentEat = wentEat; lz.ate = ate; lz.lazyAfter = s.s.g.lazy; lz.stateAfter = s.stateName(); out.lazy = lz; }
    // unset-box lazy threshold (25%) + "naps when he likes" on the floor
    { const s = S.fresh(22); s.s.box.nap = 0; s.s.energy = 26; let at = -1, floor = false; for (let i = 0; i < 6000; i++) { s.step(0.05); if (s.s.g.lazy && at < 0) at = s.s.energy; if (s.s.g.act && s.s.g.act.t === "lazynap") { floor = true; break; } } out.unsetNap = { lazyAtEnergy: at, floorNap: floor, state: s.stateName() }; }
    // no death: 30 min starving with nothing set
    { const s = S.fresh(23); s.s.hunger = 0; s.s.energy = 0; const p0 = s.s.stats.peeled; s.run(1800, 0.05); out.noDeath = { peeled: s.s.stats.peeled - p0, hunger: s.s.hunger, alive: !!s.s.g.act, lazy: s.s.g.lazy }; }
    // pace raises speed and drain together
    out.pace = [0, 1, 2, 3, 4].map((pc) => { const s = S.fresh(30); s.s.box.pace = pc; s.s.box.eat = 0; s.s.box.nap = 0; const h0 = s.s.hunger, e0 = s.s.energy; s.run(60, 0.05); return { pace: S.PACE[pc], peeled: s.s.stats.peeled, x: +(s.s.g.peel).toFixed(2), hungerUsed: +(h0 - s.s.hunger).toFixed(2), energyUsed: +(e0 - s.s.energy).toFixed(2) }; });
    // box clamps / steps
    { const s = S.fresh(31); s.setBox("eat", 999); const a = s.s.box.eat; s.setBox("eat", -5); const b2 = s.s.box.eat; s.setBox("nap", 33); const c = s.s.box.nap; s.setBox("pace", 9); const d = s.s.box.pace; out.clamp = { a, b: b2, c, d }; }
    // buy rules
    { const s = S.fresh(32); const r1 = s.buyFood(); s.s.coins = 100; s.s.food = 8; const r2 = s.buyFood(); const r3 = s.buyFood(); out.buy = { r1, r2, r3, coins: s.s.coins, food: s.s.food }; }
    // save/load round trip, exact continuation, corrupted save rejected
    { const a = S.fresh(40); a.s.box.eat = 30; a.s.box.nap = 25; a.s.box.pace = 3; a.run(777, 0.05); const str = a.serialize(); const b2 = S.load(str); const same0 = b2.serialize() === str; a.run(600, 0.05); b2.run(600, 0.05);
      out.saveload = { same0, sameAfter600: a.serialize() === b2.serialize(), coins: a.s.coins, bad1: S.load("{not json") === null, bad2: S.load('{"v":2}') === null, bad3: S.load("null") === null,
        fixed: (() => { const o = JSON.parse(str); o.box.eat = 999; o.hunger = -40; o.food = 99; const z = S.load(JSON.stringify(o)); return z && z.s.box.eat === 0 && z.s.hunger === 0 && z.s.food === C.foodMax; })() }; }
    return out;
  });
  L.fs.writeFileSync(`${OUT}/mech.json`, JSON.stringify(res, null, 1));
  console.log("cfg | coins food peeled meals naps lazyNaps lazy% cpm net/min minH minE wake maxAct windowsNoPeel violations");
  for (const c of res.cfgs) console.log(`${c.name.padEnd(28)} ${c.box} | ${c.coins} ${c.food} ${c.peeled} ${c.meals} ${c.naps} ${c.lazyNaps} ${c.lazyPct}% ${c.cpm} ${c.netpm} ${c.minH} ${c.minE} ${c.wakeMin} ${c.maxActDur}s(${c.maxActKind}) ${c.windowsNoPeel} ${JSON.stringify(c.violations)}`);
  for (const c of res.cfgs) {
    ok(`[${c.name}] 40 min: loop never stalls (every 3-min window peels ≥1, no activity > 45 s, always an activity)`, c.windowsNoPeel === 0 && c.maxActDur <= 45 && c.peeled > 50, { peeled: c.peeled, maxAct: c.maxActDur, kind: c.maxActKind });
    ok(`[${c.name}] decisions obey the boxes, values in range (0 violations)`, c.violations.length === 0, c.violations);
  }
  const by = (n) => res.cfgs.find((c) => c.name === n);
  for (const n of ["chill sane", "easy sane", "steady sane", "brisk sane", "grind sane", "steady min boxes"]) { const c = by(n); const box = JSON.parse(c.box);
    ok(`[${n}] self-sustains: never lazy, net coins/min > 0, hunger stays ≥ ${Math.max(0, box.eat - 8)}, energy ≥ ${Math.max(0, box.nap - 8)}, naps wake at ≥ 98`, c.lazyPct === 0 && c.netpm > 0 && c.minH >= box.eat - 8 && c.minE >= box.nap - 8 && (c.wakeMin === null || c.wakeMin >= 98) && c.meals > 0 && c.naps > 0, { net: c.netpm, minH: c.minH, minE: c.minE, wake: c.wakeMin, meals: c.meals, naps: c.naps }); }
  ok("grind + max eat/nap boxes meets the 0.2 food-price pushback: no violations, still earns and never dies (may run dry: net ≥ 0, price tops out)", by("grind max boxes").violations.length === 0 && by("grind max boxes").netpm >= 0, { net: by("grind max boxes").netpm, v: by("grind max boxes").violations.slice(0, 3) });
  ok("economy sane: steady 4–15 c/min, grind earns more gross than chill, grind net ≤ brisk net + 1 (trade-off)", by("steady sane").cpm >= 4 && by("steady sane").cpm <= 15 && by("grind sane").cpm > by("chill sane").cpm && by("grind sane").netpm <= by("brisk sane").netpm + 1, { steady: by("steady sane").cpm, chill: by("chill sane").cpm, grind: by("grind sane").cpm, grindNet: by("grind sane").netpm, briskNet: by("brisk sane").netpm });
  ok("max eat/nap boxes cost more (net lower than steady sane) but still positive", by("grind max boxes").netpm < by("steady sane").netpm && by("grind max boxes").netpm >= 0, by("grind max boxes").netpm);
  ok("first food purchase reachable in 1–2 min (instant buyer, 6 seeds: 50–120 s)", res.firstBuy.every((t) => t >= 50 && t <= 120), res.firstBuy);
  ok("all boxes unset → mostly AUTO-LAZY, lazy floor naps happen, still earns (no death)", by("all unset (fresh)").lazyPct > 50 && by("all unset (fresh)").lazyNaps > 5 && by("all unset (fresh)").peeled > 0 && by("all unset (fresh)").meals === 0, by("all unset (fresh)"));
  ok("eat set but food never bought → eats the 1 starter meal, then AUTO-LAZY", by("eat set, food never bought").meals === 1 && by("eat set, food never bought").lazyPct > 50, { meals: by("eat set, food never bought").meals, lazy: by("eat set, food never bought").lazyPct });
  ok("nap box unset → lazy floor naps instead of mat naps", by("eat set, nap unset").naps === 0 && by("eat set, nap unset").lazyNaps > 0, { naps: by("eat set, nap unset").naps, lazyNaps: by("eat set, nap unset").lazyNaps });
  ok("eat box unset → never eats even with food", by("eat unset, nap set").meals === 0, by("eat unset, nap set").meals);
  const lz = res.lazy;
  ok("out of food: AUTO-LAZY as soon as hunger < box (40%), state AUTO-LAZY, speed 0.5×", lz.lazyAt >= 0 && lz.hunger < 40 && lz.state === "AUTO-LAZY" && lz.spd === 0.5, lz);
  ok("buying food while lazy → he goes to eat, eats, leaves AUTO-LAZY", lz.buy === "ok" && lz.wentEat && lz.ate && !lz.lazyAfter && lz.stateAfter !== "AUTO-LAZY", lz);
  ok("lazy peels are sloppy (1c instead of 2c)", by("all unset (fresh)").sloppyCoins > 0 && by("eat set, food never bought").sloppyCoins > 0, { a: by("all unset (fresh)").sloppyCoins, b: by("eat set, food never bought").sloppyCoins });
  ok("unset NAP box → lazy below 25% energy, then naps on the floor", res.unsetNap.lazyAtEnergy > 0 && res.unsetNap.lazyAtEnergy < 25 && res.unsetNap.floorNap, res.unsetNap);
  ok("no death: 30 min at 0 hunger / 0 energy, he keeps (sloppily) peeling", res.noDeath.alive && res.noDeath.peeled > 20, res.noDeath);
  const pc = res.pace; let mono = true; for (let i = 1; i < 5; i++) if (!(pc[i].hungerUsed > pc[i - 1].hungerUsed && pc[i].energyUsed > pc[i - 1].energyUsed && (pc[i].peeled + pc[i].x) > (pc[i - 1].peeled + pc[i - 1].x))) mono = false;
  ok("work pace raises speed AND drain together (CHILL→GRIND strictly increasing, 60 s)", mono, pc);
  ok("box values clamp and step (eat 999→70, -5→OFF, nap 33→35, pace 9→GRIND)", res.clamp.a === 70 && res.clamp.b === 0 && res.clamp.c === 35 && res.clamp.d === 4, res.clamp);
  ok("buy food: poor at 0c, costs 8c, max 9 meals", res.buy.r1 === "poor" && res.buy.r2 === "ok" && res.buy.r3 === "full" && res.buy.coins === 92 && res.buy.food === 9, res.buy);
  const sl = res.saveload;
  ok("save/load round-trips byte-identical and continues identically for 10 more minutes", sl.same0 && sl.sameAfter600, sl);
  ok("corrupt / wrong-version saves are rejected, out-of-range values are clamped", sl.bad1 && sl.bad2 && sl.bad3 && sl.fixed, sl);
  // ---- the live page: localStorage, real reload, time only runs while open ----
  await p.evaluate(() => { PP.reset(77); PP.sim.setBox("eat", 45); PP.sim.setBox("nap", 35); PP.sim.setBox("pace", 3); PP.sim.s.coins = 123; PP.sim.s.food = 4; PP.save(); });
  const saved = await p.evaluate(() => JSON.parse(localStorage.getItem(PP.key)));
  await p.reload(); await p.waitForFunction(() => window.__PP_READY === true); await L.sleep(400);
  const after = await p.evaluate(() => ({ box: PP.sim.s.box, coins: PP.sim.s.coins, food: PP.sim.s.food, t: PP.sim.s.t, ui: [...document.querySelectorAll(".box .val")].map((e) => e.textContent), coinsUi: document.getElementById("coins").textContent }));
  ok("live page: localStorage save survives a real page reload (boxes, coins, food, HUD + box labels)", after.box.eat === 45 && after.box.nap === 35 && after.box.pace === 3 && after.coins >= 123 && after.food <= 4 && after.food >= 3 && after.ui.slice(0, 3).join() === "BRISK,45%,35%" && +after.coinsUi >= 123, { saved: saved.box, after });
  // time only while open: hidden → paused; closed page → no catch-up
  const vis = await p.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); Object.defineProperty(document, "hidden", { configurable: true, get: () => true }); document.dispatchEvent(new Event("visibilitychange")); const t0 = PP.sim.s.t; await w(2500); const t1 = PP.sim.s.t; Object.defineProperty(document, "hidden", { configurable: true, get: () => false }); document.dispatchEvent(new Event("visibilitychange")); await w(1500); const t2 = PP.sim.s.t; return { hiddenAdvance: +(t1 - t0).toFixed(2), visibleAdvance: +(t2 - t1).toFixed(2) }; });
  ok("time stops while the game is hidden and resumes when shown", vis.hiddenAdvance === 0 && vis.visibleAdvance > 0.8, vis);
  const tClose = await p.evaluate(() => { PP.save(); return PP.sim.s.t; }); await p.goto("about:blank"); await L.sleep(4000);
  await p.goto(L.GAME); await p.waitForFunction(() => window.__PP_READY === true); const tOpen = await p.evaluate(() => PP.sim.s.t);
  ok("closed for 4 s → no offline catch-up (game time continues from the save)", tOpen - tClose < 1.0 && tOpen >= tClose, { tClose, tOpen });
  // live loop fast-forward 30 min while rendering, and 20 s of real-time play
  const live = await p.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); PP.reset(5); PP.sim.setBox("eat", 30); PP.sim.setBox("nap", 25); PP.sim.setBox("clean", 20); const c0 = PP.sim.s.coins; for (let i = 0; i < 30; i++) { PP.sim.run(60, 0.05); if (PP.sim.s.food < 2) PP.sim.buyFood(); await w(50); } const ff = { coins: PP.sim.s.coins, peeled: PP.sim.s.stats.peeled, t: Math.round(PP.sim.s.t) }; const t0 = PP.sim.s.t, p0 = PP.sim.s.stats.peeled; await w(20000); return { ff, real20: +(PP.sim.s.t - t0).toFixed(1), peeled20: PP.sim.s.stats.peeled - p0, state: document.querySelector(".st.on").textContent }; });
  ok("live page: 30 min fast-forward with the renderer running + 20 s real time (game time ≈ real time)", live.ff.peeled > 90 && live.real20 > 18 && live.real20 < 21.5 && live.peeled20 >= 1, live);
  ok("0 JS errors (page errors + console errors)", errs.length === 0, errs);
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify(R, null, 1));
  console.log(`pass1 mechanics: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
