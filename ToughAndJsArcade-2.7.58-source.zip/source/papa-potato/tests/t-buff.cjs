// BUFF TESTING — break tests for Papa Potato 0.2 (headless Chrome, 360x800 touch, real CDP input where it matters).
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const OUT = process.argv[2] || "out/buff"; L.fs.mkdirSync(OUT, { recursive: true });
const fixture = L.fs.readFileSync(__dirname + "/fixtures/v1-save.json", "utf8");
const INV = `(() => { const s = PP.sim.s, POTS = PP.Sim.POTS, bad = []; const fin = (k, v) => { if (typeof v !== "number" || !isFinite(v)) bad.push("nonfinite " + k); };
  ["coins","food","hunger","energy","peels","pile","chute","t"].forEach((k) => fin(k, s[k]));
  if (s.coins < 0) bad.push("coins<0"); if (s.food < 0) bad.push("food<0"); if (s.peels < 0 || s.peels > 200) bad.push("peels " + s.peels); if (s.pile < 0) bad.push("pile<0"); if (s.chute < 0 || s.chute > 6) bad.push("chute " + s.chute);
  if (s.hunger < 0 || s.hunger > 100 || s.energy < 0 || s.energy > 100) bad.push("needs range");
  if (PP.sim.total() !== POTS[s.box.pot]) bad.push("total " + PP.sim.total() + " != " + POTS[s.box.pot]);
  for (const k in s.box) { if (!Number.isInteger(s.box[k])) bad.push("box " + k + "=" + s.box[k]); }
  if (s.box.pace < 0 || s.box.pace > 4 || s.box.pot < 0 || s.box.pot > POTS.length - 1 || s.box.eat < 0 || s.box.eat > 70 || s.box.nap < 0 || s.box.nap > 70 || s.box.clean < 0 || s.box.clean > 90) bad.push("box range " + JSON.stringify(s.box));
  return bad; })()`;
async function openWith(b, size, keys) { // fresh tab; set storage BEFORE the game scripts run (once per tab)
  const p = await b.newPage(); const errs = []; p.on("pageerror", (e) => errs.push(e.message)); p.on("console", (m) => { if (m.type() === "error") errs.push("console: " + m.text()); });
  await p.setViewport({ width: size[0], height: size[1], deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.evaluateOnNewDocument((k) => { try { if (!sessionStorage.getItem("__set")) { sessionStorage.setItem("__set", "1"); for (const n of ["papaPotato.save.v1", "papaPotato.save.v2"]) { if (k && n in k) { if (k[n] === null) localStorage.removeItem(n); else localStorage.setItem(n, k[n]); } } } } catch (e) {} }, keys || { "papaPotato.save.v1": null, "papaPotato.save.v2": null });
  await p.goto(L.GAME); await p.waitForFunction(() => window.__PP_READY === true, { timeout: 10000 }); await L.sleep(400); await p.evaluate(() => { window.__fill = (n) => { const s = PP.sim.s, d = Math.min(n - s.chute, s.pile); if (d > 0) { s.pile -= d; s.chute += d; } }; }); return { p, errs };
}
(async () => {
  const b = await L.browser(); const POTS = [4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 160, 200, 250, 300, 400, 500, 650, 800];
  // 1. spam taps: 400 real touch taps in a seeded random pattern over every + / − / box name / BUY / the room
  { const { p, errs } = await openWith(b, [360, 800]); await p.evaluate(() => { PP.reset(11); PP.sim.s.coins = 30; });
    let seed = 12345; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
    const targets = ['.box[data-id="pace"] .pm[data-d="1"]', '.box[data-id="pace"] .pm[data-d="-1"]', '.box[data-id="eat"] .pm[data-d="1"]', '.box[data-id="eat"] .pm[data-d="-1"]', '.box[data-id="nap"] .pm[data-d="1"]', '.box[data-id="nap"] .pm[data-d="-1"]', '.box[data-id="clean"] .pm[data-d="1"]', '.box[data-id="clean"] .pm[data-d="-1"]', '.box[data-id="pot"] .pm[data-d="1"]', '.box[data-id="pot"] .pm[data-d="-1"]', '.box[data-id="eat"] .nm', '.box[data-id="pot"] .nm', "#buy", "#play"];
    const t0 = Date.now(); let n = 0; const rects = {};
    for (let i = 0; i < 400; i++) { const sel = targets[Math.floor(rnd() * targets.length)]; const r = await L.rect(p, sel); if (!r) continue; if (r.cy > 800 || r.cy < 0) { await p.evaluate(() => { document.getElementById("cmd").scrollTop = 0; }); continue; } await L.touchTapXY(p, r.cx, r.cy); n++; if (i % 25 === 0) await p.evaluate(() => { const c = document.getElementById("cmd"); c.scrollTop = c.scrollTop > 40 ? 0 : 200; }); }
    await L.sleep(1500); const bad = await p.evaluate(INV); const st = await p.evaluate(() => ({ box: PP.sim.s.box, coins: PP.sim.s.coins, food: PP.sim.s.food, bought: PP.sim.s.stats.bought, t: PP.sim.s.t, price: PP.sim.price() }));
    // DOM-level storm: 6000 synchronous pointer events (down/move/up) at random places on the panel
    await p.evaluate(() => { const els = [...document.querySelectorAll("#cmd .box, #cmd .pm, #cmd .trk, #buy, #play")]; let s = 99; const rn = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
      for (let i = 0; i < 2000; i++) { const e = els[Math.floor(rn() * els.length)], r = e.getBoundingClientRect(), x = r.left + rn() * r.width, y = r.top + rn() * r.height, id = 100 + (i % 5);
        for (const [t, dx, dy] of [["pointerdown", 0, 0], ["pointermove", rn() * 80 - 40, rn() * 80 - 40], ["pointerup", rn() * 80 - 40, rn() * 80 - 40]]) e.dispatchEvent(new PointerEvent(t, { bubbles: true, cancelable: true, pointerId: id, pointerType: "touch", isPrimary: i % 2 === 0, clientX: x + dx, clientY: y + dy })); } });
    await L.sleep(1500); const bad2 = await p.evaluate(INV); const adv = await p.evaluate(() => PP.sim.s.t); await L.sleep(1500); const adv2 = await p.evaluate(() => PP.sim.s.t);
    ok(`spam: ${n} real taps + 6000 synthetic pointer events: invariants hold (potatoes conserved, no NaN, ranges), 0 JS errors, game still runs`, bad.length === 0 && bad2.length === 0 && errs.length === 0 && adv2 > adv + 1, { n, ms: Date.now() - t0, bad, bad2, errs: errs.slice(0, 3), st });
    await p.screenshot({ path: `${OUT}/01-after-spam.png` }); await p.close(); }
  // 2. extreme slider values: API junk is clamped; drags far beyond the track ends hit min/max
  { const { p, errs } = await openWith(b, [360, 800]); await p.evaluate(() => PP.reset(21));
    const r = await p.evaluate(() => { const o = {}; for (const id of ["pace", "eat", "nap", "clean", "pot"]) { const res = []; for (const v of [-5, -1e9, 1e9, NaN, "x", null, undefined, 3.7, Infinity, -Infinity]) { try { PP.sim.setBox(id, v); res.push(PP.sim.s.box[id]); } catch (e) { res.push("THROW " + e.message); } } o[id] = res; } return o; });
    const okv = Object.entries(r).every(([id, arr]) => arr.every((v) => Number.isInteger(v) && v >= 0 && v <= { pace: 4, eat: 70, nap: 70, clean: 90, pot: 17 }[id]));
    ok("extreme setBox values (±1e9, NaN, strings, null, ±Infinity, 3.7) on all 5 boxes: always clamped integers in range, never throws", okv && (await p.evaluate(INV)).length === 0, r);
    await p.evaluate(() => { PP.reset(22); document.getElementById("cmd").scrollTop = 999; }); await L.sleep(200); await L.touchTap(p, '.box[data-id="pot"] .nm');
    const tr = await L.rect(p, '.box[data-id="pot"] .trk'); await L.touchDrag(p, tr.x + tr.w * 0.5, tr.cy, tr.x - 400, tr.cy, 10); const hi = await p.evaluate(() => PP.sim.s.box.pot); await L.touchDrag(p, tr.x + tr.w * 0.5, tr.cy, tr.x + tr.w + 900, tr.cy, 10); const lo = await p.evaluate(() => PP.sim.s.box.pot);
    ok("dragging the POTATOES slider far past either end (±900 px) → exactly the max (800) / the min (4)", hi === 17 && lo === 0, { hi, lo });
    await p.evaluate(() => { PP.sim.setBox("pot", 17); }); await L.sleep(300); const t800 = await p.evaluate(() => PP.sim.total()); await p.evaluate(() => { PP.sim.setBox("pot", 0); }); await L.sleep(600); const t4 = await p.evaluate(() => PP.sim.total());
    ok("jumping 800 → 4 potatoes → 800 conserves the count each time (no loss, no duplicates), pile layer follows", t800 === 800 && t4 === 4 && (await p.evaluate(INV)).length === 0 && errs.length === 0, { t800, t4, errs });
    await p.close(); }
  // 3. max potatoes + 4. zero coins + 5. full chute + full peels (all at once), 40 s live + 2 sim-hours of stepping
  { const { p, errs } = await openWith(b, [360, 800]); await p.evaluate(() => { PP.reset(31); PP.sim.setBox("pot", 17); PP.sim.setBox("clean", 5); PP.sim.setBox("eat", 40); PP.sim.setBox("nap", 30); PP.sim.s.coins = 0; PP.sim.s.food = 0; PP.sim.s.peels = 200; window.__fill(6); });
    await L.sleep(1500); await L.touchTap(p, "#buy"); await L.touchTap(p, "#buy"); const c0 = await p.evaluate(() => ({ coins: PP.sim.s.coins, food: PP.sim.s.food, lab: document.getElementById("buy").textContent }));
    ok("0 coins: BUY taps refused (coins stay ≥ 0, no food), the label says NEED", c0.coins >= 0 && c0.food === 0 && /NEED/.test(c0.lab), c0);
    await L.sleep(35000); const b0 = await p.evaluate(INV); const mid = await p.evaluate(() => ({ st: (document.querySelector(".st.on") || {}).textContent, peels: PP.sim.s.peels, sweeps: PP.sim.s.stats.sweeps, sucks: PP.sim.s.stats.sucks, pile: PP.sim.s.pile, coins: PP.sim.s.coins }));
    await p.screenshot({ path: `${OUT}/02-max-potatoes-full-peels-zero-coins.png` });
    ok("800 potatoes + 200 peels + chute full + 0 coins + 0 food, 35 s live: invariants hold, 0 errors, he still works (suck/sweep happened)", b0.length === 0 && errs.length === 0 && (mid.sucks >= 1 || mid.sweeps >= 1), { b0, mid, errs });
    // 2 sim-hours of stepping with rendering running, checking invariants every sim minute and the heap every sim 30 min
    const cdp = await L.cdp(p); const heap = async () => { await cdp.send("HeapProfiler.collectGarbage"); return (await cdp.send("Runtime.getHeapUsage")).usedSize; }; const h0 = await heap();
    const run = await p.evaluate(() => new Promise((res) => { const bad = []; let steps = 0, minutes = 0, lastMin = 0; const t0 = PP.sim.s.t; const iv = setInterval(() => { for (let i = 0; i < 400; i++) { PP.sim.step(0.05); steps++; } if (PP.sim.s.t - lastMin >= 60) { lastMin = PP.sim.s.t; minutes++; const s = PP.sim.s; if (!isFinite(s.coins) || s.coins < 0 || s.peels < 0 || s.peels > 200 || PP.sim.total() !== 800 || s.food < 0) bad.push("min" + minutes); } if (PP.sim.s.t - t0 >= 7200) { clearInterval(iv); res({ bad, simSeconds: PP.sim.s.t - t0, steps, stats: PP.sim.s.stats }); } }, 8); }));
    const h1 = await heap(); const bad3 = await p.evaluate(INV);
    ok("2 game hours (at ~20x speed, rendering live) at 800 potatoes: invariants every sim-minute, 0 errors", run.bad.length === 0 && bad3.length === 0 && errs.length === 0 && run.simSeconds >= 7200, { simH: +(run.simSeconds / 3600).toFixed(2), bad: run.bad, stats: { peeled: run.stats.peeled, sucks: run.stats.sucks, sweeps: run.stats.sweeps, meals: run.stats.meals, maxPeels: run.stats.maxPeels } });
    ok("heap flat after 2 game hours (after GC within +1.5 MB of the start)", h1 < h0 + 1.5e6, { h0, h1 }); await p.close(); }
  // 6. rapid pause/resume
  { const { p, errs } = await openWith(b, [360, 800]); await p.evaluate(() => { PP.reset(41); window.__fill(5); });
    const r = await p.evaluate(() => new Promise((res) => { const t0 = PP.sim.s.t, w0 = performance.now(); let n = 0, vis = false; const iv = setInterval(() => { vis = !vis; Object.defineProperty(document, "hidden", { configurable: true, get: () => !vis }); document.dispatchEvent(new Event("visibilitychange")); window.dispatchEvent(new Event(vis ? "focus" : "blur")); if (!vis) window.dispatchEvent(new Event("pagehide")); n++; if (n >= 400) { clearInterval(iv); Object.defineProperty(document, "hidden", { configurable: true, get: () => false }); document.dispatchEvent(new Event("visibilitychange")); res({ n, dt: PP.sim.s.t - t0, wall: (performance.now() - w0) / 1000 }); } }, 10); }));
    await L.sleep(1500); const bad = await p.evaluate(INV);
    ok("400 rapid hide/show + pagehide events: sim time never runs faster than the wall clock, invariants hold, 0 errors", r.dt <= r.wall + 0.5 && bad.length === 0 && errs.length === 0, { r, bad, errs });
    // pause/resume via the hook mid-suction, 200 times
    await p.evaluate(() => { window.__fill(6); PP.sim.startSuck(); }); const sp = await p.evaluate(() => new Promise((res) => { let n = 0; const iv = setInterval(() => { PP.pause(n % 2 === 0); n++; if (n >= 200) { clearInterval(iv); PP.pause(false); res(n); } }, 7); })); await L.sleep(7000);
    ok("200 pause/resume flips during a suction: the suction still completes, total conserved", (await p.evaluate(() => !PP.sim.s.suck)) && (await p.evaluate(INV)).length === 0, { sp });
    await p.close(); }
  // 7. old/corrupted saves in real localStorage
  { const cases = [
      ["old 0.1 save only → migrated (v2 written, v1 key untouched)", { "papaPotato.save.v1": fixture, "papaPotato.save.v2": null }, async (p) => { const r = await p.evaluate(() => ({ mig: PP.migrated, v: PP.sim.s.v, total: PP.sim.total(), v1: localStorage.getItem("papaPotato.save.v1"), v2: !!localStorage.getItem("papaPotato.save.v2") })); await L.sleep(4500); const v2 = await p.evaluate(() => !!localStorage.getItem("papaPotato.save.v2")); return [r.mig && r.v === 2 && r.total === 128 && r.v1 === fixture && v2, r]; }],
      ["corrupt v2 + good v1 → falls back to the 0.1 save", { "papaPotato.save.v1": fixture, "papaPotato.save.v2": "{not json" }, async (p) => { const r = await p.evaluate(() => ({ mig: PP.migrated, total: PP.sim.total() })); return [r.mig && r.total === 128, r]; }],
      ["both corrupt → fresh game, no crash", { "papaPotato.save.v1": "}{garbage", "papaPotato.save.v2": "\u0000\u0001" }, async (p) => { const r = await p.evaluate(() => ({ mig: PP.migrated, t: PP.sim.s.t, coins: PP.sim.s.coins, total: PP.sim.total() })); return [!r.mig && r.t < 5 && r.total === 128, r]; }],
      ["v2 with NaN/negative/huge fields → rejected or repaired, never propagates", { "papaPotato.save.v1": null, "papaPotato.save.v2": JSON.stringify({ v: 2, t: "NaN", coins: -50, food: 1e12, hunger: -5, energy: 500, pile: 1e9, chute: 99, peels: -3, box: { pace: 99, eat: -1, nap: 1e9, clean: 7.5, pot: 99 } }) }, async (p) => { await L.sleep(1500); const bad = await p.evaluate(INV); return [bad.length === 0, { bad }]; }],
      ["huge string (2 MB) in the v2 slot", { "papaPotato.save.v1": null, "papaPotato.save.v2": "x".repeat(2e6) }, async (p) => { const r = await p.evaluate(() => ({ total: PP.sim.total() })); return [r.total === 128, r]; }],
      ["empty-object saves {} / [] / null-string", { "papaPotato.save.v1": "{}", "papaPotato.save.v2": "[]" }, async (p) => { const bad = await p.evaluate(INV); return [bad.length === 0, { bad }]; }],
    ];
    for (const [name, keys, check] of cases) { const { p, errs } = await openWith(b, [360, 800], keys); await L.sleep(800); const [pass, d] = await check(p); await L.sleep(1200); const bad = await p.evaluate(INV); ok("save: " + name + "; invariants + 0 JS errors", pass && bad.length === 0 && errs.length === 0, { ...d, bad, errs: errs.slice(0, 2) }); await p.close(); } }
  // 8. force-kill mid-suction: crash the tab (no unload handlers), reopen with the same storage
  { const { p } = await openWith(b, [360, 800]); await p.evaluate(() => { PP.reset(51); PP.sim.setBox("pot", 15); window.__fill(6); PP.sim.startSuck(); PP.save(); });
    const pre = await p.evaluate(() => ({ suck: PP.sim.s.suck, t: PP.sim.s.t, total: PP.sim.total() })); const cdp = await L.cdp(p); cdp.send("Page.crash").catch(() => {}); await L.sleep(1200); await p.close().catch(() => {});
    const q = await b.newPage(); const errs = []; q.on("pageerror", (e) => errs.push(e.message)); await q.setViewport({ width: 360, height: 800, isMobile: true, hasTouch: true }); await q.goto(L.GAME); await q.waitForFunction(() => window.__PP_READY === true, { timeout: 10000 }); await L.sleep(500);
    const post = await q.evaluate(() => ({ suck: PP.sim.s.suck, t: PP.sim.s.t, total: PP.sim.total(), pot: PP.sim.s.box.pot, mig: PP.migrated })); await L.sleep(6000); const post2 = await q.evaluate(() => ({ suck: PP.sim.s.suck, total: PP.sim.total() })); const bad = await q.evaluate(INV);
    ok("force-kill (tab crash) mid-suction → reopen: same sim time and suction restored, it completes, potatoes conserved (500), 0 errors", pre.suck && post.suck && Math.abs(post.t - pre.t) < 1 && post.total === 500 && post2.suck === null && post2.total === 500 && bad.length === 0 && errs.length === 0 && !post.mig, { pre, post, post2, bad, errs }); await q.close(); }
  // 9. resize / orientation storm with the cached layers
  { const { p, errs } = await openWith(b, [360, 800]); await p.evaluate(() => { PP.reset(61); PP.sim.setBox("pot", 17); PP.sim.s.peels = 100; }); await L.sleep(800); const r0 = await p.evaluate(() => PP.stats());
    const sizes = [[800, 360], [320, 568], [360, 800], [412, 915], [568, 320], [360, 640], [1024, 600], [360, 800]]; for (let i = 0; i < 24; i++) { const [w, h] = sizes[i % sizes.length]; await p.setViewport({ width: w, height: h, deviceScaleFactor: 1 + (i % 2), isMobile: true, hasTouch: true }); await L.sleep(120); }
    await L.sleep(1200); const r1 = await p.evaluate(() => PP.stats()); const bad = await p.evaluate(INV); await p.screenshot({ path: `${OUT}/03-after-resize-storm.png` });
    ok("24 resizes/orientation flips at 800 potatoes: layout rebuilt, invariants hold, 0 errors, pile re-renders bounded (<300)", bad.length === 0 && errs.length === 0 && r1.pileRenders - r0.pileRenders < 300, { r0, r1, bad, errs }); await p.close(); }
  ok("browser still alive at the end (no crash)", (await b.pages()).length >= 1, "");
  L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify(R, null, 1)); console.log(`buff: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
