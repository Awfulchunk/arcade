// PASS 1B — Mechanics of the 0.2 features, on the real game file (PP.Sim = the shipped PPSim), headless Chrome.
// Chute + suction loop, potato conservation, peels / mess penalty / CLEAN, potatoes slider, food price, balance, save v2, 0.1 migration.
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const OUT = process.argv[2] || "out/pass1b"; L.fs.mkdirSync(OUT, { recursive: true });
const V1 = L.fs.readFileSync(__dirname + "/fixtures/v1-save.json", "utf8");
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [360, 800]);
  const E = (fn, arg) => p.evaluate(fn, arg);
  await p.evaluate((v) => { window.__V1 = v; }, V1);
  const A = await E(() => {
    const S = PP.Sim, C = S.C, POTS = S.POTS, out = {};
    const mk = (seed, box, o) => { const s = S.fresh(seed); Object.assign(s.s.box, box || {}); s.retarget(); if (o) Object.assign(s.s, o); return s; };
    // ---- 1: long random torture: invariants every step, 4 game-hours, boxes and pot slider changed at random
    { const s = mk(5, { eat: 30, nap: 25, clean: 20 }); s.s.food = 9; let rng = 12345; const rnd = () => (rng = (rng * 1664525 + 1013904223) >>> 0) / 4294967296; const bad = [];
      let maxChute = 0, maxPeels = 0, minPile = 1e9, sucks0 = 0;
      for (let i = 0; i < 4 * 3600 / 0.05; i++) {
        s.step(0.05); const q = s.s;
        if (i % 20 === 0 && q.food < 2) { q.coins = Math.max(q.coins, 40); s.buyFood(); }
        if (i % 1200 === 0) { const r = rnd(); if (r < 0.34) s.setBox("pot", Math.floor(rnd() * POTS.length)); else if (r < 0.5) s.setBox("clean", Math.floor(rnd() * 19) * 5); else if (r < 0.65) s.setBox("pace", Math.floor(rnd() * 5)); else if (r < 0.8) s.setBox("eat", Math.floor(rnd() * 15) * 5); else s.setBox("nap", Math.floor(rnd() * 15) * 5); }
        if (i % 7 === 0) { if (s.total() !== POTS[q.box.pot]) bad.push("total " + s.total() + " != " + POTS[q.box.pot] + " @" + q.t.toFixed(1)); if (q.pile < 0 || q.chute < 0 || q.chute > C.chuteCap || q.peels < 0 || q.peels > C.peelMax || !isFinite(q.coins) || q.coins < 0) bad.push("range @" + q.t.toFixed(1)); if (q.suck && (q.suck.landed > q.suck.n || q.suck.n < 1)) bad.push("suck state"); if (q.hunger < 0 || q.hunger > 100 || q.energy < 0 || q.energy > 100) bad.push("needs range"); }
        maxChute = Math.max(maxChute, q.chute); maxPeels = Math.max(maxPeels, q.peels); minPile = Math.min(minPile, q.pile);
        if (bad.length > 5) break;
      }
      out.torture = { bad: bad.slice(0, 5), maxChute, maxPeels, minPile, sucks: s.s.stats.sucks, peeled: s.s.stats.peeled, t: Math.round(s.s.t) };
    }
    // ---- 2: chute loop timeline (deterministic): fill the chute to 6, the 6th drop starts the suction
    { const s = mk(3, { eat: 0, nap: 0 }); s.s.hunger = 100; s.s.energy = 100; const tl = { startedAt: null, busyUntil: null, backAt: null, doneAt: null, pileAt: [], chuteAfter: null, dropWait: false };
      let sawBusyWait = false, lastSucks = 0, pile0 = null;
      for (let i = 0; i < 60 * 20 * 6; i++) { s.step(0.05); const q = s.s;
        if (q.stats.sucks > lastSucks && tl.startedAt === null) { tl.startedAt = q.t; tl.chuteAfter = q.chute; tl.n = q.suck.n; tl.pileAtStart = q.pile; tl.totalAtStart = s.total(); lastSucks = q.stats.sucks; }
        if (tl.startedAt !== null && s.suckBusy()) { const a = q.g.act; if (a && a.label === "waiting for the chute") sawBusyWait = true; }
        if (tl.startedAt !== null && !s.suckBusy() && tl.busyUntil === null) tl.busyUntil = q.t - tl.startedAt;
        if (tl.startedAt !== null && !q.suck && tl.doneAt === null) { tl.doneAt = q.t - tl.startedAt; tl.pileEnd = q.pile; tl.totalEnd = s.total(); break; } }
      out.loop = tl; out.loopWait = sawBusyWait; }
    // ---- 3: busy-chute wait: Papa holding a skinned potato at the chute while it is sucking waits, then ships it
    { const s = mk(4, { eat: 0, nap: 0 }); s.s.hunger = 100; s.s.energy = 100; s.s.chute = 5; s.s.pile = POTS[9] - 5 - 1; s.s.g.hold = "peeled"; s.s.g.job = "chute"; s.s.g.x = 0.5; s.s.g.y = 0.175; s.walkTo(0.5, 0.175, 0, "drop", "x");
      s.startSuck(); /* a suction is already running */ const t0 = s.s.t; let dropAt = null, c0 = s.s.coins; for (let i = 0; i < 200; i++) { s.step(0.05); if (s.s.coins > c0 && dropAt === null) dropAt = s.s.t - t0; }
      out.busy = { dropAt, coins: s.s.coins - c0, total: s.total(), want: POTS[s.s.box.pot] }; }
    // ---- 4: the pile never runs out, even at the lowest potato count (4), 60 min
    { const s = mk(8, { pot: 0, eat: 30, nap: 25, clean: 20 }); s.s.food = 9; let minPile = 99, emptyT = 0, stuck = 0, lastPeeled = 0, lastT = 0, maxGap = 0;
      for (let i = 0; i < 3600 / 0.05; i++) { s.step(0.05); if (s.s.food < 2) { s.s.coins = Math.max(s.s.coins, 30); s.buyFood(); } minPile = Math.min(minPile, s.s.pile); if (s.s.pile === 0) emptyT += 0.05; if (s.s.stats.peeled > lastPeeled) { maxGap = Math.max(maxGap, s.s.t - lastT); lastPeeled = s.s.stats.peeled; lastT = s.s.t; } }
      out.low = { minPile, emptyT: +emptyT.toFixed(1), peeled: s.s.stats.peeled, sucks: s.s.stats.sucks, maxGap: +maxGap.toFixed(1), wait: +s.s.stats.waitTime.toFixed(1), total: s.total() }; }
    // ---- 5: peels: 3 per skinned potato, 5 per sloppy one, counter cap 999
    { const s = mk(2, { eat: 0, nap: 0 }); s.s.hunger = 100; s.s.energy = 100; let n0 = s.s.stats.peeled; const seen = []; let p0 = s.s.peels;
      for (let i = 0; i < 2400; i++) { s.step(0.05); while (s.s.ev.length) { const e = s.s.ev.shift(); if (e.k === "peeled") seen.push(s.s.peels - p0), p0 = s.s.peels; } if (seen.length >= 3) break; }
      const l = mk(2, { eat: 70, nap: 0 }); l.s.food = 0; l.s.hunger = 5; let lz = []; let q0 = l.s.peels; for (let i = 0; i < 6000; i++) { l.step(0.05); while (l.s.ev.length) { const e = l.s.ev.shift(); if (e.k === "peeled") { lz.push(l.s.peels - q0); q0 = l.s.peels; } } if (lz.length >= 3) break; }
      const cap = mk(2, { eat: 0, nap: 0 }); cap.s.hunger = 100; cap.s.energy = 100; cap.s.peels = 197; for (let i = 0; i < 4000; i++) cap.step(0.05); out.peels = { clean: seen, lazy: lz, cap: cap.s.peels }; }
    // ---- 6: mess penalty: speed factor, and real throughput with peels pinned
    { const s = mk(1, {}); const f = []; for (const pe of [0, 30, 45, 90, 500]) { s.s.peels = pe; f.push(+s.messF().toFixed(3)); }
      const thr = (pin) => { const q = mk(9, { eat: 0, nap: 0 }); q.s.hunger = 100; q.s.energy = 100; for (let i = 0; i < 1200 / 0.05; i++) { q.s.hunger = 100; q.s.energy = 100; if (pin >= 0) q.s.peels = pin; q.step(0.05); } return q.s.stats.peeled; };
      out.mess = { f, clean: thr(0), full: thr(90) }; }
    // ---- 7: CLEAN box
    { const off = mk(6, { eat: 0, nap: 0, clean: 0 }); off.s.hunger = 100; off.s.energy = 100; off.s.peels = 80; let swept = 0; for (let i = 0; i < 3000; i++) { off.s.hunger = 100; off.s.energy = 100; off.step(0.05); if (off.s.stats.sweeps) swept++; }
      const on = mk(6, { eat: 0, nap: 0, clean: 20 }); on.s.hunger = 100; on.s.energy = 100; on.s.peels = 30; const trace = []; let started = null, ended = null, atSpot = null, holdAtStart = null;
      for (let i = 0; i < 4000; i++) { on.s.hunger = 100; on.s.energy = 100; on.step(0.05); const a = on.s.g.act; if (a && a.t === "sweep" && started === null) { started = on.s.t; atSpot = [on.s.g.x, on.s.g.y]; holdAtStart = on.s.g.hold; trace.push(on.s.peels); } if (started !== null && on.s.stats.sweeps >= 1 && ended === null) { ended = on.s.t; break; } }
      out.clean = { offSweeps: swept, started: started && +started.toFixed(1), took: started && +(ended - started).toFixed(2), peelsAfter: on.s.peels, atSpot, holdAtStart, startPeels: trace[0], spot: S.SPOT.sweep };
      // eating interrupts sweeping; lowering the box to OFF stops it
      const ei = mk(6, { eat: 40, nap: 0, clean: 5 }); ei.s.food = 5; ei.s.hunger = 100; ei.s.energy = 100; ei.s.peels = 60; let stage = 0, ateWhileSweep = false, hh = 100;
      for (let i = 0; i < 3000 && stage < 3; i++) { ei.step(0.05); const a = ei.s.g.act; if (stage === 0 && a && a.t === "sweep") { stage = 1; ei.s.hunger = 30; } if (stage === 1 && a && (a.t === "walk" && a.then === "eat" || a.t === "eat")) { stage = 2; ateWhileSweep = ei.s.peels > 0; } }
      const so = mk(6, { eat: 0, nap: 0, clean: 5 }); so.s.hunger = 100; so.s.energy = 100; so.s.peels = 60; let ss = false, stopped = false; for (let i = 0; i < 2000; i++) { so.s.hunger = 100; so.s.energy = 100; so.step(0.05); const a = so.s.g.act; if (!ss && a && a.t === "sweep") { ss = true; so.setBox("clean", 0); } if (ss && a && a.t !== "sweep" && !(a.t === "walk" && a.then === "sweep")) { stopped = true; break; } }
      out.cleanInt = { eatInterrupts: stage === 2 && ateWhileSweep, offStops: stopped };
      // never starts a sweep with a potato in his hands
      const hs = mk(10, { eat: 0, nap: 0, clean: 5 }); hs.s.hunger = 100; hs.s.energy = 100; let bad = 0; for (let i = 0; i < 12000; i++) { hs.s.hunger = 100; hs.s.energy = 100; hs.step(0.05); const a = hs.s.g.act; if (a && a.t === "walk" && a.then === "sweep" && hs.s.g.hold) bad++; if (a && a.t === "sweep" && hs.s.g.hold) bad++; } out.cleanHold = bad; out.cleanSweeps = hs.s.stats.sweeps; }
    // ---- 8: balance across clean settings (3 game-hours, auto-buyer)
    { const run = (box) => { const s = mk(11, box); let lastB = 0; for (let i = 0; i < 180 * 600; i++) { s.step(0.1); if (i % 10 === 0 && s.s.food < 2) s.buyFood(); } const st = s.s.stats; return { gross: +(st.earned / 180).toFixed(2), net: +((st.earned - st.spent) / 180).toFixed(2), clean: +(100 * st.cleanTime / s.s.t).toFixed(1), lazy: +(100 * st.lazyTime / s.s.t).toFixed(0), bought: st.bought, price: s.price() }; };
      out.bal = { off: run({ eat: 30, nap: 25, clean: 0 }), c5: run({ eat: 30, nap: 25, clean: 5 }), c20: run({ eat: 30, nap: 25, clean: 20 }), c60: run({ eat: 30, nap: 25, clean: 60 }), grind: run({ pace: 4, eat: 30, nap: 25, clean: 20 }), chill: run({ pace: 0, eat: 30, nap: 25, clean: 20 }) }; }
    // ---- 9: food price
    { const s = mk(1, {}); const pr = []; for (let b = 0; b <= 30; b += 5) { s.s.stats.bought = b; pr.push(s.price()); } s.s.stats.bought = 0; s.s.t = 0; const t0 = s.price(); s.s.t = 900 * 3; const t3 = s.price(); s.s.stats.bought = 99; s.s.t = 1e6;
      const capp = s.price(); const q = mk(1, {}); q.s.coins = 7; const poor = q.buyFood(); q.s.coins = 8; const ok1 = q.buyFood(); const c1 = q.s.coins; q.s.coins = 100; q.s.food = 0; const secondPrice = q.price(); const ok2 = q.buyFood();
      out.price = { pr, t0, t3, capp, poor, ok1, c1, secondPrice, spentOk: q.s.stats.spent, coinsAfter2: q.s.coins }; }
    // ---- 10: no death spiral: worst settings, clean OFF; then fix the settings and recover
    { const s = mk(13, { pace: 4, eat: 70, nap: 70, clean: 0 }); let minCoins = 1e9; for (let i = 0; i < 180 * 600; i++) { s.step(0.1); if (i % 10 === 0 && s.s.food < 2) s.buyFood(); minCoins = Math.min(minCoins, s.s.coins); }
      const worst = { earnedPerMin: +(s.s.stats.earned / 180).toFixed(2), lazy: +(100 * s.s.stats.lazyTime / s.s.t).toFixed(0), coins: s.s.coins, minCoins, peels: s.s.peels, price: s.price() };
      s.setBox("pace", 2); s.setBox("eat", 30); s.setBox("nap", 25); s.setBox("clean", 20); let rl = null; for (let i = 0; i < 45 * 600; i++) { s.step(0.1); if (i % 10 === 0 && s.s.food < 2) s.buyFood(); if (rl === null && !s.s.g.lazy) rl = s.s.t; } const e0 = s.s.stats.earned, sp0 = s.s.stats.spent, lz0 = s.s.stats.lazyTime; for (let i = 0; i < 15 * 600; i++) { s.step(0.1); if (i % 10 === 0 && s.s.food < 2) s.buyFood(); }
      out.spiral = { worst, recover: { netPerMin: +(((s.s.stats.earned - e0) - (s.s.stats.spent - sp0)) / 15).toFixed(2), lazyPct: +(100 * (s.s.stats.lazyTime - lz0) / 900).toFixed(0), firstWorkingAfterMin: rl && +((rl - 10800) / 60).toFixed(1) } };
      const z = mk(14, { eat: 0, nap: 0, clean: 0 }); z.s.coins = 0; z.s.food = 0; for (let i = 0; i < 20 * 600; i++) z.step(0.1); out.zero = { coins: z.s.coins, peeled: z.s.stats.peeled, alive: z.s.hunger >= 0 }; }
    // ---- 11: potato slider table + clamp + immediate effect
    { const s = mk(1, {}); const r = { pots: POTS.slice(), up: POTS.every((v, i) => !i || v > POTS[i - 1]), min: POTS[0], max: POTS[POTS.length - 1], def: POTS[S.BOX.pot.def] };
      s.setBox("pot", 99); r.clampHi = s.s.box.pot === POTS.length - 1; s.setBox("pot", -4); r.clampLo = s.s.box.pot === 0; s.setBox("pot", 9); r.t9 = s.total() === POTS[9]; s.setBox("pot", 17); r.t15 = s.total() === 800 && s.s.pile === 800; s.setBox("pot", 0); r.t0 = s.total() === 4 && s.s.pile === 4 - (s.s.g.hold ? 1 : 0);
      // shrinking while potatoes are in the chute and in transit still conserves
      const q = mk(2, { eat: 0, nap: 0 }); q.s.chute = 5; q.s.g.hold = null; q.startSuck(); q.s.chute = 3; q.s.pile -= 3; for (let i = 0; i < 60; i++) q.step(0.05); q.setBox("pot", 0); r.shrinkInTransit = q.total() === 4; for (let i = 0; i < 600; i++) q.step(0.05); r.afterSettle = q.total() === 4 && q.s.pile >= 0; out.pots = r; }
    // ---- 12: save v2 round-trip, mid-suction determinism
    { const s = mk(21, { eat: 30, nap: 25, clean: 20 }); s.s.food = 9; let found = false; for (let i = 0; i < 20000; i++) { s.step(0.05); if (s.s.suck && s.s.t - s.s.suck.t0 > 0.9) { found = true; break; } }
      const str = s.serialize(), l = S.load(str), l2 = S.load(str); const same0 = l && l.serialize() === str; for (let i = 0; i < 1200; i++) { s.step(0.05); if (l) l.step(0.05); }
      out.save = { found, same0, sameAfter60: !!l && s.serialize() === l.serialize(), suckInSave: JSON.parse(str).suck !== null, v: JSON.parse(str).v }; }
    // ---- 13: 0.1 migration (fixture saved by the real 0.1 sim) + garbage rejection
    { const m = S.load(window.__V1); const r = {}; if (m) { const o = JSON.parse(window.__V1); r.v = m.s.v; r.coins = m.s.coins === o.coins; r.food = m.s.food === o.food; r.box = m.s.box.pace === o.box.pace && m.s.box.eat === o.box.eat && m.s.box.nap === o.box.nap; r.newBoxes = m.s.box.clean === 0 && m.s.box.pot === S.BOX.pot.def; r.hold = m.s.g.hold; r.total = m.total() === POTS[S.BOX.pot.def]; r.t = m.s.t === o.t; r.peels = m.s.peels; r.pile = m.s.pile; r.chute = m.s.chute;
        for (let i = 0; i < 12000; i++) { m.step(0.05); if (m.s.food < 2) { m.s.coins += 10; m.buyFood(); } } r.runs = m.total() === POTS[m.s.box.pot] && m.s.stats.peeled > o.stats.peeled; }
      const bad = ["", "{", "null", "[]", '{"v":3}', '{"v":2,"coins":"x"}', '{"v":1,"coins":5}', '{"v":2,"coins":5,"g":null,"box":{}}'].map((x) => S.load(x) === null);
      const fuzz = []; const base = JSON.parse(window.__V1); const mut = [(o) => (o.peels = -5), (o) => (o.pile = 1e12), (o) => (o.chute = 99), (o) => (o.suck = { t0: "x", n: 5, landed: 9 }), (o) => (o.box.pot = 400), (o) => (o.box.clean = "a"), (o) => (o.coins = 1e30), (o) => (o.food = -3), (o) => (o.t = -4), (o) => (o.g.act = { t: "bogus" }), (o) => (o.g.act = { t: "walk", x: "n", y: 1 }), (o) => (o.g.hold = "gold"), (o) => (o.stats = 7), (o) => (o.hunger = "NaN"), (o) => (o.v = 2), (o) => (o.suck = { t0: 5, n: 3, landed: 1 })];
      for (const f of mut) { const o = JSON.parse(JSON.stringify(base)); f(o); let ok2 = false, why = ""; try { const q = S.load(JSON.stringify(o)); if (q) { for (let i = 0; i < 2400; i++) q.step(0.05); const s2 = q.s; ok2 = isFinite(s2.coins) && s2.coins >= 0 && s2.pile >= 0 && s2.chute >= 0 && s2.chute <= 6 && s2.peels >= 0 && s2.peels <= 200 && q.total() === POTS[s2.box.pot]; if (!ok2) why = JSON.stringify([s2.coins, s2.pile, s2.chute, s2.peels, q.total()]); } else ok2 = true; } catch (e) { ok2 = false; why = String(e); } fuzz.push(ok2 || why); }
      out.mig = { r, bad, fuzz }; }
    return out;
  }).catch((e) => ({ error: String(e) }));
  if (A.error) { console.log("FAIL evaluate error", A.error); process.exit(1); }
  const near = (a, b, e) => Math.abs(a - b) <= e;
  const T = A.torture, Lp = A.loop;
  ok("4 game-hours of random box + potato-slider changes: potatoes conserved (pile+hand+chute+transit = slider) on every check, all values in range", T.bad.length === 0 && T.maxChute <= 6 && T.sucks > 80 && T.peeled > 300, T);
  ok("chute loop: 6th skinned potato starts the suction, chute empties, busy window = 2.0 s", !!Lp.startedAt && Lp.n === 6 && Lp.chuteAfter === 0 && near(Lp.busyUntil, 2.0, 0.1) && Lp.totalAtStart === 128, Lp);
  ok("suction loop timeline: they come back onto the pile (skin on) ~4.9 s later, all 6, nothing lost", near(Lp.doneAt, 4.9, 0.15) && Lp.pileEnd === Lp.pileAtStart + 6 && Lp.totalEnd === 128, { doneAt: Lp.doneAt, pileAtStart: Lp.pileAtStart, pileEnd: Lp.pileEnd });
  ok("a full / sucking chute makes Papa wait, then ship the potato (coins paid once, nothing lost)", A.busy.dropAt >= 2.0 && A.busy.dropAt < 2.4 && A.busy.coins === C_VALUE() && A.busy.total === A.busy.want, A.busy);
  ok("the pile never runs out, even with the lowest potato count (4) for an hour: no deadlock, keeps peeling", A.low.total === 4 && A.low.peeled > 120 && A.low.maxGap < 60 && A.low.sucks > 20, A.low);
  ok("peels: +3 per skinned potato, +5 for a sloppy (lazy) one, counter capped at 200", A.peels.clean.every((v) => v === 3) && A.peels.lazy.length >= 3 && A.peels.lazy.every((v) => v === 5) && A.peels.cap === 200, A.peels);
  ok("mess penalty: speed ×1.0 (0 peels) → 0.9 (30) → 0.85 (45) → 0.70 (90+, capped)", JSON.stringify(A.mess.f) === JSON.stringify([1, 0.9, 0.85, 0.7, 0.7]), A.mess.f);
  ok("a full mess really slows the work: ~30% fewer potatoes peeled in 20 min", near(A.mess.full / A.mess.clean, 0.70, 0.07), A.mess);
  ok("CLEAN box OFF: Papa never sweeps, however messy", A.clean.offSweeps === 0, A.clean);
  ok("CLEAN > 20: he walks to the broom spot, sweeps ~6 peels/s (+0.8 s wind-up) until the floor is clear, hands empty", A.clean.started !== null && A.clean.holdAtStart === null && A.clean.peelsAfter === 0 && A.clean.took > 4.5 && A.clean.took < 9 && near(A.clean.atSpot[0], A.clean.spot.x, 0.02) && near(A.clean.atSpot[1], A.clean.spot.y, 0.02), A.clean);
  ok("eating interrupts sweeping; setting CLEAN to OFF stops it", A.cleanInt.eatInterrupts && A.cleanInt.offStops, A.cleanInt);
  ok("he never starts a sweep with a potato in his hands (CLEAN 5 for 10 game-min)", A.cleanHold === 0 && A.cleanSweeps >= 10, { bad: A.cleanHold, sweeps: A.cleanSweeps });
  const bl = A.bal;
  ok("balance (3 game-hours): cleaning pays: CLEAN OFF earns >15% less than CLEAN 20; CLEAN 60 earns less than 20; CLEAN 5 wastes more time than 20", bl.off.gross < bl.c20.gross * 0.85 && bl.c60.gross < bl.c20.gross && bl.c5.clean > bl.c20.clean * 1.5, bl);
  ok("balance: steady settings net 1–3.5 c/min after food (price rises 8 → 14), grind nets less than steady, chill still positive, no lazy time", bl.c20.net >= 1 && bl.c20.net <= 3.5 && bl.grind.net < bl.c20.net && bl.chill.net > 0.5 && bl.c20.lazy === 0, { c20: bl.c20, grind: bl.grind, chill: bl.chill });
  const P = A.price;
  ok("food price: 8c first, then 8·1.05^bought + 1c per 15 game-min, capped at 14c; BUY charges exactly the shown price", P.pr[0] === 8 && P.pr.every((v, i) => !i || v >= P.pr[i - 1]) && P.pr[P.pr.length - 1] === 14 && P.t0 === 8 && P.t3 === 11 && P.capp === 14 && P.poor === "poor" && P.ok1 === "ok" && P.c1 === 0 && P.spentOk === 16, P);
  ok("no death spiral: grind + eat 70 + nap 70 + CLEAN OFF for 3 h never goes negative and keeps earning; fixing the boxes recovers within 45 min (last 15 min: net > 0.5 c/min, ~0% lazy)", A.spiral.worst.minCoins >= 0 && A.spiral.worst.earnedPerMin > 0.8 && A.spiral.recover.netPerMin > 0.5 && A.spiral.recover.lazyPct < 5, A.spiral);
  ok("0 coins + 0 food + everything unset: he still works (lazy) and earns, alive", A.zero.coins >= 0 && A.zero.peeled > 5 && A.zero.alive, A.zero);
  const Pt = A.pots;
  ok("potatoes slider: 18 steps 4 → 800, default 128, clamps, total follows the slider immediately (also while potatoes are in the chute / in transit)", Pt.pots.length === 18 && Pt.up && Pt.min === 4 && Pt.max === 800 && Pt.def === 128 && Pt.clampHi && Pt.clampLo && Pt.t9 && Pt.t15 && Pt.t0 && Pt.shrinkInTransit && Pt.afterSettle, Pt);
  ok("save v2 round-trips byte-identical, also in the middle of a suction, and continues identically for 60 s", A.save.found && A.save.suckInSave && A.save.same0 && A.save.sameAfter60 && A.save.v === 2, A.save);
  const M = A.mig.r;
  ok("0.1 save (real 0.1 sim output, mid-job holding a raw potato) migrates: coins/food/boxes/time kept, new boxes default, potato count rebuilt, runs on", M.v === 2 && M.coins && M.food && M.box && M.newBoxes && M.hold === "raw" && M.total && M.t && M.runs && M.peels === 0, M);
  ok("garbage / wrong-version saves are rejected (8 kinds)", A.mig.bad.every(Boolean), A.mig.bad);
  ok("16 corrupted save fields (negatives, NaN, 1e30, bogus acts, bad suction state, out-of-range slider …) load clamped and play 2 min with all invariants intact", A.mig.fuzz.every((v) => v === true), A.mig.fuzz);
  ok("0 JS errors (page errors + console errors)", errs.length === 0, errs);
  const n = R.length, pc = R.filter((r) => r.pass).length; console.log(`pass1B mechanics (0.2 features): ${pc}/${n} pass`); L.fs.writeFileSync(`${OUT}/results.json`, JSON.stringify({ R, A }, null, 1));
  await b.close(); process.exit(pc === n ? 0 : 1);
})();
function C_VALUE() { return 2; }
