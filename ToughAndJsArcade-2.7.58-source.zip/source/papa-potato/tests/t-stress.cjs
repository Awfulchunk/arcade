// STRESS: 800 potatoes at 6x CPU throttle (A03s-like), 360x800@2x. Phase A: live loop only (fps + heap). Phase B: live loop + ~20x game-time fast-forward (heap, errors).
const L = require("./lib.cjs"); const { ok, R } = L.reporter(); const A = +(process.argv[2] || 240), B = +(process.argv[3] || 240); const OUT = process.argv[4] || "out/stress"; L.fs.mkdirSync(OUT, { recursive: true });
const stats = (a) => { const x = a.slice().sort((m, n) => m - n); const q = (k) => x[Math.min(x.length - 1, Math.floor(k * x.length))]; const tot = a.reduce((m, n) => m + n, 0); return { frames: x.length, fps: +(x.length / (tot / 1000)).toFixed(1), p95: +q(0.95).toFixed(1), p99: +q(0.99).toFixed(1), max: +x[x.length - 1].toFixed(1), over50: x.filter((v) => v > 50).length }; };
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [360, 800], { dpr: 2 }); const s = await L.cdp(p); await s.send("Emulation.setCPUThrottlingRate", { rate: 6 });
  const heap = async () => { await s.send("HeapProfiler.collectGarbage"); return (await s.send("Runtime.getHeapUsage")).usedSize; };
  await p.evaluate(() => { PP.reset(77); PP.sim.setBox("pot", 17); PP.sim.setBox("eat", 40); PP.sim.setBox("nap", 30); PP.sim.setBox("clean", 40); PP.sim.setBox("pace", 4); PP.sim.s.food = 9; PP.sim.s.coins = 100; }); await L.sleep(1500);
  const h = [await heap()]; const frames = []; let t0 = Date.now(); const rec = () => p.evaluate(() => { window.__fr = []; let last = performance.now(); window.__run = true; const f = (t) => { window.__fr.push(t - last); last = t; if (window.__run) requestAnimationFrame(f); }; requestAnimationFrame(f); }); const stop = () => p.evaluate(() => { window.__run = false; return window.__fr.slice(2); });
  const win = []; while (Date.now() - t0 < A * 1000) { await rec(); await L.sleep(30000); const st = stats(await stop()); win.push(st); h.push(await heap()); console.log("A", Math.round((Date.now() - t0) / 1000), JSON.stringify(st), h[h.length - 1]); }
  const worst = win.reduce((m, x) => (x.fps < m.fps ? x : m), win[0]); const info = await p.evaluate(() => ({ t: PP.sim.s.t, sucks: PP.sim.s.stats.sucks, sweeps: PP.sim.s.stats.sweeps, peeled: PP.sim.s.stats.peeled, st: PP.stats() }));
  ok(`phase A: 800 potatoes, 6x throttle, ${A} s live (suction + sweeping + flights happen): every 30 s window ≥ 55 fps, 0 errors`, win.every((x) => x.fps >= 55) && errs.length === 0 && info.sucks >= 3, { worst, info, errs });
  const hA = h.slice(); ok("phase A heap flat (after GC, last − first ≤ 1 MB)", hA[hA.length - 1] - hA[0] <= 1e6, { hA });
  // phase B
  await p.evaluate(() => { window.__ff = setInterval(() => { for (let i = 0; i < 400; i++) PP.sim.step(0.05); }, 40); }); const tb = Date.now(); const hB = [await heap()]; const t00 = await p.evaluate(() => PP.sim.s.t);
  while (Date.now() - tb < B * 1000) { await L.sleep(30000); hB.push(await heap()); console.log("B", Math.round((Date.now() - tb) / 1000), hB[hB.length - 1]); }
  const fin = await p.evaluate(() => { clearInterval(window.__ff); const s = PP.sim.s; return { simH: +((s.t) / 3600).toFixed(2), total: PP.sim.total(), peels: s.peels, stats: { sucks: s.stats.sucks, sweeps: s.stats.sweeps, peeled: s.stats.peeled } }; });
  ok(`phase B: ${B} s at 6x throttle with fast-forward (≈${fin.simH} game hours total): potatoes conserved (800), 0 errors`, fin.total === 800 && errs.length === 0, { fin, errs });
  ok("phase B heap flat (after GC, last − first ≤ 1.5 MB)", hB[hB.length - 1] - hB[0] <= 1.5e6, { hB });
  await p.screenshot({ path: `${OUT}/stress-end.png` }); L.fs.writeFileSync(`${OUT}/stress.json`, JSON.stringify({ R, win, hA, hB, fin }, null, 1)); console.log(`stress: ${R.filter((r) => r.pass).length}/${R.length} pass`); await b.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
