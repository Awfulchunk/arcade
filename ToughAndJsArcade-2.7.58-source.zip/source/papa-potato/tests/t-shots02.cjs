// Deliverable screenshots for Papa Potato 0.2: heaped pile (3 sizes), suction mid-effect, peel mess + cleaning, settings slider.
// Real touch input on the panel; the pile/suction/mess states are PRIMED through the PP hooks (chute 5, peels 70) so they show within seconds.
const L = require("./lib.cjs");
const [w, h] = (process.argv[2] || "360x800").split("x").map(Number); const OUT = (process.argv[3] || "out/shots02") + `-${w}x${h}`; L.fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await L.browser(); const { p, errs } = await L.open(b, [w, h], { dpr: 2 });
  const st = () => p.evaluate(() => ({ t: +PP.sim.s.t.toFixed(1), coins: PP.sim.s.coins, peels: PP.sim.s.peels, pile: PP.sim.s.pile, chute: PP.sim.s.chute, suck: !!PP.sim.s.suck, state: (document.querySelector(".st.on") || {}).textContent, pot: document.querySelector('.box[data-id="pot"] .val').textContent }));
  const log = []; const shot = async (n) => { await p.screenshot({ path: `${OUT}/${n}.png` }); const s = await st(); log.push({ n, ...s }); console.log(n, JSON.stringify(s)); };
  const top = () => p.evaluate(() => { document.getElementById("cmd").scrollTop = 0; });
  const tapN = async (sel, n) => { for (let i = 0; i < n; i++) await L.touchTap(p, sel); };
  await L.sleep(3000); await shot("01-start-default-128-heap");
  await tapN('.box[data-id="eat"] .pm[data-d="1"]', 6); await tapN('.box[data-id="nap"] .pm[data-d="1"]', 5); await shot("02-panel-eat-nap-set");
  // settings: real swipe scrolls the panel, then the CLEAN and POTATOES sliders
  { const r = await L.rect(p, '.box[data-id="pace"] .trk'); await L.touchDrag(p, r.x + r.w / 2, r.cy, r.x + r.w / 2 + 4, r.cy - 150, 12); await L.sleep(400); await shot("03-panel-scrolled-clean-potatoes"); }
  await L.touchTap(p, '.box[data-id="clean"] .nm'); { const r = await L.rect(p, '.box[data-id="clean"] .trk'); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.6, r.cy, 12); } await L.sleep(300); await shot("04-clean-slider-selected-and-set");
  await L.touchTap(p, '.box[data-id="pot"] .nm'); { const r = await L.rect(p, '.box[data-id="pot"] .trk'); await L.touchDrag(p, r.x + r.w * 0.9, r.cy, r.x + r.w * 0.35, r.cy, 12); } await L.sleep(1200); await shot("05-potatoes-slider-mid");
  { const r = await L.rect(p, '.box[data-id="pot"] .trk'); await L.touchDrag(p, r.x + r.w * 0.6, r.cy, r.x - 100, r.cy, 12); } await L.sleep(1500); await shot("06-potatoes-slider-max-800-heap");
  { const r = await L.rect(p, '.box[data-id="pot"] .trk'); await L.touchDrag(p, r.x + r.w * 0.3, r.cy, r.x + r.w + 100, r.cy, 12); } await L.sleep(1500); await shot("07-potatoes-slider-min-4");
  await tapN('.box[data-id="pot"] .pm[data-d="-1"]', 0); for (let i = 0; i < 4; i++) await L.touchTap(p, '.box[data-id="pot"] .pm[data-d="1"]'); await L.sleep(1200); await shot("08-potatoes-24-heap");
  await p.evaluate(() => { PP.sim.setBox("pot", 9); }); await top(); await L.sleep(1500); await shot("09-pile-128-after-reset");
  // suction mid-effect (primed: chute 5; the 6th drop triggers it; or start it directly)
  await p.evaluate(() => { { const s = PP.sim.s, d = Math.min(6 - s.chute, s.pile); s.pile -= d; s.chute += d; } PP.sim.startSuck(); });
  for (const [n, ms] of [["10-suction-start", 250], ["11-suction-mid-rings-pull", 650], ["12-suction-late", 600], ["13-return-flight-onto-pile", 900], ["14-return-landing", 900]]) { await L.sleep(ms); await shot(n); }
  // peel mess: primed 70 peels with CLEAN OFF, then CLEAN set → sweeping
  await p.evaluate(() => { PP.sim.setBox("clean", 0); PP.sim.s.peels = 70; PP.sim.s.food = 5; PP.sim.s.hunger = 95; PP.sim.s.energy = 95; PP.sim.decide(); }); await top(); await L.sleep(1500); await shot("15-peel-mess-70-clean-off");
  await p.evaluate(() => { PP.sim.s.peels = 150; }); await L.sleep(1500); await shot("16-peel-mess-150");
  await p.evaluate(() => { document.getElementById("cmd").scrollTop = 200; }); await L.touchTap(p, '.box[data-id="clean"] .pm[data-d="1"]'); for (let i = 0; i < 9; i++) await L.touchTap(p, '.box[data-id="clean"] .pm[data-d="1"]');
  await p.evaluate(() => PP.sim.decide()); let seen = false; for (let i = 0; i < 40 && !seen; i++) { await L.sleep(500); const s = await st(); if (s.state === "CLEANING") { seen = true; await shot("17-cleaning-sweeping"); await L.sleep(2500); await shot("18-cleaning-mid-sweep"); } }
  for (let i = 0; i < 80; i++) { await L.sleep(1000); const s = await st(); if (s.peels < 20) break; } await top(); await shot("19-after-clean");
  L.fs.writeFileSync(`${OUT}/log.json`, JSON.stringify({ log, errs }, null, 1)); console.log("errs", errs.length); await b.close();
})();
