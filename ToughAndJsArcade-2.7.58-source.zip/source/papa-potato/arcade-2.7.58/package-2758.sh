#!/bin/bash
# Stage finished-ship/papa-potato-0.2-arcade-2.7.58. Never copies keys; prints no secrets.
set -euo pipefail
D=/workspace/game/requests/finished-ship/papa-potato-0.2-arcade-2.7.58
B=/workspace/game/build-potato2; P=$B/package-2.7.58; OLD=/workspace/game/requests/finished-ship/latch-manual-arcade-2.7.56
mkdir -p $D/screenshots $D/test-evidence $D/licenses
cp $P/out/ToughAndJsArcade-2.7.58.apk $D/
Z=/tmp/pp02src; rm -rf $Z; R=$Z/PapaPotato-0.2-source; mkdir -p $R/{game,arcade-2.7.58,tests/fixtures,android-app,old-webview}
cp $B/src/head.html $B/src/sim.js $B/src/game.js $B/build.sh $R/game/
cp $B/out/papa-potato-0.2.html $R/game/papa-potato-0.2.html
cp $B/out/papa-potato-0.1-frozen.html $R/game/papa-potato-0.1-frozen.html
cp /workspace/game/requests/future/potato-peeler/mock/mock-0.1b-zoom15.html $R/game/mock-0.1b-approved.html
cp $B/assemble-2758.mjs $B/build-2758.sh $B/verify-2758.cjs $B/arcade-reg-2758.cjs $B/emu-2758.cjs $B/emu-2758-short.cjs $B/emu-2758-focus.cjs $B/package-2758.sh $B/run-final.sh $R/arcade-2.7.58/
cp $B/test/lib.cjs $B/test/t-mech.cjs $B/test/t-mech02.cjs $B/test/t-gui.cjs $B/test/t-perf.cjs $B/test/t-buff.cjs $B/test/t-stress.cjs $B/test/t-shots02.cjs $B/test/balance.cjs $R/tests/
cp $B/test/fixtures/v1-save.json $R/tests/fixtures/
cp $P/app/AndroidManifest.xml $P/build-apk.sh $R/android-app/; cp -r $P/app/src $R/android-app/src
cp /workspace/game/build-latch/fix/legacy-css.mjs /workspace/game/build-latch/fix/legacy-html.mjs /workspace/game/build-latch/fix/legacy-prelude.js /workspace/game/build-latch/fix/cdp.cjs $R/old-webview/
cat > $R/README.md <<'MD'
# Papa Potato 0.2 source (Tough & J's Arcade 2.7.58) — GPL-3.0
- game/: the cartridge. `build.sh` joins head.html + sim.js (DOM-free simulation) + game.js (renderer, HUD, scroll-safe command panel, save) into papa-potato-0.2.html. `papa-potato-0.1-frozen.html` is the untouched 0.1 (ships as slot papa-potato:v01). The approved layout mock is included.
- arcade-2.7.58/: assemble the new cartridge into the (unpublished) 2.7.57 bundle (every other cartridge byte-identical; `papa-potato:latest` replaced, `papa-potato:v01` added), verify, arcade regression, WebView-83 emulator script, run-final.sh (the sequential test pipeline).
- tests/: pass 1 mechanics (t-mech, t-mech02), pass 2 GUI, A03s perf, BUFF tests (t-buff), stress (t-stress), screenshot script, balance runner, the real 0.1 save fixture.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.56).
- No signing keys are included. Papa Potato has no secrets and no Latch code.
MD
rm -f $D/PapaPotato-0.2-source.zip; (cd $Z && python3 -c "import shutil; shutil.make_archive('$D/PapaPotato-0.2-source','zip','.','PapaPotato-0.2-source')")
cp -r $OLD/licenses/* $D/licenses/
echo staged
