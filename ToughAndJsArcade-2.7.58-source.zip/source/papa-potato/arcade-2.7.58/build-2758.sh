#!/bin/bash
# Full 2.7.58 build: game html -> arcade bundle (on top of the unpublished 2.7.57 bundle) -> signed APK -> extract for tests.
set -euo pipefail
export PATH=/workspace/tools/jdk/bin:$PATH
B=/workspace/game/build-potato2; P=$B/package-2.7.58
bash $B/build.sh
node $B/assemble-2758.mjs $B/out/index.html > $B/out/assemble.log
cp $B/out/index.html $P/tough-and-js-arcade.html
rm -f $P/out/ToughAndJsArcade-2.7.58.apk $P/out/ToughAndJsArcade-2.7.58.apk.idsig
(cd $P && ./build-apk.sh) > $B/out/build-apk.log 2>&1
rm -rf /tmp/a58 && mkdir /tmp/a58 && (cd /tmp/a58 && unzip -q $P/out/ToughAndJsArcade-2.7.58.apk assets/index.html)
cp /tmp/a58/assets/index.html $B/test/index-from-apk.html
node -e 'const fs=require("fs"),vm=require("vm");const t=fs.readFileSync(process.argv[1],"utf8");const i=t.indexOf("const GAME_SRC="),j=t.indexOf("// END_PACKED_GAME_SRC");const G=vm.runInNewContext(t.slice(i,j)+"\nGAME_SRC;");fs.writeFileSync(process.argv[2],G["papa-potato:latest"]);fs.writeFileSync(process.argv[3],G["papa-potato:v01"])' $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v01-from-apk.html
cmp $B/test/papa-potato-from-apk.html $B/out/papa-potato-0.2.html
cmp $B/test/papa-potato-v01-from-apk.html $B/out/papa-potato-0.1-frozen.html
cmp $B/test/index-from-apk.html $B/out/index.html
sha256sum $P/out/ToughAndJsArcade-2.7.58.apk $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v01-from-apk.html | tee $B/evidence/tested-artifacts.sha256
