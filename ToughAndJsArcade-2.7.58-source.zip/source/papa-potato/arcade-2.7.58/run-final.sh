#!/bin/bash
# Sequential final run on the APK-extracted html. One heavy job at a time.
cd /workspace/game/build-potato2
F=/workspace/game/build-potato2/out/final; rm -rf $F; mkdir -p $F
H=file:///workspace/game/build-potato2/test/papa-potato-from-apk.html
step(){ n=$1; shift; echo "== $(date +%H:%M:%S) $n" | tee -a $F/steps.log; pkill -f google-chrome || true; "$@" > $F/$n.log 2>&1; echo "   exit $? $(tail -1 $F/$n.log | cut -c1-160)" | tee -a $F/steps.log; }
step build bash build-2758.sh
step verify env PATH=/workspace/tools/jdk/bin:$PATH node verify-2758.cjs
cd test
export PP_HTML=$H
step pass1a-mech timeout 600 node t-mech.cjs out/p1a
step pass1b-mech02 timeout 300 node t-mech02.cjs out/p1b
step pass2-gui-360x800 timeout 400 node t-gui.cjs 360x800 out/p2
step pass2-gui-320x568 timeout 400 node t-gui.cjs 320x568 out/p2
cd ..
step pass3-arcade-reg timeout 400 node arcade-reg-2758.cjs
cd test
step buff timeout 900 node t-buff.cjs out/buff
step perf-a03s timeout 900 node t-perf.cjs 6 out/perf-a03s
step stress timeout 1500 node t-stress.cjs 90 90 out/stress
step shots-360x800 timeout 400 node t-shots02.cjs 360x800 out/shots02
step shots-320x568 timeout 400 node t-shots02.cjs 320x568 out/shots02
echo "== $(date +%H:%M:%S) ALL DONE" | tee -a $F/steps.log
