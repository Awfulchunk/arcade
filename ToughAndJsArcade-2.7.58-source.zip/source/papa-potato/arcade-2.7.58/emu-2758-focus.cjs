// PASS 4 — WebView 83 emulator (Android 11, Chrome 83, software rendering), installed 2.7.58 APK.
// Papa Potato 0.2 (and the v01 slot) legacy build: real adb taps/swipes to open it from the menu, set boxes, check scroll-safety,
// play ~2 min real time, buy food, change a box, quit (◀ Arcade, and force-stop the app) and reopen to confirm the save.
const connect = require("/workspace/game/build-latch/fix/cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const ADB = "/workspace/tools/sdk/platform-tools/adb";
const OUT = process.argv[2] || __dirname + "/emu"; fs.mkdirSync(OUT, { recursive: true });
const sh = (c) => execSync(`${ADB} ${c}`).toString();
const shot = (n) => execSync(`${ADB} exec-out screencap -p > ${OUT}/${n}.png`);
const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d === undefined ? "" : d).slice(0, 400)); };
async function startApp(fresh) {
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); let pid = "";
  for (let a = 0; a < 3 && !pid; a++) { // a busy software emulator can time out a cold start ("failed to attach"): retry the launch
    sh("shell am start -n com.toughandj.arcade/.MainActivity"); await sleep(20000);
    try { pid = sh("shell pidof com.toughandj.arcade").trim(); } catch (e) { pid = ""; console.log("note: launch attempt " + (a + 1) + " not up yet, retrying"); }
  } execSync(`${ADB} forward --remove-all`); execSync(`${ADB} forward tcp:9333 localabstract:webview_devtools_remote_${pid}`);
  let c; for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  if (fresh) await c.ev(`(localStorage.removeItem('papaPotato.save.v1'),localStorage.removeItem('papaPotato.save.v2'),1)`);
  return c;
}
async function openGame(c, tag, v01) {
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const dpr = await c.ev("devicePixelRatio");
  if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(2000); }
  // bring the card to the middle, then the REAL tap on its PLAY button
  await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');ARCADE.go(i);return 1})()`); await sleep(2500);
  const pb = JSON.parse(await c.ev(`JSON.stringify((()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');const el=document.querySelectorAll('.card')[i];const b=el.querySelector('.play').getBoundingClientRect();return {x:b.left+b.width/2,y:b.top+b.height/2,t:el.innerText.slice(0,40)}})())`));
  shot(`${tag}-menu-card`);
  const n0 = c.ctx.length;
  if (v01) { await c.ev(`(ARCADE.launch(ARCADE.GAMES.findIndex(g=>g.id==='papa-potato'),'v01'),1)`); await sleep(1500); } else { sh(`shell input tap ${Math.round(pb.x * dpr)} ${Math.round(pb.y * dpr)}`); await sleep(1500); }
  if (await c.ev("document.getElementById('sheet')&&document.getElementById('sheet').classList.contains('show')")) { /* version sheet: should not appear for one version */ }
  await sleep(8000);
  let cx; for (let i = 0; i < 25 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); }
  if (!cx) throw new Error("no game frame");
  for (let i = 0; i < 20; i++) { try { if (await c.ev("window.__PP_READY===true", cx.id)) break; } catch (e) {} await sleep(1000); }
  const ev = (e) => c.ev(e, cx.id); const J = async (e) => JSON.parse(await ev(`JSON.stringify(${e})`));
  const pt = async (sel, fx = 0.5, fy = 0.5) => { const r = await J(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const b=e.getBoundingClientRect();return {x:b.left+b.width*${fx},y:b.top+b.height*${fy}}})()`); if (!r) throw new Error("not visible " + sel); const o = JSON.parse(await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`)); return { x: Math.round((o.x + r.x) * dpr), y: Math.round((o.y + r.y) * dpr) }; };
  const atap = async (sel, wait = 1200, fx, fy) => { const p = await pt(sel, fx, fy); sh(`shell input tap ${p.x} ${p.y}`); await sleep(wait); return p; };
  return { ev, J, pt, atap, card: pb.t, dpr };
}
const ST = `{t:+PP.sim.s.t.toFixed(1),coins:PP.sim.s.coins,food:PP.sim.s.food,box:PP.sim.s.box,peeled:PP.sim.s.stats.peeled,peels:PP.sim.s.peels,sweeps:PP.sim.s.stats.sweeps,sucks:PP.sim.s.stats.sucks,pile:PP.sim.s.pile,chute:PP.sim.s.chute,suck:!!PP.sim.s.suck,total:PP.sim.total(),meals:PP.sim.s.stats.meals,bought:PP.sim.s.stats.bought,state:(document.querySelector('.st.on')||{}).textContent,focus:PP.focus(),ui:[...document.querySelectorAll('.box .val')].map(e=>e.textContent),coinsUi:document.getElementById('coins').textContent,foodUi:document.getElementById('food').textContent,errs:window.__errs}`;
(async () => {
  const APK = "/workspace/game/build-potato2/package-2.7.58/out/ToughAndJsArcade-2.7.58.apk";
  const inst = sh(`install -r ${APK}`).trim(); const path = sh("shell pm path com.toughandj.arcade").trim().replace(/^package:/, "");
  const devSha = sh(`shell sha256sum ${path}`).trim().split(/\s+/)[0]; const locSha = execSync(`sha256sum ${APK}`).toString().split(" ")[0];
  fs.writeFileSync(`${OUT}/installed-apk.sha256`, `${devSha}  ${path}\n`);
  ok("adb install -r: installed APK on the device is byte-identical (sha)", /Success/.test(inst) && devSha === locSha, { devSha });
  let c = await startApp(true); let g = await openGame(c, "f1"); await g.ev("(PP.reset(777),1)"); await sleep(1500);
  // 1. slider reaches the END by a real swipe (several tries; each must land exactly on 800)
  const res = [];
  for (let k = 0; k < 3; k++) {
    const a = await g.pt('.box[data-id="pace"] .trk', 0.5, 0.5);
    for (let s = 0; s < 4; s++) { const q = await g.J(`{st:document.getElementById('cmd').scrollTop,max:document.getElementById('cmd').scrollHeight-document.getElementById('cmd').clientHeight}`); if (q.st >= q.max - 3) break; const f = await g.pt('.box[data-id="clean"] .trk', 0.5, 0.5).catch(() => a); sh(`shell input swipe ${f.x} ${f.y} ${f.x + 5} ${f.y - 220} 350`); await sleep(1500); }
    await g.ev(`(PP.sim.setBox('pot',9),1)`); await g.atap('.box[data-id="pot"] .nm', 1000);
    const p1 = await g.pt('.box[data-id="pot"] .trk', 0.9), p2 = await g.pt('.box[data-id="pot"] .trk', -0.05); sh(`shell input swipe ${p1.x} ${p1.y} ${p2.x} ${p2.y} 600`); await sleep(2500);
    res.push(await g.J(`{pot:PP.sim.s.box.pot,lab:document.querySelector('.box[data-id="pot"] .val').textContent,total:PP.sim.total(),errs:window.__errs}`));
    shot(`f-swipe-end-${k}`);
  }
  ok("real swipe from 90% to past the left end lands exactly on 800 potatoes, 3 of 3 tries", res.every((r) => r.lab === "800" && r.total === 800 && r.errs.length === 0), res);
  await g.ev(`(PP.sim.setBox('pot',9),1)`); await sleep(1500);
  // 2a. force-stop right while playing: diagnostic of what was lost
  await g.ev(`(PP.sim.s.coins=30,PP.sim.setBox('eat',30),PP.sim.setBox('nap',25),PP.save(),1)`); await sleep(6000);
  const live = await g.J(`{t:+PP.sim.s.t.toFixed(2),savedT:+(JSON.parse(localStorage.getItem('papaPotato.save.v2')).t).toFixed(2),box:PP.sim.s.box,coins:PP.sim.s.coins}`);
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); c.close();
  c = await startApp(false); g = await openGame(c, "f2"); const after = await g.J(`{t:+PP.sim.s.t.toFixed(2),box:PP.sim.s.box,coins:PP.sim.s.coins,errs:window.__errs}`);
  fs.writeFileSync(`${OUT}/forcestop-diag.json`, JSON.stringify({ live, after }, null, 1));
  ok("force-stop while playing: in-memory save was fresh (≤2.5 s behind live) at the kill", live.t - live.savedT <= 2.5, live);
  ok("…after relaunch: boxes restored, ≤ 10 s of game time lost (2 s autosave + WebView storage flush before the kill)", JSON.stringify(after.box) === JSON.stringify(live.box) && after.t >= live.t - 10 && after.t > 5 && after.errs.length === 0, { liveT: live.t, savedT: live.savedT, afterT: after.t, lost: +(live.t - after.t).toFixed(2) });
  // 2b. hypothesis check: pause (saves), idle 9 s so the WebView flushes, then kill: nothing should be lost
  await g.ev(`(PP.pause(true),PP.save(),1)`); const pt = await g.J(`+PP.sim.s.t.toFixed(2)`); await sleep(9000);
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); c.close();
  c = await startApp(false); g = await openGame(c, "f3"); const a2 = await g.J(`{t:+PP.sim.s.t.toFixed(2),errs:window.__errs}`);
  ok("save → idle 9 s → force-stop → relaunch: no game time lost (so the earlier loss was the storage flush delay, not the interval)", a2.t >= pt - 0.1 && a2.errs.length === 0, { pausedT: pt, afterT: a2.t });
  await c.ev("ARCADE.back(),1"); fs.writeFileSync(`${OUT}/emu-2758focus.json`, JSON.stringify({ R }, null, 1));
  console.log(`emu-2758focus: ${R.filter((r) => r.pass).length}/${R.length} pass`); c.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); process.exit(1); });
