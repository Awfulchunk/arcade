// Arcade 2.7.58 bundle (taken out of the APK): Papa Potato 0.2 (latest) + 0.1 (v01) + every 2.7.56 cartridge (FunMotion, Needle, Latch 2.1/2.0/1.1/1, Swarm 1.6.14/1.6.13). 0 JS errors.
const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const b = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--autoplay-policy-no-user-gesture-required", "--autoplay-policy=no-user-gesture-required", "--allow-file-access-from-files"] });
  const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, d); };
  const page = async () => {
    const p = await b.newPage(); const errs = [];
    p.on("pageerror", (e) => errs.push("shell: " + e.message));
    await p.setViewport({ width: 360, height: 800, isMobile: true, hasTouch: true });
    await p.evaluateOnNewDocument(() => {
      const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc");
      Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});addEventListener('unhandledrejection',function(e){__errs.push('rejection '+(e.reason&&e.reason.message||e.reason))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } });
    });
    await p.goto("file:///workspace/game/build-potato2/test/index-from-apk.html"); await sleep(1500);
    return { p, errs };
  };
  const { p, errs } = await page();
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/00-menu.png" });
  const info = await p.evaluate(() => {
    const latch = GAMES.find((x) => x.id === "latch");
    const sw = GAMES.find((x) => x.id === "swarm");
    const fm = GAMES.find((x) => x.id === "funmotion");
    return {
      latch: latch.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      swarm: sw.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      funmotion: fm.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")),
      has: ["funmotion", "needle", "latch", "swarm"].map((id) => GAMES.findIndex((x) => x.id === id))
    };
  });
  ok("GAMES has funmotion, needle, latch, swarm (2.7.56 cartridges still there)", info.has.every((i) => i >= 0), JSON.stringify(info.has));
  ok("Latch picker v1 / v1.1 / v2.0 kept / v2.1 default", info.latch.length === 4 && /^latest=v2\.1.*\(default\)/.test(info.latch[3]) && /^v20=v2\.0/.test(info.latch[2]) && !/default/.test(info.latch[2]) && /^v11=v1\.1/.test(info.latch[1]) && /^v1=/.test(info.latch[0]), info.latch.join(" | "));
  ok("FunMotion picker v0.2.5 latest (default) + v024 kept", info.funmotion.some((s) => /^latest=v0\.2\.5.*\(default\)/.test(s)) && info.funmotion.some((s) => /^v024=v0\.2\.4/.test(s)), info.funmotion.join(" | "));
  ok("Swarm picker v1.6.14 latest (default) + v1613 kept", info.swarm.some((s) => /^latest=v1\.6\.14.*\(default\)/.test(s)) && info.swarm.some((s) => /^v1613=v1\.6\.13/.test(s)), info.swarm.slice(-4).join(" | "));
  const run = async (id, verId, check, shot) => {
    await p.evaluate((id, verId) => { const i = GAMES.findIndex((g) => g.id === id); const G = GAMES[i]; if (verId) ARCADE.launch(i, verId); else ARCADE.launchCard(i); }, id, verId);
    await sleep(3500);
    const fr = p.frames().find((f) => f !== p.mainFrame());
    let res = { loaded: false };
    if (fr) res = await fr.evaluate(check).catch((e) => ({ loaded: false, err: e.message }));
    const ferrs = fr ? await fr.evaluate(() => window.__errs || ["no capture"]).catch(() => ["eval failed"]) : ["no frame"];
    await p.screenshot({ path: `/workspace/game/build-potato2/test/out/arcade-reg/${shot}.png` });
    ok(`${id}${verId ? ":" + verId : ""} launches, 0 JS errors`, res.loaded && ferrs.length === 0, JSON.stringify({ ...res, errs: ferrs }).slice(0, 400));
    await p.evaluate(() => ARCADE.back()); await sleep(800);
    return fr;
  };
  await run("funmotion", null, () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, ver: (document.documentElement.innerHTML.match(/0\.2\.\d/) || [])[0], tutorial: /Tutorial/i.test(document.body.innerText) || !!document.querySelector("[data-tutorial],#tutorial,button") && [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01-funmotion");
  await run("funmotion", "v024", () => ({ loaded: !!document.querySelector("canvas") || document.body.innerText.length > 20, tutorial: [...document.querySelectorAll("button")].some((b) => /tutorial/i.test(b.textContent)) }), "01b-funmotion-v024");
  await run("needle", null, () => ({ loaded: document.body.innerText.length > 20, text: document.body.innerText.slice(0, 60) }), "02-needle");
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "latch"); ARCADE.launchCard(i); }); await sleep(2500);
  let fr = p.frames().find((f) => f !== p.mainFrame());
  const v2 = await fr.evaluate(async () => { const vtr = !!document.querySelector("main.vtr"); const book = !!document.querySelector("[data-manual-open]") || /Owner/.test(document.documentElement.innerHTML); const qm = document.querySelectorAll(".qm").length; const s = document.querySelector("[data-sample]"); if (s) s.click(); await new Promise((r) => setTimeout(r, 1800)); return { vtr, qm, pic: !!document.querySelector(".vf canvas.pic"), osd: document.querySelector(".osd.obl") && document.querySelector(".osd.obl").textContent, ver: document.body.innerText.includes("VTR"), book }; });
  const e2 = await fr.evaluate(() => window.__errs);
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/03-latch-v2.1.png" });
  ok("latch v2.1 (default) = VTR-1 UI with the Owner's Manual, no ? badges, 0 errors", v2.vtr && v2.book && v2.qm === 0 && e2.length === 0, JSON.stringify({ ...v2, errs: e2 }));
  // open the book inside the real arcade frame: MENU > MANUAL, turn a page, close
  const bk = await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); document.querySelector(".bar [aria-label=Menu]").click(); await w(300); const t = document.querySelector("[data-manual-open]"); if (!t) return { opened: false }; t.click(); await w(400); const m = document.querySelector(".lman"); const p1 = m && m.dataset.page; document.querySelector("[data-manual-next]").click(); await w(300); const p2 = m && m.dataset.page; document.querySelector("[data-manual-close]").click(); await w(300); return { opened: !!m, p1, p2, closed: !document.querySelector(".lman"), ver: /Latch 2\.1/.test(document.documentElement.innerHTML) }; });
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/03b-latch-v2.1-after-book.png" });
  ok("latch v2.1 in the arcade: MENU › MANUAL opens p.1, Next → p.2, CLOSE closes", bk.opened && bk.p1 === "1" && bk.p2 === "2" && bk.closed, JSON.stringify(bk));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await run("latch", "v20", () => ({ loaded: !!document.querySelector("main.vtr") && document.querySelectorAll(".qm").length === 0 && !/data-manual-open|lman/.test(document.documentElement.innerHTML), vtr: !!document.querySelector("main.vtr") }), "03c-latch-v2.0-kept");
  await run("latch", "v11", () => ({ loaded: document.querySelectorAll(".qm").length > 5 && !document.querySelector("main.vtr"), qm: document.querySelectorAll(".qm").length }), "04-latch-v1.1");
  await run("latch", "v1", () => ({ loaded: document.body.innerText.length > 20 && !document.querySelector("main.vtr") }), "05-latch-v1");
  const swc = () => ({ loaded: !!document.querySelector("canvas"), ver: (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1] });
  await run("swarm", null, swc, "07-swarm-latest");
  await run("swarm", "v1613", swc, "08-swarm-v1613");
  // confirm versions from last two runs by a dedicated eval
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launchCard(i); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const latestVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const lerr = await fr.evaluate(() => window.__errs);
  ok("swarm latest is 1.6.14", latestVer === "1.6.14" && lerr.length === 0, JSON.stringify({ latestVer, errs: lerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await p.evaluate(() => { const i = GAMES.findIndex((g) => g.id === "swarm"); ARCADE.launch(i, "v1613"); }); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const oldVer = await fr.evaluate(() => (document.documentElement.innerHTML.match(/VERSION\s*=\s*["']([\d.]+)/) || [])[1]);
  const oerr = await fr.evaluate(() => window.__errs);
  ok("swarm v1613 is 1.6.13", oldVer === "1.6.13" && oerr.length === 0, JSON.stringify({ oldVer, errs: oerr }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // ===== NEW: Papa Potato 0.1 =====
  const pi = await p.evaluate(() => GAMES.findIndex((g) => g.id === "papa-potato"));
  const card = await p.evaluate((pi) => { ARCADE.go(pi); const G = GAMES[pi]; return { title: G.title, prev: GAMES[pi - 1].id, n: GAMES.length, vers: G.versions.map((v) => v.id + "=" + v.name + (v.def ? " (default)" : "")) }; }, pi); await sleep(1200);
  const cardDom = await p.evaluate((pi) => { const els = [...document.querySelectorAll(".card")]; const el = els[pi]; if (!el) return null; const r = el.getBoundingClientRect(); return { text: el.innerText.slice(0, 160), visible: r.left > -10 && r.right < innerWidth + 10, idx: ARCADE.idx }; }, pi);
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/10-menu-papa-potato-card.png" });
  ok("Papa Potato card in the menu (after Swarm): picker v0.1 (kept) + v0.2 default, centered when selected", pi >= 0 && card.title === "PAPA POTATO" && card.prev === "swarm" && card.vers.length === 2 && /^v01=v0\.1/.test(card.vers[0]) && !/default/.test(card.vers[0]) && /^latest=v0\.2.*\(default\)/.test(card.vers[1]) && cardDom && /PAPA POTATO/.test(cardDom.text) && cardDom.visible && cardDom.idx === pi, JSON.stringify({ pi, card, cardDom }));
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3500);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const pp1 = fr ? await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const t0 = PP.sim.s.t; await w(4000); return { ready: window.__PP_READY === true, ver: PP.version, brand: document.querySelector("#hud .brand b").innerText.replace(/\s+/g, " "), title: document.title, tags: [...document.querySelectorAll(".tag")].map((e) => e.textContent), boxes: document.querySelectorAll("#cmd .box").length, ran: +(PP.sim.s.t - t0).toFixed(1), errs: window.__errs }; }).catch((e) => ({ err: e.message })) : { err: "no frame" };
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/11-papa-potato-in-arcade.png" });
  ok("Papa Potato 0.2 launches inside the arcade: PAPA POTATO HUD, SHIPPING/POTATOES, 5 boxes, game clock runs, 0 JS errors", pp1.ready && pp1.ver === "0.2" && pp1.brand === "PAPA POTATO" && pp1.title === "Papa Potato 0.2" && pp1.tags.join() === "SHIPPING,POTATOES" && pp1.boxes === 5 && pp1.ran > 3 && pp1.errs && pp1.errs.length === 0, JSON.stringify(pp1));
  // change a box + buy, so we can see it survive the exit
  await fr.evaluate(() => { PP.sim.s.coins = 30; PP.sim.setBox("eat", 40); PP.sim.setBox("nap", 30); PP.sim.buyFood(); PP.save(); });
  const before = await fr.evaluate(() => ({ eat: PP.sim.s.box.eat, nap: PP.sim.s.box.nap, food: PP.sim.s.food, coins: PP.sim.s.coins }));
  // exit with the real ◀ Arcade button (tap twice)
  await p.evaluate(() => ARCADE.peekBack(3000)); await sleep(200);
  await p.click("#back"); await sleep(250); await p.click("#back"); await sleep(1200);
  const exited = await p.evaluate(() => ({ inGame: ARCADE.inGame, frames: document.querySelectorAll("#game iframe").length, menuBack: !document.getElementById("menu").classList.contains("away") }));
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/12-back-in-menu.png" });
  ok("Papa Potato exits cleanly with the ◀ Arcade button (frame removed, menu back)", !exited.inGame && exited.frames === 0 && exited.menuBack, JSON.stringify(exited));
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const back2 = await fr.evaluate(() => ({ eat: PP.sim.s.box.eat, nap: PP.sim.s.box.nap, food: PP.sim.s.food, coins: PP.sim.s.coins, ui: [...document.querySelectorAll(".box .val")].map((e) => e.textContent), errs: window.__errs }));
  ok("relaunch from the menu: the save came back (boxes, food, coins)", back2.eat === before.eat && back2.nap === before.nap && back2.food >= before.food - 1 && back2.coins >= before.coins && back2.ui[1] === "40%" && back2.errs.length === 0, JSON.stringify({ before, back2 }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // ===== v01 slot: the frozen 0.1 launches, keeps its own save (v1 key) and never touches the 0.2 save (v2 key) =====
  const lsRead = (k) => p.evaluate((k) => { const v = localStorage.getItem(k); return v === null ? null : v.length + ":" + v.slice(0, 40) + v.slice(-40); }, k);
  const k2before = await lsRead("papaPotato.save.v2");
  await p.evaluate((pi) => ARCADE.launch(pi, "v01"), pi); await sleep(3500);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const v01 = fr ? await fr.evaluate(async () => { const w = (ms) => new Promise((r) => setTimeout(r, ms)); const t0 = PP.sim.s.t; await w(3000); PP.sim.s.coins = 17; PP.save(); return { ready: window.__PP_READY === true, ver: PP.version, title: document.title, boxes: document.querySelectorAll("#cmd .box").length, ran: +(PP.sim.s.t - t0).toFixed(1), errs: window.__errs }; }) : { ready: false };
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/14-papa-potato-v01-in-arcade.png" });
  ok("v01 slot: Papa Potato 0.1 launches in the arcade (3 boxes, clock runs, 0 JS errors)", v01.ready && v01.ver === "0.1" && v01.title === "Papa Potato 0.1" && v01.boxes === 3 && v01.ran > 2 && v01.errs.length === 0, JSON.stringify(v01));
  const k1after = await lsRead("papaPotato.save.v1"), k2after = await lsRead("papaPotato.save.v2");
  ok("0.1 wrote only its own key (v1 exists, the 0.2 save v2 is byte-identical)", !!k1after && k2after === k2before && !!k2before, JSON.stringify({ k1after: !!k1after, same: k2after === k2before }));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const back3 = await fr.evaluate(() => ({ ver: PP.version, eat: PP.sim.s.box.eat, migrated: PP.migrated, errs: window.__errs }));
  ok("back on 0.2: its save wins over the 0.1 save (eat 40%, not re-migrated)", back3.ver === "0.2" && back3.eat === before.eat && !back3.migrated && back3.errs.length === 0, JSON.stringify(back3));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // fresh 0.2 start with only a real 0.1 save in storage → migrated (welcome hint), 0.1 save kept
  const fx = fs.readFileSync("/workspace/game/build-potato2/test/fixtures/v1-save.json", "utf8");
  await p.evaluate((fx) => { localStorage.removeItem("papaPotato.save.v2"); localStorage.setItem("papaPotato.save.v1", fx); }, fx);
  await p.evaluate((pi) => ARCADE.launchCard(pi), pi); await sleep(3000);
  fr = p.frames().find((f) => f !== p.mainFrame());
  const mig = await fr.evaluate(() => ({ migrated: PP.migrated, ver: PP.sim.s.v, coins: PP.sim.s.coins, total: PP.sim.total(), errs: window.__errs }));
  const k1mig = await p.evaluate(() => localStorage.getItem("papaPotato.save.v1"));
  await p.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/15-migrated-from-0.1.png" });
  ok("a real 0.1 save in the arcade: 0.2 migrates it (v2 state, no potato lost/duplicated) and leaves the 0.1 key untouched", mig.migrated === true && mig.ver === 2 && mig.errs.length === 0 && k1mig === fx, JSON.stringify(mig));
  await p.evaluate(() => ARCADE.back()); await sleep(800);
  // old-WebView (legacy) path inside the arcade: force arcade.legacy=1 and launch again
  const p2 = await b.newPage(); const errs2 = []; p2.on("pageerror", (e) => errs2.push(e.message));
  await p2.setViewport({ width: 320, height: 568, isMobile: true, hasTouch: true });
  await p2.evaluateOnNewDocument(() => { try { localStorage.setItem("arcade.legacy", "1"); } catch (e) {} const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "srcdoc"); Object.defineProperty(HTMLIFrameElement.prototype, "srcdoc", { set(v) { const inj = "<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});<\/script>"; d.set.call(this, v ? inj + v : v); }, get() { return d.get.call(this); } }); });
  await p2.goto("file:///workspace/game/build-potato2/test/index-from-apk.html"); await sleep(1500);
  await p2.evaluate(() => { localStorage.removeItem("papaPotato.save.v2"); ARCADE.launchCard(GAMES.findIndex((g) => g.id === "papa-potato")); }); await sleep(3500);
  const f2 = p2.frames().find((f) => f !== p2.mainFrame());
  const lg = await f2.evaluate(() => ({ ready: window.__PP_READY === true, prelude: /TJ legacy prelude/.test(document.head.innerHTML), errs: window.__errs, t: PP.sim.s.t }));
  await p2.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/13-papa-potato-legacy-320x568.png" });
  ok("legacy (old-WebView) variant launches at 320x568: prelude present, 0 JS errors", lg.ready && lg.prelude && lg.errs.length === 0 && errs2.length === 0, JSON.stringify({ lg, errs2 }));
  ok("legacy 0.2 reports version 0.2 with 5 boxes", (await f2.evaluate(() => ({ v: PP.version, b: document.querySelectorAll("#cmd .box").length }))).b === 5, "");
  await p2.evaluate(() => ARCADE.back()); await sleep(800);
  await p2.evaluate(() => ARCADE.launch(GAMES.findIndex((g) => g.id === "papa-potato"), "v01")); await sleep(3500);
  const f3 = p2.frames().find((f) => f !== p2.mainFrame());
  const lg1 = await f3.evaluate(() => ({ ready: window.__PP_READY === true, prelude: /TJ legacy prelude/.test(document.head.innerHTML), ver: PP.version, errs: window.__errs }));
  await p2.screenshot({ path: "/workspace/game/build-potato2/test/out/arcade-reg/16-papa-potato-v01-legacy-320x568.png" });
  ok("legacy (old-WebView) variant of v01 (0.1) launches at 320x568, 0 JS errors", lg1.ready && lg1.prelude && lg1.ver === "0.1" && lg1.errs.length === 0 && errs2.length === 0, JSON.stringify({ lg1, errs2 }));
  await p2.close();
  ok("arcade shell 0 JS errors", errs.length === 0, errs.join("; "));
  fs.writeFileSync("/workspace/game/build-potato2/test/out/arcade-reg/arcade.json", JSON.stringify(R, null, 1));
  console.log(`arcade: ${R.filter((r) => r.pass).length}/${R.length} pass`);
  await b.close();
  process.exit(R.every((r) => r.pass) ? 0 : 1);
})();
