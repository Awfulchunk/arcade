// PASS 4 — WebView 83 emulator (Android 11, Chrome 83, software rendering), installed 2.7.58 APK.
// Papa Potato 0.2 (and the v01 slot) legacy build: real adb taps/swipes to open it from the menu, set boxes, check scroll-safety,
// play ~2 min real time, buy food, change a box, quit (◀ Arcade, and force-stop the app) and reopen to confirm the save.
const connect = require("/workspace/game/build-latch/fix/cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const ADB = "/workspace/tools/sdk/platform-tools/adb";
const OUT = process.argv[2] || __dirname + "/emu"; fs.mkdirSync(OUT, { recursive: true });
const sh = (c) => execSync(`${ADB} ${c}`).toString();
const shot = (n) => execSync(`${ADB} exec-out screencap -p > ${OUT}/${n}.png`);
const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d === undefined ? "" : d).slice(0, 400)); };
async function startApp(fresh) {
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); let pid = "";
  for (let a = 0; a < 3 && !pid; a++) { // a busy software emulator can time out a cold start ("failed to attach"): retry the launch
    sh("shell am start -n com.toughandj.arcade/.MainActivity"); await sleep(20000);
    try { pid = sh("shell pidof com.toughandj.arcade").trim(); } catch (e) { pid = ""; console.log("note: launch attempt " + (a + 1) + " not up yet, retrying"); }
  } execSync(`${ADB} forward --remove-all`); execSync(`${ADB} forward tcp:9333 localabstract:webview_devtools_remote_${pid}`);
  let c; for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  if (fresh) await c.ev(`(localStorage.removeItem('papaPotato.save.v1'),localStorage.removeItem('papaPotato.save.v2'),1)`);
  return c;
}
async function openGame(c, tag, v01) {
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const dpr = await c.ev("devicePixelRatio");
  if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(2000); }
  // bring the card to the middle, then the REAL tap on its PLAY button
  await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');ARCADE.go(i);return 1})()`); await sleep(2500);
  const pb = JSON.parse(await c.ev(`JSON.stringify((()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');const el=document.querySelectorAll('.card')[i];const b=el.querySelector('.play').getBoundingClientRect();return {x:b.left+b.width/2,y:b.top+b.height/2,t:el.innerText.slice(0,40)}})())`));
  shot(`${tag}-menu-card`);
  const n0 = c.ctx.length;
  if (v01) { await c.ev(`(ARCADE.launch(ARCADE.GAMES.findIndex(g=>g.id==='papa-potato'),'v01'),1)`); await sleep(1500); } else { sh(`shell input tap ${Math.round(pb.x * dpr)} ${Math.round(pb.y * dpr)}`); await sleep(1500); }
  if (await c.ev("document.getElementById('sheet')&&document.getElementById('sheet').classList.contains('show')")) { /* version sheet: should not appear for one version */ }
  await sleep(8000);
  let cx; for (let i = 0; i < 25 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); }
  if (!cx) throw new Error("no game frame");
  for (let i = 0; i < 20; i++) { try { if (await c.ev("window.__PP_READY===true", cx.id)) break; } catch (e) {} await sleep(1000); }
  const ev = (e) => c.ev(e, cx.id); const J = async (e) => JSON.parse(await ev(`JSON.stringify(${e})`));
  const pt = async (sel, fx = 0.5, fy = 0.5) => { const r = await J(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const b=e.getBoundingClientRect();return {x:b.left+b.width*${fx},y:b.top+b.height*${fy}}})()`); if (!r) throw new Error("not visible " + sel); const o = JSON.parse(await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`)); return { x: Math.round((o.x + r.x) * dpr), y: Math.round((o.y + r.y) * dpr) }; };
  const atap = async (sel, wait = 1200, fx, fy) => { const p = await pt(sel, fx, fy); sh(`shell input tap ${p.x} ${p.y}`); await sleep(wait); return p; };
  return { ev, J, pt, atap, card: pb.t, dpr };
}
const ST = `{t:+PP.sim.s.t.toFixed(1),coins:PP.sim.s.coins,food:PP.sim.s.food,box:PP.sim.s.box,peeled:PP.sim.s.stats.peeled,peels:PP.sim.s.peels,sweeps:PP.sim.s.stats.sweeps,sucks:PP.sim.s.stats.sucks,pile:PP.sim.s.pile,chute:PP.sim.s.chute,suck:!!PP.sim.s.suck,total:PP.sim.total(),meals:PP.sim.s.stats.meals,bought:PP.sim.s.stats.bought,state:(document.querySelector('.st.on')||{}).textContent,focus:PP.focus(),ui:[...document.querySelectorAll('.box .val')].map(e=>e.textContent),coinsUi:document.getElementById('coins').textContent,foodUi:document.getElementById('food').textContent,errs:window.__errs}`;
(async () => {
  // install + verify the exact APK on the device
  const APK = "/workspace/game/build-potato2/package-2.7.58/out/ToughAndJsArcade-2.7.58.apk";
  const inst = sh(`install -r ${APK}`).trim();
  const path = sh("shell pm path com.toughandj.arcade").trim().replace(/^package:/, "");
  const devSha = sh(`shell sha256sum ${path}`).trim().split(/\s+/)[0]; const locSha = execSync(`sha256sum ${APK}`).toString().split(" ")[0];
  const ver = (sh("shell dumpsys package com.toughandj.arcade").match(/versionName=([\d.]+)/) || [])[1];
  fs.writeFileSync(`${OUT}/installed-apk.sha256`, `${devSha}  ${path}\n`);
  ok("adb install -r: the installed APK on the device is byte-identical (sha) and is 2.7.58", /Success/.test(inst) && devSha === locSha && ver === "2.7.58", { inst, devSha, ver });
  let c = await startApp(true);
  const shell = JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:(navigator.userAgent.match(/Chrome\\/[\\d.]+/)||[''])[0],dpr:devicePixelRatio,w:innerWidth,h:innerHeight,card:ARCADE.GAMES.findIndex(g=>g.id==='papa-potato')})`));
  ok("APK shell on WebView 83 (legacy builds), Papa Potato card present", shell.legacy && /Chrome\/83/.test(shell.ua) && shell.card > 0, shell);
  // ---- v01 slot (frozen 0.1) opens, writes only the v1 save; then PLAY opens 0.2 which migrates it ----
  { let g1 = await openGame(c, "00a", true); await sleep(14000);
    const v1 = await g1.J(`{ver:PP.version,title:document.title,boxes:document.querySelectorAll('#cmd .box').length,t:+PP.sim.s.t.toFixed(1),errs:window.__errs}`); shot("00b-v01-0.1-running");
    ok("v01 slot opens the frozen Papa Potato 0.1 on WebView 83 (3 boxes, clock runs, 0 errors)", v1.ver === "0.1" && v1.boxes === 3 && v1.t > 5 && v1.errs.length === 0, v1);
    const keys = await c.ev("JSON.stringify([!!localStorage.getItem('papaPotato.save.v1'),!!localStorage.getItem('papaPotato.save.v2')])");
    ok("0.1 wrote only its own save key (v1 yes, v2 no)", keys === "[true,false]", keys);
    await c.ev("ARCADE.back(),1"); await sleep(2500); }
  let g = await openGame(c, "01");
  { const m = await g.J(`{migrated:PP.migrated,v:PP.sim.s.v,total:PP.sim.total(),pot:PP.sim.s.box.pot,keysAfter:[!!localStorage.getItem('papaPotato.save.v1'),!!localStorage.getItem('papaPotato.save.v2')]}`); shot("01b-migrated-from-0.1");
    ok("PLAY → 0.2 migrates the real 0.1 save on-device (v2 state, potato count conserved, 0.1 key kept)", m.migrated === true && m.v === 2 && m.total === 128 && m.keysAfter[0] === true, m);
    await g.ev("(PP.reset(777),1)"); await sleep(1500); }
  const env = await g.J(`{ready:window.__PP_READY===true,prelude:/TJ legacy prelude/.test(document.documentElement.innerHTML),brand:document.querySelector('#hud .brand b').innerText.replace(/\\s+/g,' '),title:document.title,vw:innerWidth,vh:innerHeight,zoom:PP.layout().zoom,errs:window.__errs}`);
  ok("real tap on PLAY opens Papa Potato (legacy variant with prelude), PAPA POTATO HUD, 0 errors", env.ready && env.prelude && env.brand === "PAPA POTATO" && env.errs.length === 0, env);
  shot("02-papa-potato-start");
  const s0 = await g.J(ST);
  // scroll-safety with REAL swipes: vertical swipes across each slider must not change anything
  for (const id of ["pace", "eat", "nap"]) { const a = await g.pt(`.box[data-id="${id}"] .trk`, 0.5, 0.5); sh(`shell input swipe ${a.x} ${a.y} ${a.x + 8} ${a.y - 150} 300`); await sleep(900); sh(`shell input swipe ${a.x} ${a.y} ${a.x - 8} ${a.y + 150} 300`); await sleep(900); }
  const s1 = await g.J(ST); const gl = await g.J("window.__ppGL.slice(-24)"); fs.writeFileSync(`${OUT}/gesture-log-vertical.json`, JSON.stringify(gl, null, 1));
  ok("6 real vertical swipes over the sliders change no box", JSON.stringify(s0.box) === JSON.stringify(s1.box) && s1.focus === null, { before: s0.box, after: s1.box, focus: s1.focus, gl: gl.slice(-6) });
  // locked: horizontal swipe on an unselected slider does nothing
  { const a = await g.pt('.box[data-id="eat"] .trk', 0.9), b = await g.pt('.box[data-id="eat"] .trk', 0.3); sh(`shell input swipe ${a.x} ${a.y} ${b.x} ${b.y} 400`); await sleep(1200); }
  const s2 = await g.J(ST); ok("real horizontal swipe on an unselected slider: locked, no change", s2.box.eat === s0.box.eat, s2.box);
  // tap EAT box → selected, then real horizontal swipe → value
  await g.atap('.box[data-id="eat"] .nm', 1200); const f = await g.J(ST); shot("03-eat-selected");
  { const a = await g.pt('.box[data-id="eat"] .trk', 0.95), b = await g.pt('.box[data-id="eat"] .trk', 0.55); sh(`shell input swipe ${a.x} ${a.y} ${b.x} ${b.y} 500`); await sleep(1500); }
  const s3 = await g.J(ST);
  ok("real tap selects EAT (lit), then a real horizontal swipe sets it", f.focus === "eat" && s3.box.eat >= 20 && s3.box.eat <= 45 && s3.ui[1] === s3.box.eat + "%", { focus: f.focus, eat: s3.box.eat, ui: s3.ui });
  // NAP via real + taps
  for (let i = 0; i < 5; i++) await g.atap('.box[data-id="nap"] .pm[data-d="1"]', 700);
  const s4 = await g.J(ST); ok("5 real taps on NAP + → 25%", s4.box.nap === 25 && s4.ui[2] === "25%", s4.box);
  shot("04-boxes-set");
  // play ~2 min real time; buy food with a real tap once there are 8 coins
  const timeline = []; let bought = null; const t0 = Date.now(); let fpsNote = null;
  while (Date.now() - t0 < 125000) {
    await sleep(5000); const s = await g.J(ST); timeline.push({ real: Math.round((Date.now() - t0) / 1000), t: s.t, coins: s.coins, food: s.food, state: s.state, peeled: s.peeled });
    if (!bought && s.coins >= 8) { const B = "{coins:PP.sim.s.coins,food:PP.sim.s.food,bought:PP.sim.s.stats.bought,spent:PP.sim.s.stats.spent,earned:PP.sim.s.stats.earned,meals:PP.sim.s.stats.meals,ui:document.getElementById('food').textContent}"; const b4 = await g.J(B); await g.atap("#buy", 1500); const af = await g.J(B); bought = { before: b4, after: af }; shot("06-bought-food"); }
    const real = (Date.now() - t0) / 1000; if (Math.abs(real - 30) < 3) shot("05-playing-30s"); if (Math.abs(real - 90) < 3) shot("07-playing-90s");
  }
  fpsNote = await g.ev(`new Promise(r=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n/((performance.now()-t0)/1000)).toFixed(1))}requestAnimationFrame(f)})`);
  const s5 = await g.J(ST); fs.writeFileSync(`${OUT}/timeline.json`, JSON.stringify(timeline, null, 1));
  ok("played ~2 min real time: he peels and ships (coins + potatoes go up), game clock follows real time", s5.peeled >= 4 && s5.t > 90 && timeline.some((x) => x.coins > 0), { real: timeline[timeline.length - 1].real, t: s5.t, peeled: s5.peeled, coins: s5.coins, emuFps: fpsNote });
  ok("BUY FOOD with a real tap: exactly one purchase, 8 coins spent (coins = before − 8 + earned meanwhile), +1 food, HUD updates", bought && bought.after.bought === bought.before.bought + 1 && bought.after.spent === bought.before.spent + 8 && bought.after.coins === bought.before.coins - 8 + (bought.after.earned - bought.before.earned) && bought.after.food === bought.before.food + 1 - (bought.after.meals - bought.before.meals) && String(bought.after.ui).startsWith(String(bought.after.food)), bought);
  // change a box (pace) with real taps
  await g.atap('.box[data-id="pace"] .pm[data-d="1"]', 900); const s6 = await g.J(ST);
  ok("real tap on WORK PACE + → BRISK", s6.box.pace === 3 && s6.ui[0] === "BRISK", s6.ui);
  shot("08-pace-brisk");
  // ---- 0.2: panel scroll with a real swipe, CLEAN + POTATOES, max potatoes, sweeping, suction ----
  { const a = await g.pt('.box[data-id="pace"] .trk', 0.5, 0.5); const bx = await g.J(`{...PP.sim.s.box}`); for (let k = 0; k < 4; k++) { sh(`shell input swipe ${a.x} ${a.y} ${a.x + 5} ${a.y - 220} 350`); await sleep(1500); const q = await g.J(`{st:document.getElementById('cmd').scrollTop,max:document.getElementById('cmd').scrollHeight-document.getElementById('cmd').clientHeight}`); if (q.st >= q.max - 3) break; const a2 = await g.pt('.box[data-id="clean"] .trk', 0.5, 0.5); a.x = a2.x; a.y = a2.y; }
    const sc = await g.J(`{st:document.getElementById('cmd').scrollTop,box:{...PP.sim.s.box},cleanTop:document.querySelector('.box[data-id="clean"]').getBoundingClientRect().top,buyTop:document.getElementById('buy').getBoundingClientRect().top,potBottom:document.querySelector('.box[data-id="pot"]').getBoundingClientRect().bottom,ch:innerHeight}`); shot("08b-panel-scrolled");
    ok("a real vertical swipe on a slider scrolls the panel to CLEAN + POTATOES; no value changes; BUY stays visible", sc.st > 20 && JSON.stringify(sc.box) === JSON.stringify(bx) && sc.buyTop < sc.ch && sc.potBottom <= sc.buyTop + 5, sc);
    await g.atap('.box[data-id="clean"] .nm', 1200); { const p1 = await g.pt('.box[data-id="clean"] .trk', 0.9), p2 = await g.pt('.box[data-id="clean"] .trk', 0.55); sh(`shell input swipe ${p1.x} ${p1.y} ${p2.x} ${p2.y} 500`); await sleep(1500); }
    const cl = await g.J(`{clean:PP.sim.s.box.clean,lab:document.querySelector('.box[data-id="clean"] .val').textContent}`);
    ok("real tap selects CLEAN, real horizontal swipe sets 'clean when peels > N'", cl.clean > 0 && cl.clean % 5 === 0 && cl.lab === "> " + cl.clean, cl);
    await g.atap('.box[data-id="pot"] .pm[data-d="1"]', 800); await g.atap('.box[data-id="pot"] .pm[data-d="1"]', 800);
    const p3 = await g.J(`{pot:PP.sim.s.box.pot,lab:document.querySelector('.box[data-id="pot"] .val').textContent,total:PP.sim.total()}`);
    ok("2 real taps on POTATOES + → 128→160→200 (list steps); the label and the pile follow", p3.lab === "200" && p3.total === 200, p3);
    // slide POTATOES with a real swipe after selecting
    await g.atap('.box[data-id="pot"] .nm', 1000); { const p1 = await g.pt('.box[data-id="pot"] .trk', 0.9), p2 = await g.pt('.box[data-id="pot"] .trk', -0.05); sh(`shell input swipe ${p1.x} ${p1.y} ${p2.x} ${p2.y} 600`); await sleep(2500); }
    const p4 = await g.J(`{pot:PP.sim.s.box.pot,lab:document.querySelector('.box[data-id="pot"] .val').textContent,total:PP.sim.total(),errs:window.__errs}`);
    shot("08c-potatoes-max-slider");
    ok("real swipe slides POTATOES to the 800 end; total = 800; 0 JS errors", p4.lab === "800" && p4.total === 800 && p4.errs.length === 0, p4);
    // run at 800 for 25 s on the software emulator: no crash, no errors, heap stays small
    const h0 = await g.J(`performance.memory?performance.memory.usedJSHeapSize:0`); await sleep(25000);
    const fps800 = await g.ev(`new Promise(r=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n/((performance.now()-t0)/1000)).toFixed(1))}requestAnimationFrame(f)})`);
    const h1 = await g.J(`{heap:performance.memory?performance.memory.usedJSHeapSize:0,errs:window.__errs,st:PP.stats(),t:PP.sim.s.t}`); shot("08d-800-potatoes-playing");
    ok("800 potatoes on WebView 83 (software emulator): ran 25 s, 0 errors, JS heap not growing (>2x)", h1.errs.length === 0 && (h0 === 0 || h1.heap < h0 * 2 + 4e6), { h0, h1: h1.heap, emuFps: fps800, st: h1.st });
    await g.atap('.box[data-id="pot"] .pm[data-d="-1"]', 600); for (let i = 0; i < 8; i++) await g.atap('.box[data-id="pot"] .pm[data-d="-1"]', 400);
    const p5 = await g.J(`{lab:document.querySelector('.box[data-id="pot"] .val').textContent,total:PP.sim.total()}`); ok("real − taps bring the count back down (…→ ≤ 128), total follows", +p5.lab <= 128 && p5.total === +p5.lab, p5);
    // sweeping: make a mess over the threshold; he should go CLEANING and the mess should shrink
    await g.ev(`(PP.sim.setBox('clean',20),PP.sim.s.peels=90,PP.sim.s.food=Math.max(PP.sim.s.food,3),PP.sim.s.hunger=90,PP.sim.s.energy=90,1)`); let sw = null; const swT0 = Date.now();
    while (Date.now() - swT0 < 90000) { await sleep(2500); const q = await g.J(`{state:(document.querySelector('.st.on')||{}).textContent,peels:PP.sim.s.peels,sweeps:PP.sim.s.stats.sweeps}`); if (q.state === "CLEANING" && !sw) { sw = q; shot("08e-cleaning-on-emulator"); } if (q.sweeps >= 1 && q.peels < 60) { sw = Object.assign(sw || {}, { done: q }); break; } }
    ok("peels over the CLEAN threshold: CLEANING seen and the mess shrinks (real sweeps on the emulator)", sw && sw.done && sw.done.peels < 60, sw);
    await g.ev(`(PP.sim.setBox('clean',0),1)`);
    // suction visual: fill the chute and start a suck; screenshot mid-effect
    await g.ev(`((()=>{const s=PP.sim.s,d=Math.min(6-s.chute,s.pile);s.pile-=d;s.chute+=d})(),PP.sim.startSuck(),1)`); const su = await g.J(`{suck:!!PP.sim.s.suck,t:PP.sim.s.t,errs:window.__errs}`); shot("08f-suction-mid-effect"); await sleep(7000);
    const su2 = await g.J(`{suck:PP.sim.s.suck,pile:PP.sim.s.pile,chute:PP.sim.s.chute,total:PP.sim.total(),sucks:PP.sim.s.stats.sucks,errs:window.__errs}`);
    ok("suction on WebView 83: effect runs, completes, potatoes return (total conserved), 0 errors", su.suck && su2.total === +(await g.J(`PP.sim.s.box?PP.Sim.POTS[PP.sim.s.box.pot]:0`)) && su2.errs.length === 0, { su, su2 }); }
  const saved = await g.J(ST);
  ok("0 JS errors in Papa Potato during play on WebView 83", saved.errs.length === 0, saved.errs);
  // quit #1: the phone's Back key twice (arcade "Tap again to leave") → menu; reopen
  sh("shell input keyevent 4 4"); await sleep(3000);
  const inMenu = await c.ev("!ARCADE.inGame&&document.querySelectorAll('#game iframe').length===0"); shot("09-back-in-menu");
  ok("real Back key twice leaves Papa Potato cleanly (frame removed, menu back)", inMenu, inMenu);
  g = await openGame(c, "10"); const r1 = await g.J(ST); shot("11-reopened");
  ok("reopened from the menu: save restored (boxes, food stock net of meals, coins, clock not reset)", JSON.stringify(r1.box) === JSON.stringify(saved.box) && r1.bought === saved.bought && r1.food === saved.food - (r1.meals - saved.meals) && r1.coins >= saved.coins && r1.t >= saved.t && r1.ui.join() === saved.ui.join(), { note: "game keeps running during the slow Back on the emulator; food is checked as saved − meals eaten meanwhile", saved: { t: saved.t, box: saved.box, food: saved.food, coins: saved.coins, meals: saved.meals, bought: saved.bought }, r1: { t: r1.t, box: r1.box, food: r1.food, coins: r1.coins, meals: r1.meals, bought: r1.bought, ui: r1.ui } });
  // quit #2: kill the whole app (force-stop), relaunch, reopen
  await sleep(5000); const k0 = await g.J(ST); c.close();
  c = await startApp(false); g = await openGame(c, "12"); const r2 = await g.J(ST); shot("13-after-force-stop");
  ok("force-stop the app → relaunch → Papa Potato: save restored (≤ 4 s of play lost by design)", JSON.stringify(r2.box) === JSON.stringify(k0.box) && r2.food === k0.food && r2.coins >= saved.coins && r2.t >= k0.t - 5 && r2.t > 60, { before: { t: k0.t, coins: k0.coins, food: k0.food, box: k0.box }, after: { t: r2.t, coins: r2.coins, food: r2.food, box: r2.box } });
  ok("0 JS errors after relaunch", r2.errs.length === 0, r2.errs);
  // force-kill mid-suction: start a suck, save, kill the app at once, relaunch
  { await g.ev(`((()=>{const s=PP.sim.s,d=Math.min(6-s.chute,s.pile);s.pile-=d;s.chute+=d})(),PP.sim.startSuck(),PP.save(),1)`); const pre = await g.J(`{suck:PP.sim.s.suck,total:PP.sim.total(),pot:PP.sim.s.box.pot}`); sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); c.close();
    c = await startApp(false); g = await openGame(c, "14"); const post = await g.J(`{suck:PP.sim.s.suck,t:PP.sim.s.t,total:PP.sim.total(),pile:PP.sim.s.pile,chute:PP.sim.s.chute,pot:PP.sim.s.box.pot,errs:window.__errs}`); shot("14-after-kill-mid-suction"); await sleep(6000);
    const post2 = await g.J(`{suck:PP.sim.s.suck,total:PP.sim.total(),errs:window.__errs}`);
    ok("force-kill mid-suction → relaunch: state valid, potato total conserved, suction continues/finishes, 0 errors", pre.suck && post.total === +(await g.J("PP.Sim.POTS[PP.sim.s.box.pot]")) && post.errs.length === 0 && post2.total === post.total && post2.errs.length === 0, { pre, post, post2 }); }
  await c.ev("ARCADE.back(),1"); 
  fs.writeFileSync(`${OUT}/emu-2758.json`, JSON.stringify({ shell, R, timeline }, null, 1));
  console.log(`emu-2758: ${R.filter((r) => r.pass).length}/${R.length} pass`); c.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); fs.writeFileSync(`${OUT}/emu-2758.json`, JSON.stringify({ R, err: e.message }, null, 1)); process.exit(1); });
