// Arcade 2.7.58 = unpublished 2.7.57 (APK 4e303b0e…, bundle 2dbba426…) with
//   papa-potato:latest  -> Papa Potato 0.2
//   papa-potato:v01     -> NEW slot: Papa Potato 0.1, byte-identical to the 2.7.57 "latest" payload
// plus the card (v01 first, latest default) and the GAME_LEGACY entries. Every other slot payload + legacy variant byte-for-byte.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-potato2";
const BASE = `${B}/package-2.7.58/base-2.7.57.html`, NEWF = `${B}/out/papa-potato-0.2.html`, OLDF = `${B}/out/papa-potato-0.1-frozen.html`;
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "2dbba426faa22b2c0ce3b8c1a2ef1efa9db19fb0a6f18a953902b31da03548fd", "2.7.57 bundle changed?!");
const NEW = fs.readFileSync(NEWF, "utf8"), OLD = fs.readFileSync(OLDF, "utf8");
assert(sha(OLD) === "7f723f70ce086e4a78ee5b993d493deac66cbc29914371b60b273257d357f229", "frozen 0.1 html changed");
const KL = "papa-potato:latest", KO = "papa-potato:v01";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && !before[KO], "slots before");
const G0 = GS(src); assert(G0[KL] === OLD, "2.7.57 latest payload == frozen 0.1");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
// 1) replace the latest slot in place, append the v01 slot at the end
let out = src.slice(0, before[KL][0]) + ex(NEW) + src.slice(before[KL][1]);
const END = '\n};})(); // END_PACKED_GAME_SRC'; const e = out.indexOf(END); assert(e > 0 && out.slice(e - 10, e) === '].join("")', "end marker");
out = out.slice(0, e) + ',\n"' + KO + '":' + ex(OLD) + out.slice(e);
// 2) card
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const ci = GAMES.findIndex((g) => g.id === "papa-potato"); assert(ci >= 0, "card");
const c0 = GAMES[ci]; const oldV = c0.versions[0]; assert(oldV.id === "latest" && c0.versions.length === 1, "card shape");
c0.tagline = "Top-down potato room. He peels forever; you program his day with command boxes.";
c0.versions = [
  { id: "v01", name: "v0.1 – foundation (2.7.57)", desc: oldV.desc, def: false },
  { id: "latest", name: "v0.2 – Latest (the pile loop)", desc: "Papa Potato 0.2: a real heaped POTATO PILE, an infinite loop (peeled spuds fill the SHIPPING chute, then get sucked up and come back onto the pile with their skin on), PEELS pile up on the floor with a counter and a CLEAN box (sweeping costs time, a messy floor slows him), a POTATOES IN PLAY slider, and food that gets more expensive as you buy it. Five command boxes along the bottom (Work pace, Eat when hunger <, Nap when energy <, Clean when peels >, Potatoes in play); BUY FOOD stays pinned under them. Tap a box to unlock its slider so scrolling never moves one. Your 0.1 save is carried over; 0.1 stays playable and keeps its own save.", def: true }];
GAMES[ci] = c0;
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// 3) legacy parts for both
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const repN = {}, repO = {}; const pN = legacyParts(NEW, repN), pO = legacyParts(OLD, repO); assert(repN.jsFail.length === 0 && repO.jsFail.length === 0, "legacy js fail");
assert(joinParts(pN, NEW) === legacyHtml(NEW, {}) && joinParts(pO, OLD) === legacyHtml(OLD, {}), "parts mismatch");
assert(JSON.stringify(pO) === JSON.stringify(LEG[KL]), "v01 legacy parts == 2.7.57 latest legacy parts");
const LEG2 = { ...LEG, [KL]: pN, [KO]: pO };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// ---- verification ----
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]); assert(JSON.stringify(changed) === JSON.stringify([KL]), "changed slots " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([KO]), "new slots");
const G1 = GS(out); assert(G1[KL] === NEW && G1[KO] === OLD, "payloads");
for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); const sl = slots(t); const ends = t.indexOf('\n};})(); // END_PACKED_GAME_SRC'); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const k1 = s.indexOf(',\n"' + KO + '":'); if (k1 >= 0) { const k2 = s.indexOf('].join("")', k1) + 10; s = s.slice(0, k1) + s.slice(k2); } const ks = slots(s); const x = ks[KL]; return s.slice(0, x[0]) + "<LATEST>" + s.slice(x[1]); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / latest slot / v01 slot / GAME_LEGACY");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.58", versionCode: 96, latest: "Papa Potato 0.2", v01: "Papa Potato 0.1 (frozen, = 2.7.57 payload)", gameHtmlSHA256_02: sha(NEW), gameHtmlBytes_02: Buffer.byteLength(NEW), frozenHtmlSHA256_01: sha(OLD),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), baseBundleSHA256_2757: sha(src), cartridgeSlots: Object.keys(after).length, unchangedSlots: Object.keys(before).length - 1, changedSlots: changed, newSlots: [KO],
  legacy: { v02: `css ${repN.css} js ${repN.js}`, v01: `css ${repO.css} js ${repO.js}`, variants: Object.keys(LEG2).length }, menuOrder: GAMES.map((g) => g.id), papaVersions: GAMES[ci].versions.map((v) => v.id + (v.def ? "*" : "")) };
fs.writeFileSync(OUT.replace(/[^/]+$/, "assembly-verification.json"), JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
