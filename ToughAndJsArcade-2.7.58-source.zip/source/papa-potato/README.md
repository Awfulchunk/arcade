# Papa Potato 0.2 source (Tough & J's Arcade 2.7.58) — GPL-3.0
- game/: the cartridge. `build.sh` joins head.html + sim.js (DOM-free simulation) + game.js (renderer, HUD, scroll-safe command panel, save) into papa-potato-0.2.html. `papa-potato-0.1-frozen.html` is the untouched 0.1 (ships as slot papa-potato:v01). The approved layout mock is included.
- arcade-2.7.58/: assemble the new cartridge into the (unpublished) 2.7.57 bundle (every other cartridge byte-identical; `papa-potato:latest` replaced, `papa-potato:v01` added), verify, arcade regression, WebView-83 emulator script, run-final.sh (the sequential test pipeline).
- tests/: pass 1 mechanics (t-mech, t-mech02), pass 2 GUI, A03s perf, BUFF tests (t-buff), stress (t-stress), screenshot script, balance runner, the real 0.1 save fixture.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.56).
- No signing keys are included. Papa Potato has no secrets and no Latch code.
