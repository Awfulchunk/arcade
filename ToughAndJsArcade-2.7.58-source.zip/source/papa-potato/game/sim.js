/* ===== Papa Potato 0.2 — simulation (no DOM; runs headless for tests) ===== */
var PPSim=(function(){
  var PACE=["CHILL","EASY","STEADY","BRISK","GRIND"];
  var SPD=[0.6,0.8,1.0,1.25,1.5];      /* work + walk speed */
  var DRN=[0.55,0.75,1.0,1.45,2.0];    /* hunger + energy drain */
  var C={
    walk:18,            /* canonical room units / s (room = 100 x 150) */
    grab:0.7, peel:6.0, drop:0.5, eat:3.0,
    meal:55, foodPrice:8, foodMax:9,
    hungerDrain:0.30, hungerDrainNap:0.10,
    energyDrain:0.42,
    napRegen:6.0, lazyNapRegen:4.0, napWake:98,
    value:2, sloppyValue:1,
    lazyLow:25, lazySpeed:0.5,
    startCoins:0, startFood:1,
    /* 0.2: shipping chute + suction loop */
    chuteCap:6, tSuck:2.0, tTransit:1.5, retGap:0.12, flight:0.8,
    /* 0.2: peels, mess penalty, sweeping */
    peelPer:3, peelPerSloppy:5, peelMax:200, messFull:90, messMax:0.30,
    sweepRate:6, sweepWind:0.8,
    /* 0.2: food price pushback: min(priceCap, round(foodPrice * priceGrow^bought) + floor(t / priceEvery)) */
    priceGrow:1.05, priceCap:14, priceEvery:900
  };
  /* potatoes in play (settings slider; index into this list). Cap chosen from the A03s throttle tests. */
  var POTS=[4,8,12,16,24,32,48,64,96,128,160,200,250,300,400,500,650,800];
  var BOX={
    pace:{min:0,max:4,step:1,def:2},
    eat:{min:0,max:70,step:5,def:0},   /* 0 = OFF (unset) */
    nap:{min:0,max:70,step:5,def:0},
    clean:{min:0,max:90,step:5,def:0},            /* 0 = OFF: sweep when peels > X */
    pot:{min:0,max:POTS.length-1,step:1,def:9}    /* index into POTS */
  };
  /* spots, as fractions of the room (render maps them to the real room) */
  var SPOT={
    table:{x:0.50,y:0.48,dir:0},
    chute:{x:0.50,y:0.175,dir:0},
    mat:{x:0.25,y:0.575,dir:1},
    food:{x:0.64,y:0.305,dir:0},
    sweep:{x:0.37,y:0.57,dir:3},
    pileY:0.665
  };
  function fresh(seed){
    seed=(seed>>>0)||((Math.random()*4294967295)>>>0);
    return {v:2,seed:seed,rs:0,rr:seed|0,t:0,
      coins:C.startCoins,food:C.startFood,hunger:100,energy:100,
      box:{pace:BOX.pace.def,eat:BOX.eat.def,nap:BOX.nap.def,clean:BOX.clean.def,pot:BOX.pot.def},
      pile:POTS[BOX.pot.def],chute:0,suck:null,peels:0,
      stats:{peeled:0,earned:0,meals:0,naps:0,lazyNaps:0,bought:0,spent:0,lazyTime:0,eatTime:0,napTime:0,firstBuyT:-1,
        sucks:0,swept:0,sweeps:0,peelsMade:0,maxPeels:0,cleanTime:0,waitTime:0},
      g:{x:0.5,y:0.40,dir:2,hold:null,job:"pile",peel:0,sloppy:false,lazy:false,act:null,walkPh:0},
      ev:[]};
  }
  function Sim(st){
    this.s=st||fresh();if(typeof this.s.rr!=="number")this.s.rr=this.s.seed|0;
    if(!this.s.g.act)this.decide();
  }
  var P=Sim.prototype;
  /* mulberry32 with its state kept in the save, so a loaded game continues exactly */
  P.rand=function(){var a=this.s.rr=(this.s.rr+0x6D2B79F5)|0;this.s.rs=(this.s.rs|0)+1;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  P.emit=function(e){if(this.s.ev.length<64)this.s.ev.push(e);};
  P.spd=function(){var g=this.s.g;return g.lazy?C.lazySpeed:SPD[this.s.box.pace];};
  /* messy floor slows walking, grabbing, peeling and dropping (not sweeping, not eating/napping) */
  P.messF=function(){return 1-C.messMax*Math.min(1,this.s.peels/C.messFull);};
  P.wspd=function(){return this.spd()*this.messF();};
  P.price=function(){var b=this.s.stats.bought;return Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery));};
  P.target=function(){return POTS[this.s.box.pot];};
  P.total=function(){var s=this.s,k=s.suck;return s.pile+(s.g.hold?1:0)+s.chute+(k?k.n-k.landed:0);};
  P.suckBusy=function(){var k=this.s.suck;return !!k&&this.s.t<k.t0+C.tSuck;};
  P.startSuck=function(){var s=this.s;if(s.suck||s.chute<=0)return false;s.suck={t0:s.t,n:s.chute,landed:0};s.chute=0;s.stats.sucks++;this.emit({k:"suck"});return true;};
  /* keep the number of potatoes in play equal to the slider: add to / take from the raw pile (then chute, then the ones in transit) */
  P.retarget=function(){var s=this.s,d=this.target()-this.total();if(d>0){s.pile+=d;return;}
    var r=-d,t=Math.min(r,s.pile);s.pile-=t;r-=t;
    if(r>0){t=Math.min(r,s.chute);s.chute-=t;r-=t;}
    if(r>0&&s.suck){var k=s.suck;t=Math.min(r,k.n-k.landed);k.n-=t;r-=t;if(k.n<=k.landed)s.suck=null;}};
  P.drn=function(){var g=this.s.g;return g.lazy?DRN[0]:DRN[this.s.box.pace];};
  P.needState=function(){
    var s=this.s,b=s.box;
    var eatThr=b.eat>0?b.eat:0,napThr=b.nap>0?b.nap:0;
    var wantEat=eatThr>0&&s.hunger<eatThr&&s.food>0;
    var wantNap=napThr>0&&s.energy<napThr;
    var hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<C.lazyLow);
    var energyUnmet=napThr>0?false:(s.energy<C.lazyLow);
    var lazy=(hungerUnmet||energyUnmet);
    return {wantEat:wantEat,wantNap:wantNap,lazy:lazy,hungerUnmet:hungerUnmet,energyUnmet:energyUnmet,
      wantClean:b.clean>0&&s.peels>b.clean&&!lazy&&!s.g.hold};
  };
  P.walkTo=function(x,y,dir,then,label){var g=this.s.g;g.act={t:"walk",x:x,y:y,dir:dir,then:then,label:label};};
  P.decide=function(){
    var s=this.s,g=s.g,n=this.needState();
    if(n.wantEat){g.lazy=false;this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the food");return;}
    if(n.wantNap){g.lazy=false;this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the mat");return;}
    g.lazy=n.lazy;
    if(n.wantClean){this.walkTo(SPOT.sweep.x,SPOT.sweep.y,SPOT.sweep.dir,"sweep","to the broom");return;}
    if(g.lazy){
      var r=this.rand();
      if(s.energy<15||(s.energy<70&&r<0.30)){g.act={t:"lazynap",until:Math.min(100,60+this.rand()*35),label:"dozing on the floor"};s.stats.lazyNaps++;this.emit({k:"lazynap"});return;}
      if(r>0.72){g.act={t:"idle",d:1.5+this.rand()*2.5,e:0,label:"slacking off"};return;}
    }
    if(g.job==="pile"){var px=0.36+this.rand()*0.28;this.walkTo(px,SPOT.pileY,2,"grab","to the pile");}
    else if(g.job==="table"||g.job==="peel"){this.walkTo(SPOT.table.x,SPOT.table.y,0,"peel","to the table");}
    else this.walkTo(SPOT.chute.x,SPOT.chute.y,0,"drop","to the chute");
  };
  P.startAt=function(kind){
    var g=this.s.g;
    if(kind==="grab")g.act={t:"grab",e:0,label:"grabbing a potato"};
    else if(kind==="peel"){g.job="peel";g.act={t:"peel",label:g.lazy?"peeling (sloppy)":"peeling"};}
    else if(kind==="drop")g.act={t:"drop",e:0,label:"shipping it"};
    else if(kind==="eat")g.act={t:"eat",e:0,label:"eating"};
    else if(kind==="sweep")g.act={t:"sweep",e:0,acc:0,label:"sweeping up the peels"};
    else if(kind==="nap"){g.act={t:"nap",label:"napping on the mat"};this.s.stats.naps++;this.emit({k:"nap"});}
  };
  /* one fixed step of game time (dt seconds, ≤ 0.25) */
  P.step=function(dt){
    var s=this.s,g=s.g,a=g.act,sp=this.spd(),dr=this.drn(),wsp=sp*this.messF();
    s.t+=dt;
    if(s.suck){var k=s.suck,T0=k.t0+C.tSuck+C.tTransit;
      while(k.landed<k.n&&s.t>=T0+k.landed*C.retGap+C.flight){s.pile++;k.landed++;this.emit({k:"land"});}
      if(k.landed>=k.n)s.suck=null;}
    if(a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep")))s.stats.cleanTime+=dt;
    var resting=a&&(a.t==="nap"||a.t==="lazynap"),eating=a&&a.t==="eat";
    if(resting){s.hunger-=C.hungerDrainNap*dt;}
    else if(!eating){s.hunger-=C.hungerDrain*dr*dt;s.energy-=C.energyDrain*dr*dt*(a&&a.t==="idle"?0.4:1);}
    if(s.hunger<0)s.hunger=0;if(s.energy<0)s.energy=0;
    if(g.lazy)s.stats.lazyTime+=dt;
    if(eating||(a&&a.t==="walk"&&a.then==="eat"))s.stats.eatTime+=dt;
    if(resting||(a&&a.t==="walk"&&a.then==="nap"))s.stats.napTime+=dt;
    if(!a){this.decide();return;}
    switch(a.t){
      case "walk":{
        var dx=(a.x-g.x)*100,dy=(a.y-g.y)*150,d=Math.sqrt(dx*dx+dy*dy),mv=C.walk*wsp*dt;
        g.walkPh+=mv*0.35;
        if(Math.abs(dx)>Math.abs(dy)*0.8)g.dir=dx>0?1:3;else g.dir=dy>0?2:0;
        if(d<=mv||d<0.01){g.x=a.x;g.y=a.y;g.dir=a.dir;this.startAt(a.then);}
        else{g.x+=dx/d*mv/100;g.y+=dy/d*mv/150;}
        break;}
      case "grab":a.e+=dt*wsp;if(a.e>=C.grab){
          if(s.pile<=0){a.e=C.grab;a.label="waiting for potatoes";s.stats.waitTime+=dt;if(s.chute>0&&!s.suck)this.startSuck();break;}
          s.pile--;g.hold="raw";g.job="table";g.peel=0;g.sloppy=false;this.emit({k:"grab"});this.decide();}break;
      case "peel":
        if(g.lazy)g.sloppy=true;
        g.peel+=dt*wsp/C.peel;
        if(g.peel>=1){g.peel=1;g.hold="peeled";g.job="chute";var pp=g.sloppy?C.peelPerSloppy:C.peelPer;
          s.peels=Math.min(C.peelMax,s.peels+pp);s.stats.peelsMade+=pp;if(s.peels>s.stats.maxPeels)s.stats.maxPeels=s.peels;
          this.emit({k:"peeled"});this.decide();}
        break;
      case "drop":a.e+=dt*wsp;if(a.e>=C.drop){
          if(this.suckBusy()){a.e=C.drop;a.label="waiting for the chute";s.stats.waitTime+=dt;break;}
          var v=g.sloppy?C.sloppyValue:C.value;s.chute++;if(s.chute>=C.chuteCap)this.startSuck();s.coins+=v;s.stats.earned+=v;s.stats.peeled++;
          g.hold=null;g.job="pile";g.peel=0;this.emit({k:"coin",v:v,sloppy:g.sloppy});g.sloppy=false;this.decide();}break;
      case "eat":a.e+=dt;if(a.e>=C.eat){
          if(s.food>0){s.food--;s.hunger=Math.min(100,s.hunger+C.meal);s.stats.meals++;this.emit({k:"ate"});}
          var n=this.needState();if(n.wantEat){a.e=0;}else this.decide();}break;
      case "nap":s.energy=Math.min(100,s.energy+C.napRegen*dt);if(s.energy>=C.napWake)this.decide();break;
      case "lazynap":s.energy=Math.min(100,s.energy+C.lazyNapRegen*dt);if(s.energy>=a.until)this.decide();break;
      case "idle":a.e+=dt;if(a.e>=a.d)this.decide();break;
      case "sweep":{
        var nn=this.needState();
        if(s.box.clean<=0||nn.wantEat||nn.wantNap||nn.lazy){this.decide();break;}
        a.e+=dt*sp;
        if(a.e>C.sweepWind){a.acc+=dt*sp*C.sweepRate;var kk=Math.floor(a.acc);if(kk>0){a.acc-=kk;var rm=Math.min(kk,s.peels);s.peels-=rm;s.stats.swept+=rm;}}
        if(s.peels<=0){s.peels=0;s.stats.sweeps++;this.emit({k:"swept"});this.decide();}
        break;}
    }
  };
  P.run=function(sec,h){h=h||0.1;var n=Math.round(sec/h);for(var i=0;i<n;i++)this.step(h);};
  /* the player touched something: wake him out of lazy loafing so the change shows right away */
  P.poke=function(){var g=this.s.g,a=g.act,n=this.needState();
    if(a&&(a.t==="idle"||a.t==="lazynap"))this.decide();
    else if(a&&a.t==="walk"&&/grab|peel|drop|sweep/.test(a.then)&&(n.wantEat||n.wantNap))this.decide(); /* new food / a lowered threshold: act on it now, not after the next job */
    else if(g.lazy&&!n.lazy){g.lazy=false;}};
  P.setBox=function(id,v){var b=BOX[id];v=Number(v);if(v!==v)return false;v=Math.max(b.min,Math.min(b.max,Math.round(v/b.step)*b.step));if(this.s.box[id]===v)return false;this.s.box[id]=v;if(id==="pot")this.retarget();this.poke();return true;};
  P.buyFood=function(){var s=this.s,pr=this.price();if(s.food>=C.foodMax)return "full";if(s.coins<pr)return "poor";
    s.coins-=pr;s.food++;s.stats.bought++;s.stats.spent+=pr;if(s.stats.firstBuyT<0)s.stats.firstBuyT=s.t;this.poke();return "ok";};
  P.stateName=function(){var g=this.s.g,a=g.act;if(g.lazy)return "AUTO-LAZY";if(!a)return "PEELING";
    if(a.t==="eat"||(a.t==="walk"&&a.then==="eat"))return "EATING";
    if(a.t==="nap"||(a.t==="walk"&&a.then==="nap"))return "NAPPING";
    if(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"))return "CLEANING";return "PEELING";};
  P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];return JSON.stringify(o);};
  /* accepts a 0.2 save (v:2) or a 0.1 save (v:1, migrated; the 0.1 slot keeps its own v1 key, so it is never overwritten) */
  Sim.load=function(str){try{var o=JSON.parse(str);if(!o||(o.v!==1&&o.v!==2)||typeof o.coins!=="number"||!o.g||typeof o.g!=="object"||!o.box||typeof o.box!=="object")return null;
      var from1=o.v===1;o.v=2;
      var f=fresh(o.seed);for(var k in f)if(!(k in o))o[k]=f[k];
      if(!o.stats||typeof o.stats!=="object")o.stats={};for(var k2 in f.stats)if(typeof o.stats[k2]!=="number"||!isFinite(o.stats[k2]))o.stats[k2]=f.stats[k2];
      for(var id in BOX){var v=+o.box[id];if(!(v>=BOX[id].min&&v<=BOX[id].max))o.box[id]=BOX[id].def;}
      o.hunger=Math.max(0,Math.min(100,+o.hunger||0));o.energy=Math.max(0,Math.min(100,+o.energy||0));
      o.coins=Math.max(0,Math.min(1e9,Math.floor(+o.coins||0)));o.food=Math.max(0,Math.min(C.foodMax,Math.floor(+o.food||0)));o.ev=[];
      o.t=Math.max(0,+o.t||0);if(!isFinite(o.t))o.t=0;
      o.peels=Math.max(0,Math.min(C.peelMax,Math.floor(+o.peels||0)));
      o.chute=Math.max(0,Math.min(C.chuteCap,Math.floor(+o.chute||0)));
      o.pile=Math.max(0,Math.floor(+o.pile||0));
      var kk=o.suck;if(kk&&typeof kk==="object"&&isFinite(+kk.t0)&&+kk.n>0&&+kk.n<=C.chuteCap&&+kk.landed>=0&&+kk.landed<=+kk.n){o.suck={t0:+kk.t0,n:Math.floor(+kk.n),landed:Math.floor(+kk.landed)};if(o.suck.t0>o.t)o.suck.t0=o.t;}else o.suck=null;
      var g=o.g;if(g.act&&typeof g.act!=="object")g.act=null;
      var ok={walk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1};if(g.act&&!ok[g.act.t])g.act=null;
      if(g.act&&g.act.t==="walk"&&!(isFinite(+g.act.x)&&isFinite(+g.act.y)))g.act=null;
      if(!(g.x>=0&&g.x<=1))g.x=0.5;if(!(g.y>=0&&g.y<=1))g.y=0.4;if(!(g.dir>=0&&g.dir<=3))g.dir=2;
      if(g.hold!==null&&g.hold!=="raw"&&g.hold!=="peeled")g.hold=null;
      /* hands, job and action must agree (a corrupt save must never make a potato out of nothing) */
      var h=g.hold;g.job=h==="raw"?(g.job==="peel"?"peel":"table"):(h==="peeled"?"chute":"pile");
      if(g.act){var at=g.act,wt=at.t==="walk"?at.then:null;
        if((at.t==="peel"&&h!=="raw")||(at.t==="drop"&&h!=="peeled")||(at.t==="grab"&&h!==null)||(at.t==="sweep"&&h!==null)||
           (at.t==="walk"&&(["grab","peel","drop","eat","nap","sweep"].indexOf(wt)<0||(wt==="peel"&&h!=="raw")||(wt==="drop"&&h!=="peeled")||(wt==="grab"&&h!==null)||(wt==="sweep"&&h!==null))))g.act=null;}
      if(g.peel!==0&&!(g.peel>0&&g.peel<=1))g.peel=0;
      var sim=new Sim(o);
      /* 0.1 saves (and any inconsistent save): rebuild the potato counts so that pile + hand + chute + in transit = the slider */
      var want=POTS[o.box.pot],have=sim.total();
      if(from1||have!==want){if(have>want){o.pile=Math.max(0,o.pile-(have-want));}else o.pile+=want-have;}
      return sim;}catch(e){return null;}};
  Sim.fresh=function(seed){return new Sim(fresh(seed));};
  Sim.C=C;Sim.POTS=POTS;Sim.BOX=BOX;Sim.PACE=PACE;Sim.SPOT=SPOT;Sim.SPD=SPD;Sim.DRN=DRN;
  return Sim;
})();
if(typeof module!=="undefined")module.exports=PPSim;
