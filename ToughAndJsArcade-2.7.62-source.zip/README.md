# Tough & J's Arcade 2.7.62 (versionCode 100) — source (GPL-3.0)

2.7.62 is cumulative over 2.7.61 (Papa Potato 0.3 stays playable as slot papa-potato:v03, 0.2 as v02, 0.1 as v01):
- NEW: Papa Potato 0.4.1 (latest) — source/papa-potato/ (game src including sprites04.js, frozen 0.1 + 0.2 + 0.3 html, assembler/tests, WebView-83 emulator scripts, README). Inventory (buy-to-inv, equip tools, place from the EDIT tray), fit-to-screen room with no zoom/pan/scroll arrows, hidden name labels, solid furniture, CLEAN at the peels, cutting board moves with the table. Saves stay on the v4 key; existing owned items migrate as already placed. Old keys are never written.
- Unchanged from 2.7.61 / 2.7.59: Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms: source/latch-ui, latch-manual, latch-build, funmotion-0.2.5, swarm-1.6.14, needle-ui, engine, android-app, old-webview.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
