// Arcade 2.7.61 = published 2.7.59 bundle with
//   papa-potato:latest  -> Papa Potato 0.4 (new)
//   papa-potato:v03     -> NEW slot: Papa Potato 0.3, byte-identical to the 2.7.59 "latest" payload
//   papa-potato:v02     -> unchanged (Papa Potato 0.2)
//   papa-potato:v01     -> unchanged (Papa Potato 0.1)
// Every other slot payload + legacy variant byte-for-byte.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B04 = "/workspace/game/build-potato04";
const B31 = "/workspace/game/build-potato31";
const B2 = "/workspace/game/build-potato2";
const BASE = `${B31}/package-2.7.60/base-2.7.59.html`;
const NEWF = `${B04}/out/papa-potato-0.4.html`;
const V03F = `${B31}/out/papa-potato-0.3-frozen.html`;
const V02F = `${B2}/out/papa-potato-0.2.html`;
const OLDF = `${B2}/out/papa-potato-0.1-frozen.html`;
const SHAFILE = `${B31}/base-2759.sha256`;
const V03SHAFILE = `${B31}/frozen-03.sha256`;
const OUT = process.argv[2];
assert(fs.existsSync(BASE), "missing base-2.7.59.html — run sync-base-2759.sh after 2.7.59 is live");
assert(fs.existsSync(SHAFILE), "missing base-2759.sha256 — run sync-base-2759.sh after 2.7.59 is live");
const src = fs.readFileSync(BASE, "utf8");
const expectBase = fs.readFileSync(SHAFILE, "utf8").trim().split(/\s+/)[0];
assert(sha(src) === expectBase, `2.7.59 base hash mismatch: got ${sha(src)} expected ${expectBase}`);
const NEW = fs.readFileSync(NEWF, "utf8"), V03 = fs.readFileSync(V03F, "utf8"), V02 = fs.readFileSync(V02F, "utf8"), OLD = fs.readFileSync(OLDF, "utf8");
assert(sha(OLD) === "7f723f70ce086e4a78ee5b993d493deac66cbc29914371b60b273257d357f229", "frozen 0.1 html changed");
const expect03 = fs.existsSync(V03SHAFILE) ? fs.readFileSync(V03SHAFILE, "utf8").trim().split(/\s+/)[0] : "6e1bc23cb2a768a57887e6096abbdd43a996820ddf757fa04b46235f40d6c53d";
assert(sha(V03) === expect03, `frozen 0.3 html hash mismatch: got ${sha(V03)} expected ${expect03}`);
const KL = "papa-potato:latest", K3 = "papa-potato:v03", KO = "papa-potato:v02", K1 = "papa-potato:v01";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && before[KO] && before[K1] && !before[K3], "slots before");
const G0 = GS(src);
assert(G0[KL] === V03, "live 2.7.59 latest payload == the frozen 0.3 html (byte-identical)");
assert(G0[KO] === V02, "v02 slot == 0.2 html");
assert(G0[K1] === OLD, "v01 slot == frozen 0.1");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
// 1) replace the latest slot in place, append the v03 slot at the end
let out = src.slice(0, before[KL][0]) + ex(NEW) + src.slice(before[KL][1]);
const END = '\n};})(); // END_PACKED_GAME_SRC'; const e = out.indexOf(END); assert(e > 0 && out.slice(e - 10, e) === '].join("")', "end marker");
out = out.slice(0, e) + ',\n"' + K3 + '":' + ex(V03) + out.slice(e);
// 2) card
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const ci = GAMES.findIndex((g) => g.id === "papa-potato"); assert(ci >= 0, "card");
const c0 = GAMES[ci];
assert(c0.versions.length === 3 && c0.versions[0].id === "v01" && c0.versions[1].id === "v02" && c0.versions[2].id === "latest", "card shape from 2.7.59");
const v01c = c0.versions[0], v02c = c0.versions[1], v03from = c0.versions[2];
c0.versions = [
  v01c,
  v02c,
  { id: "v03", name: "v0.3 – taller room, shop, handbook (2.7.59)", desc: v03from.desc, def: false },
  { id: "latest", name: "v0.4 – Latest (levels, work line, editor)", desc: "Papa Potato 0.4: a slightly bigger room with levels and a shop, a conveyor work line (suction, auto-peeler, out-belt to shipping), decorations (TV + armchair — he sits facing the set — radio, plant, lamp, rug), a carry bag that grabs several potatoes at once, zoom and pan, and a room editor. Your 0.3 / 0.2 / 0.1 saves carry over into a new 0.4 slot (the old keys stay untouched). 0.3, 0.2 and 0.1 stay playable in their own version slots.", def: true }];
GAMES[ci] = c0;
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// 3) legacy parts
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const repN = {}, rep3 = {}; const pN = legacyParts(NEW, repN), p3 = legacyParts(V03, rep3); assert(repN.jsFail.length === 0 && rep3.jsFail.length === 0, "legacy js fail");
assert(joinParts(pN, NEW) === legacyHtml(NEW, {}) && joinParts(p3, V03) === legacyHtml(V03, {}), "parts mismatch");
assert(JSON.stringify(p3) === JSON.stringify(LEG[KL]), "v03 legacy parts == live 2.7.59 latest legacy parts");
const LEG2 = { ...LEG, [KL]: pN, [K3]: p3 };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// ---- verification ----
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]); assert(JSON.stringify(changed) === JSON.stringify([KL]), "changed slots " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([K3]), "new slots");
const G1 = GS(out); assert(G1[KL] === NEW && G1[K3] === V03 && G1[KO] === V02 && G1[K1] === OLD, "payloads");
for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); const ends = t.indexOf('\n};})(); // END_PACKED_GAME_SRC'); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const k1 = s.indexOf(',\n"' + K3 + '":'); if (k1 >= 0) { const k2 = s.indexOf('].join("")', k1) + 10; s = s.slice(0, k1) + s.slice(k2); } const ks = slots(s); const x = ks[KL]; return s.slice(0, x[0]) + "<LATEST>" + s.slice(x[1]); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / latest slot / v03 slot / GAME_LEGACY");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.61", versionCode: 99, latest: "Papa Potato 0.4", v03: "Papa Potato 0.3 (= live 2.7.59 latest payload, byte-identical)", v02: "Papa Potato 0.2", v01: "Papa Potato 0.1 (frozen)", gameHtmlSHA256_04: sha(NEW), gameHtmlBytes_04: Buffer.byteLength(NEW), html03SHA256: sha(V03), html02SHA256: sha(V02), frozenHtmlSHA256_01: sha(OLD),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), baseBundleSHA256_2759: sha(src), cartridgeSlots: Object.keys(after).length, unchangedSlots: Object.keys(before).length - 1, changedSlots: changed, newSlots: [K3],
  legacy: { v04: `css ${repN.css} js ${repN.js}`, v03: `css ${rep3.css} js ${rep3.js}`, variants: Object.keys(LEG2).length }, menuOrder: GAMES.map((g) => g.id), papaVersions: GAMES[ci].versions.map((v) => v.id + (v.def ? "*" : "")) };
fs.writeFileSync(OUT.replace(/[^/]+$/, "assembly-verification.json"), JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
