#!/bin/bash
# Full 2.7.61 build: game html -> arcade bundle (on top of the published 2.7.59 bundle) -> signed APK -> extract for tests.
set -euo pipefail
export PATH=/workspace/tools/jdk/bin:$PATH
B=/workspace/game/build-potato04
B31=/workspace/game/build-potato31
B2=/workspace/game/build-potato2
P=$B/package-2.7.61
bash $B/build.sh
node $B/assemble-2761.mjs $B/out/index.html | tee $B/out/assemble.log
cp $B/out/index.html $P/tough-and-js-arcade.html
rm -f $P/out/ToughAndJsArcade-2.7.61.apk $P/out/ToughAndJsArcade-2.7.61.apk.idsig
(cd $P && ./build-apk.sh) > $B/out/build-apk.log 2>&1
rm -rf /tmp/a61 && mkdir /tmp/a61 && (cd /tmp/a61 && unzip -q $P/out/ToughAndJsArcade-2.7.61.apk assets/index.html)
cp /tmp/a61/assets/index.html $B/test/index-from-apk.html
node $B/extract-slots-2761.cjs $B/test/index-from-apk.html \
  $B/test/papa-potato-from-apk.html \
  $B/test/papa-potato-v03-from-apk.html \
  $B/test/papa-potato-v02-from-apk.html \
  $B/test/papa-potato-v01-from-apk.html
cmp $B/test/papa-potato-from-apk.html $B/out/papa-potato-0.4.html
cmp $B/test/papa-potato-v03-from-apk.html $B31/out/papa-potato-0.3-frozen.html
cmp $B/test/papa-potato-v02-from-apk.html $B2/out/papa-potato-0.2.html
cmp $B/test/papa-potato-v01-from-apk.html $B2/out/papa-potato-0.1-frozen.html
cmp $B/test/index-from-apk.html $B/out/index.html
mkdir -p $B/evidence
sha256sum $P/out/ToughAndJsArcade-2.7.61.apk $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v03-from-apk.html $B/test/papa-potato-v02-from-apk.html $B/test/papa-potato-v01-from-apk.html | tee $B/evidence/tested-artifacts.sha256
