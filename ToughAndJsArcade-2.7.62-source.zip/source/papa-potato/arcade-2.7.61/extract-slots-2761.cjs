#!/usr/bin/env node
const fs=require('fs'),vm=require('vm');
const t=fs.readFileSync(process.argv[2],'utf8');
const i=t.indexOf('const GAME_SRC='),j=t.indexOf('// END_PACKED_GAME_SRC');
const G=vm.runInNewContext(t.slice(i,j)+'\nGAME_SRC;');
fs.writeFileSync(process.argv[3],G['papa-potato:latest']);
fs.writeFileSync(process.argv[4],G['papa-potato:v03']);
fs.writeFileSync(process.argv[5],G['papa-potato:v02']);
fs.writeFileSync(process.argv[6],G['papa-potato:v01']);
