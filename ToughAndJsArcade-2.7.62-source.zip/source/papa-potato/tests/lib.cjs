const puppeteer = require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");
const fs = require("fs"); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const GAME = process.env.PP_HTML || "file:///workspace/game/build-potato31/out/papa-potato-0.3.1.html";
async function browser() { return puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: "new", args: ["--no-sandbox", "--allow-file-access-from-files"] }); }
async function open(b, [w, h], opts = {}) {
  const p = await b.newPage(); const errs = [];
  p.on("pageerror", (e) => errs.push(e.message)); p.on("console", (m) => { if (m.type() === "error") errs.push("console: " + m.text()); });
  await p.setViewport({ width: w, height: h, deviceScaleFactor: opts.dpr || 1, isMobile: true, hasTouch: true });
  if (opts.clear !== false) await p.evaluateOnNewDocument(() => { try { if (location.protocol === "file:" && !sessionStorage.getItem("__kept")) { localStorage.removeItem("papaPotato.save.v1"); localStorage.removeItem("papaPotato.save.v2");localStorage.removeItem("papaPotato.save.v3"); sessionStorage.setItem("__kept", "1"); } } catch (e) {} });
  await p.goto(opts.url || GAME); await p.waitForFunction(() => window.__PP_READY === true, { timeout: 10000 }); await sleep(300);
  return { p, errs };
}
async function cdp(p) { return p.__cdp || (p.__cdp = await p.target().createCDPSession()); }
async function touchDrag(p, x0, y0, x1, y1, steps = 10, holdMs = 0) {
  const s = await cdp(p);
  await s.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: x0, y: y0 }] }); if (holdMs) await sleep(holdMs);
  for (let i = 1; i <= steps; i++) { await s.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: x0 + ((x1 - x0) * i) / steps, y: y0 + ((y1 - y0) * i) / steps }] }); await sleep(12); }
  await s.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] }); await sleep(120);
}
async function touchTapXY(p, x, y) { const s = await cdp(p); await s.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x, y }] }); await sleep(40); await s.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] }); await sleep(120); }
async function rect(p, sel) { return p.evaluate((s) => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; }, sel); }
async function touchTap(p, sel) { const r = await rect(p, sel); if (!r) throw new Error("no " + sel); await touchTapXY(p, r.cx, r.cy); }
function reporter() { const R = []; const ok = (n, v, d = "") => { R.push({ n, pass: !!v, d: typeof d === "string" ? d : JSON.stringify(d) }); console.log(v ? "PASS" : "FAIL", n, typeof d === "string" ? d : JSON.stringify(d)); }; return { R, ok }; }
module.exports = { puppeteer, fs, sleep, GAME, browser, open, cdp, touchDrag, touchTapXY, touchTap, rect, reporter };
