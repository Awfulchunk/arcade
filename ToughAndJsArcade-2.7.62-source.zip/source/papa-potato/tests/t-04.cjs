// Papa Potato 0.4 — four hard tests (mechanics, visuals/GUI, commands, arcade) + buff + perf.
// Headless Chrome, A03s-like 360x800 @ dpr 2. Not a physical-phone test.
const L = require("./lib.cjs");
const { ok, R } = L.reporter();
const OUT = process.argv[2] || "/workspace/game/build-potato04/out/t-04";
L.fs.mkdirSync(OUT, { recursive: true });
const URL = "file:///workspace/game/build-potato04/out/papa-potato-0.4.html";

(async () => {
  const b = await L.browser();
  const p = await b.newPage();
  const errs = [];
  p.on("pageerror", (e) => errs.push(String(e.message || e)));
  await p.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await p.evaluateOnNewDocument(() => {
    try {
      ["papaPotato.save.v1","papaPotato.save.v2","papaPotato.save.v3","papaPotato.save.v4"].forEach((k) => localStorage.removeItem(k));
    } catch (e) {}
  });
  await p.goto(URL, { waitUntil: "domcontentloaded" });
  await p.waitForFunction(() => window.__PP_READY === true, { timeout: 12000 });
  await L.sleep(200);

  const ev = (fn, ...a) => p.evaluate(fn, ...a);

  // ========== MECHANICS ==========
  const mech = await ev(() => {
    const S = PP.Sim, out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }

    // room size
    check("room-size", S.RW === 108 && S.RH === 280, S.RW + "x" + S.RH);

    // fresh v4
    const s = S.fresh(7);
    check("fresh-v4", s.s.v === 4 && s.s.level === 1, "v=" + s.s.v + " lv=" + s.s.level);

    // v3 migrate
    const v3 = { v: 3, seed: 1, rs: 0, rr: 1, t: 12, coins: 40, food: 2, hunger: 80, energy: 70,
      box: { pace: 2, eat: 30, nap: 25, clean: 0, pot: 6, style: 1, wake: 100, autob: 0 },
      potCap: 6, up: { peeler: 0, boots: 0, chute: 0, pantry: 0, broom: 0, mat: 0 },
      pile: 6, chute: 0, suck: null, peels: 0,
      stats: { peeled: 0, earned: 0, meals: 0, naps: 0, lazyNaps: 0, bought: 0, spent: 0, lazyTime: 0, eatTime: 0, napTime: 0, firstBuyT: -1, sucks: 0, swept: 0, sweeps: 0, peelsMade: 0, maxPeels: 0, cleanTime: 0, waitTime: 0, boughtPot: 0, boughtUp: 0, autoBuys: 0 },
      g: { x: 0.5, y: 0.2, dir: 2, hold: null, job: "pile", peel: 0, pgot: 0, sloppy: false, lazy: false, act: null, walkPh: 0 }, ev: [] };
    const m = S.load(JSON.stringify(v3));
    check("migrate-v3", m && m.s.v === 4 && m.s.coins === 40 && m.s.level === 1 && m.total() === S.POTS[6], "v=" + (m && m.s.v) + " tot=" + (m && m.total()));

    // level buy
    s.s.coins = 80;
    const br = s.buyLevel();
    check("buy-level-2", br === "ok" && s.s.level === 2, br + " lv=" + s.s.level);
    check("unlock-conveyor", s.unlocked("conveyor") && !s.owned("conveyor"), "unlocked not owned");
    s.s.coins = 70;
    check("buy-conveyor", s.buyItem("conveyor") === "ok" && s.owned("conveyor"), "owned");

    // locked item
    const locked = s.buyItem("autoPeeler");
    check("locked-lv3-item", locked === "locked", locked);

    // editor cannot move fixed
    check("no-move-pile", s.moveItem("pile", 40, 40) === false, "pile");
    check("no-move-ship", s.moveItem("ship", 40, 40) === false, "ship");
    check("no-move-ret", s.moveItem("ret", 40, 40) === false, "ret");
    const t0 = { x: (S.GEO.table.x0 + S.GEO.table.x1) / 2, y: (S.GEO.table.y0 + S.GEO.table.y1) / 2 };
    const moved = s.moveItem("table", t0.x + 4, t0.y + 4);
    check("move-table", moved === true, String(moved));

    // line conservation + shipping
    const L = S.fresh(3);
    L.s.level = 5; L.s.coins = 2000;
    ["conveyor", "suction", "autoPeeler", "outConveyor"].forEach((id) => { L.buyItem(id); });
    L.s.box.suction = 1; L.s.box.conveyor = 2; L.s.box.apeeler = 2; L.s.box.outbelt = 2;
    L.s.potCap = 8; L.s.box.pot = 8; L.retarget();
    const start = L.total();
    let minTot = start, maxTot = start, shipped0 = 0;
    for (let i = 0; i < 800; i++) {
      L.step(0.05);
      const tot = L.total();
      if (tot < minTot) minTot = tot;
      if (tot > maxTot) maxTot = tot;
    }
    const lt = L.lineTotals();
    check("line-conservation", minTot === start && maxTot === start, "start=" + start + " min=" + minTot + " max=" + maxTot);
    check("line-ships", lt.shipped > 0, "shipped=" + lt.shipped + " peels=" + L.s.peels);
    check("peels-from-line", L.s.peels > 0, "peels=" + L.s.peels);

    // commands: peeler off — in-flight out-belt potatoes may finish, then shipping freezes
    L.setBox("apeeler", 0);
    for (let i = 0; i < 200; i++) L.step(0.05);
    const shippedAt = L.s.line.shipped;
    for (let i = 0; i < 80; i++) L.step(0.05);
    check("cmd-peeler-off", L.s.line.shipped === shippedAt && L.total() === start, "shipped " + L.s.line.shipped + " vs " + shippedAt);

    L.setBox("apeeler", 2);
    L.setBox("outbelt", 0);
    for (let i = 0; i < 80; i++) L.step(0.05);
    const sh2 = L.s.line.shipped;
    for (let i = 0; i < 80; i++) L.step(0.05);
    check("cmd-outbelt-off", L.s.line.shipped === sh2 && L.total() === start, "held");

    L.setBox("outbelt", 2);
    L.setBox("suction", 0);
    const pileAt = L.s.pile;
    for (let i = 0; i < 80; i++) L.step(0.05);
    check("cmd-suction-off", L.s.pile >= pileAt && L.total() === start, "pile " + pileAt + "->" + L.s.pile);

    // plant dries, water command
    const D = S.fresh(9);
    D.s.level = 2; D.s.coins = 200; D.buyItem("plant");
    D.s.decor.plant = 80; D.setBox("water", 40);
    D.decide();
    let watered = false;
    for (let i = 0; i < 400; i++) { D.step(0.05); if (D.s.g.act && (D.s.g.act.t === "water" || (D.s.g.act.t === "walk" && D.s.g.act.then === "water"))) watered = true; }
    check("water-job", watered || D.s.decor.plant < 80, "plant=" + D.s.decor.plant + " watered=" + watered);

    // carry bag grabs several at once
    const B = S.fresh(5);
    B.s.coins = 80;
    check("buy-carry-bag", B.buyItem("carryBag") === "ok" && B.carryCap() === 2, "cap=" + B.carryCap());
    const pile0 = B.s.pile, tot0 = B.total();
    B.s.g.hold = null; B.s.g.held = 0; B.s.g.act = { t: "grab", e: 0, label: "grabbing potatoes" };
    for (let i = 0; i < 20; i++) B.step(0.1);
    check("carry-grabs-cap", B.heldN() === 2 && B.s.g.hold === "raw" && B.s.pile === pile0 - 2 && B.total() === tot0,
      "held=" + B.heldN() + " pile " + pile0 + "->" + B.s.pile + " tot " + B.total() + "/" + tot0);
    B.s.coins = 80; B.buyUp("bag");
    check("carry-cap-upgrade", B.carryCap() === 3, "cap=" + B.carryCap());
    B.s.pile = Math.max(B.s.pile, 6); B.s.g.hold = null; B.s.g.held = 0;
    B.s.g.act = { t: "grab", e: 0, label: "grabbing potatoes" };
    const tot1 = B.total(), pile1 = B.s.pile;
    for (let i = 0; i < 20; i++) B.step(0.1);
    check("carry-grabs-upgraded", B.heldN() === 3 && B.s.pile === pile1 - 3 && B.total() === tot1,
      "held=" + B.heldN() + " pile " + pile1 + "->" + B.s.pile);
    // drop the bag one-by-one, conservation holds
    B.s.g.hold = "peeled"; B.s.g.held = 3; B.s.g.job = "chute";
    B.s.g.act = { t: "drop", e: 0, label: "shipping them" };
    const tot2 = B.total();
    for (let i = 0; i < 40; i++) B.step(0.1);
    check("carry-drop-all", B.heldN() === 0 && B.s.g.hold === null && B.total() === tot2,
      "held=" + B.heldN() + " tot " + B.total() + "/" + tot2);

    // watching TV walks to the sit spot in the armchair
    const W = S.fresh(6);
    W.s.level = 4; W.s.coins = 200; W.buyItem("tvArmchair");
    W.s.box.tv = 1; W.s.box.watch = 40; W.s.box.eat = 0; W.s.box.nap = 0; W.s.box.clean = 0;
    W.s.energy = 30; W.s.hunger = 100; W.s.g.hold = null; W.s.g.held = 0; W.s.g.lazy = false;
    W.rebuildObst(); W.decide();
    let sat = false, sit = W.sitSpot();
    for (let i = 0; i < 2000; i++) {
      W.step(0.05);
      if (W.s.g.act && W.s.g.act.t === "watch") {
        const dx = Math.abs(W.s.g.x * S.RW - sit.x), dy = Math.abs(W.s.g.y * S.RH - sit.y);
        sat = dx < 0.6 && dy < 0.6 && W.s.g.dir === 1;
        break;
      }
    }
    const act = W.s.g.act || {};
    check("watch-sits-in-chair", sat, "act=" + act.t + (act.then ? "->" + act.then : "") + " dir=" + W.s.g.dir + " xy=" + W.s.g.x.toFixed(3) + "," + W.s.g.y.toFixed(3));

    // serialize v4 and reload
    const raw = L.serialize();
    const L2 = S.load(raw);
    check("save-roundtrip", L2 && L2.s.v === 4 && L2.s.level === 5 && L2.owned("autoPeeler"), "v=" + (L2 && L2.s.v));

    out.errs = 0;
    return out;
  });
  mech.checks.forEach((c) => ok("mech:" + c.n, c.pass, c.d));

  // ========== COMMANDS (panel + help + shop UI) ==========
  const cmd = await ev(() => {
    const out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }
    PP.reset(4);
    const boxes = Array.from(document.querySelectorAll("#boxes .box")).map((e) => e.getAttribute("data-id"));
    check("starter-panel-hides-line", boxes.indexOf("suction") < 0 && boxes.indexOf("pace") >= 0, boxes.join(","));
    PP.giveAll();
    const boxes2 = Array.from(document.querySelectorAll("#boxes .box")).map((e) => e.getAttribute("data-id"));
    check("panel-shows-line-after-buy", boxes2.indexOf("suction") >= 0 && boxes2.indexOf("apeeler") >= 0 && boxes2.indexOf("outbelt") >= 0, boxes2.join(","));
    check("set-suction", PP.sim.setBox("suction", 1) === false || PP.sim.s.box.suction === 1, "suction=" + PP.sim.s.box.suction);
    PP.sim.setBox("conveyor", 2);
    check("fmt-speed", true, "conveyor=" + PP.sim.s.box.conveyor);
    const bookN = PP.book().pages;
    check("help-pages", bookN >= PP.Sim.COMMANDS.length + 6, "pages=" + bookN);
    return out;
  });
  cmd.checks.forEach((c) => ok("cmd:" + c.n, c.pass, c.d));

  // shop buy via API
  const shop = await ev(() => {
    PP.reset(5);
    PP.sim.s.coins = 200;
    const r1 = PP.buy("lv");
    const r2 = PP.sim.s.level === 2;
    PP.sim.s.coins = 200;
    const r3 = PP.buy("item:conveyor");
    return { r1, r2, r3, level: PP.sim.s.level, owned: !!PP.sim.owned("conveyor") };
  });
  ok("cmd:shop-level", shop.r1 === "ok" && shop.r2, JSON.stringify(shop));
  ok("cmd:shop-item", shop.r3 === "ok" && shop.owned, JSON.stringify(shop));

  // help open
  await ev(() => PP.open("help"));
  const helpOn = await ev(() => PP.ovl() === "help" && !!document.getElementById("pg"));
  ok("cmd:help-opens", helpOn, "ovl");
  await ev(() => PP.close());

  // ========== VISUALS / GUI ==========
  await ev(() => { PP.reset(2); PP.giveAll(); PP.pause(true); });
  await ev((t) => PP.drawAt(t), 2000);
  const gui = await ev(() => {
    const out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }
    const cv = PP.cv();
    check("canvas-size", cv.width > 100 && cv.height > 100, cv.width + "x" + cv.height);
    const ctx = cv.getContext("2d");
    check("smoothing-off", ctx.imageSmoothingEnabled === false, String(ctx.imageSmoothingEnabled));
    const lay = PP.layout();
    check("dpr", lay.dpr >= 1, "dpr=" + lay.dpr);
    check("room-in-layout", lay.roomW === 108 && lay.roomH === 280, lay.roomW + "x" + lay.roomH);
    // zoom
    const z0 = PP.zoom();
    PP.setZoom(3);
    const z1 = PP.zoom();
    check("zoom-in", z1.k > z0.k, z0.k + " -> " + z1.k);
    PP.setZoom(1);
    check("zoom-fit", PP.zoom().k === 1, String(PP.zoom().k));
    // pixels not empty
    const img = ctx.getImageData(0, 0, cv.width, Math.min(cv.height, 400));
    let filled = 0;
    for (let i = 3; i < img.data.length; i += 16) if (img.data[i] > 0) filled++;
    check("pixels", filled > 100, "samples=" + filled);
    const brand = document.querySelector("#hud .brand span");
    check("hud-v04", brand && /v0\.4/.test(brand.textContent), brand && brand.textContent);
    check("zoom-rail", !!document.getElementById("zoomRail") && !!document.getElementById("panPad") && !!document.getElementById("editBtn"), "ui");
    check("level-hud", /1|5/.test(document.getElementById("level").textContent), document.getElementById("level").textContent);
    return out;
  });
  gui.checks.forEach((c) => ok("gui:" + c.n, c.pass, c.d));

  // overlap of shipping vs out belt via GEOMETRY (same numbers as the sprite test)
  const ov = await ev(() => {
    const G = PP.Sim.GEO;
    const shipY1 = G.ship.lip + 6.5;
    const vY0 = G.shipBeltY0, vY1 = G.shipBeltY1;
    const butt = Math.abs(vY0 - shipY1) <= 0.2;
    const over = vY0 < shipY1 - 0.2;
    return { butt, over, vY0, shipY1, vY1 };
  });
  ok("gui:belt-butts-shipping", ov.butt && !ov.over, JSON.stringify(ov));

  // launch hint + labels must never overlap zoom/pan/editor chrome
  const chrome = await ev(() => {
    PP.reset(2);
    PP.pause(true);
    const hint = document.getElementById("hint");
    hint.textContent = "Tap a box to unlock its slider. Set EAT and NAP or he goes lazy. HELP explains every box.";
    hint.className = "";
    PP.labels(20000, true);
    PP.placeTags();
    function box(el) { const r = el.getBoundingClientRect(); return { l: r.left, t: r.top, r: r.right, b: r.bottom, id: el.id, text: (el.textContent || "").slice(0, 24) }; }
    function hit(a, b, p) { return a.l < b.r + p && a.r > b.l - p && a.t < b.b + p && a.b > b.t - p; }
    const chromeEls = ["zoomRail", "panPad", "editBtn"].map((id) => box(document.getElementById(id)));
    const tags = [...document.querySelectorAll(".tag")].filter((e) => e.className.indexOf("off") < 0).map(box);
    const hintBox = box(hint);
    const hits = [];
    function against(el) {
      chromeEls.forEach((c) => { if (hit(el, c, 1)) hits.push(el.id + "/" + el.text + " overlaps " + c.id); });
    }
    tags.forEach(against);
    if (hint.className.indexOf("off") < 0) against(hintBox);
    return { hits, nTags: tags.length, hintOn: hint.className.indexOf("off") < 0 };
  });
  ok("gui:no-chrome-overlap", chrome.hits.length === 0, JSON.stringify(chrome));

  async function railsCheck(label) {
    const r = await ev(() => {
      window.dispatchEvent(new Event("resize"));
      function box(el) { const r = el.getBoundingClientRect(); return { l: r.left, t: r.top, r: r.right, b: r.bottom, w: r.width, h: r.height, id: el.id || el.getAttribute("data-act") || el.tagName }; }
      function hit(a, b, p) { p = p || 0; return a.l < b.r - p && a.r > b.l + p && a.t < b.b - p && a.b > b.t + p; }
      const play = box(document.getElementById("play"));
      const cv = box(document.getElementById("cv"));
      const left = box(document.getElementById("leftRail"));
      const right = box(document.getElementById("rightRail"));
      const hud = box(document.getElementById("hud"));
      const cmd = box(document.getElementById("cmd"));
      const controls = [...document.querySelectorAll("#leftRail, #rightRail, #leftRail button, #rightRail button, #zoomRail, #panPad, #editBtn")].map(box);
      const hits = controls.filter((c) => hit(c, play, 0.5)).map((c) => c.id + " overlaps play");
      const sizes = [...document.querySelectorAll("#leftRail button, #rightRail button")].map((el) => { const b = box(el); return { id: b.id, w: +b.w.toFixed(1), h: +b.h.toFixed(1) }; });
      const small = sizes.filter((b) => b.w < 36 || b.h < 36);
      return {
        hits,
        leftOfPlay: left.r <= play.l + 1,
        rightOfPlay: right.l >= play.r - 1,
        playInGutters: left.r <= play.l + 1 && right.l >= play.r - 1 && play.l >= left.l && play.r <= right.r + 1,
        small,
        sizes,
        play: { w: +play.w.toFixed(1), h: +play.h.toFixed(1), l: +play.l.toFixed(1), r: +play.r.toFixed(1) },
        cv: { w: +cv.w.toFixed(1), h: +cv.h.toFixed(1) },
        vw: window.innerWidth,
        vh: window.innerHeight
      };
    });
    ok("gui:rails-outside-room@" + label, r.hits.length === 0 && r.playInGutters && r.leftOfPlay && r.rightOfPlay && r.small.length === 0 && r.play.w > 80 && r.play.h > 80, JSON.stringify(r));
    return r;
  }
  await railsCheck("360x800");
  await p.setViewport({ width: 320, height: 568, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await L.sleep(80);
  await ev(() => { window.dispatchEvent(new Event("resize")); PP.placeTags(); });
  await L.sleep(40);
  await railsCheck("320x568");
  await p.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await ev(() => { window.dispatchEvent(new Event("resize")); });
  await L.sleep(40);

  // sit pose: Papa is in the armchair (not on the TV), locked 0.3.1 hair/shirt colors present
  const sitVis = await ev(() => {
    PP.reset(2); PP.giveAll(); PP.pause(true);
    const s = PP.sim, sit = s.sitSpot(), tv = s.placeOf("tvArmchair");
    s.s.box.tv = 1; s.startAt("watch");
    PP.setZoom(3);
    const lay = PP.layout();
    PP.setPan(sit.x - PP.Sim.RW / 2, sit.y - PP.Sim.RH / 2);
    PP.drawAt(2400);
    const cv = PP.cv(), ctx = cv.getContext("2d"), dpr = lay.dpr, k = PP.layout().k;
    const offX = PP.layout().offX, offY = PP.layout().offY;
    function sample(wx, wy) {
      const x = Math.round((wx * k + offX) * dpr), y = Math.round((wy * k + offY) * dpr);
      if (x < 0 || y < 0 || x >= cv.width || y >= cv.height) return null;
      const d = ctx.getImageData(x, y, 1, 1).data;
      return [d[0], d[1], d[2], d[3]];
    }
    function near(px, rgb, tol) {
      if (!px || px[3] < 10) return false;
      return Math.abs(px[0] - rgb[0]) <= tol && Math.abs(px[1] - rgb[1]) <= tol && Math.abs(px[2] - rgb[2]) <= tol;
    }
    // sample a small patch around the sit point (head is slightly east of the sit origin)
    let hair = 0, shirt = 0, skin = 0;
    for (let dx = -6; dx <= 8; dx += 2) for (let dy = -6; dy <= 6; dy += 2) {
      const px = sample(sit.x + dx, sit.y + dy);
      if (near(px, [42, 32, 24], 28) || near(px, [58, 42, 32], 28) || near(px, [26, 20, 16], 24)) hair++;
      if (near(px, [58, 106, 138], 40) || near(px, [42, 74, 98], 40) || near(px, [90, 136, 168], 40) || near(px, [122, 168, 192], 40) || near(px, [42, 74, 98], 36) || near(px, [26, 48, 66], 28)) shirt++;
      if (near(px, [196, 160, 112], 36) || near(px, [216, 184, 136], 36)) skin++;
    }
    // the TV set center should not have a standing body (shoulders south of a north-facing head)
    return { hair, shirt, skin, sit, tv, dir: s.s.g.dir, act: s.s.g.act && s.s.g.act.t };
  });
  ok("gui:watch-sit-pose", sitVis.act === "watch" && sitVis.dir === 1 && sitVis.hair >= 2 && (sitVis.shirt >= 1 || sitVis.skin >= 8),
    JSON.stringify(sitVis));

  // carry bag: several potatoes rendered on him
  const bagVis = await ev(() => {
    PP.reset(2); PP.giveAll(); PP.pause(true);
    const s = PP.sim;
    s.s.g.hold = "raw"; s.s.g.held = s.carryCap(); s.s.g.act = { t: "idle", e: 0, d: 2, label: "carrying" };
    s.s.g.x = 0.36; s.s.g.y = 0.82; s.s.g.dir = 0;
    PP.setZoom(3);
    PP.setPan(s.s.g.x * PP.Sim.RW - PP.Sim.RW / 2, s.s.g.y * PP.Sim.RH - PP.Sim.RH / 2);
    PP.drawAt(1800);
    return { held: s.heldN(), cap: s.carryCap(), hold: s.s.g.hold };
  });
  ok("gui:carry-bag-held", bagVis.held >= 2 && bagVis.held === bagVis.cap && bagVis.hold === "raw", JSON.stringify(bagVis));

  // ========== ARCADE (loop still plays, labels, states) ==========
  await ev(() => { PP.reset(8); PP.giveAll(); PP.pause(false); });
  await ev(() => { const s = PP.sim; s.setBox("eat", 40); s.setBox("nap", 35); s.s.food = 6; });
  // fast-forward 30s of sim
  const arcade = await ev(() => {
    const s = PP.sim;
    const startT = s.s.t, startC = s.s.coins, startP = s.total();
    for (let i = 0; i < 600; i++) s.step(0.05);
    const jobs = {};
    // sample last act isn't required; just that time passed, coins maybe rose, conservation held
    return {
      dt: s.s.t - startT,
      coins: s.s.coins,
      startC,
      tot: s.total(),
      startP,
      shipped: s.s.line && s.s.line.shipped,
      peels: s.s.peels,
      state: s.stateName(),
      version: PP.version
    };
  });
  ok("arcade:version", arcade.version === "0.4", arcade.version);
  ok("arcade:time-advances", arcade.dt >= 29, "dt=" + arcade.dt);
  ok("arcade:conserved", arcade.tot === arcade.startP, arcade.tot + "/" + arcade.startP);
  ok("arcade:line-or-loop-earns", arcade.coins >= arcade.startC, "coins " + arcade.startC + "->" + arcade.coins);
  ok("arcade:peels-inside-budget", arcade.peels >= 0 && arcade.peels < 200, "peels=" + arcade.peels);

  // ========== BUFF / STRESS ==========
  const buff = await ev(() => {
    const s = PP.Sim.fresh(11);
    s.s.level = 5; s.s.coins = 5000;
    PP.Sim.ITEMS.forEach((it) => { if (!s.owned(it.id)) { s.s.owned[it.id] = 1; s.s.place[it.id] = PP.Sim.defaultPlace(it.id); } });
    s.s.box.suction = 1; s.s.box.conveyor = 3; s.s.box.apeeler = 3; s.s.box.outbelt = 3;
    s.s.box.eat = 40; s.s.box.nap = 30; s.s.box.clean = 40; s.s.food = 12; s.s.potCap = 17; s.s.box.pot = 17; s.retarget();
    const start = s.total();
    let minT = start, maxT = start, steps = 0;
    const t0 = (typeof performance !== "undefined") ? performance.now() : Date.now();
    for (let i = 0; i < 72000; i++) { s.step(0.05); steps++; const t = s.total(); if (t < minT) minT = t; if (t > maxT) maxT = t; }
    const ms = ((typeof performance !== "undefined") ? performance.now() : Date.now()) - t0;
    return { hours: s.s.t / 3600, start, minT, maxT, shipped: s.s.line.shipped, peels: s.s.peels, coins: s.s.coins, ms, steps };
  });
  ok("buff:conservation-1h", buff.minT === buff.start && buff.maxT === buff.start, JSON.stringify({ start: buff.start, minT: buff.minT, maxT: buff.maxT, hours: buff.hours.toFixed(2) }));
  ok("buff:ran", buff.hours >= 0.99, "hours=" + buff.hours.toFixed(2) + " shipped=" + buff.shipped);

  // ========== PERF (rAF, A03s budget) ==========
  await ev(() => { PP.reset(1); PP.giveAll(); });
  const perf = await ev(() => new Promise((resolve) => {
    const budget = 1000 / 60, warmup = 15, n = 90;
    const times = [];
    let i = 0;
    function tick(ts) {
      const t0 = performance.now();
      PP.drawAt(ts);
      const dt = performance.now() - t0;
      if (i >= warmup) times.push(dt);
      i++;
      if (i < warmup + n) requestAnimationFrame(tick);
      else {
        times.sort((a, b) => a - b);
        const sum = times.reduce((a, b) => a + b, 0);
        let over = 0;
        for (let k = 0; k < times.length; k++) if (times[k] > budget) over++;
        resolve({ n: times.length, avg: sum / times.length, p50: times[Math.floor(times.length * 0.5)], p95: times[Math.min(times.length - 1, Math.floor(times.length * 0.95))], max: times[times.length - 1], over, budget });
      }
    }
    requestAnimationFrame(tick);
  }));
  ok("perf:avg-under-budget", perf.avg < perf.budget, JSON.stringify(perf));
  ok("perf:p95-under-budget", perf.p95 < perf.budget, "p95=" + perf.p95.toFixed(2));
  ok("perf:no-over", perf.over === 0, "over=" + perf.over + "/" + perf.n);

  ok("boot:no-page-errors", errs.length === 0, errs.join(" | "));

  const fail = R.filter((r) => !r.pass);
  const summary = { total: R.length, pass: R.length - fail.length, fail: fail.length, fails: fail, perf, buff, errs };
  L.fs.writeFileSync(OUT + "/results.json", JSON.stringify(summary, null, 2));
  L.fs.writeFileSync(OUT + "/results.txt", R.map((r) => (r.pass ? "PASS" : "FAIL") + "  " + r.n + "  " + r.d).join("\n") + "\n\n" + (fail.length ? "FAILURES: " + fail.length : "ALL GREEN " + R.length + "/" + R.length) + "\n");
  console.log(fail.length ? ("FAILURES " + fail.length + "/" + R.length) : ("ALL GREEN " + R.length + "/" + R.length));
  await b.close();
  process.exit(fail.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
