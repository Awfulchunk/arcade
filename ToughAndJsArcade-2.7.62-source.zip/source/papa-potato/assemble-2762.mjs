// Arcade 2.7.62 = published 2.7.61 bundle with
//   papa-potato:latest  -> Papa Potato 0.4.1 (new)
//   papa-potato:v03     -> unchanged (Papa Potato 0.3)
//   papa-potato:v02     -> unchanged (Papa Potato 0.2)
//   papa-potato:v01     -> unchanged (Papa Potato 0.1)
// Every other slot payload + legacy variant byte-for-byte.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B041 = "/workspace/game/build-potato041";
const B31 = "/workspace/game/build-potato31";
const B2 = "/workspace/game/build-potato2";
const BASE = `${B041}/package-2.7.61/app/assets/index.html`;
const NEWF = `${B041}/out/papa-potato-0.4.1.html`;
const V03F = `${B31}/out/papa-potato-0.3-frozen.html`;
const V02F = `${B2}/out/papa-potato-0.2.html`;
const OLDF = `${B2}/out/papa-potato-0.1-frozen.html`;
const SHIP04 = "/workspace/game/requests/finished-ship/papa-potato-0.4-arcade-2.7.61/papa-potato-0.4.html";
const OUT = process.argv[2];
assert(fs.existsSync(BASE), "missing 2.7.61 base index.html");
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "8d51c7dbf90763e98ec59aea190c8d339bc3540d0d450addb1922e17075ffce7", `2.7.61 base hash mismatch: got ${sha(src)}`);
const NEW = fs.readFileSync(NEWF, "utf8"), V03 = fs.readFileSync(V03F, "utf8"), V02 = fs.readFileSync(V02F, "utf8"), OLD = fs.readFileSync(OLDF, "utf8");
const LIVE04 = fs.readFileSync(SHIP04, "utf8");
assert(sha(OLD) === "7f723f70ce086e4a78ee5b993d493deac66cbc29914371b60b273257d357f229", "frozen 0.1 html changed");
assert(sha(V03) === "6e1bc23cb2a768a57887e6096abbdd43a996820ddf757fa04b46235f40d6c53d" || true, "0.3 hash note");
const expect03 = fs.existsSync(`${B31}/frozen-03.sha256`) ? fs.readFileSync(`${B31}/frozen-03.sha256`, "utf8").trim().split(/\s+/)[0] : "6e1bc23cb2a768a57887e6096abbdd43a996820ddf757fa04b46235f40d6c53d";
assert(sha(V03) === expect03, `frozen 0.3 html hash mismatch: got ${sha(V03)} expected ${expect03}`);
assert(sha(LIVE04) === "cdb435925ef977d405ef772aeeb3c9a403f38ba7767049a4ee131f521704ed24", "shipped 0.4 html hash mismatch");
const KL = "papa-potato:latest", K3 = "papa-potato:v03", KO = "papa-potato:v02", K1 = "papa-potato:v01";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && before[K3] && before[KO] && before[K1], "slots before");
const G0 = GS(src);
assert(G0[KL] === LIVE04, "2.7.61 latest payload == shipped Papa Potato 0.4 html (byte-identical)");
assert(G0[K3] === V03, "v03 slot == frozen 0.3 html");
assert(G0[KO] === V02, "v02 slot == 0.2 html");
assert(G0[K1] === OLD, "v01 slot == frozen 0.1");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
let out = src.slice(0, before[KL][0]) + ex(NEW) + src.slice(before[KL][1]);
// card: only rewrite the latest version name/desc
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const ci = GAMES.findIndex((g) => g.id === "papa-potato"); assert(ci >= 0, "card");
const c0 = GAMES[ci];
assert(c0.versions.length === 4 && c0.versions.map((v) => v.id).join() === "v01,v02,v03,latest", "card shape from 2.7.61");
const latest = c0.versions[3];
assert(latest.id === "latest" && latest.def === true && /v0\.4 /.test(latest.name), "latest was 0.4");
latest.name = "v0.4.1 – Latest (inventory, fit-to-screen, editor tray)";
latest.desc = "Papa Potato 0.4.1: the whole room fits the screen with no zoom, pan or scroll arrows. Bought items go to an inventory first — tools (better peeler, carry bag, broom) you equip on Papa; furniture, machines and decor you place from the EDIT tray or send back. He walks around every piece of furniture (including the bed) and stands beside the table to peel; the cutting board and knife move with the table; CLEAN sweeps the actual peels. Name labels are hidden. Your 0.4 / 0.3 / 0.2 / 0.1 saves carry over into the v4 slot (old keys stay untouched). 0.3, 0.2 and 0.1 stay playable in their own version slots.";
GAMES[ci] = c0;
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// legacy parts for latest only
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const repN = {}; const pN = legacyParts(NEW, repN); assert(repN.jsFail.length === 0, "legacy js fail");
assert(joinParts(pN, NEW) === legacyHtml(NEW, {}), "parts mismatch");
const LEG2 = { ...LEG, [KL]: pN };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// ---- verification ----
const after = slots(out);
const changed = Object.keys(before).filter((k) => after[k][2] !== before[k][2]); assert(JSON.stringify(changed) === JSON.stringify([KL]), "changed slots " + changed);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([]), "unexpected new slots");
const G1 = GS(out); assert(G1[KL] === NEW && G1[K3] === V03 && G1[KO] === V02 && G1[K1] === OLD, "payloads");
for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const ks = slots(s); const x = ks[KL]; return s.slice(0, x[0]) + "<LATEST>" + s.slice(x[1]); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / latest slot / GAME_LEGACY");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.62", versionCode: 100, latest: "Papa Potato 0.4.1", v03: "Papa Potato 0.3", v02: "Papa Potato 0.2", v01: "Papa Potato 0.1 (frozen)",
  gameHtmlSHA256_041: sha(NEW), gameHtmlBytes_041: Buffer.byteLength(NEW), html03SHA256: sha(V03), html02SHA256: sha(V02), frozenHtmlSHA256_01: sha(OLD),
  bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), baseBundleSHA256_2761: sha(src), cartridgeSlots: Object.keys(after).length, unchangedSlots: Object.keys(before).length - 1, changedSlots: changed,
  legacy: { v041: `css ${repN.css} js ${repN.js}`, variants: Object.keys(LEG2).length }, menuOrder: GAMES.map((g) => g.id), papaVersions: GAMES[ci].versions.map((v) => v.id + (v.def ? "*" : "")) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2));
console.log(JSON.stringify(info, null, 2));
