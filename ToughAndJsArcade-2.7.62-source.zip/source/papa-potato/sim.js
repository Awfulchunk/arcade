/* ===== Papa Potato 0.4.1 — simulation (no DOM; runs headless for tests). Built on 0.4 + inventory, solid furniture, peel clusters, table children. Save v4. ===== */
var PPSim=(function(){
  var RW=108,RH=280;                    /* 0.4: longer and slightly wider. x,y in the save are fractions of this */
  var PACE=["CHILL","EASY","STEADY","BRISK","GRIND"];
  var SPD=[0.6,0.8,1.0,1.25,1.5];      /* work + walk speed */
  var DRN=[0.55,0.75,1.0,1.45,2.0];    /* hunger + energy drain */
  var STYLE=[{n:"NEAT",sp:0.8,peels:2},{n:"NORMAL",sp:1.0,peels:3},{n:"QUICK",sp:1.3,peels:5}];
  var C={
    walk:34,            /* room units / s (0.2: 18 in a 150-tall room; 0.3's room is taller so he walks faster) */
    grab:0.7, peel:6.0, drop:0.5, eat:3.0,
    meal:55, foodPrice:8, foodMax:9,
    hungerDrain:0.30, hungerDrainNap:0.10,
    energyDrain:0.42,
    napRegen:6.0, lazyNapRegen:4.0, napWake:98,
    value:2, sloppyValue:1,
    lazyLow:25, lazySpeed:0.5,
    startCoins:0, startFood:1,
    chuteCap:6, tPipe:1.6,              /* a full chute's batch spends tPipe in the pipe, then spills out of the return chute */
    peelPer:3, peelPerSloppy:5, peelMax:200, messFull:90, messMax:0.30,
    sweepRate:6, sweepWind:0.8, sweepTidy:0.10,
    priceGrow:1.05, priceCap:14, priceEvery:900,
    potBase:6, potLegacy:9, potPrice0:15, potPriceGrow:1.4
  };
  var POTS=[4,8,12,16,24,32,48,64,96,128,160,200,250,300,400,500,650,800];
  var POT_MAX=POTS.length-1;
  /* ---- room geometry (units; room = 100 wide x 240 tall). The renderer draws from these; the router avoids OBST. ---- */
  var GEO={WALL:7,INFL:9,
    ship:{x:54,lip:22,top:2,mouth:18},                 /* FIXED: shipping chute hangs from the top wall */
    /* 0.4.1 default layout: work loop uses the mid-room so a fitted view is not a long empty hallway */
    table:{x0:36,y0:112,x1:70,y1:130},
    cooler:{x0:80,y0:108,x1:94,y1:118},
    stool:{x:87,y:130},
    mat:{x:74,y:200,w:32,h:18},
    pile:{cx:54,base:258,rx:45,rz:14},                 /* FIXED */
    ret:{wallX:101,mouthX:86,y:244,w:9},               /* FIXED: return chute */
    mess:{cx:53,cy:146,rx:22,rz:14},
    peeler:{x:22,y:52},
    beltX:22,beltY0:66,beltY1:246,
    outBeltY:52,outBeltX0:31,outBeltX1:59.4,
    shipBeltX:54,shipBeltY0:28.5,shipBeltY1:36.6,
    suction:{x:22,y:255},
    spill:{x:34,y:68},
    sink:{x:26,y:150},
    broom:{x:96,y:150},
    bag:{x:40,y:248},
    cot:{x:74,y:222},
    rug:{x:68,y:168},
    tv:{x:68,y:164},
    lamp:{x:96,y:154},
    radio:{x:96,y:142},
    plant:{x:50,y:170},
    betterPeeler:{x:60,y:121},
    smallCooler:{x:92,y:90}};
  var GEO0=JSON.parse(JSON.stringify(GEO));
  var FIXED=["pile","ret","ship"]; /* editor must never move these */
  var TOOLS=["betterPeeler","carryBag","broomDustpan"];
  var PLACEABLES=["sink","smallCooler","basicCot","conveyor","suction","plant","lamp","autoPeeler","outConveyor","radio","rug","tvArmchair"];
  var STARTER=["table","cooler","stool","mat"];
  function isTool(id){return TOOLS.indexOf(id)>=0;}
  function isPlaceable(id){return PLACEABLES.indexOf(id)>=0;}
  function tableKids(){
    var T=GEO.table,cx=(T.x0+T.x1)/2,cy=(T.y0+T.y1)/2,tw=T.x1-T.x0,th=T.y1-T.y0;
    var bw=Math.min(18,tw-12),bh=Math.min(11,th-6);
    var board={x0:T.x0+4,y0:T.y0+3.5,x1:T.x0+4+bw,y1:T.y0+3.5+bh};
    return {
      cx:cx,cy:cy,
      board:board,
      knife:{x:board.x1+3,y:cy,ok:board.x1+6<T.x1-1},
      peelSpawn:{x:cx,y:T.y1+2},
      stand:{x:cx,y:T.y1+12,dir:0}
    };
  }
  function bedside(){
    var m=GEO.mat;return {x:m.x,y:m.y+m.h/2+GEO.INFL+3,dir:0};
  }
  var OBST=[{id:"table",x0:GEO.table.x0,y0:GEO.table.y0,x1:GEO.table.x1,y1:GEO.table.y1},{id:"cooler",x0:GEO.cooler.x0,y0:GEO.cooler.y0,x1:GEO.cooler.x1,y1:GEO.cooler.y1}];
  var SPOT={
    ship:{x:60,y:40,dir:3},
    table:{x:53,y:142,dir:0},
    food:{x:87,y:130,dir:0},
    mat:{x:74,y:221,dir:0},
    sweep:{x:53,y:146,dir:0},
    pile:{y:233,x0:28,x1:80},
    sink:{x:26,y:162,dir:0},
    tv:{x:60,y:176,dir:1},
    radio:{x:88,y:142,dir:1},
    plant:{x:50,y:182,dir:0},
    lamp:{x:88,y:154,dir:1},
    cot:{x:74,y:234,dir:0},
    bag:{x:40,y:242,dir:2}};
  var SPOT0=JSON.parse(JSON.stringify(SPOT));
  function copyBox(a,b){var k;for(k in b){if(b[k]&&typeof b[k]==="object"){if(!a[k])a[k]={};copyBox(a[k],b[k]);}else a[k]=b[k];}}
  /* ---- the command table: ONE source for the panel, the sim's BOX limits and the HELP screen ---- */
  var COMMANDS=[
    {id:"pace",does:"How fast he walks and works.",affects:"Speed x0.6 up to x1.5. Faster drains hunger and energy faster (x0.55 up to x2.0).",hi:"GRIND",lo:"CHILL",name:"WORK PACE",min:0,max:4,step:1,def:2,
      what:"How fast he walks and works.",
      effect:"Faster pace = more potatoes per minute, but hunger and energy drain faster. CHILL x0.6 speed (0.55 drain) up to GRIND x1.5 speed (2.0 drain).",
      range:"5 steps: CHILL, EASY, STEADY, BRISK, GRIND"},
    {id:"eat",does:"Sends him to eat when he gets hungry.",affects:"Hunger under the number = go eat (1 food = +55 hunger). OFF = never.",hi:"70%",lo:"OFF",name:"EAT WHEN HUNGER <",min:0,max:70,step:5,def:0,
      what:"Sends him to the cooler to eat when his hunger drops below the number.",
      effect:"Higher = he eats sooner and never gets hungry. Eating takes 3 s and uses 1 food (+55 hunger). OFF = he never eats on his own and goes lazy at 25%.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"nap",does:"Sends him to bed when he gets tired.",affects:"Energy under the number = go nap. OFF = he dozes on the floor instead.",hi:"70%",lo:"OFF",name:"NAP WHEN ENERGY <",min:0,max:70,step:5,def:0,
      what:"Sends him to the bed to nap when his energy drops below the number.",
      effect:"Higher = he naps sooner. OFF = he never goes to bed and dozes on the floor when he gets too tired. Pair it with NAP UNTIL.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"clean",does:"Sends him to sweep up peels.",affects:"Peels over the number = sweep. Lower = tidier floor but more sweeping.",hi:"90",lo:"OFF",name:"CLEAN WHEN PEELS >",min:0,max:90,step:5,def:0,
      what:"Sends him to sweep when the peel count on the floor goes over the number.",
      effect:"Lower = he sweeps earlier and keeps the floor clean, but spends more time sweeping. He sweeps until the floor is nearly clear (under 10% of the trigger). OFF = never. Peels slow him up to 30% at 90 peels.",
      range:"OFF, 5 to 90 peels (step 5)"},
    {id:"pot",does:"How many potatoes are in the loop.",affects:"More = bigger pile, no waiting. The top of the slider is what you own (buy more in the SHOP).",hi:"OWNED",lo:"4",name:"POTATOES IN PLAY",min:0,max:POT_MAX,step:1,def:6,dyn:"potCap",
      what:"How many potatoes are in the loop (pile + hands + chute + pipe).",
      effect:"More potatoes = a bigger pile and he never waits for the pipe. Fewer = a small pile. The top of the slider is what you own: buy more in the SHOP.",
      range:"4 up to the amount you own (4, 8, 12 ... 800)"},
    {id:"style",does:"How carefully he peels.",affects:"NEAT: slow, 2 peels. NORMAL: 3 peels. QUICK: fast, 5 peels (messy).",hi:"QUICK",lo:"NEAT",name:"PEEL STYLE",min:0,max:2,step:1,def:1,
      what:"How carefully he peels.",
      effect:"NEAT x0.8 speed, 2 peels per potato (clean floor). NORMAL x1.0, 3 peels. QUICK x1.3 speed, 5 peels per potato (fast but very messy).",
      range:"3 steps: NEAT, NORMAL, QUICK"},
    {id:"wake",does:"How rested he is when he gets up.",affects:"Lower = short naps, back to work sooner. 100% = fully rested. Needs NAP WHEN.",hi:"100%",lo:"50%",name:"NAP UNTIL ENERGY >",min:50,max:100,step:10,def:100,
      what:"How rested he is before he gets up from a nap.",
      effect:"Lower = short naps, back to work sooner (but he tires again sooner). 100% = sleeps until fully rested. Only matters if NAP WHEN is set.",
      range:"50% to 100% (step 10)"},
    {id:"autob",does:"Buys food for you.",affects:"Keeps at least this many cans stocked while you have the coins. OFF = buy in the SHOP.",hi:"9",lo:"OFF",name:"KEEP FOOD AT LEAST",min:0,max:9,step:1,def:0,
      what:"Automatically buys food (at the shop price) whenever you have fewer cans than the number and enough coins.",
      effect:"Higher = he never runs out, but it spends your coins as soon as they come in. OFF = you buy food yourself in the SHOP. Cannot go over the cooler size.",
      range:"OFF, 1 to 9 food (step 1)"},
    {id:"suction",does:"Auto suction on the pile intake.",affects:"ON pulls potatoes from the pile onto the inbound conveyor. Needs the suction unit in the shop.",hi:"ON",lo:"OFF",name:"SUCTION",min:0,max:1,step:1,def:0,fmt:"onoff",need:"suction",
      what:"Turns the auto suction intake on the pile on or off.",
      effect:"ON = potatoes are pulled from the pile onto the inbound conveyor (if that belt is on). OFF = the pile sits still and he can still grab by hand.",
      range:"OFF or ON"},
    {id:"conveyor",does:"Inbound conveyor, pile to the auto-peeler.",affects:"Speed of the inbound belt. OFF = stopped. Needs the conveyor in the shop.",hi:"FAST",lo:"OFF",name:"CONVEYOR SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"conveyor",
      what:"How fast the inbound belt carries raw potatoes from the suction intake to the auto-peeler.",
      effect:"OFF = the belt is stopped. SLOW / STEADY / FAST change how quickly potatoes reach the peeler. Needs the conveyor bought.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"apeeler",does:"The auto-peeler.",affects:"How fast it peels each potato. OFF = idle. Needs the auto-peeler in the shop.",hi:"FAST",lo:"OFF",name:"AUTO-PEELER SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"autoPeeler",
      what:"Turns the auto-peeler on and sets how fast it peels.",
      effect:"OFF = potatoes wait on the inbound belt. SLOW / STEADY / FAST peel faster and shoot more peels onto the floor (always inside the room). Capacity grows with the peeler upgrade.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"outbelt",does:"Outbound conveyor into shipping.",affects:"Speed of the belt from the peeler into the shipping intake. OFF = stopped.",hi:"FAST",lo:"OFF",name:"OUT-CONVEYOR SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"outConveyor",
      what:"How fast peeled potatoes ride from the auto-peeler into the shipping unit.",
      effect:"OFF = the peeler holds finished potatoes and shipping receives nothing. SLOW / STEADY / FAST. The belt butts the shipping intake and never draws over it.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"lamp",does:"The floor lamp.",affects:"ON lights the living nook. Needs the lamp bought.",hi:"ON",lo:"OFF",name:"LAMP",min:0,max:1,step:1,def:0,fmt:"onoff",need:"lamp",
      what:"Turns the floor lamp on or off.",
      effect:"ON = a warm light pool in the living nook (looped shade). OFF = dark. Decoration with a real on/off, no other stat effect.",
      range:"OFF or ON"},
    {id:"radio",does:"The radio.",affects:"ON plays a looped tune. TUNING sends him to adjust it.",hi:"ON",lo:"OFF",name:"RADIO",min:0,max:1,step:1,def:0,fmt:"onoff",need:"radio",
      what:"Turns the radio on or off. When it's on he will walk over and tune it now and then.",
      effect:"ON = looped notes and a small energy tick while it plays. He walks to it to tune. OFF = silent.",
      range:"OFF or ON"},
    {id:"tv",does:"The TV.",affects:"ON plays a looped picture. Pair with WATCH WHEN.",hi:"ON",lo:"OFF",name:"TV",min:0,max:1,step:1,def:0,fmt:"onoff",need:"tvArmchair",
      what:"Turns the TV on or off. The screen only glows when ON.",
      effect:"ON = the set plays (looped frames). He sits in the armchair and watches when WATCH WHEN ENERGY < is set. Watching restores energy slowly, not as fast as a nap.",
      range:"OFF or ON"},
    {id:"watch",does:"Sends him to watch TV when he gets a little tired.",affects:"Energy under the number = go watch (needs TV on and the armchair). OFF = never.",hi:"70%",lo:"OFF",name:"WATCH WHEN ENERGY <",min:0,max:70,step:5,def:0,fmt:"pct",need:"tvArmchair",
      what:"Sends him to sit in the armchair and watch TV when his energy drops below the number.",
      effect:"Only works if you bought the TV + armchair and TV is ON. Restores energy slowly (weaker than a nap). OFF = he never watches on his own.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"water",does:"Sends him to water the plant when it dries out.",affects:"Dryness over the number = water. OFF = never. Needs the plant.",hi:"80",lo:"OFF",name:"WATER WHEN DRY >",min:0,max:90,step:10,def:0,fmt:"dry",need:"plant",
      what:"Sends him to water the plant when its dryness goes over the number.",
      effect:"The plant dries slowly over time. If it gets too dry it droops (off look). Watering brings it back. OFF = he never waters it.",
      range:"OFF, 10 to 90 dryness (step 10)"},
    {id:"wash",does:"Sends him to the sink with a raw potato for a cleaner peel.",affects:"ON = he washes a potato at the sink before peeling (worth +1c). Needs the sink.",hi:"ON",lo:"OFF",name:"WASH BEFORE PEEL",min:0,max:1,step:1,def:0,fmt:"onoff",need:"sink",
      what:"When ON, he walks a raw potato to the sink and washes it before he peels.",
      effect:"A washed potato is worth 3c instead of 2c (still 1c if sloppy). Takes a few seconds at the sink. Needs the sink bought.",
      range:"OFF or ON"}
  ];
  var BOX={};for(var ci=0;ci<COMMANDS.length;ci++){var cm=COMMANDS[ci];BOX[cm.id]={min:cm.min,max:cm.max,step:cm.step,def:cm.def};}
  /* ---- the shop ---- */
  var UPS=[
    {id:"peeler",name:"SHARP PEELER",max:3,prices:[40,110,260],fx:"Peeling takes 15% less time per level."},
    {id:"boots",name:"GOOD BOOTS",max:3,prices:[30,90,220],fx:"Walks 10% faster per level."},
    {id:"chute",name:"BIGGER CHUTE",max:3,prices:[35,100,240],fx:"Drops go in 30% quicker and each batch holds 2 more potatoes per level."},
    {id:"pantry",name:"BIGGER COOLER",max:2,prices:[25,80],fx:"The cooler holds 3 more food per level (9, then 12, then 15)."},
    {id:"broom",name:"STIFF BROOM",max:3,prices:[30,90,200],fx:"Sweeps 50% faster per level."},
    {id:"mat",name:"SOFT BED",max:2,prices:[30,90],fx:"Naps restore energy 35% faster per level."},
    {id:"apeeler",name:"FASTER AUTO-PEELER",max:3,prices:[50,140,300],fx:"Auto-peeler works 20% faster and holds 1 more potato per level."},
    {id:"belts",name:"BETTER BELTS",max:3,prices:[40,120,260],fx:"All conveyor belts run 15% faster per level."},
    {id:"bag",name:"BIGGER CARRY BAG",max:2,prices:[25,80],fx:"He can carry 1 extra potato per level (2, then 3)."}
  ];

  /* ---- 0.4 shop items (unlocked by level, then bought). Unused stay in the table, hidden in the shop until unlocked. ---- */
  var ITEMS=[
    {id:"betterPeeler",name:"BETTER PEELER",lv:1,price:20,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa. Peeling is 10% faster while equipped."},
    {id:"carryBag",name:"SMALL CARRY BAG",lv:1,price:18,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa to carry 2 potatoes at a time (3 / 4 with upgrades)."},
    {id:"sink",name:"SINK",lv:1,price:25,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. WASH BEFORE PEEL sends him here for a +1c clean potato."},
    {id:"broomDustpan",name:"SMALL BROOM + DUSTPAN",lv:1,price:16,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa. He sweeps at the peel mess, broom on the peels. Stiff Broom still upgrades speed."},
    {id:"smallCooler",name:"SMALL COOLER",lv:1,price:22,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Adds 2 food slots. Hums when stocked."},
    {id:"basicCot",name:"BASIC COT",lv:1,price:28,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. A second bed he can nap on (enters from the side)."},
    {id:"conveyor",name:"CONVEYOR",lv:2,price:70,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Inbound belt from the pile toward the auto-peeler."},
    {id:"suction",name:"AUTO SUCTION",lv:2,price:55,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Swarm-style intake on the pile."},
    {id:"plant",name:"PLANT",lv:2,price:15,group:"decor",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Waters when you set WATER WHEN DRY."},
    {id:"lamp",name:"LAMP",lv:2,price:14,group:"decor",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. On/off command, looped glow."},
    {id:"autoPeeler",name:"AUTO-PEELER",lv:3,price:120,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Peels shoot onto the floor inside the room."},
    {id:"outConveyor",name:"OUT-CONVEYOR",lv:3,price:80,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Belt into the shipping intake."},
    {id:"radio",name:"RADIO",lv:3,price:22,group:"decor",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. He walks over to tune it now and then."},
    {id:"rug",name:"RUG",lv:3,price:18,group:"decor",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. A rug he will stand on."},
    {id:"tvArmchair",name:"TV + ARMCHAIR",lv:4,price:90,group:"decor",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. He sits in the chair when you set WATCH WHEN ENERGY <."}
  ];
  var ITEMI={};for(var ii=0;ii<ITEMS.length;ii++)ITEMI[ITEMS[ii].id]=ITEMS[ii];
  var LEVEL_PRICE=[0,0,80,160,280,450]; /* cost to BUY that level (reach Lv N). Max 5. */
  var BELT_SPD=[0,0.55,1.0,1.45];
  var SPEED_NAME=["OFF","SLOW","STEADY","FAST"];
  var UPI={};for(var ui=0;ui<UPS.length;ui++)UPI[UPS[ui].id]=UPS[ui];
  function upsFresh(){var o={};for(var i=0;i<UPS.length;i++)o[UPS[i].id]=0;return o;}
  function hash(a,b){var x=Math.imul((Math.round(a*1000)|0)^0x9e3779b9,0x85ebca6b)^Math.imul((b|0)+1,0xc2b2ae35);x^=x>>>13;x=Math.imul(x,0x27d4eb2f);x^=x>>>15;x=Math.imul(x,0x165667b1);x^=x>>>16;return (x>>>0)/4294967296;}
  /* the spill schedule of one batch: when potato j leaves the return chute (ex) and when it comes to rest on the pile (ld). Pure function of (t0,n): sim and renderer share it. */
  function spill(t0,n){var ex=[],ld=[],t=t0+C.tPipe,pl=0;
    for(var j=0;j<n;j++){t+=(j===0?hash(t0,900)*0.25:0.10+hash(t0,j*7+1)*0.55);ex.push(t);
      var l=t+0.75+hash(t0,j*7+3)*0.6;if(l<pl+0.05)l=pl+0.05;ld.push(l);pl=l;}
    return {ex:ex,ld:ld};}
  /* ---- routing: shortest path round the inflated obstacles (visibility graph) ---- */
  function inflated(){var r=[],I=GEO.INFL;for(var i=0;i<OBST.length;i++){var o=OBST[i];r.push({x0:o.x0-I,y0:o.y0-I,x1:o.x1+I,y1:o.y1+I});}return r;}
  var INF=inflated(),EPS=0.01;
  function inside(b,x,y){return x>b.x0+EPS&&x<b.x1-EPS&&y>b.y0+EPS&&y<b.y1-EPS;}
  function segHits(b,ax,ay,bx,by){var t0=0,t1=1,dx=bx-ax,dy=by-ay,p=[-dx,dx,-dy,dy],q=[ax-(b.x0+EPS),(b.x1-EPS)-ax,ay-(b.y0+EPS),(b.y1-EPS)-ay];
    for(var i=0;i<4;i++){if(p[i]===0){if(q[i]<=0)return false;}else{var r=q[i]/p[i];if(p[i]<0){if(r>t1)return false;if(r>t0)t0=r;}else{if(r<t0)return false;if(r<t1)t1=r;}}}
    return t1-t0>1e-9;}
  function clearSeg(ax,ay,bx,by){for(var i=0;i<INF.length;i++)if(segHits(INF[i],ax,ay,bx,by))return false;return true;}
  function route(sx,sy,tx,ty){
    var pre=[];
    for(var i=0;i<INF.length;i++){var b=INF[i];if(inside(b,sx,sy)){ /* started inside an obstacle's margin: step out by the shortest way */
        var dl=sx-b.x0,dr=b.x1-sx,dt=sy-b.y0,db=b.y1-sy,m=Math.min(dl,dr,dt,db);
        if(m===dl)sx=b.x0;else if(m===dr)sx=b.x1;else if(m===dt)sy=b.y0;else sy=b.y1;pre.push([sx,sy]);}}
    if(clearSeg(sx,sy,tx,ty))return pre.concat([[tx,ty]]);
    var N=[[sx,sy],[tx,ty]],lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3;
    for(var k=0;k<INF.length;k++){var c=INF[k],cs=[[c.x0,c.y0],[c.x1,c.y0],[c.x0,c.y1],[c.x1,c.y1]];
      for(var q=0;q<4;q++){var p=cs[q];if(p[0]<lo||p[0]>hx||p[1]<lo||p[1]>hy)continue;var bad=false;for(var m2=0;m2<INF.length;m2++)if(inside(INF[m2],p[0],p[1])){bad=true;break;}if(!bad)N.push(p);}}
    var n=N.length,D=[],P=[],U=[],i2,j2;for(i2=0;i2<n;i2++){D.push(i2===0?0:1e9);P.push(-1);U.push(false);}
    for(var it=0;it<n;it++){var u=-1;for(i2=0;i2<n;i2++)if(!U[i2]&&(u<0||D[i2]<D[u]))u=i2;if(u<0||D[u]>=1e9)break;U[u]=true;if(u===1)break;
      for(j2=0;j2<n;j2++){if(U[j2])continue;if(!clearSeg(N[u][0],N[u][1],N[j2][0],N[j2][1]))continue;
        var d=D[u]+Math.sqrt((N[u][0]-N[j2][0])*(N[u][0]-N[j2][0])+(N[u][1]-N[j2][1])*(N[u][1]-N[j2][1]));if(d<D[j2]){D[j2]=d;P[j2]=u;}}}
    if(P[1]<0){
      /* no full path: still refuse a straight cut through furniture; walk to the closest reachable node toward the target */
      var best=-1,bd=1e9,bi;
      for(bi=2;bi<n;bi++){if(D[bi]>=1e9)continue;var dd=D[bi]+Math.sqrt((N[bi][0]-tx)*(N[bi][0]-tx)+(N[bi][1]-ty)*(N[bi][1]-ty));if(dd<bd){bd=dd;best=bi;}}
      if(best<0)return pre.concat([[sx,sy]]);
      var path2=[],cur2=best;while(cur2>0){path2.unshift(N[cur2]);cur2=P[cur2];}
      return pre.concat(path2);
    }
    var path=[],cur=1;while(cur>0){path.unshift(N[cur]);cur=P[cur];}
    return pre.concat(path);}
  function lineFresh(){return {beltIn:[],peeler:null,beltOut:[],shipQ:0,emitted:0,shipped:0};}
  function defaultPlace(id){
    var g=GEO[id]||GEO.tv;
    if(id==="betterPeeler")return {x:GEO.betterPeeler.x,y:GEO.betterPeeler.y};
    if(id==="smallCooler")return {x:GEO.smallCooler.x,y:GEO.smallCooler.y};
    if(id==="tvArmchair")return {x:GEO.tv.x,y:GEO.tv.y};
    if(id==="broomDustpan")return {x:GEO.broom.x,y:GEO.broom.y};
    if(id==="carryBag")return {x:GEO.bag.x,y:GEO.bag.y};
    if(typeof g.x==="number")return {x:g.x,y:g.y};
    return {x:(g.x0+g.x1)/2,y:(g.y0+g.y1)/2};
  }
  function fresh(seed){
    seed=(seed>>>0)||((Math.random()*4294967295)>>>0);
    var b={};for(var id in BOX)b[id]=BOX[id].def;
    return {v:4,seed:seed,rs:0,rr:seed|0,t:0,level:1,
      coins:C.startCoins,food:C.startFood,hunger:100,energy:100,
      box:b,potCap:C.potBase,up:upsFresh(),
      owned:{},place:{},equipped:{},line:lineFresh(),
      decor:{lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0},
      pile:POTS[BOX.pot.def],chute:0,suck:null,peels:0,mess:[],
      stats:{peeled:0,earned:0,meals:0,naps:0,lazyNaps:0,bought:0,spent:0,lazyTime:0,eatTime:0,napTime:0,firstBuyT:-1,
        sucks:0,swept:0,sweeps:0,peelsMade:0,maxPeels:0,cleanTime:0,waitTime:0,boughtPot:0,boughtUp:0,autoBuys:0},
      g:{x:0.5,y:0.20,dir:2,hold:null,held:0,washed:false,job:"pile",peel:0,pgot:0,sloppy:false,lazy:false,act:null,walkPh:0},
      ev:[]};
  }
  function Sim(st){
    this.s=st||fresh();if(typeof this.s.rr!=="number")this.s.rr=this.s.seed|0;
    if(!this.s.equipped||typeof this.s.equipped!=="object")this.s.equipped={};
    if(!this.s.place||typeof this.s.place!=="object")this.s.place={};
    if(!this.s.mess)this.s.mess=[];
    this.syncGeom();this.rebuildObst();
    if(!this.s.g.act)this.decide();
  }
  var P=Sim.prototype;
  P.rand=function(){var a=this.s.rr=(this.s.rr+0x6D2B79F5)|0;this.s.rs=(this.s.rs|0)+1;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  P.emit=function(e){if(this.s.ev.length<64)this.s.ev.push(e);};
  P.up=function(id){return Math.max(0,Math.min(UPI[id].max,this.s.up[id]|0));};
  P.spd=function(){var g=this.s.g;return g.lazy?C.lazySpeed:SPD[this.s.box.pace];};
  P.messF=function(){return 1-C.messMax*Math.min(1,this.s.peels/C.messFull);};
  P.wspd=function(){return this.spd()*this.messF();};
  P.price=function(){var b=this.s.stats.bought;return Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery));};
  P.foodMax=function(){return C.foodMax+3*this.up("pantry")+(this.placed("smallCooler")?2:0);};
  P.chuteCap=function(){return C.chuteCap+2*this.up("chute");};
  P.peelTime=function(){return C.peel*Math.pow(0.85,this.up("peeler"))*(this.equipped("betterPeeler")?0.90:1)/STYLE[this.s.box.style].sp;};
  P.dropTime=function(){return C.drop*Math.pow(0.7,this.up("chute"));};
  P.walkMul=function(){return 1+0.10*this.up("boots");};
  P.sweepRate=function(){return C.sweepRate*(1+0.5*this.up("broom"));};
  P.napRegen=function(){return C.napRegen*(1+0.35*this.up("mat"));};
  P.potMax=function(){return Math.max(0,Math.min(POT_MAX,this.s.potCap));};
  P.target=function(){return POTS[this.s.box.pot];};
  P.total=function(){var s=this.s,k=s.suck,L=s.line;var ln=L?((L.beltIn?L.beltIn.length:0)+(L.peeler?1:0)+(L.beltOut?L.beltOut.length:0)):0;return s.pile+this.heldN()+s.chute+(k?k.n-k.landed:0)+ln;};
  /* a full chute (or an empty pile) sends the batch up the pipe; it spills out of the return chute onto the pile */
  P.startSuck=function(){var s=this.s;if(s.suck||s.chute<=0)return false;s.suck={t0:s.t,n:s.chute,landed:0};s.chute=0;s.stats.sucks++;this.emit({k:"suck"});return true;};
  P.retarget=function(){var s=this.s,d=this.target()-this.total();if(d>0){s.pile+=d;return;}
    var r=-d,t=Math.min(r,s.pile);s.pile-=t;r-=t;
    if(r>0){t=Math.min(r,s.chute);s.chute-=t;r-=t;}
    if(r>0&&s.suck){var k=s.suck;t=Math.min(r,k.n-k.landed);k.n-=t;r-=t;if(k.n<=k.landed)s.suck=null;}};
  P.drn=function(){var g=this.s.g;return g.lazy?DRN[0]:DRN[this.s.box.pace];};
  P.needState=function(){
    var s=this.s,b=s.box;
    var eatThr=b.eat>0?b.eat:0,napThr=b.nap>0?b.nap:0;
    var wantEat=eatThr>0&&s.hunger<eatThr&&s.food>0;
    var wantNap=napThr>0&&s.energy<napThr;
    var hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<C.lazyLow);
    var energyUnmet=napThr>0?false:(s.energy<C.lazyLow);
    var lazy=(hungerUnmet||energyUnmet);
    var wantWatch=this.placed("tvArmchair")&&b.tv>0&&b.watch>0&&s.energy<b.watch&&!s.g.hold;
    var wantWater=this.placed("plant")&&b.water>0&&(s.decor&&s.decor.plant>=b.water)&&!s.g.hold;
    return {wantEat:wantEat,wantNap:wantNap,lazy:lazy,hungerUnmet:hungerUnmet,energyUnmet:energyUnmet,
      wantClean:b.clean>0&&s.peels>b.clean&&!lazy&&!s.g.hold,
      wantWatch:wantWatch&&!lazy,wantWater:wantWater&&!lazy};
  };
  P.walkTo=function(xu,yu,dir,then,label){var g=this.s.g,dest=this.standBeside(xu,yu);xu=dest.x;yu=dest.y;
    var r=route(g.x*RW,g.y*RH,xu,yu),wp=[];for(var i=0;i<r.length-1;i++)wp.push([r[i][0]/RW,r[i][1]/RH]);
    g.act={t:"walk",x:xu/RW,y:yu/RH,dir:dir,then:then,label:label,wp:wp};};
  P.decide=function(){
    var s=this.s,g=s.g,n=this.needState();
    if(n.wantEat){g.lazy=false;this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the food");return;}
    if(n.wantNap){g.lazy=false;this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the bed");return;}
    g.lazy=n.lazy;
    if(n.wantClean){var sw=this.sweepSpot();this.walkTo(sw.x,sw.y,sw.dir,"sweep","to sweep");return;}
    if(n.wantWater){var pl=this.placeOf("plant");this.walkTo(pl.x,pl.y+12,0,"water","to water the plant");return;}
    if(n.wantWatch){var sp=this.sitSpot();this.walkTo(sp.x,sp.y+10,0,"watch","to watch TV");return;}
    if(g.lazy){
      var r=this.rand();
      if(s.energy<15||(s.energy<70&&r<0.30)){g.act={t:"lazynap",until:Math.min(100,60+this.rand()*35),label:"dozing on the floor"};s.stats.lazyNaps++;this.emit({k:"lazynap"});return;}
      if(r>0.72){g.act={t:"idle",d:1.5+this.rand()*2.5,e:0,label:"slacking off"};return;}
    }
    /* if the full work line is running, leave the peeling to the machines and do a little living */
    if(this.lineRunning()&&!g.hold){
      if(this.placed("radio")&&s.box.radio>0&&this.rand()<0.08){var rd=this.placeOf("radio");this.walkTo(rd.x-7.5,rd.y,1,"tune","to tune the radio");return;}
      g.act={t:"idle",d:1.2+this.rand()*2.0,e:0,label:"watching the line"};return;
    }
    if(g.job==="pile"){var px=SPOT.pile.x0+this.rand()*(SPOT.pile.x1-SPOT.pile.x0);this.walkTo(px,SPOT.pile.y,2,"grab","to the pile");}
    else if(g.job==="wash"){var sk=this.placeOf("sink");this.walkTo(sk.x,sk.y+12,0,"wash","to the sink");}
    else if(g.job==="table"||g.job==="peel"){this.walkTo(SPOT.table.x,SPOT.table.y,SPOT.table.dir,"peel","to the table");}
    else this.walkTo(SPOT.ship.x,SPOT.ship.y,SPOT.ship.dir,"drop","to the chute");
  };
  P.startAt=function(kind){
    var g=this.s.g;
    if(kind==="grab")g.act={t:"grab",e:0,label:this.carryCap()>1?"grabbing potatoes":"grabbing a potato"};
    else if(kind==="wash")g.act={t:"wash",e:0,label:this.heldN()>1?"washing potatoes":"washing a potato"};
    else if(kind==="peel"){g.job="peel";g.act={t:"peel",label:g.lazy?"peeling (sloppy)":"peeling"};}
    else if(kind==="watch"){var sp=this.sitSpot();g.x=sp.x/RW;g.y=sp.y/RH;g.dir=1;g.act={t:"watch",e:0,label:"watching TV"};}
    else if(kind==="water")g.act={t:"water",e:0,label:"watering the plant"};
    else if(kind==="tune")g.act={t:"tune",e:0,label:"tuning the radio"};
    else if(kind==="drop")g.act={t:"drop",e:0,label:this.heldN()>1?"shipping them":"shipping it"};
    else if(kind==="eat")g.act={t:"eat",e:0,label:"eating"};
    else if(kind==="sweep")g.act={t:"sweep",e:0,acc:0,label:"sweeping up the peels"};
    else if(kind==="nap"){g.x=GEO.mat.x/RW;g.y=GEO.mat.y/RH;g.dir=1;g.act={t:"nap",label:"napping on the bed"};this.s.stats.naps++;this.emit({k:"nap"});}
  };
  P.peelEmit=function(n,src){var s=this.s;if(!s.mess)s.mess=[];src=src||"table";
    for(var i=0;i<n;i++){if(s.mess.length>=C.peelMax)break;
      var pos=this.spawnPeelPos(src,s.mess.length);
      s.mess.push(pos);s.peels=s.mess.length;s.stats.peelsMade++;if(s.peels>s.stats.maxPeels)s.stats.maxPeels=s.peels;
      this.emit({k:"peel",slot:s.mess.length-1,x:pos.x,y:pos.y,src:src});}};
  P.spawnPeelPos=function(src,i){
    var x,y,h=hash(this.s.seed||1,i*11+7);
    if(src==="peeler"&&this.placed("autoPeeler")){
      var p=this.placeOf("autoPeeler");
      var ang=h*6.283,r=6+hash(this.s.seed||1,i*13+3)*10;
      x=p.x+8+Math.cos(ang)*r*0.4;y=p.y+14+Math.sin(ang)*r*0.55;
    }else{
      var k=tableKids(),sp=k.peelSpawn;
      var ang=h*6.283,r=4+hash(this.s.seed||1,i*17+5)*16;
      x=sp.x+Math.cos(ang)*r*0.85;y=sp.y+2+Math.abs(Math.sin(ang))*r;
    }
    x=Math.max(GEO.WALL+4,Math.min(RW-GEO.WALL-4,x));
    y=Math.max(GEO.WALL+4,Math.min(GEO.pile.base-GEO.pile.rz-8,y));
    /* keep peels off the table, bed and cooler tops */
    var T=GEO.table,M=GEO.mat,C=GEO.cooler;
    if(x>T.x0-1&&x<T.x1+1&&y>T.y0-1&&y<T.y1+2)y=T.y1+4;
    if(Math.abs(x-M.x)<M.w/2+2&&Math.abs(y-M.y)<M.h/2+2)y=M.y+M.h/2+4;
    if(x>C.x0-1&&x<C.x1+1&&y>C.y0-1&&y<C.y1+2)y=C.y1+4;
    return {x:x,y:y,src:src||"table"};
  };
  P.syncPeelCount=function(){var s=this.s;if(!s.mess)s.mess=[];s.peels=s.mess.length;};
  P.step=function(dt){
    var s=this.s,g=s.g,a=g.act,sp=this.spd(),dr=this.drn(),wsp=sp*this.messF();
    s.t+=dt;
    if(s.suck){var k=s.suck,sc=spill(k.t0,k.n);
      while(k.landed<k.n&&s.t>=sc.ld[k.landed]){s.pile++;k.landed++;this.emit({k:"land"});}
      if(k.landed>=k.n)s.suck=null;}
    if(!s.suck&&s.chute>=this.chuteCap())this.startSuck();
    this.lineStep(dt);
    this.decorStep(dt);
    if(s.box.autob>0&&s.food<s.box.autob&&s.food<this.foodMax()&&s.coins>=this.price()){this.buyFood(true);}
    if(a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep")))s.stats.cleanTime+=dt;
    var resting=a&&(a.t==="nap"||a.t==="lazynap"),eating=a&&a.t==="eat";
    if(resting){s.hunger-=C.hungerDrainNap*dt;}
    else if(!eating){s.hunger-=C.hungerDrain*dr*dt;s.energy-=C.energyDrain*dr*dt*(a&&a.t==="idle"?0.4:1);}
    if(s.hunger<0)s.hunger=0;if(s.energy<0)s.energy=0;
    if(g.lazy)s.stats.lazyTime+=dt;
    if(eating||(a&&a.t==="walk"&&a.then==="eat"))s.stats.eatTime+=dt;
    if(resting||(a&&a.t==="walk"&&a.then==="nap"))s.stats.napTime+=dt;
    if(!a){this.decide();return;}
    switch(a.t){
      case "walk":{
        var fin=!(a.wp&&a.wp.length),gt=fin?[a.x,a.y]:a.wp[0];
        var dx=(gt[0]-g.x)*RW,dy=(gt[1]-g.y)*RH,d=Math.sqrt(dx*dx+dy*dy),mv=C.walk*wsp*this.walkMul()*dt;
        g.walkPh+=mv*0.35;
        if(Math.abs(dx)>Math.abs(dy)*0.8)g.dir=dx>0?1:3;else g.dir=dy>0?2:0;
        if(d<=mv||d<0.01){g.x=gt[0];g.y=gt[1];if(fin){g.dir=a.dir;this.startAt(a.then);}else a.wp.shift();}
        else{g.x+=dx/d*mv/RW;g.y+=dy/d*mv/RH;}
        break;}
      case "grab":a.e+=dt*wsp;if(a.e>=C.grab){
          if(s.pile<=0){a.e=C.grab;a.label="waiting for potatoes";s.stats.waitTime+=dt;if(s.chute>0&&!s.suck)this.startSuck();break;}
          var take=Math.min(this.carryCap(),s.pile);s.pile-=take;g.hold="raw";g.held=take;g.washed=false;g.job=(this.owned("sink")&&s.box.wash>0)?"wash":"table";g.peel=0;g.pgot=0;g.sloppy=false;this.emit({k:"grab",n:take});this.decide();}break;
      case "peel":{
        if(g.lazy)g.sloppy=true;
        var nHold=Math.max(1,this.heldN());
        var np=(g.sloppy?C.peelPerSloppy:STYLE[s.box.style].peels)*nHold;
        g.peel+=dt*wsp/(this.peelTime()*(0.70+0.30*nHold));
        /* the skin comes off progressively: one peel pops off at each fraction of the load */
        while(g.pgot<np&&g.peel>=(g.pgot+1)/(np+1)&&g.peel<1){g.pgot++;this.peelEmit(1);}
        if(g.peel>=1){g.peel=1;g.hold="peeled";g.job="chute";if(g.pgot<np)this.peelEmit(np-g.pgot);g.pgot=0;
          this.emit({k:"peeled",n:nHold});this.decide();}
        break;}
      case "drop":a.e+=dt*wsp;if(a.e>=this.dropTime()){
          if(s.chute>=this.chuteCap()){a.e=this.dropTime();a.label="waiting for the chute";s.stats.waitTime+=dt;break;}
          var v=g.sloppy?C.sloppyValue:(g.washed?C.value+1:C.value);s.chute++;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;
          if(s.chute>=this.chuteCap())this.startSuck();
          g.held=this.heldN()-1;this.emit({k:"coin",v:v,sloppy:g.sloppy});
          if(g.held<=0){g.hold=null;g.held=0;g.job="pile";g.peel=0;g.sloppy=false;this.decide();}
          else{a.e=0;a.label="shipping them";}}break;
      case "eat":a.e+=dt;if(a.e>=C.eat){
          if(s.food>0){s.food--;s.hunger=Math.min(100,s.hunger+C.meal);s.stats.meals++;this.emit({k:"ate"});}
          var n=this.needState();if(n.wantEat){a.e=0;}else this.decide();}break;
      case "nap":{s.energy=Math.min(100,s.energy+this.napRegen()*dt);var wk=s.box.wake>=100?C.napWake:s.box.wake;if(s.energy>=wk){var bs=bedside();g.x=bs.x/RW;g.y=bs.y/RH;g.dir=bs.dir;this.decide();}break;}
      case "lazynap":s.energy=Math.min(100,s.energy+C.lazyNapRegen*dt);if(s.energy>=a.until)this.decide();break;
      case "idle":a.e+=dt;if(a.e>=a.d)this.decide();break;
      case "sweep":{
        var nn=this.needState();
        if(s.box.clean<=0||nn.wantEat||nn.wantNap||nn.lazy){this.decide();break;}
        a.e+=dt*sp;
        if(a.e>C.sweepWind){a.acc+=dt*sp*this.sweepRate();var kk=Math.floor(a.acc);if(kk>0){a.acc-=kk;var got=this.sweepNear(g.x*RW,g.y*RH,kk);
          var tidy=Math.floor(s.box.clean*C.sweepTidy);
          if(got===0&&s.peels>tidy){this.decide();break;}}}
        if(s.peels<=Math.floor(s.box.clean*C.sweepTidy)){s.stats.sweeps++;this.emit({k:"swept"});this.decide();}
        break;}
      case "wash":{
        a.e+=dt*sp;if(a.e>=2.2){g.washed=true;g.job="table";this.decide();}break;}
      case "watch":{
        var nn=this.needState();
        if(!this.placed("tvArmchair")||s.box.tv<=0||nn.wantEat||nn.wantNap){this.decide();break;}
        s.energy=Math.min(100,s.energy+1.8*dt);
        a.e+=dt;if(s.energy>=(s.box.watch>0?Math.min(100,s.box.watch+25):80)||a.e>12)this.decide();
        break;}
      case "water":{
        a.e+=dt*sp;if(a.e>=2.4){if(s.decor){s.decor.plant=0;s.decor.plantT=s.t;}this.emit({k:"watered"});this.decide();}break;}
      case "tune":{
        a.e+=dt;if(a.e>=1.8){if(s.decor)s.decor.radioTune=s.t;this.decide();}break;}
    }
  };
  P.run=function(sec,h){h=h||0.1;var n=Math.round(sec/h);for(var i=0;i<n;i++)this.step(h);};
  P.poke=function(){var g=this.s.g,a=g.act,n=this.needState();
    if(a&&(a.t==="idle"||a.t==="lazynap"))this.decide();
    else if(a&&a.t==="walk"&&/grab|peel|drop|sweep|wash|watch|water|tune/.test(a.then)&&(n.wantEat||n.wantNap))this.decide();
    else if(g.lazy&&!n.lazy){g.lazy=false;}};
  P.setBox=function(id,v){var b=BOX[id];if(!b)return false;v=Number(v);if(v!==v)return false;var mx=id==="pot"?this.potMax():b.max;
    v=Math.max(b.min,Math.min(mx,Math.round((v-b.min)/b.step)*b.step+b.min));if(this.s.box[id]===v)return false;this.s.box[id]=v;if(id==="pot")this.retarget();this.poke();return true;};
  P.buyFood=function(auto){var s=this.s,pr=this.price();if(s.food>=this.foodMax())return "full";if(s.coins<pr)return "poor";
    s.coins-=pr;s.food++;s.stats.bought++;s.stats.spent+=pr;if(auto)s.stats.autoBuys++;if(s.stats.firstBuyT<0)s.stats.firstBuyT=s.t;this.poke();return "ok";};
  P.potPrice=function(){var i=this.s.potCap+1;if(i>POT_MAX)return null;return Math.round(C.potPrice0*Math.pow(C.potPriceGrow,i-C.potBase));};
  /* buying potatoes raises the limit to the next stop and puts them in play right away */
  P.buyPotatoes=function(){var s=this.s,pr=this.potPrice();if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.potCap++;s.box.pot=s.potCap;s.stats.boughtPot++;s.stats.spent+=pr;this.retarget();this.poke();return "ok";};
  P.upPrice=function(id){var u=UPI[id],l=this.up(id);return l>=u.max?null:u.prices[l];};
  P.buyUp=function(id){var s=this.s;if(!UPI[id])return "bad";var pr=this.upPrice(id);if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.up[id]=this.up(id)+1;s.stats.boughtUp++;s.stats.spent+=pr;this.poke();return "ok";};
  P.stateName=function(){var g=this.s.g,a=g.act;if(g.lazy)return "AUTO-LAZY";if(!a)return "PEELING";
    if(a.t==="eat"||(a.t==="walk"&&a.then==="eat"))return "EATING";
    if(a.t==="nap"||(a.t==="walk"&&a.then==="nap"))return "NAPPING";
    if(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"))return "CLEANING";
    if(a.t==="watch"||(a.t==="walk"&&a.then==="watch"))return "WATCHING";
    if(a.t==="water"||(a.t==="walk"&&a.then==="water"))return "WATERING";
    if(a.t==="tune"||(a.t==="walk"&&a.then==="tune"))return "TUNING";
    if(a.t==="wash"||(a.t==="walk"&&a.then==="wash"))return "WASHING";
    return "PEELING";};

  P.owned=function(id){return !!(this.s.owned&&this.s.owned[id]);};
  P.unlocked=function(id){var it=ITEMI[id];return !!(it&&this.s.level>=it.lv);};
  P.placed=function(id){return this.owned(id)&&!!(this.s.place&&this.s.place[id]);};
  P.equipped=function(id){return this.owned(id)&&!!(this.s.equipped&&this.s.equipped[id]);};
  P.inInv=function(id){if(!this.owned(id))return false;if(isTool(id))return !this.equipped(id);if(isPlaceable(id))return !this.placed(id);return false;};
  P.placeOf=function(id){var p=(this.s.place&&this.s.place[id])||defaultPlace(id);return p;};
  P.equip=function(id){if(!isTool(id)||!this.owned(id))return "bad";if(!this.s.equipped)this.s.equipped={};this.s.equipped[id]=1;this.poke();return "ok";};
  P.unequip=function(id){if(!isTool(id)||!this.owned(id))return "bad";if(this.s.equipped)this.s.equipped[id]=0;this.poke();return "ok";};
  P.placeItem=function(id,x,y){if(!isPlaceable(id)||!this.owned(id))return "bad";
    if(x==null||y==null){var d=defaultPlace(id);x=d.x;y=d.y;}
    if(!sanePlace(id,x,y))return "blocked";
    if(!this.s.place)this.s.place={};this.s.place[id]={x:x,y:y};this.syncGeom();this.rebuildObst();this.poke();return "ok";};
  P.unplace=function(id){if(!isPlaceable(id)||!this.placed(id))return "bad";
    delete this.s.place[id];this.syncGeom();this.rebuildObst();this.poke();return "ok";};
  P.invList=function(){var out=[],i,it;
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(!this.owned(it.id))continue;
      out.push({id:it.id,name:it.name,kind:isTool(it.id)?"tool":"place",equipped:this.equipped(it.id),placed:this.placed(it.id),inInv:this.inInv(it.id)});
    }return out;};
  P.trayList=function(){var out=[],i,it;
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(isPlaceable(it.id)&&this.owned(it.id)&&!this.placed(it.id))out.push({id:it.id,name:it.name});}
    return out;};
  P.standBeside=function(x,y){
    var pads=[[0,10],[0,14],[10,0],[-10,0],[0,-10],[8,8],[-8,8],[8,-8],[-8,-8]];
    var lo=GEO.WALL+4,hx=RW-GEO.WALL-4,hy=RH-GEO.WALL-4,i,px,py,ok,j,b;
    for(i=0;i<pads.length;i++){
      px=Math.max(lo,Math.min(hx,x+pads[i][0]));py=Math.max(lo,Math.min(hy,y+pads[i][1]));
      ok=true;for(j=0;j<INF.length;j++){b=INF[j];if(px>b.x0+EPS&&px<b.x1-EPS&&py>b.y0+EPS&&py<b.y1-EPS){ok=false;break;}}
      if(ok)return {x:px,y:py,dir:0};
    }
    return {x:Math.max(lo,Math.min(hx,x)),y:Math.max(lo,Math.min(hy,y)),dir:0};
  };
  P.nearestMess=function(){
    var s=this.s,mess=s.mess||[],gx=s.g.x*RW,gy=s.g.y*RH;
    if(!mess.length)return null;
    var used={},clusters=[],i,j,k,p,q,c;
    for(i=0;i<mess.length;i++){
      if(used[i])continue;
      c={x:0,y:0,n:0,ps:[]};q=[i];used[i]=1;
      while(q.length){
        k=q.pop();p=mess[k];c.ps.push(p);c.x+=p.x;c.y+=p.y;c.n++;
        for(j=0;j<mess.length;j++)if(!used[j]&&Math.hypot(mess[j].x-p.x,mess[j].y-p.y)<16){used[j]=1;q.push(j);}
      }
      c.x/=c.n;c.y/=c.n;clusters.push(c);
    }
    clusters.sort(function(a,b){return Math.hypot(a.x-gx,a.y-gy)-Math.hypot(b.x-gx,b.y-gy);});
    return clusters[0];
  };
  P.sweepSpot=function(){
    var c=this.nearestMess();
    if(!c){var k=tableKids();return {x:k.stand.x,y:k.stand.y,dir:0};}
    var pt=this.standBeside(c.x,c.y);
    return {x:pt.x,y:pt.y,dir:0,cx:c.x,cy:c.y,n:c.n};
  };
  P.sweepNear=function(x,y,n){
    var s=this.s;if(!s.mess)s.mess=[];
    var reach=16,near=[],far=[],i,d,p,take,left;
    for(i=0;i<s.mess.length;i++){p=s.mess[i];d=Math.hypot(p.x-x,p.y-y);if(d<=reach)near.push({d:d,p:p});else far.push(p);}
    near.sort(function(a,b){return a.d-b.d;});
    take=near.slice(0,n);left=near.slice(n);
    for(i=0;i<left.length;i++)far.push(left[i].p);
    s.mess=far;s.peels=s.mess.length;
    var removed=[];for(i=0;i<take.length;i++)removed.push({x:take[i].p.x,y:take[i].p.y,d:take[i].d});
    if(removed.length)s.stats.swept+=removed.length;
    this.lastSweep={x:x,y:y,removed:removed};
    return removed.length;
  };
  P.syncGeom=function(){
    var s=this.s,pl=s.place||{},k,bs,tv,sk,rd,lp,pn,ct;
    copyBox(GEO,GEO0);copyBox(SPOT,SPOT0);
    if(pl.table){GEO.table.x0=pl.table.x-17;GEO.table.x1=pl.table.x+17;GEO.table.y0=pl.table.y-9;GEO.table.y1=pl.table.y+9;}
    k=tableKids();SPOT.table.x=k.stand.x;SPOT.table.y=k.stand.y;SPOT.table.dir=0;
    GEO.mess.cx=k.cx;GEO.mess.cy=GEO.table.y1+16;
    if(pl.cooler){GEO.cooler.x0=pl.cooler.x-7;GEO.cooler.x1=pl.cooler.x+7;GEO.cooler.y0=pl.cooler.y-5;GEO.cooler.y1=pl.cooler.y+5;}
    if(pl.stool){GEO.stool.x=pl.stool.x;GEO.stool.y=pl.stool.y;}
    else{GEO.stool.x=(GEO.cooler.x0+GEO.cooler.x1)/2;GEO.stool.y=GEO.cooler.y1+12;}
    SPOT.food.x=GEO.stool.x;SPOT.food.y=GEO.stool.y+8;SPOT.food.dir=0;
    if(pl.mat||pl.bed){var m=pl.mat||pl.bed;GEO.mat.x=m.x;GEO.mat.y=m.y;}
    bs=bedside();SPOT.mat.x=bs.x;SPOT.mat.y=bs.y;SPOT.mat.dir=bs.dir;
    if(this.placed("sink")){sk=this.placeOf("sink");SPOT.sink.x=sk.x;SPOT.sink.y=sk.y+12;}
    if(this.placed("tvArmchair")){tv=this.placeOf("tvArmchair");SPOT.tv.x=tv.x-8;SPOT.tv.y=tv.y+12;}
    if(this.placed("radio")){rd=this.placeOf("radio");SPOT.radio.x=rd.x-8;SPOT.radio.y=rd.y;}
    if(this.placed("lamp")){lp=this.placeOf("lamp");SPOT.lamp.x=lp.x-8;SPOT.lamp.y=lp.y;}
    if(this.placed("plant")){pn=this.placeOf("plant");SPOT.plant.x=pn.x;SPOT.plant.y=pn.y+12;}
    if(this.placed("basicCot")){ct=this.placeOf("basicCot");SPOT.cot.x=ct.x;SPOT.cot.y=ct.y+14;}
  };
  P.lineOn=function(which){
    var b=this.s.box;
    if(which==="suction")return this.placed("suction")&&b.suction>0&&this.placed("conveyor")&&b.conveyor>0;
    if(which==="conveyor")return this.placed("conveyor")&&b.conveyor>0;
    if(which==="peeler")return this.placed("autoPeeler")&&b.apeeler>0;
    if(which==="outbelt")return this.placed("outConveyor")&&b.outbelt>0;
    return false;
  };
  P.lineRunning=function(){return this.lineOn("suction")&&this.lineOn("conveyor")&&this.lineOn("peeler")&&this.lineOn("outbelt");};
  P.beltSpd=function(){return BELT_SPD[this.s.box.conveyor]||0;};
  P.outSpd=function(){return BELT_SPD[this.s.box.outbelt]||0;};
  P.peelSpd=function(){return (BELT_SPD[this.s.box.apeeler]||0)*Math.pow(1.20,this.up("apeeler"));};
  P.beltMul=function(){return Math.pow(1.15,this.up("belts"));};
  P.peelCap=function(){return 1+this.up("apeeler");};
  P.carryCap=function(){return this.equipped("carryBag")?(2+this.up("bag")):1;};
  P.heldN=function(){var g=this.s.g;if(!g.hold)return 0;var n=g.held|0;return n>0?n:1;};
  P.sitSpot=function(){var tv=this.placeOf("tvArmchair");return {x:tv.x-8.2+2.6,y:tv.y+0.4,dir:1};};
  P.levelPrice=function(){var n=this.s.level+1;if(n>5)return null;return LEVEL_PRICE[n];};
  P.buyLevel=function(){var s=this.s,pr=this.levelPrice();if(pr===null)return "max";if(s.coins<pr)return "poor";s.coins-=pr;s.level++;s.stats.spent+=pr;s.stats.boughtUp++;this.emit({k:"level",lv:s.level});return "ok";};
  P.itemPrice=function(id){var it=ITEMI[id];if(!it)return null;if(this.owned(id))return null;return it.price;};
  P.buyItem=function(id){var s=this.s,it=ITEMI[id];if(!it)return "bad";if(!this.unlocked(id))return "locked";if(this.owned(id))return "have";if(s.coins<it.price)return "poor";
    s.coins-=it.price;s.owned[id]=1;if(!s.place)s.place={};if(!s.equipped)s.equipped={};
    /* 0.4.1: bought items go to the inventory first, not auto-placed / auto-equipped */
    s.stats.spent+=it.price;s.stats.boughtUp++;this.poke();this.emit({k:"item",id:id});return "ok";};
  P.moveItem=function(id,x,y){
    if(FIXED.indexOf(id)>=0)return false;
    if(id==="pile"||id==="ret"||id==="ship"||id==="return"||id==="shipping")return false;
    if(isPlaceable(id)&&!this.placed(id)&&!this.owned(id))return false;
    if(isTool(id))return false;
    if(!this.owned(id)&&STARTER.indexOf(id)<0&&id!=="bed")return false;
    var pad=8;
    x=Math.max(GEO.WALL+pad,Math.min(RW-GEO.WALL-pad,x));
    y=Math.max(GEO.WALL+pad,Math.min(RH-GEO.WALL-pad,y));
    if(!sanePlace(id,x,y))return false;
    if(!this.s.place)this.s.place={};
    /* cooler move carries the seat (stool) with it, unless the stool was already independently placed after this cooler move — we always carry it by the same delta */
    if(id==="cooler"){
      var ocx=(GEO.cooler.x0+GEO.cooler.x1)/2,ocy=(GEO.cooler.y0+GEO.cooler.y1)/2;
      var dx=x-ocx,dy=y-ocy;
      GEO.stool.x+=dx;GEO.stool.y+=dy;
      this.s.place.stool={x:GEO.stool.x,y:GEO.stool.y};
    }
    this.s.place[id]={x:x,y:y};
    if(id==="bed")this.s.place.mat={x:x,y:y};
    this.syncGeom();this.rebuildObst();return true;
  };
  function sanePlace(id,x,y){
    /* may not cover the fixed pile, return mouth, or shipping unit */
    var ship={x0:GEO.ship.x-10,y0:GEO.WALL,x1:GEO.ship.x+12,y1:GEO.ship.lip+8};
    var pile={x0:GEO.pile.cx-GEO.pile.rx,y0:GEO.pile.base-8,x1:GEO.pile.cx+GEO.pile.rx,y1:RH-GEO.WALL};
    var ret={x0:GEO.ret.mouthX-2,y0:GEO.ret.y-8,x1:RW-GEO.WALL,y1:GEO.ret.y+8};
    var box={x0:x-6,y0:y-6,x1:x+6,y1:y+6};
    function hit(a,b){return a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0;}
    if(hit(box,ship)||hit(box,ret))return false;
    /* suction is built to sit on the pile; other items may not cover it */
    if(id!=="suction"&&hit(box,pile))return false;
    return true;
  }
  P.rebuildObst=function(){
    var list=[],p,m=GEO.mat,sh=GEO.ship,rt=GEO.ret;
    list.push({id:"table",x0:GEO.table.x0,y0:GEO.table.y0,x1:GEO.table.x1,y1:GEO.table.y1});
    list.push({id:"cooler",x0:GEO.cooler.x0,y0:GEO.cooler.y0,x1:GEO.cooler.x1,y1:GEO.cooler.y1});
    list.push({id:"stool",x0:GEO.stool.x-5,y0:GEO.stool.y-5,x1:GEO.stool.x+5,y1:GEO.stool.y+5});
    list.push({id:"bed",x0:m.x-m.w/2,y0:m.y-m.h/2,x1:m.x+m.w/2,y1:m.y+m.h/2});
    list.push({id:"ship",x0:sh.x-10,y0:GEO.WALL,x1:sh.x+12,y1:sh.lip+6});
    list.push({id:"ret",x0:rt.mouthX,y0:rt.y-rt.w/2-1,x1:RW-GEO.WALL,y1:rt.y+rt.w/2+1});
    function add(id,hx,hy){if(!this.placed(id))return;p=this.placeOf(id);list.push({id:id,x0:p.x-hx,y0:p.y-hy,x1:p.x+hx,y1:p.y+hy});}
    add.call(this,"autoPeeler",12,12);
    add.call(this,"sink",8,8);
    add.call(this,"basicCot",14,8);
    add.call(this,"tvArmchair",16,8);
    add.call(this,"smallCooler",7,6);
    add.call(this,"plant",6,6);
    add.call(this,"lamp",5,6);
    add.call(this,"radio",5,5);
    add.call(this,"suction",8,8);
    add.call(this,"conveyor",6,18);
    add.call(this,"outConveyor",14,6);
    OBST=list;INF=inflated();Sim.OBST=OBST;
  };
  P.lineStep=function(dt){
    var s=this.s;if(!s.line)s.line=lineFresh();
    var L=s.line,mul=this.beltMul();
    /* suction + inbound */
    if(this.lineOn("suction")&&this.lineOn("conveyor")&&s.pile>0&&L.beltIn.length<4){
      s.pile--;L.beltIn.push({p:0,raw:true});this.emit({k:"suction"});
    }
    var vIn=(this.lineOn("conveyor")?this.beltSpd():0)*mul*0.22*dt;
    var i,p,it;
    if(vIn>0){
      for(i=0;i<L.beltIn.length;i++)L.beltIn[i].p=Math.min(1,L.beltIn[i].p+vIn);
      /* feed peeler when a potato arrives */
      if(L.beltIn.length&&L.beltIn[0].p>=1&&this.lineOn("peeler")&&!L.peeler){
        L.beltIn.shift();L.peeler={t:0,done:false,emitted:false};
      }else if(L.beltIn.length&&L.beltIn[0].p>=1&&!this.lineOn("peeler")){
        /* wait at the end of the belt */
        L.beltIn[0].p=1;
      }
    }
    if(L.peeler){
      if(this.lineOn("peeler")){
        L.peeler.t+=dt*this.peelSpd()*0.55;
        if(!L.peeler.emitted&&L.peeler.t>=0.45){L.peeler.emitted=true;this.peelEmit(3,"peeler");L.emitted=(L.emitted||0)+3;}
        if(L.peeler.t>=1)L.peeler.done=true;
      }
      if(L.peeler.done){
        if(this.lineOn("outbelt")&&L.beltOut.length<4){L.beltOut.push({p:0});L.peeler=null;}
        /* else hold the finished potato so conservation stays honest */
      }
    }
    var vOut=(this.lineOn("outbelt")?this.outSpd():0)*mul*0.22*dt;
    if(vOut>0){
      for(i=0;i<L.beltOut.length;i++)L.beltOut[i].p=Math.min(1,L.beltOut[i].p+vOut);
      if(L.beltOut.length&&L.beltOut[0].p>=1){
        L.beltOut.shift();
        var v=C.value;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;L.shipped=(L.shipped||0)+1;L.shipQ++;
        this.emit({k:"coin",v:v,sloppy:false,auto:true});
        /* auto-shipped potatoes skip the manual chute and go straight out; they still return via the pipe when a batch fills */
        s.chute++;
        if(s.chute>=this.chuteCap())this.startSuck();
      }
    }
  };
  P.decorStep=function(dt){
    var s=this.s;if(!s.decor)s.decor={lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0};
    if(this.placed("plant"))s.decor.plant=Math.min(100,s.decor.plant+dt*0.15);
    if(this.placed("radio")&&s.box.radio>0)s.energy=Math.min(100,s.energy+0.15*dt);
  };
  P.lineTotals=function(){
    var s=this.s,L=s.line||lineFresh(),k=s.suck;
    var n=s.pile+this.heldN()+s.chute+(k?k.n-k.landed:0)+(L.beltIn?L.beltIn.length:0)+(L.peeler?1:0)+(L.beltOut?L.beltOut.length:0);
    return {potatoes:n,pile:s.pile,hold:this.heldN(),chute:s.chute,pipe:k?k.n-k.landed:0,beltIn:L.beltIn.length,peeler:L.peeler?1:0,beltOut:L.beltOut.length,shipped:L.shipped||0,peels:s.peels};
  };
  P.visibleCommands=function(){
    var out=[],i,c;
    for(i=0;i<COMMANDS.length;i++){
      c=COMMANDS[i];
      if(c.need&&!this.owned(c.need))continue;
      out.push(c);
    }
    return out;
  };

  P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];o.v=4;return JSON.stringify(o);};

  function synthMess(n,seed){
    var out=[],i,k,sp,ang,r,x,y;
    if(!n)return out;
    k=tableKids();sp=k.peelSpawn;
    for(i=0;i<n&&i<C.peelMax;i++){
      ang=hash(seed||1,i*17+5)*6.283;r=4+hash(seed||1,i*11+3)*16;
      x=sp.x+Math.cos(ang)*r*0.85;y=sp.y+2+Math.abs(Math.sin(ang))*r;
      x=Math.max(GEO.WALL+4,Math.min(RW-GEO.WALL-4,x));
      y=Math.max(GEO.table.y1+3,Math.min(GEO.pile.base-GEO.pile.rz-8,y));
      out.push({x:x,y:y,src:"table"});
    }
    return out;
  }
  function ensure04(o){
    o.v=4;
    if(typeof o.level!=="number"||o.level<1)o.level=1;
    if(o.level>5)o.level=5;
    if(!o.owned||typeof o.owned!=="object")o.owned={};
    if(!o.place||typeof o.place!=="object")o.place={};
    if(!o.line||typeof o.line!=="object")o.line=lineFresh();
    if(!o.line.beltIn)o.line.beltIn=[];if(!o.line.beltOut)o.line.beltOut=[];
    if(!o.decor||typeof o.decor!=="object")o.decor={lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0};
    if(typeof o.g.washed!=="boolean")o.g.washed=false;
    var id;
    for(id in BOX)if(typeof o.box[id]!=="number")o.box[id]=BOX[id].def;
    /* 0.4.1 inventory: missing equipped means this is a pre-inventory v4 (or v1-v3) save.
       Migrate owned items as already placed / tools already equipped. */
    if(!o.equipped||typeof o.equipped!=="object"){
      o.equipped={};
      for(id in o.owned){
        if(!o.owned[id])continue;
        if(isTool(id))o.equipped[id]=1;
        if(isPlaceable(id)&&!o.place[id])o.place[id]=defaultPlace(id);
      }
    }
    if(!Array.isArray(o.mess))o.mess=synthMess(Math.max(0,o.peels|0),o.seed||1);
    o.peels=o.mess.length;
  }
  /* accepts a 0.4 save (v:4), a 0.3 save (v:3), a 0.2 save (v:2) or a 0.1 save (v:1). Older saves are migrated in memory; the old keys are never written. */
  Sim.load=function(str){try{var o=JSON.parse(str);if(!o||(o.v!==1&&o.v!==2&&o.v!==3&&o.v!==4)||typeof o.coins!=="number"||!o.g||typeof o.g!=="object"||!o.box||typeof o.box!=="object")return null;
      var old=o.v<3,from1=o.v===1,from3=o.v===3;o.v=4;ensure04(o);
      var f=fresh(o.seed);for(var k in f)if(!(k in o))o[k]=f[k];
      if(!o.stats||typeof o.stats!=="object")o.stats={};for(var k2 in f.stats)if(typeof o.stats[k2]!=="number"||!isFinite(o.stats[k2]))o.stats[k2]=f.stats[k2];
      var oldPot=+o.box.pot;
      for(var id in BOX){var v=+o.box[id];if(!(v>=BOX[id].min&&v<=BOX[id].max))o.box[id]=BOX[id].def;else o.box[id]=Math.round((v-BOX[id].min)/BOX[id].step)*BOX[id].step+BOX[id].min;}
      if(old){o.potCap=Math.max(C.potLegacy,o.box.pot);o.up=upsFresh();}
      if(!o.up||typeof o.up!=="object")o.up=upsFresh();for(var ui2=0;ui2<UPS.length;ui2++){var uu=Math.floor(+o.up[UPS[ui2].id]);o.up[UPS[ui2].id]=(uu>=0&&uu<=UPS[ui2].max)?uu:0;}
      o.potCap=Math.floor(+o.potCap);if(!(o.potCap>=0&&o.potCap<=POT_MAX))o.potCap=C.potBase;if(o.box.pot>o.potCap)o.potCap=o.box.pot;
      o.hunger=Math.max(0,Math.min(100,+o.hunger||0));o.energy=Math.max(0,Math.min(100,+o.energy||0));
      o.coins=Math.max(0,Math.min(1e9,Math.floor(+o.coins||0)));
      var fmx=C.foodMax+3*o.up.pantry,cmx=C.chuteCap+2*o.up.chute;
      o.food=Math.max(0,Math.min(fmx,Math.floor(+o.food||0)));o.ev=[];
      o.t=Math.max(0,+o.t||0);if(!isFinite(o.t))o.t=0;
      o.peels=Math.max(0,Math.min(C.peelMax,Math.floor(+o.peels||0)));
      o.chute=Math.max(0,Math.min(cmx,Math.floor(+o.chute||0)));
      o.pile=Math.max(0,Math.floor(+o.pile||0));
      var kk=o.suck;if(kk&&typeof kk==="object"&&isFinite(+kk.t0)&&+kk.n>0&&+kk.n<=cmx&&+kk.landed>=0&&+kk.landed<=+kk.n){o.suck={t0:+kk.t0,n:Math.floor(+kk.n),landed:Math.floor(+kk.landed)};if(o.suck.t0>o.t)o.suck.t0=o.t;}else o.suck=null;
      var g=o.g;if(g.act&&typeof g.act!=="object")g.act=null;
      if(old)g.act=null;      /* geometry changed in 0.3: let him re-decide from where he stands */
      var ok={walk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1,wash:1,watch:1,water:1,tune:1};if(g.act&&!ok[g.act.t])g.act=null;
      if(g.act&&g.act.t==="walk"&&!(isFinite(+g.act.x)&&isFinite(+g.act.y)))g.act=null;
      if(typeof g.x!=="number"||!(g.x>=0&&g.x<=1))g.x=0.5;if(typeof g.y!=="number"||!(g.y>=0&&g.y<=1))g.y=0.2;if(typeof g.dir!=="number"||!(g.dir>=0&&g.dir<=3))g.dir=2;
      if(old){g.x=Math.max(0.12,Math.min(0.88,g.x));g.y=Math.max(0.08,Math.min(0.92,g.y));}
      if(g.hold!==null&&g.hold!=="raw"&&g.hold!=="peeled")g.hold=null;
      if(!g.hold)g.held=0;else{var hn=Math.floor(+g.held||0);g.held=(hn>=1&&hn<=6)?hn:1;}
      var h=g.hold;g.job=h==="raw"?(g.job==="wash"||g.job==="peel"?g.job:"table"):(h==="peeled"?"chute":"pile");
      if(g.act){var at=g.act,wt=at.t==="walk"?at.then:null;
        var walkOk=["grab","peel","drop","eat","nap","sweep","wash","watch","water","tune"];
        if((at.t==="peel"&&h!=="raw")||(at.t==="drop"&&h!=="peeled")||(at.t==="wash"&&h!=="raw")||(at.t==="grab"&&h!==null)||(at.t==="sweep"&&h!==null)||((at.t==="watch"||at.t==="water"||at.t==="tune")&&h!==null)||
           (at.t==="walk"&&(walkOk.indexOf(wt)<0||(wt==="peel"&&h!=="raw")||(wt==="drop"&&h!=="peeled")||(wt==="wash"&&h!=="raw")||(wt==="grab"&&h!==null)||(wt==="sweep"&&h!==null)||((wt==="watch"||wt==="water"||wt==="tune")&&h!==null))))g.act=null;}
      if(g.peel!==0&&!(g.peel>0&&g.peel<=1))g.peel=0;
      g.pgot=Math.max(0,Math.min(5,Math.floor(+g.pgot||0)));
      if(g.act&&g.act.t==="walk"){var rr=route(g.x*RW,g.y*RH,g.act.x*RW,g.act.y*RH),wp=[];for(var ri=0;ri<rr.length-1;ri++)wp.push([rr[ri][0]/RW,rr[ri][1]/RH]);g.act.wp=wp;}
      var sim=new Sim(o);sim.rebuildObst();
      var want=POTS[o.box.pot],have=sim.total();
      if(from1||have!==want){if(have>want){o.pile=Math.max(0,o.pile-(have-want));}else o.pile+=want-have;}
      return sim;}catch(e){return null;}};
  Sim.fresh=function(seed){return new Sim(fresh(seed));};
  Sim.C=C;Sim.POTS=POTS;Sim.BOX=BOX;Sim.PACE=PACE;Sim.SPOT=SPOT;Sim.SPD=SPD;Sim.DRN=DRN;Sim.GEO=GEO;Sim.OBST=OBST;Sim.RW=RW;Sim.RH=RH;
  Sim.COMMANDS=COMMANDS;Sim.UPS=UPS;Sim.STYLE=STYLE;Sim.ITEMS=ITEMS;Sim.ITEMI=ITEMI;Sim.LEVEL_PRICE=LEVEL_PRICE;Sim.SPEED_NAME=SPEED_NAME;Sim.FIXED=FIXED;Sim.TOOLS=TOOLS;Sim.PLACEABLES=PLACEABLES;Sim.STARTER=STARTER;Sim.isTool=isTool;Sim.isPlaceable=isPlaceable;Sim.tableKids=tableKids;Sim.bedside=bedside;Sim.spill=spill;Sim.route=route;Sim.INFL=function(){return INF;};Sim.defaultPlace=defaultPlace;
  return Sim;
})();
if(typeof module!=="undefined")module.exports=PPSim;
