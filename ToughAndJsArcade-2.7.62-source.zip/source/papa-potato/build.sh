#!/bin/bash
# Build papa-potato-0.4.1.html from src/ (single file, no deps).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
{
  cat src/head.html
  echo "<script>"
  cat src/sim.js
  echo
  cat src/sprites04.js
  echo
  cat src/game.js
  echo "</script>"
  echo "</body></html>"
} > out/papa-potato-0.4.1.html
node -e 'const fs=require("fs");const t=fs.readFileSync("out/papa-potato-0.4.1.html","utf8");const m=t.match(/<script>([\s\S]*)<\/script>/);if(!m)throw new Error("no script");new Function(m[1]);console.log("syntax ok",t.length,"bytes")'
