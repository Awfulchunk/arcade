# Papa Potato 0.4 source (Tough & J's Arcade 2.7.61) — GPL-3.0
- game/: the cartridge. `build.sh` joins head.html + sim.js (levels, shop, work line, decorations, carry bag, save v4 with v3/v2/v1 migration) + sprites04.js + game.js (renderer, side rails outside the room, zoom/pan, editor, HUD, shop, handbook) into papa-potato-0.4.html. papa-potato-0.3.html, papa-potato-0.2.html and papa-potato-0.1-frozen.html are the older versions (slots papa-potato:v03 / v02 / v01).
- arcade-2.7.61/: assemble the new cartridge into the live 2.7.59 bundle (every other cartridge byte-identical; `papa-potato:latest` replaced, `papa-potato:v03` added), WebView-83 emulator script.
- tests/: t-04.cjs — mechanics, visuals/GUI (including rails-outside-room at 360x800 and 320x568), commands, arcade, buff, A03s perf.
- old-webview/: the WebView 83 legacy transform. android-app/: the APK wrapper (no Java changes since 2.7.56; AndroidManifest version bump only).
- No signing keys are included. Papa Potato has no secrets and no Latch code.
