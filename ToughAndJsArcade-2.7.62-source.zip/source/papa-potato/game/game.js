/* ===== Papa Potato 0.4 — renderer, HUD, zoom/pan, room editor, shop + help, save v4 (migrates v3) ===== */
(function(){
"use strict";
var SAVE_KEY="papaPotato.save.v4",KEY_V3="papaPotato.save.v3",KEY_V2="papaPotato.save.v2",KEY_V1="papaPotato.save.v1";   /* older keys are only ever READ */
var C=PPSim.C,BOX=PPSim.BOX,SPOT=PPSim.SPOT,PACE=PPSim.PACE,GEO=PPSim.GEO,RW=PPSim.RW,RH=PPSim.RH,CMDS=PPSim.COMMANDS,UPS=PPSim.UPS,STYLE=PPSim.STYLE,SPD=PPSim.SPD,POTS=PPSim.POTS;
var sim=null;
var migrated=false;
/* 0.4 save first; else carry over a 0.3 / 0.2 / 0.1 save (those keys are never written). */
function loadGame(){var s=null;try{var raw=localStorage.getItem(SAVE_KEY);if(raw)s=PPSim.load(raw);}catch(e){}
  if(!s){try{var o3=localStorage.getItem(KEY_V3);if(o3){s=PPSim.load(o3);if(s)migrated="0.3";}}catch(e){}}
  if(!s){try{var o2=localStorage.getItem(KEY_V2);if(o2){s=PPSim.load(o2);if(s)migrated="0.2";}}catch(e){}}
  if(!s){try{var o1=localStorage.getItem(KEY_V1);if(o1){s=PPSim.load(o1);if(s)migrated="0.1";}}catch(e){}}
  return s||PPSim.fresh();}
var lastSave=0;
function saveGame(){if(!sim)return false;try{localStorage.setItem(SAVE_KEY,sim.serialize());lastSave=performance.now();return true;}catch(e){return false;}}
sim=loadGame();

/* ---------- art: Swarm-style DPR. Fit by default; +/- zoom and arrow pan live in side rails outside the room (Jay t1065). ---------- */
var DETAIL=1.10;      /* ~10% finer pixel grid (t1014) */
var cv=document.getElementById("cv"),ctx=cv.getContext("2d",{alpha:false});
ctx.imageSmoothingEnabled=false;
var W=0,H=0,SC=1,DPR=1,k=1,camX=0,camY=0,offX=0,offY=0,roomW=RW,roomH=RH,WALL=GEO.WALL;
var ZOOM_STEPS=[0.75,1,1.25,1.5,2,2.5,3],zoomI=1,panX=0,panY=0,editMode=false,dragId=null;
var OUT="#1a1410",ANIM_F=0,ANIM_T=0;
var staticLayer=null,gx=0,gy=0,table=null,chute=null,playRect=null;
var pops=[];
var pileLayer=null,pileKey=-1,messLayer=null,messKey="",POS=[],ORDER=[],MESSPOS=[],SPR=null,SPRS=null,PEELSPR=null,TIER=[],renders={pile:0,mess:0};
var MAXVIS=400,PILEMAX=POTS[POTS.length-1],LIFT=1.1,MESSVIS=140;
function R(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y,Math.max(0.5,w),Math.max(0.5,h));}
function wx(x){return Math.round((x-camX)*k);}
function wy(y){return Math.round((y-camY)*k);}
function ws(s){return Math.max(0.6,s*k);}
function wr(x,y,w,h,c){var x0=wx(x),y0=wy(y),x1=wx(x+w),y1=wy(y+h);R(x0,y0,Math.max(0.6,x1-x0),Math.max(0.6,y1-y0),c);}
function oval(cx,cy,rw,rh,c){rw=Math.max(0.35,rw);rh=Math.max(0.35,rh);ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(cx,cy,rw,rh,0,0,6.283185);ctx.fill();}
function disc(cx,cy,rw,rh,c,out){if(out!==null)oval(cx,cy,rw+0.7,rh+0.7,out||OUT);oval(cx,cy,rw,rh,c);}
function blob(x,y,w,h,r,c,out){r=Math.max(0.4,r||1);ctx.fillStyle=out||OUT;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x-0.7,y-0.7,w+1.4,h+1.4,r+0.7);else ctx.rect(x-0.7,y-0.7,w+1.4,h+1.4);ctx.fill();ctx.fillStyle=c;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x,y,w,h,r);else ctx.rect(x,y,w,h);ctx.fill();}
function softShadow(cx,cy,rx,ry){rx=rx||10;ry=ry||7;var g=ctx.createRadialGradient(cx,cy,0,cx,cy,Math.max(rx,ry));g.addColorStop(0,"rgba(0,0,0,0.28)");g.addColorStop(1,"rgba(0,0,0,0)");ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(cx,cy,rx,ry,0,0,6.283185);ctx.fill();}
function tickAnim(now){ANIM_T=now/1000;ANIM_F=((now/125)|0)%4;}
function resetXform(){ctx.setTransform(DPR,0,0,DPR,0,0);ctx.imageSmoothingEnabled=false;}
function blitLayer(layer){if(!layer)return;ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(layer,0,0);resetXform();}
function srng(n){var s=(n*1664525+1013904223)>>>0;return (s%10000)/10000;}
var TAGDEF=[
  {id:"tagShip",x:GEO.ship.x+20,y:15,al:"l"},
  {id:"tagRet",x:GEO.ret.mouthX+3,y:GEO.ret.y-13,al:"c"},
  {id:"tagTable",x:(GEO.table.x0+GEO.table.x1)/2,y:GEO.table.y0-6,al:"c"},
  {id:"tagBed",x:GEO.mat.x,y:GEO.mat.y-GEO.mat.h/2-3,al:"c"},
  {id:"tagFood",x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:GEO.cooler.y0+2.5,al:"c"},
  {id:"tagSeat",x:GEO.stool.x,y:GEO.stool.y+9,al:"c"},
  {id:"tagPot",x:GEO.pile.cx,y:GEO.pile.base+3,al:"c"},
  {id:"tagPeeler",x:GEO.peeler.x,y:GEO.peeler.y-13,al:"c"},
  {id:"tagLine",x:GEO.outBeltX0+10,y:GEO.outBeltY-8,al:"c"},
  {id:"tagSink",x:GEO.sink.x,y:GEO.sink.y-10,al:"c"},
  {id:"tagTV",x:GEO.tv.x,y:GEO.tv.y-12,al:"c"}];
function fitK(){return Math.min(W/RW,H/RH)*0.985;}
function clampPan(){
  var maxX=Math.max(0,(RW*k-W)/(2*k)+10), maxY=Math.max(0,(RH*k-H)/(2*k)+10);
  panX=Math.max(-maxX,Math.min(maxX,panX));
  panY=Math.max(-maxY,Math.min(maxY,panY));
}
function applyCam(){
  k=fitK()*ZOOM_STEPS[zoomI];
  clampPan();
  offX=(W-RW*k)/2-panX*k;offY=(H-RH*k)/2-panY*k;
  camX=-offX/k;camY=-offY/k;
}
function syncZoomLabel(){
  var el=document.getElementById("zoomLabel");
  if(el)el.textContent=zoomI===1&&Math.abs(panX)<0.01&&Math.abs(panY)<0.01?"FIT":Math.round(ZOOM_STEPS[zoomI]*100)+"%";
}
function zoomBy(d){
  zoomI=Math.max(0,Math.min(ZOOM_STEPS.length-1,zoomI+d));
  applyCam();staticLayer=null;pileLayer=null;messLayer=null;if(playRect)placeTags();syncZoomLabel();
}
function panBy(dx,dy){panX+=dx;panY+=dy;applyCam();if(playRect)placeTags();syncZoomLabel();}
function resetView(){zoomI=1;panX=0;panY=0;applyCam();staticLayer=null;pileLayer=null;messLayer=null;if(playRect)placeTags();syncZoomLabel();}
function layout(){
  var r=document.getElementById("play").getBoundingClientRect();playRect=r;
  var cssW=Math.max(1,r.width),cssH=Math.max(1,r.height);
  DPR=Math.min(2,window.devicePixelRatio||1);SC=1;
  W=cssW;H=cssH;
  cv.style.width=W+"px";cv.style.height=H+"px";
  cv.width=Math.max(1,Math.round(W*DPR));cv.height=Math.max(1,Math.round(H*DPR));
  resetXform();
  applyCam();
  gx=GEO.table.x0+(GEO.table.x1-GEO.table.x0)/2;gy=GEO.table.y0+(GEO.table.y1-GEO.table.y0)/2;
  table={x:gx,y:gy,w:GEO.table.x1-GEO.table.x0,h:GEO.table.y1-GEO.table.y0};
  chute={cx:GEO.ship.x,mouthW:GEO.ship.mouth*2,lip:GEO.ship.lip};
  staticLayer=null;pileLayer=null;messLayer=null;buildPile();buildMess();buildSprites();placeTags();
}
function clampTag(el,play,pad){
  var r=el.getBoundingClientRect();var left=parseFloat(el.style.left)||0,top=parseFloat(el.style.top)||0;
  var centered=el.style.transform&&el.style.transform.indexOf("translateX(-50%)")>=0;
  if(centered){var half=r.width/2;left=Math.max(pad+half,Math.min(play.width-pad-half,left));}
  else{left=Math.max(pad,Math.min(play.width-pad-r.width,left));}
  top=Math.max(pad,Math.min(play.height-pad-(r.height||12),top));
  el.style.left=Math.round(left)+"px";el.style.top=Math.round(top)+"px";
}
function placeTags(){var play=playRect;
  for(var i=0;i<TAGDEF.length;i++){var d=TAGDEF[i],el=document.getElementById(d.id);if(!el)continue;
    var px=(wx(d.x)/W)*play.width,py=(wy(d.y)/H)*play.height;
    el.style.transform=d.al==="c"?"translateX(-50%)":"none";el.style.left=Math.round(px)+"px";
    var hh=el.getBoundingClientRect().height||12;var top=Math.round(Math.max(3,Math.min(play.height-hh-3,py-hh/2)));el.style.top=top+"px";clampTag(el,play,4);}}
var labelsUntil=0;
function showLabels(ms,force){labelsUntil=force?performance.now()+ms:Math.max(labelsUntil,performance.now()+ms);}
var labelsOn=null;
function updateLabels(){var on=performance.now()<labelsUntil&&!ovlMode;if(on===labelsOn)return;labelsOn=on;
  for(var i=0;i<TAGDEF.length;i++){var el=document.getElementById(TAGDEF[i].id);if(el)el.className="tag"+(on?"":" off");}}
function potato(x,y,s,peeled,flip,spots,pal){
  var body=pal||(peeled?["#a88830","#c8a848","#e8c868","#f0d890"]:["#4a2810","#6a4020","#8a5a28","#c48a48"]);
  var out=body[0],dk=body[1],md=body[2],hi=body[3];
  var hw=Math.max(1.2,s),hh=Math.max(0.9,s*0.72),fx=flip?1:-1;
  oval(x+0.7,y+0.7,hw+0.3,hh+0.2,"rgba(0,0,0,0.22)");
  disc(x,y,hw,hh,md,out);
  oval(x+fx*hw*0.16,y-hh*0.18,hw*0.62,hh*0.5,hi);
  oval(x+fx*hw*0.28,y-hh*0.32,hw*0.28,hh*0.22,peeled?"#fff3a0":hi);
  if(!peeled){oval(x+fx*hw*0.12,y+hh*0.05,Math.max(0.5,hw*0.12),Math.max(0.5,hh*0.12),dk);
    oval(x-fx*hw*0.28,y+hh*0.18,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),out);
    if(s>3)oval(x+fx*hw*0.35,y-hh*0.08,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),"#6a4020");}
  else if(spots){var sp=[[-0.45,-0.25],[0.5,0.22],[0,0.45],[-0.28,0.28],[0.3,-0.3]];
    for(var i=0;i<Math.min(spots,sp.length);i++)oval(x+sp[i][0]*hw,y+sp[i][1]*hh,Math.max(0.4,hw*0.1),Math.max(0.4,hh*0.1),"#6a4020");}
}
/* ---------- room pieces ---------- */
function drawFloor(){R(0,0,W,H,"#2a2820");var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);var fw=Math.max(1,ix2-ix),fh=Math.max(1,iy2-iy);
  R(ix,iy,fw,fh,"#9a947c");var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,"#8e876e");}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?"#7a7460":"#a8a288");}
  ctx.strokeStyle="rgba(60,55,40,0.28)";ctx.lineWidth=1;ctx.beginPath();
  for(var x2=ix;x2<=ix+fw;x2+=step){ctx.moveTo(x2+0.5,iy);ctx.lineTo(x2+0.5,iy+fh);}for(var y2=iy;y2<=iy+fh;y2+=step){ctx.moveTo(ix,y2+0.5);ctx.lineTo(ix+fw,y2+0.5);}ctx.stroke();
  /* 0.3: the dashed centre stripe had no use and is hidden (drawCentreStripe, not called) */
  var lcx=wx(gx),lcy=wy(gy);for(var j=0;j<7;j++){ctx.fillStyle="rgba(255,240,180,"+(0.07-j*0.009)+")";ctx.beginPath();ctx.ellipse(lcx,lcy,ws(22+j*6),ws(15+j*4.5),0,0,6.28);ctx.fill();}}
function drawCentreStripe(){var cx=wx(roomW*0.5);for(var y3=wy(WALL+8);y3<wy(roomH*0.72);y3+=Math.max(5,ws(5)))R(cx-ws(3.5),y3,ws(7),1,"#8a846c");}

function drawWalls(){var x0=wx(0),y0=wy(0),x1=wx(roomW),y1=wy(roomH);var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);
  R(x0,y0,x1-x0,iy-y0,"#3a3830");R(x0,iy2,x1-x0,y1-iy2,"#3a3830");R(x0,iy,ix-x0,iy2-iy,"#3a3830");R(ix2,iy,x1-ix2,iy2-iy,"#3a3830");
  var t=Math.max(2,ws(2.4));R(x0,y0,x1-x0,t,"#1a1814");R(x0,y1-t,x1-x0,t,"#1a1814");R(x0,y0,t,y1-y0,"#1a1814");R(x1-t,y0,t,y1-y0,"#1a1814");
  var bs=Math.max(4,ws(5));for(var i=0;i<80;i++){var side=i%4,bx,by;
    if(side===0){bx=x0+t+((i*11)%Math.max(2,x1-x0-t*2));by=y0+t+((i*5)%Math.max(2,iy-y0-t));}
    else if(side===1){bx=x0+t+((i*13)%Math.max(2,x1-x0-t*2));by=iy2+((i*7)%Math.max(2,y1-iy2-t));}
    else if(side===2){bx=x0+t+((i*3)%Math.max(2,ix-x0-t));by=iy+((i*17)%Math.max(2,iy2-iy));}
    else{bx=ix2+((i*3)%Math.max(2,x1-ix2-t));by=iy+((i*19)%Math.max(2,iy2-iy));}
    R(bx,by,bs,Math.max(2,ws(2.2)),(i%3===0)?"#4a4638":"#323028");}
  R(ix,iy,ix2-ix,1,"#5a5648");R(ix,iy2-1,ix2-ix,1,"#2a2820");R(ix,iy,1,iy2-iy,"#5a5648");R(ix2-1,iy,1,iy2-iy,"#2a2820");
  R(ix+1,iy+1,ws(3),iy2-iy-2,"rgba(0,0,0,0.18)");R(ix+1,iy+1,ix2-ix-2,ws(2),"rgba(0,0,0,0.14)");}
function drawChuteBase(){var cx=wx(chute.cx),mouthW=ws(chute.mouthW),y0=wy(2),yLip=wy(chute.lip),wallInner=wy(WALL),y1=yLip;
  for(var y=y0;y<=y1;y++){var t=(y-y0)/Math.max(1,y1-y0);var half=Math.round((mouthW*0.28)+(mouthW*0.22)*t);
    R(cx-half-2,y,(half+2)*2,1,"#3a4038");R(cx-half,y,half*2,1,t<0.18?"#8a9088":"#5a6058");var ih=Math.max(2,half-3);
    if(y>y0+2&&y>wallInner-2)R(cx-ih,y,ih*2,1,"#12141a");else if(y>y0+2)R(cx-ih,y,ih*2,1,"#1a1c18");}
  var half0=Math.round(mouthW*0.28),half1=Math.round(mouthW*0.50);
  R(cx-half0-2,y0,(half0+2)*2,2,"#8a9088");R(cx-half0-1,y0,(half0+1)*2,1,"#c0c8c0");R(cx-half0,y0+1,2,2,"#c0c8c0");R(cx+half0,y0+1,2,2,"#c0c8c0");
  R(cx-(half1-2),y1-1,2,2,"#8a9088");R(cx+(half1-4),y1-1,2,2,"#8a9088");R(cx-half1,y1,half1*2,2,"#4a5048");R(cx-half1,y1,half1*2,1,"#7a8478");
  var ss=[-0.7,-0.35,0.35,0.7];for(var i=0;i<4;i++)R(cx+Math.round(half1*ss[i])-1,y1,2,2,"#9aa49a");
  }
/* ---- HIDDEN PROPS (never called; kept in code, not deleted) ---- */
function drawLamp(){var lx=wx(gx-roomW*0.18),ly=wy((chute.lip+(table.y-table.h/2))*0.5);var r=Math.max(4,ws(4.5));
  oval(lx,ly,r+1,r+1,"#2a2a24");oval(lx,ly,r,r,"#3a3a32");oval(lx,ly,r-2,r-2,"#c8c070");oval(lx,ly,Math.max(1,r-3),Math.max(1,r-3),"#fff3a0");
  R(lx-1,ly-r-Math.max(2,ws(2.2)),2,Math.max(2,ws(2.2)),"#2a2a24");R(lx-2,ly-r-Math.max(2,ws(2.2)),4,1,"#3a3a32");}
function drawDrain(cx,cy,rad){var x=wx(cx),y=wy(cy),r=Math.max(3,ws(rad));oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#5a6058");oval(x,y,r-1,r-1,"#1a1c18");oval(x,y,Math.max(1,r-2),Math.max(1,r-2),"#12141a");
  R(x-(r-2),y,(r-2)*2,1,"#5a6058");R(x,y-(r-2),1,(r-2)*2,"#5a6058");R(x-(r-2),y-Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");R(x-(r-2),y+Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");}
function drawBucket(cx,cy,rad,inner){var x=wx(cx),y=wy(cy),r=Math.max(4,ws(rad));oval(x+1,y+1,r,r,"rgba(0,0,0,0.28)");oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#6a7068");oval(x,y,r-1,r-1,"#4a5048");
  oval(x,y,Math.max(2,r-2),Math.max(2,r-2),inner||"#2a2c28");R(x-1,y-r,2,1,"#c0c8c0");R(x-(r-1),y-1,1,2,"#8a9088");R(x-Math.max(2,r-2),y-r-Math.max(1,ws(1.2)),Math.max(4,(r-2)*2),Math.max(1,ws(1.2)),"#3a2a20");}
function drawPeelBin(cx,cy,bw,bh){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#3a2a18");R(x+1,y+1,w-2,h-2,"#5a4030");R(x+2,y+2,w-4,h-4,"#2a1c10");R(x+1,y+1,w-2,1,"#8a6a40");
  for(var i=0;i<9;i++)R(x+3+srng(i*3)*(w-8),y+3+srng(i*7)*(h-8),Math.max(2,ws(2.2)),Math.max(1,ws(1.2)),i%2?"#e8c070":"#d4a04a");R(x+2,y+h-2,w-4,1,"#2a1c10");}
function drawTable(){var tw=table.w,th=table.h,x=wx(table.x-tw/2),y=wy(table.y-th/2),w=ws(tw),h=ws(th);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  oval(wx(gx)-ws(3),wy(gy)-ws(6),ws(4),ws(2.5),"rgba(80,50,20,0.25)");
  /* old peels on the table */
  var tx=wx(gx),ty=wy(gy);R(tx+ws(6),ty-ws(9),2,1,"#e8c070");R(tx-ws(9),ty-ws(8),2,2,"#d4a04a");R(tx-ws(6),ty-ws(11),2,1,"#f5e0a8");R(tx+ws(9),ty-ws(6),1,1,"#e8c070");}
function drawSack(cx,cy,bw,bh,rot,spill){var x=wx(cx),y=wy(cy),rw=Math.max(4,ws(bw/2)),rh=Math.max(3,ws(bh/2));
  oval(x+1,y+1,rw,rh,"rgba(0,0,0,0.25)");oval(x,y,rw+1,rh+1,"#4a4028");oval(x,y,rw,rh,"#8a7a50");oval(x-1,y-1,Math.max(2,rw-2),Math.max(2,rh-2),"#9a8a60");oval(x-2,y-2,Math.max(1,rw-4),Math.max(1,rh-4),"#a89868");
  R(x-Math.max(1,rw-3),y,Math.max(2,(rw-3)*2),1,"#6a5a38");R(x,y-Math.max(1,rh-3),1,Math.max(2,(rh-3)*2),"#6a5a38");
  if(rot==="n"){R(x-Math.max(2,ws(2)),y-rh-ws(1.5),Math.max(4,ws(4)),Math.max(2,ws(2.2)),"#6a5a38");R(x-1,y-rh-ws(2),2,Math.max(2,ws(1.5)),"#c4b480");}
  else if(rot==="w"){R(x-rw-ws(1.5),y-Math.max(2,ws(2)),Math.max(2,ws(2.2)),Math.max(4,ws(4)),"#6a5a38");R(x-rw-ws(2),y-1,Math.max(2,ws(1.5)),2,"#c4b480");}
  if(spill){potato(x+rw-1,y+rh-1,Math.max(2,ws(2.6)),false,true);potato(x+rw+ws(2),y+1,Math.max(2,ws(2.4)),false,false);}}
function drawCrate(cx,cy,bw,bh,open,lid){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,1,"#8a6a40");R(x,y,1,h,"#6a4a28");R(x,y+h-1,w,1,"#3a200c");R(x+w-1,y,1,h,"#3a200c");
  R(x+1,y+1,w-2,h-2,"#6a4a28");var sl=Math.max(2,ws(2.4));for(var i=0;i<Math.max(2,Math.floor((h-2)/sl));i++)R(x+1,y+1+i*sl,w-2,1,i%2?"#8a6a40":"#5a3a20");
  var b=Math.max(2,ws(2));R(x,y,b,b,"#3a2a18");R(x+w-b,y,b,b,"#3a2a18");R(x,y+h-b,b,b,"#3a2a18");R(x+w-b,y+h-b,b,b,"#3a2a18");
  if(open){var inset=Math.max(2,ws(2));R(x+inset,y+inset,w-inset*2,h-inset*2,"#2a1c10");potato(x+Math.round(w*0.35),y+Math.round(h*0.45),Math.max(2,ws(2.8)),false,false);potato(x+Math.round(w*0.62),y+Math.round(h*0.4),Math.max(2,ws(2.5)),false,true);potato(x+Math.round(w*0.5),y+Math.round(h*0.65),Math.max(2,ws(2.6)),false,false);}
  else if(lid){R(x+1,y+1,w-2,h-2,"#7a5a30");R(x+2,y+Math.round(h*0.45),w-4,1,"#4a3018");R(x+Math.round(w*0.5)-1,y+2,2,h-4,"#5a3a20");}}
function drawShelf(){var x=WALL,y1=roomH*0.20,y2=roomH*0.62,depth=Math.max(5,WALL*0.7);
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x+depth-0.8,y1,0.8,y2-y1,"#3a200c");for(var i=1;i<=4;i++)wr(x,y1+(y2-y1)*i/5,depth,0.7,"#5a3a20");
  var spots=[0.24,0.30,0.36,0.44,0.50,0.56],kinds=["jar","tin","jar","bag","tin","jar"];
  for(var j=0;j<spots.length;j++){var ix=wx(x+depth*0.55),iy=wy(roomH*spots[j]);
    if(kinds[j]==="jar"){oval(ix,iy,ws(1.8),ws(1.8),"#6a3030");oval(ix,iy,ws(1.2),ws(1.2),"#8a4840");R(ix-1,iy-ws(1.8),2,1,"#c4b480");}
    else if(kinds[j]==="tin"){R(ix-ws(1.8),iy-ws(1.4),ws(3.6),ws(2.8),"#5a6058");R(ix-ws(1.8),iy-ws(1.4),ws(3.6),1,"#8a9088");}
    else oval(ix,iy,ws(2.0),ws(1.6),"#6a5a38");}}
function drawToolRack(){var depth=Math.max(4.5,WALL*0.65),x=roomW-WALL-depth,y1=WALL+2,y2=roomH*0.27;
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x,y1+0.8,0.7,y2-y1-1.6,"#5a3a20");
  for(var i=0;i<6;i++){var yy=y1+2+(y2-y1-4)*(i+0.5)/6,hx=wx(x),hy=wy(yy);R(hx-1,hy,2,2,"#8a9088");
    if(i%2===0){R(hx-ws(5.5),hy-1,ws(5.5),Math.max(2,ws(1.6)),"#3a2a20");R(hx-ws(10.5),hy-1,ws(5.2),Math.max(2,ws(1.4)),"#c8d0d8");R(hx-ws(10.5),hy-1,ws(5.2),1,"#e8eef4");}
    else{R(hx-ws(4.8),hy-1,ws(4.8),Math.max(2,ws(1.8)),"#4a3020");R(hx-ws(8.5),hy,ws(4.0),Math.max(1,ws(1.2)),"#c8d0d8");R(hx-ws(8.5),hy,1,Math.max(1,ws(1.2)),"#e8eef4");}}}
function drawPipes(){var x2=chute.cx-chute.mouthW*0.55;wr(WALL+1,WALL+1.4,x2-(WALL+1),2.6,"#4a5048");wr(WALL+1,WALL+1.4,x2-(WALL+1),0.8,"#7a8478");
  var fl=[WALL+4,(WALL+x2)*0.5,x2-3];for(var i=0;i<3;i++)wr(fl[i],WALL+0.7,1.6,4.0,"#6a7068");wr(WALL+1.0,WALL+1.0,3.2,3.2,"#5a6058");
  var px=wx(WALL+2.6),py=wy(WALL+8),r=Math.max(3,ws(3.2));oval(px,py,r+1,r+1,"#3a4038");oval(px,py,r,r,"#6a7068");oval(px,py,r-2,r-2,"#2a2e2a");oval(px,py,Math.max(1,r-3),Math.max(1,r-3),"#12141a");
  var vx=wx(WALL+7),vy=wy(WALL+2.6);oval(vx,vy,ws(2.2),ws(2.2),"#8a9088");R(vx-ws(1.6),vy,ws(3.2),1,"#c0c8c0");R(vx,vy-ws(1.6),1,ws(3.2),"#c0c8c0");
  wr(roomW-WALL-8,WALL+1.4,7,2.4,"#4a5048");wr(roomW-WALL-8,WALL+1.4,7,0.7,"#7a8478");wr(roomW-WALL-9,WALL+0.8,1.6,3.6,"#6a7068");}
function drawMachinePad(cx,cy,bw,bh,kind){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#3a4038");R(x,y,w,1,"#8a9088");R(x,y,1,h,"#6a7068");R(x,y+h-1,w,1,"#2a2e2a");R(x+w-1,y,1,h,"#2a2e2a");R(x+2,y+2,w-4,h-4,"#4a5048");
  var inx=x+Math.max(3,ws(2.5)),iny=y+Math.max(3,ws(2.5)),inw=w-Math.max(6,ws(5)),inh=h-Math.max(6,ws(5));R(inx,iny,inw,inh,"#323830");
  for(var i=0;i<inw;i+=2){R(inx+i,iny,1,1,"#6a7068");R(inx+i,iny+inh-1,1,1,"#2a2e2a");}
  var b=Math.max(1,ws(1.3)),bolts=[[x+2,y+2],[x+w-3-b,y+2],[x+2,y+h-3-b],[x+w-3-b,y+h-3-b]];for(var j=0;j<4;j++){R(bolts[j][0],bolts[j][1],b+1,b+1,"#8a9088");R(bolts[j][0],bolts[j][1],b,b,"#c0c8c0");}
  if(kind==="drum"){oval(x+w/2,y+h/2,ws(3.2),ws(3.2),"#2a2e2a");oval(x+w/2,y+h/2,ws(1.6),ws(1.6),"#1a1c18");}
  else if(kind==="slot")R(x+Math.round(w*0.25),y+Math.round(h*0.45),Math.round(w*0.5),Math.max(2,ws(2)),"#2a2e2a");}
function drawMat(){var cx=roomW*SPOT.mat.x+2,cy=roomH*SPOT.mat.y,mw=19,mh=9;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#5a2a2a");R(x+1,y+1,w-2,h-2,"#8a3a34");
  for(var i=2;i<w-2;i+=3)R(x+i,y+1,1,h-2,"#a04a40");R(x+1,y+Math.round(h/2),w-2,1,"#6a2a28");
  R(x,y,w,1,"#b06a50");for(var j=0;j<h;j+=2){R(x-1,y+j,1,1,"#c4a070");R(x+w,y+j,1,1,"#c4a070");}
  /* pillow at the west end */
  R(x+2,y+2,Math.max(3,ws(4)),h-4,"#d8d0b8");R(x+2,y+2,Math.max(3,ws(4)),1,"#f0ead8");}
function drawCooler(){var cx=roomW*SPOT.food.x,cy=roomH*SPOT.food.y-8.5,bw=11,bh=8;var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#2a4a6a");R(x+1,y+1,w-2,h-2,"#3a6a9a");R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+Math.round(h*0.55),w-2,1,"#24405a");
  R(x+Math.round(w*0.3),y+Math.round(h*0.25),Math.round(w*0.4),Math.max(1,ws(1.4)),"#e8eef4");
  /* stool in front */
  oval(wx(cx+5.5),wy(cy+7),ws(2.2),ws(2.2),"#5a3a20");oval(wx(cx+5.5),wy(cy+7),ws(1.6),ws(1.6),"#8a6a40");}

/* ---- 0.3.1 redraw: every object he uses, machines-sheet detail, true top-down; labels unchanged ---- */
function drawShipChute(){
  /* 0.3.1: airport X-ray scanner + belt (static body). Moving slats and the lock lamp are drawn in drawShipAnim. */
  var cx=GEO.ship.x, wall=GEO.WALL, boxW=16, boxH=15, boxX0=cx-boxW/2, boxY0=wall, boxY1=boxY0+boxH;
  /* square scanner box, top-down: heavy housing, darker tunnel, lead curtains on the south mouth */
  wr(boxX0+0.6,boxY0+0.6,boxW,boxH,"rgba(0,0,0,0.32)");
  wr(boxX0,boxY0,boxW,boxH,"#3a4038");wr(boxX0+0.6,boxY0+0.6,boxW-1.2,boxH-1.2,"#5a6258");
  wr(boxX0+0.6,boxY0+0.6,boxW-1.2,1.2,"#9aa49a");wr(boxX0+0.6,boxY1-1.6,boxW-1.2,1,"#2a2c28");
  wr(boxX0,boxY0,0.8,boxH,"#8a9088");wr(boxX0+boxW-0.8,boxY0,0.8,boxH,"#2a2c28");
  /* tunnel / viewing window down the centre */
  wr(boxX0+3.2,boxY0+3,boxW-6.4,boxH-6.5,"#12141a");wr(boxX0+3.6,boxY0+3.4,boxW-7.2,boxH-7.3,"#1a2030");
  wr(boxX0+3.6,boxY0+3.4,boxW-7.2,0.6,"#3a5068");
  /* corner bolts */
  var bolts=[[0.8,0.8],[boxW-1.6,0.8],[0.8,boxH-1.6],[boxW-1.6,boxH-1.6]];
  for(var i=0;i<bolts.length;i++){wr(boxX0+bolts[i][0],boxY0+bolts[i][1],1.1,1.1,"#2a2c28");wr(boxX0+bolts[i][0]+0.2,boxY0+bolts[i][1]+0.2,0.7,0.7,"#c0c8c0");}
  /* lead-curtain strips at the south mouth */
  var mx0=cx-4.2, mw=8.4;for(var s=0;s<6;s++)wr(mx0+s*1.4,boxY1-1.2,1.1,2.2,s%2?"#2a2c28":"#3a4038");
  /* hazard lip just south of the mouth */
  var bl=1.6, hy=boxY1+0.4, hx0=cx-5;for(var x=0,n=0;x<10;x+=bl,n++)wr(hx0+x,hy,bl,1.1,n%2?"#2a2a24":"#e0b020");
  /* belt bed from the mouth down toward the drop stand (rails + deck; slats are animated) */
  var beltW=9, beltX0=cx-beltW/2, beltY0=boxY1+1.4, beltY1=GEO.ship.lip+6.5;
  wr(beltX0-0.8,beltY0,beltW+1.6,beltY1-beltY0,"#2a2c28");
  wr(beltX0,beltY0,beltW,beltY1-beltY0,"#4a4a44");
  wr(beltX0,beltY0,beltW,0.5,"#6a6a60");
  wr(beltX0-0.8,beltY0,0.8,beltY1-beltY0,"#6a7068");wr(beltX0+beltW,beltY0,0.8,beltY1-beltY0,"#3a4038");
  /* roller caps at the south end */
  wr(beltX0-1,beltY1-0.8,beltW+2,1.4,"#3a4038");wr(beltX0-0.6,beltY1-0.5,beltW+1.2,0.8,"#8a9088");
  /* small side panel on the east face of the box */
  wr(boxX0+boxW,boxY0+4,2.4,6,"#3a4038");wr(boxX0+boxW,boxY0+4.3,2,1.1,"#1a1c18");wr(boxX0+boxW+0.4,boxY0+7,1.4,1.4,"#2a2010");
  }
function drawDoor(){
  /* giant industrial door, west of the scanner, flush to the north wall. Decoration only. */
  var x0=17,y0=GEO.WALL-0.6,w=20,h=18.5;
  wr(x0+0.8,y0+0.8,w,h,"rgba(0,0,0,0.34)");
  wr(x0,y0,w,h,"#2a2c30");wr(x0+0.6,y0+0.6,w-1.2,h-1.2,"#4a5058");
  wr(x0+0.6,y0+0.6,w-1.2,1.4,"#8a9098");wr(x0,y0,0.8,h,"#6a7078");wr(x0+w-0.8,y0,0.8,h,"#1a1c20");
  /* centre seam + two leaves */
  wr(x0+w/2-0.4,y0+0.6,0.8,h-1.2,"#2a2c30");wr(x0+w/2-0.15,y0+0.6,0.3,h-1.2,"#8a9098");
  /* rivet grid */
  for(var ry=2;ry<h-1.5;ry+=3.2)for(var rx=1.6;rx<w-1.2;rx+=3.2){
    if(Math.abs(rx-w/2)<1.2)continue;
    wr(x0+rx,y0+ry,1.1,1.1,"#1a1c20");wr(x0+rx+0.2,y0+ry+0.15,0.7,0.7,"#c0c8c0");}
  /* hinges on the west edge */
  for(var i=0;i<3;i++){var hy=y0+3+i*5.5;wr(x0-1.2,hy,2.2,2.2,"#3a4038");wr(x0-0.9,hy+0.3,1.6,1.6,"#8a9088");}
  /* heavy bar lock + padlock at the seam */
  wr(x0+w/2-4,y0+h*0.58,8,2.2,"#2a2018");wr(x0+w/2-3.6,y0+h*0.58+0.3,7.2,1.6,"#5a4a38");
  var px=x0+w/2,py=y0+h*0.36;
  wr(px-1.4,py-3.6,0.8,2.4,"#c0c8c0");wr(px+0.6,py-3.6,0.8,2.4,"#c0c8c0");wr(px-1.4,py-3.8,2.8,0.8,"#d0d8d0");
  wr(px-2.4,py-1.2,4.8,4.0,"#1a1410");wr(px-2.1,py-0.9,4.2,3.4,"#6a5a40");wr(px-1.7,py-0.5,3.4,2.6,"#8a7a58");
  wr(px-0.55,py+0.35,1.1,1.5,"#1a1410");wr(px-0.35,py+0.55,0.7,0.7,"#c8b890");
  /* lamp housing on the north (top) edge — the bulb is drawn pulsing in drawShipAnim */
  wr(x0+w/2-2,y0-2.2,4,2.4,"#3a4038");wr(x0+w/2-1.6,y0-1.8,3.2,1.6,"#2a2c28");
  /* bigger LOCKED plate + 3x5 bitmap letters in world units */
  wr(x0+w/2-6.6,y0+h-5.4,13.2,4.2,"#1a0808");wr(x0+w/2-6.2,y0+h-5.1,12.4,3.6,"#4a1818");wr(x0+w/2-5.8,y0+h-4.8,11.6,3.0,"#6a2020");
  var glyphs={L:["100","100","100","100","111"],O:["111","101","101","101","111"],C:["111","100","100","100","111"],K:["101","101","110","101","101"],E:["111","100","110","100","111"],D:["110","101","101","101","110"]};
  var word="LOCKED",uu=0.48,gap=0.26,tw=6*(3*uu+gap)-gap,lx=x0+w/2-tw/2,ly=y0+h-4.55;
  for(var gi=0;gi<word.length;gi++){var rows=glyphs[word[gi]],bx=lx+gi*(3*uu+gap);
    for(var r=0;r<5;r++)for(var c=0;c<3;c++)if(rows[r][c]==="1")wr(bx+c*uu,ly+r*uu,uu*0.9,uu*0.9,"#ffd0d8");}
  }
function drawShipAnim(now){
  var cx=GEO.ship.x, boxY1=GEO.WALL+15, beltX0=cx-4.5, beltW=9, beltY0=boxY1+1.4, beltY1=GEO.ship.lip+6.5;
  var period=3.2, off=(ANIM_F/4)*period;
  /* slats travel north (toward the scanner), 4 discrete frames */
  for(var y=beltY0-period+off;y<beltY1;y+=period){
    var y0=Math.max(beltY0,y), y1=Math.min(beltY1,y+1.3);if(y1<=y0)continue;
    wr(beltX0+0.3,y0,beltW-0.6,y1-y0,"#6a6a58");wr(beltX0+0.3,y0,beltW-0.6,0.35,"#8a8a70");}
  /* scanner window glow, stepped with the frame clock */
  var g=[0.08,0.12,0.16,0.11][ANIM_F];ctx.globalAlpha=g;wr(cx-4.6,GEO.WALL+3.4,9.2,8.2,"#40a0ff");ctx.globalAlpha=1;
  /* door lock lamp: 4-frame red pulse (LOCKED) */
  var dx=17+10, dy=GEO.WALL-0.6-1.1, pulse=[0.35,0.65,1,0.55][ANIM_F];
  ctx.globalAlpha=0.30+0.50*pulse;oval(wx(dx),wy(dy),ws(2.2),ws(1.6),"#ff2030");
  ctx.globalAlpha=0.65+0.35*pulse;oval(wx(dx),wy(dy),ws(1.3),ws(1.0),"#ff8090");
  ctx.globalAlpha=1;oval(wx(dx),wy(dy),ws(0.6),ws(0.5),"#ffe8e8");
  }
function drawCoolerHum(){
  var G=GEO.cooler,lx=wx(G.x1)-ws(2.3),ly=wy(G.y0)+ws(2.4);
  var col=["#1a4a3a","#2a8a60","#50f0a0","#2a8a60"][ANIM_F];
  disc(lx,ly,ws(1.15),ws(1.15),col,"#0a2018");
  if(ANIM_F===2){ctx.globalAlpha=0.35;oval(lx,ly,ws(2.1),ws(2.1),"#40e090");ctx.globalAlpha=1;}
}
function drawReturnRattle(){
  if(sim&&sim.s&&sim.s.suck)retLight=1;
  var G=GEO.ret,x0=G.mouthX,y=G.y,hh=G.w/2+0.5;
  var jx=[ -1.2, 1.1, 0.2, -0.6 ][ANIM_F], jy=[ 0.2, -0.9, 1.2, -0.3 ][ANIM_F];
  if(!retLight){jx*=0.45;jy*=0.45;}
  var mx=wx(x0+jx),my=wy(y+jy);
  oval(mx,my,ws(2.7),ws(hh+0.7),"#9aa49a");oval(mx,my,Math.max(1,ws(2.2)),ws(hh+0.2),"#5a6058");
  oval(mx,my,Math.max(1,ws(2.0)),ws(hh-0.2),"#12141a");oval(mx+1,my,Math.max(1,ws(1.2)),ws(hh-1.2),"#06070a");
  oval(mx-1,my-1,Math.max(1,ws(0.7)),Math.max(1,ws(0.5)),"#3a4038");
  /* rattling bolts */
  var bx=wx(x0+3+jx), by1=wy(y-hh-0.4+jy), by2=wy(y+hh-0.6+jy);
  oval(bx,by1,ws(0.55),ws(0.55),"#c0c8c0");oval(bx,by2,ws(0.55),ws(0.55),"#c0c8c0");
}

function drawReturnChute(){var G=GEO.ret,x0=G.mouthX,x1=RW-WALL,y=G.y,hh=G.w/2+0.5,len=x1-x0;
  wr(x0+1,y-hh+2,len,hh*2,"rgba(0,0,0,0.28)");
  wr(x0,y-hh,len+0.5,hh*2,"#323830");wr(x0,y-hh+0.4,len+0.5,hh*2-0.8,"#5a6258");wr(x0,y-hh+1.4,len+0.5,hh*2-2.8,"#6a7268");
  wr(x0,y-hh,len+0.5,1.4,"#9aa49a");wr(x0,y+hh-1.6,len+0.5,1.6,"#3a4038");
  /* centre seam */
  wr(x0,y-0.4,len+0.5,0.8,"#4a5248");
  /* pipe rings + bolts */
  var rx=[x0+3,x0+9,x0+15];for(var i=0;i<rx.length;i++){wr(rx[i],y-hh-0.8,1.4,hh*2+1.6,"#3a4038");wr(rx[i],y-hh-0.8,0.7,hh*2+1.6,"#7a8478");
    wr(rx[i]+0.2,y-hh-0.4,0.8,0.8,"#c0c8c0");wr(rx[i]+0.2,y+hh-0.6,0.8,0.8,"#c0c8c0");}
  /* green arrows pointing OUT (west) */
  for(var a=0;a<2;a++){var ax=x0+5.5+a*6,ay=y;for(var d=0;d<3;d++){wr(ax+d*0.9,ay-d*0.9,1,1,"#3ad070");wr(ax+d*0.9,ay+d*0.9,1,1,"#3ad070");}}
  /* wall flange with four bolts */
  wr(x1-0.5,y-hh-2,4.5,hh*2+4,"#3a4038");wr(x1-0.5,y-hh-2,1,hh*2+4,"#8a9088");
  wr(x1+1,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+1,y+hh-0.2,1.2,1.2,"#c0c8c0");
  wr(x1+2.4,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+2.4,y+hh-0.2,1.2,1.2,"#c0c8c0");
  /* mouth is drawn each frame in drawReturnRattle so it can shake */
  /* spill tray with grate under the mouth */
  wr(x0-7,y-hh+0.5,6,hh*2-1,"rgba(40,50,40,0.28)");wr(x0-7,y-hh+0.5,6,0.6,"#7a8478");wr(x0-7,y+hh-1.1,6,0.6,"#3a4038");
  for(var t=0;t<3;t++)wr(x0-6+t*2,y-hh+1,0.6,hh*2-2,"rgba(200,210,200,0.28)");}
function drawTable2(){var G=GEO.table,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.30)");
  /* thick wooden slab + corner irons + legs peeking at the four corners */
  R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");
  for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  var lg=Math.max(2,ws(2.2));
  R(x-1,y-1,lg,lg,"#3a200c");R(x+w-lg+1,y-1,lg,lg,"#3a200c");R(x-1,y+h-lg+1,lg,lg,"#2a1408");R(x+w-lg+1,y+h-lg+1,lg,lg,"#2a1408");
  R(x,y,3,3,"#5a4030");R(x+w-3,y,3,3,"#5a4030");R(x,y+h-3,3,3,"#3a200c");R(x+w-3,y+h-3,3,3,"#3a200c");
  /* cutting board with a juice groove and knife marks */
  var bx=wx(40),by=wy(G.y0+4),bw=ws(20),bh=ws(12);
  R(bx+1,by+1,bw,bh,"rgba(0,0,0,0.25)");R(bx,by,bw,bh,"#8a6a30");R(bx+1,by+1,bw-2,bh-2,"#d8b878");R(bx+1,by+1,bw-2,1,"#ecd29a");
  R(bx+2,by+2,bw-4,1,"#b8985c");R(bx+2,by+bh-3,bw-4,1,"#b8985c");R(bx+2,by+2,1,bh-4,"#b8985c");R(bx+bw-3,by+2,1,bh-4,"#b8985c");
  for(var j=0;j<5;j++)R(bx+3+j*Math.max(2,Math.round(bw/6)),by+3+(j%2)*2,Math.max(2,Math.round(bw/9)),1,"#b8985c");
  /* knife resting beside the board (handle + bolster + blade highlight) */
  var kx=wx(62),ky=wy(G.y0+9),kw=Math.max(3,ws(3.4)),kh=Math.max(2,ws(1.8)),blw=Math.max(5,ws(5.5));
  R(kx,ky,kw,kh,"#3a2a20");R(kx+1,ky,kw-2,1,"#6a4a30");R(kx-1,ky,1,kh,"#2a1c14");
  R(kx-blw,ky,blw,Math.max(2,ws(1.5)),"#c8d0d8");R(kx-blw,ky,blw,1,"#f0f4f8");R(kx-blw,ky+Math.max(1,ws(1.5))-1,blw,1,"#8a9098");}
function drawBed(){var cx=GEO.mat.x,cy=GEO.mat.y,mw=GEO.mat.w,mh=GEO.mat.h;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  /* full-size wooden frame, mattress, west pillows, east blanket — holds a lying Papa */
  R(x+2,y+2,w,h,"rgba(0,0,0,0.30)");
  blob(x-1.2,y-1.2,w+2.4,h+2.4,2.2,"#5a3a20","#2a1810");
  R(x-1.2,y-1.2,w+2.4,1.4,"#8a6a40");R(x-1.2,y+h,w+2.4,1.2,"#3a200c");
  blob(x+1.4,y+1.4,w-2.8,h-2.8,1.6,"#e8e4d4","#c8c0a8");
  R(x+2,y+2,w-4,1.2,"#fffaf0");
  /* headboard on the west end */
  blob(x-2.2,y-2.2,ws(3.4),h+4.4,1.1,"#7a5a30","#2a1810");R(x-2.2,y-2.2,ws(3.4),1.4,"#9a7a48");
  /* blanket over the east two thirds, folded hem */
  var bw=w*0.62,bx=x+w-bw-1.2;
  blob(bx,y+1.6,bw,h-3.2,1.4,"#4a6aa8","#2a3058");
  R(bx,y+1.6,bw,Math.max(2,h*0.22),"#6a8ac8");R(bx,y+1.6,2,h-3.2,"#d8e0f0");
  for(var i=5;i<bw-3;i+=6)R(bx+i,y+h*0.28,1,h-h*0.28-3.2,"#3a5a98");
  /* two stacked pillows at the west end, room for his head */
  var pw=Math.max(6,ws(6.8)),ph=Math.max(5,h-5.2);
  blob(x+3.2,y+2.6,pw,ph,2.0,"#fffaf0","#a8a090");
  blob(x+4.2,y+3.4,pw-2,ph-2.2,1.6,"#fffef6","#d8d0b8");
  R(x+5,y+3.8,pw-4,1.2,"#ffffff");}
function drawCooler2(){var G=GEO.cooler,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#1c3a5a");R(x+1,y+1,w-2,h-2,"#3a6a9a");
  R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+h-2,w-2,1,"#1a2c44");R(x+1,y,1,h,"#8ab8e0");R(x+w-2,y,1,h,"#1a2c44");
  /* lid seam, hinges, latch */
  R(x+1,y+Math.round(h*0.62),w-2,1,"#24405a");R(x+2,y+Math.round(h*0.62)-1,Math.max(2,ws(2)),2,"#c0c8c0");R(x+w-Math.max(4,ws(3.5)),y+Math.round(h*0.62)-1,Math.max(2,ws(2)),2,"#c0c8c0");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),Math.max(1,ws(1.5)),"#e8eef4");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),1,"#ffffff");
  /* rubber gasket just inside the rim */
  R(x+2,y+2,w-4,1,"#1a2840");R(x+2,y+h-3,w-4,1,"#1a2840");
  /* a can of food on the lid (the stock lives in here) */
  var cw=Math.max(3,ws(3.4)),chh=Math.max(3,ws(3.6)),cx0=x+Math.round(w*0.12),cy0=y+Math.round(h*0.12);
  R(cx0,cy0,cw,chh,"#7a3a10");R(cx0,cy0+1,cw,chh-2,"#e0a040");R(cx0,cy0,cw,1,"#f0e0b0");R(cx0+1,cy0+Math.round(chh/2),Math.max(1,cw-2),1,"#b04020");
  /* hum-lamp well (the glow is drawn in drawCoolerHum) */
  R(x+w-ws(3.6),y+ws(1.1),ws(2.6),ws(2.6),"#0a1828");R(x+w-ws(3.3),y+ws(1.4),ws(2.0),ws(2.0),"#1a2840");}
function drawStool(){var x=wx(GEO.stool.x),y=wy(GEO.stool.y),r=Math.max(5,ws(4.4)),q=Math.max(2,Math.round(r*0.34)),lg=Math.round(r*0.95);
  oval(x+1,y+r*0.45,r+1,r*0.7,"rgba(0,0,0,0.30)");
  /* four wooden legs + a foot ring so it reads as a stool, not a cushion */
  ctx.fillStyle="#3a2410";var d=[[-1,-1],[1,-1],[-1,1],[1,1]];for(var i=0;i<4;i++)ctx.fillRect(Math.round(x+d[i][0]*lg-q/2),Math.round(y+d[i][1]*lg*0.8-q/2),q,q);
  oval(x,y,r*0.85,r*0.7,"#5a3a20");oval(x,y,r*0.72,r*0.58,"#3a2410");
  /* round red cushion, dark rim, highlight, centre button, stitch ring */
  oval(x,y,r,r*0.86,"#2a1010");oval(x,y,r-1,r*0.86-1,"#a8302a");oval(x,y,r-2,r*0.86-2,"#c8443a");
  oval(x-r*0.25,y-r*0.2,Math.max(1,r*0.4),Math.max(1,r*0.28),"#e87a64");
  oval(x,y,Math.max(1,r*0.16),Math.max(1,r*0.14),"#6a2018");oval(x,y,Math.max(1,r*0.08),Math.max(1,r*0.07),"#e87a64");}
function drawPileBay(){var G=GEO.pile,x0=G.cx-G.rx-2,x1=G.cx+G.rx+2,y0=G.base+G.rz-3,y1=RH-WALL;
  /* shallow wooden bay against the bottom wall; potatoes draw on top, the curb shows around a small pile */
  wr(x0,y0,x1-x0,y1-y0,"rgba(40,30,16,0.16)");
  wr(x0,y1-2.2,x1-x0,2.2,"#4a3018");wr(x0,y1-2.2,x1-x0,0.8,"#8a6a40");wr(x0,y1-1.2,x1-x0,1.2,"#3a200c");
  wr(x0,y0,1.6,y1-y0,"#4a3018");wr(x0,y0,0.7,y1-y0,"#8a6a40");
  wr(x1-1.6,y0,1.6,y1-y0,"#3a200c");wr(x1-0.8,y0,0.8,y1-y0,"#5a3a18");
  /* corner posts */
  wr(x0-0.4,y1-3.2,2.2,3.2,"#3a200c");wr(x0-0.4,y1-3.2,2.2,0.8,"#8a6a40");
  wr(x1-1.8,y1-3.2,2.2,3.2,"#3a200c");wr(x1-1.8,y1-3.2,2.2,0.8,"#8a6a40");}
function drawPileShadow(){var G=GEO.pile;ctx.fillStyle="rgba(40,30,16,0.22)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+1),ws(G.rx+4),ws(G.rz+2),0,0,6.28);ctx.fill();
  ctx.fillStyle="rgba(30,22,10,0.16)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+2),ws(G.rx-4),ws(G.rz-2),0,0,6.28);ctx.fill();}
/* ---------- the pile: 0.2 look (stacked tiers), spread wider and lower along the bottom wall ---------- */
function shadeHex(h,f){var n=parseInt(h.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function c(v){v=Math.round(v*f);return Math.max(0,Math.min(255,v));}return"rgb("+c(r)+","+c(g)+","+c(b)+")";}
var LVF=[0.60,0.74,0.90,1.08,1.25,1.42];
function buildPile(){POS=[];ORDER=[];TIER=[];var G=GEO.pile,cx=G.cx,base=G.base,rx0=G.rx,rz0=G.rz,idx=0;
  var LF=LIFT;
  for(var t=0;idx<PILEMAX;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(100*sc*sc):90;TIER.push(idx);
    for(var j=0;j<cap;j++,idx++){var r=Math.sqrt(((j+0.5)*0.7548776662)%1),th=(((j+0.5)*0.5698402910)%1)*6.28318+t*1.3;   /* R2 low-discrepancy: ANY prefix of a tier is spread over the whole tier, so a small pile already lies wide along the floor */
      var x=cx+rx0*sc*r*Math.cos(th)+(srng(idx*5+2)-0.5)*3,z=base+rz0*sc*r*Math.sin(th)+(srng(idx*3+7)-0.5)*2.2;
      POS.push({x:x,y:z-Math.min(t,9)*LF,z:z,t:t,vi:idx%3,fl:(idx*7)%2});}}
  MAXVIS=POS.length;ORDER=POS.map(function(p,i){return i;});ORDER.sort(function(a,b){var pa=POS[a],pb=POS[b];return pa.t!==pb.t?pa.t-pb.t:pa.y-pb.y;});}
function withCtx(c2,fn){var o=ctx;ctx=c2;try{fn();}finally{ctx=o;}}
function mkSprite(w,h,fn){var c=document.createElement("canvas");c.width=Math.max(1,Math.round(w*DPR));c.height=Math.max(1,Math.round(h*DPR));var g=c.getContext("2d");g.imageSmoothingEnabled=false;g.setTransform(DPR,0,0,DPR,0,0);withCtx(g,fn);c.cssW=w;c.cssH=h;return c;}
function buildSprites(){SPR=[];SPRS=[];var sizes=[2.9,3.3,3.7];
  for(var vi=0;vi<3;vi++){var sp=Math.max(3,Math.round(sizes[vi]*k)),hw=Math.max(2,Math.round(sp)),hh=Math.max(2,Math.round(sp*0.72)),w=2*hw+6,hgt=2*hh+7;
    for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++){var base=["#4a2810","#6a4020","#8a5a28","#c48a48"],f=LVF[lv];
      var pal=[shadeHex(base[0],f*0.9),shadeHex(base[1],f),shadeHex(base[2],f),shadeHex(base[3],f)];
      for(var sh=0;sh<2;sh++){(function(sh2){var spr=mkSprite(w,hgt,function(){if(sh2)oval(hw+3+1,hh+4+1,hw+1,hh,"rgba(0,0,0,0.20)");potato(hw+3,hh+3,sp,false,!!fl,0,pal);});
        spr.cx=hw+3;spr.cy=hh+3;(sh2?SPRS:SPR)[(vi*6+lv)*2+fl]=spr;})(sh);}}}
  PEELSPR=[];var pcol=[["#f5e0a8","#e8c070","#b08838"],["#e8c070","#d4a04a","#9a7430"],["#f0d890","#c8a040","#8a6a2a"]];
  var pats=[[".XX.","X..X","...X"],["XX..",".XXX","...."],[".X.","X.X",".XX"],["XXX.","...X",".XX."]];
  var pw=Math.max(10,Math.round(4.4*k)),ph=Math.max(8,Math.round(3.4*k)),psc=pw/6;
  for(var q=0;q<12;q++){var pc=pcol[q%3],pt=pats[q%4];PEELSPR[q]=mkSprite(pw,ph,function(){for(var yy=0;yy<pt.length;yy++)for(var xx=0;xx<pt[yy].length;xx++)if(pt[yy][xx]==="X"){R((1+xx)*psc,(1+yy+1)*psc,psc,psc,pc[2]);R((1+xx)*psc,(1+yy)*psc,psc,psc,pc[(xx+yy)%2]);}});PEELSPR[q].cx=pw/2;PEELSPR[q].cy=ph/2;}}
/* mess slots: the first peels land right where he works (south of the table), later ones spread out; sorted by distance so the heap grows from his feet */
function buildMess(){MESSPOS=[];var G=GEO.mess,T=GEO.table;
  for(var i=0,tries=0;i<MESSVIS&&tries<6000;tries++){var r=Math.sqrt((i+0.5)/MESSVIS),th2=(i+tries)*2.39996,x=G.cx+G.rx*r*Math.cos(th2)+(srng(tries*3+1)-0.5)*3,y=G.cy+G.rz*r*Math.sin(th2)+(srng(tries*7+3)-0.5)*3;
    if(x<WALL+3||x>RW-WALL-3||y<T.y1+3||y>GEO.pile.base-GEO.pile.rz-8)continue;
    if(Math.abs(x-GEO.mat.x)<GEO.mat.w/2+6&&Math.abs(y-GEO.mat.y)<GEO.mat.h/2+6)continue;
    MESSPOS.push({x:x,y:y,q:(i*5+tries)%12});i++;}}
function renderPile(n){if(!pileLayer||pileLayer.width!==cv.width||pileLayer.height!==cv.height){pileLayer=document.createElement("canvas");pileLayer.width=cv.width;pileLayer.height=cv.height;pileKey=-1;}
  if(pileKey===n)return;pileKey=n;renders.pile++;var c=pileLayer.getContext("2d");c.imageSmoothingEnabled=false;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cv.width,cv.height);
  /* 0.3 shading: a fixed, gentle light ramp by tier (never relative to the heap height) and a soft shadow only under the bottom tier, so a big pile stays readable */
  for(var q=0;q<ORDER.length;q++){var i=ORDER[q];if(i>=n)continue;var p=POS[i],lv=Math.min(4,2+Math.floor(p.t/3)),sp=(p.t===0?SPRS:SPR)[(p.vi*6+lv)*2+p.fl];c.drawImage(sp,Math.round((wx(p.x)-sp.cx)*DPR),Math.round((wy(p.y)-sp.cy)*DPR));}}
var flying={},messVer=0;
function renderMess(n){if(!messLayer||messLayer.width!==cv.width||messLayer.height!==cv.height){messLayer=document.createElement("canvas");messLayer.width=cv.width;messLayer.height=cv.height;messKey="";}
  var key=n+"|"+messVer;if(messKey===key)return;messKey=key;renders.mess++;var c=messLayer.getContext("2d");c.imageSmoothingEnabled=false;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cv.width,cv.height);
  for(var i=0;i<n&&i<MESSPOS.length;i++){if(flying[i])continue;var p=MESSPOS[i];c.drawImage(PEELSPR[p.q],Math.round((wx(p.x)-PEELSPR[p.q].cx)*DPR),Math.round((wy(p.y)-PEELSPR[p.q].cy)*DPR));}}
function drawStatic(){drawFloor();drawWalls();
  /* hidden props (0.2.1 t1027, still hidden): drawPipes drawShelf drawToolRack drawMachinePad x3 drawDrain drawPeelBin drawBucket drawSack x4 drawCrate x3 drawLamp; 0.3 also hides drawCentreStripe and the old drawChuteBase/drawCooler/drawMat/drawTable */
  drawPileBay();drawPileShadow();drawBed();drawTable2();drawCooler2();drawStool();drawDoor();drawReturnChute();}
function ensureStatic(){if(staticLayer&&staticLayer.width===cv.width&&staticLayer.height===cv.height)return;drawStatic();var copy=document.createElement("canvas");copy.width=cv.width;copy.height=cv.height;var g=copy.getContext("2d");g.imageSmoothingEnabled=false;g.drawImage(cv,0,0);staticLayer=copy;}

/* ---------- the guy: 0.3.1 slimmer Papa, Swarm hybrid (DPR vectors, flat shading, 1px outline). True top-down, crown + arms only (mock 0.1b look lock). ---------- */
function M(dx,dy){switch(GD){case 1:return[GX-dy,GY+dx];case 2:return[GX-dx,GY-dy];case 3:return[GX+dy,GY-dx];default:return[GX+dx,GY+dy];}}
function O(dx,dy,rw,rh,c){var p=M(dx,dy);if(GD&1)oval(p[0],p[1],rh,rw,c);else oval(p[0],p[1],rw,rh,c);}
function Oout(dx,dy,rw,rh,c,out){var p=M(dx,dy);if(GD&1)disc(p[0],p[1],rh,rw,c,out||OUT);else disc(p[0],p[1],rw,rh,c,out||OUT);}
function limb(x0,y0,x1,y1,x2,y2,w){function seg(a,b,c2,d,ww,col,out){var p0=M(a,b),p1=M(c2,d);
    ctx.lineCap="round";ctx.lineJoin="round";
    ctx.strokeStyle=out||"#5a3a22";ctx.lineWidth=ww+1.3;ctx.beginPath();ctx.moveTo(p0[0],p0[1]);ctx.lineTo(p1[0],p1[1]);ctx.stroke();
    ctx.strokeStyle=col;ctx.lineWidth=ww;ctx.beginPath();ctx.moveTo(p0[0],p0[1]);ctx.lineTo(p1[0],p1[1]);ctx.stroke();}
  seg(x0,y0,x1,y1,w,"#c4a070","#5a3a22");if(x2!=null){seg(x1,y1,x2,y2,w,"#c4a070","#5a3a22");seg((x1+x2)/2,(y1+y2)/2,x2,y2,Math.max(0.8,w-0.5),"#d8b888","#5a3a22");}}
function hand(x,y,hw,fx,fy){if(fx==null)fx=0;if(fy==null)fy=0;
  /* small proportional palm + 3 fingers, skin with a darker outline */
  Oout(x,y,hw,hw*0.82,"#c4a070","#5a3a22");O(x-hw*0.18,y-hw*0.18,hw*0.38,hw*0.3,"#d8b888");
  var fl=hw*1.15,fw=Math.max(0.35,hw*0.32);
  for(var i=-1;i<=1;i++){var px=x+fx*fl+(-fy)*i*(hw*0.9),py=y+fy*fl+fx*i*(hw*0.9);
    Oout(px,py,fw,fw,"#d0a878","#5a3a22");}}
function drawCrown(useO,x,y,hr,u){
  /* hair cap, visible part, fringe, tucked ears, soft shading — no face. useO: local/rotated (standing). else absolute (sleeper). */
  function P(dx,dy,rw,rh,c,ol){if(useO){if(ol===false)O(x+dx,y+dy,rw,rh,c);else Oout(x+dx,y+dy,rw,rh,c,OUT);}else{if(ol===false)oval(x+dx,y+dy,rw,rh,c);else disc(x+dx,y+dy,rw,rh,c,OUT);}}
  P(0,0.4,hr+0.7,hr+0.35,"#2a2018");P(0,0.15,hr-0.15,hr-0.35,"#3a2a20",false);P(-hr*0.22,-hr*0.06,hr*0.55,hr*0.48,"#4a3828",false);
  P(-hr*0.28,-hr*0.18,Math.max(0.8,hr*0.42),Math.max(0.6,hr*0.28),"#5a4630",false);
  P(-hr*0.18,-hr*0.28,Math.max(0.5,hr*0.2),Math.max(0.4,hr*0.14),"#8a7860",false);
  /* hair part */
  P(-hr*0.12,-hr*0.12,Math.max(0.35,hr*0.08),Math.max(1.0,hr*0.55),"#6a5640",false);
  /* fringe along the north hairline */
  P(-hr*0.45,-hr+0.55,Math.max(0.6,hr*0.18),Math.max(0.5,hr*0.14),"#2a2018",false);
  P(-hr*0.05,-hr+0.35,Math.max(0.7,hr*0.22),Math.max(0.5,hr*0.13),"#3a2a20",false);
  P(hr*0.38,-hr+0.55,Math.max(0.55,hr*0.16),Math.max(0.5,hr*0.13),"#2a2018",false);
  P(hr*0.12,-hr+0.42,Math.max(0.45,hr*0.12),Math.max(0.4,hr*0.1),"#4a3828",false);
  /* tucked ears — defined rim + inner skin */
  var ear=Math.max(0.9,1.05*u);
  P(-hr+0.1,hr*0.12,ear,ear*0.92,"#8a6840");P(-hr+0.1,hr*0.12,ear*0.55,ear*0.55,"#c4a070",false);
  P(hr-0.1,hr*0.12,ear,ear*0.92,"#8a6840");P(hr-0.1,hr*0.12,ear*0.55,ear*0.55,"#c4a070",false);
  P(hr*0.32,hr*0.2,Math.max(0.35,hr*0.08),Math.max(0.35,hr*0.08),"#2a2018",false);
  P(-hr*0.42,hr*0.28,Math.max(0.35,hr*0.08),Math.max(0.35,hr*0.08),"#1a1410",false);
}
function drawGuy(now){
  var g=sim.s.g,a=g.act||{t:"idle"};
  GX=wx(g.x*roomW);GY=wy(g.y*roomH);GD=g.dir|0;
  /* slimmer than 0.3, a hair larger than the too-tiny 0.3.1 so detail reads; sizes in CSS px via k */
  var u=k*0.82;
  var hr=6.4*u,shW=14.2*u,shH=6.0*u;
  var breath=0;
  if(a.t==="idle")breath=[0,0.7,1.35,0.5][ANIM_F]*u;
  shH+=breath*0.5;
  var shY=hr+Math.max(1.4,shH*0.40)+breath*0.25,armW=1.55*u,workY=-hr-4.0*u;
  var armX=shW*0.40,armRootY=shY-shH*0.42,hw=1.20*u,sl=2.10*u;
  if(a.t==="nap"||a.t==="lazynap"){drawSleeper(now,hr,shW,shH,a.t==="lazynap",u);}
  else if(a.t==="watch"){drawSitter(now,u);}
  else{
    var sp=M(0,shY+1.2);softShadow(sp[0],sp[1],(GD&1?shH*0.7:shW*0.52),(GD&1?shW*0.52:shH*0.7));
    /* tapered shoulders + apron, strap, 1px outline */
    Oout(0,shY+0.25,shW/2+0.15,shH/2+0.45,"#2a4a62");
    O(0,shY-0.15,shW/2-1.0,shH/2-0.25,"#3a6a8a");
    O(-0.4,shY-0.7,Math.max(1.2,shW/2-2.4),Math.max(1.0,shH/2-1.6),"#5a8aaa");
    O(-0.9,shY-1.1,Math.max(0.9,shW/2-3.6),Math.max(0.7,shH/2-2.2),"#7aa8c0");
    /* apron neck strap */
    Oout(0,shY-shH*0.42,Math.max(0.9,shW*0.12),0.85,"#2a4a62");O(0,shY-shH*0.42,Math.max(0.55,shW*0.08),0.45,"#c8d0a8");
    Oout(-armX,armRootY,sl,sl-0.15,"#2a4a62");O(-armX,armRootY,sl-0.45,sl-0.6,"#4a7a9a");
    Oout(armX,armRootY,sl,sl-0.15,"#2a4a62");O(armX,armRootY,sl-0.45,sl-0.6,"#5a8aaa");
    drawCrown(true,0,0,hr,u);
    var t=ANIM_T;
    if(a.t==="peel"){
      var stroke=Math.sin(t*(g.lazy?5:9)*(sim.spd()))*2.4*u,potX=-1.2*u,lH=potX+2.2*u,rH=potX+5.4*u+stroke;
      limb(-armX,armRootY-1,-armX-3.2*u,(armRootY+workY)/2,lH,workY,armW);
      limb(armX,armRootY-1,armX+3.2*u,(armRootY+workY)/2,rH,workY+stroke*0.3,armW);
      hand(lH,workY,hw,0.35,-0.15);hand(rH,workY+stroke*0.3,hw,0.55,0);
      var pp=M(potX,workY-0.4*u);var pr=g.peel;potato(pp[0],pp[1],Math.max(3.2,4.6*u),pr>0.55,(ANIM_F%2)===0,pr>0.55?Math.round((1-pr)*10):0);
      var kb=M(rH-6.8*u+2,workY-1),kh=M(rH,workY-1);
      if(GD===0){R(kh[0],kh[1],Math.max(2.4,3.4*u),Math.max(1.4,1.7*u),"#3a2a20");R(kb[0],kb[1],Math.max(4.4,6.4*u),Math.max(1.3,1.5*u),"#c8d0d8");R(kb[0],kb[1],Math.max(4.4,6.4*u),0.7,"#f0f4f8");}
    }else if(a.t==="eat"){
      var bite=(ANIM_F>=2),mY=bite?-hr+1:workY+2;
      limb(-armX,armRootY-1,-armX-3*u,(armRootY+workY)/2,-2*u,mY,armW);
      limb(armX,armRootY-1,armX+3*u,(armRootY+workY)/2+2,3*u,workY+3,armW);
      hand(-2*u,mY,hw,0,-0.8);hand(3*u,workY+3,hw,0,0.8);
      var fp=M(-2*u,mY-1);R(fp[0]-2,fp[1]-1,4,3,"#e8c070");R(fp[0]-2,fp[1]-1,4,1,"#c08040");
    }else if(a.t==="sweep"){
      var sw2=Math.sin(t*7.5)*3.4*u,hx0=-1.6*u+sw2*0.35,hy0=workY+2.5*u;
      limb(-armX,armRootY-1,-armX-2.6*u,(armRootY+hy0)/2,hx0,hy0,armW);
      limb(armX,armRootY-1,armX+2.6*u,(armRootY+hy0)/2,hx0+3.4*u,hy0+1.2*u,armW);
      hand(hx0,hy0,hw,0.2,-0.8);hand(hx0+3.4*u,hy0+1.2*u,hw,0.2,-0.8);
      var tipY=workY-8*u,tipX=sw2*1.5;
      for(var bi=0;bi<=10;bi++){var bq=bi/10;Oout(hx0+(tipX-hx0)*bq,hy0+(tipY-hy0)*bq,0.55,0.55,"#8a6840");}
      Oout(tipX,tipY,Math.max(2.2,3.2*u),Math.max(1.1,1.4*u),"#5a4020");O(tipX,tipY-0.8,Math.max(2.0,3.0*u),Math.max(0.8,1.05*u),"#c8a860");
    }else if(a.t==="drop"||g.hold){
      var nHold=g.held||1;
      var bob=a.t==="walk"?Math.sin(g.walkPh)*1:0,cy=nHold>1&&a.t!=="drop"?(shY-0.6*u):(workY+2+bob);
      limb(-armX,armRootY-1,-armX-2.6*u,(armRootY+cy)/2,-2*u,cy,armW);
      limb(armX,armRootY-1,armX+2.6*u,(armRootY+cy)/2,2*u,cy,armW);
      hand(-2.4*u,cy,hw,0.3,-0.4);hand(2.4*u,cy,hw,-0.3,-0.4);
      var cp=M(0,cy-1);
      if(a.t==="drop"){
        /* potato leaves the hands and rides onto the belt, always clear of the crown */
        var bx=wx(GEO.ship.x),by=wy(GEO.ship.lip+5.5),p0x=cp[0],p0y=cp[1],pr=Math.max(2.8,4.0*u);
        var need=hr+pr+3,d0=Math.hypot(p0x-GX,p0y-GY),sx=bx-GX,sy=by-GY,sn=Math.hypot(sx,sy)||1;
        if(d0<need){p0x=GX+sx/sn*need;p0y=GY+sy/sn*need;}
        var e=1-Math.pow(1-Math.min(1,a.e/Math.max(0.05,sim.dropTime())),1.5);
        potato(p0x+(bx-p0x)*e,p0y+(by-p0y)*e,pr,true,false,g.sloppy?3:0);
      }else{
        var nHold=g.held||1,pr=Math.max(2.8,4.0*u),peeled=g.hold==="peeled",spots=peeled&&g.sloppy?3:0;
        if(nHold<=1)potato(cp[0],cp[1],pr,peeled,false,spots);
        else{
          disc(cp[0],cp[1]+pr*0.35,pr*1.55,pr*1.7,"#6a4a28","#3a2810");
          oval(cp[0]-pr*0.15,cp[1]-pr*0.15,pr*0.9,pr*0.7,"#8a6840");
          for(var hi=0;hi<Math.min(nHold,4);hi++){
            var ox=(hi%2?1:-1)*pr*(0.42+(hi>1?0.08:0)),oy=(hi<2?-0.45:0.38)*pr;
            potato(cp[0]+ox,cp[1]+oy,pr*0.78,peeled,hi%2===1,spots);
          }
        }
      }
    }else{
      var sw=a.t==="walk"?Math.sin(g.walkPh)*5.4*u:(a.t==="idle"?[0,0.4,0,-0.35][ANIM_F]*u:0);
      var yL=shY-1+sw,yR=shY-1-sw,out= (a.t==="walk"?2.8:2.0)*u;
      var endYL=yL-(a.t==="walk"?4.2:3.0)*u,endYR=yR-(a.t==="walk"?4.2:3.0)*u;
      limb(-armX,armRootY,-armX-out,(armRootY+yL)/2,-armX-1*u,endYL,armW);
      limb(armX,armRootY,armX+out,(armRootY+yR)/2,armX+1*u,endYR,armW);
      hand(-armX-1*u,endYL,hw,0,sw>0?0.9:-0.9);hand(armX+1*u,endYR,hw,0,sw<0?0.9:-0.9);
      if(a.t==="grab"){var gp=M(0,workY+2);potato(gp[0],gp[1],Math.max(2.8,3.8*u),false,false);}
    }
  }
}
function sitWorld(){var tv=itemXY("tvArmchair");return {x:tv.x-8.2+2.6,y:tv.y+0.4};}
function drawSitter(now,u){
  /* Proper SIT in the armchair, facing the TV (east). Layout matches the approved close-tv look;
     crown uses the locked 0.3.1 head/hair/colors, drawn screen-space like the sleeper. */
  var sw=sitWorld(),px=wx(sw.x),py=wy(sw.y),su=k*0.70,sHr=4.8*su,sShN=6.4*su,sShE=4.6*su;
  GX=px;GY=py;GD=1;
  softShadow(px,py+ws(0.5),sShE*0.75,sShN*0.7);
  disc(px-ws(1.0),py,sShE/2+0.25,sShN/2+0.4,"#2a4a62",OUT);
  oval(px-ws(0.85),py-0.2,sShE/2-0.5,sShN/2-0.35,"#3a6a8a");
  oval(px-ws(1.05),py-0.7,Math.max(1.0,sShE/2-1.3),Math.max(0.8,sShN/2-1.1),"#5a8aaa");
  oval(px-ws(1.2),py-1.0,Math.max(0.7,sShE/2-1.8),Math.max(0.6,sShN/2-1.6),"#7aa8c0");
  disc(px-ws(0.15),py,Math.max(0.6,0.7*su),0.7,"#2a4a62",OUT);
  oval(px-ws(0.15),py,Math.max(0.4,0.45*su),0.4,"#c8d0a8");
  disc(px-ws(0.2),py-sShN*0.52,1.2*su,1.05*su,"#c4a070","#5a3a22");
  disc(px-ws(0.2),py+sShN*0.52,1.2*su,1.05*su,"#c4a070","#5a3a22");
  drawCrown(false,px+ws(2.2),py,sHr,su);
}
function drawSleeper(now,hr,shW,shH,lazy,u){
  /* lying in the full-size bed (or on the floor if lazy): only the head shows on the pillow, blanket covers the whole body up to the shoulders. No arms or legs outside the blanket. */
  var G=GEO.mat;
  var hx,hy;
  if(!lazy){hx=wx(G.x-G.w/2+5.4);hy=wy(G.y);}
  else{hx=GX-5;hy=GY;}
  var bodyLen=lazy?22*u:ws(G.w*0.74);
  var hrS=lazy?6.2*u:Math.min(ws(G.h*0.40),bodyLen*0.155);
  var blanketW=lazy?shW*0.78:ws(G.h*0.52);
  /* 4-frame gentle breath: the blanket mound rises and falls (~8 fps) */
  var breathe=[0,0.45,1.0,0.40][ANIM_F];
  var rise=breathe*Math.max(1.1,blanketW*0.10);
  var tx=hx+hrS+0.8, ty=hy;
  softShadow(tx+bodyLen*0.40,hy+1.6,bodyLen*0.52,blanketW*0.58);
  /* a hint of shoulders / apron at the neckline, tucked under the hem — not sticking out */
  disc(tx-0.2,ty,Math.max(1.6,hrS*0.55),blanketW*0.22,"#2a4a62","#1a1410");
  /* blanket from the shoulders to the foot of the bed, covering arms, torso, and legs */
  var bx=hx+hrS*0.62, by=ty-(blanketW*0.50+rise*0.35), bw=bodyLen*0.98, bh=blanketW+rise;
  blob(bx,by,bw,bh,bh*0.46,"#4a6aa8","#2a3058");
  /* folded hem at the shoulders (just under the head) */
  R(bx,by,2.4,bh,"#d8e0f0");
  R(bx+1.2,by+bh*0.12,1.2,bh*0.76,"#c8d4ec");
  /* soft folds; the chest highlight lifts with the breath */
  for(var i=1;i<=4;i++)R(bx+bw*(0.16+i*0.16),by+bh*0.20,1,bh*0.60,"#3a5a98");
  oval(bx+bw*0.34,ty-rise*0.45,bw*0.24,blanketW*0.16+rise*0.40,"#6a8ac8");
  oval(bx+bw*0.55,ty+rise*0.15,bw*0.18,blanketW*0.10+rise*0.15,"#3a5a98");
  /* crown on the pillow — the only part of him left uncovered */
  drawCrown(false,hx,hy,hrS,hrS/6.4);
  /* steam puffs + Zzz, 4 discrete frames (pale, not yellow peel-bits) */
  var zcol=lazy?"#d0d8e8":"#e8eef4";
  var frames=[
    [{x:-2,y:-hrS-4,s:0.7,a:0.9},{x:3,y:-hrS-9,s:0.9,a:0.55},{x:8,y:-hrS-14,s:1.1,a:0.25}],
    [{x:0,y:-hrS-6,s:0.8,a:0.8},{x:5,y:-hrS-11,s:1.0,a:0.45},{x:10,y:-hrS-16,s:1.15,a:0.2}],
    [{x:2,y:-hrS-8,s:0.9,a:0.65},{x:7,y:-hrS-13,s:1.1,a:0.35},{x:11,y:-hrS-17,s:0.7,a:0.15}],
    [{x:-1,y:-hrS-5,s:0.75,a:0.85},{x:4,y:-hrS-10,s:0.95,a:0.5},{x:9,y:-hrS-15,s:1.05,a:0.22}]
  ][ANIM_F];
  for(var i=0;i<frames.length;i++){var z=frames[i],zx=hx+z.x,zy=hy+z.y,sc=z.s*Math.max(1.8,u*2.4);
    ctx.globalAlpha=z.a;
    oval(zx+sc*3.4,zy-sc*0.8,sc*1.1,sc*0.8,"#d8e4f0");
    R(zx,zy,sc*3,sc*0.7,zcol);R(zx+sc*2.1,zy+sc*0.7,sc*0.7,sc*0.7,zcol);R(zx+sc,zy+sc*1.4,sc*0.7,sc*0.7,zcol);R(zx,zy+sc*2.1,sc*3,sc*0.7,zcol);}
  ctx.globalAlpha=1;
}

/* ---------- effects: peels hop off and land flat on the floor; sweep dust; shipping suction (Swarm port) ---------- */
var flights=[],dust=[],sucks=[],dustAcc=0,GX=0,GY=0,GD=0;
function M2(dx,dy){var g=sim.s.g;GX=wx(g.x*roomW);GY=wy(g.y*roomH);GD=g.dir|0;return M(dx,dy);}
function spawnPeel(slot){if(slot<0||slot>=MESSPOS.length||flights.length>60)return;
  var hr=Math.max(3,6*k*0.82),o=M2((0.8+Math.random()*2.4)*k*0.82,-hr-4.2*k*0.82),tp=MESSPOS[slot];
  flights.push({slot:slot,x0:o[0],y0:o[1],tx:wx(tp.x),ty:wy(tp.y),t:0,dur:0.42+Math.random()*0.26,q:tp.q,h:(4+Math.random()*3)*k});flying[slot]=true;messVer++;}
function tickFlights(dt){var np=sim.s.peels;for(var i=flights.length-1;i>=0;i--){var f=flights[i];f.t+=dt;
    if(f.t>=f.dur||f.slot>=np){delete flying[f.slot];flights.splice(i,1);messVer++;}}}
function drawFlights(){for(var i=0;i<flights.length;i++){var f=flights[i],p=Math.min(1,f.t/f.dur),e=1-(1-p)*(1-p);
    var gxp=f.x0+(f.tx-f.x0)*e,gyp=f.y0+(f.ty-f.y0)*e,z=Math.sin(p*Math.PI)*f.h;
    R(Math.round(gxp)-1,Math.round(gyp)+1,3,1,"rgba(40,30,16,0.32)");
    var sp=PEELSPR[(f.q+Math.floor(p*8))%12],cx=sp.cx||sp.cssW/2||3,cy=sp.cy||sp.cssH/2||2,cw=sp.cssW||6,ch=sp.cssH||5;
    ctx.imageSmoothingEnabled=false;ctx.drawImage(sp,gxp-cx,gyp-z-cy,cw,ch);}}
function tickDust(dt){var g=sim.s.g,a=g.act;
  if(a&&a.t==="sweep"&&a.e>C.sweepWind){var hr2=Math.max(5,Math.round(6*k));var sw=Math.sin(performance.now()/1000*7.5);var o2=M2(Math.round(sw*5*k),-hr2-Math.max(4,Math.round(14*k)));dustAcc+=dt*14;
    while(dustAcc>1){dustAcc-=1;if(dust.length<28)dust.push({x:o2[0]+(Math.random()*6-3),y:o2[1]+(Math.random()*4-2),vx:(Math.random()-0.5)*8,vy:-2-Math.random()*5,life:0.5});}}
  for(var i=dust.length-1;i>=0;i--){var d=dust[i];d.x+=d.vx*dt;d.y+=d.vy*dt;d.life-=dt;if(d.life<=0)dust.splice(i,1);}}
function drawDust(){for(var i=0;i<dust.length;i++){var d=dust[i];ctx.globalAlpha=Math.max(0,d.life*1.6);R(d.x,d.y,2,1,"#d8c898");}ctx.globalAlpha=1;}
/* shipping: potato rides the belt into the scanner, then Swarm suction (3 pulsing red rings + shrinking swirl) at the mouth / inside the box. */
var SUCK_T=0.75;
function pushSuck(sloppy){if(sucks.length<6)sucks.push({t:0,sl:!!sloppy});}
function tickSucks(dt){for(var i=sucks.length-1;i>=0;i--){sucks[i].t+=dt;if(sucks[i].t>=SUCK_T)sucks.splice(i,1);}}
function drawSucks(){var cx=wx(chute.cx),startY=wy(GEO.ship.lip+5.5),mouthY=wy(GEO.WALL+15.2),inY=wy(GEO.WALL+8);
  for(var i=0;i<sucks.length;i++){var s=sucks[i],p=s.t/SUCK_T,x=cx,y,sz,ride=0.55;
    if(p<ride){var e=p/ride;y=startY+(mouthY-startY)*e;sz=Math.max(3,ws(3.1));}
    else{var e=Math.pow((p-ride)/(1-ride),1.4);y=mouthY+(inY-mouthY)*e;sz=Math.max(2,Math.round(Math.max(3,ws(3.1))*(1-0.72*e)));
      var tt=performance.now()/1000,ringY=mouthY-ws(1);ctx.save();ctx.globalAlpha=(0.34+0.20*Math.sin(tt*20))*(1-e*0.65);ctx.strokeStyle="#ff3050";ctx.lineWidth=1;
      for(var q=0;q<3;q++){ctx.beginPath();ctx.arc(cx,ringY,ws(3.2)+((tt*16+q*5.4)%ws(10)),0,6.28);ctx.stroke();}ctx.restore();}
    potato(x,y,sz,true,i%2===1,s.sl?3:0);}
}
/* return chute: raw potatoes come OUT of the mouth (clipped inside the pipe), tumble and bounce, roll and settle onto their slot in the pile.
   The schedule (exit + rest times) comes from PPSim.spill(t0,n): the sim lands each potato at exactly the time drawn here. */
var RT=0,retLight=0;
/* where potato j of the batch is at time RT (canvas px): phase A it slides out of the mouth (clipped inside the pipe), phase B it bounces/rolls to its slot. Shared by the drawing and the test hook. */
function retPos(kk,sc,j,rt){var s=sim.s,mx=GEO.ret.mouthX,ex=sc.ex[j],ld=sc.ld[j],p=(rt-ex)/(ld-ex);if(p<0)return null;if(p>1)p=1;
  var idx=Math.min(MAXVIS-1,s.pile+(j-kk.landed)),tp=POS[idx],tx=wx(tp.x),ty=wy(tp.y),key=Math.round(kk.t0*100);
  var sy=GEO.ret.y+(srng(key+j*17)-0.5)*3.6,spx=wx(mx),spy=wy(sy);
  var pA=Math.min(1,p/0.18),pB=Math.min(1,Math.max(0,(p-0.18)/0.82)),bn=2+Math.floor(srng(key+j*31)*2.99),amp=(5+srng(j*7+Math.round(kk.t0*10))*5)*k;
  var x,y,z=0;
  if(pB<=0){x=spx+ws(4)-ws(13)*pA;y=spy;}
  else{var e=1-Math.pow(1-pB,2.3),bx=spx-ws(9);x=bx+(tx-bx)*e;y=spy+(ty-spy)*Math.pow(pB,0.85);z=Math.abs(Math.sin(pB*Math.PI*bn))*amp*Math.pow(1-pB,1.4);}
  return {x:x,y:y,z:z,p:p,inPipe:pB<=0,ex:ex,ld:ld,tx:tx,ty:ty,mouthX:spx,slot:idx};}
function drawReturn(){var s=sim.s,kk=s.suck;if(!kk)return;var sc=PPSim.spill(kk.t0,kk.n);retLight=0;
  for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);if(!q)break;
    if(RT-q.ex<0.3)retLight=1;
    ctx.fillStyle="rgba(0,0,0,0.30)";ctx.beginPath();ctx.ellipse(q.x,q.y+ws(2.2),ws(2.8),ws(1.3),0,0,6.28);ctx.fill();
    if(q.inPipe){ctx.save();ctx.beginPath();ctx.rect(0,0,q.mouthX-ws(1.2),H);ctx.clip();}
    potato(q.x,q.y-q.z,Math.max(3,ws(3.3)),false,Math.floor(q.p*9)%2===0,0,["#5a3418","#7a4c28","#9a6a34","#d89a54"]);
    if(q.inPipe)ctx.restore();}
  if(retLight){var my=wy(GEO.ret.y-GEO.ret.w/2-0.2);R(wx(GEO.ret.mouthX+8),my,2,1,"#40ff70");}}
function bindSprites(){
  if(!window.PPSprites04)return null;
  PPSprites04.bind({ctx:ctx,k:k,camX:camX,camY:camY,frame:ANIM_F,t:ANIM_T,wx:wx,wy:wy,ws:ws});
  return PPSprites04;
}
function itemXY(id){return sim.placeOf(id);}
function drawWorkLine04(){
  var S=bindSprites();if(!S)return;
  var stC=sim.lineOn("conveyor")?"on":"off";
  if(sim.owned("conveyor"))S.drawConveyorRun(GEO.beltX,GEO.beltY0,GEO.beltY1,stC);
  if(sim.owned("suction"))S.draw("suction",sim.lineOn("suction")?"on":"off",GEO.suction.x,GEO.suction.y);
  if(sim.owned("autoPeeler")){var p=itemXY("autoPeeler");S.draw("autoPeeler",sim.lineOn("peeler")?"on":"off",p.x,p.y,{bounds:{x0:GEO.WALL+1,y0:GEO.WALL+1,x1:RW-GEO.WALL-1,y1:RH-GEO.WALL-1}});}
  if(sim.owned("outConveyor")){
    var st=sim.lineOn("outbelt")?"on":"off";
    S.drawConveyorRunH(GEO.outBeltY,GEO.outBeltX0,GEO.outBeltX1,st,{peeled:true,cap1:false,maxP:0.70});
    S.drawConveyorRun(GEO.shipBeltX,GEO.shipBeltY0,GEO.shipBeltY1,st,{peeled:true,cap0:false,cap1:false,minP:0.16,maxP:0.90});
  }
}
function drawItems04(){
  var S=bindSprites();if(!S)return;
  var g=sim.s.g,a=g.act,watching=a&&(a.t==="watch"||(a.t==="walk"&&a.then==="watch"));
  var watering=a&&(a.t==="water"||(a.t==="walk"&&a.then==="water"));
  var tuning=a&&(a.t==="tune"||(a.t==="walk"&&a.then==="tune"));
  var sweeping=a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"));
  var washing=a&&(a.t==="wash"||(a.t==="walk"&&a.then==="wash"));
  function st(id,onId){return sim.owned(id)?(sim.s.box[onId||id]>0?"on":"off"):null;}
  if(sim.owned("rug")){var r=itemXY("rug");S.draw("rug","on",r.x,r.y);}
  if(sim.owned("lamp")){var lp=itemXY("lamp");S.draw("lamp",sim.s.box.lamp>0?"on":"off",lp.x,lp.y);}
  if(sim.owned("radio")){var rd=itemXY("radio");S.draw("radio",tuning?"on":(sim.s.box.radio>0?"on":"off"),rd.x,rd.y);}
  if(sim.owned("plant")){var pl=itemXY("plant");var dry=sim.s.decor&&sim.s.decor.plant>=70;S.draw("plant",dry?"off":"on",pl.x,pl.y);}
  if(sim.owned("tvArmchair")){var tv=itemXY("tvArmchair");S.draw("tvArmchair",sim.s.box.tv>0?"on":"off",tv.x,tv.y);}
  if(sim.owned("sink")){var sk=itemXY("sink");S.draw("sink",washing?"on":"on",sk.x,sk.y);}
  if(sim.owned("betterPeeler")){var bp=itemXY("betterPeeler");S.draw("betterPeeler",a&&a.t==="peel"?"on":"off",bp.x,bp.y);}
  if(sim.owned("smallCooler")){var sc=itemXY("smallCooler");S.draw("smallCooler",sim.s.food>0?"on":"off",sc.x,sc.y);}
  if(sim.owned("basicCot")){var ct=itemXY("basicCot");S.draw("basicCot","off",ct.x,ct.y);}
  if(sim.owned("carryBag")&&!sim.s.g.hold){var bg=itemXY("carryBag");S.draw("carryBag","off",bg.x,bg.y);}
  if(sim.owned("broomDustpan")){
    var br=itemXY("broomDustpan");
    if(sweeping)S.draw("broomDustpan","on",GEO.spill.x,GEO.spill.y+8);
    else S.draw("broomDustpan","off",br.x,br.y);
  }
  if(editMode)drawEditOverlay();
}
function drawPeelerPeels(){
  var S=bindSprites();if(!S||!sim.owned("autoPeeler")||!sim.s.line)return;
  var b={x0:GEO.WALL+1,y0:GEO.WALL+1,x1:RW-GEO.WALL-1,y1:RH-GEO.WALL-1};
  var p=itemXY("autoPeeler");
  var peels=S.peelerPeelWorld(p.x,p.y,ANIM_F,b);
  for(var i=0;i<peels.length;i++)S.peelFlake(wx(peels[i].x),wy(peels[i].y),peels[i].ang,ws(peels[i].settled?1.7:2.0));
}
function drawEditOverlay(){
  var ids=["table","cooler","stool","mat","betterPeeler","carryBag","sink","broomDustpan","smallCooler","basicCot","conveyor","suction","plant","lamp","autoPeeler","outConveyor","radio","rug","tvArmchair"];
  ctx.save();ctx.globalAlpha=0.9;
  for(var i=0;i<ids.length;i++){
    var id=ids[i];
    if(["table","cooler","stool","mat"].indexOf(id)<0&&!sim.owned(id))continue;
    var p=id==="table"?{x:(GEO.table.x0+GEO.table.x1)/2,y:(GEO.table.y0+GEO.table.y1)/2}:id==="cooler"?{x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:(GEO.cooler.y0+GEO.cooler.y1)/2}:id==="stool"?{x:GEO.stool.x,y:GEO.stool.y}:id==="mat"?{x:GEO.mat.x,y:GEO.mat.y}:id==="conveyor"?{x:GEO.beltX,y:(GEO.beltY0+GEO.beltY1)/2}:id==="suction"?{x:GEO.suction.x,y:GEO.suction.y}:id==="outConveyor"?{x:(GEO.outBeltX0+GEO.outBeltX1)/2,y:GEO.outBeltY}:itemXY(id);
    var x=wx(p.x),y=wy(p.y);
    ctx.strokeStyle=dragId===id?"#ffe066":"#9fc0ff";ctx.lineWidth=1;
    ctx.strokeRect(x-ws(6),y-ws(6),ws(12),ws(12));
  }
  ctx.restore();
  ctx.font="700 10px Courier New,monospace";ctx.fillStyle="#ffe066";ctx.textAlign="left";
  ctx.fillText("EDITOR: drag items. Pile, return and shipping stay put.",8,16);
}
function worldFromEvent(e){
  var r=playRect||$("play").getBoundingClientRect();
  var sx=(e.clientX-r.left)/r.width*W, sy=(e.clientY-r.top)/r.height*H;
  return {x:sx/k+camX,y:sy/k+camY};
}
function hitEditItem(wx0,wy0){
  var ids=["tvArmchair","autoPeeler","sink","basicCot","smallCooler","betterPeeler","carryBag","broomDustpan","plant","lamp","radio","rug","table","cooler","stool","mat"];
  var best=null,bestD=999;
  for(var i=0;i<ids.length;i++){
    var id=ids[i];
    if(["table","cooler","stool","mat"].indexOf(id)<0&&!sim.owned(id))continue;
    var p=id==="table"?{x:(GEO.table.x0+GEO.table.x1)/2,y:(GEO.table.y0+GEO.table.y1)/2}:id==="cooler"?{x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:(GEO.cooler.y0+GEO.cooler.y1)/2}:id==="stool"?{x:GEO.stool.x,y:GEO.stool.y}:id==="mat"?{x:GEO.mat.x,y:GEO.mat.y}:itemXY(id);
    var d=Math.abs(wx0-p.x)+Math.abs(wy0-p.y);
    if(d<12&&d<bestD){best=id;bestD=d;}
  }
  return best;
}

function drawScene(now){if(W<2||H<2)return;tickAnim(now);ensureStatic();var s=sim.s;blitLayer(staticLayer);
  drawWorkLine04();
  drawShipChute();
  renderMess(Math.min(s.peels,MESSVIS));blitLayer(messLayer);
  if(sim.owned("autoPeeler"))drawPeelerPeels();
  renderPile(Math.min(s.pile,MAXVIS));blitLayer(pileLayer);
  drawItems04();
  drawGuy(now);drawFlights();drawDust();drawShipAnim(now);drawCoolerHum();drawReturnRattle();drawSucks();drawReturn();}

/* ---------- HUD ---------- */
var $=function(id){return document.getElementById(id);};
var hud={};
function coinIcon(){var g=$("coinIco").getContext("2d");var r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};
  r(3,1,8,12,"#c4a020");r(4,0,6,14,"#c4a020");r(2,2,10,10,"#c4a020");r(4,1,6,12,"#ffe066");r(3,2,8,10,"#ffe066");r(5,2,4,10,"#fff3a0");r(4,3,6,8,"#fff3a0");r(6,5,2,5,"#c4a020");r(5,6,4,1,"#c4a020");
  var f=$("foodIco").getContext("2d");var q=function(x,y,w,h,c){f.fillStyle=c;f.fillRect(x,y,w,h);};
  q(1,5,12,7,"#5a3a20");q(2,6,10,5,"#c08040");q(2,4,10,2,"#e8c070");q(3,3,8,1,"#f5e0a8");q(4,7,2,2,"#7a4a20");q(8,8,2,1,"#7a4a20");
  var pl=$("peelIco").getContext("2d");var w=function(x,y,ww,h,c){pl.fillStyle=c;pl.fillRect(x,y,ww,h);};
  w(2,3,9,2,"#b08838");w(2,2,9,2,"#f5e0a8");w(10,4,2,4,"#e8c070");w(3,6,9,2,"#d4a04a");w(3,5,8,2,"#f5e0a8");w(2,8,2,3,"#e8c070");w(3,10,9,2,"#b08838");w(3,9,9,2,"#e8c070");}
function setText(id,v){if(hud[id]!==v){hud[id]=v;$(id).textContent=v;}}
var boxSnap="";
function messPct(){return Math.round((1-sim.messF())*100);}
function updateHud(){var s=sim.s;var bs="",ci;for(ci=0;ci<CMDS.length;ci++)bs+=s.box[CMDS[ci].id]+",";bs+=s.potCap+","+s.up.chute;if(bs!==boxSnap){boxSnap=bs;renderAll();}
  setText("coins",String(s.coins));setText("peels",String(s.peels));if($("level"))setText("level",s.level+" / 5");var mp=messPct();
  var pe=$("peelRow"),pc="food peels"+(mp>=22?" filthy":(mp>=8?" messy":""));if(hud.pc!==pc){hud.pc=pc;pe.className=pc;}
  var mt=mp>=1?"MESS: "+mp+"% SLOWER":"";if(hud.mt!==mt){hud.mt=mt;var me=$("mess");me.textContent=mt;me.className="mess"+(mp>=8?" on":"");}setText("food",s.food+(s.food>=sim.foodMax()?" MAX":""));
  $("foodRow").className="food"+(s.food<=0?" out":"");
  var h=Math.round(s.hunger),e=Math.round(s.energy);
  if(hud.h!==h){hud.h=h;$("hFill").style.transform="scaleX("+(h/100)+")";$("hPct").textContent=h+"%";$("hBar").className="bar hunger"+(h<20?" low":"");}
  if(hud.e!==e){hud.e=e;$("eFill").style.transform="scaleX("+(e/100)+")";$("ePct").textContent=e+"%";$("eBar").className="bar energy"+(e<20?" low":"");}
  var st=sim.stateName();if(hud.st!==st){hud.st=st;var els=document.querySelectorAll(".st");for(var i=0;i<els.length;i++)els[i].classList.toggle("on",els[i].getAttribute("data-s")===st);}
  var a=s.g.act;setText("doing",a&&a.label?a.label:"");
  /* object labels carry live numbers */
  tagText("tagFood","FOOD x"+s.food);tagText("tagPot","POTATOES "+POTS[s.box.pot]);tagText("tagRet",s.chute>0?"RETURN "+s.chute+"/"+sim.chuteCap():"RETURN");
  var hasP=sim.owned("autoPeeler"),hasL=sim.owned("outConveyor"),hasS=sim.owned("sink"),hasT=sim.owned("tvArmchair");
  function tagOn(id,on){var el=$(id);if(!el)return;el.className="tag"+(on&&(performance.now()<labelsUntil)?" ":" off");}
  tagOn("tagPeeler",hasP);tagOn("tagLine",hasL);tagOn("tagSink",hasS);tagOn("tagTV",hasT);

  var can=s.coins>=Math.min(sim.price(),sim.potPrice()||9999)?" can":"";var sb=$("shopBtn");var sc2="shopb"+can;if(hud.sb!==sc2){hud.sb=sc2;sb.className=can?"can":"";}
  if(ovlMode){$("ovlCoins").textContent=ovlMode==="shop"?s.coins+"c":"";if(ovlDirty){ovlDirty=false;buildOvl();}}
  updateHint();}
function tagText(id,t){var key="t"+id;if(hud[key]!==t){hud[key]=t;var el=$(id);el.textContent=t;if(playRect)placeTagsSoon();}}
var tagTimer=0;function placeTagsSoon(){if(tagTimer)return;tagTimer=setTimeout(function(){tagTimer=0;if(playRect)placeTags();},60);}
var hintShown="",migUntil=0;
function updateHint(){var s=sim.s,msg="";
  if(migrated&&performance.now()<migUntil)msg="Welcome back. Your "+migrated+" save was carried over ("+migrated+" itself is untouched).";
  else if(s.peels>=45&&s.box.clean===0&&s.t<7200)msg="The floor is a mess: he works "+messPct()+"% slower. Set CLEAN WHEN PEELS > to make him sweep.";
  else if(s.box.eat===0&&s.box.nap===0&&s.t<20)msg="Tap a box to unlock its slider. Set EAT and NAP or he goes lazy. HELP explains every box.";
  else if(s.box.eat>0&&s.food<=0&&s.hunger<s.box.eat)msg="Out of food! He's slacking. Open the SHOP (or set KEEP FOOD AT LEAST).";
  else if(s.g.lazy&&s.box.eat===0&&s.hunger<C.lazyLow)msg="Hungry and no EAT box set: he's going lazy.";
  else if(s.g.lazy&&s.box.nap===0&&s.energy<C.lazyLow)msg="Tired and no NAP box set: he naps wherever.";
  if(msg!==hintShown){hintShown=msg;var el=$("hint");if(msg){el.textContent=msg;el.className="";}else el.className="off";}}
function popCoin(v,sloppy){var el=document.createElement("div");el.className="pop";el.textContent="+"+v+"c"+(sloppy?" sloppy":"");
  var x=(wx(chute.cx)/W)*playRect.width,y=(wy(chute.lip+6)/H)*playRect.height;el.style.left=Math.round(x+8)+"px";el.style.top=Math.round(y)+"px";$("play").appendChild(el);pops.push({el:el,t:0,y:y});}
function tickPops(dt){for(var i=pops.length-1;i>=0;i--){var p=pops[i];p.t+=dt;p.el.style.transform="translateY("+(-p.t*22)+"px)";p.el.style.opacity=String(Math.max(0,1-p.t/1.2));if(p.t>1.2){p.el.parentNode&&p.el.parentNode.removeChild(p.el);pops.splice(i,1);}}}

/* ---------- command panel: scroll-safe (Jay t1015) ----------
   Built from PPSim.COMMANDS, the same table the HELP screen reads, so the two can never drift apart.
   A slider is LOCKED until you tap its box (the box lights up). Vertical drags always scroll the panel and never move a slider.
   + and - always work (they act on a clean tap). SHOP / HELP also need a clean tap, so scrolling can't open them. A slide applies its value where the finger lifts. */
var cmd=$("cmd"),focusId=null;
function fmt(id,v){
  var c=null,i;for(i=0;i<CMDS.length;i++)if(CMDS[i].id===id)c=CMDS[i];
  if(c&&c.fmt==="onoff")return v>0?"ON":"OFF";
  if(c&&c.fmt==="speed")return (PPSim.SPEED_NAME||["OFF","SLOW","STEADY","FAST"])[v]||String(v);
  if(c&&c.fmt==="dry")return v>0?"> "+v:"OFF";
  if(id==="pace")return PACE[v]+" x"+SPD[v];
  if(id==="pot")return String(POTS[v]);
  if(id==="clean")return v>0?"> "+v:"OFF";
  if(id==="style")return STYLE[v].n+" x"+STYLE[v].sp;
  if(id==="wake")return v+"%";
  if(id==="autob")return v>0?">= "+v:"OFF";
  return v>0?"< "+v+"%":"OFF";}
function bmax(id){return id==="pot"?Math.max(1,sim.potMax()):BOX[id].max;}
function pct(id,v){var b=BOX[id];return (v-b.min)/(bmax(id)-b.min);}
var UNSET={eat:1,nap:1,clean:1,autob:1,suction:1,conveyor:1,apeeler:1,outbelt:1,lamp:1,radio:1,tv:1,watch:1,water:1,wash:1};
function visCmds(){return sim.visibleCommands?sim.visibleCommands():CMDS;}
function buildPanel(){var h="",list=visCmds(),i,c;
  for(i=0;i<list.length;i++){c=list[i];
    h+='<div class="box" data-id="'+c.id+'"><button class="pm" data-d="1" aria-label="'+c.name+' up">+</button><div class="mid"><div class="top"><span class="nm">'+c.name.replace(/</g,"&lt;").replace(/>/g,"&gt;")+'</span><span class="lk"></span><span class="val"></span></div><div class="trk"><div class="ln"></div><div class="fill"></div><div class="kn"></div></div></div><button class="pm" data-d="-1" aria-label="'+c.name+' down">&minus;</button></div>';}
  $("boxes").innerHTML=h;}
function renderTicks(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),trk=el.querySelector(".trk"),b=BOX[id],mx=bmax(id),old=trk.querySelectorAll(".tk");for(var j=0;j<old.length;j++)trk.removeChild(old[j]);
  var n=Math.max(1,Math.round((mx-b.min)/b.step)),tn=Math.min(n,14);for(var i=0;i<=tn;i++){var t=document.createElement("i");t.className="tk";t.style.left=(i/tn*100)+"%";trk.appendChild(t);}}
function renderBox(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),v=sim.s.box[id],p=pct(id,v);
  el.querySelector(".kn").style.left=((1-p)*100)+"%";el.querySelector(".fill").style.width=(p*100)+"%";el.querySelector(".val").textContent=fmt(id,v);
  el.classList.toggle("unset",!!UNSET[id]&&v===0);el.classList.toggle("focus",focusId===id);el.querySelector(".lk").textContent=focusId===id?"<SLIDE>":"";
  var key=id==="pot"?"tk"+sim.potMax():"tk";if(el.getAttribute("data-tk")!==key){el.setAttribute("data-tk",key);renderTicks(id);}}
function renderAll(){var list=visCmds(),i,el;
  for(i=0;i<list.length;i++){el=cmd.querySelector('.box[data-id="'+list[i].id+'"]');if(el)renderBox(list[i].id);}}
function rebuildPanel(){buildPanel();renderAll();}

function setFocus(id){focusId=id;renderAll();}
buildPanel();
function changed(){renderAll();updateHud();saveGame();}
function valFromX(id,trk,clientX){var r=trk.getBoundingClientRect(),b=BOX[id];var q=(clientX-r.left)/r.width;q=Math.max(0,Math.min(1,q));return b.min+(1-q)*(bmax(id)-b.min);}
var G=null; /* the active gesture */
var SLOP=8;
function doAct(a){
  if(a==="shop")openOvl("shop");else if(a==="help")openOvl("help");else if(a==="close")closeOvl();
  else if(a==="book:next")flipBook(1);else if(a==="book:prev")flipBook(-1);
  else if(a==="editor")toggleEditor();
  else if(a==="zoom:in")zoomBy(1);else if(a==="zoom:out")zoomBy(-1);
  else if(a==="pan:up")panBy(0,-18);else if(a==="pan:down")panBy(0,18);
  else if(a==="pan:left")panBy(-14,0);else if(a==="pan:right")panBy(14,0);
  else if(a==="pan:reset")resetView();
  else if(a&&a.indexOf("buy:")===0)shopBuy(a.slice(4));}
function toggleEditor(){
  editMode=!editMode;dragId=null;
  var b=$("editBtn"),pl=$("play");
  if(b)b.classList.toggle("on",editMode);
  if(pl)pl.classList.toggle("editing",editMode);
  showLabels(editMode?60000:8000,!!editMode);
}

cmd.addEventListener("pointerdown",function(e){if(G&&G.id!==e.pointerId)return;
  var t=e.target,box=t.closest?t.closest(".box"):null,pm=t.closest?t.closest(".pm"):null,trk=t.closest?t.closest(".trk"):null,btn=t.closest?t.closest("#bar button"):null;
  G={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:cmd.scrollTop,box:box,bid:box?box.getAttribute("data-id"):null,pm:pm,trk:trk,btn:btn,mode:null};
  if(pm)pm.classList.add("press");if(btn)btn.classList.add("press");
  try{cmd.setPointerCapture(e.pointerId);}catch(x){}
  e.preventDefault();});
cmd.addEventListener("pointermove",function(e){if(!G||G.id!==e.pointerId)return;var dx=e.clientX-G.x0,dy=e.clientY-G.y0;
  if(G.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){
    if(Math.abs(dy)>=Math.abs(dx)*0.75)G.mode="scroll";
    else if(G.bid&&G.bid===focusId&&(G.trk||(!G.pm)))G.mode="slide";
    else G.mode="none";
    if(G.pm)G.pm.classList.remove("press");if(G.btn)G.btn.classList.remove("press");}
  if(G.mode==="scroll")cmd.scrollTop=G.st0-dy;
  else if(G.mode==="slide"){var trk=G.box.querySelector(".trk");if(sim.setBox(G.bid,valFromX(G.bid,trk,e.clientX)))changed();}});
function endG(e,cancel){if(!G||G.id!==e.pointerId)return;var g=G;G=null;if(g.pm)g.pm.classList.remove("press");if(g.btn)g.btn.classList.remove("press");
  /* a slide ends where the finger lifts: a slow WebView may not deliver a final move */
  if(!cancel&&g.mode==="slide"){var tk=g.box.querySelector(".trk");if(sim.setBox(g.bid,valFromX(g.bid,tk,e.clientX)))changed();return;}
  if(cancel||g.mode!==null)return;
  /* slow old WebViews can deliver a swipe as down -> up with few or no moves: judge by where the finger lifted */
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)cmd.scrollTop=g.st0-dy;return;}
  /* a clean tap */
  if(g.pm&&g.bid){var d=+g.pm.getAttribute("data-d");setFocus(g.bid);if(sim.setBox(g.bid,sim.s.box[g.bid]+d*BOX[g.bid].step))changed();return;}
  if(g.btn){doAct(g.btn.getAttribute("data-act"));return;}
  if(g.bid){if(focusId===g.bid&&g.trk){if(sim.setBox(g.bid,valFromX(g.bid,g.trk,e.clientX)))changed();}else setFocus(g.bid);return;}
  setFocus(null);}
cmd.addEventListener("pointerup",function(e){endG(e,false);});
cmd.addEventListener("pointercancel",function(e){endG(e,true);});
cmd.addEventListener("lostpointercapture",function(e){if(G&&G.id===e.pointerId&&G.mode!==null)endG(e,true);});
var GL=[];window.__ppGL=GL;["pointerdown","pointermove","pointerup","pointercancel"].forEach(function(t){cmd.addEventListener(t,function(e){GL.push(t.slice(7)+":"+Math.round(e.clientX)+","+Math.round(e.clientY)+(G?":"+G.mode:""));if(GL.length>40)GL.shift();},true);});
cmd.addEventListener("click",function(e){e.preventDefault();});
var PE=null;
$("play").addEventListener("pointerdown",function(e){
  if(focusId)setFocus(null);showLabels(8000);
  if(editMode){
    var w=worldFromEvent(e),hit=hitEditItem(w.x,w.y);
    if(hit){dragId=hit;PE={id:e.pointerId,act:"drag",item:hit};try{e.currentTarget.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();}
  }
});
$("play").addEventListener("pointermove",function(e){
  if(!PE||PE.id!==e.pointerId)return;
  if(PE.act==="drag"&&dragId){var w=worldFromEvent(e);if(sim.moveItem(dragId,w.x,w.y)){staticLayer=null;if(playRect)placeTags();}}
});
function endPE(e){
  if(!PE||PE.id!==e.pointerId)return;
  if(PE.btn&&PE.btn.classList)PE.btn.classList.remove("press");
  if(PE.act==="drag"){dragId=null;saveGame();}
  PE=null;
}
$("play").addEventListener("pointerup",endPE);
$("play").addEventListener("pointercancel",endPE);
function bindRail(el){if(!el)return;
  el.addEventListener("pointerdown",function(e){
    var btn=e.target.closest?e.target.closest("[data-act]"):null;if(!btn||!el.contains(btn))return;
    doAct(btn.getAttribute("data-act"));btn.classList.add("press");
    PE={id:e.pointerId,act:btn.getAttribute("data-act"),btn:btn};
    try{el.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();
  });
  el.addEventListener("pointerup",endPE);
  el.addEventListener("pointercancel",endPE);
}
bindRail($("leftRail"));bindRail($("rightRail"));

/* ---------- shop + help screens (same scroll-safe rule: a tap is judged where the finger lifts; drags scroll) ---------- */
var ovl=$("ovl"),ovlBody=$("ovlBody"),ovlMode=null,ovlDirty=false,OG=null;
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function goBtn(act,price,state){var cls="go"+(state==="poor"?" poor":"")+(state==="done"?" done":"");
  return '<button class="'+cls+'" type="button" data-act="'+act+'">'+(state==="done"?"MAXED":price+"c<br>BUY")+'</button>';}
function buildShop(){var s=sim.s,h="",pr=sim.price(),fm=sim.foodMax(),i,it,st,lp;
  h+='<div class="sec">LEVEL</div>';
  lp=sim.levelPrice();
  h+='<div class="row"><div class="tx"><div class="nm">LEVEL <b>'+s.level+' / 5</b></div><div class="fx">Pay coins to level up. Each level unlocks machines and decorations, then you buy them below. Lv1 is the six starters.</div></div>'+(lp===null?goBtn("buy:lv",0,"done"):goBtn("buy:lv",lp,s.coins<lp?"poor":""))+'</div>';
  h+='<div class="sec">UNLOCKED ITEMS</div>';
  for(i=0;i<PPSim.ITEMS.length;i++){
    it=PPSim.ITEMS[i];
    if(s.level<it.lv)continue;
    st=sim.owned(it.id)?"done":(s.coins<it.price?"poor":"");
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>Lv'+it.lv+'</b></div><div class="fx">'+esc(it.fx)+'</div></div>'+goBtn("buy:item:"+it.id,it.price,st)+'</div>';
  }
  var locked=0;for(i=0;i<PPSim.ITEMS.length;i++)if(s.level<PPSim.ITEMS[i].lv)locked++;
  if(locked)h+='<div class="row"><div class="tx"><div class="nm">LOCKED</div><div class="fx">'+locked+' more item'+(locked>1?"s":"")+' unlock at higher levels. (They are hidden, not deleted.)</div></div></div>';
  h+='<div class="sec">FOOD</div>';
  h+='<div class="row"><div class="tx"><div class="nm">FOOD CAN <b>'+s.food+' / '+fm+'</b></div><div class="fx">One can = +55 hunger when he eats. The price climbs a little with each can and slowly over time.</div></div>'+(s.food>=fm?goBtn("buy:food",pr,"done"):goBtn("buy:food",pr,s.coins<pr?"poor":""))+'</div>';
  h+='<div class="sec">POTATOES</div>';var pp=sim.potPrice(),cap=s.potCap;
  h+='<div class="row"><div class="tx"><div class="nm">MORE POTATOES <b>'+POTS[cap]+(pp===null?'':' &rarr; '+POTS[cap+1])+'</b></div><div class="fx">You own '+POTS[cap]+'. Buying raises your limit to the next stop and puts the new potatoes on the pile. The POTATOES IN PLAY slider goes up to what you own.</div></div>'+(pp===null?goBtn("buy:pot",0,"done"):goBtn("buy:pot",pp,s.coins<pp?"poor":""))+'</div>';
  h+='<div class="sec">UPGRADES</div>';
  for(var i=0;i<UPS.length;i++){var u=UPS[i],lv=sim.up(u.id),p2=sim.upPrice(u.id);
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(u.name)+' <b>LV '+lv+'/'+u.max+'</b></div><div class="fx">'+esc(u.fx)+'</div></div>'+(p2===null?goBtn("buy:up:"+u.id,0,"done"):goBtn("buy:up:"+u.id,p2,s.coins<p2?"poor":""))+'</div>';}
  ovlBody.innerHTML=h;}
/* ---- the HELP booklet: cover, one page per command (generated from PPSim.COMMANDS), a last page on the loop. Flip with PREV / NEXT or a sideways swipe. ---- */
var bookPage=0;
function bookPages(){return CMDS.length+6;}      /* cover + every command + levels + line + editor/zoom + decor + loop */
function icoDraw(cv2,id){var g=cv2.getContext("2d"),r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};g.clearRect(0,0,16,16);
  if(id==="cover"){r(2,2,12,12,"#8a5a28");r(3,3,10,10,"#c48a48");r(4,4,8,2,"#e8c070");r(5,8,2,2,"#6a4020");r(9,9,2,2,"#6a4020");r(6,11,2,1,"#6a4020");}
  else if(id==="pace"){r(1,6,3,1,"#8a6a40");r(0,9,4,1,"#8a6a40");r(2,12,3,1,"#8a6a40");r(5,3,3,10,"#c0361e");r(8,5,2,6,"#c0361e");r(10,6,2,4,"#c0361e");r(12,7,2,2,"#c0361e");}
  else if(id==="eat"){r(3,4,10,9,"#7a3a10");r(3,5,10,7,"#e0a040");r(3,4,10,1,"#f0e0b0");r(4,8,8,2,"#b04020");r(6,2,4,2,"#9aa49a");}
  else if(id==="nap"){r(1,5,14,8,"#3a3a50");r(2,6,12,6,"#e8e4d4");r(6,7,8,5,"#4a6aa8");r(2,7,4,4,"#fffaf0");r(9,3,3,1,"#4a6aa8");r(11,2,3,1,"#4a6aa8");r(9,4,3,1,"#4a6aa8");}
  else if(id==="clean"){for(var i=0;i<9;i++)r(11-i,1+i,2,2,"#8a6840");r(1,10,8,5,"#c8a860");r(1,13,8,2,"#8a6a30");for(var j=0;j<4;j++)r(2+j*2,10,1,5,"#5a4020");}
  else if(id==="pot"){r(4,5,8,7,"#8a5a28");r(3,6,10,5,"#8a5a28");r(5,4,6,1,"#c48a48");r(5,5,3,1,"#e8c070");r(6,8,1,1,"#4a2810");r(9,9,1,1,"#4a2810");r(7,11,1,1,"#4a2810");r(4,12,8,1,"#4a2810");}
  else if(id==="style"){r(2,10,5,3,"#3a2a20");r(6,8,8,3,"#c8d0d8");r(7,8,7,1,"#f0f4f8");r(12,7,2,1,"#c8d0d8");r(3,3,2,1,"#e8c070");r(6,2,3,1,"#e8c070");r(10,4,2,1,"#e8c070");}
  else if(id==="wake"){r(6,6,4,4,"#ffe066");r(5,7,6,2,"#ffe066");r(7,2,2,2,"#ffd060");r(7,12,2,2,"#ffd060");r(2,7,2,2,"#ffd060");r(12,7,2,2,"#ffd060");r(4,4,1,1,"#ffd060");r(11,4,1,1,"#ffd060");r(4,11,1,1,"#ffd060");r(11,11,1,1,"#ffd060");}
  else if(id==="autob"){r(2,6,9,8,"#7a3a10");r(2,7,9,6,"#e0a040");r(2,6,9,1,"#f0e0b0");r(9,1,5,5,"#c4a020");r(10,2,3,3,"#ffe066");r(11,3,1,1,"#c4a020");}
  else{r(1,7,3,3,"#8a6a40");r(3,6,10,5,"#3a4038");r(4,7,8,3,"#12141a");r(5,3,6,1,"#c0361e");r(7,2,2,1,"#c0361e");r(5,12,6,1,"#3ad070");}}
function miniSlider(c,v){var mx=c.id==="pot"?Math.max(1,sim.potMax()):c.max,p=(v-c.min)/(mx-c.min),n=Math.max(1,Math.round((mx-c.min)/c.step)),tn=Math.min(n,14),tk="";
  for(var i=0;i<=tn;i++)tk+='<i class="tk" style="left:'+(i/tn*100)+'%"></i>';
  return '<div class="mini"><span class="e">'+esc(c.hi)+'</span><div class="mt"><div class="ln"></div><div class="mf" style="width:'+(p*100)+'%"></div>'+tk+'<div class="mk" style="left:'+((1-p)*100)+'%"></div></div><span class="e r">'+esc(c.lo)+'</span></div>';}
function pageHtml(pg){var s=sim.s,N=bookPages(),pn='<span class="pn">'+(pg+1)+' / '+N+'</span>';
  if(pg===0)return '<div id="pg" class="cover"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><div class="t1">PAPA POTATO</div><div class="t2">HANDBOOK</div><button class="go2" type="button" data-act="book:next">OPEN THE BOOK</button><div class="note" style="margin-top:12px;color:#d8b878">'+CMDS.length+' commands, plus levels, the line, the editor and decor</div></div>';
  if(pg===N-1)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="loop" width="16" height="16"></canvas><b>THE LOOP</b></div><div class="lb">WHAT HE DOES</div><div class="chips"><span>PILE</span><span>&gt; PEEL TABLE</span><span>&gt; SHIP IN</span><span>&gt; RETURN</span><span>&gt; PILE</span></div><div class="tx">Or buy the work line: pile &gt; suction &gt; conveyor &gt; auto-peeler &gt; out-conveyor &gt; shipping. Peels land on the floor inside the room. CLEAN sends him to sweep them.</div><div class="lb">YOUR COINS GO TO</div><div class="chips"><span>LEVELS</span><span>ITEMS</span><span>FOOD</span><span>POTATOES</span><span>UPGRADES</span></div><div class="tx">Open the SHOP. Tap the room to see object names. +/− zoom and scroll arrows sit in the side rails (never over the room). EDIT moves furniture (not the pile, return or shipping).</div></div>';
  if(pg===N-5)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><b>LEVELS</b></div><div class="lb">PAY TO LEVEL UP</div><div class="tx">You start at Level 1. Pay coins in the SHOP to reach the next level (up to 5). Each level UNLOCKS items; you still BUY them in the shop. Lv1 is the six starters (better peeler, carry bag, sink, broom, small cooler, cot).</div><div class="lb">UPGRADES</div><div class="tx">Old upgrades (sharp peeler, boots, chute, cooler, broom, soft bed) stay. New ones speed the auto-peeler and belts and grow the carry bag. Unused items stay in the game, just hidden until unlocked.</div></div>';
  if(pg===N-4)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="loop" width="16" height="16"></canvas><b>THE WORK LINE</b></div><div class="lb">MACHINES</div><div class="tx">CONVEYOR, AUTO SUCTION, AUTO-PEELER and OUT-CONVEYOR. Each has an on/off or speed slider once bought. The out-conveyor butts the shipping intake and is drawn under it. Peeled potatoes ride in and get sucked through. Peels always land inside the room.</div><div class="lb">COMMANDS</div><div class="tx">SUCTION, CONVEYOR SPEED, AUTO-PEELER SPEED, OUT-CONVEYOR SPEED. Faster belts and peelers come from the BETTER BELTS / FASTER AUTO-PEELER upgrades.</div></div>';
  if(pg===N-3)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="wake" width="16" height="16"></canvas><b>EDITOR AND ZOOM</b></div><div class="lb">EDITOR</div><div class="tx">Tap EDITOR, then drag any item except the potato pile, the return chute and the shipping chute. Those three stay put. Your layout is saved with the game.</div><div class="lb">ZOOM AND SCROLL</div><div class="tx">The zoom +/− and scroll arrows live in the side rails, outside the room — the room shrinks to fit between them, and nothing draws over the play area. +/− zoom like FunMotion (75% to 300%). Arrow buttons scroll the room. The centre dot resets to a fitted view.</div></div>';
  if(pg===N-2)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="nap" width="16" height="16"></canvas><b>DECORATIONS</b></div><div class="lb">WHAT HE DOES</div><div class="tx">LAMP on/off. RADIO on/off — he walks over to tune it. PLANT dries out; WATER WHEN DRY sends him to water it. TV + ARMCHAIR: turn the TV on and set WATCH WHEN ENERGY &lt; so he sits and watches (slow energy, not a nap). Sleep is still the 0.3.1 bed, unchanged.</div></div>';
  if(pg-1>=CMDS.length)return '<div id="pg">'+pn+'<div class="tx">Missing page.</div></div>';
  var c=CMDS[pg-1],v=s.box[c.id];
  return '<div id="pg" data-cmd="'+c.id+'">'+pn+'<div class="hd"><canvas class="ic" data-ic="'+c.id+'" width="16" height="16"></canvas><b>'+esc(c.name)+'</b></div><div class="lb">DOES</div><div class="tx">'+esc(c.does)+'</div><div class="lb">SLIDER</div>'+miniSlider(c,v)+'<div class="now">NOW: '+esc(fmt(c.id,v))+'</div><div class="lb">AFFECTS</div><div class="tx">'+esc(c.affects)+'</div><div class="lb">RANGE</div><div class="rg">'+esc(c.range)+'</div></div>';}
function buildBook(dir){var N=bookPages(),h='<div id="book">'+pageHtml(bookPage)+'<div id="bkNav"><button type="button" data-act="book:prev"'+(bookPage<=0?' class="dis"':'')+'>&lt; PREV</button><div class="dots">';
  for(var i=0;i<N;i++)h+='<i'+(i===bookPage?' class="on"':'')+'></i>';h+='</div><button type="button" data-act="book:next"'+(bookPage>=N-1?' class="dis"':'')+'>NEXT &gt;</button></div></div>';
  ovlBody.innerHTML=h;var cs=ovlBody.querySelectorAll("canvas.ic");for(var j=0;j<cs.length;j++)icoDraw(cs[j],cs[j].getAttribute("data-ic"));
  if(dir){var pg=$("pg");pg.className=(pg.className?pg.className+" ":"")+(dir>0?"flipn":"flipp");}}
function flipBook(d){d=+d;d=d>0?1:(d<0?-1:0);var n=Math.max(0,Math.min(bookPages()-1,bookPage+d));if(n===bookPage)return false;bookPage=n;buildBook(d);return true;}
function buildOvl(){var st=ovlBody.scrollTop;ovlBody.className=ovlMode==="help"?"book":"";if(ovlMode==="shop")buildShop();else if(ovlMode==="help")buildBook(0);ovlBody.scrollTop=ovlMode==="shop"?st:0;$("ovlCoins").textContent=ovlMode==="shop"?sim.s.coins+"c":"";}
function openOvl(mode){ovlMode=mode;ovl.className="on";$("ovlTitle").textContent=mode==="shop"?"SHOP":"HELP BOOKLET";ovlBody.scrollTop=0;if(mode==="help")bookPage=0;buildOvl();if(focusId)setFocus(null);}
function closeOvl(){ovlMode=null;ovl.className="";OG=null;}
function flash(btn,txt){if(!btn)return;var old=btn.innerHTML;btn.innerHTML=txt;setTimeout(function(){if(ovlMode)ovlDirty=true;},700);}
function shopBuy(what){var r,btn=ovl.querySelector('[data-act="buy:'+what+'"]'),pr;
  if(what==="food"){pr=sim.price();r=sim.buyFood();}
  else if(what==="pot"){pr=sim.potPrice();r=sim.buyPotatoes();}
  else if(what==="lv"){pr=sim.levelPrice();r=sim.buyLevel();}
  else if(what.indexOf("item:")===0){var iid=what.slice(5);pr=sim.itemPrice(iid);r=sim.buyItem(iid);if(r==="ok")rebuildPanel();}
  else if(what.indexOf("up:")===0){var id=what.slice(3);pr=sim.upPrice(id);r=sim.buyUp(id);}
  else return "bad";
  if(r==="ok"){if(btn)btn.innerHTML="BOUGHT!";setTimeout(function(){ovlDirty=true;},600);changed();}
  else if(r==="poor"){if(btn)btn.innerHTML="NEED<br>"+pr+"c";setTimeout(function(){ovlDirty=true;},800);}
  else{if(btn)btn.innerHTML=r==="full"?"FULL":"MAXED";setTimeout(function(){ovlDirty=true;},800);}
  updateHud();saveGame();return r;}
ovl.addEventListener("pointerdown",function(e){if(OG&&OG.id!==e.pointerId)return;var t=e.target,btn=t.closest?t.closest("[data-act]"):null;
  OG={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:ovlBody.scrollTop,btn:btn,mode:null};if(btn)btn.classList.add("press");
  try{ovl.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();});
ovl.addEventListener("pointermove",function(e){if(!OG||OG.id!==e.pointerId)return;var dx=e.clientX-OG.x0,dy=e.clientY-OG.y0;
  if(OG.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){OG.mode=Math.abs(dy)>=Math.abs(dx)*0.75?"scroll":"none";if(OG.btn)OG.btn.classList.remove("press");}
  if(OG.mode==="scroll")ovlBody.scrollTop=OG.st0-dy;});
function endO(e,cancel){if(!OG||OG.id!==e.pointerId)return;var g=OG;OG=null;if(g.btn)g.btn.classList.remove("press");if(cancel)return;
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(ovlMode==="help"&&Math.abs(dx)>=40&&Math.abs(dx)>=Math.abs(dy)*1.2){flipBook(dx<0?1:-1);return;}   /* sideways swipe turns the page, judged where the finger lifts */
  if(g.mode!==null)return;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)ovlBody.scrollTop=g.st0-dy;return;}
  if(g.btn)doAct(g.btn.getAttribute("data-act"));}
ovl.addEventListener("pointerup",function(e){endO(e,false);});
ovl.addEventListener("pointercancel",function(e){endO(e,true);});
ovl.addEventListener("click",function(e){e.preventDefault();});

/* ---------- main loop: time runs only while the game is open and visible ---------- */
function events(){var ev=sim.s.ev;while(ev.length){var e=ev.shift();if(e.k==="coin"){popCoin(e.v,e.sloppy);pushSuck(e.sloppy);}else if(e.k==="peel")spawnPeel(e.slot);}}
var last=0,acc=0,STEP=0.05,paused=false,frames=0;
function frame(ts){
  var dt=last?Math.min(0.25,(ts-last)/1000):0;last=ts;
  if(!paused){acc+=dt;while(acc>=STEP){sim.step(STEP);acc-=STEP;}events();tickFlights(dt);tickDust(dt);tickSucks(dt);tickPops(dt);}
  RT=sim.s.t+acc;drawScene(ts);frames++;updateLabels();
  if(frames%6===0)updateHud();
  if(ts-lastSave>2000)saveGame();
  requestAnimationFrame(frame);}
document.addEventListener("visibilitychange",function(){if(document.hidden){paused=true;saveGame();}else{paused=false;last=0;}});
window.addEventListener("pagehide",saveGame);window.addEventListener("beforeunload",saveGame);window.addEventListener("unload",saveGame);
window.addEventListener("resize",function(){layout();drawScene(performance.now());});
/* what is on screen, for the HANDOFF object table and the tests */
var OBJECTS=[
  {id:"ship",name:"SHIP IN (X-ray)",use:"He drops each peeled potato on the conveyor: it rides the belt into the scanner and is sucked in. +2c (+1c sloppy).",gameplay:true},
  {id:"door",name:"METAL DOOR (LOCKED)",use:"No use yet. Heavy industrial door with a red lock light — decoration only.",gameplay:false},
  {id:"return",name:"RETURN chute",use:"A full batch (or an empty pile) spills back out of its mouth onto the pile, raw again.",gameplay:true},
  {id:"table",name:"PEEL TABLE",use:"Where he stands to peel (never walked over: he goes around it).",gameplay:true},
  {id:"bed",name:"BED",use:"NAP WHEN ENERGY < sends him here; SOFT BED upgrade speeds naps.",gameplay:true},
  {id:"cooler",name:"FOOD cooler",use:"Holds the food cans (HUD FOOD count, BIGGER COOLER upgrade); EAT WHEN HUNGER < sends him here.",gameplay:true},
  {id:"stool",name:"SEAT (stool)",use:"The spot he stands on to eat. Position only: it has no effect of its own.",gameplay:false},
  {id:"pile",name:"POTATOES pile",use:"The raw potatoes (POTATOES IN PLAY, shop potatoes). He grabs from its top edge.",gameplay:true},
  {id:"peels",name:"Peels on the floor",use:"Mess: slows him up to 30%; CLEAN WHEN PEELS > and STIFF BROOM deal with it. Auto-peeler peels always land inside the room.",gameplay:true},
  {id:"light",name:"Soft light pool under the table",use:"Lighting only. No gameplay.",gameplay:false},
  {id:"conveyor",name:"CONVEYOR",use:"Inbound belt, pile to auto-peeler. CONVEYOR SPEED. Hidden until bought.",gameplay:true},
  {id:"suction",name:"AUTO SUCTION",use:"Swarm intake on the pile. SUCTION on/off. Hidden until bought.",gameplay:true},
  {id:"autoPeeler",name:"AUTO-PEELER",use:"Peels potatoes onto the out-conveyor; peels shoot to the floor. AUTO-PEELER SPEED.",gameplay:true},
  {id:"outConveyor",name:"OUT-CONVEYOR",use:"Butts the shipping intake (drawn under it). OUT-CONVEYOR SPEED.",gameplay:true},
  {id:"sink",name:"SINK",use:"WASH BEFORE PEEL sends him here for a +1c clean potato.",gameplay:true},
  {id:"tv",name:"TV + ARMCHAIR",use:"WATCH WHEN ENERGY < sits him in the chair facing the glowing TV.",gameplay:true},
  {id:"radio",name:"RADIO",use:"On/off. He walks over to tune it. Small energy tick while it plays.",gameplay:true},
  {id:"plant",name:"PLANT",use:"WATER WHEN DRY sends him to water it. Droops if ignored.",gameplay:true},
  {id:"lamp",name:"LAMP",use:"On/off light in the living nook.",gameplay:true},
  {id:"rug",name:"RUG",use:"Decoration under the TV nook. Movable in the editor.",gameplay:false},
  {id:"cot",name:"BASIC COT",use:"Extra furniture. Naps still use the 0.3.1 soft bed (sleep locked).",gameplay:false}];
coinIcon();layout();rebuildPanel();syncZoomLabel();updateHud();migUntil=performance.now()+9000;RT=sim.s.t;showLabels(30000);drawScene(performance.now());
requestAnimationFrame(frame);
/* test + debug hooks */
window.PP={get sim(){return sim;},Sim:PPSim,save:saveGame,key:SAVE_KEY,reset:function(seed){sim=PPSim.fresh(seed);focusId=null;hud={};boxSnap="";flights=[];flying={};messVer++;sucks=[];rebuildPanel();updateHud();saveGame();},
  reload:function(){sim=loadGame();hud={};flights=[];flying={};messVer++;renderAll();updateHud();},focus:function(){return focusId;},
  pause:function(p){paused=!!p;},layout:function(){return {W:W,H:H,k:k,roomW:roomW,roomH:roomH,offX:offX,offY:offY,detail:DETAIL,fitW:RW*k,fitH:RH*k,dpr:DPR,SC:SC};},version:"0.4",zoom:function(){return {i:zoomI,k:ZOOM_STEPS[zoomI],panX:panX,panY:panY};},setZoom:function(i){zoomI=Math.max(0,Math.min(ZOOM_STEPS.length-1,i|0));applyCam();staticLayer=null;syncZoomLabel();},edit:function(on){if(on==null)return editMode;editMode=!!on;var b=$("editBtn");if(b)b.classList.toggle("on",editMode);},move:function(id,x,y){var r=sim.moveItem(id,x,y);if(r){staticLayer=null;saveGame();}return r;},
  drawAt:function(t){drawScene(t);},animF:function(){return ANIM_F;},sitWorld:sitWorld,setPan:function(x,y){panX=+x||0;panY=+y||0;applyCam();if(playRect)placeTags();syncZoomLabel();},seedSucks:function(arr){sucks=arr||[];},
  setPileMax:function(n){PILEMAX=n;buildPile();pileLayer=null;pileKey=-1;},forcePile:function(n){sim.s.pile=n;},get migrated(){return migrated;},
  stats:function(){return {pileRenders:renders.pile,messRenders:renders.mess,maxVis:MAXVIS,tiers:TIER.slice(),messVis:MESSPOS.length,flights:flights.length,sucks:sucks.length};},
  giveAll:function(){var s=sim.s,i;s.level=5;s.coins=Math.max(s.coins,999);for(i=0;i<PPSim.ITEMS.length;i++){var it=PPSim.ITEMS[i];if(!s.owned[it.id]){s.owned[it.id]=1;s.place[it.id]=PPSim.defaultPlace(it.id);}}s.box.suction=1;s.box.conveyor=2;s.box.apeeler=2;s.box.outbelt=2;s.box.lamp=1;s.box.radio=1;s.box.tv=1;s.box.watch=30;s.box.water=40;s.box.wash=1;s.box.clean=20;s.box.eat=40;s.box.nap=35;sim.rebuildObst();rebuildPanel();changed();},
  objects:function(){return OBJECTS;},labels:function(ms,force){showLabels(ms||8000,force);updateLabels();if(playRect)placeTags();},placeTags:function(){if(playRect)placeTags();},ovl:function(){return ovlMode;},book:function(){return {page:bookPage,pages:bookPages()};},flip:flipBook,open:openOvl,close:closeOvl,buy:shopBuy,
  retView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);o.push(q?{j:j,x:q.x,y:q.y,z:q.z,p:q.p,inPipe:q.inPipe,mouthX:q.mouthX,tx:q.tx,ty:q.ty}:{j:j,p:-1});}return o;},spillView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++)o.push({j:j,ex:sc.ex[j],ld:sc.ld[j],rt:RT});return o;},
  posOf:function(i){return POS[i];},messPos:function(i){return MESSPOS[i];},tagRects:function(){var o={};for(var i=0;i<TAGDEF.length;i++){var r=$(TAGDEF[i].id).getBoundingClientRect();o[TAGDEF[i].id]={x:r.left,y:r.top,w:r.width,h:r.height,on:$(TAGDEF[i].id).className.indexOf("off")<0};}return o;},
  flightsNow:function(){return flights.map(function(f){return {slot:f.slot,t:f.t,dur:f.dur,x0:f.x0,y0:f.y0,tx:f.tx,ty:f.ty,h:f.h};});},cv:function(){return cv;}};
window.__PP_READY=true;
})();
