/* ===== Papa Potato 0.4 — game-ready sprites =====
 * True top-down, Swarm-style crisp hybrid: clean shapes, flat shading,
 * 1px dark outline, imageSmoothing off. Palette and machine language
 * match the 0.3.1 room (shipping x-ray, belt slats, cooler, bed) and
 * the machines-sheet concept art.
 *
 * Drop-in:
 *   PPSprites04.bind({ ctx, k, camX, camY, frame, t });
 *   PPSprites04.draw("autoPeeler", "on", worldX, worldY);
 *   // or PPSprites04.attach({ ctx, wx, wy, ws, k }) to share the game's camera.
 *
 * (x, y) is the sprite's world-unit CENTER. Conveyor runs use
 * PPSprites04.drawConveyorRun(cx, y0, y1, state).
 *
 * Frame clock: 4 frames at 8 fps (125 ms), same as the 0.3.1 ANIM_F.
 * Never print or embed keys/secrets.
 */
(function (root) {
  "use strict";
  var OUT = "#1a1410";
  var FPS = 8;
  var FRAME_MS = 125;
  var ctx = null, k = 1, camX = 0, camY = 0, ANIM_F = 0, ANIM_T = 0;
  var _wx = null, _wy = null, _ws = null;

  function frameAt(nowMs) { return ((nowMs / FRAME_MS) | 0) % 4; }
  function bind(opts) {
    opts = opts || {};
    ctx = opts.ctx;
    k = opts.k == null ? 1 : opts.k;
    camX = opts.camX || 0;
    camY = opts.camY || 0;
    ANIM_F = (opts.frame == null ? ANIM_F : opts.frame) & 3;
    ANIM_T = opts.t == null ? ANIM_T : opts.t;
    _wx = opts.wx || null;
    _wy = opts.wy || null;
    _ws = opts.ws || null;
    if (ctx) { ctx.imageSmoothingEnabled = false; if (ctx.imageSmoothingQuality) ctx.imageSmoothingQuality = "low"; }
    return api;
  }
  function attach(apiIn) { return bind(apiIn); }
  function setFrame(f, t) { ANIM_F = f & 3; if (t != null) ANIM_T = t; }

  function wx(x) { return _wx ? _wx(x) : Math.round((x - camX) * k); }
  function wy(y) { return _wy ? _wy(y) : Math.round((y - camY) * k); }
  function ws(s) { return _ws ? _ws(s) : Math.max(0.6, s * k); }

  function R(x, y, w, h, c) { ctx.fillStyle = c; ctx.fillRect(x, y, Math.max(0.5, w), Math.max(0.5, h)); }
  function wr(x, y, w, h, c) {
    var x0 = wx(x), y0 = wy(y), x1 = wx(x + w), y1 = wy(y + h);
    R(x0, y0, Math.max(0.6, x1 - x0), Math.max(0.6, y1 - y0), c);
  }
  function oval(cx, cy, rw, rh, c) {
    rw = Math.max(0.35, rw); rh = Math.max(0.35, rh);
    ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(cx, cy, rw, rh, 0, 0, 6.283185); ctx.fill();
  }
  function disc(cx, cy, rw, rh, c, out) {
    if (out !== null) oval(cx, cy, rw + 0.7, rh + 0.7, out || OUT);
    oval(cx, cy, rw, rh, c);
  }
  function blob(x, y, w, h, r, c, out) {
    r = Math.max(0.4, r || 1);
    ctx.fillStyle = out || OUT;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x - 0.7, y - 0.7, w + 1.4, h + 1.4, r + 0.7);
    else ctx.rect(x - 0.7, y - 0.7, w + 1.4, h + 1.4);
    ctx.fill();
    ctx.fillStyle = c;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
    else ctx.rect(x, y, w, h);
    ctx.fill();
  }
  function softShadow(cx, cy, rx, ry) {
    rx = rx || 10; ry = ry || 7;
    var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(rx, ry));
    g.addColorStop(0, "rgba(0,0,0,0.28)"); g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, 6.283185); ctx.fill();
  }
  function potato(x, y, s, peeled, flip, spots, pal) {
    var body = pal || (peeled
      ? ["#a88830", "#c8a848", "#e8c868", "#f0d890"]
      : ["#4a2810", "#6a4020", "#8a5a28", "#c48a48"]);
    var out = body[0], dk = body[1], md = body[2], hi = body[3];
    var hw = Math.max(1.2, s), hh = Math.max(0.9, s * 0.72), fx = flip ? 1 : -1;
    oval(x + 0.7, y + 0.7, hw + 0.3, hh + 0.2, "rgba(0,0,0,0.22)");
    disc(x, y, hw, hh, md, out);
    oval(x + fx * hw * 0.16, y - hh * 0.18, hw * 0.62, hh * 0.5, hi);
    oval(x + fx * hw * 0.28, y - hh * 0.32, hw * 0.28, hh * 0.22, peeled ? "#fff3a0" : hi);
    if (!peeled) {
      oval(x + fx * hw * 0.12, y + hh * 0.05, Math.max(0.5, hw * 0.12), Math.max(0.5, hh * 0.12), dk);
      oval(x - fx * hw * 0.28, y + hh * 0.18, Math.max(0.45, hw * 0.1), Math.max(0.45, hh * 0.1), out);
      if (s > 3) oval(x + fx * hw * 0.35, y - hh * 0.08, Math.max(0.45, hw * 0.1), Math.max(0.45, hh * 0.1), "#6a4020");
    } else if (spots) {
      var sp = [[-0.45, -0.25], [0.5, 0.22], [0, 0.45], [-0.28, 0.28], [0.3, -0.3]];
      for (var i = 0; i < Math.min(spots, sp.length); i++)
        oval(x + sp[i][0] * hw, y + sp[i][1] * hh, Math.max(0.4, hw * 0.1), Math.max(0.4, hh * 0.1), "#6a4020");
    }
  }
  function peelFlake(x, y, ang, sc, pal) {
    pal = pal || ["#f5e0a8", "#e8c070", "#b08838"];
    var s = Math.max(1.2, sc || ws(2.2));
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang || 0);
    oval(0.4, 0.4, s * 0.85, s * 0.38, "rgba(0,0,0,0.22)");
    disc(0, 0, s * 0.8, s * 0.34, pal[1], pal[2]);
    oval(-s * 0.15, -s * 0.08, s * 0.45, s * 0.16, pal[0]);
    ctx.restore();
  }
  function bolt(x, y, s) {
    s = s == null ? 1.1 : s;
    wr(x, y, s, s, "#2a2c28");
    wr(x + 0.2, y + 0.15, Math.max(0.4, s - 0.4), Math.max(0.4, s - 0.4), "#c0c8c0");
  }
  function led(x, y, col, on, r) {
    r = r == null ? 0.7 : r;
    disc(wx(x), wy(y), ws(r), ws(r), on ? col : "#2a2010", "#1a1410");
    if (on) {
      ctx.globalAlpha = 0.4;
      oval(wx(x), wy(y), ws(r * 1.7), ws(r * 1.7), col);
      ctx.globalAlpha = 1;
      oval(wx(x) - 0.4, wy(y) - 0.4, Math.max(0.4, ws(r * 0.35)), Math.max(0.4, ws(r * 0.35)), "#fff8e0");
    }
  }

  /* ---------- compact top-down Papa (0.3.1 locked look) for interaction states ---------- */
  function drawPapa(kind, x, y, dir, opt) {
    opt = opt || {};
    var u = k * 0.82;
    var hrU = (opt.hr != null ? opt.hr : (kind === "sleep" ? 3.7 : 6.4));
    var hr = hrU * u;
    var shW = (opt.shW || 14.2) * u, shH = (opt.shH || 6.0) * u;
    var px = wx(x), py = wy(y);
    var breath = kind === "stand" || kind === "idle" ? [0, 0.7, 1.35, 0.5][ANIM_F] * u : 0;
    shH += breath * 0.5;
    function crown(cx, cy) {
      disc(cx, cy + 0.4, hr + 0.7, hr + 0.35, "#2a2018", OUT);
      oval(cx, cy + 0.15, hr - 0.15, hr - 0.35, "#3a2a20");
      oval(cx - hr * 0.22, cy - hr * 0.06, hr * 0.55, hr * 0.48, "#4a3828");
      oval(cx - hr * 0.28, cy - hr * 0.18, Math.max(0.8, hr * 0.42), Math.max(0.6, hr * 0.28), "#5a4630");
      oval(cx - hr * 0.18, cy - hr * 0.28, Math.max(0.5, hr * 0.2), Math.max(0.4, hr * 0.14), "#8a7860");
      oval(cx - hr * 0.12, cy - hr * 0.12, Math.max(0.35, hr * 0.08), Math.max(1.0, hr * 0.55), "#6a5640");
      oval(cx - hr * 0.45, cy - hr + 0.55, Math.max(0.6, hr * 0.18), Math.max(0.5, hr * 0.14), "#2a2018");
      oval(cx - hr * 0.05, cy - hr + 0.35, Math.max(0.7, hr * 0.22), Math.max(0.5, hr * 0.13), "#3a2a20");
      oval(cx + hr * 0.38, cy - hr + 0.55, Math.max(0.55, hr * 0.16), Math.max(0.5, hr * 0.13), "#2a2018");
      var ear = Math.max(0.7, Math.min(1.05 * u, hr * 0.22));
      disc(cx - hr + 0.1, cy + hr * 0.12, ear, ear * 0.92, "#8a6840", OUT);
      oval(cx - hr + 0.1, cy + hr * 0.12, ear * 0.55, ear * 0.55, "#c4a070");
      disc(cx + hr - 0.1, cy + hr * 0.12, ear, ear * 0.92, "#8a6840", OUT);
      oval(cx + hr - 0.1, cy + hr * 0.12, ear * 0.55, ear * 0.55, "#c4a070");
    }
    function body(cx, cy, shy) {
      softShadow(cx, cy + shy + 1.2, shW * 0.52, shH * 0.7);
      disc(cx, cy + shy + 0.25, shW / 2 + 0.15, shH / 2 + 0.45, "#2a4a62", OUT);
      oval(cx, cy + shy - 0.15, shW / 2 - 1.0, shH / 2 - 0.25, "#3a6a8a");
      oval(cx - 0.4, cy + shy - 0.7, Math.max(1.2, shW / 2 - 2.4), Math.max(1.0, shH / 2 - 1.6), "#5a8aaa");
      oval(cx - 0.9, cy + shy - 1.1, Math.max(0.9, shW / 2 - 3.6), Math.max(0.7, shH / 2 - 2.2), "#7aa8c0");
      disc(cx, cy + shy - shH * 0.42, Math.max(0.9, shW * 0.12), 0.85, "#2a4a62", OUT);
      oval(cx, cy + shy - shH * 0.42, Math.max(0.55, shW * 0.08), 0.45, "#c8d0a8");
    }
    var shy = hr + Math.max(1.4, shH * 0.40) + breath * 0.25;
    if (kind === "sit" || kind === "watch") {
      /* True top-down seated, facing east (toward the TV). The whole body stays IN the seat:
         shoulders as a N-S oval between the armrests, crown slightly east, hands on the arms. */
      var su = k * 0.70;
      var sHr = 4.8 * su, sShN = 6.4 * su, sShE = 4.6 * su;
      softShadow(px, py + ws(0.5), sShE * 0.75, sShN * 0.7);
      /* body west of the head (he faces east): N-S shoulders in the seat */
      disc(px - ws(1.0), py, sShE / 2 + 0.25, sShN / 2 + 0.4, "#2a4a62", OUT);
      oval(px - ws(0.85), py - 0.2, sShE / 2 - 0.5, sShN / 2 - 0.35, "#3a6a8a");
      oval(px - ws(1.05), py - 0.5, Math.max(0.8, sShE / 2 - 1.3), Math.max(0.8, sShN / 2 - 1.1), "#5a8aaa");
      disc(px - ws(0.15), py, Math.max(0.6, 0.7 * su), 0.7, "#2a4a62", OUT);
      oval(px - ws(0.15), py, Math.max(0.4, 0.45 * su), 0.4, "#c8d0a8");
      /* hands on the north and south armrests */
      disc(px - ws(0.2), py - sShN * 0.52, 1.2 * su, 1.05 * su, "#c4a070", "#5a3a22");
      disc(px - ws(0.2), py + sShN * 0.52, 1.2 * su, 1.05 * su, "#c4a070", "#5a3a22");
      /* head toward the TV (east), still in the seat */
      var oldHr = hr; hr = sHr;
      crown(px + ws(2.2), py);
      hr = oldHr;
    } else if (kind === "sleep") {
      crown(px, py);
    } else {
      body(px, py, shy);
      /* simple arm nubs */
      disc(px - shW * 0.40, py + shy - shH * 0.42, 2.1 * u, 1.95 * u, "#2a4a62", OUT);
      oval(px - shW * 0.40, py + shy - shH * 0.42, 1.65 * u, 1.5 * u, "#4a7a9a");
      disc(px + shW * 0.40, py + shy - shH * 0.42, 2.1 * u, 1.95 * u, "#2a4a62", OUT);
      oval(px + shW * 0.40, py + shy - shH * 0.42, 1.65 * u, 1.5 * u, "#5a8aaa");
      crown(px, py);
    }
  }

  /* ======================== MACHINES ======================== */

  /* Vertical belt. (cx, cy) = center of a default 11 x 36 segment, or pass opt.y0/opt.y1. */
  function drawConveyor(cx, cy, state, opt) {
    opt = opt || {};
    var h = opt.h || 36, y0 = opt.y0 != null ? opt.y0 : cy - h / 2, y1 = opt.y1 != null ? opt.y1 : cy + h / 2;
    drawConveyorRun(cx, y0, y1, state, opt);
  }
  function drawConveyorRun(cx, y0, y1, state, opt) {
    opt = opt || {};
    var on = state === "on";
    var beltW = 9, rail = 0.9;
    var x0 = cx - beltW / 2;
    if (y1 < y0) { var t = y0; y0 = y1; y1 = t; }
    /* shadow + rails + deck (same language as the shipping belt) */
    wr(x0 - rail + 0.5, y0 + 0.5, beltW + rail * 2, y1 - y0, "rgba(0,0,0,0.30)");
    wr(x0 - rail, y0, beltW + rail * 2, y1 - y0, "#2a2c28");
    wr(x0, y0, beltW, y1 - y0, on ? "#4a4a44" : "#3a3a36");
    wr(x0, y0, beltW, 0.5, "#6a6a60");
    wr(x0 - rail, y0, rail, y1 - y0, "#6a7068");
    wr(x0 + beltW, y0, rail, y1 - y0, "#3a4038");
    wr(x0 - rail, y0, beltW + rail * 2, 0.6, "#8a9088");
    wr(x0 - rail, y1 - 0.6, beltW + rail * 2, 0.6, "#2a2c28");
    /* roller caps; cap0 = north (y0), cap1 = south (y1). Omit at a butt joint. */
    if (opt.cap0 !== false) {
      wr(x0 - 1.2, y0 - 0.4, beltW + 2.4, 1.6, "#3a4038");
      wr(x0 - 0.7, y0 - 0.1, beltW + 1.4, 1.0, on ? "#9aa49a" : "#6a7068");
    }
    if (opt.cap1 !== false) {
      wr(x0 - 1.2, y1 - 1.2, beltW + 2.4, 1.6, "#3a4038");
      wr(x0 - 0.7, y1 - 0.9, beltW + 1.4, 1.0, on ? "#9aa49a" : "#6a7068");
    }
    /* slats travel north (toward the peeler). 4 discrete frames, period 3.2 like the ship belt. */
    var period = 3.2, off = on ? (ANIM_F / 4) * period : 0;
    var slatC = on ? "#6a6a58" : "#4a4a44", slatH = on ? "#8a8a70" : "#5a5a52";
    for (var y = y0 - period + off; y < y1; y += period) {
      var a = Math.max(y0 + 0.4, y), b = Math.min(y1 - 0.4, y + 1.3);
      if (b <= a) continue;
      wr(x0 + 0.3, a, beltW - 0.6, b - a, slatC);
      wr(x0 + 0.3, a, beltW - 0.6, 0.35, slatH);
    }
    /* potatoes riding (on) or sitting still (off, one idle) */
    var slots = opt.slots || (on ? [0.18, 0.42, 0.68, 0.88] : [0.55]);
    var minP = opt.minP || 0;
    var maxP = opt.maxP == null ? 1 : opt.maxP;
    for (var i = 0; i < slots.length; i++) {
      var p = slots[i];
      if (on) p = (p + ANIM_F * 0.04) % 1; /* crawl north with the slats */
      if (p < minP || p > maxP) continue;
      var py = y1 - 2 - p * (y1 - y0 - 4);
      var peeled = !!(opt.peeled);
      potato(wx(cx + (i % 2 ? 0.6 : -0.4)), wy(py), Math.max(2.4, ws(2.6)), peeled, i % 2 === 1, peeled ? 0 : 0);
    }
    /* tiny status lamp on the east rail */
    led(cx + beltW / 2 + 0.6, y0 + 2.2, on ? "#40ff70" : "#3a2010", on, 0.65);
  }

  /* Horizontal belt. Slats and potatoes travel toward x1 (east, into shipping). */
  function drawConveyorRunH(cy, x0, x1, state, opt) {
    opt = opt || {};
    var on = state === "on";
    var beltW = 9, rail = 0.9;
    if (x1 < x0) { var t = x0; x0 = x1; x1 = t; }
    var y0 = cy - beltW / 2;
    wr(x0 + 0.5, y0 - rail + 0.5, x1 - x0, beltW + rail * 2, "rgba(0,0,0,0.30)");
    wr(x0, y0 - rail, x1 - x0, beltW + rail * 2, "#2a2c28");
    wr(x0, y0, x1 - x0, beltW, on ? "#4a4a44" : "#3a3a36");
    wr(x0, y0 - rail, x1 - x0, rail, "#6a7068");
    wr(x0, y0 + beltW, x1 - x0, rail, "#3a4038");
    wr(x0, y0 - rail, 0.6, beltW + rail * 2, "#8a9088");
    wr(x1 - 0.6, y0 - rail, 0.6, beltW + rail * 2, "#2a2c28");
    if (opt.cap0 !== false) {
      wr(x0 - 0.4, y0 - 1.2, 1.6, beltW + 2.4, "#3a4038");
      wr(x0 - 0.1, y0 - 0.7, 1.0, beltW + 1.4, on ? "#9aa49a" : "#6a7068");
    }
    if (opt.cap1 !== false) {
      wr(x1 - 1.2, y0 - 1.2, 1.6, beltW + 2.4, "#3a4038");
      wr(x1 - 0.9, y0 - 0.7, 1.0, beltW + 1.4, on ? "#9aa49a" : "#6a7068");
    }
    var period = 3.2, off = on ? (ANIM_F / 4) * period : 0;
    var slatC = on ? "#6a6a58" : "#4a4a44", slatH = on ? "#8a8a70" : "#5a5a52";
    for (var x = x0 - period + off; x < x1; x += period) {
      var a = Math.max(x0 + 0.4, x), b = Math.min(x1 - 0.4, x + 1.3);
      if (b <= a) continue;
      wr(a, y0 + 0.3, b - a, beltW - 0.6, slatC);
      wr(a, y0 + 0.3, 0.35, beltW - 0.6, slatH);
    }
    if (opt.potatoes !== false) {
      var slots = opt.slots || (on ? [0.18, 0.42, 0.68, 0.88] : [0.55]);
      var peeled = opt.peeled !== false; /* outbound default: peeled */
      var minP = opt.minP || 0;
      var maxP = opt.maxP == null ? 1 : opt.maxP;
      for (var i = 0; i < slots.length; i++) {
        var p = slots[i];
        if (on) p = (p + ANIM_F * 0.04) % 1;
        if (p < minP || p > maxP) continue;
        var px = x0 + 2 + p * (x1 - x0 - 4);
        potato(wx(px), wy(cy + (i % 2 ? 0.5 : -0.4)), Math.max(2.4, ws(2.6)), peeled, i % 2 === 1, 0);
      }
    }
    led(x1 - 2.2, cy - beltW / 2 - 0.6, on ? "#40ff70" : "#3a2010", on, 0.65);
  }

  function drawSuction(cx, cy, state, opt) {
    opt = opt || {};
    var on = state === "on";
    var w = 16, h = 14;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    /* housing — squat intake hood, mouth opens south toward the pile */
    wr(x0 + 0.6, y0 + 0.6, w, h, "rgba(0,0,0,0.32)");
    wr(x0, y0, w, h - 3.2, "#3a4038");
    wr(x0 + 0.6, y0 + 0.6, w - 1.2, h - 4.4, "#5a6258");
    wr(x0 + 0.6, y0 + 0.6, w - 1.2, 1.2, "#9aa49a");
    wr(x0, y0, 0.8, h - 3.2, "#8a9088");
    wr(x0 + w - 0.8, y0, 0.8, h - 3.2, "#2a2c28");
    /* flared south mouth */
    wr(x0 - 1.2, y0 + h - 4.2, w + 2.4, 4.4, "#3a4038");
    wr(x0 - 0.6, y0 + h - 3.8, w + 1.2, 3.6, "#4a5248");
    wr(x0 + 1.6, y0 + h - 3.2, w - 3.2, 2.8, "#12141a");
    wr(x0 + 2.0, y0 + h - 2.8, w - 4.0, 2.0, "#1a1020");
    /* round intake throat */
    disc(wx(cx), wy(y0 + h - 1.6), ws(4.4), ws(1.6), "#08060c", "#1a1410");
    oval(wx(cx), wy(y0 + h - 1.6), ws(3.2), ws(1.05), "#120818");
    /* corner bolts + a top handle */
    bolt(x0 + 0.8, y0 + 0.8, 1.1);
    bolt(x0 + w - 1.9, y0 + 0.8, 1.1);
    bolt(x0 + 0.8, y0 + h - 5.4, 1.1);
    bolt(x0 + w - 1.9, y0 + h - 5.4, 1.1);
    wr(x0 + w / 2 - 3, y0 - 1.2, 6, 1.6, "#3a4038");
    wr(x0 + w / 2 - 2.5, y0 - 0.9, 5, 1.0, "#8a9088");
    /* status cluster */
    led(x0 + 2.4, y0 + 3.0, "#ff3050", on, 0.7);
    led(x0 + 4.2, y0 + 3.0, "#40ff70", on && ANIM_F >= 2, 0.55);
    led(x0 + 5.8, y0 + 3.0, "#ffd040", on && (ANIM_F === 1 || ANIM_F === 3), 0.55);
    /* Swarm suction rings, ported from the shipping suck (red expanding arcs into the mouth) */
    if (on) {
      var mx = wx(cx), my = wy(y0 + h - 2.2);
      var tt = ANIM_T || (ANIM_F * 0.125);
      ctx.save();
      for (var q = 0; q < 3; q++) {
        var rad = ws(2.4) + ((tt * 16 + q * 5.4 + ANIM_F * 2) % ws(9));
        ctx.globalAlpha = (0.34 + 0.20 * Math.sin((tt * 20) + q)) * (1 - rad / ws(14));
        ctx.strokeStyle = "#ff3050";
        ctx.lineWidth = Math.max(1.2, ws(0.35));
        ctx.beginPath();
        ctx.arc(mx, my, Math.max(1, rad), 0.12, 3.02);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,160,170,0.55)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(mx, my, Math.max(1, rad - 1.2), 0.18, 2.96);
        ctx.stroke();
      }
      /* inward dust motes */
      ctx.globalAlpha = 0.7;
      for (var m = 0; m < 6; m++) {
        var a = (m / 6) * 3.0 + 0.2 + ANIM_F * 0.2;
        var rr = ws(6.5) - ANIM_F * ws(1.1) - (m % 3) * ws(0.8);
        R(mx + Math.cos(a) * rr, my + Math.sin(a) * rr * 0.55, 1, 1, "#ff8090");
      }
      ctx.restore();
      /* a potato mid-suck, shrinking toward the mouth */
      var suckP = [0.85, 0.6, 0.38, 0.18][ANIM_F];
      var psz = Math.max(1.6, ws(2.8) * suckP);
      potato(mx, my + ws(3.5) * suckP, psz, false, ANIM_F % 2 === 0, 0);
    }
  }

  /* World-unit peel landings / mid-air flakes for the auto-peeler.
     The arc ejects SOUTH-EAST of the box onto the floor, never west into a wall.
     All default positions sit in a 0.4-room inner floor (x 8..100, y 8..272). */
  var DEFAULT_ROOM = { x0: 8, y0: 8, x1: 100, y1: 272 };
  function clampRoom(x, y, b) {
    b = b || DEFAULT_ROOM;
    return {
      x: Math.max(b.x0, Math.min(b.x1, x)),
      y: Math.max(b.y0, Math.min(b.y1, y))
    };
  }
  function peelerPeelWorld(cx, cy, frame, bounds) {
    var boxW = 18, boxH = 16, x0 = cx - boxW / 2, y0 = cy - boxH / 2, y1 = y0 + boxH;
    var shots = [
      { p: 0.12, ox: 0.2, oy: 0.0 },
      { p: 0.36, ox: 1.6, oy: 0.8 },
      { p: 0.60, ox: 0.8, oy: 1.6 },
      { p: 0.84, ox: 2.2, oy: 0.4 }
    ];
    var out = [];
    for (var i = 0; i < shots.length; i++) {
      var ph = (shots[i].p + (frame & 3) * 0.18) % 1;
      /* SE floor: start at the SE slot, arc south-east, settle on the floor */
      var px = x0 + boxW + 1.2 + ph * 7.0 + shots[i].ox;
      var py = y1 + 1.4 + ph * 6.0 + Math.sin(ph * 2.4) * 1.2 + shots[i].oy;
      var c = clampRoom(px, py, bounds);
      out.push({ x: c.x, y: c.y, ang: ph * 4.2 + i, flying: ph < 0.82, rawX: px, rawY: py, clamped: c.x !== px || c.y !== py });
    }
    /* settled peel pile on the floor (always inside) */
    var settled = [[3.0, 3.2], [5.2, 4.6], [4.0, 6.0], [6.4, 5.2], [7.2, 7.0], [2.4, 5.8]];
    for (var s = 0; s < settled.length; s++) {
      var q = clampRoom(x0 + boxW + settled[s][0], y1 + settled[s][1], bounds);
      out.push({ x: q.x, y: q.y, ang: s * 0.9, flying: false, settled: true, rawX: q.x, rawY: q.y, clamped: false });
    }
    return out;
  }

  function drawAutoPeeler(cx, cy, state, opt) {
    opt = opt || {};
    var on = state === "on" || state === "peeling";
    var boxW = 18, boxH = 16;
    var x0 = cx - boxW / 2, y0 = cy - boxH / 2, y1 = y0 + boxH;
    /* boxy housing — same language as the shipping x-ray unit */
    wr(x0 + 0.6, y0 + 0.6, boxW, boxH, "rgba(0,0,0,0.32)");
    wr(x0, y0, boxW, boxH, "#3a4038");
    wr(x0 + 0.6, y0 + 0.6, boxW - 1.2, boxH - 1.2, "#5a6258");
    wr(x0 + 0.6, y0 + 0.6, boxW - 1.2, 1.2, "#9aa49a");
    wr(x0 + 0.6, y1 - 1.6, boxW - 1.2, 1, "#2a2c28");
    wr(x0, y0, 0.8, boxH, "#8a9088");
    wr(x0 + boxW - 0.8, y0, 0.8, boxH, "#2a2c28");
    /* viewing window */
    wr(x0 + 3.4, y0 + 3.6, boxW - 6.8, boxH - 8.0, "#12141a");
    wr(x0 + 3.8, y0 + 4.0, boxW - 7.6, boxH - 8.8, on ? "#1a2030" : "#10141c");
    wr(x0 + 3.8, y0 + 4.0, boxW - 7.6, 0.6, on ? "#3a5068" : "#1a2430");
    if (on) {
      var g = [0.08, 0.13, 0.18, 0.11][ANIM_F];
      ctx.globalAlpha = g;
      wr(x0 + 3.8, y0 + 4.0, boxW - 7.6, boxH - 8.8, "#40a0ff");
      ctx.globalAlpha = 1;
      /* potato in the chamber, mid-peel */
      var mid = ANIM_F >= 2;
      potato(wx(cx), wy(cy - 0.4), Math.max(2.6, ws(2.8)), mid, ANIM_F % 2 === 0, mid ? 2 : 0);
    }
    /* corner bolts */
    bolt(x0 + 0.8, y0 + 0.8, 1.1);
    bolt(x0 + boxW - 1.9, y0 + 0.8, 1.1);
    bolt(x0 + 0.8, y0 + boxH - 1.9, 1.1);
    bolt(x0 + boxW - 1.9, y0 + boxH - 1.9, 1.1);
    /* tiny blinking lights along the north edge — the "peeling" tell */
    var cols = ["#ff3050", "#ffd040", "#40ff70", "#40c0ff"];
    for (var i = 0; i < 4; i++) {
      var lit = on && ((ANIM_F + i) % 4 !== 3); /* chase, one dark per frame */
      if (on && i === ANIM_F) lit = true;
      led(x0 + 4.2 + i * 2.6, y0 + 2.0, cols[i], lit, 0.62);
    }
    /* south mouth (in from conveyor) + lead curtains */
    var mx0 = cx - 4.2, mw = 8.4;
    for (var s = 0; s < 6; s++) wr(mx0 + s * 1.4, y1 - 1.2, 1.1, 2.2, s % 2 ? "#2a2c28" : "#3a4038");
    var bl = 1.6, hy = y1 + 0.4, hx0 = cx - 5;
    for (var x = 0, n = 0; x < 10; x += bl, n++) wr(hx0 + x, hy, bl, 1.1, n % 2 ? "#2a2a24" : "#e0b020");
    /* east exit lip — feeds the outbound conveyor toward shipping */
    wr(x0 + boxW, y0 + 5.5, 2.6, 5.2, "#3a4038");
    wr(x0 + boxW, y0 + 5.9, 2.2, 4.4, "#2a2c28");
    wr(x0 + boxW + 0.3, y0 + 6.3, 1.6, 3.6, on ? "#1a2030" : "#12141a");
    /* SE peel-eject slot (onto the floor inside the room, not into a wall) */
    wr(x0 + boxW - 4.0, y1, 3.6, 2.2, "#3a4038");
    wr(x0 + boxW - 3.6, y1 + 0.3, 2.8, 1.6, "#12141a");
    if (on) {
      var peels = peelerPeelWorld(cx, cy, ANIM_F, opt.bounds);
      for (var p = 0; p < peels.length; p++) {
        peelFlake(wx(peels[p].x), wy(peels[p].y), peels[p].ang, ws(peels[p].settled ? 1.7 : 2.0));
      }
    }
    /* nameplate */
    wr(x0 + 5.5, y1 - 3.4, 7, 1.6, "#2a2c28");
    wr(x0 + 5.8, y1 - 3.15, 6.4, 1.1, on ? "#3a5040" : "#2a3028");
  }

  /* ======================== LV1 STARTERS ======================== */

  function drawBetterPeeler(cx, cy, state, opt) {
    var on = state === "on" || state === "peeling";
    var x = cx, y = cy;
    /* Y-peeler, top-down: metal head with a slot, colored handle, 1px outline */
    softShadow(wx(x), wy(y + 0.8), ws(5), ws(2.2));
    /* handle */
    wr(x - 5.2, y - 1.15, 6.2, 2.3, OUT);
    wr(x - 5.0, y - 0.95, 5.8, 1.9, "#3a2a20");
    wr(x - 5.0, y - 0.95, 5.8, 0.55, "#6a4a30");
    wr(x - 4.7, y - 0.55, 4.6, 0.55, on ? "#8a6a48" : "#5a3a28");
    /* bolster */
    wr(x + 0.8, y - 1.25, 1.3, 2.5, "#2a2c28");
    wr(x + 0.95, y - 1.05, 1.0, 2.1, "#8a9088");
    /* Y head */
    wr(x + 1.8, y - 1.55, 3.6, 3.1, OUT);
    wr(x + 2.0, y - 1.35, 3.2, 2.7, "#8a9098");
    wr(x + 2.0, y - 1.35, 3.2, 0.6, "#e8eef4");
    wr(x + 2.3, y - 0.55, 2.6, 1.1, "#4a5058"); /* blade slot */
    wr(x + 2.3, y - 0.35, 2.6, 0.35, "#c8d0d8");
    if (on) {
      /* gleam + a curl of peel coming off the slot */
      wr(x + 2.4, y - 1.2, 0.7, 0.35, "#ffffff");
      peelFlake(wx(x + 3.2), wy(y - 2.8 - ANIM_F * 0.4), -0.8 - ANIM_F * 0.25, ws(1.8));
    }
  }

  function drawCarryBag(cx, cy, state, opt) {
    var full = state === "on" || state === "full" || state === "carrying";
    var carrying = state === "carrying";
    var w = 11, h = full ? 10 : 7.5;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    if (carrying) drawPapa("stand", cx, cy - 2.2, 0, { shW: 12.5, shH: 5.4, hr: 5.8 });
    softShadow(wx(cx), wy(cy + h * 0.35), ws(w * 0.55), ws(h * 0.35));
    /* burlap sack, cinched top, same family as the bagger concept */
    blob(wx(x0), wy(y0 + (full ? 1.6 : 0.8)), ws(w), ws(h - (full ? 1.6 : 0.8)), ws(2.2), full ? "#8a6a38" : "#6a5230", "#3a2a14");
    /* cloth highlight + stitch */
    wr(x0 + 1.4, y0 + (full ? 2.2 : 1.4), w - 2.8, 0.7, full ? "#c8a860" : "#8a7050");
    wr(x0 + 2, y0 + (full ? 4.2 : 3.0), w - 4, 0.4, "#5a4020");
    wr(x0 + 2, y0 + (full ? 6.2 : 4.6), w - 4, 0.4, "#5a4020");
    /* cinch + two ear loops */
    wr(x0 + 3.2, y0 + (full ? 1.0 : 0.4), w - 6.4, 1.2, "#5a3a18");
    wr(x0 + 3.5, y0 + (full ? 1.15 : 0.55), w - 7.0, 0.7, "#c8a860");
    disc(wx(x0 + 2.4), wy(y0 + 0.6), ws(1.1), ws(0.7), "#5a3a18", OUT);
    disc(wx(x0 + w - 2.4), wy(y0 + 0.6), ws(1.1), ws(0.7), "#5a3a18", OUT);
    if (full) {
      potato(wx(cx - 1.6), wy(y0 + 0.2), Math.max(2.0, ws(2.1)), false, false, 0);
      potato(wx(cx + 1.8), wy(y0 + 0.5), Math.max(1.8, ws(1.9)), false, true, 0);
      if (!carrying) potato(wx(cx + 0.2), wy(y0 - 0.4), Math.max(1.7, ws(1.8)), false, false, 0);
    }
  }

  function drawSink(cx, cy, state, opt) {
    var on = state === "on" || state === "washing";
    var washing = state === "washing";
    var w = 16, h = 14;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    softShadow(wx(cx), wy(cy + 2), ws(w * 0.5), ws(h * 0.4));
    /* stainless basin, top-down, rim + bowl (washer-tub cousin, more sink-like) */
    wr(x0 + 0.5, y0 + 0.5, w, h, "rgba(0,0,0,0.28)");
    wr(x0, y0, w, h, "#3a4038");
    wr(x0 + 0.5, y0 + 0.5, w - 1, h - 1, "#8a9098");
    wr(x0 + 0.5, y0 + 0.5, w - 1, 0.8, "#e8eef4");
    wr(x0 + 0.5, y0 + h - 1.2, w - 1, 0.7, "#5a6058");
    wr(x0 + 1.8, y0 + 2.4, w - 3.6, h - 4.6, "#4a5058");
    wr(x0 + 2.2, y0 + 2.8, w - 4.4, h - 5.4, on ? "#3a6a9a" : "#2a3038");
    if (on) {
      wr(x0 + 2.2, y0 + 2.8, w - 4.4, 0.6, "#8ab8e0");
      /* ripple rings, 4 frames */
      var rx = wx(cx), ry = wy(cy + 0.6);
      ctx.strokeStyle = "rgba(200,230,255,0.45)";
      ctx.lineWidth = 1;
      for (var q = 0; q < 2; q++) {
        ctx.beginPath();
        ctx.ellipse(rx, ry, ws(2.2 + q * 1.6 + ANIM_F * 0.45), ws(1.3 + q * 0.9 + ANIM_F * 0.25), 0, 0, 6.28);
        ctx.stroke();
      }
      potato(wx(cx - 2.4), wy(cy + 0.8), Math.max(2.1, ws(2.3)), false, false, 0);
      potato(wx(cx + 2.2), wy(cy + 1.3), Math.max(1.9, ws(2.1)), false, true, 0);
      potato(wx(cx + 0.2), wy(cy - 0.4), Math.max(1.7, ws(1.9)), false, false, 0);
    } else {
      /* dry drain */
      disc(wx(cx), wy(cy + 0.8), ws(1.3), ws(1.3), "#1a1c18", "#3a4038");
      disc(wx(cx), wy(cy + 0.8), ws(0.6), ws(0.6), "#12141a", null);
    }
    /* faucet at the north rim */
    wr(cx - 0.7, y0 - 0.2, 1.4, 2.6, "#3a4038");
    wr(cx - 0.5, y0, 1.0, 2.2, "#c0c8c0");
    wr(cx - 0.5, y0, 1.0, 0.4, "#e8eef4");
    wr(cx - 0.7, y0 + 2.2, 2.4, 1.1, "#8a9098");
    wr(cx - 0.5, y0 + 2.35, 2.0, 0.7, "#c0c8c0");
    if (on) {
      /* dripping / flowing stream, 4 frames */
      var fl = [1.2, 2.0, 2.8, 1.6][ANIM_F];
      wr(cx + 1.0, y0 + 3.3, 0.7, fl, "#8ab8e0");
      wr(cx + 1.15, y0 + 3.3, 0.35, fl, "#d0e8f8");
    }
    /* handles */
    wr(x0 + 2.4, y0 + 0.7, 2.0, 1.1, "#4a5048");
    wr(x0 + 2.55, y0 + 0.85, 1.7, 0.7, on ? "#c0c8c0" : "#6a7068");
    wr(x0 + w - 4.4, y0 + 0.7, 2.0, 1.1, "#4a5048");
    wr(x0 + w - 4.25, y0 + 0.85, 1.7, 0.7, "#8a9098");
    if (washing) drawPapa("stand", cx, cy + 9.5, 0);
  }

  function drawBroomDustpan(cx, cy, state, opt) {
    opt = opt || {};
    var on = state === "on" || state === "sweeping";
    var sweeping = state === "sweeping";
    /* Floor peel patch NORTH of Papa — broom bristles sit ON this mess. */
    var messY = sweeping ? -8.0 : 4.4;
    var mess = [
      [0.2, messY + 0.8], [2.0, messY], [3.6, messY + 1.0], [1.2, messY - 1.0], [3.0, messY - 1.4], [4.6, messY - 0.4],
      [-0.8, messY - 0.2], [1.6, messY - 2.2], [4.0, messY - 1.8], [2.6, messY + 1.4]
    ];
    if (on || sweeping) {
      for (var m = 0; m < mess.length; m++)
        peelFlake(wx(cx + mess[m][0]), wy(cy + mess[m][1]), m * 0.7, ws(1.7));
    }
    var swing = on ? [-2.4, 0.2, 2.6, 0.3][ANIM_F] : 0;
    /* dustpan on the floor WEST and slightly SOUTH of Papa — drawn BEFORE him so it never covers his hair */
    var dx = cx - 10.4, dy = cy + 6.8;
    wr(dx - 3.2 + 0.4, dy - 1.6 + 0.4, 6.6, 4.4, "rgba(0,0,0,0.25)");
    wr(dx - 3.2, dy - 1.6, 6.6, 4.4, OUT);
    wr(dx - 3.0, dy - 1.4, 6.2, 4.0, "#8a3028");
    wr(dx - 3.0, dy - 1.4, 6.2, 0.7, "#c05040");
    wr(dx - 2.4, dy - 0.4, 5.0, 2.4, "#5a2018");
    wr(dx - 2.4, dy - 0.4, 5.0, 0.4, "#a04030");
    if (on) {
      peelFlake(wx(dx - 0.4), wy(dy + 0.4), 0.4, ws(1.5));
      peelFlake(wx(dx + 1.2), wy(dy + 0.9), -0.6, ws(1.3));
    }
    /* Papa stands SOUTH of the mess so the broom can reach north into the peels. */
    if (sweeping) drawPapa("stand", cx, cy + 3.8, 0);
    /* broom: handle at Papa, tip NORTH on the peel patch, 4-frame side-to-side stroke */
    var bx = cx + (sweeping ? 1.6 : 2.4) + swing * 0.25;
    var by = cy + (sweeping ? 2.4 : -1.2);
    var tipX = cx + 1.2 + swing;
    var tipY = cy + (sweeping ? -8.2 : 5.4);
    var hx0 = wx(bx), hy0 = wy(by), hx1 = wx(tipX), hy1 = wy(tipY);
    ctx.lineCap = "round";
    ctx.strokeStyle = OUT; ctx.lineWidth = Math.max(2.2, ws(1.15) + 1.3);
    ctx.beginPath(); ctx.moveTo(hx0, hy0); ctx.lineTo(hx1, hy1); ctx.stroke();
    ctx.strokeStyle = "#8a6840"; ctx.lineWidth = Math.max(1.4, ws(1.15));
    ctx.beginPath(); ctx.moveTo(hx0, hy0); ctx.lineTo(hx1, hy1); ctx.stroke();
    ctx.strokeStyle = "#c8a860"; ctx.lineWidth = Math.max(0.6, ws(0.4));
    ctx.beginPath(); ctx.moveTo(hx0, hy0); ctx.lineTo(hx1, hy1); ctx.stroke();
    disc(wx(tipX), wy(tipY), ws(2.8), ws(1.4), "#5a4020", OUT);
    oval(wx(tipX), wy(tipY - 0.4), ws(2.4), ws(0.95), "#c8a860");
    wr(tipX - 2.3, tipY - 0.1, 4.6, 0.35, "#6a4a20");
    if (on) {
      ctx.globalAlpha = 0.85;
      for (var d = 0; d < 5; d++)
        R(wx(tipX + swing * 0.2 + d * 0.7), wy(tipY + 0.8 + (d % 2) * 0.4), 2, 1, "#d8c898");
      ctx.globalAlpha = 1;
    }
  }

  function drawSmallCooler(cx, cy, state, opt) {
    var on = state === "on";
    var w = 11, h = 9;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    wr(x0 + 0.6, y0 + 0.6, w, h, "rgba(0,0,0,0.28)");
    wr(x0, y0, w, h, "#1c3a5a");
    wr(x0 + 0.6, y0 + 0.6, w - 1.2, h - 1.2, "#3a6a9a");
    wr(x0 + 0.6, y0 + 0.6, w - 1.2, 0.8, "#8ab8e0");
    wr(x0 + 0.6, y0 + h - 1.4, w - 1.2, 0.8, "#1a2c44");
    wr(x0 + 0.6, y0, 0.8, h, "#8ab8e0");
    wr(x0 + w - 1.4, y0, 0.8, h, "#1a2c44");
    /* lid seam, hinges, latch */
    wr(x0 + 0.7, y0 + h * 0.62, w - 1.4, 0.7, "#24405a");
    wr(x0 + 1.2, y0 + h * 0.62 - 0.5, 1.6, 1.5, "#c0c8c0");
    wr(x0 + w - 2.8, y0 + h * 0.62 - 0.5, 1.6, 1.5, "#c0c8c0");
    wr(x0 + w * 0.3, y0 + h * 0.32, w * 0.4, 1.2, "#e8eef4");
    wr(x0 + w * 0.3, y0 + h * 0.32, w * 0.4, 0.45, "#ffffff");
    /* gasket */
    wr(x0 + 1.2, y0 + 1.2, w - 2.4, 0.5, "#1a2840");
    /* a can on the lid */
    wr(x0 + 1.3, y0 + 1.4, 2.6, 2.8, "#7a3a10");
    wr(x0 + 1.3, y0 + 1.7, 2.6, 2.2, "#e0a040");
    wr(x0 + 1.3, y0 + 1.4, 2.6, 0.5, "#f0e0b0");
    wr(x0 + 1.6, y0 + 2.6, 2.0, 0.5, "#b04020");
    /* hum lamp */
    wr(x0 + w - 3.0, y0 + 1.1, 1.9, 1.9, "#0a1828");
    var col = on ? ["#1a4a3a", "#2a8a60", "#50f0a0", "#2a8a60"][ANIM_F] : "#1a2840";
    disc(wx(x0 + w - 2.05), wy(y0 + 2.05), ws(0.85), ws(0.85), col, "#0a2018");
    if (on && ANIM_F === 2) { ctx.globalAlpha = 0.35; oval(wx(x0 + w - 2.05), wy(y0 + 2.05), ws(1.6), ws(1.6), "#40e090"); ctx.globalAlpha = 1; }
  }

  function drawBasicCot(cx, cy, state, opt) {
    var sleeping = state === "on" || state === "sleeping";
    var w = 28, h = 15;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    /* metal pipe frame, thin khaki mattress, one pillow — starter bed, not the plush 0.3.1 one */
    wr(x0 + 0.8, y0 + 0.8, w, h, "rgba(0,0,0,0.30)");
    wr(x0, y0, w, h, "#3a4038");
    wr(x0, y0, w, 1.0, "#8a9088");
    wr(x0, y0, 1.0, h, "#6a7068");
    wr(x0, y0 + h - 1.0, w, 1.0, "#2a2c28");
    wr(x0 + w - 1.0, y0, 1.0, h, "#2a2c28");
    /* corner posts */
    for (var c = 0; c < 4; c++) {
      var px = c % 2 ? x0 + w - 1.6 : x0 - 0.4, py = c < 2 ? y0 - 0.4 : y0 + h - 1.6;
      wr(px, py, 2.0, 2.0, "#3a4038"); wr(px + 0.3, py + 0.3, 1.4, 1.4, "#c0c8c0");
    }
    /* thin mattress */
    wr(x0 + 1.2, y0 + 1.2, w - 2.4, h - 2.4, "#6a5a38");
    wr(x0 + 1.2, y0 + 1.2, w - 2.4, 0.7, "#9a8a60");
    wr(x0 + 1.6, y0 + 1.8, w - 3.2, h - 3.4, "#c8b888");
    wr(x0 + 1.6, y0 + 1.8, w - 3.2, 0.6, "#e8d8a8");
    /* west pillow */
    blob(wx(x0 + 2.0), wy(y0 + 2.6), ws(6.2), ws(h - 5.2), ws(1.6), "#e8e0cc", "#8a8070");
    wr(x0 + 2.6, y0 + 3.0, 4.8, 0.5, "#fffaf0");
    if (sleeping) {
      /* Papa's head on the pillow; thin olive blanket covers the body */
      var bw = w * 0.62, bx = x0 + w - bw - 1.2;
      var rise = [0, 0.35, 0.85, 0.30][ANIM_F];
      blob(wx(bx), wy(y0 + 2.0 - rise * 0.15), ws(bw), ws(h - 4.0 + rise * 0.5), ws(1.4), "#5a6340", "#2a3018");
      wr(bx, y0 + 2.0, 1.4, h - 4.0, "#c8d0a8");
      wr(bx + 1.6, y0 + 2.0, bw - 2.2, 0.7, "#7a8460");
      drawPapa("sleep", x0 + 6.6, cy + 0.15, 1, { hr: 3.6 });
    }
  }

  /* ======================== DECORATIONS ======================== */

  function drawRadio(cx, cy, state, opt) {
    var on = state === "on" || state === "tuning";
    var tuning = state === "tuning";
    var w = 8, h = 6.2;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    if (tuning) drawPapa("stand", cx - 7.5, cy + 1, 1, { hr: 5.6, shW: 12, shH: 5.2 });
    wr(x0 + 0.5, y0 + 0.5, w, h, "rgba(0,0,0,0.28)");
    wr(x0, y0, w, h, "#2a2c30");
    wr(x0 + 0.5, y0 + 0.5, w - 1, h - 1, "#4a5058");
    wr(x0 + 0.5, y0 + 0.5, w - 1, 0.7, "#8a9098");
    wr(x0, y0, 0.6, h, "#6a7078");
    wr(x0 + w - 0.6, y0, 0.6, h, "#1a1c20");
    /* speaker grill */
    wr(x0 + 0.9, y0 + 1.5, 3.2, 3.2, "#1a1c20");
    for (var gy = 0; gy < 4; gy++) for (var gx = 0; gx < 4; gx++)
      wr(x0 + 1.15 + gx * 0.7, y0 + 1.75 + gy * 0.7, 0.45, 0.45, on && ((gx + gy + ANIM_F) % 3 === 0) ? "#c8b890" : "#3a3c40");
    /* amber dial + a knob */
    disc(wx(x0 + 5.8), wy(y0 + 2.3), ws(1.15), ws(1.15), on ? "#e0a040" : "#3a2a10", OUT);
    if (on) oval(wx(x0 + 5.8) - 0.4, wy(y0 + 2.3) - 0.4, ws(0.45), ws(0.45), "#ffe8a0");
    wr(x0 + 5.1, y0 + 3.9, 1.5, 1.5, "#2a2c28");
    wr(x0 + 5.3, y0 + 4.1, 1.1, 1.1, "#8a9088");
    /* antenna */
    wr(x0 + w - 1.0, y0 - 3.0, 0.55, 3.2, "#c0c8c0");
    wr(x0 + w - 1.15, y0 - 3.3, 0.85, 0.7, "#8a9088");
    if (on) {
      /* music notes, 4-frame float */
      var notes = [
        [1.6, -2.2], [3.4, -3.4], [5.2, -2.6]
      ];
      ctx.fillStyle = "#f0e8c0";
      for (var n = 0; n < notes.length; n++) {
        var ny = notes[n][1] - ANIM_F * 0.45 - (n % 2) * 0.3;
        var nx = notes[n][0] + Math.sin((ANIM_F + n) * 0.8) * 0.35;
        wr(x0 + nx, y0 + ny, 0.7, 0.7, "#f0e8c0");
        wr(x0 + nx + 0.7, y0 + ny - 1.1, 0.35, 1.5, "#f0e8c0");
      }
    }
  }

  function drawPlant(cx, cy, state, opt) {
    var healthy = state === "on" || state === "watering";
    var watering = state === "watering";
    /* terracotta pot */
    softShadow(wx(cx), wy(cy + 3.4), ws(4.2), ws(2.0));
    disc(wx(cx), wy(cy + 2.6), ws(3.4), ws(2.2), "#6a3a22", OUT);
    oval(wx(cx), wy(cy + 2.6), ws(2.6), ws(1.6), "#4a2414");
    wr(cx - 3.6, cy + 0.6, 7.2, 1.4, "#8a5a32");
    wr(cx - 3.6, cy + 0.6, 7.2, 0.45, "#c48a58");
    wr(cx - 3.4, cy + 0.85, 6.8, 0.4, "#3a200c");
    /* leaves — droopy brown when off, perky green + sway when on */
    var sway = healthy ? [-0.3, 0.4, 0.9, 0.2][ANIM_F] : 0;
    var leafC = healthy ? "#3a7a38" : "#6a5a30";
    var leafH = healthy ? "#6ab050" : "#8a7a48";
    var leafD = healthy ? "#2a5020" : "#4a3a18";
    function leaf(dx, dy, rw, rh, a) {
      ctx.save();
      ctx.translate(wx(cx + dx + sway * 0.15), wy(cy + dy));
      ctx.rotate(a);
      disc(0, 0, ws(rw), ws(rh), leafC, leafD);
      oval(-ws(rw) * 0.15, -ws(rh) * 0.2, ws(rw) * 0.55, ws(rh) * 0.45, leafH);
      ctx.restore();
    }
    if (healthy) {
      leaf(-1.6, -1.6, 2.2, 1.3, -0.7 + sway * 0.08);
      leaf(1.8, -1.4, 2.0, 1.2, 0.6 + sway * 0.08);
      leaf(0.1, -2.8, 2.4, 1.4, 0.05 + sway * 0.06);
      leaf(-0.2, -0.6, 1.6, 1.0, -0.2);
      leaf(1.0, -0.3, 1.4, 0.9, 0.5);
    } else {
      leaf(-1.8, 0.0, 2.0, 0.9, 0.8);
      leaf(1.6, 0.1, 1.8, 0.85, -0.85);
      leaf(0.2, -0.8, 1.6, 0.8, 0.15);
    }
    if (watering) {
      drawPapa("stand", cx + 7.5, cy + 1.5, 3, { hr: 5.6, shW: 12, shH: 5.2 });
      /* watering can + droplets */
      wr(cx + 3.4, cy - 0.6, 3.2, 2.0, "#3a6a8a");
      wr(cx + 3.4, cy - 0.6, 3.2, 0.5, "#8ab8e0");
      wr(cx + 2.0, cy - 0.2, 1.6, 0.7, "#3a6a8a");
      wr(cx + 1.2, cy - 0.1, 1.2, 0.5, "#c0c8c0");
      for (var d = 0; d < 3; d++) wr(cx + 1.0 - d * 0.3, cy + 0.6 + d * 0.8 + ANIM_F * 0.25, 0.5, 0.8, "#8ab8e0");
    }
  }

  function drawRug(cx, cy, state, opt) {
    var laid = state === "on" || state === "standing";
    var standing = state === "standing";
    var w = 24, h = 16;
    var x0 = cx - w / 2, y0 = cy - h / 2;
    if (!laid) {
      /* rolled up against a wall */
      wr(cx - 8.5 + 0.5, cy - 2.2 + 0.5, 17, 4.4, "rgba(0,0,0,0.28)");
      blob(wx(cx - 8.5), wy(cy - 2.2), ws(17), ws(4.4), ws(1.8), "#8a3a30", "#3a1810");
      wr(cx - 8.2, cy - 2.0, 16.4, 0.7, "#c06050");
      wr(cx - 7.6, cy - 0.4, 15.2, 0.5, "#5a2018");
      /* end rings of the roll */
      disc(wx(cx - 8.5), wy(cy), ws(1.5), ws(2.2), "#6a2820", OUT);
      oval(wx(cx - 8.5), wy(cy), ws(0.8), ws(1.3), "#3a1410");
      disc(wx(cx + 8.5), wy(cy), ws(1.5), ws(2.2), "#6a2820", OUT);
      return;
    }
    /* laid oval rug, rust field, dark border, simple diamond */
    softShadow(wx(cx), wy(cy + 1), ws(w * 0.48), ws(h * 0.42));
    disc(wx(cx), wy(cy), ws(w / 2), ws(h / 2), "#4a2018", OUT);
    oval(wx(cx), wy(cy), ws(w / 2 - 0.9), ws(h / 2 - 0.9), "#8a3a30");
    oval(wx(cx), wy(cy), ws(w / 2 - 1.6), ws(h / 2 - 1.5), "#a05040");
    /* inner border */
    ctx.strokeStyle = "#c08060"; ctx.lineWidth = Math.max(1, ws(0.45));
    ctx.beginPath(); ctx.ellipse(wx(cx), wy(cy), ws(w / 2 - 2.4), ws(h / 2 - 2.2), 0, 0, 6.28); ctx.stroke();
    /* diamond */
    var dx = wx(cx), dy = wy(cy), rw = ws(3.2), rh = ws(2.2);
    ctx.fillStyle = "#5a2018";
    ctx.beginPath(); ctx.moveTo(dx, dy - rh); ctx.lineTo(dx + rw, dy); ctx.lineTo(dx, dy + rh); ctx.lineTo(dx - rw, dy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#c07050";
    ctx.beginPath(); ctx.moveTo(dx, dy - rh + 1.2); ctx.lineTo(dx + rw - 1.4, dy); ctx.lineTo(dx, dy + rh - 1.2); ctx.lineTo(dx - rw + 1.4, dy); ctx.closePath(); ctx.fill();
    if (standing) drawPapa("stand", cx, cy, 0);
  }

  function drawTvArmchair(cx, cy, state, opt) {
    var on = state === "on" || state === "watching";
    var watching = state === "watching";
    /* layout: armchair west, TV east, a clear sitting gap between them. Center is mid-set. */
    var chairX = cx - 8.2, chairY = cy + 0.4;
    var tvX = cx + 12.2, tvY = cy - 0.2;
    /* rug-less; chair first (under Papa) */
    /* armchair — rust wingback, U from above */
    softShadow(wx(chairX), wy(chairY + 1.5), ws(8), ws(6));
    var cw = 13, ch = 14, c0x = chairX - cw / 2, c0y = chairY - ch / 2;
    wr(c0x + 0.5, c0y + 0.5, cw, ch, "rgba(0,0,0,0.28)");
    /* back (east, toward TV? wait: chair faces east toward the TV, so the back is west) */
    wr(c0x, c0y, 3.2, ch, "#3a1810");
    wr(c0x + 0.4, c0y + 0.4, 2.6, ch - 0.8, "#6a2a22");
    wr(c0x + 0.4, c0y + 0.4, 2.6, 0.7, "#8a4a3a");
    /* seat cushion */
    blob(wx(c0x + 2.8), wy(c0y + 3.2), ws(7.6), ws(7.6), ws(1.6), "#8a3a30", "#3a1810");
    wr(c0x + 3.4, c0y + 3.6, 6.4, 0.7, "#c06050");
    wr(c0x + 3.8, c0y + 6.4, 5.6, 0.4, "#6a2820");
    /* armrests north/south */
    blob(wx(c0x + 2.6), wy(c0y + 0.3), ws(8.0), ws(2.8), ws(1.1), "#6a2a22", "#3a1810");
    wr(c0x + 3.0, c0y + 0.5, 7.0, 0.5, "#a05040");
    blob(wx(c0x + 2.6), wy(c0y + ch - 3.1), ws(8.0), ws(2.8), ws(1.1), "#6a2a22", "#3a1810");
    wr(c0x + 3.0, c0y + ch - 2.9, 7.0, 0.5, "#8a3a30");
    /* Papa sits IN the cushion (east of the back, between the armrests), facing the TV. */
    if (watching) drawPapa("sit", chairX + 2.6, chairY, 1);
    /* TV cabinet: large inset screen faces the chair (west). Readable from true top-down. */
    var tw = 10, th = 11, t0x = tvX - tw / 2 + 0.4, t0y = tvY - th / 2;
    wr(t0x + 0.5, t0y + 0.5, tw, th, "rgba(0,0,0,0.28)");
    wr(t0x, t0y, tw, th, "#2a241c");
    wr(t0x + 0.5, t0y + 0.5, tw - 1, th - 1, "#4a4030");
    wr(t0x + 0.5, t0y + 0.5, tw - 1, 0.7, "#7a6a50");
    wr(t0x, t0y, 0.6, th, "#6a5a40");
    wr(t0x + tw - 0.6, t0y, 0.6, th, "#1a1814");
    /* bezel + screen — most of the top face */
    wr(t0x + 0.8, t0y + 1.2, tw - 2.6, th - 3.6, "#12141a");
    var screenCol = on ? ["#3050a0", "#40a068", "#c04040", "#d0b040"][ANIM_F] : "#1a1c20";
    wr(t0x + 1.15, t0y + 1.55, tw - 3.3, th - 4.3, screenCol);
    if (on) {
      wr(t0x + 1.4, t0y + 1.9, (tw - 3.3) * 0.55, 1.6, "#e8e8ff");
      wr(t0x + 1.4, t0y + 4.0, 2.2, 1.2, "#fff8c0");
      wr(t0x + tw - 4.6, t0y + 5.2, 1.8, 1.8, "#203060");
      ctx.globalAlpha = 0.28;
      wr(t0x - 3.6, t0y + 1.8, 4.2, th - 4.6, screenCol);
      ctx.globalAlpha = 1;
    }
    /* knobs along the south bezel + stand feet */
    wr(t0x + 2.0, t0y + th - 2.1, 0.9, 0.9, "#2a2c28");
    wr(t0x + 2.15, t0y + th - 1.95, 0.6, 0.6, on ? "#e0a040" : "#6a7068");
    wr(t0x + 3.4, t0y + th - 2.1, 0.9, 0.9, "#2a2c28");
    wr(t0x + 3.55, t0y + th - 1.95, 0.6, 0.6, "#8a9088");
    wr(t0x + 0.8, t0y + th, 1.8, 0.8, "#3a3018");
    wr(t0x + tw - 2.6, t0y + th, 1.8, 0.8, "#3a3018");
  }

  function drawLamp(cx, cy, state, opt) {
    var on = state === "on";
    /* floor lamp, true top-down: round shade, slim stand, base. Concept-sheet cousin. */
    if (on) {
      var lx = wx(cx), ly = wy(cy);
      for (var j = 0; j < 6; j++) {
        ctx.fillStyle = "rgba(255,220,140," + (0.16 - j * 0.022) + ")";
        ctx.beginPath();
        ctx.ellipse(lx, ly, ws(10 + j * 3.2), ws(7.5 + j * 2.4), 0, 0, 6.28);
        ctx.fill();
      }
    }
    /* base */
    disc(wx(cx), wy(cy + 1.4), ws(2.4), ws(1.6), "#3a2a18", OUT);
    oval(wx(cx), wy(cy + 1.4), ws(1.6), ws(1.0), "#5a4030");
    /* stand (a small disc at center — the pole seen from above) */
    disc(wx(cx), wy(cy + 0.4), ws(0.7), ws(0.7), "#4a3a28", OUT);
    oval(wx(cx), wy(cy + 0.4), ws(0.35), ws(0.35), "#8a7a60");
    /* shade */
    disc(wx(cx), wy(cy - 0.6), ws(3.3), ws(2.5), on ? "#d8b050" : "#6a5a38", OUT);
    oval(wx(cx), wy(cy - 0.6), ws(2.6), ws(1.9), on ? "#f0d070" : "#8a7850");
    oval(wx(cx) - ws(0.6), wy(cy - 1.1), ws(1.2), ws(0.8), on ? "#fff3a0" : "#a09068");
    /* shade well / bulb */
    disc(wx(cx), wy(cy - 0.4), ws(1.1), ws(0.8), on ? "#fff8d0" : "#2a2418", "#3a3018");
    if (on) oval(wx(cx), wy(cy - 0.4), ws(0.5), ws(0.35), "#ffffff");
  }

  /* ======================== CATALOG + DISPATCH ======================== */

  var CATALOG = [
    { id: "conveyor",     name: "CONVEYOR",          group: "machine",  w: 11, h: 36, states: ["off", "on"],                     animated: ["on"],                     blurb: "Belt, pile to auto-peeler. 4-frame slat loop." },
    { id: "suction",      name: "AUTO SUCTION",      group: "machine",  w: 16, h: 14, states: ["off", "on"],                     animated: ["on"],                     blurb: "Intake on the conveyor. Swarm suction rings." },
    { id: "autoPeeler",   name: "AUTO-PEELER",       group: "machine",  w: 28, h: 28, states: ["off", "on"],                     animated: ["on"],                     blurb: "X-ray-style box. Blinking lights, peels shoot to the floor." },
    { id: "betterPeeler", name: "BETTER PEELER",     group: "starter",  w: 12, h: 8,  states: ["off", "on"],                     animated: ["on"],                     blurb: "Lv1 Y-peeler. Curl of peel when in use." },
    { id: "carryBag",     name: "SMALL CARRY BAG",   group: "starter",  w: 12, h: 12, states: ["off", "on", "carrying"],         animated: [],                         blurb: "Empty sack, or stuffed with potatoes. Carrying includes Papa." },
    { id: "sink",         name: "SINK",              group: "starter",  w: 16, h: 16, states: ["off", "on", "washing"],          animated: ["on", "washing"],          blurb: "Holds a few potatoes. Faucet and ripples when on." },
    { id: "broomDustpan", name: "BROOM + DUSTPAN",   group: "starter",  w: 16, h: 18, states: ["off", "on", "sweeping"],         animated: ["on", "sweeping"],         blurb: "Stowed pair, or mid-sweep with dust and peels." },
    { id: "smallCooler",  name: "SMALL COOLER",      group: "starter",  w: 12, h: 10, states: ["off", "on"],                     animated: ["on"],                     blurb: "Lv1 cooler. Hum-lamp blinks when on." },
    { id: "basicCot",     name: "BASIC COT",         group: "starter",  w: 28, h: 16, states: ["off", "on"],                     animated: ["on"],                     blurb: "Metal-frame cot. On = Papa asleep, blanket breathes." },
    { id: "radio",        name: "RADIO",             group: "decor",    w: 10, h: 12, states: ["off", "on", "tuning"],           animated: ["on", "tuning"],           blurb: "Amber dial, grill pulse, floating notes. Tuning includes Papa." },
    { id: "plant",        name: "PLANT",             group: "decor",    w: 12, h: 14, states: ["off", "on", "watering"],         animated: ["on", "watering"],         blurb: "Dry and droopy, or healthy with a 4-frame sway." },
    { id: "rug",          name: "RUG",               group: "decor",    w: 24, h: 16, states: ["off", "on", "standing"],         animated: [],                         blurb: "Rolled up (off) or laid out (on). Standing includes Papa." },
    { id: "tvArmchair",   name: "TV + ARMCHAIR",     group: "decor",    w: 36, h: 16, states: ["off", "on", "watching"],         animated: ["on", "watching"],         blurb: "Dark set and empty chair, or a playing TV. Watching seats Papa." },
    { id: "lamp",         name: "LAMP",              group: "decor",    w: 16, h: 16, states: ["off", "on"],                     animated: [],                         blurb: "Floor lamp. On = warm shade and a light pool." }
  ];
  var BY_ID = {};
  for (var i = 0; i < CATALOG.length; i++) BY_ID[CATALOG[i].id] = CATALOG[i];

  var DRAWS = {
    conveyor: drawConveyor,
    suction: drawSuction,
    autoPeeler: drawAutoPeeler,
    betterPeeler: drawBetterPeeler,
    carryBag: drawCarryBag,
    sink: drawSink,
    broomDustpan: drawBroomDustpan,
    smallCooler: drawSmallCooler,
    basicCot: drawBasicCot,
    radio: drawRadio,
    plant: drawPlant,
    rug: drawRug,
    tvArmchair: drawTvArmchair,
    lamp: drawLamp
  };

  function draw(id, state, x, y, opt) {
    opt = opt || {};
    var prevF = ANIM_F, prevT = ANIM_T;
    if (opt.frame != null) ANIM_F = opt.frame & 3;
    if (opt.t != null) ANIM_T = opt.t;
    var fn = DRAWS[id];
    if (!fn) throw new Error("PPSprites04: unknown sprite " + id);
    fn(x, y, state || "off", opt);
    ANIM_F = prevF; ANIM_T = prevT;
  }

  function sizeOf(id) { var c = BY_ID[id]; return c ? { w: c.w, h: c.h } : null; }
  function statesOf(id) { var c = BY_ID[id]; return c ? c.states.slice() : []; }
  function isAnimated(id, state) {
    var c = BY_ID[id]; if (!c) return false;
    return c.animated.indexOf(state) !== -1;
  }

  var api = {
    version: "0.4.2-sprites",
    OUT: OUT,
    FPS: FPS,
    FRAME_MS: FRAME_MS,
    CATALOG: CATALOG,
    ids: function () { return CATALOG.map(function (c) { return c.id; }); },
    sizeOf: sizeOf,
    statesOf: statesOf,
    isAnimated: isAnimated,
    frameAt: frameAt,
    bind: bind,
    attach: attach,
    setFrame: setFrame,
    draw: draw,
    drawConveyorRun: function (cx, y0, y1, state, opt) {
      opt = opt || {};
      var prevF = ANIM_F, prevT = ANIM_T;
      if (opt.frame != null) ANIM_F = opt.frame & 3;
      if (opt.t != null) ANIM_T = opt.t;
      drawConveyorRun(cx, y0, y1, state, opt);
      ANIM_F = prevF; ANIM_T = prevT;
    },
    drawConveyorRunH: function (cy, x0, x1, state, opt) {
      opt = opt || {};
      var prevF = ANIM_F, prevT = ANIM_T;
      if (opt.frame != null) ANIM_F = opt.frame & 3;
      if (opt.t != null) ANIM_T = opt.t;
      drawConveyorRunH(cy, x0, x1, state, opt);
      ANIM_F = prevF; ANIM_T = prevT;
    },
    peelerPeelWorld: peelerPeelWorld,
    clampRoom: clampRoom,
    DEFAULT_ROOM: DEFAULT_ROOM,
    drawPapa: drawPapa,
    potato: potato,
    peelFlake: peelFlake,
    /* expose primitives so the harness room can share them */
    primitives: function () {
      return { R: R, wr: wr, oval: oval, disc: disc, blob: blob, softShadow: softShadow, wx: wx, wy: wy, ws: ws, bolt: bolt, led: led, OUT: OUT };
    }
  };
  root.PPSprites04 = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
