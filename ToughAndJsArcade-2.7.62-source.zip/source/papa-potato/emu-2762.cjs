// WebView 83 emulator (Android 11, Chrome 83, software rendering), installed 2.7.62 APK (the FINAL one, run ALONE and LAST).
// Papa Potato 0.4.1 (and the v03 / v02 / v01 slots) legacy build: real adb taps/swipes to open it from the menu, set boxes, check scroll-safety,
// play ~2 min real time, buy food, change a box, quit (◀ Arcade, and force-stop the app) and reopen to confirm the save.
const connect = require("/workspace/game/build-latch/fix/cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const ADB = "/workspace/tools/sdk/platform-tools/adb";
const OUT = process.argv[2] || __dirname + "/emu"; fs.mkdirSync(OUT, { recursive: true });
const sh = (c) => execSync(`${ADB} ${c}`).toString();
const shot = (n) => execSync(`${ADB} exec-out screencap -p > ${OUT}/${n}.png`);
const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d === undefined ? "" : d).slice(0, 400)); };
async function startApp(fresh) {
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); let pid = "";
  for (let a = 0; a < 3 && !pid; a++) { // a busy software emulator can time out a cold start ("failed to attach"): retry the launch
    sh("shell am start -n com.toughandj.arcade/.MainActivity"); await sleep(20000);
    try { pid = sh("shell pidof com.toughandj.arcade").trim(); } catch (e) { pid = ""; console.log("note: launch attempt " + (a + 1) + " not up yet, retrying"); }
  } execSync(`${ADB} forward --remove-all`); execSync(`${ADB} forward tcp:9333 localabstract:webview_devtools_remote_${pid}`);
  let c; for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  if (fresh) await c.ev(`(localStorage.removeItem('papaPotato.save.v1'),localStorage.removeItem('papaPotato.save.v2'),localStorage.removeItem('papaPotato.save.v3'),localStorage.removeItem('papaPotato.save.v4'),1)`);
  return c;
}
async function openGame(c, tag, ver) {
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const dpr = await c.ev("devicePixelRatio");
  if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(2000); }
  // bring the card to the middle, then the REAL tap on its PLAY button
  await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');ARCADE.go(i);return 1})()`); await sleep(2500);
  const pb = JSON.parse(await c.ev(`JSON.stringify((()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='papa-potato');const el=document.querySelectorAll('.card')[i];const b=el.querySelector('.play').getBoundingClientRect();return {x:b.left+b.width/2,y:b.top+b.height/2,t:el.innerText.slice(0,40)}})())`));
  shot(`${tag}-menu-card`);
  const n0 = c.ctx.length;
  if (ver) { await c.ev(`(ARCADE.launch(ARCADE.GAMES.findIndex(g=>g.id==='papa-potato'),'${ver}'),1)`); await sleep(1500); } else { sh(`shell input tap ${Math.round(pb.x * dpr)} ${Math.round(pb.y * dpr)}`); await sleep(1500); }
  if (await c.ev("document.getElementById('sheet')&&document.getElementById('sheet').classList.contains('show')")) { /* version sheet: should not appear for one version */ }
  await sleep(8000);
  let cx; for (let i = 0; i < 25 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); }
  if (!cx) throw new Error("no game frame");
  for (let i = 0; i < 20; i++) { try { if (await c.ev("window.__PP_READY===true", cx.id)) break; } catch (e) {} await sleep(1000); }
  const ev = (e) => c.ev(e, cx.id); const J = async (e) => JSON.parse(await ev(`JSON.stringify(${e})`));
  const pt = async (sel, fx = 0.5, fy = 0.5) => { const r = await J(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const b=e.getBoundingClientRect();return {x:b.left+b.width*${fx},y:b.top+b.height*${fy}}})()`); if (!r) throw new Error("not visible " + sel); const o = JSON.parse(await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`)); return { x: Math.round((o.x + r.x) * dpr), y: Math.round((o.y + r.y) * dpr) }; };
  const atap = async (sel, wait = 1200, fx, fy) => { const p = await pt(sel, fx, fy); sh(`shell input tap ${p.x} ${p.y}`); await sleep(wait); return p; };
  return { ev, J, pt, atap, card: pb.t, dpr };
}
const ST = `{t:+PP.sim.s.t.toFixed(1),coins:PP.sim.s.coins,food:PP.sim.s.food,box:PP.sim.s.box,up:PP.sim.s.up,potCap:PP.sim.s.potCap,peeled:PP.sim.s.stats.peeled,peels:PP.sim.s.peels,sweeps:PP.sim.s.stats.sweeps,sucks:PP.sim.s.stats.sucks,pile:PP.sim.s.pile,chute:PP.sim.s.chute,suck:!!PP.sim.s.suck,total:PP.sim.total(),meals:PP.sim.s.stats.meals,bought:PP.sim.s.stats.bought,focus:PP.focus(),ui:[...document.querySelectorAll('.box .val')].map(e=>e.textContent),state:(document.querySelector('.st.on')||{}).textContent,ovl:PP.ovl(),errs:window.__errs}`;
(async () => {
  const APK = "/workspace/game/build-potato041/package-2.7.62/out/ToughAndJsArcade-2.7.62.apk";
  const inst = sh(`install -r ${APK}`).trim();
  const path = sh("shell pm path com.toughandj.arcade").trim().replace(/^package:/, "");
  const devSha = sh(`shell sha256sum ${path}`).trim().split(/\s+/)[0]; const locSha = execSync(`sha256sum ${APK}`).toString().split(" ")[0];
  const ver = (sh("shell dumpsys package com.toughandj.arcade").match(/versionName=([\d.]+)/) || [])[1];
  fs.writeFileSync(`${OUT}/installed-apk.sha256`, `${devSha}  ${path}\n`);
  ok("adb install -r: the installed APK on the device is byte-identical (sha) and is 2.7.62", /Success/.test(inst) && devSha === locSha && ver === "2.7.62", { inst, devSha, ver });
  let c = await startApp(true);
  const shell = JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:(navigator.userAgent.match(/Chrome\\/[\\d.]+/)||[''])[0],dpr:devicePixelRatio,w:innerWidth,h:innerHeight,card:ARCADE.GAMES.findIndex(g=>g.id==='papa-potato'),vers:ARCADE.GAMES.find(g=>g.id==='papa-potato').versions.map(v=>v.id+(v.def?'*':''))})`));
  ok("APK shell on WebView 83 (legacy builds); Papa Potato card has v01, v02, v03 and latest (default)", shell.legacy && /Chrome\/83/.test(shell.ua) && shell.card > 0 && shell.vers.join() === "v01,v02,v03,latest*", shell);
  const keys = () => c.ev("JSON.stringify([!!localStorage.getItem('papaPotato.save.v1'),!!localStorage.getItem('papaPotato.save.v2'),!!localStorage.getItem('papaPotato.save.v3'),!!localStorage.getItem('papaPotato.save.v4')])");
  // ---- v01 slot (frozen 0.1) ----
  { const g1 = await openGame(c, "00a", "v01"); await sleep(12000);
    const v1 = await g1.J(`{ver:PP.version,boxes:document.querySelectorAll('#cmd .box').length,t:+PP.sim.s.t.toFixed(1),errs:window.__errs}`); shot("00b-v01-0.1-running");
    ok("v01 slot: frozen Papa Potato 0.1 opens on WebView 83 (3 boxes, clock runs, 0 errors); wrote only the v1 key", v1.ver === "0.1" && v1.boxes === 3 && v1.t > 5 && v1.errs.length === 0 && (await keys()) === "[true,false,false,false]", v1);
    await c.ev("ARCADE.back(),1"); await sleep(2500); }
  // ---- v02 slot (the real 0.2) ----
  let v2raw = null;
  { const g2 = await openGame(c, "00c", "v02"); await sleep(12000);
    const v = await g2.J(`{ver:PP.version,boxes:document.querySelectorAll('#cmd .box').length,t:+PP.sim.s.t.toFixed(1),errs:window.__errs}`); shot("00d-v02-0.2-running");
    await g2.ev("(PP.sim.s.coins=61,PP.sim.setBox('eat',35),PP.save(),1)"); v2raw = await c.ev("localStorage.getItem('papaPotato.save.v2')");
    ok("v02 slot: the real Papa Potato 0.2 opens on WebView 83 (5 boxes, clock runs, 0 errors); wrote only v1+v2 keys, no v3/v4", v.ver === "0.2" && v.boxes === 5 && v.t > 5 && v.errs.length === 0 && (await keys()) === "[true,true,false,false]", v);
    await c.ev("ARCADE.back(),1"); await sleep(4000); v2raw = await c.ev("localStorage.getItem('papaPotato.save.v2')"); /* read AFTER 0.2 has closed and made its final save */ }
  // ---- v03 slot (frozen 0.3; 0.3 save key v3; 0.4 migrates it to v4) ----
  { const g3 = await openGame(c, "00e", "v03"); await sleep(12000);
    const v = await g3.J(`{ver:PP.version,title:document.title,boxes:document.querySelectorAll('#cmd .box').length,t:+PP.sim.s.t.toFixed(1),errs:window.__errs}`); shot("00f-v03-0.3-running");
    ok("v03 slot: the real Papa Potato 0.3 opens on WebView 83 (8 boxes, clock runs, 0 errors)", v.ver === "0.3" && v.title === "Papa Potato 0.3" && v.boxes === 8 && v.t > 5 && v.errs.length === 0, v);
    await c.ev("ARCADE.back(),1"); await sleep(2500);
    await c.ev("localStorage.removeItem('papaPotato.save.v3')"); /* v03 shares the v3 key; drop it so the next PLAY can migrate from the 0.2 save */ }
  let g = await openGame(c, "01");
  { const m = await g.J(`{migrated:PP.migrated,v:PP.sim.s.v,coins:PP.sim.s.coins,eat:PP.sim.s.box.eat,total:PP.sim.total(),pot:PP.sim.s.box.pot,errs:window.__errs}`); shot("01b-migrated-from-0.2");
    const v2after = await c.ev("localStorage.getItem('papaPotato.save.v2')");
    ok("PLAY → 0.4.1 migrates the real 0.2 save on-device (v4 state, coins 61 and EAT 35% kept, potatoes conserved); the 0.2 key is untouched", m.migrated === "0.2" && m.v === 4 && m.coins >= 61 && m.eat === 35 && m.total > 0 && v2after === v2raw && m.errs.length === 0, { m, v2same: v2after === v2raw });
    await g.ev("(PP.reset(777),1)"); await sleep(1500); }
  const env = await g.J(`{ready:window.__PP_READY===true,prelude:/TJ legacy prelude/.test(document.documentElement.innerHTML),ver:PP.version,brand:document.querySelector('#hud .brand b').innerText.replace(/\\s+/g,' '),title:document.title,vw:innerWidth,vh:innerHeight,noScroll:document.documentElement.scrollHeight<=innerHeight+1&&document.documentElement.scrollWidth<=innerWidth+1,fit:(()=>{const l=PP.layout();return l.offX>=-0.01&&l.offY>=-0.01&&l.offX+l.fitW<=l.W+0.01&&l.offY+l.fitH<=l.H+0.01})(),tags:[...document.querySelectorAll('.tag')].map(e=>e.textContent),visTags:[...document.querySelectorAll('.tag')].filter(e=>getComputedStyle(e).display!=='none').length,zoomRail:!!document.getElementById('zoomRail')&&!!document.getElementById('leftRail')&&!!document.getElementById('rightRail'),boxes:document.querySelectorAll('#cmd .box').length,errs:window.__errs}`);
  ok("real tap on PLAY opens Papa Potato 0.4.1 (legacy variant with prelude): whole room in view with no page scroll, name labels hidden, 8 boxes, 0 errors", env.ready && env.prelude && env.ver === "0.4.1" && env.brand === "PAPA POTATO" && env.noScroll && env.fit && env.visTags === 0 && env.boxes === 8 && env.errs.length === 0, env);
  shot("02-papa-potato-0.4.1-start");
  await sleep(9000); shot("02b-after-labels-fade");
  const s0 = await g.J(ST);
  const show = async (id) => { await g.ev(`(()=>{const e=document.querySelector('.box[data-id="${id}"]'),c=document.getElementById('cmd'),r=e.getBoundingClientRect(),q=c.getBoundingClientRect(),b=document.getElementById('bar').getBoundingClientRect();if(r.top<q.top||r.bottom>b.top)c.scrollTop+=r.top-q.top-6;return 1})()`); await sleep(500); };
  // scroll-safety with REAL swipes: vertical swipes across each visible slider must not change anything
  for (const id of ["pace", "eat", "nap"]) { await show(id); const a = await g.pt(`.box[data-id="${id}"] .trk`, 0.5, 0.5); sh(`shell input swipe ${a.x} ${a.y} ${a.x + 8} ${a.y - 150} 300`); await sleep(900); sh(`shell input swipe ${a.x} ${a.y} ${a.x - 8} ${a.y + 150} 300`); await sleep(900); }
  const s1 = await g.J(ST); const gl = await g.J("window.__ppGL.slice(-24)"); fs.writeFileSync(`${OUT}/gesture-log-vertical.json`, JSON.stringify(gl, null, 1));
  ok("6 real vertical swipes over the sliders change no box and unlock none", JSON.stringify(s0.box) === JSON.stringify(s1.box) && s1.focus === null, { before: s0.box, after: s1.box, focus: s1.focus });
  await show("eat"); { const a = await g.pt('.box[data-id="eat"] .trk', 0.9), b = await g.pt('.box[data-id="eat"] .trk', 0.3); sh(`shell input swipe ${a.x} ${a.y} ${b.x} ${b.y} 400`); await sleep(1200); }
  const s2 = await g.J(ST); ok("real horizontal swipe on a LOCKED slider does nothing", s2.box.eat === s0.box.eat, s2.box);
  await g.atap('.box[data-id="eat"] .nm', 1200); const f = await g.J(ST); shot("03-eat-selected");
  { const a = await g.pt('.box[data-id="eat"] .trk', 0.95), b = await g.pt('.box[data-id="eat"] .trk', 0.55); sh(`shell input swipe ${a.x} ${a.y} ${b.x} ${b.y} 500`); await sleep(1500); }
  const s3 = await g.J(ST); ok("real tap unlocks EAT, then a real horizontal swipe sets it (judged at the lift point)", f.focus === "eat" && s3.box.eat >= 20 && s3.box.eat <= 45 && s3.ui[1].replace(/^< /, "") === s3.box.eat + "%", { focus: f.focus, eat: s3.box.eat, ui: s3.ui });
  await show("nap"); for (let i = 0; i < 5; i++) await g.atap('.box[data-id="nap"] .pm[data-d="1"]', 700);
  const s4 = await g.J(ST); ok("5 real taps on NAP + → 25%", s4.box.nap === 25 && s4.ui[2].replace(/^< /, "") === "25%", s4.box); shot("04-boxes-set");
  // lower boxes: real vertical swipe scrolls the panel, bar stays pinned; set PEEL STYLE and KEEP FOOD with real taps
  { const a = await g.pt('.box[data-id="pace"] .trk', 0.5, 0.5); const bx = await g.J(`{...PP.sim.s.box}`); await show("pace"); for (let k = 0; k < 4; k++) { const a2 = a; /* fixed start point inside the panel */ sh(`shell input swipe ${a2.x} ${a2.y} ${a2.x + 5} ${a2.y - 220} 350`); await sleep(1500); const q = await g.J(`{st:document.getElementById('cmd').scrollTop,max:document.getElementById('cmd').scrollHeight-document.getElementById('cmd').clientHeight}`); if (q.st >= q.max - 3) break; }
    const sc = await g.J(`{st:document.getElementById('cmd').scrollTop,box:{...PP.sim.s.box},barTop:document.getElementById('bar').getBoundingClientRect().top,ch:innerHeight,styleVisible:document.querySelector('.box[data-id="autob"]').getBoundingClientRect().bottom<=document.getElementById('bar').getBoundingClientRect().top+6}`); shot("04b-panel-scrolled-bar-pinned");
    ok("a real vertical swipe on a slider scrolls the panel to the lower boxes (KEEP FOOD visible above the pinned SHOP/HELP bar); no value changes", sc.st > 20 && JSON.stringify(sc.box) === JSON.stringify(bx) && sc.barTop < sc.ch && sc.styleVisible, sc);
    await g.atap('.box[data-id="style"] .pm[data-d="1"]', 800); await g.atap('.box[data-id="autob"] .pm[data-d="1"]', 800); await g.atap('.box[data-id="autob"] .pm[data-d="1"]', 800); await g.atap('.box[data-id="autob"] .pm[data-d="1"]', 800);
    const nb = await g.J(ST); ok("real taps: PEEL STYLE + → QUICK, KEEP FOOD AT LEAST + ×3 → 3 (new boxes work on the device)", nb.box.style === 2 && nb.box.autob === 3 && /^QUICK/.test(nb.ui[5]) && /3$/.test(nb.ui[7]), { box: nb.box, ui: nb.ui });
    await g.atap('.box[data-id="style"] .pm[data-d="-1"]', 800); await g.atap('.box[data-id="style"] .pm[data-d="-1"]', 800); await g.atap('.box[data-id="autob"] .pm[data-d="-1"]', 600); await g.atap('.box[data-id="autob"] .pm[data-d="-1"]', 600); await g.atap('.box[data-id="autob"] .pm[data-d="-1"]', 600); await g.atap('.box[data-id="autob"] .pm[data-d="-1"]', 600); }
  // play ~2 min real time
  const timeline = []; const t0 = Date.now();
  while (Date.now() - t0 < 125000) { await sleep(5000); const s = await g.J(ST); timeline.push({ real: Math.round((Date.now() - t0) / 1000), t: s.t, coins: s.coins, food: s.food, state: s.state, peeled: s.peeled, peels: s.peels }); const real = (Date.now() - t0) / 1000; if (Math.abs(real - 30) < 3) shot("05-playing-30s"); if (Math.abs(real - 90) < 3) shot("07-playing-90s"); }
  const fpsNote = await g.ev(`new Promise(r=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n/((performance.now()-t0)/1000)).toFixed(1))}requestAnimationFrame(f)})`);
  const s5 = await g.J(ST); fs.writeFileSync(`${OUT}/timeline.json`, JSON.stringify(timeline, null, 1));
  ok("played ~2 min real time: he peels and ships (coins + peeled go up), peels land on the floor, game clock follows real time", s5.peeled >= 4 && s5.t > 90 && timeline.some((x) => x.coins > 0) && timeline.some((x) => x.peels > 0), { real: timeline[timeline.length - 1].real, t: s5.t, peeled: s5.peeled, coins: s5.coins, peels: s5.peels, emuFps: fpsNote });
  // ---- SHOP with real taps ----
  await g.ev("(PP.sim.s.coins=120,1)"); await sleep(300); await g.atap("#shopBtn", 1500); const sh0 = await g.J(ST); shot("08-shop-open");
  ok("real tap on SHOP opens the shop screen", sh0.ovl === "shop", sh0.ovl);
  { const b0 = await g.J(ST); const a = await g.pt('#ovlBody .go[data-act="buy:food"]', 0.5, 0.5); sh(`shell input swipe ${a.x} ${a.y} ${a.x + 4} ${a.y - 140} 300`); await sleep(1200); const b1 = await g.J(ST); ok("real swipe that STARTS on a BUY button scrolls and never buys", b1.coins >= b0.coins && b1.food === b0.food, { b0: b0.coins, b1: b1.coins }); await g.ev("(document.getElementById('ovlBody').scrollTop=0,1)"); await sleep(500); }
  { const b0 = await g.J(ST); await g.atap('#ovlBody .go[data-act="buy:food"]', 1500); const b1 = await g.J(ST); ok("real tap on FOOD BUY: exactly one purchase (+1 food, coins spent)", b1.bought === b0.bought + 1 && b1.coins < b0.coins && b1.food >= b0.food, { b0: [b0.coins, b0.food], b1: [b1.coins, b1.food] }); }
  { const b0 = await g.J(ST); await g.ev("(document.getElementById('ovlBody').scrollTop=0,1)"); await g.ev(`(()=>{const e=document.querySelector('#ovlBody .go[data-act="buy:up:peeler"]'),bd=document.getElementById('ovlBody'),r=e.getBoundingClientRect(),q=bd.getBoundingClientRect();bd.scrollTop+=r.top-q.top-60;return 1})()`); await sleep(600); await g.atap('#ovlBody .go[data-act="buy:up:peeler"]', 1500); const b1 = await g.J(ST); shot("08b-shop-after-buy"); ok("real tap on SHARP PEELER BUY: level 1, coins spent, persisted", b1.up.peeler === 1 && b1.coins < b0.coins, { up: b1.up, c0: b0.coins, c1: b1.coins }); }
  await g.atap("#ovlClose", 1200); ok("real tap on X closes the shop", (await g.J(ST)).ovl === null, "");
  // ---- BOOKLET with real taps / swipes ----
  await g.atap("#helpBtn", 1500); shot("09-booklet-cover"); const bk0 = await g.J(`{o:PP.ovl(),b:PP.book()}`);
  await g.atap("#pg .go2", 1500); const bk1 = await g.J(`PP.book()`); shot("09b-booklet-page-1");
  { const r = await g.J(`(()=>{const b=document.getElementById('pg').getBoundingClientRect();return {x:b.left,y:b.top,w:b.width,h:b.height}})()`); const o = JSON.parse(await c.ev(`JSON.stringify((()=>{const b=document.getElementById('game').getBoundingClientRect();return {x:b.left,y:b.top}})())`)); const dpr = g.dpr; const X = (v) => Math.round((o.x + v) * dpr), Y = (v) => Math.round((o.y + v) * dpr);
    sh(`shell input swipe ${X(r.x + r.w * 0.85)} ${Y(r.y + r.h * 0.5)} ${X(r.x + r.w * 0.15)} ${Y(r.y + r.h * 0.5 + 6)} 350`); await sleep(1500); var bk2 = await g.J(`PP.book()`); shot("09c-booklet-page-2-after-swipe");
    sh(`shell input swipe ${X(r.x + r.w * 0.15)} ${Y(r.y + r.h * 0.5)} ${X(r.x + r.w * 0.85)} ${Y(r.y + r.h * 0.5 + 6)} 350`); await sleep(1500); var bk3 = await g.J(`PP.book()`);
    sh(`shell input swipe ${X(r.x + r.w * 0.5)} ${Y(r.y + r.h * 0.85)} ${X(r.x + r.w * 0.52)} ${Y(r.y + r.h * 0.2)} 350`); await sleep(1200); var bk4 = await g.J(`PP.book()`); }
  await g.atap('#bkNav button[data-act="book:next"]', 1200); await g.atap('#bkNav button[data-act="book:next"]', 1200); const bk5 = await g.J(`PP.book()`); shot("09d-booklet-page-3-next-taps");
  ok("real taps/swipes on the HELP booklet: opens on its cover, OPEN THE BOOK → p.1, a left swipe flips to p.2, a right swipe back to p.1, a vertical drag does not flip, NEXT×2 → p.3", bk0.o === "help" && bk0.b.page === 0 && bk1.page === 1 && bk2.page === 2 && bk3.page === 1 && bk4.page === 1 && bk5.page === 3, { bk0: bk0.b, bk1, bk2, bk3, bk4, bk5 });
  await g.atap("#ovlClose", 1200);
  // ---- 800 potatoes via the shop's upgrade of the cap (sim-side purchase), then real slider drag to the top ----
  await g.ev("(PP.sim.s.potCap=17,1)"); await sleep(500); await show("pot"); await g.atap('.box[data-id="pot"] .nm', 1000); { const p1 = await g.pt('.box[data-id="pot"] .trk', 0.9), p2 = await g.pt('.box[data-id="pot"] .trk', -0.05); sh(`shell input swipe ${p1.x} ${p1.y} ${p2.x} ${p2.y} 600`); await sleep(2500); }
  const p4 = await g.J(`{pot:PP.sim.s.box.pot,lab:document.querySelector('.box[data-id="pot"] .val').textContent,total:PP.sim.total(),errs:window.__errs}`); shot("10-potatoes-max-slider");
  ok("real swipe slides POTATOES to the 800 end; total = 800; 0 JS errors", p4.lab === "800" && p4.total === 800 && p4.errs.length === 0, p4);
  const h0 = await g.J(`performance.memory?performance.memory.usedJSHeapSize:0`); await sleep(25000);
  const fps800 = await g.ev(`new Promise(r=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(+(n/((performance.now()-t0)/1000)).toFixed(1))}requestAnimationFrame(f)})`);
  const h1 = await g.J(`{heap:performance.memory?performance.memory.usedJSHeapSize:0,errs:window.__errs,st:PP.stats(),t:PP.sim.s.t}`); shot("10b-800-potatoes-playing");
  ok("800 potatoes on WebView 83 (software emulator): ran 25 s, 0 errors, JS heap not growing (>2x)", h1.errs.length === 0 && (h0 === 0 || h1.heap < h0 * 2 + 4e6), { h0, h1: h1.heap, emuFps: fps800, st: h1.st });
  for (let i = 0; i < 12; i++) await g.atap('.box[data-id="pot"] .pm[data-d="-1"]', 350);
  // ---- return chute spill + shipping suction on the device ----
  await g.ev(`((()=>{const s=PP.sim.s,d=Math.min(6-s.chute,s.pile);s.pile-=d;s.chute+=d})(),PP.sim.startSuck(),1)`); await sleep(1200); shot("11-ship-suction-mid-effect"); await sleep(1500); shot("11b-return-chute-spilling"); await sleep(700); shot("11c-return-chute-spilling-2"); await sleep(5000);
  const su2 = await g.J(`{suck:PP.sim.s.suck,total:PP.sim.total(),pot:PP.Sim.POTS[PP.sim.s.box.pot],errs:window.__errs}`);
  ok("shipping suction + return-chute spill on WebView 83: runs, completes, potatoes return (total conserved), 0 errors", !su2.suck && su2.total === su2.pot && su2.errs.length === 0, su2);
  const saved = await g.J(ST); ok("0 JS errors in Papa Potato during play on WebView 83", saved.errs.length === 0, saved.errs);
  // quit #1: Back key twice
  sh("shell input keyevent 4 4"); await sleep(3000); const inMenu = await c.ev("!ARCADE.inGame&&document.querySelectorAll('#game iframe').length===0"); shot("12-back-in-menu");
  ok("real Back key twice leaves Papa Potato cleanly (frame removed, menu back)", inMenu, inMenu);
  g = await openGame(c, "13"); const r1 = await g.J(ST); shot("13-reopened");
  ok("reopened from the menu: save restored (boxes, upgrade levels, potato limit, coins, clock not reset)", JSON.stringify(r1.box) === JSON.stringify(saved.box) && JSON.stringify(r1.up) === JSON.stringify(saved.up) && r1.potCap === saved.potCap && r1.coins >= saved.coins && r1.t >= saved.t, { before: { box: saved.box, up: saved.up, potCap: saved.potCap, coins: saved.coins, t: saved.t }, after: { box: r1.box, up: r1.up, potCap: r1.potCap, coins: r1.coins, t: r1.t } });
  await sleep(5000); const k0 = await g.J(ST); c.close();
  c = await startApp(false); g = await openGame(c, "14"); const r2 = await g.J(ST); shot("15-after-force-stop");
  ok("force-stop the app → relaunch → Papa Potato: save restored (boxes, upgrades), clock not reset", JSON.stringify(r2.box) === JSON.stringify(k0.box) && JSON.stringify(r2.up) === JSON.stringify(k0.up) && r2.t >= k0.t - 5 && r2.t > 60, { before: { t: k0.t, box: k0.box, up: k0.up }, after: { t: r2.t, box: r2.box, up: r2.up } });
  ok("0 JS errors after relaunch", r2.errs.length === 0, r2.errs);
  { await g.ev(`((()=>{const s=PP.sim.s,d=Math.min(6-s.chute,s.pile);s.pile-=d;s.chute+=d})(),PP.sim.startSuck(),PP.save(),1)`); const pre = await g.J(`{suck:PP.sim.s.suck,total:PP.sim.total(),pot:PP.sim.s.box.pot}`); sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); c.close();
    c = await startApp(false); g = await openGame(c, "16"); const post = await g.J(`{suck:PP.sim.s.suck,t:PP.sim.s.t,total:PP.sim.total(),pot:PP.Sim.POTS[PP.sim.s.box.pot],errs:window.__errs}`); shot("16-after-kill-mid-suction"); await sleep(7000);
    const post2 = await g.J(`{suck:PP.sim.s.suck,total:PP.sim.total(),errs:window.__errs}`);
    ok("force-kill mid-suction → relaunch: state valid, potato total conserved, suction continues/finishes, 0 errors", pre.suck && post.total === post.pot && post.errs.length === 0 && post2.total === post.total && post2.errs.length === 0, { pre, post, post2 }); }
  await c.ev("ARCADE.back(),1");
  fs.writeFileSync(`${OUT}/emu-2762.json`, JSON.stringify({ shell, R, timeline }, null, 1));
  console.log(`emu-2762: ${R.filter((r) => r.pass).length}/${R.length} pass`); c.close(); process.exit(R.every((r) => r.pass) ? 0 : 1);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); fs.writeFileSync(`${OUT}/emu-2762.json`, JSON.stringify({ R, err: e.message }, null, 1)); process.exit(1); });
