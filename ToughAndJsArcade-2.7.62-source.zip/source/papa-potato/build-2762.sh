#!/bin/bash
# Full 2.7.62 build: game html -> arcade bundle (on top of the published 2.7.61 bundle) -> signed APK -> extract for tests.
set -euo pipefail
export PATH=/workspace/tools/jdk/bin:$PATH
B=/workspace/game/build-potato041
B31=/workspace/game/build-potato31
B2=/workspace/game/build-potato2
P=$B/package-2.7.62
bash $B/build.sh
node $B/assemble-2762.mjs $B/out/index.html | tee $B/out/assemble.log
cp $B/out/index.html $P/tough-and-js-arcade.html
rm -f $P/out/ToughAndJsArcade-2.7.62.apk $P/out/ToughAndJsArcade-2.7.62.apk.idsig
(cd $P && ./build-apk.sh) > $B/out/build-apk.log 2>&1
rm -rf /tmp/a62 && mkdir /tmp/a62 && (cd /tmp/a62 && unzip -q $P/out/ToughAndJsArcade-2.7.62.apk assets/index.html)
cp /tmp/a62/assets/index.html $B/test/index-from-apk.html
node $B/extract-slots-2762.cjs $B/test/index-from-apk.html \
  $B/test/papa-potato-from-apk.html \
  $B/test/papa-potato-v03-from-apk.html \
  $B/test/papa-potato-v02-from-apk.html \
  $B/test/papa-potato-v01-from-apk.html
cmp $B/test/papa-potato-from-apk.html $B/out/papa-potato-0.4.1.html
cmp $B/test/papa-potato-v03-from-apk.html $B31/out/papa-potato-0.3-frozen.html
cmp $B/test/papa-potato-v02-from-apk.html $B2/out/papa-potato-0.2.html
cmp $B/test/papa-potato-v01-from-apk.html $B2/out/papa-potato-0.1-frozen.html
cmp $B/test/index-from-apk.html $B/out/index.html
mkdir -p $B/evidence
sha256sum $P/out/ToughAndJsArcade-2.7.62.apk $B/test/index-from-apk.html $B/test/papa-potato-from-apk.html $B/test/papa-potato-v03-from-apk.html $B/test/papa-potato-v02-from-apk.html $B/test/papa-potato-v01-from-apk.html | tee $B/evidence/tested-artifacts.sha256
