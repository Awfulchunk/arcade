#!/bin/bash
# Tough & J's Arcade 2.7.62 (code 100): 2.7.61 + Papa Potato 0.4.1 (latest); 0.3/0.2/0.1 stay in v03/v02/v01. Every other cartridge byte-identical. No Gradle; plain SDK tools.
# Usage: ./build-apk.sh            (version comes from app/AndroidManifest.xml)
# Output: ./out/ToughAndJsArcade-<ver>.apk  (never overwrites an existing release file)
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
export ANDROID_HOME=${ANDROID_HOME:-/workspace/tools/sdk}
export JAVA_HOME=${JAVA_HOME:-/workspace/tools/jdk}
export PATH=$JAVA_HOME/bin:$PATH
BT=$ANDROID_HOME/build-tools/34.0.0
D8=$ANDROID_HOME/build-tools/36.0.0/d8   # d8 from 34.0.0 crashes on JDK 21 inner classes
JAR=$ANDROID_HOME/platforms/android-34/android.jar
SRC_HTML=$PWD/tough-and-js-arcade.html
MAN=app/AndroidManifest.xml
# runtime libraries that go into the dex (rhino-engine/javax.script is NOT included: not on Android, not used)
LIBS="libs/NewPipeExtractor-v0.27.1.jar libs/nanojson.jar libs/jsoup-1.24.1.jar libs/protobuf-javalite-4.36.2.jar libs/rhino-1.8.1.jar libs/jump3r-1.0.5.jar"
CPONLY="libs/jsr305-3.0.2.jar"
VC=$(grep -oP 'android:versionCode="\K[0-9]+' $MAN); VN=$(grep -oP 'android:versionName="\K[^"]+' $MAN)
echo "== Building Tough & J's Arcade $VN (code $VC)"
cp "$SRC_HTML" app/assets/index.html
B=build; rm -rf $B; mkdir -p $B/res $B/gen $B/classes $B/dex $B/javares out
"$BT/aapt2" compile --dir app/res -o $B/res/res.zip
"$BT/aapt2" link -o $B/base.apk -I "$JAR" --manifest $MAN -A app/assets \
  --java $B/gen --min-sdk-version 24 --target-sdk-version 34 \
  --version-code "$VC" --version-name "$VN" $B/res/res.zip
CP="$JAR:$(echo $LIBS $CPONLY | tr ' ' ':')"
javac --release 17 -nowarn -encoding UTF-8 -classpath "$CP" -d $B/classes -sourcepath "app/src:$B/gen" \
  $(find app/src $B/gen -name '*.java') -Xlint:-options 2>&1 | grep -v '^Note:' || true
ls $B/classes/com/toughandj/arcade/MainActivity.class $B/classes/com/toughandj/arcade/NeedleBridge.class >/dev/null
(cd $B/classes && jar cf ../classes.jar .)
# Core library desugaring (same as NewPipe's app): Java 11-17 APIs the extractor uses (Stream.toList, URLDecoder(Charset), ...)
# are rewritten to a bundled copy so they work on Android 8-12 too.
DSJ=libs/desugar_nio_2.1.5.json
"$D8" --release --min-api 24 --lib "$JAR" --classpath $CPONLY --desugared-lib $DSJ \
  --desugared-lib-pg-conf-output $B/desugar-keep.pro --output $B/dex $B/classes.jar $LIBS 2>&1 | grep -v -E '^Warning: (Missing class|Type `)' | head -20 || true
ls $B/dex/classes.dex >/dev/null
mkdir -p $B/l8
java -cp "$ANDROID_HOME/build-tools/36.0.0/lib/d8.jar" com.android.tools.r8.L8 --release --min-api 24 --desugared-lib $DSJ \
  --lib "$JAR" --pg-conf $B/desugar-keep.pro --output $B/l8 libs/desugar_jdk_libs_nio-2.1.5.jar libs/desugar_jdk_libs_configuration_nio-2.1.5.jar 2>&1 | head -20 || true
n=$(ls $B/dex/classes*.dex | wc -l); cp $B/l8/classes.dex $B/dex/classes$((n+1)).dex
# Java resources the libraries read with getResourceAsStream (Rhino error messages)
(cd $B/javares && unzip -q -o ../../libs/rhino-1.8.1.jar 'org/mozilla/javascript/resources/*')
cp $B/base.apk $B/unsigned.apk
python3 - "$B" <<'PY'
import zipfile,sys,os,glob
B=sys.argv[1]; z=zipfile.ZipFile(B+'/unsigned.apk','a',zipfile.ZIP_DEFLATED)
for d in sorted(glob.glob(B+'/dex/classes*.dex')): z.write(d,os.path.basename(d))
for root,_,files in os.walk(B+'/javares'):
    for f in files:
        p=os.path.join(root,f); z.write(p,os.path.relpath(p,B+'/javares'))
z.close()
PY
"$BT/zipalign" -f -p 4 $B/unsigned.apk $B/aligned.apk
PW=$(grep '^storepass:' keys/KEYSTORE-INFO.txt | awk '{print $2}')
OUT=out/ToughAndJsArcade-$VN.apk
[ -e "$OUT" ] && { echo "refusing to overwrite $OUT"; exit 1; }
"$BT/apksigner" sign --ks keys/tj-release.jks --ks-key-alias tjarcade --ks-pass "pass:$PW" --key-pass "pass:$PW" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true --min-sdk-version 24 \
  --out "$OUT" $B/aligned.apk
"$BT/apksigner" verify --min-sdk-version 24 "$OUT" && echo "== signature OK"
ls -la "$OUT"
