// match-length / balance sampler: node balance.cjs [file]
const {launch,FILE}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:1});await pg.goto(process.argv[2]?'file://'+require('path').resolve(process.argv[2]):FILE);await new Promise(r=>setTimeout(r,500));
 const rows=await pg.evaluate(()=>{const out=[];for(let sd=1;sd<=8;sd++){__tt.setSeed(sd);__pw.aiPlan(0);__pw.startBattle();const t0=performance.now();let pk=[0,0],hist=[];
   while(!__pw.S.over&&__pw.S.tick<(+(window.__lim||36000))){__pw.tick();const a=__pw.S.sides;pk[0]=Math.max(pk[0],a[0].active);pk[1]=Math.max(pk[1],a[1].active);if(__pw.S.tick%600===0)hist.push([a[0].circle.hp,a[1].circle.hp]);}
   const S=__pw.S,a=S.sides;out.push({seed:sd,sec:+(S.tick/60).toFixed(1),win:S.winner,hp:[a[0].circle.hp,a[1].circle.hp],walls:[a[0].stats.wallsBroken,a[1].stats.wallsBroken],wd:[a[0].stats.wallDmg,a[1].stats.wallDmg],cd:[a[0].stats.circleDmg,a[1].stats.circleDmg],kills:[a[0].stats.kills,a[1].stats.kills],pk,ms:Math.round(performance.now()-t0),hist:hist.slice(0,6).map(h=>h.join('/')).join(' ')});}return out;});
 for(const r of rows)console.log(JSON.stringify(r));await b.close();})();
