const {launch,open}=require('./lib.cjs');const {duelPair}=require('./duel0412.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
 const grid=JSON.parse(process.argv[2]);const T=+(process.argv[3]||3600);
 for(const [cK,hK,dK,dg,hHi,dHi] of grid){const SZ_HP=[],SZ_DMG=[],SZ_DG=[],SZ_CNT=[],SZ_MASS=[];for(let s=1;s<=10;s++){SZ_HP.push(+(2*(1+(s>5?hHi:hK)*(s-5)/5)).toFixed(3));SZ_DMG.push(+(1*(1+(s>5?dHi:dK)*(s-5)/5)).toFixed(3));SZ_DG.push(s<5?+(dg*(5-s)/4).toFixed(3):0);const c=s<5?1+cK*(5-s)/4:1-cK*(s-5)/5;SZ_CNT.push(+c.toFixed(3));SZ_MASS.push(+(1/c).toFixed(3));}
  const tune={SZ_HP,SZ_DMG,SZ_DG,SZ_CNT,SZ_MASS};let worstF=0,worstK=0;const rs=[];
  for(const [a,c] of [[1,10],[1,5],[5,10],[3,8]]){const r=await duelPair(pg,a,c,700,6,T,JSON.parse(process.env.SEEDS||"[5,9]"),tune);rs.push([a,c,r.killShareA,r.frontA,r.hpLeft]);worstF=Math.max(worstF,Math.abs(r.frontA-250));worstK=Math.max(worstK,Math.abs(r.killShareA-50));}
  console.log('CFG',JSON.stringify({cK,hK,dK,dg,hHi,dHi,worstF:+worstF.toFixed(1),worstK:+worstK.toFixed(1),rs}),'TUNE',JSON.stringify(tune));}
 await b.close();})();
