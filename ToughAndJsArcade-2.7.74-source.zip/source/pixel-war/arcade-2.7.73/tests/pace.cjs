// pace sweep: AI-vs-AI headless matches at pace 1/5/10 -> how long and who wins. node pace.cjs
const {launch,FILE}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:1});await pg.goto(FILE);await new Promise(r=>setTimeout(r,500));
 for(const sp of [1,5,10]){const rows=await pg.evaluate(sp=>{const out=[];for(let sd=1;sd<=6;sd++){__tt.setSeed(sd);const P=__pw;for(const s of P.S.sides)s.set.speed=sp;P.aiPlan(0);P.startBattle();
   while(!P.S.over&&P.S.tick<40000)P.tick();const S=P.S,a=S.sides;out.push([sd,+(S.tick/60).toFixed(0),S.winner,a[0].circle.hp,a[1].circle.hp,a[0].stats.kills+a[1].stats.kills]);}return out;},sp);
  console.log('pace',sp,rows.map(r=>r.join(',')).join(' | '));}
 await b.close();})();
