// Pixel War 0.4.12 own checks (t1199/t1200): old density off, PIXEL SIZE slider (labelled DENSITY), size balance, AI size picks + size habits, save keys v412,
// plus every 0.4.11 check (lanes, shapes, locked rules, guard + width match, learning series, memory delete, smooth motion).
const {launch,open,FILE}=require('./lib.cjs');const {runFight,SPECS}=require('./fairlib.cjs');
const res=[];const ok=(name,pass,info)=>{res.push({name,pass:!!pass,info});console.log((pass?'PASS ':'FAIL ')+name+(info!==undefined?' '+JSON.stringify(info):''));};
(async()=>{const b=await launch();
 // ---------- 1. load, version, lanes UI, shapes UI
 let pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 const ui=await pg.evaluate(()=>{const g=window.__pw;g.startWith({});const vis=id=>{const e=document.getElementById(id);if(!e)return null;let n=e;while(n){if(getComputedStyle(n).display==='none')return false;n=n.parentElement;}return true;};
   g.draw&&g.draw();return {title:document.title,h1:document.querySelector('#menu h1').textContent,laneBtn:vis('tLane'),laneBox:vis('boxLn'),widthSlider:!!document.getElementById('sWd'),wMin:+document.getElementById('sWd').min,wMax:+document.getElementById('sWd').max,
     flowMin:+document.getElementById('sRe').min,flowMax:+document.getElementById('sRe').max,legacy:vis('legacy'),sSD:vis('sSD'),sCo:vis('sCo'),sPu:vis('sPu'),sAt:vis('sAt'),shbtns:vis('shbtns'),
     LS:g.LANE_SHAPES_ON,SO:g.SHAPES_OFF};});
 ok('title/label 0.4.12',ui.title==='PIXEL WAR 0.4.12'&&ui.h1==='PIXEL WAR 0.4.12',ui.title);
 ok('LANE SHAPE button hidden, LANE WIDTH slider 1-10 kept',ui.laneBtn===false&&ui.laneBox===false&&ui.widthSlider&&ui.wMin===1&&ui.wMax===10,ui);
 ok('flow slider 200-1000',ui.flowMin===200&&ui.flowMax===1000);
 ok('shape controls hidden (SHAPE DENS/COMPACT/PULL/FORM AT/shape buttons)',[ui.legacy,ui.sSD,ui.sCo,ui.sPu,ui.sAt,ui.shbtns].every(v=>v===false),ui);
 const lane=await pg.evaluate(()=>{const g=window.__pw;const r={};r.set1=g.setLane(0,0,1);r.set4=g.setLane(0,0,4);r.lane0=g.S.sides[0].paths[0].lane;r.f=[0,1,2,3,4].map(t=>g.laneF(t,0.5));r.ok=[0,1,2,3,4].map(t=>g.laneOk(t));
   // an old save / AI memory that carries a lane shape is forced back to NORMAL
   g.S.sides[1].paths[0].lane=1;r.hwForced=g.laneHalf(g.S.sides[1].set,1,0)===g.laneHalf(g.S.sides[1].set,0,0);
   r.max10=Math.abs(g.laneHW({width:10})-22)<1e-9;return r;});
 ok('lane shapes forced NORMAL (setLane refuses, laneF=1 for all, old lane value ignored)',!lane.set1&&!lane.set4&&lane.lane0===0&&lane.f.every(v=>v===1)&&lane.ok.join()==='true,false,false,false,false'&&lane.hwForced,lane);
 ok('max lane width = circle diameter (width 10 half-width = CR 22)',lane.max10);
 // custom menu rows
 const cus=await pg.evaluate(()=>{const g=window.__pw;g.buildCustom();const t=document.getElementById('clist').textContent;return {shapesGrp:/SHAPES/.test(t)&&/Shape cooldown/.test(t),shapesOn:/Shapes: arrow, wedge/.test(t),laneDef:/Default lane shape/.test(t),tint:/Tint shape pixels/.test(t),ai:/AI learns during match/.test(t)};});
 ok('CUSTOM GAME: shape group, shapes toggle, lane-shape default, shape tint hidden; AI rows kept',!cus.shapesGrp&&!cus.shapesOn&&!cus.laneDef&&!cus.tint&&cus.ai,cus);
 const sh=await pg.evaluate(()=>{const g=window.__pw;g.startWith({shapesOn:1,laneDef:2,aiForms:1});const r={cfgShapes:g.CFG.shapesOn,cfgLane:g.CFG.laneDef,aiForms:g.CFG.aiForms,use:[0,1,2,3,6].map(t=>g.useShape(0,0,t)),okS:[0,1,2,3,6].map(t=>g.shapeOkS(g.S.sides[0],t)),feat:g.feat('shapes'),pathLane:g.S.sides[0].paths[0].lane};return r;});
 ok('shapes cannot come back (startWith shapesOn:1 forced off, useShape false, shapeOkS false)',sh.cfgShapes===0&&sh.cfgLane===0&&sh.aiForms===0&&sh.use.every(v=>v===false)&&sh.okS.every(v=>v===false)&&!sh.feat&&sh.pathLane===0,sh);
 // ---------- 2. a full AI match: no shape/formation pixel (state 4/5) ever, all paths NORMAL, no mid-match walls
 const fr=await runFight(pg,Object.assign({},SPECS[3],{name:'shape-scan'}),2400);
 const scan=await pg.evaluate(()=>{const g=window.__pw;let s4=0;for(let i=0;i<g.POOL*2;i++)if(g.pst[i]===4||g.pst[i]===5)s4++;const lanes=[];for(const sd of g.S.sides)for(const P of sd.paths)if(P)lanes.push(P.lane|0);return {s4,lanes,forms:g.S.sides[1].forms.length};});
 ok('no shape/formation pixels, every path (player + AI) NORMAL lane after a match',scan.s4===0&&scan.lanes.every(v=>v===0)&&scan.forms===0,scan);
 ok('no mid-match walls either side, defense locked',fr.wallsUnchanged&&fr.aiNeverTried&&fr.locked,{w:fr.wallsUnchanged,a:fr.aiNeverTried,l:fr.locked});
 const midWall=await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=11/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const pc=g.S.sides[0].circle,ac=g.S.sides[1].circle;
   for(let i=1;i<=140;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/140,pc.y+(ac.y-pc.y)*i/140);const w=g.wallBegin(0,16,300);if(w){g.wallExtend(0,w,140,300);g.wallEnd(0,w);}g.tryStart();g.S.paused=false;for(let i=0;i<120;i++)g.tick();
   return {p:!!g.wallBegin(0,200,320),a:!!g.wallBegin(1,200,120)};});
 ok('wallBegin refused mid-match for player and AI',!midWall.p&&!midWall.a,midWall);
 // ---------- 3. guard: a player branch aimed at the AI circle is blocked head-on, width matched (+2), re-matched when the player widens
 const gd=await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=17/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;
   const Pl=g.S.sides[0],A=g.S.sides[1],pc=Pl.circle,ac=A.circle;
   for(let i=1;i<=160;i++)g.pathExtend(0,pc.x+(40-pc.x)*i/160,pc.y+(250-pc.y)*i/160);   // main goes off to the left (not at the AI)
   const w=g.wallBegin(0,200,300);if(w){g.wallExtend(0,w,340,300);g.wallEnd(0,w);}g.aiRevisePlan();g.setSetting(0,'release',400);g.tryStart();g.S.paused=false;
   for(let i=0;i<200;i++)g.tick();
   const M=Pl.paths[0],n=M.p.length>>1,bx=M.p[(n-20)*2],by=M.p[(n-20)*2+1];const B=g.branchBegin(0,bx,by);
   for(let i=1;i<=90;i++)g.branchExtend(0,B,bx+(ac.x-bx)*i/90,by+(ac.y-by)*i/90);g.branchEnd(0,B);B.set.width=5;B.set.release=520;
   let t0=g.S.tick,guardAt=-1,gw=-1;for(let i=0;i<400;i++){g.tick();for(const P of A.paths)if(P&&P.job==='guard'&&P.guardOf===B.id){if(guardAt<0){guardAt=g.S.tick-t0;gw=P.set.width;}}if(guardAt>=0)break;}
   const G=A.paths.find(P=>P&&P.job==='guard'&&P.guardOf===B.id);
   // head-on overlap: share of guard points that sit on the player's branch lane
   let on=0,cnt=0;if(G){for(let k=0;k<(G.p.length>>1);k++){cnt++;let bd=1e9;for(let j=0;j<(B.p.length>>1);j++){const d=Math.hypot(G.p[k*2]-B.p[j*2],G.p[k*2+1]-B.p[j*2+1]);if(d<bd)bd=d;}if(bd<6)on++;}}
   B.set.width=8;for(let i=0;i<130;i++)g.tick();const gw2=G&&A.paths[G.id]===G?G.set.width:-1;
   B.set.width=10;for(let i=0;i<130;i++)g.tick();const gw3=G&&A.paths[G.id]===G?G.set.width:-1;
   return {guardAt,gw,gz:G?G.set.size:-1,overlap:cnt?on/cnt:0,gw2,gw3,lessons:g.S.ai?g.S.ai.lessons.filter(l=>/guard|width/.test(l)).slice(-4):[]};});
 ok('AI guards a player branch heading for its circle (within 2 s)',gd.guardAt>=0&&gd.guardAt<=120,gd);
 ok('AI guard picks small pixels for coverage (size 3)',gd.gz===3,{gz:gd.gz});
 ok('guard runs head-on along the player lane (>=40% of its points on that lane)',gd.overlap>=0.4,{overlap:+gd.overlap.toFixed(2)});
 ok('guard width = player width +2 and re-matches (5->7, 8->10, 10->10)',gd.gw===7&&gd.gw2===10&&gd.gw3===10,{gw:gd.gw,gw2:gd.gw2,gw3:gd.gw3});
 // edge pixels: a WIDE player (main 9, offense 9) on fair 23 + variant 19; 0.4.11 AI vs the same AI with guard / width-match / side-approach switched off
 const wide={on:[],off:[]};for(const mode of ['on','off'])for(const base of [SPECS[3],SPECS[4]]){await pg.evaluate(m=>Object.assign(window.__pw.AIR,m==='on'?{guard:1,mainW:1,side:1}:{guard:0,mainW:0,side:0}),mode);
   const r=await runFight(pg,Object.assign({},base,{pw:9,ow:9,name:base.name+'-wide-'+mode}),18000);wide[mode].push({name:base.name,winner:r.winner,ai:r.aiHits,p:r.pHits,t:r.tick});}
 await pg.evaluate(()=>Object.assign(window.__pw.AIR,{guard:1,mainW:1,side:1}));
 const pOn=wide.on.reduce((a,r)=>a+r.p,0),pOff=wide.off.reduce((a,r)=>a+r.p,0);
 ok('wide player (width 9): guard + width match concede <= half the circle hits and win',pOn<=pOff*0.5&&wide.on.every(r=>r.winner===1),wide);
 // ---------- 4. learning: same player 3 matches in a row, memory kept; habits recorded and countered
 await pg.evaluate(()=>window.__pw.clearAiMem());const ser=[];
 for(let m=0;m<3;m++){const r=await runFight(pg,Object.assign({},SPECS[3],{keepMem:1,ps:8,os:9,name:'learn-'+m}),18000);
   const h=await pg.evaluate(()=>{const g=window.__pw,H=g.AIMEM.habits;return H?{n:H.n,width:H.width,size:H.size,offS:H.offS,density:H.density,flow:H.flow,brN:H.brN,straight:H.straight,offense:H.offense}:null;});
   ser.push({m,standing:r.standing,ai:r.aiHits,p:r.pHits,tick:r.tick,mem:r.mem,h,lesson:(r.trace.find(t=>t.lessons&&t.lessons.some(l=>/remembered your habits/.test(l)))||{}).t||null});}
 console.log('LEARN',JSON.stringify(ser));
 ok('habits recorded each match (n 1,2,3) and persisted',ser.map(s=>s.h&&s.h.n).join()==='1,2,3'&&ser[2].mem.matches===3);
 ok('learned habits match what the player did (width 5, pixel size 8, attack size 9, flow 480, branches; no density habit)',ser[2].h&&Math.abs(ser[2].h.width-5)<0.6&&Math.abs(ser[2].h.size-8)<0.6&&Math.abs(ser[2].h.offS-9)<0.8&&ser[2].h.density===undefined&&Math.abs(ser[2].h.flow-480)<40&&ser[2].h.brN>=1,ser[2].h);
 const ctr=await pg.evaluate(()=>{const g=window.__pw;const _r=Math.random;let u=23/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const pc=g.S.sides[0].circle,ac=g.S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150,pc.y+(ac.y-pc.y)*i/150);const w=g.wallBegin(0,16,300);if(w){g.wallExtend(0,w,140,300);g.wallEnd(0,w);}g.aiRevisePlan();g.tryStart();
   const ai=g.S.ai,A=g.S.sides[1];return {hab:ai&&ai.hab&&{n:ai.hab.n},density:A.set.density,size:A.set.size,release:A.set.release,reserve:ai&&ai.reserve,early:ai&&ai.earlyGuard,react:ai&&ai.react,lesson:ai&&ai.lessons.filter(l=>/remembered/.test(l))};});
 ok('next match counters the habits (main size 7 vs your size 8 (3 matches), density stays 5, flow >= 520, spare branch, early guard, fast react, one habits lesson)',ctr.hab&&ctr.hab.n===3&&ctr.size===7&&ctr.density===5&&ctr.release>=520&&ctr.reserve===1&&ctr.early===1&&ctr.react===20&&ctr.lesson.length===1,ctr);
 ok('AI wins the 3-match learning series vs the same player (fair 23)',ser.every(x=>x.standing==='AI ahead'),ser.map(x=>x.standing));
 // ---------- 5. save keys + AI memory migration + delete (v412, falls back to v411 then v410). Old density in a save or AI memory never comes back.
 await pg.evaluate(()=>{localStorage.clear();localStorage.setItem('pixelwar.v411',JSON.stringify({speed:8,density:2,release:700,cap:1000,sdens:7,compact:6,width:9,wins:4,losses:2,stage:0,diff:4}));
   localStorage.setItem('pixelwar.v411.aimem',JSON.stringify({matches:7,wins:3,losses:4,lessons:['old lesson'],best:-1,forms:[],loss:[],tune:{speed:6,density:9,release:520,width:6},open:{L:2,R:-1,gap:1},mirror:{hits:2,detour:1,offense:1,aimX:150,aimN:2,split:0},habits:{n:4,width:6,density:9,flow:500,brN:1}}));});
 await pg.reload();await new Promise(r=>setTimeout(r,900));
 const mig=await pg.evaluate(()=>{const g=window.__pw;g.loadAiMem();const m=g.AIMEM;return {key:g.KEY,keyai:g.KEYAI,matches:m.matches,lessons:m.lessons,mirror:m.mirror.hits,open:m.open.L,tune:m.tune,habits:m.habits,sp:g.S.sides[0].set.speed,wd:g.S.sides[0].set.width,de:g.S.sides[0].set.density,sz:g.S.sides[0].set.size};});
 ok('save keys v412 with v411 fallback (prefs load from v411)',mig.key==='pixelwar.v412'&&mig.keyai==='pixelwar.v412.aimem'&&mig.sp===8&&mig.wd===9,mig);
 ok('old save density 2 not loaded (density stays 5, size defaults 5)',mig.de===5&&mig.sz===5,{de:mig.de,sz:mig.sz});
 ok('v411 AI memory migrated, not wiped; its tune.density and habits.density dropped',mig.matches===7&&mig.lessons[0]==='old lesson'&&mig.mirror===2&&mig.open===2&&mig.tune&&mig.tune.release===520&&mig.tune.density===undefined&&mig.habits&&mig.habits.n===4&&mig.habits.density===undefined,mig);
 const memStart=await pg.evaluate(()=>{const g=window.__pw;const _r=Math.random;let u=11/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const pc=g.S.sides[0].circle,ac=g.S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150,pc.y+(ac.y-pc.y)*i/150);g.aiRevisePlan();g.tryStart();return {aiDens:g.S.sides[1].set.density,plDens:g.S.sides[0].set.density};});
 ok('after loading that memory the AI starts with density 5 (old 9 ignored)',memStart.aiDens===5&&memStart.plDens===5,memStart);
 await pg.evaluate(()=>{localStorage.clear();localStorage.setItem('pixelwar.v410',JSON.stringify({speed:7,density:3,release:600,cap:1000,width:4,wins:1,losses:1,stage:0,diff:4}));localStorage.setItem('pixelwar.v410.aimem',JSON.stringify({matches:5,wins:1,losses:4,lessons:['v410 lesson'],best:-1,forms:[],loss:[],tune:{speed:6,density:7,release:480,width:6}}));});
 await pg.reload();await new Promise(r=>setTimeout(r,900));
 const mig2=await pg.evaluate(()=>{const g=window.__pw;g.loadAiMem();return {sp:g.S.sides[0].set.speed,wd:g.S.sides[0].set.width,de:g.S.sides[0].set.density,matches:g.AIMEM.matches,l:g.AIMEM.lessons[0]};});
 ok('v410 fallback still loads (prefs + AI memory)',mig2.sp===7&&mig2.wd===4&&mig2.de===5&&mig2.matches===5&&mig2.l==='v410 lesson',mig2);
 const del=await pg.evaluate(()=>{const g=window.__pw;g.saveAiMem();localStorage.setItem('pixelwar.v411.aimem','{"matches":3}');const before=[localStorage.getItem('pixelwar.v412.aimem')!==null,localStorage.getItem('pixelwar.v411.aimem')!==null,localStorage.getItem('pixelwar.v410.aimem')!==null];
   document.getElementById('mAiMem').click();document.getElementById('mAiMem').click();const after=[localStorage.getItem('pixelwar.v412.aimem'),localStorage.getItem('pixelwar.v411.aimem'),localStorage.getItem('pixelwar.v410.aimem'),localStorage.getItem('pixelwar.v49.aimem')];
   return {before,after,matches:g.AIMEM.matches,habits:g.AIMEM.habits,label:document.getElementById('mAiMem').textContent};});
 ok('DELETE AI MEMORY button clears v412 + v411 + v410 memory (habits too)',del.before.every(Boolean)&&del.after.every(v=>v===null)&&del.matches===0&&del.habits===null,del);
 // ---------- 6. PIXEL SIZE (the DENSITY slider) + old density off
 await pg.reload();await new Promise(r=>setTimeout(r,900));
 const zu=await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=7/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const S=g.S,pc=S.sides[0].circle,ac=S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150,pc.y+(ac.y-pc.y)*i/150);const w=g.wallBegin(0,16,320);if(w){g.wallExtend(0,w,120,320);g.wallEnd(0,w);}g.aiRevisePlan();g.tryStart();S.paused=false;for(let i=0;i<60;i++)g.tick();
   const M=S.sides[0].paths[0],n=M.p.length>>1,bx=M.p[(n>>1)*2],by=M.p[(n>>1)*2+1];const B=g.branchBegin(0,bx,by);for(let i=1;i<=60;i++)g.branchExtend(0,B,bx+90*i/60,by-60*i/60);g.branchEnd(0,B);
   const el=document.getElementById('sDe'),lab=()=>document.getElementById('lDe').textContent;g.selP=0;el.value=3;el.dispatchEvent(new Event('input',{bubbles:true}));g.draw();const l3=lab();
   g.selP=B.id;el.value=9;el.dispatchEvent(new Event('input',{bubbles:true}));g.draw();const l9=lab();
   return {main:S.sides[0].set.size,br:S.sides[0].paths[B.id].set.size,dens:[S.sides[0].set.density,S.sides[0].paths[B.id].set.density],l3,l9,bid:B.id,boxSpc:getComputedStyle(document.getElementById('boxSpc')).display,aria:el.getAttribute('aria-label')};});
 ok('DENSITY slider now sets PIXEL SIZE per path (main 3, branch 9), old density untouched at 5',zu.main===3&&zu.br===9&&zu.dens.join()==='5,5',zu);
 ok('label still says DENSITY with the size word (3 small, 9 huge)',/^DENSITY/.test(zu.l3)&&/3 small/.test(zu.l3)&&/9 huge/.test(zu.l9),{l3:zu.l3,l9:zu.l9});
 const zsp=await pg.evaluate(bid=>{const g=window.__pw,S=g.S;for(let i=0;i<900;i++)g.tick();let onB=0,onBz=0,onM=0,onMz=0,onM9=0;for(let i=0;i<g.POOL;i++){if(!g.pst[i])continue;if(g.pid[i]===bid){onB++;if(g.psz[i]===9)onBz++;}else if(g.pid[i]===0){onM++;if(g.psz[i]===3)onMz++;else if(g.psz[i]===9)onM9++;}}
   return {onB,onBz,onM,onMz,onM9};},zu.bid);
 ok('pixels take the size of the path they are on (100% of main pixels size 3, >=95% of branch pixels size 9)',zsp.onB>20&&zsp.onBz/zsp.onB>=0.95&&zsp.onMz===zsp.onM,zsp);
 const doff=await pg.evaluate(()=>{const g=window.__pw;const r={};r.s1=g.setSetting(0,'density',9);r.d1=g.S.sides[0].set.density;r.s2=g.setPathSetting(0,1,'density',1);r.d2=g.S.sides[0].paths[1]?g.S.sides[0].paths[1].set.density:5;
   r.s3=g.setSetting(0,'spacing',1);r.d3=g.S.sides[0].set.density;r.off=g.DENSITY_OFF;r.densOf=[g.densOf({density:1}),g.densOf({density:10})];
   // the engine reads density only through densOf: a forced raw density 1 vs 10 gives the identical match (same seed)
   const run=d=>{const _r=Math.random;let u=5/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;const S=g.S;S.sides[1].human=true;const a=S.sides[0].circle,c=S.sides[1].circle;
     for(let i=1;i<=150;i++){g.pathExtend(0,a.x+(c.x-a.x)*i/150,a.y+(c.y-a.y)*i/150);g.pathExtend(1,c.x+(a.x-c.x)*i/150,c.y+(a.y-c.y)*i/150);}
     for(const sd of [0,1]){g.setSetting(sd,'width',6);g.setSetting(sd,'release',600);}g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;S.sides[0].set.density=d;S.sides[1].set.density=11-d;
     for(let i=0;i<900;i++)g.tick();let h=0;for(let i=0;i<g.POOL*2;i++)if(g.pst[i])h=(h*31+Math.round(g.px[i]*100)+Math.round(g.py[i]*7))%1000000007;return [h,S.sides[0].stats.kills,S.sides[1].stats.kills];};
   r.a=run(1);r.b=run(10);return r;});
 ok('old density OFF: setters force 5, spacing does nothing, raw density 1 vs 10 = identical match',doff.d1===5&&doff.d2===5&&doff.d3===5&&doff.off===true&&doff.densOf.join()==='5,5'&&doff.a.join()===doff.b.join(),doff);
 const zst=await pg.evaluate(()=>{const g=window.__pw,out={};for(const z of [1,5,10]){const _r=Math.random;let u=9/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;const S=g.S;S.sides[1].human=true;const a=S.sides[0].circle,c=S.sides[1].circle;
     for(let i=1;i<=150;i++)g.pathExtend(0,a.x+(c.x-a.x)*i/150,a.y+(c.y-a.y)*i/150);for(let i=1;i<=20;i++)g.pathExtend(1,c.x+i,c.y);g.setSetting(0,'width',6);g.setSetting(0,'release',600);g.setSetting(0,'size',z);
     g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;let hp=0,n=0,mx=0;for(let t=0;t<900;t++){g.tick();if(t>600){let k=0;for(let i=0;i<g.POOL;i++)if(g.pst[i])k++;mx+=k;n++;}}
     let hs=0,hn=0,h3=0;for(let i=0;i<g.POOL;i++)if(g.pst[i]&&g.psz[i]===z&&g.pps[i]<20){hs+=g.php[i]/g.HPQ;hn++;if(g.php[i]/g.HPQ>2)h3++;}
     const sp=window.__tt.getSprites().filter(q=>q.kind==='pixel');out[z]={field:Math.round(mx/n),hpMean:hn?+(hs/hn).toFixed(2):null,hpN:hn,sprite:sp.length?sp[0].w:0};}
   out.ct=Math.max(...g.SZ_CT);return out;});
 ok('same FLOW 600: size 1 swarms more pixels, size 10 fewer (ratio ~1.12 : 1 : 0.88)',zst[1].field>zst[5].field&&zst[5].field>zst[10].field&&Math.abs(zst[1].field/zst[5].field-1.12)<0.06&&Math.abs(zst[10].field/zst[5].field-0.88)<0.06,zst);
 ok('size 5 spawns at exactly HP 2 (the locked value); size 10 tougher, size 1 weaker',zst[5].hpMean===2&&zst[10].hpMean>2&&zst[1].hpMean<2,{h1:zst[1].hpMean,h5:zst[5].hpMean,h10:zst[10].hpMean});
 ok('bigger pixels draw bigger (sprite 1 / 2 / 5 px) and hit radius max 4.0 = collision cell',zst[1].sprite===1&&zst[5].sprite===2&&zst[10].sprite===5&&zst.ct<=4,{s:[zst[1].sprite,zst[5].sprite,zst[10].sprite],ct:zst.ct});
 // balance: head-on duels, same flow + width, sides swapped, 2 seeds; bigger wins slightly more kills, smaller holds the front: kill share 40-60, front within 15 of even
 const {duelPair}=require('./duel0412.cjs');const bal=[];for(const [a,c] of [[1,10],[1,5],[5,10],[3,8]]){bal.push(await duelPair(pg,a,c,600,6,2400,[5,9]));}
 console.log('BALANCE',JSON.stringify(bal.map(r=>[r.sA,r.sB,r.killShareA,r.frontA,r.outMax])));
 ok('size balance: small vs big kill share 40-60 and front within 15 units of even (4 pairs)',bal.every(r=>r.killShareA>=40&&r.killShareA<=60&&Math.abs(r.frontA-250)<=15),bal.map(r=>[r.sA,r.sB,r.killShareA,r.frontA]));
 // AI size picks by job + tt hooks
 const pick=await pg.evaluate(()=>{const g=window.__pw;return {cmds:window.__tt.listCommands().map(c=>c.name).filter(n=>/Size|Density/.test(n)),set:window.__tt.runCommand('setSize',[9]),z:g.S.sides[0].set.size,setD:window.__tt.runCommand('setOldDensity',[1]),d:g.S.sides[0].set.density,
   st:(()=>{const s=window.__tt.getState();return {sizes:s.sides[0].sizes,pxSize:s.pixels.length?s.pixels[0].size:null};})()};});
 ok('tt hooks: setSize / setPathSize / setOldDensity commands, getState carries sizes',pick.cmds.includes('setSize')&&pick.cmds.includes('setPathSize')&&pick.z===9&&pick.d===5&&Array.isArray(pick.st.sizes),pick);
 // ---------- 7. smooth motion: during a fair match nearly all live pixels are moving, none stuck
 await runFight(pg,Object.assign({},SPECS[3],{name:'motion'}),900);
 const mv=await pg.evaluate(()=>{const g=window.__pw;let live=0,still=0;for(let i=0;i<g.POOL*2;i++){if(!g.pst[i])continue;live++;if(Math.hypot(g.pvx[i],g.pvy[i])<0.5)still++;}return {live,still};});
 ok('smooth motion mid-match (fair 23, t=900): >=97% of live pixels moving',mv.live>200&&mv.still/mv.live<0.03,mv);
 ok('no JS errors',pg._errs.length===0,pg._errs);
 await b.close();
 const f=res.filter(r=>!r.pass);console.log('CHECKS pass '+(res.length-f.length)+' / fail '+f.length);if(f.length)process.exit(1);
})().catch(e=>{console.error(e);process.exit(1);});
