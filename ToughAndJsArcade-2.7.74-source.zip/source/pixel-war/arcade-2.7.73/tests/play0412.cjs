// Pixel War 0.4.12 — Tough plays it (t1201/t1202). Three scripted matches vs the full-smart AI, memory carried across the series.
// Every feature is used: circle placement, defense line (locks at START), main path, pace, lane width, flow, the PIXEL SIZE slider (labelled DENSITY)
// at min / mid / max through the real +/- buttons and slider, branches (attack), a detour that merges back downstream, a loop-connect upstream,
// erasing a branch mid-match (free) and redrawing it. Hidden SPACING is poked to prove it does nothing. Screenshots in out/.
const {launch,open}=require('./lib.cjs');const fs=require('fs');const path=require('path');
const OUT=path.join(__dirname,'out0412');fs.mkdirSync(OUT,{recursive:true});
const PLANS=[
 {name:'M1 swarm',seed:31,mainSize:1,mainW:7,pace:6,flow:650,detourSize:5,attackSize:10,attackW:3,changes:[[600,'size',5],[1200,'size',10],[1500,'width',4],[1800,'flow',820],[2100,'pace',8]]},
 {name:'M2 bruiser',seed:47,mainSize:10,mainW:4,pace:7,flow:700,detourSize:10,attackSize:1,attackW:6,changes:[[600,'size',5],[1200,'size',1],[1500,'width',8],[1800,'flow',500],[2100,'pace',5]]},
 {name:'M3 mixed',seed:59,mainSize:5,mainW:6,pace:7,flow:600,detourSize:2,attackSize:9,attackW:3,changes:[[600,'size',9],[1200,'size',2],[1500,'width',5],[1800,'flow',900],[2100,'pace',6]]}];
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 await pg.evaluate(()=>window.__pw.clearAiMem());const log=[];
 for(let m=0;m<PLANS.length;m++){const P=PLANS[m];
  const pre=await pg.evaluate(P=>{const g=window.__pw;const _r=Math.random;let u=P.seed/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const S=g.S,me=S.sides[0];
    // move my circle a little (prep), then the defense line with a gap for my own path
    g.placeCircle(0,P.seed%2?150:210,me.circle.y);const pc=me.circle,ac=S.sides[1].circle;
    const wy=pc.y-70;const gx=pc.x;const w1=g.wallBegin(0,10,wy);if(w1){g.wallExtend(0,w1,gx-30,wy);g.wallEnd(0,w1);}const w2=g.wallBegin(0,gx+30,wy);if(w2){g.wallExtend(0,w2,350,wy);g.wallEnd(0,w2);}
    // main path: up through my gap, a gentle S toward the AI circle
    for(let i=1;i<=200;i++){const t=i/200,x=pc.x+(ac.x-pc.x)*t+(t>0.3?Math.sin((t-0.3)/0.7*Math.PI*2)*40:0),y=pc.y+(ac.y-pc.y)*t;g.pathExtend(0,x,y);}
    g.aiRevisePlan&&g.aiRevisePlan();
    // sliders for the main path through the real UI (selP 0): size via the slider, width / pace / flow via setPathSetting like the slider handlers
    g.selP=0;const el=document.getElementById('sDe');el.value=P.mainSize;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
    g.setPathSetting(0,0,'width',P.mainW);g.setPathSetting(0,0,'speed',P.pace);g.setSetting(0,'release',P.flow);
    const spc=g.setSetting(0,'spacing',1);const pathN=me.paths[0].p.length>>1,need=g.prepNeeds?g.prepNeeds(me):[];const started=g.tryStart();S.paused=false;
    return {started,pathN,need,locked:!!me.defLocked,walls:me.strokes.length,mainSize:me.set.size,dens:me.set.density,spacingNoop:spc&&me.set.density===5,aiMainSize:S.sides[1].set.size,aiLessons:S.ai?S.ai.lessons.filter(l=>/remembered|pixel size/.test(l)).slice(-2):[]};},P);
  const ev=[];let t=0,shot=0;const aiSizes={};
  while(t<18000){
   const r=await pg.evaluate((t,P)=>{const g=window.__pw,S=g.S,me=S.sides[0],A=S.sides[1],out={};const M=me.paths[0],n=M.p.length>>1;
     if(t===180){ // DETOUR: out to the side and back into my main further down (merge)
       const fk=Math.floor(n*0.3),rk=Math.floor(n*0.55),x0=M.p[fk*2],y0=M.p[fk*2+1],x1=M.p[rk*2],y1=M.p[rk*2+1],side=x0<180?1:-1;const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=40;i++){const s=i/40;g.branchExtend(0,B,x0+(x1-x0)*s+side*70*Math.sin(s*Math.PI),y0+(y1-y0)*s);}g.branchExtend(0,B,x1,y1);g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.detourSize);g.setPathSetting(0,B.id,'width',5);g.setPathSetting(0,B.id,'release',380);}out.detour=Q?{id:B.id,rj:Q.rj,loop:Q.loop,size:Q.set.size}:null;}}
     if(t===300){ // LOOP-CONNECT upstream: from late on the main, curl back into an earlier part of it
       const fk=Math.floor(n*0.62),rk=Math.floor(n*0.4),x0=M.p[fk*2],y0=M.p[fk*2+1],x1=M.p[rk*2],y1=M.p[rk*2+1],side=x0<180?1:-1;const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=40;i++){const s=i/40;g.branchExtend(0,B,x0+(x1-x0)*s+side*60*Math.sin(s*Math.PI),y0+(y1-y0)*s);}g.branchExtend(0,B,x1,y1);g.branchEnd(0,B);const Q=me.paths[B.id];out.loop=Q?{id:B.id,rj:Q.rj,loop:Q.loop}:null;if(Q)g.setPathSetting(0,B.id,'release',250);}}
     if(t===420){ // ATTACK branch hooking round to the AI circle
       const fk=Math.floor(n*0.5),x0=M.p[fk*2],y0=M.p[fk*2+1],ac=A.circle,vx=x0<180?Math.min(340,ac.x+90):Math.max(20,ac.x-90);const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=80;i++){const s=i/80;g.branchExtend(0,B,x0+(vx-x0)*s*(1-s)*2+(ac.x-x0)*s*s,y0+(ac.y-y0)*s);}g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.attackSize);g.setPathSetting(0,B.id,'width',P.attackW);g.setPathSetting(0,B.id,'release',520);g.setPathSetting(0,B.id,'speed',8);}out.attack=Q?{id:B.id,size:Q.set.size,n:Q.p.length>>1}:null;}}
     for(const c of P.changes)if(c[0]===t){if(c[1]==='size'){g.selP=0;const el=document.getElementById('sDe');el.value=c[2];el.dispatchEvent(new Event('input',{bubbles:true}));}else if(c[1]==='flow')g.setSetting(0,'release',c[2]);else g.setPathSetting(0,0,c[1]==='pace'?'speed':c[1],c[2]);out.change=c;}
     if(t===2400){ // ERASE my attack branch (free) and redraw it fresh
       let id=-1;for(let k=me.paths.length-1;k>=1;k--)if(me.paths[k]&&me.paths[k].rj<0){id=k;break;}if(id>0){g.removeBranch(me,id);out.erased=id;}
       const fk=Math.floor(n*0.45),x0=M.p[fk*2],y0=M.p[fk*2+1],ac=A.circle;const B=g.branchBegin(0,x0,y0);if(B){for(let i=1;i<=70;i++){const s=i/70;g.branchExtend(0,B,x0+(ac.x-x0)*s+(x0<180?60:-60)*Math.sin(s*Math.PI),y0+(ac.y-y0)*s);}g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.attackSize);g.setPathSetting(0,B.id,'release',500);}out.redraw=Q?{id:B.id,size:Q.set.size}:null;}}
     for(let i=0;i<30;i++){if(S.over)break;g.tick();}
     const aiB=[];for(let k=0;k<A.paths.length;k++){const Q=A.paths[k];if(Q)aiB.push([k,Q.job||'main',k?Q.set.size:A.set.size,k?Q.set.width:A.set.width]);}
     const zc=[0,0,0,0,0,0,0,0,0,0,0];for(let i=0;i<g.POOL;i++)if(g.pst[i])zc[g.psz[i]]++;
     out.st={t:S.tick,over:S.over,w:S.winner,hp:[Math.round(me.circle.hp),Math.round(A.circle.hp)],aiB,mySizes:zc.map((v,i)=>v?i+':'+v:'').filter(Boolean).join(' '),walls:[me.strokes.length,A.strokes.length],lock:[!!me.defLocked,!!A.defLocked],lessons:S.ai?S.ai.lessons.slice(-2):[]};return out;},t,P);
   for(const x of r.st.aiB)if(x[0]>0){const k=x[1]+':'+x[2];aiSizes[k]=(aiSizes[k]||0)+1;}
   if(r.detour||r.loop||r.attack||r.change||r.erased||r.redraw)ev.push(Object.assign({t},r.detour?{detour:r.detour}:{},r.loop?{loop:r.loop}:{},r.attack?{attack:r.attack}:{},r.change?{change:r.change}:{},r.erased?{erased:r.erased}:{},r.redraw?{redraw:r.redraw}:{},{mySizes:r.st.mySizes}));
   if((t===660||t===1260||t===2220)&&shot<3){shot++;const c=await pg.$('canvas');await c.screenshot({path:path.join(OUT,'m'+(m+1)+'-t'+t+'.png')});}
   t+=30;if(r.st.over){ev.push({t,end:r.st});break;}
   if(t%1800===0)ev.push({t,hp:r.st.hp,aiB:r.st.aiB,mySizes:r.st.mySizes,lessons:r.st.lessons});}
  const post=await pg.evaluate(()=>{const g=window.__pw,H=g.AIMEM.habits;return {mem:{matches:g.AIMEM.matches,wins:g.AIMEM.wins,losses:g.AIMEM.losses,tune:g.AIMEM.tune},hab:H?{n:H.n,size:H.size,offS:H.offS,width:+(+H.width).toFixed(2),flow:Math.round(H.flow),brN:H.brN,detour:H.detour,loop:H.loop}:null,winner:g.S.winner,tick:g.S.tick,
    stats:[0,1].map(s=>({kills:g.S.sides[s].stats.kills,hits:g.S.sides[s].stats.circleDmg})),summary:g.S.aiSummary?g.S.aiSummary.lessons.filter(l=>/size|guard|width|habit/.test(l)).slice(-6):[]};});
  log.push({match:P.name,pre,aiSizes,events:ev,post});
  console.log('MATCH',P.name,JSON.stringify({pre,winner:post.winner===1?'AI':post.winner===0?'me':'draw',sec:+(post.tick/60).toFixed(1),stats:post.stats,mem:post.mem,hab:post.hab,aiSizes,lessons:post.summary}));}
 fs.writeFileSync(path.join(OUT,'play-log.json'),JSON.stringify(log,null,1));
 console.log('ERRS',JSON.stringify(pg._errs));await b.close();})().catch(e=>{console.error(e);process.exit(1);});
