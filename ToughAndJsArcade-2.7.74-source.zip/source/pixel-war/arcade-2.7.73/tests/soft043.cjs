// SOFT TEST 0.4.3: one quick functional check per mechanic / physics behaviour. Prints "N. NAME: PASS|FAIL - what was seen".
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar043/out/';fs.mkdirSync(OUT,{recursive:true});
const code=function(){
const P=window.__pw,R=[];const POOL=P.POOL;{const _bb=P.branchBegin;P.branchBegin=(s,x,y)=>{if(P.S.phase==='prep')P.startBattle();return _bb(s,x,y);};P.branchBegin.orig=_bb;}
const T=(name,fn)=>{let r;try{r=fn();}catch(e){r={pass:false,msg:'EXCEPTION '+e.message};}R.push({name:name,pass:!!r.pass,msg:String(r.msg)});};
const lcg=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
const f1=v=>(+v).toFixed(2);
function fresh(seed,cfg){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130,relMul:360},cfg||{});/*0.4.3: relMul 360 keeps area/lane tests fed*/P.newGame(seed||1,false);P.setRnd(lcg(seed||1));}
function mainPath(side,pts){const q=pts||[[180,400],[184,330],[190,260],[196,190],[196,130]];for(const k of q)P.pathExtend(side||0,k[0],k[1]);}
function quietFoe(){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;f.acc=0;for(let i=POOL;i<2*POOL;i++)if(P.pst[i])P.recall(i);}
function run(n){for(let i=0;i<n;i++)P.tick();}
function battle(seed,cfg,quiet){fresh(seed,cfg);P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();if(quiet!==false)quietFoe();return P.S.sides[0];}
const count=(side,f)=>{let c=0;for(let i=side*POOL;i<side*POOL+POOL;i++)if(P.pst[i]&&(!f||f(i)))c++;return c;};
function clearPix(){for(let i=0;i<2*POOL;i++)if(P.pst[i])P.recall(i);}
function put(i,x,y,vx,vy,st){P.pspm[i]=1;P.px[i]=x;P.py[i]=y;P.pvx[i]=vx;P.pvy[i]=vy;P.php[i]=2;P.pst[i]=st||3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;P.pgc[i]=0;}
const A=0,B=POOL;
function lateral(side,pid){const sd=P.S.sides[side],p=sd.paths[pid].p,n=p.length/2;let s=0,c=0;for(let i=side*POOL;i<side*POOL+POOL;i++){if(P.pst[i]!==2||P.pid[i]!==pid)continue;let bd=1e9;for(let k=0;k<n;k++){const d=Math.hypot(P.px[i]-p[k*2],P.py[i]-p[k*2+1]);if(d<bd)bd=d;}s+=bd;c++;}return c?s/c:-1;}
let N=0;
// 1 POOL
T('POOL',()=>{fresh(1);const s=P.S.sides;return{pass:s[0].pool===10000&&s[1].pool===10000&&s[0].circle.hp===10000,msg:'both circles start at pool '+s[0].pool+', circle HP = pool'};});
// 2 LIVES
T('LIVES',()=>{const sd=battle(2);const i=A+1;let used=0;for(let k=0;k<20;k++){put(i,200,300,0,0,3);sd.active++;P.loseLife(i);used++;}return{pass:P.plife[i]===0&&sd.pool===9999,msg:'a pixel started with 20 lives; after 20 collision deaths plife='+P.plife[i]+', pool '+sd.pool+' (gone for good)'};});
// 3 BURN
T('BURN',()=>{const sd=battle(3),foe=P.S.sides[1];const c=sd.circle;put(B+1,c.x,c.y-5,0,0,3);foe.active++;const h0=sd.pool;P.collide();return{pass:sd.pool===h0-20&&sd.circle.hp===sd.pool,msg:'one enemy pixel into my circle: pool '+h0+' -> '+sd.pool+' (burn 20)'};});
// 4 RELEASE
T('RELEASE',()=>{const sd=battle(4);sd.set.release=5;sd.acc=0;const r0=sd.stats.released;run(60);const n=sd.stats.released-r0;return{pass:n>=P.rateOf(sd.set)*0.95&&n<=P.rateOf(sd.set)*1.05+1,msg:'FLOW 5 = '+(P.rateOf(sd.set))+'/s: '+n+' pixels left the circle in 1 s'};});
// 5 PACE / DENSITY
T('PACE and DENSITY',()=>{const dist=sp=>{const sd=battle(5);sd.set.speed=sp;sd.set.release=3;run(70);let m=0,c=0;const base=0;for(let i=0;i<POOL;i++){if(P.pst[i]){m+=Math.hypot(P.px[i]-180,P.py[i]-456);c++;}}return m/Math.max(1,c);};
  const slow=dist(2),fast=dist(9);
  const lat=d=>{const sd=battle(5);sd.set.density=d;sd.set.release=6;run(150);return lateral(0,0);};
  const loose=lat(2),tight=lat(9);return{pass:fast>slow*1.3&&loose>tight*1.4,msg:'PACE 9 pixels travelled '+f1(fast/slow)+'x farther than PACE 2; DENSITY 2 lane spread '+f1(loose)+' vs DENSITY 9 '+f1(tight)};});
// 6 LANE SHAPES
T('LANE SHAPES',()=>{const lat=ty=>{fresh(6);P.placeCircle(0,180,456);mainPath(0);P.setLane(0,0,ty);P.S.sides[1].human=true;P.startBattle();quietFoe();P.S.sides[0].set.release=6;run(160);return lateral(0,0);};
  const nm=lat(0),wd=lat(1),nr=lat(2);
  const tp=P.laneF(3,0)>P.laneF(3,0.5)&&P.laneF(3,0.5)>P.laneF(3,1),ar=P.laneF(4,0.3)<P.laneF(4,0.8)&&P.laneF(4,1)<P.laneF(4,0.8);
  fresh(6);P.placeCircle(0,180,456);mainPath(0);P.setLane(0,0,4);const pp=P.lanePoly(P.S.sides[0].paths[0],P.laneHW(P.S.sides[0].set));
  return{pass:wd>nm*1.15&&nm>nr*1.15&&tp&&ar&&!!pp,msg:'pixel spread NARROW '+f1(nr)+' < NORMAL '+f1(nm)+' < WIDE '+f1(wd)+'; TAPERED narrows '+f1(P.laneF(3,0))+'->'+f1(P.laneF(3,1))+'; ARROW shaft '+f1(P.laneF(4,0.3))+', head '+f1(P.laneF(4,0.8))+', tip '+f1(P.laneF(4,1))+'; overlay polygon built'};});
T('LANE overlay + area are visible and stay inside the field',()=>{fresh(6);P.placeCircle(0,180,456);mainPath(0);P.draw();let ok2=true;for(const ty of[0,1,2,3,4]){P.setLane(0,0,ty);try{P.draw();}catch(e){ok2=false;}}return{pass:ok2,msg:'drew all 5 lane types without error (overlay = flat translucent polygon, hairline edge)'};});
function areaOf(sd,t){return sd.sq.find(q=>q&&q.t===t);}
function formArea(t,cfg,seed){const sd=battle(seed||3,cfg);P.useShape(0,0,t);run(170);return {sd:sd,q:areaOf(sd,t)};}
function members(q){const o=[];for(let m=0;m<q.n;m++){const i=q.slot[m];if(i>=0)o.push(i);}return o;}
function insideFrac(q){const ms=members(q);let c=0;for(const i of ms)if(P.areaSd(q,i)<=P.CFG.koMargin)c++;return ms.length?c/ms.length:0;}
// 7 ARROW FRONT + the sizes: wide ~5x thin, arrowhead <= 3x thin
T('ARROW leading edge (pixels gather at the front of the area)',()=>{const frac=af=>{const {q}=formArea(1,{arrowFront:af},3);if(!q)return 0;const Lu=q.def.Lu;let f=0,b=0;for(const i of members(q)){const u=P.plu[i];if(u>-Lu/3)f++;else if(u<-2*Lu/3)b++;}return f/Math.max(1,b);};
  const a60=frac(60),a0=frac(0);return{pass:a60>a0*1.3&&a60>1,msg:'ARROW front-third : back-third members = '+f1(a60)+' with front concentration vs '+f1(a0)+' without'};});
T('WIDE ~5x the THIN lane, ARROWHEAD up to ~3x thin',()=>{const hw=P.laneHW({width:5});const th=P.laneF(2,0.5)*hw,wd=P.laneF(1,0.5)*hw;const ar=P.areaDef(1,hw,P.laneF(4,0.7)).rad,ar2=P.areaDef(1,hw,0.4).rad;
  return{pass:wd/th>4.5&&wd/th<5.5&&ar<=th*3.02&&ar>th*2&&ar2<=th*3.02,msg:'lane half-widths: wide '+f1(wd)+' / thin '+f1(th)+' = '+f1(wd/th)+'x; ARROW area half-width '+f1(ar)+' = '+f1(ar/th)+'x thin (cap 3x)'};});
// 8 SHAPE AREAS: free wander inside a soft hitbox, each shape
const names=['LINE','ARROW','WEDGE','RING','DIAMOND','DOUBLE','SPIRAL'];
for(const t of[0,1,2,3,4,5,6]){T('SHAPE AREA '+names[t],()=>{const {sd,q}=formArea(t,{ring:1});if(!q)return{pass:false,msg:'no area formed'};const fr=insideFrac(q),e=P.formErr(0,q.id);const min=t===5||t===6?0.7:0.88;return{pass:q.live>=60&&fr>=min&&e<3,msg:q.live+' pixels wander in the area, '+Math.round(fr*100)+'% inside its edge (+margin), mean distance outside '+f1(e)+' units, '+(P.cdTicks(t)/60).toFixed(1)+'s cooldown'};});}
T('AREA: pixels free-wander (not slots) and are denser along the line',()=>{const {sd,q}=formArea(2,{},3);if(!q)return{pass:false,msg:'no area'};const ms=members(q),rad=q.def.rad;
  const p0=ms.map(i=>[P.px[i],P.py[i]]);run(60);let moved=0;for(let k=0;k<ms.length;k++){const i=ms[k];if(P.pst[i]>=4&&Math.hypot(P.px[i]-p0[k][0],P.py[i]-p0[k][1])>0)moved++;}
  let inner=0,outer=0;for(const i of ms){if(P.pst[i]<4)continue;const v=Math.abs(P.plv[i]);if(v<rad*0.5)inner++;else if(v<rad*1.0)outer++;}
  return{pass:moved>ms.length*0.9&&inner>outer*1.5&&outer>0,msg:ms.length+' members, '+moved+' moved in 1 s (always shifting); inner half-width holds '+inner+' wander spots vs outer half '+outer+' (equal widths, so clearly denser toward the line)'};});
T('AREA width follows the lane at the form point (never grows it)',()=>{const hw=P.laneHW({width:5});const wide=P.areaDef(0,hw,P.laneF(3,0.1)).rad,narrow=P.areaDef(0,hw,P.laneF(3,0.9)).rad,all=[0,1,2,3,4,5,6].every(t=>P.areaDef(t,hw,1).rad<=1.2*hw+1e-6&&P.areaDef(t,hw,1).Lu<=48.001);
  return{pass:narrow<wide*0.6&&all,msg:'TAPERED lane: area half-width '+f1(wide)+' formed near the circle vs '+f1(narrow)+' formed late; every shape stays <= 1.2x the lane half-width and <= 48 long'};});
T('AREA hold: curved path, no enemy, almost nobody is knocked out',()=>{const sd=battle(31,{},true);const pts=[[180,400],[240,340],[250,270],[200,200],[140,160]];fresh(31);P.placeCircle(0,180,456);for(const k of pts)P.pathExtend(0,k[0],k[1]);P.S.sides[1].human=true;P.startBattle();quietFoe();
  P.useShape(0,0,1);let maxKo=0,live=0;for(let k=0;k<420;k++){P.tick();const q=areaOf(P.S.sides[0],1);if(q){maxKo=Math.max(maxKo,q.ko);live=Math.max(live,q.live);}}
  const kn=P.S.sides[0].stats.knocked;return{pass:live>=100&&kn<=live*0.05,msg:'a bending path over 7 s: area of '+live+' pixels, knocked out '+kn+' ('+Math.round(100*kn/Math.max(1,live))+'%)'};});
T('KNOCK-OUT: a collision knocks pixels out of the area',()=>{const {sd,q}=formArea(1,{},3);if(!q)return{pass:false,msg:'no area'};const id=q.id,ms=members(q);const k0=sd.stats.knocked;
  let cx=0,cy=0;for(const i of ms){cx+=P.px[i];cy+=P.py[i];}cx/=ms.length;cy/=ms.length;P.S.sides[1].paths[0].p=[cx,cy-30,cx,cy-26];
  let k=0;for(let m=0;m<ms.length&&k<90;m++){if(m%2===0){put(B+k,P.px[ms[m]]+1.2,P.py[ms[m]],0,0,3);k++;}}P.S.sides[1].active+=k;
  let peak=0,st5=0;for(let s=0;s<60;s++){P.movePixels();P.collide();P.S.tick++;const qq=sd.sq[id];if(!qq)break;peak=Math.max(peak,P.formErr(0,id));let c5=0;for(let m=0;m<qq.n;m++){const i=qq.slot[m];if(i>=0&&P.pst[i]===5)c5++;}st5=Math.max(st5,c5);}
  for(let i=B;i<B+k;i++)if(P.pst[i])P.recall(i);P.S.sides[1].active=0;
  return{pass:sd.stats.knocked-k0>=10&&st5>=10,msg:'90 enemy pixels crashed into the area: '+(sd.stats.knocked-k0)+' pixels knocked out of the hitbox (peak '+st5+' outside at once), mean distance outside peaked at '+f1(peak)+' units'};});
T('KNOCK-OUT: knocked pixels rejoin when they are close, and the area regroups',()=>{const {sd,q}=formArea(1,{},3);if(!q)return{pass:false,msg:'no area'};const id=q.id;const ms=members(q).slice(0,60);
  for(const i of ms){const a=P.areaSd(q,i);const tx=-q.ty,ty=q.tx,rad=q.def.rad;P.px[i]=q.cx+tx*(rad+9)+q.tx*P.plu[i];P.py[i]=q.cy+ty*(rad+9)+q.ty*P.plu[i];P.pvx[i]=0;P.pvy[i]=0;P.pcnt[i]=0;}
  const r0=sd.stats.reentered,k0=sd.stats.knocked;run(2);let out=0;for(const i of ms)if(P.pst[i]===5)out++;run(70);let back=0;for(const i of ms)if(P.pst[i]===4)back++;
  return{pass:out>=40&&back>=out*0.7&&sd.stats.reentered-r0>=30,msg:'60 members pushed ~9 units past the edge: '+out+' were knocked out, 1.2 s later '+back+' are back inside ('+(sd.stats.reentered-r0)+' rejoined)'};});
T('RECALL: knocked out past the leash (from the shape edge) goes home',()=>{const {sd,q}=formArea(1,{},3);if(!q)return{pass:false,msg:'no area'};const ms=members(q).slice(0,20);const lash=P.CFG.leash;const rc0=sd.stats.koRecall;
  const near=ms.slice(0,10),far=ms.slice(10);const place=(i,d)=>{const tx=-q.ty,ty=q.tx,rad=q.def.rad;P.px[i]=q.cx+tx*(rad+d);P.py[i]=q.cy+ty*(rad+d);P.pvx[i]=0;P.pvy[i]=0;P.pcnt[i]=0;};
  for(const i of near)place(i,lash*0.5);for(const i of far)place(i,lash+8);
  const ok0=far.every(i=>P.areaSd(q,i)>lash);run(P.CFG.fadeSec*60+10);const gone=far.filter(i=>!P.pst[i]).length,kept=near.filter(i=>P.pst[i]).length;
  return{pass:ok0&&gone>=9&&kept>=8&&sd.stats.koRecall-rc0>=9,msg:'leash = '+lash+' units from the edge: 10 pixels placed at '+Math.round(lash+8)+' beyond it -> '+gone+' recalled to the circle; 10 at '+Math.round(lash*0.5)+' -> '+kept+' still out and heading back ('+(sd.stats.koRecall-rc0)+' recalls)'};});
T('HIT on an area member pushes it (knock impulse)',()=>{const {sd,q}=formArea(0,{},3);if(!q)return{pass:false,msg:'no area'};const ms=members(q).slice(0,40);for(const i of ms)P.pcd[i]=0;P.movePixels();const v0=ms.map(i=>[P.pvx[i],P.pvy[i]]);
  ms.forEach((i,k)=>put(B+3+k,P.px[i]+1.3,P.py[i],0,0,3));P.S.sides[1].active+=ms.length;P.collide();let pushed=0,mx=0;ms.forEach((i,k)=>{const d=Math.hypot(P.pvx[i]-v0[k][0],P.pvy[i]-v0[k][1]);if(d>8)pushed++;if(d>mx)mx=d;});
  return{pass:pushed>=15,msg:'40 area members touched by an enemy pixel: '+pushed+' got a velocity kick of >8 units/s (largest '+f1(mx)+', knockK '+P.CFG.knockK+')'};});
T('ARROW ability forms and thins the stream behind it (borrowed, lane not widened)',()=>{const cnt=(arm)=>{const sd=battle(3,{});sd.set.release=6;if(arm)P.useShape(0,0,1);run(150);let lane=0,area=0;for(let i=0;i<POOL;i++){if(P.pst[i]===2)lane++;else if(P.pst[i]>=4)area++;}return{lane:lane,area:area,lat:lateral(0,0)};};
  const a=cnt(true),b=cnt(false);return{pass:a.area>=100&&a.lane<=b.lane-a.area*0.5&&b.area===0,msg:'with the ARROW armed: '+a.area+' pixels in the area, stream behind holds '+a.lane+' (vs '+b.lane+' with no shape): the area borrows from the stream; lane spread '+f1(a.lat)+' vs '+f1(b.lat)};});
T('AREA starts right at the circle (at = 0)',()=>{const sd=battle(3,{});const P0=sd.paths[0];if(P0.sh)P0.sh.at=0;P.useShape(0,0,0);let d=1e9;for(let k=0;k<200;k++){P.tick();const q=areaOf(sd,0);if(q){d=Math.hypot(q.cx-sd.circle.x,q.cy-sd.circle.y);break;}}
  return{pass:d<46,msg:'with the start point set to the circle, the area opened '+Math.round(d)+' units from the circle centre'};});
T('AREA breaks up when too few pixels survive',()=>{const {sd,q}=formArea(0,{});if(!q)return{pass:false,msg:'no area'};const id=q.id;let killed=0;const want=q.live-4;for(const i of members(q)){if(killed<want){P.loseLife(i);killed++;}}
  run(3);const gone=!sd.sq[id];return{pass:gone&&sd.stats.formBreaks>0,msg:'killed '+killed+' of '+q.n+': area disbanded='+gone+', survivors carry on as the normal stream (breaks '+sd.stats.formBreaks+')'};});
T('AREA feather: soft yellow draws behind the dots, also without ctx.filter',()=>{fresh(9);P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();quietFoe();P.useShape(0,0,2);run(170);let e1=null,e2=null;try{P.draw();}catch(e){e1=e.message;}window.__pwNoFilter=true;try{P.draw();}catch(e){e2=e.message;}window.__pwNoFilter=false;
  return{pass:!e1&&!e2,msg:'drew a battle with an open area: filter path '+(e1||'ok')+', fallback (layered copies) '+(e2||'ok')};});
// 9 EDITOR + PRESETS (engine side)
T('EDITOR and PRESETS (outline)',()=>{localStorage.removeItem(P.KEYF);P.PRESETS=[];P.ED.sel=-1;const heart=[];for(let a=0;a<28;a++){const t=a/28*Math.PI*2;heart.push([0.5+0.42*Math.sin(t)*(1-0.3*Math.cos(t)),0.5-0.4*Math.cos(t)]);}P.ED.pts=heart;P.ED.poly=P.edPoly();const np=P.ED.poly?P.ED.poly.length:0;const i=P.edSave();
  const raw=JSON.parse(localStorage.getItem(P.KEYF)||'[]');P.PRESETS=[];P.loadForms();P.syncForms();fresh(9);const sd=battle(9);P.useShape(0,0,7);run(170);const q=areaOf(sd,7);
  return{pass:i===0&&np>=4&&np<=P.C.POLYMAX&&raw.length===1&&!!raw[0].poly&&P.PRESETS.length===1&&!!q&&q.live>=40&&sd.stats.shapeMade[7]>0,msg:'drawn outline of 28 raw points simplified to '+np+' (cap '+P.C.POLYMAX+'), saved as '+(P.PRESETS[0]&&P.PRESETS[0].name)+', survives reload ('+P.PRESETS.length+' preset), used as ability C1: '+(q?q.live:0)+' pixels in it'};});
T('PRESETS reject junk, repair, cap at 6, old v4 dots convert',()=>{const bad=[null,{},{poly:[[99,99]]},{poly:'x'},{poly:[[0,0],[1,1],[0.5,0.5]]},{poly:[[NaN,0],[1,Infinity],['a',2]]},{poly:[[0,0],[0.01,0],[0.01,0.01]]}];const res=bad.map(b=>P.cleanForm(b));
  const bow=P.cleanForm({name:'bow',poly:[[0,0],[1,1],[1,0],[0,1]]}),sloppy=P.cleanForm({name:5,poly:[[2,-1],[0.9,0],[0.5,1.4],[0.1,0.5]]}),old=P.cleanForm({name:'old',cells:[[1,1],[2,2],[3,3],[4,1],[2,5],[5,5]]});
  P.PRESETS=[];for(let k=0;k<8;k++)P.addPreset('X'+k,[[0.1,0],[0.9,0],[0.5,1]]);const n=P.PRESETS.length;P.PRESETS=[];localStorage.removeItem(P.KEYF);
  return{pass:res.every(v=>v===null)&&bow&&sloppy&&old&&old.poly.length>=3&&n===6,msg:'7 malformed outlines rejected, a self-crossing bow-tie became its hull ('+(bow&&bow.poly.length)+' pts), a sloppy one clamped, a v4 dot-grid converted ('+(old&&old.poly.length)+' pts), '+n+' of 8 saved (cap 6)'};});
// 10 AI CUSTOM SHAPES
T('AI designs and uses custom shapes',()=>{let designed=0,used=0,cdOk=true,valid=true;for(const seed of[1,2,3,4]){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{aiLevel:3});P.newGame(seed,false);P.setRnd(lcg(seed));P.placeCircle(0,180,456);mainPath(0);P.startBattle();const ai=P.S.sides[1];designed+=ai.forms.length;for(const f of ai.forms){if(!f.poly||f.poly.length<3||!P.cleanForm(f))valid=false;}
    for(let k=0;k<3000;k++){P.tick();if(k%50===0){for(let t=7;t<13;t++)if(ai.shUsed[t]>0){const cdT=P.cdTicks(t);if(ai.shUsed[t]>P.S.tick/cdT+1.01)cdOk=false;}}}
    for(let t=7;t<13;t++)used+=ai.shUsed[t];}
  return{pass:designed>=4&&used>=2&&cdOk&&valid,msg:'Hard AI drew '+designed+' outlines over 4 seeds (all valid polygons), fired custom shapes '+used+' times, never faster than the cooldown ('+cdOk+')'};});
T('AI shape design is bounded and mutates (not fixed)',()=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130});P.newGame(11,false);P.setRnd(lcg(11));const sd=P.S.sides[1];const sigs=new Set();for(let k=0;k<6;k++){const f=P.aiDesignForm(sd);if(f)sigs.add(f.name+f.poly.length);}return{pass:sd.forms.length===6&&sigs.size>=3&&P.aiDesignForm(sd)===null,msg:sd.forms.length+' designs ('+sigs.size+' distinct), 7th refused (6-slot cap)'};});
// 11 BRANCH REDRAW (free)
T('BRANCH erase and redraw mid-match is FREE',()=>{fresh(12);P.placeCircle(0,180,456);mainPath(0);const sd0=P.S.sides[0],M=sd0.paths[0];const bp=P.branchBegin(0,M.p[40],M.p[41]);P.branchExtend(0,bp,100,250);P.branchEnd(0,bp);P.eraseAt(0,M.p[40]+3,M.p[41]);const prepFree=sd0.brWaste===0;
  fresh(12);P.placeCircle(0,180,456);mainPath(0);const M2=P.S.sides[0].paths[0],sd2=P.S.sides[0];const b2=P.branchBegin(0,M2.p[40],M2.p[41]);P.branchExtend(0,b2,100,250);P.branchEnd(0,b2);P.S.sides[1].human=true;P.startBattle();quietFoe();
  const used0=P.pathUsed(sd2);const L0=P.brUsed(b2),left0=P.brLeft(sd2,b2);const did=P.eraseAt(0,b2.p[b2.p.length-2],b2.p[b2.p.length-1]);const L1=P.brUsed(b2),left1=P.brLeft(sd2,b2);const waste1=sd2.brWaste;
  const cont=P.branchBegin(0,b2.p[b2.p.length-2],b2.p[b2.p.length-1]);const same=cont===b2;const mainErase=P.eraseAt(0,M2.p[20],M2.p[21]);
  let capOk=true,cycles=0;for(let k=0;k<40;k++){const q=sd2.paths[1];if(!q)break;P.eraseAt(0,q.p[q.p.length-2],q.p[q.p.length-1]);const b=P.branchBegin(0,q.p[q.p.length-2],q.p[q.p.length-1]);if(b)P.branchExtend(0,b,100,250);if(P.brTotal(sd2)>P.brCap()+1e-6)capOk=false;cycles++;}
  return{pass:prepFree&&did&&L1<L0&&left1>left0&&waste1===0&&sd2.brWaste===0&&same&&!mainErase&&P.pathUsed(sd2)===used0&&capOk,msg:'erase in prep and in battle cost 0 meter (waste '+sd2.brWaste+'); erase cut the branch '+Math.round(L0)+'->'+Math.round(L1)+' and gave the meter back ('+Math.round(left0)+'->'+Math.round(left1)+'); dragging from its end continues the same branch; main path erase refused; '+cycles+' erase/redraw cycles never exceed the cap'};});
// 12 WALL cells
T('WALL numbers: 1000 HP per section, 5 damage per hit',()=>{fresh(13);P.placeCircle(0,180,456);P.S.sides[1].human=true;const st=P.wallBegin(0,140,400);P.wallExtend(0,st,230,400);P.wallEnd(0,st);P.startBattle();quietFoe();P.S.sides[1].paths[0].p=[180,340,180,344];
  const cells=st.segs;const hp0=cells.map(c=>c.hp);put(B,182,396,0,40,3);P.S.sides[1].active=1;for(let k=0;k<5;k++){P.movePixels();P.collide();}const ch=cells.map((c,i)=>hp0[i]-c.hp).filter(d=>d!==0);
  return{pass:P.CFG.segHP===1000&&P.CFG.wallDmg===5&&ch.length===1&&ch[0]===5,msg:'segHP '+P.CFG.segHP+' (cell '+P.cellHP()+' HP), wallDmg '+P.CFG.wallDmg+'; one enemy hit changed exactly '+ch.length+' cell by '+ch.join()};});
// 12 WALL CELLS
T('WALL cells (local damage, hole opens)',()=>{fresh(13);P.placeCircle(0,180,456);P.S.sides[1].human=true;const st=P.wallBegin(0,140,400);P.wallExtend(0,st,230,400);P.wallEnd(0,st);P.startBattle();quietFoe();P.S.sides[1].paths[0].p=[180,340,180,344];
  const sd=P.S.sides[0];const cells=st.segs;const hp0=cells.map(c=>c.hp);put(B,182,396,0,40,3);P.S.sides[1].active=1;for(let k=0;k<5;k++){P.movePixels();P.collide();}const changed=cells.filter((c,i)=>c.hp!==hp0[i]).length;
  for(let k=0;k<4000&&cells.some(c=>c.alive&&Math.abs((c.x1+c.x2)/2-182)<3);k++){put(B,182,396,0,40,3);P.pcd[B]=0;P.movePixels();P.collide();}
  const dead=cells.filter(c=>!c.alive).length;return{pass:changed===1&&dead>=1&&dead<cells.length/3,msg:'one hit changes exactly '+changed+' cell; hammering the spot kills '+dead+' of '+cells.length+' cells (the hole opens there only)'};});
// 13 GATES
T('GATES (friendly-only openings)',()=>{const mk=gate=>{fresh(14);P.placeCircle(0,180,456);const st=P.wallBegin(0,150,420,gate);P.wallExtend(0,st,210,420);P.wallEnd(0,st);P.S.sides[1].human=true;P.startBattle();quietFoe();P.S.sides[1].paths[0].p=[180,380,180,384];P.S.sides[1].circle.x=60;
    const sd=P.S.sides[0];put(A,180,436,0,-60,3);sd.active=1;let minY=999;for(let k=0;k<40;k++){P.movePixels();P.collide();if(P.py[A]<minY)minY=P.py[A];}const passed=P.py[A]<418;
    const cells=st.segs;const hp0=cells.reduce((a,c)=>a+c.hp,0);put(B,180,404,0,60,3);P.S.sides[1].active=1;for(let k=0;k<30;k++){P.movePixels();P.collide();}const dmg=hp0-cells.reduce((a,c)=>a+c.hp,0);
    return{passed:passed,gp:sd.stats.gatePass,enemyBlocked:P.py[B]<420,dmg:dmg};};
  const g=mk(true),w=mk(false);return{pass:g.passed&&g.gp>0&&g.enemyBlocked&&g.dmg>0&&!w.passed,msg:'own pixel through a GATE: passed='+g.passed+' (gate passes '+g.gp+'); through a normal wall: passed='+w.passed+'; enemy pixel at the gate: blocked='+g.enemyBlocked+', gate damaged '+g.dmg+' (localized)'};});
T('GATES: your path may cross a gate, not a wall',()=>{const cross=gate=>{fresh(15);P.placeCircle(0,180,456);const st=P.wallBegin(0,150,380,gate);P.wallExtend(0,st,215,380);P.wallEnd(0,st);P.pathExtend(0,184,300);const p=P.S.sides[0].paths[0].p;let miny=1e9;for(let k=1;k<p.length;k+=2)if(p[k]<miny)miny=p[k];return miny;};
  const g=cross(true),w=cross(false);return{pass:g<340&&w>380,msg:'main path drawn through a gate reached y='+Math.round(g)+'; drawn at a normal wall it stops at y='+Math.round(w)};});
// 14 HYBRID RICOCHET
function rico(mode,setup,Ntr,neigh){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{ricoMode:mode});P.newGame(7,false);P.setRnd(lcg(99));P.placeCircle(0,180,456);P.placeCircle(1,180,44);P.S.sides[0].human=P.S.sides[1].human=true;P.startBattle();clearPix();
  let surv=0,pushed=0,pushDmg=0;const s0=P.S.sides[0],s1=P.S.sides[1];
  for(let n=0;n<Ntr;n++){s0.active=60;s1.active=60;for(let k=0;k<neigh;k++){put(A+2+k,96+(k%3),196+((k/3)|0)*1.4,0,0,3);}put(A,100,200,0,0,3);put(B,102,200,0,0,3);setup(A,B);P.collide();if(P.php[A]===2)surv++;if(P.pstun[B]>0)pushed++;if(P.pstun[B]>0&&P.php[B]===1)pushDmg++;P.pstun[B]=0;P.pstun[A]=0;}
  return{surv:surv/Ntr,push:pushed/Ntr,pd:pushDmg/Ntr};}
const head=(v)=>(a,b)=>{P.pvx[a]=v;P.pvy[a]=0;P.pvx[b]=-v;P.pvy[b]=0;};
const glance=(v)=>(a,b)=>{P.pvx[a]=v;P.pvy[a]=0;P.pvx[b]=0;P.pvy[b]=v;};
T('RICOCHET angle',()=>{const h=rico(3,head(50),3000,0),g=rico(3,glance(50),3000,0);return{pass:g.surv>h.surv*1.8&&g.push>h.push,msg:'glancing hits survive '+f1(g.surv)+' / push '+f1(g.push)+' vs head-on survive '+f1(h.surv)+' / push '+f1(h.push)};});
T('RICOCHET relative speed',()=>{const sl=rico(3,head(15),3500,0),fa=rico(3,head(75),3500,0);return{pass:fa.pd>sl.pd*1.5&&fa.surv<sl.surv,msg:'fast head-on: enemy pushed away while still hit '+f1(fa.pd)+', survive '+f1(fa.surv)+'; slow: pushed '+f1(sl.pd)+', survive '+f1(sl.surv)+' (fast hits hit harder and push farther)'};});
T('RICOCHET neighbour packing (density)',()=>{const lo=rico(3,head(50),3000,0),hi=rico(3,head(50),3000,24);return{pass:hi.surv>lo.surv*2,msg:'24 packed neighbours: survive '+f1(hi.surv)+' vs loose '+f1(lo.surv)+' (rho from 1 to 25)'};});
T('RICOCHET modes stay selectable (RANDOM / ANGLE / HYBRID / FULL)',()=>{const r=[0,1,2,3].map(m=>rico(m,glance(50),1500,0).surv);return{pass:r[1]>r[0]&&r[3]>0&&{...P.C.DEFCFG,shapesOn:1,paceMax:130}.ricoMode===3,msg:'glancing survive per mode '+r.map(f1).join(' / ')+' (default FULL HYBRID)'};});
// 15 DRIFT and LEASH
T('DRIFT and LEASH',()=>{fresh(16);P.placeCircle(0,180,456);P.pathExtend(0,180,400);P.pathExtend(0,180,380);P.S.sides[1].human=true;P.startBattle();quietFoe();const sd=P.S.sides[0];sd.set.release=6;const p=sd.paths[0].p,ex=p[p.length-2],ey=p[p.length-1];
  let maxD=0,hd=[],r0=sd.stats.recalled;let maxDev=0,nEnd=0;for(let k=0;k<420;k++){P.tick();for(let i=0;i<POOL;i++)if(P.pst[i]===3&&!P.pfree[i]){const d=Math.hypot(P.px[i]-ex,P.py[i]-ey);if(d>maxD)maxD=d;const an=Math.atan2(P.pvy[i],P.pvx[i]);let dv=Math.abs(an+Math.PI/2);if(dv>Math.PI)dv=2*Math.PI-dv;if(dv>maxDev)maxDev=dv;nEnd++;if(k===419)hd.push(an);}}
  let sx=0,sy=0;for(const a of hd){sx+=Math.cos(a);sy+=Math.sin(a);}const R=Math.hypot(sx,sy)/Math.max(1,hd.length);const spread=Math.sqrt(-2*Math.log(Math.max(1e-6,R)));
  return{pass:maxD<=P.CFG.leash+P.speedOf(sd.set)*P.CFG.fadeSec*1.15+4&&sd.stats.recalled>r0&&hd.length>20&&maxDev<0.55&&spread<0.45,msg:'t1131 pixels past the path end head the same way as the path end (max heading error '+f1(maxDev*57.3)+' deg over '+nEnd+' pixel-ticks, limit 31; spread '+f1(spread)+' rad), no loops; recalled at the leash: farthest '+Math.round(maxD)+' <= leash '+P.CFG.leash+' + the fade-out run; '+(sd.stats.recalled-r0)+' recalled'};});

// 0.4.3 additions
T('t1130 EXIT follows the path start direction (curved start path, no kink)',()=>{fresh(60);P.placeCircle(0,180,456);for(const k of[[180,430],[176,404],[160,380],[132,360],[100,346]])P.pathExtend(0,k[0],k[1]);P.S.sides[1].human=true;P.startBattle();quietFoe();const sd=P.S.sides[0];sd.set.release=6;sd.set.speed=5;
  let maxTurn=0,n=0;const last={};for(let k=0;k<200;k++){P.tick();for(let i=0;i<POOL;i++)if(P.pst[i]===1||(P.pst[i]===2&&P.pps[i]<60)){const a=Math.atan2(P.pvy[i],P.pvx[i]);if(last[i]!==undefined){let d=Math.abs(a-last[i]);if(d>Math.PI)d=2*Math.PI-d;if(d>maxTurn)maxTurn=d;n++;}last[i]=a;}else delete last[i];}
  return{pass:n>200&&maxTurn<0.12,msg:'pixels leaving the circle turn at most '+f1(maxTurn*57.3)+' deg in one tick along a curved path start ('+n+' samples, limit 6.9)'};});
T('t1130 RICOCHET pixels still fade out past the leash',()=>{fresh(61);P.placeCircle(0,180,456);P.pathExtend(0,180,400);P.pathExtend(0,180,340);P.S.sides[1].human=true;P.startBattle();quietFoe();const sd=P.S.sides[0],p=sd.paths[0].p;const i=3;P.recall(i);
  // a ricocheted (free, straight) pixel starts near the path and flies sideways
  P.pst[i]=3;P.pfree[i]=1;P.pfade[i]=0;P.pid[i]=0;P.px[i]=180;P.py[i]=350;P.pvx[i]=20;P.pvy[i]=0;P.php[i]=2;P.pspm[i]=1;sd.active++;let faded=-1,gone=-1,maxD=0;
  for(let k=0;k<1200;k++){P.tick();if(P.pst[i]===0){gone=k;break;}if(P.pfade[i]>0&&faded<0)faded=k;maxD=Math.max(maxD,Math.hypot(P.px[i]-180,P.py[i]-340));}
  return{pass:gone>0&&faded>0&&maxD<P.CFG.leash+20*P.CFG.fadeSec*1.3+30,msg:'ricocheted pixel flew straight, started fading at tick '+faded+' and was removed at tick '+gone+' (farthest '+Math.round(maxD)+' from the path end; leash '+P.CFG.leash+')'};});
T('t1130 STEADY FLOW: even spacing, no per-tick bursts',()=>{const sd=battle(62);sd.set.release=5;sd.set.speed=5;sd.acc=0;const rate=P.rateOf(sd.set)/60;let maxPerTick=0,tot=0;for(let k=0;k<300;k++){const a0=sd.stats.released;P.tick();const d=sd.stats.released-a0;maxPerTick=Math.max(maxPerTick,d);tot+=d;}
  // spacing of pixels along the path (state 1/2, pid 0) should be nearly uniform
  const ps=[];for(let i=0;i<POOL;i++)if((P.pst[i]===2||P.pst[i]===1)&&P.pid[i]===0)ps.push(P.pps[i]);ps.sort((a,b)=>a-b);const gaps=[];for(let k=1;k<ps.length;k++)gaps.push(ps[k]-ps[k-1]);const m=gaps.reduce((a,b)=>a+b,0)/Math.max(1,gaps.length);const big=gaps.filter(g=>g>m*6).length;
  return{pass:maxPerTick<=Math.ceil(rate)&&Math.abs(tot/300-rate)<rate*0.1&&P.flowPS(5)===100,msg:'FLOW 5 = '+P.flowPS(5)+' pixels/s ('+f1(rate)+' per tick): released '+f1(tot/300)+' per tick, never more than '+maxPerTick+' in one tick; '+ps.length+' pixels on the path, '+big+' large gaps'};});
T('t1130 DEFAULT density and flow are low',()=>{fresh(63,{relMul:120});const d=P.S.sides[0].set;return{pass:d.density<=3&&d.release<=3&&P.rateOf(d)<=40,msg:'defaults: DENSITY '+d.density+', FLOW '+d.release+' ('+P.rateOf(d)+' pixels/s; was 1080/s)'};});
T('t1130 per-path FLOW slider: a branch has its own steady stream',()=>{const sd=battle(64);sd.set.release=4;P.S.phase==='battle';const B=P.branchBegin(0,190,260);if(B){for(const k of[[230,230],[262,190],[290,150]])P.branchExtend(0,B,k[0],k[1]);P.branchEnd(0,B);}
  if(!B)return{pass:false,msg:'no branch'};P.setPathSetting(0,B.id,'release',1);run(1);const cnt=(rel)=>{P.setPathSetting(0,B.id,'release',rel);sd.pacc=[];for(let i=0;i<POOL;i++)if(P.pst[i])P.recall(i);sd.acc=0;let n=0;for(let k=0;k<500;k++){P.tick();}for(let i=0;i<POOL;i++)if(P.pst[i]&&P.pid[i]===B.id)n++;return n;};
  const lo=cnt(1),hi=cnt(8);return{pass:hi>lo*3&&P.rateOf(B.set)===P.flowPS(8)&&B.set.release===8,msg:'branch FLOW 1 -> '+lo+' pixels on the branch, FLOW 8 -> '+hi+' (main FLOW stays '+sd.set.release+')'};});

T('t1132 RICOCHET SPRAY: many bounced pixels leave their lane heading, sideways',()=>{fresh2(70);P.placeCircle(0,180,456);for(const k of[[180,400],[180,330],[180,260],[180,190],[180,120]])P.pathExtend(0,k[0],k[1]);P.S.sides[1].human=true;P.S.sides[1].strokes=[];P.placeCircle(1,180,44);for(const k of[[180,100],[180,170],[180,240],[180,310],[180,380]])P.pathExtend(1,k[0],k[1]);
  const a=P.S.sides[0],b=P.S.sides[1];a.set.release=b.set.release=8;a.set.cap=b.set.cap=4000;P.startBattle();let n=0,side=0,off=0;const seen={};
  for(let k=0;k<700;k++){P.tick();for(let i=0;i<2*POOL;i++)if(P.pfree[i]&&P.pst[i]===3&&!seen[i]){seen[i]=1;const dir=i<POOL?-1:1;const an=Math.atan2(P.pvy[i],P.pvx[i]);const ref=dir<0?-Math.PI/2:Math.PI/2;let dv=Math.abs(an-ref);if(dv>Math.PI)dv=2*Math.PI-dv;n++;if(dv>0.5)off++;if(Math.abs(P.pvx[i])>Math.abs(P.pvy[i]))side++;}}
  return{pass:n>60&&off/n>0.55&&side/n>0.2,msg:n+' pixels ricocheted: '+Math.round(100*off/n)+'% left their course by more than 29 deg, '+Math.round(100*side/n)+'% fly mostly sideways'};});
T('t1132 PAST THE END: loose widening cone, mostly straight, never loops back',()=>{fresh2(71);P.placeCircle(0,180,456);P.pathExtend(0,180,400);P.pathExtend(0,180,380);P.S.sides[1].human=true;P.startBattle();quiet2();const sd=P.S.sides[0];sd.set.release=6;sd.set.cap=2000;
  const first={},devs=[];let maxTurn=0,rev=0;const lastA={};for(let k=0;k<480;k++){P.tick();for(let i=0;i<POOL;i++)if(P.pst[i]===3&&!P.pfree[i]){const an=Math.atan2(P.pvy[i],P.pvx[i]);if(lastA[i]!==undefined){let d=Math.abs(an-lastA[i]);if(d>Math.PI)d=2*Math.PI-d;if(d>maxTurn)maxTurn=d;}lastA[i]=an;if(first[i]===undefined){first[i]=1;let dv=Math.abs(an+Math.PI/2);if(dv>Math.PI)dv=2*Math.PI-dv;devs.push(dv);if(P.pvy[i]>0)rev++;}}else delete lastA[i];}
  devs.sort((x,y)=>x-y);const med=devs[devs.length>>1],p95=devs[Math.floor(devs.length*0.95)];
  return{pass:devs.length>80&&med<0.2&&p95>0.25&&p95<0.7&&maxTurn<0.02&&rev===0,msg:'t1131/t1132 '+devs.length+' pixels past the end: median heading error '+f1(med*57.3)+' deg, 95th '+f1(p95*57.3)+' deg (a loose cone), largest turn in one tick '+f1(maxTurn*57.3)+' deg (no steering), '+rev+' headed back'};});
T('t1132 THIN LANE packs denser (default and wide stay loose)',()=>{const dens=w=>{const sd=bat2(72,{});sd.set.width=w;sd.set.release=5;sd.set.speed=5;run(500);let n=0,sw=0;for(let i=0;i<POOL;i++)if(P.pst[i]===2&&P.pid[i]===0){n++;}const hw=P.laneHW({width:w});return n/(hw*2);};
  const d2=dens(2),d5=dens(5),d9=dens(9);return{pass:d2>d5*1.5&&d5>d9*1.2,msg:'pixels per unit of lane width: WIDTH 2 '+f1(d2)+' > WIDTH 5 (default) '+f1(d5)+' > WIDTH 9 '+f1(d9)};});
T('t1133 DEFENSE LINE draws smoothly: jittery finger -> smooth wall, follows 1:1',()=>{fresh2(73);P.placeCircle(0,180,456);P.S.tool='wall';const r=lcg(5);const pts=[];for(let k=0;k<150;k++){const x=15+k*2.2,y=330+30*Math.sin(k/22);pts.push([x+(r()-.5)*3,y+(r()-.5)*3,x,y]);}
  P.toolDown({x:pts[0][0],y:pts[0][1]});for(let k=1;k<pts.length;k++)P.toolMove({x:pts[k][0],y:pts[k][1]});P.toolUp();
  const st=P.S.sides[0].strokes[0];if(!st)return{pass:false,msg:'no stroke'};const q=st.pts;const turns=[];for(let k=4;k<q.length;k+=2){const a1=Math.atan2(q[k-1]-q[k-3],q[k-2]-q[k-4]),a2=Math.atan2(q[k+1]-q[k-1],q[k]-q[k-2]);let d=Math.abs(a2-a1);if(d>Math.PI)d=2*Math.PI-d;turns.push(d);}
  turns.sort((x,y)=>x-y);const mean=turns.reduce((x,y)=>x+y,0)/turns.length,p95=turns[Math.floor(turns.length*0.95)];let maxOff=0;for(let k=0;k<q.length;k+=2){let m=1e9;for(const t of pts)m=Math.min(m,Math.hypot(q[k]-t[2],q[k+1]-t[3]));maxOff=Math.max(maxOff,m);}
  const e=q.length,last=pts[pts.length-1],endD=Math.hypot(q[e-2]-last[0],q[e-1]-last[1]);
  return{pass:p95<0.3&&mean<0.12&&maxOff<3.2&&endD<4,msg:'wall of '+(q.length/2)+' points: mean turn '+f1(mean*57.3)+' deg, 95th '+f1(p95*57.3)+' deg, farthest from the true curve '+f1(maxOff)+', ends '+f1(endD)+' from the finger'};});

// 16 RECYCLING
T('RECYCLING',()=>{const sd=battle(17);sd.set.release=8;run(900);const inv=P.qN[0]+sd.active-sd.debt===sd.pool;const again=sd.stats.released>sd.active+sd.stats.lostForGood;return{pass:inv&&again&&sd.stats.recalled>0,msg:'pool '+sd.pool+' = ready '+P.qN[0]+' + out '+sd.active+' - debt '+sd.debt+'; '+sd.stats.released+' releases from '+(10000-sd.pool)+' lost: pixels re-enter after returning to the circle'};});
// 17 COOLDOWNS
T('COOLDOWNS',()=>{battle(18);const a=P.useShape(0,0,1);P.S.sides[0].paths[0].arm=null;const b=P.useShape(0,0,1);const c=P.useShape(0,0,0);P.S.sides[0].paths[0].arm=null;run(P.cdTicks(1)+2);P.S.sides[0].paths[0].arm=null;const d=P.useShape(0,0,1);
  return{pass:a&&!b&&c&&d&&P.cdTicks(0)<P.cdTicks(6),msg:'ARROW fires ('+a+'), again at once refused ('+!b+'), LINE has its own timer ('+c+'), ARROW ready again after '+(P.cdTicks(1)/60).toFixed(1)+'s ('+d+'); LINE '+(P.cdTicks(0)/60).toFixed(1)+'s < SPIRAL '+(P.cdTicks(6)/60).toFixed(1)+'s'};});
// 18 DIFFICULTY
T('DIFFICULTY changes decisions only, never stats',()=>{const snap=[],plan=[];for(let lv=1;lv<=4;lv++){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{aiLevel:lv});P.newGame(5,false);P.setRnd(lcg(5));P.placeCircle(0,180,456);const sd=P.S.sides[1];
    snap.push(JSON.stringify({pool:sd.pool,hp:sd.circle.hp,set:sd.set,life:P.plife[POOL+5],cd:[0,1,2,3,4,5,6].map(P.cdTicks),pm:P.CFG.pathMax,bm:P.CFG.brMax,wm:P.CFG.wallMax,burn:P.CFG.burn,lives:P.CFG.lives,cap:sd.set.cap,r:P.CFG.circleR}));
    P.aiPlan(1);const pi=P.S.planInfo[1];plan.push(pi.walls+'w'+pi.gates+'g'+pi.branches+'b'+pi.forms.length+'f'+(pi.lane?'L':''));}
  const same=snap.every(s=>s===snap[0]);const differ=new Set(plan).size>=3;
  return{pass:same&&differ,msg:'pool, lives, burn, cooldowns, meters, settings identical at EASY/NORMAL/HARD/BRUTAL; decisions differ (walls/gates/branches/formations/lane): '+plan.join(' | ')};});
T('DIFFICULTY adaptation: Easy never learns, Brutal adapts fastest',()=>{const ev=[];for(let lv=1;lv<=4;lv++){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{aiLevel:lv});P.newGame(5,false);P.placeCircle(0,180,456);mainPath(0);P.startBattle();ev.push([!!P.S.ai,lv>=2?P.S.ai&&1:0]);}
  return{pass:ev[0][0]===false&&ev[1][0]&&ev[2][0]&&ev[3][0],msg:'AI memory: EASY off, NORMAL/HARD/BRUTAL on; adapt every '+[1,2,3,4].map(l=>P.DIFFN[l]+' '+(l>=4?60:l>=3?150:240)/60+'s').join(', ')};});
// 19 STAGES
T('PROGRESSION: 4 stages unlock mechanics gradually',()=>{const rep=[];const chk=n=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{stage:n,aiLevel:n});P.newGame(20,false);P.setRnd(lcg(20));P.PRESETS=[{name:'T',poly:[[0.1,0],[0.9,0],[0.5,1]]}];P.syncForms();P.placeCircle(0,180,456);const sd=P.S.sides[0];
      return{walls:!!P.wallBegin(0,150,420),gate:!!P.wallBegin(0,150,440,true),br:(()=>{mainPath(0);return !!P.branchBegin(0,sd.paths[0].p[40],sd.paths[0].p[41]);})(),shapes:[0,1,2,4,6].map(t=>P.shapeOkS(sd,t)),forms:P.shapeOkS(sd,7),laneAB:P.setLane(0,0,1),laneCD:P.setLane(0,0,3),rico:P.feat('rico3'),aiForms:P.feat('aiForms')};};
    const s=[1,2,3,4].map(chk);P.PRESETS=[];P.syncForms();const f=(()=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130});P.newGame(20,false);return P.feat('walls')&&P.feat('rico3')&&P.feat('aiForms');})();
    const okp=!s[0].walls&&!s[0].br&&!s[0].shapes.some(x=>x)&&s[1].walls&&s[1].br&&s[1].shapes[0]&&s[1].shapes[1]&&!s[1].shapes[3]&&!s[1].gate&&!s[1].laneCD&&s[1].laneAB&&s[2].gate&&s[2].shapes[3]&&s[2].shapes[4]&&s[2].forms&&s[2].laneCD&&!s[2].rico&&s[3].rico&&s[3].aiForms&&!s[2].aiForms&&f;
    return{pass:okp,msg:'S1 path only (walls '+s[0].walls+', branches '+s[0].br+', shapes none); S2 +walls/branches/LINE-ARROW-WEDGE/wide-narrow; S3 +gates, all shapes, own formations, tapered lanes; S4 +full hybrid ricochet and AI formations; FREE PLAY has all ('+f+')'};});
T('PROGRESSION: stage start sets difficulty and records a cleared stage',()=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130});P.startStage(3);const c=P.CFG.stage===3&&P.CFG.aiLevel===3;const before=P.prefs.stage;P.prefs.stage=0;P.S.sides[1].human=false;P.endMatch(0);const up=P.prefs.stage===3;P.prefs.stage=before;P.startStage(0);return{pass:c&&up&&P.CFG.stage===0,msg:'stage 3 = HARD AI; winning it records stage 3 cleared; stage 0 = free play ('+P.CFG.stage+')'};});
// 20 STATS
T('STATS: interceptions, formations, efficiency, barrier damage, duration, destroyed',()=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{aiLevel:3});P.newGame(21,false);P.setRnd(lcg(21));P.placeCircle(0,180,456);P.placeCircle(1,180,44);P.S.sides[1].human=true;
    for(let k=1;k<=30;k++){P.pathExtend(0,180,456-k*7);P.pathExtend(1,180,44+k*6);}
    P.startBattle();P.useShape(0,0,1);P.S.sides[1].set.cap=4000;run(1500);P.useShape(1,0,4);run(600);const a=P.S.sides[0].stats,b=P.S.sides[1].stats;const L=P.resultLines().map(x=>x[0]);const need=['Particles destroyed','Interceptions','Deployment efficiency','Barrier damage','Shape performance','Time'];
  const cons=a.kills===b.livesUsed&&b.kills===a.livesUsed&&a.wallDmg===b.wallTaken&&b.wallDmg===a.wallTaken;const icOk=a.intercepts+b.intercepts>0&&a.intercepts<=a.kills&&b.intercepts<=b.kills;
  return{pass:need.every(n=>L.indexOf(n)>=0)&&cons&&icOk&&a.released>0&&a.kills>50,msg:'after '+(P.S.tick/60).toFixed(0)+' s: destroyed '+a.kills+'/'+b.kills+', interceptions '+a.intercepts+'/'+b.intercepts+', barrier dmg dealt '+a.wallDmg+'/'+b.wallDmg+', efficiency '+Math.round(100*(a.kills+a.circleDmg)/Math.max(1,a.released))+'%, formations made '+a.shapeMade.reduce((x,y)=>x+y,0)+'; conserved (my kills = their lives used, my wall damage = their wall taken): '+cons};});
// 21 AI REVIEW + wipe
T('AI REVIEW shown at the end, then tactical memory wiped',()=>{P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:130},{aiLevel:3,burn:1});P.newGame(22,false);P.setRnd(lcg(22));P.placeCircle(0,180,456);mainPath(0);P.startBattle();run(2400);const hadMem=!!P.S.ai&&P.S.sides[1].forms.length>0;P.endMatch(0);const rv=P.S.aiReview;const wiped=P.S.ai===null&&P.S.sides[1].forms.length===0;
  P.newGame(23,false);const cleared=P.S.aiReview===null;P.setRnd(lcg(23));P.placeCircle(0,180,456);mainPath(0);P.startBattle();const fresh0=P.S.ai&&P.S.ai.lessons.length===0;
  return{pass:hadMem&&rv&&rv.lines.length>=5&&wiped&&cleared&&fresh0,msg:'review '+(rv?rv.lines.length:0)+' lines ("'+(rv?rv.lines[0].slice(0,60):'')+'"), AI memory + its formations wiped at the end='+wiped+', review cleared on the next game='+cleared+', next match starts with 0 lessons='+fresh0};});
// ======================= 0.4.3 NEW TESTS (one per ask, default CFG = the real game) =======================
const D0=()=>Object.assign({},P.C.DEFCFG);
function fresh2(seed,cfg){P.CFG=Object.assign(D0(),cfg||{});P.newGame(seed||1,false);P.setRnd(lcg(seed||1));}
function quiet2(){const f=P.S.sides[1];f.human=true;f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;f.strokes=[];f.segs=[];P.rebuildSegs(f);for(let i=POOL;i<2*POOL;i++)if(P.pst[i])P.recall(i);f.acc=0;}
function bat2(seed,cfg){fresh2(seed,cfg);P.placeCircle(0,180,456);for(const k of[[180,400],[180,330],[180,260],[180,190],[180,120]])P.pathExtend(0,k[0],k[1]);P.S.sides[1].human=true;P.startBattle();quiet2();return P.S.sides[0];}
const pct=(a,q)=>{if(!a.length)return 0;a=a.slice().sort((x,y)=>x-y);return a[Math.min(a.length-1,Math.max(0,Math.floor(q*(a.length-1))))];};
T('t1122 SHAPES HIDDEN: off by default, code kept (Custom flag brings them back)',()=>{fresh2(1);const sd=P.S.sides[0];const off=!P.feat('shapes')&&!P.feat('forms')&&!P.feat('aiForms')&&!P.shapeOkS(sd,1);const row=P.CUSTOM.some(r=>r[0]==='shapesOn');
  fresh2(1,{shapesOn:1});const on=P.feat('shapes')&&P.shapeOkS(P.S.sides[0],1);return{pass:P.C.DEFCFG.shapesOn===0&&off&&row&&on,msg:'default shapesOn='+P.C.DEFCFG.shapesOn+', shape tools '+(off?'hidden':'SHOWN')+', Custom Game has the hidden-shapes flag='+row+', flag ON brings them back='+!!on};});
T('t1122 SLOTH SPEED: the fastest PACE is slow (units per second)',()=>{const hi=P.speedOf({speed:10}),lo=P.speedOf({speed:1});let far=0;const sd=bat2(41,{});sd.set.speed=10;sd.set.release=6;run(300);for(let i=0;i<POOL;i++)if(P.pst[i]){far=Math.max(far,Math.hypot(P.px[i]-180,P.py[i]-456));}
  return{pass:hi<=24.001&&lo<=7&&500/hi>=20&&far<=hi*5+34,msg:'PACE 10 = '+f1(hi)+' u/s (crossing the 500u field takes '+f1(500/hi)+' s), PACE 1 = '+f1(lo)+' u/s; after 5 s at PACE 10 the farthest pixel is '+Math.round(far)+'u from the circle (<= '+Math.round(hi*5+34)+')'};});
T('t1116 DEFENSE REQUIRED: START needs a main path AND a wall line',()=>{fresh2(42);P.placeCircle(0,180,456);const sd=P.S.sides[0];for(const k of[[180,400],[180,330],[180,260]])P.pathExtend(0,k[0],k[1]);const n1=P.prepNeeds(sd).join('+');P.S.aiRev=1;const s1=P.tryStart();const ph1=P.S.phase;
  const st=P.wallBegin(0,120,380);P.wallExtend(0,st,240,380);P.wallEnd(0,st);const n2=P.prepNeeds(sd).join('+');const s2=P.tryStart();
  return{pass:n1==='wall'&&!s1&&ph1==='prep'&&n2===''&&s2&&P.S.phase==='battle',msg:'path only: still needs "'+n1+'", START refused='+!s1+'; after a '+Math.round(P.wallLen(sd))+'u wall: needs "'+n2+'", START works='+s2};});
T('t1116 AI DRAWS ITS MAIN PATH AND WALLS IN PREP (both see them)',()=>{fresh2(43);const f=P.S.sides[1],m=P.S.sides[0];const rev0=P.S.aiRev;const path=P.pathUsed(f),wall=P.wallLen(f);const stk=f.strokes.length;
  P.placeCircle(0,60,456);const replanned=P.S.aiRev===0&&f.planned;
  return{pass:rev0<1&&path>=P.MINPATH&&wall>=P.MINWALL&&stk>=1&&replanned&&P.prepNeeds(f).length===0,msg:'AI plan at the start of prep: main path '+Math.round(path)+'u, '+stk+' wall piece(s) '+Math.round(wall)+'u, reveal starts at '+rev0+' and plays out over ~3 s; moving my circle replans it ('+replanned+'); AI needs: '+P.prepNeeds(f).join('+')};});
T('t1116 SPARKLE: a destroyed pixel splits into 1x1 bits that fade; pooled and capped',()=>{bat2(44,{missP:0,ricoP:0,ricoMode:0});P.setRnd(()=>0.999);const b0=P.VFX.bits,s0=P.VFX.sparkBursts;
  for(let k=0;k<200;k++){const a=k,b=POOL+k,x=20+(k%20)*16,y=150+Math.floor(k/20)*14;put(a,x,y,0,0,3);put(b,x+1,y,0,0,3);P.php[a]=1;P.php[b]=1;}
  P.S.sides[0].active=200;P.S.sides[1].active=200;P.collide();const added=P.VFX.bits-b0,bursts=P.VFX.sparkBursts-s0,n1=P.vpN;
  P.setRnd(lcg(5));let t=0;for(;t<200&&P.vpN>0;t++)P.vfxStep();
  return{pass:bursts>=4&&bursts<=20&&added===bursts*4&&n1<=P.VPMAX&&P.vpN===0&&t>=30&&t<=100,msg:'200 pixel pairs destroyed in one tick: '+bursts+' sparkle bursts (cap 20 per tick) x4 bits = '+added+' bits (pool max '+P.VPMAX+'); all bits faded out after '+t+' ticks ('+f1(t/60)+' s)'};});
T('t1116 HEAD-ON + RICOCHET VISIBLE: both streams fill the lane, bounce, push (physics)',()=>{fresh2(45);P.placeCircle(0,180,456);for(const k of[[180,400],[180,330],[180,260],[180,190],[180,120]])P.pathExtend(0,k[0],k[1]);P.S.sides[1].human=true;P.S.sides[1].strokes=[];P.placeCircle(1,180,44);for(const k of[[180,100],[180,170],[180,240],[180,310],[180,380]])P.pathExtend(1,k[0],k[1]);
  const m=P.S.sides[0],e=P.S.sides[1];e.human=true;m.set.release=8;e.set.release=8;m.set.speed=e.set.speed=6;m.set.cap=e.set.cap=4000;m.pool=e.pool=1e9;m.circle.hp=e.circle.hp=1e9;P.startBattle();
  const hw=P.laneHW(m.set);const dx0=[],dx1=[],fr0=[],fr1=[];let rico0=P.VFX.bounces,tr0=P.VFX.trails;
  for(let t=0;t<2100;t++){P.tick();if(t>=1500&&t%25===0){for(let i=0;i<2*POOL;i++){if(!P.pst[i]||P.py[i]<170||P.py[i]>330)continue;if(P.pst[i]===2)(i<POOL?dx0:dx1).push(P.px[i]-180);else(i<POOL?fr0:fr1).push(P.px[i]-180);}}}
  const st=a=>{const lo=pct(a,0.05),hi=pct(a,0.95),mean=a.reduce((s,v)=>s+v,0)/Math.max(1,a.length),pos=a.filter(v=>v>0).length/Math.max(1,a.length);return{lo,hi,mean,pos,n:a.length};};
  const s0=st(dx0),s1=st(dx1),f0=st(fr0.concat(fr1));const full=s=>s.n>200&&(s.hi-s.lo)>=1.3*hw&&Math.abs(s.mean)<=0.3*hw&&s.pos>0.3&&s.pos<0.7;
  return{pass:full(s0)&&full(s1)&&f0.n>100&&f0.pos>0.35&&f0.pos<0.65&&P.VFX.bounces-rico0>50&&P.VFX.trails-tr0>50,msg:'lane half-width '+f1(hw)+'; contact-zone lateral fill of path followers (5%..95%) mine '+f1(s0.lo)+'..'+f1(s0.hi)+' (mean '+f1(s0.mean)+', '+Math.round(100*s0.pos)+'% right of the line), foe '+f1(s1.lo)+'..'+f1(s1.hi)+' (mean '+f1(s1.mean)+', '+Math.round(100*s1.pos)+'% right); ricocheted (free) pixels '+Math.round(100*f0.pos)+'% right of the line ('+f0.n+', spread '+f1(f0.lo)+'..'+f1(f0.hi)+'); ricochets '+(P.VFX.bounces-rico0)+', bounce trail bits '+(P.VFX.trails-tr0)};});
T('t1124 LANE WIDTH slider: smaller min and bigger max than before',()=>{const old=w=>(30-7*2.5)*1.25*0+w;const oldMin=(30-10*2.5)*(1.25-0.05*10),oldMax=(30-1*2.5)*(1.25-0.05*1);const mn=P.laneHW({width:1}),mx=P.laneHW({width:10}),mid=P.laneHW({width:5});
  return{pass:mn<oldMin&&mx>oldMax*1.15&&mid>8&&mid<16,msg:'lane half-width slider 1..10 = '+f1(mn)+' .. '+f1(mx)+' units (0.4.1 was '+f1(oldMin)+' .. '+f1(oldMax)+'); default '+f1(mid)};});
T('t1116 LIVE SLIDERS: lane width, density and spacing change the stream while it runs',()=>{const meas=()=>{const sd=P.S.sides[0],p=sd.paths[0].p;const lat=[],nn=[];const ids=[];for(let i=0;i<POOL;i++)if(P.pst[i]===2&&P.pid[i]===0&&P.pps[i]>3)ids.push(i);
    for(const i of ids){let bd=1e9;for(let k=0;k<p.length;k+=2){const d=Math.hypot(P.px[i]-p[k],P.py[i]-p[k+1]);if(d<bd)bd=d;}lat.push(bd);}
    let near=0;for(let a=0;a<ids.length;a+=3){const i=ids[a];for(const j of ids)if(j!==i&&Math.abs(P.px[i]-P.px[j])<4&&Math.abs(P.py[i]-P.py[j])<4)near++;}
    return{lat:lat.reduce((s,v)=>s+v,0)/Math.max(1,lat.length),near:near/Math.max(1,Math.ceil(ids.length/3)),n:ids.length};};
  const trial=(key,v)=>{const sd=bat2(46,{});sd.set.release=6;run(200);P.setPathSetting(0,0,key,v);run(260);return meas();};
  const w2=trial('width',2),w9=trial('width',9),d1=trial('density',1),d10=trial('density',10),s1=trial('spacing',1),s10=trial('spacing',10);
  return{pass:w9.lat>w2.lat*1.5&&d1.lat>d10.lat*1.1&&s10.near<s1.near*0.95&&s10.lat>s1.lat*1.1,msg:'mean distance from the line: WIDTH 2 '+f1(w2.lat)+' vs 9 '+f1(w9.lat)+'; DENSITY 1 '+f1(d1.lat)+' vs 10 '+f1(d10.lat)+'; SPACING 1 '+f1(s1.lat)+' vs 10 '+f1(s10.lat)+' and neighbours within 4u '+f1(s1.near)+' vs '+f1(s10.near)};});
T('t1122 BRANCH only in the match, each with its OWN colour and OWN meter',()=>{fresh2(47);P.placeCircle(0,180,456);for(const k of[[180,400],[184,330],[196,260]])P.pathExtend(0,k[0],k[1]);const sd=P.S.sides[0];const prep=P.canBr(sd);const rawPrep=P.branchBegin.orig?P.branchBegin.orig(0,184,380):P.branchBegin(0,184,380);
  P.startBattle();const inB=P.canBr(sd);const b1=P.branchBegin(0,184,380),b1b=b1&&P.branchExtend(0,b1,100,330);if(b1)P.branchEnd(0,b1);const b2=P.branchBegin(0,196,260);if(b2){P.branchExtend(0,b2,300,200);P.branchEnd(0,b2);}
  const c1=b1&&P.brCol(b1.id),c2=b2&&P.brCol(b2.id);const u1=b1?P.brUsed(b1):0,u2=b2?P.brUsed(b2):0;
  return{pass:!prep&&rawPrep===null&&inB&&!!b1&&!!b2&&c1&&c2&&c1!==c2&&u1>20&&u2>20&&u1!==u2,msg:'branches in prep: '+(prep?'ALLOWED':'refused')+', in the match: '+(inB?'allowed':'REFUSED')+'; branch 1 colour '+c1+' meter '+Math.round(u1)+'u, branch 2 colour '+c2+' meter '+Math.round(u2)+'u (separate)'};});
T('t1122 PER-PATH SLIDERS: tap a path to pick it; its sliders change only that path',()=>{const sd=bat2(48,{});const b=P.branchBegin(0,180,330);P.branchExtend(0,b,40,300);P.branchEnd(0,b);P.ME=0;
  const bq={x:b.p[b.p.length-2],y:b.p[b.p.length-1]};const t1=P.selectAt(bq),sel1=P.selP;const t0=P.selectAt({x:180,y:200}),sel0=P.selP;P.selectAt(bq);
  const w0=sd.set.width,spc0=sd.set.spacing;P.setPathSetting(0,b.id,'width',9);P.setPathSetting(0,b.id,'density',2);P.setPathSetting(0,b.id,'spacing',8);const mainSame=sd.set.width===w0&&sd.set.spacing===spc0&&P.pset(sd,sd.paths[0]).width===w0;const brSet=P.pset(sd,b);
  P.setPathSetting(0,0,'width',3);const brKeeps=P.pset(sd,b).width===9&&sd.set.width===3;
  return{pass:t1&&sel1===b.id&&t0&&sel0===0&&mainSame&&brSet.width===9&&brSet.density===2&&brSet.spacing===8&&brKeeps,msg:'tap on the branch selects path '+sel1+', tap on the main path selects '+sel0+'; branch width/density/spacing = '+brSet.width+'/'+brSet.density+'/'+brSet.spacing+' while MAIN stays '+w0+'/'+spc0+'; later main width change to 3 leaves the branch at '+P.pset(sd,b).width};});
T('t1122 WALLS reach the screen edges and follow the finger smoothly',()=>{let r=[];const one=(sx,sy,tx,ty)=>{fresh2(49);P.placeCircle(0,180,456);const st=P.wallBegin(0,sx,sy);const n=P.wallExtend(0,st,tx,ty);P.wallEnd(0,st);const pts=st.pts;return{x:pts[pts.length-2],y:pts[pts.length-1],pts:pts,n:n};};
  const L=one(150,380,-60,380),R=one(200,400,430,400),B=one(100,420,100,560),Fo=one(60,380,120,416);
  let gap=0;for(let k=2;k<Fo.pts.length;k+=2)gap=Math.max(gap,Math.hypot(Fo.pts[k]-Fo.pts[k-2],Fo.pts[k+1]-Fo.pts[k-1]));let dev=0;for(let k=0;k<Fo.pts.length;k+=2){const t=((Fo.pts[k]-60)*60+(Fo.pts[k+1]-380)*36)/(60*60+36*36),qx=60+60*t,qy=380+36*t;dev=Math.max(dev,Math.hypot(Fo.pts[k]-qx,Fo.pts[k+1]-qy));}
  const eF=Math.hypot(Fo.x-120,Fo.y-416);
  return{pass:L.x<=0.5&&R.x>=359.5&&B.y>=499.5&&gap<=3.01&&dev<=1&&eF<=3.5,msg:'wall dragged past the left edge ends at x='+f1(L.x)+', right edge x='+f1(R.x)+', bottom y='+f1(B.y)+'; a 70u finger jump is filled with steps of at most '+f1(gap)+'u, stays within '+f1(dev)+'u of the finger line and ends '+f1(eF)+'u from the finger'};});
T('t1123 LEASH is 1.5x (108, was 72)',()=>{const sd=bat2(50,{});const p=sd.paths[0].p;const lash=P.CFG.leash;const ps0=456-330;put(0,180+100,330,0,0,2);P.pps[0]=ps0;P.pfade[0]=0;P.movePixels();const a=P.pfade[0]===0&&P.pst[0]!==0;put(1,180+115,330,0,0,2);P.pps[1]=ps0;P.pfade[1]=0;P.movePixels();const b=P.pfade[1]>0;
  return{pass:lash===108&&lash===1.5*72&&a&&b,msg:'leash '+lash+' = 1.5 x 72; a pixel 100u off the line is fine (no fade), one at 115u starts fading'};});
T('t1123 FADE is gradual and a fading pixel can still collide (less and less)',()=>{const FT=P.FADE_T();bat2(51,{missP:0,ricoP:0,ricoMode:0});P.S.sides[1].active=1;
  const trialAt=frac=>{let n=0,T=300;P.setRnd(lcg(7));for(let k=0;k<T;k++){const a=k,b=POOL+k,x=14+(k%20)*16,y=150+Math.floor(k/20)*14;put(a,x,y,0,0,3);put(b,x+1,y,0,0,3);P.pfade[a]=Math.max(1,Math.round(FT*frac));P.php[a]=2;P.php[b]=2;P.pcd[a]=0;P.pcd[b]=0;}
    P.S.sides[0].active=T;P.S.sides[1].active=T;P.collide();for(let k=0;k<T;k++){if(P.php[k]<2||P.pcd[k]>0)n++;}for(let k=0;k<T;k++){P.pfade[k]=0;P.recall(k);P.recall(POOL+k);}return n/T;};
  const f9=trialAt(0.9),f5=trialAt(0.5),f1_=trialAt(0.1);
  put(5,200,300,0,0,3);P.pfade[5]=FT;const seq=[];for(let k=0;k<FT+4;k++){if(P.pst[5]===0)break;seq.push(P.pfade[5]);P.movePixels();}
  let mono=true,steps=0;for(let k=1;k<seq.length;k++){if(seq[k]>seq[k-1])mono=false;if(seq[k]<seq[k-1])steps++;}
  return{pass:f9>f5&&f5>f1_&&f1_>0.01&&f9<0.99&&mono&&FT>=48&&steps>=FT*0.8,msg:'fade lasts '+FT+' ticks ('+f1(FT/60)+' s), one step at a time ('+steps+' steps, never goes back up); chance to still hit an enemy: '+Math.round(100*f9)+'% when 90% faded-in, '+Math.round(100*f5)+'% at 50%, '+Math.round(100*f1_)+'% at 10% (never zero until it is gone)'};});
T('t1125 EXIT SPREAD at the circle mouth is about the lane width',()=>{const ex=w=>{const sd=bat2(52,{});sd.set.width=w;sd.set.release=8;sd.acc=0;run(40);const a=[];const c=sd.circle;for(let i=0;i<POOL;i++)if(P.pst[i]&&P.pid[i]===0&&Math.hypot(P.px[i]-c.x,P.py[i]-c.y)<c.r+14||false){a.push(P.px[i]-180);}
    const q=P.laneHW(sd.set);return{hi:pct(a.map(Math.abs),0.95),n:a.length,hw:q};};
  const a3=ex(3),a5=ex(5);return{pass:a5.n>40&&a5.hi>=0.7*a5.hw&&a5.hi<=1.15*a5.hw&&a3.hi<a5.hi*0.8&&a3.hi>=0.6*a3.hw,msg:'width 5: lane half-width '+f1(a5.hw)+', 95th percentile sideways offset of pixels leaving the circle '+f1(a5.hi)+' ('+a5.n+' pixels); width 3: lane '+f1(a3.hw)+', exit '+f1(a3.hi)+' (follows the lane width)'};});
T('t1125 AFTER A RICOCHET the heading stays straight (no steering back) until fade or hit',()=>{const sd=bat2(53,{missP:0,ricoP:100,ricoMode:0});sd.set.speed=10;sd.set.release=1;for(let i=0;i<2*POOL;i++)if(P.pst[i])P.recall(i);P.setRnd(()=>0.5);
  put(0,180,300,0,-24,2);P.pps[0]=20;P.pid[0]=0;P.php[0]=2;put(POOL,181,299.5,-24,0,3);P.php[POOL]=2;sd.active=1;P.S.sides[1].active=1;P.collide();const free=P.pfree[0]===1&&P.pst[0]===3,bounced=P.pbnc[0]>0;
  P.recall(POOL);P.S.sides[1].active=0;const h0=Math.atan2(P.pvy[0],P.pvx[0]);let maxTurn=0,t=0,fadeAt=-1,off0=Math.abs(P.px[0]-180),offMax=0,sawFade=false;
  for(;t<1500&&P.pst[0]!==0;t++){P.movePixels();if(P.pst[0]===0)break;const h=Math.atan2(P.pvy[0],P.pvx[0]);let d=Math.abs(h-h0);if(d>Math.PI)d=2*Math.PI-d;maxTurn=Math.max(maxTurn,d);offMax=Math.max(offMax,Math.abs(P.px[0]-180));if(P.pfade[0]>0&&fadeAt<0){fadeAt=t;}}
  return{pass:free&&bounced&&maxTurn<0.02&&fadeAt>0&&P.pst[0]===0&&offMax>100,msg:'after the bounce the pixel is "free" ('+free+'), glows ('+bounced+'), keeps heading '+f1(h0)+' rad: biggest turn in '+t+' ticks = '+f1(maxTurn)+' rad although it ends up '+Math.round(offMax)+'u off the line; fade began at tick '+fadeAt+', gone at '+t};});
T('t1126 SANDBOX: place and draw for BOTH sides mid-run, live sliders for either, pause/step/reset, no win or lose',()=>{P.CFG=Object.assign(D0(),{duel:1,aiLevel:0});P.newGame(54,false);P.setRnd(lcg(54));const S0=P.S.sides[0],S1=P.S.sides[1];const isSbx=P.sbx(),ph0=P.S.phase;
  P.placeCircle(0,180,420);P.placeCircle(1,180,100);for(const k of[[180,370],[180,300],[180,230]])P.pathExtend(0,k[0],k[1]);for(const k of[[180,150],[180,220],[180,290]])P.pathExtend(1,k[0],k[1]);
  const adv=P.sandboxStep(120);const t1=P.S.tick;const live0=S0.active+S1.active;
  const mid={c0:P.placeCircle(0,120,440),c1:P.placeCircle(1,240,80)};const w0=P.wallBegin(0,60,360);if(w0){P.wallExtend(0,w0,160,360);P.wallEnd(0,w0);}const w1=P.wallBegin(1,200,140);if(w1){P.wallExtend(1,w1,300,140);P.wallEnd(1,w1);}
  for(const k of[[120,380],[120,320]])P.pathExtend(0,k[0],k[1]);for(const k of[[240,140],[240,200]])P.pathExtend(1,k[0],k[1]);const b0=P.branchBegin(0,120,380),b1=P.branchBegin(1,240,140);if(b0){P.branchExtend(0,b0,200,330);P.branchEnd(0,b0);}if(b1){P.branchExtend(1,b1,300,200);P.branchEnd(1,b1);}
  const s0=P.setSetting(0,'width',9),s1=P.setSetting(1,'density',2);const pr0=S0.set.width===9&&S1.set.density===2;
  S0.set.release=10;S1.set.release=10;S0.set.cap=4000;S1.set.cap=4000;CFGburn();function CFGburn(){P.CFG.burn=200;}
  P.sandboxStep(600);const t2=P.S.tick;const refill=P.sandboxRefill();const act=S0.active+S1.active;
  return{pass:isSbx&&ph0==='battle'&&adv===120&&t1===120&&!!w0&&!!w1&&!!b0&&!!b1&&pr0&&P.S.over===false&&t2===720&&refill&&act===0,msg:'sandbox on='+isSbx+', starts in the match phase ('+ph0+'); mid-run I placed circles for both sides, drew '+(S0.strokes.length+S1.strokes.length)+' walls and a branch for each side, set sliders on both sides ('+pr0+'); stepped 120+600 ticks (tick '+t2+'), nobody won ('+!P.S.over+'), REFILL cleared the field ('+act+' pixels left)'};});
return JSON.stringify(R);
};
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
 const R=JSON.parse(await pg.evaluate(code));
 // UI checks (real clicks)
 const ui=[];const U=(n,c,m)=>ui.push({name:n,pass:!!c,msg:m});
 try{
  const hid=await pg.evaluate(()=>{__pw.showView('menu');const e=document.getElementById('mForms');return{forms:e?getComputedStyle(e).display:'none',sb:!!document.getElementById('mSandbox')&&document.getElementById('mSandbox').offsetParent!==null,row:(document.getElementById('clist').textContent.match(/HIDDEN FOR NOW/g)||[]).length};});
  U('t1122 SHAPES HIDDEN in the menus: no SHAPE EDITOR button, SANDBOX button present',hid.forms==='none'&&hid.sb,'SHAPE EDITOR display='+hid.forms+', SANDBOX button='+hid.sb);
  // with the Custom flag ON the editor comes back and still works with a finger
  await pg.evaluate(()=>{localStorage.removeItem('pixelwar.v43.forms');__pw.PRESETS=[];__pw.CUS.shapesOn=1;__pw.showView('menu');});
  const back=await pg.evaluate(()=>getComputedStyle(document.getElementById('mForms')).display);
  await pg.click('#mForms');await new Promise(r=>setTimeout(r,300));
  const box=await pg.evaluate(()=>{const r=document.getElementById('edc').getBoundingClientRect();return{x:r.left,y:r.top,w:r.width,h:r.height};});
  const X=(u)=>box.x+box.w*u,Y=(v)=>box.y+box.h*v;const tr=[[0.5,0.05],[0.62,0.2],[0.78,0.4],[0.86,0.7],[0.7,0.92],[0.5,0.82],[0.3,0.92],[0.14,0.7],[0.22,0.4],[0.38,0.2],[0.5,0.05]];
  await pg.mouse.move(X(tr[0][0]),Y(tr[0][1]));await pg.mouse.down();for(let k=1;k<tr.length;k++)await pg.mouse.move(X(tr[k][0]),Y(tr[k][1]),{steps:5});await pg.mouse.up();
  const np=await pg.evaluate(()=>__pw.ED.poly?__pw.ED.poly.length:0);await pg.click('#edSave');await new Promise(r=>setTimeout(r,200));
  const saved=await pg.evaluate(()=>JSON.parse(localStorage.getItem('pixelwar.v43.forms')||'[]'));
  U('EDITOR (kept, behind the Custom flag): draw an outline with a finger, SAVE writes a polygon preset',back!=='none'&&np>=4&&np<=24&&saved.length===1&&!!saved[0].poly,'flag ON shows the button ('+back+'); drawn shape simplified to '+np+' points, '+saved.length+' preset saved');
  await pg.screenshot({path:OUT+'ed-view.png'});
  await pg.evaluate(()=>{__pw.CUS.shapesOn=0;__pw.showView('menu');});
  const pg2=await b.newPage();await pg2.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});pg2._errs=[];pg2.on('pageerror',e=>pg2._errs.push(String(e)));await pg2.goto(require('./lib.cjs').FILE);await new Promise(r=>setTimeout(r,600));
  const hudIds=await pg2.evaluate(()=>{const o={};for(const id of['sSp','sDe','sSpc','sWd','sRe']){const e=document.getElementById(id);o[id]=e?[e.min,e.max]:null;}o.pm=document.querySelectorAll('.pm').length;o.legacyHidden=getComputedStyle(document.getElementById('legacy')).display==='none';return o;});
  U('t1116 HUD sliders: PACE, DENSITY, SPACING, LANE WIDTH, FLOW with big - / + buttons; the old shape controls are hidden',['sSp','sDe','sSpc','sWd','sRe'].every(k=>hudIds[k])&&hudIds.pm>=10&&hudIds.legacyHidden,JSON.stringify(hudIds));
  await pg2.evaluate(()=>__pw.showView('menu'));await pg2.click('#mStages');await new Promise(r=>setTimeout(r,200));
  const nst=await pg2.evaluate(()=>document.querySelectorAll('#stlist .stg').length);await pg2.click('#st2');await new Promise(r=>setTimeout(r,200));
  const st2=await pg2.evaluate(()=>({stage:__pw.CFG.stage,ai:__pw.CFG.aiLevel}));
  U('STAGES menu: 5 entries, stage 2 starts with NORMAL AI',nst===5&&st2.stage===2&&st2.ai===2,nst+' entries; stage '+st2.stage+', AI level '+st2.ai);
  await pg2.evaluate(()=>{__pw.CFG.burn=1;__pw.startStage(0);__pw.S.sides[1].human=false;__pw.aiPlan(0);__pw.startBattle();for(let i=0;i<1500;i++)__pw.tick();__pw.endMatch(0);});await new Promise(r=>setTimeout(r,500));
  const rv=await pg2.evaluate(()=>({txt:document.getElementById('rBody').textContent.slice(0,120),btn:document.getElementById('btnRev').textContent,vis:document.getElementById('result').style.display}));
  U('RESULT: AI REVIEW is shown at the end, STATS one tap away',/AI REVIEW/.test(rv.txt)&&rv.btn==='STATS'&&rv.vis==='block','shows "'+rv.txt.slice(0,70)+'", button says '+rv.btn);
  await pg2.screenshot({path:OUT+'result-review.png'});await pg2.click('#btnRev');await new Promise(r=>setTimeout(r,300));
  const st=await pg2.evaluate(()=>document.getElementById('rBody').textContent.slice(0,90));await pg2.screenshot({path:OUT+'result-stats.png'});
  U('RESULT: stats pane has the full table',/Time/.test(st)&&/destroyed/.test(st),'"'+st+'"');
  const e2=(pg2._errs||[]);U('page errors',pg._errs.length+e2.length===0,JSON.stringify(pg._errs.concat(e2)).slice(0,200));
 }catch(e){U('UI part',false,'EXCEPTION '+e.message);}
 let out='',n=0,fail=0;for(const r of R.concat(ui)){n++;if(!r.pass)fail++;out+=n+'. '+r.name+': '+(r.pass?'PASS':'FAIL')+' - '+r.msg+'\n';}
 out+='\nSOFT042 '+(n-fail)+' pass / '+fail+' fail\n';console.log(out);fs.writeFileSync(OUT+'soft043.txt',out);await b.close();process.exit(fail?1:0);})();
