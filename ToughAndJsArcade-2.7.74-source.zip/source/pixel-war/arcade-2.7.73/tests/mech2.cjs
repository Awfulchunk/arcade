// 0.2 feature tests: branches, shapes/squads, thinning, AI (same meters, no peeking, learning, wipe), Custom Game, modes
const {launch,open}=require('./lib.cjs');
const code=function(){
const P=window.__pw,R=[],SHAPES=P.C.SHAPES;{const _bb=P.branchBegin;P.branchBegin=(s,x,y)=>{if(P.S.phase==='prep')P.startBattle();return _bb(s,x,y);};}
const ok=(name,cond,info)=>R.push({name,pass:!!cond,info:info===undefined?'':String(info)});
const CAP=P.C.CAPMAX;
const lcg=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
function fresh(seed,cfg){P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:90},cfg||{});P.newGame(seed||1,false);P.setRnd(lcg(seed||1));}
const PTS=[[180,456],[184,380],[196,300],[200,220],[196,140]];
function mainPath(side){for(let i=1;i<PTS.length;i++)P.pathExtend(side||0,PTS[i][0],PTS[i][1]);}
function quiet(){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;for(let i=CAP;i<2*CAP;i++)if(P.pst[i])P.recall(i);f.acc=0;}
function setup(seed,cfg,shape){fresh(seed,cfg);P.placeCircle(0,180,456);mainPath();if(shape)shape();}
function run(n){for(let i=0;i<n;i++)P.tick();}
function count(side,f){let c=0;for(let i=side*CAP;i<side*CAP+CAP;i++)if(P.pst[i]&&(!f||f(i)))c++;return c;}
// ================= branches
{setup(1);const sd=P.S.sides[0];
 ok('branch refused when not started on the main path',P.branchBegin(0,60,300)===null);
 const b1=P.branchBegin(0,184,380);ok('branch starts on the main path (forks from a path sample)',!!b1&&b1.par===0&&b1.fk>0&&P.S.sides[0].paths[1]===b1);
 P.branchExtend(0,b1,60,300);P.branchEnd(0,b1);const u1=P.brUsed(b1);
 ok('branch has its OWN meter (<= brMax) separate from the main path meter',u1>40&&u1<=P.CFG.brMax+1e-6&&P.pathUsed(sd)<=P.CFG.pathMax,[u1,P.pathUsed(sd)]);
 P.branchExtend(0,b1,0,0);ok('branch meter caps total length',P.brUsed(b1)<=P.CFG.brMax+1e-6&&P.brUsed(b1)>=P.CFG.brMax-4.5,P.brUsed(b1));
 const b2=P.branchBegin(0,196,300),b3=P.branchBegin(0,200,220),b4=P.branchBegin(0,196,140);
 ok('maxBr (3) respected: 3 branches ok, 4th refused',!!b2&&!!b3&&b4===null&&P.brCount(sd)===3,P.brCount(sd));
 P.branchExtend(0,b2,320,300);P.branchEnd(0,b2);const full=P.pathUsed(sd);
 ok('each branch meter independent: drawing one does not spend the others',P.brUsed(b2)>20&&P.pathUsed(sd)===full&&P.brUsed(b1)>=P.CFG.brMax-4.5);
 P.branchEnd(0,b3);ok('a branch with no length is discarded',P.S.sides[0].paths[3]===null||P.brCount(sd)<3,P.brCount(sd));
 const n0=P.brCount(sd);P.eraseAt(0,b1.p[2*5],b1.p[2*5+1]);ok('erase trims a branch (frees its meter)',P.brUsed(b1)<P.CFG.brMax-4.5||P.S.sides[0].paths[1]===null,P.brUsed(b1));
 P.eraseAt(0,b2.p[2],b2.p[3]);ok('erase near the fork removes the whole branch and frees the slot',P.brCount(sd)<n0,P.brCount(sd));}
{setup(2);const st=P.wallBegin(0,130,350);P.wallExtend(0,st,240,350);P.wallEnd(0,st);
 const b=P.branchBegin(0,184,380);const n=P.branchExtend(0,b,170,290);const ly=b.p[b.p.length-1];
 ok('a branch must go AROUND a defensive line, never over or through it (stopped at y='+ly.toFixed(0)+' below the wall at y=350)',n>3&&ly>=350&&P.brUsed(b)<P.CFG.brMax,[n,ly]);}
{setup(3);const b=P.branchBegin(0,196,300);P.branchExtend(0,b,320,260);P.branchEnd(0,b);b.share=100;P.S.sides[0].paths[0].sh.t=0;P.startBattle();quiet();run(500);
 let onB=count(0,i=>P.pid[i]===1),tot=count(0);ok('share 100%: pixels passing the fork take the branch ('+onB+'/'+tot+')',onB>tot*0.35,[onB,tot]);}
{setup(4);const b=P.branchBegin(0,196,300);P.branchExtend(0,b,320,260);P.branchEnd(0,b);b.share=0;P.startBattle();quiet();run(500);
 ok('share 0%: nobody takes the branch',count(0,i=>P.pid[i]===1)===0);}
{setup(5);const b=P.branchBegin(0,196,300);P.branchExtend(0,b,320,260);P.branchEnd(0,b);b.share=40;P.startBattle();quiet();let ob=0,om=0;for(let t=0;t<300;t++){run(1);}
 const sd=P.S.sides[0];ob=count(0,i=>P.pid[i]===1);const dec=count(0,i=>(P.pid[i]===1)||P.pps[i]>b.fk*4);
 ok('share 40%: roughly 40% of pixels past the fork are on the branch ('+ob+' of '+dec+')',dec>100&&ob/dec>0.2&&ob/dec<0.65,[ob,dec]);}
{setup(6,{liveBr:1});P.startBattle();quiet();const b=P.branchBegin(0,196,300);ok('liveBr ON: branches can be drawn during battle',!!b);
 const used=P.pathUsed(P.S.sides[0]);P.pathExtend(0,300,100);ok('main path stays LOCKED after prep',P.pathUsed(P.S.sides[0])===used);
 const w=P.wallBegin(0,100,400);ok('liveWall ON: walls can be built during battle (and become live segments)',!!w);if(w){P.wallExtend(0,w,150,400);P.wallEnd(0,w);ok('...and are collidable segments right away',P.S.sides[0].segs.length>=1&&P.S.sides[0].strokes[0].segs.length>=1);}}
{setup(7,{liveBr:0,liveWall:0});P.startBattle();quiet();ok('liveBr OFF: branch refused in battle',P.branchBegin(0,196,300)===null);ok('liveWall OFF: wall refused in battle',P.wallBegin(0,100,400)===null);}
{setup(8);const b=P.branchBegin(0,196,300);P.branchExtend(0,b,320,260);P.branchEnd(0,b);b.share=100;P.startBattle();quiet();run(400);const had=count(0,i=>P.pid[i]===1);P.removeBranch(P.S.sides[0],1);
 let stale=0;for(let i=0;i<CAP;i++)if(P.pst[i]&&P.pid[i]===1)stale++;ok('deleting a branch recalls its pixels (no stale paths): had '+had,had>0&&stale===0&&P.S.sides[0].active===count(0),[had,stale]);}
// branch end / convergence modes
function convTest(mode,seed){setup(seed,{converge:mode});const sd=P.S.sides[0],M=sd.paths[0];
  const b=P.branchBegin(0,184,380);P.branchExtend(0,b,150,340);P.branchExtend(0,b,196,300);P.branchExtend(0,b,200,262);P.branchEnd(0,b);b.share=100;P.startBattle();quiet();run(520);return{b:b,rj:b.rj,onMain:count(0,i=>P.pid[i]===0&&P.pcap[i]!==undefined&&P.pst[i]===2),end:count(0,i=>P.pid[i]===1&&P.pst[i]===3),onB:count(0,i=>P.pid[i]===1)};}
{const a=convTest(0,9),m=convTest(1,9);ok('branch end: SEPARATE -> pixels drift on from the branch end ('+a.end+' in end state, rejoin index '+a.rj+')',a.rj>=0&&a.end>5,a);
 ok('branch end: MERGE -> pixels hop back to the main path',m.rj>=0&&m.end<a.end,[m.end,a.end]);
 const r=convTest(2,9);ok('branch end: REFORM mode runs clean',r.rj>=0);}
{ // speed slider: slow = wide/dense, fast = thin/packed (lane half width + stream density per length)
  ok('WIDTH slider scales the lane',P.laneHW({width:8})>P.laneHW({width:3}));
  const dens=(sp)=>{setup(18);P.S.sides[0].set.speed=sp;P.startBattle();quiet();run(500);const c=count(0,i=>P.pst[i]===2);return c;};
  const slow=dens(1),fast=dens(10);ok('SPEED slow = denser stream on the field ('+slow+' vs '+fast+' pixels) and speed never changes release/hp',slow>fast&&P.rateOf({release:5})===P.rateOf({release:5}),[slow,fast]);}
// ================= AI
{let bad=[],lv1=0,withBr=0,withShape=0;
 for(let s=1;s<=160;s++){const lv=1+(s%4);fresh(s,{aiLevel:lv});const sd=P.S.sides[1];P.aiPlan(1);if(lv>=2){P.startBattle();sd.aiBr=1;P.aiOpenBranch(1);}
  if(P.pathUsed(sd)>P.CFG.pathMax+1e-6)bad.push('path'+s);if(P.wallUsed(sd)>P.CFG.wallMax+1e-6)bad.push('wall'+s);if(sd.strokes.length>12)bad.push('strk'+s);
  if(P.brCount(sd)>P.CFG.maxBr)bad.push('nbr'+s);for(let k=1;k<sd.paths.length;k++){const b=sd.paths[k];if(!b)continue;if(P.brUsed(b)>P.CFG.brMax+1e-6)bad.push('brm'+s);withBr++;withShape++;if(b.share<0||b.share>100)bad.push('shr'+s);}
  const M=sd.paths[0];if(M.sh.pull>100||M.sh.t<0||M.sh.t>6)bad.push('sh'+s);
  if(lv===1){if(P.brCount(sd)>0)lv1++;}
  const q=sd.circle;if(q.y>P.CFG.zoneH+40)bad.push('circle'+s);
  for(const st of sd.strokes)for(let k=0;k<st.pts.length;k+=2)if(st.pts[k+1]>250)bad.push('wz'+s);}
 ok('AI plans (160 seeds, levels 1-4) with the SAME meters/limits as the player: path, branch, wall, count, zones ('+withBr+' branches)',bad.length===0,bad.slice(0,5).join(','));
 ok('AI level EASY uses no branches or shapes (intelligence tiers, never extra stats)',lv1===0,lv1);ok('AI higher levels do use branches and shapes',withBr>20&&withShape>5,[withBr,withShape]);}
{fresh(21,{aiLevel:3});P.newGame(21,false);P.CFG=Object.assign({},{...P.C.DEFCFG,shapesOn:1,paceMax:90});const a=(()=>{P.newGame(21,false);P.setRnd(lcg(5));P.aiPlan(1);const s=P.S.sides[1];return JSON.stringify([s.paths[0].p,s.strokes.map(x=>x.pts),s.paths.map(x=>x&&x.sh)]);})();
 const b=(()=>{P.newGame(21,false);P.pathExtend(0,200,100);const w=P.wallBegin(0,100,400);P.wallExtend(0,w,180,400);P.wallEnd(0,w);P.setShape(0,0,3);P.setRnd(lcg(5));P.aiPlan(1);const s=P.S.sides[1];return JSON.stringify([s.paths[0].p,s.strokes.map(x=>x.pts),s.paths.map(x=>x&&x.sh)]);})();
 ok('AI plan does not depend on the player path/branches/walls/shape (sees only the circle)',a===b);}
{fresh(22,{aiLevel:4});P.aiPlan(0);P.startBattle();const s0=P.S.sides[0];let reads=0;
 for(const k of['paths','set','sq','locked']){const v=s0[k];Object.defineProperty(s0,k,{get(){reads++;return v;},configurable:true});}
 reads=0;P.S.ai={lessons:[],adapts:0,last:0,best:0};P.aiAdapt(1);P.aiAdapt(1);P.aiPlan(1);
 ok('AI adapt/plan never reads the player hidden plan (paths, sliders, formations): reads='+reads,reads===0,reads);}
function aiMatch(seed,cfg,ticks){fresh(seed,Object.assign({aiLevel:3,burn:1},cfg||{}));P.aiPlan(0);P.startBattle();const o={snap:null};const s1=P.S.sides[1];o.shapes0=JSON.stringify(s1.paths.map(p=>p&&p.sh.t));o.br0=P.brCount(s1);o.w0=s1.strokes.length;
 for(let t=0;t<ticks&&!P.S.over;t++){P.tick();if(t===ticks-1||P.S.over)break;}return o;}
{const o=aiMatch(23,{},1800);const ai=P.S.ai,s1=P.S.sides[1];
 ok('AI learns DURING the match: adapts '+(ai&&ai.adapts)+'x, '+(ai&&ai.lessons.length)+' lessons',ai&&ai.adapts>=3&&ai.lessons.length>=1,ai&&ai.lessons.join(' | '));
 const ch=JSON.stringify(s1.paths.map(p=>p&&p.sh.t))!==o.shapes0||P.brCount(s1)!==o.br0||s1.strokes.length!==o.w0;ok('AI adapted its setup mid-match (shapes/branches/walls changed from the opening plan)',ch,[o.shapes0,o.br0,o.w0,JSON.stringify(s1.paths.map(p=>p&&p.sh.t)),P.brCount(s1),s1.strokes.length]);
 ok('AI adaptations stayed inside the same meters',P.pathUsed(s1)<=P.CFG.pathMax+1e-6&&P.wallUsed(s1)<=P.CFG.wallMax+1e-6&&P.brCount(s1)<=P.CFG.maxBr&&s1.paths.every((b,i)=>!b||i===0||P.brUsed(b)<=P.CFG.brMax+1e-6));
 for(let t=0;t<9000&&!P.S.over;t++)P.tick();const sum=P.S.aiSummary;
 ok('memory wiped at match end: live memory null, a summary kept only for the result screen',P.S.over&&P.S.ai===null&&sum&&sum.lessons.length>=1,[P.S.over,sum&&sum.lessons.length]);
 P.restart();ok('new match starts fresh: no memory, no summary, zeroed stats',P.S.ai===null&&P.S.aiSummary===null&&P.S.sides[1].stats.shapeKill.every(v=>v===0)&&P.S.sides[1].lossGrid.every(v=>v===0));}
{const o=aiMatch(24,{aiLearn:0},1800);ok('aiLearn OFF: no memory, no mid-match adaptation',P.S.ai===null&&P.S.sides[1].strokes.length===o.w0);}
{const o=aiMatch(25,{aiLevel:1},1800);ok('AI EASY: no learning',P.S.ai===null);}
// ================= Custom Game / rules
{P.startWith({poolSize:5000,pixHP:3,segHP:900,matchSec:45,circleR:30,pixDmg:2});const S=P.S;
 ok('Custom values apply: pool size, radius, match time',S.sides[0].circle.hp===5000&&S.sides[1].pool===5000&&S.sides[0].circle.r===30&&P.CFG.matchSec===45);
 P.aiPlan(0);P.startBattle();P.release(0);let i0=-1;for(let i=0;i<CAP;i++)if(P.pst[i]){i0=i;break;}ok('Custom pixel HP applies to released pixels',P.php[i0]===3,P.php[i0]);
 ok('Custom segment HP applies to walls',S.sides[0].segs.length>0&&S.sides[0].segs.every(g=>g.hp>=1&&g.hp<=P.cellHP())&&Math.max(...S.sides[0].segs.map(g=>g.hp))>=0.7*P.cellHP()&&P.cellHP()===Math.round(900*P.CFG.wcell/P.CFG.wsp));
 P.S.tick=45*60-1;P.tick();ok('Custom time limit ends the match',P.S.over);}
{const keys=Object.keys({...P.C.DEFCFG,shapesOn:1,paceMax:90}),rows=P.CUSTOM.map(r=>r[0]);const missing=keys.filter(k=>!rows.includes(k));ok('every tunable constant is exposed in Custom Game (missing: '+missing.join(',')+')',missing.length===0,missing);
 const opts=['ricoMode','converge','orient','bias','autoDist','knockK','pattern','duel','momentum','aiLevel','aiLearn','liveBr','liveWall','prepSec','zoneH','halo','reveal','maxBr'];ok('every unpicked questionnaire option has a Custom row',opts.every(k=>rows.includes(k)),opts.filter(k=>!rows.includes(k)));}
{localStorage.setItem('pixelwar.v3.custom',JSON.stringify({poolSize:1e99,burn:-4,lives:1e9,pixHP:-4,maxBr:'x',aiLevel:99,halo:7,wallMax:null}));
 ok('corrupt custom save never throws (clamped on use)',(()=>{try{P.buildCustom();return true;}catch(e){return false;}})());localStorage.removeItem('pixelwar.v3.custom');}
{const rate=(mode,glance)=>{P.startWith({ricoMode:mode,missP:20,ricoP:35});P.aiPlan(0);P.startBattle();for(let i=0;i<2*CAP;i++)if(P.pst[i])P.recall(i);P.S.sides[0].set.cap=250;let rc=0,N=1500;
  for(let n=0;n<N;n++){P.recall;const A=0,B=CAP;for(const[i,sd]of[[A,0],[B,1]]){P.px[i]=100;P.py[i]=200;P.php[i]=2;P.pst[i]=3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;}
   P.px[B]=101.5;P.py[B]=200;if(glance){P.pvx[A]=60;P.pvy[A]=0;P.pvx[B]=60;P.pvy[B]=5;}else{P.pvx[A]=60;P.pvy[A]=0;P.pvx[B]=-60;P.pvy[B]=0;}
   const s0=P.S.sides[0].stats.ricochets;P.S.sides[0].active=1;P.S.sides[1].active=1;P.collide();if(P.S.sides[0].stats.ricochets>s0)rc++;P.pst[A]=0;P.pst[B]=0;}
  return rc/N;};
 const r0=rate(0,false),h=rate(1,false),g=rate(1,true),hy=rate(2,false);
 ok('ricochet rules: RANDOM ~55% (miss 20 + 35 of the rest) ('+r0.toFixed(2)+'); ANGLE head-on rare ('+h.toFixed(2)+') vs glancing common ('+g.toFixed(2)+'); HYBRID in between ('+hy.toFixed(2)+')',r0>0.4&&r0<0.7&&h<g&&hy>h*0.9&&hy<g*1.1+0.15,[r0,h,g,hy]);}
{const spd=(m)=>{fresh(4,{momentum:m});P.aiPlan(0);P.startBattle();quiet();run(500);let s=0,n=0;for(let i=0;i<CAP;i++)if(P.pst[i]===2){s+=Math.hypot(P.pvx[i],P.pvy[i]);n++;}return s/Math.max(1,n);};
 const a=spd(1),b=spd(0);ok('formation momentum ON: unhit pixels move faster ('+a.toFixed(0)+' vs '+b.toFixed(0)+' u/s)',a>b*1.08,[a,b]);}
{const cnt=(pat)=>{P.startWith({pattern:pat});P.aiPlan(0);P.startBattle();quiet();P.S.sides[0].set.release=2;P.S.sides[0].set.cap=3000;const out=[];let prev=P.S.sides[0].stats.released;for(let t=0;t<360;t++){P.tick();if(t%15===14){out.push(P.S.sides[0].stats.released-prev);prev=P.S.sides[0].stats.released;}}return out;};
 const st=cnt(0),pu=cnt(1);const sp=a=>Math.max(...a)-Math.min(...a);ok('release pattern PULSE modulates waves, STEADY does not ('+sp(st)+' vs '+sp(pu)+' per half-second)',sp(pu)>sp(st)*3+20,[st.join(','),pu.join(',')]);}
{P.startWith({duel:1});const S=P.S;ok('hot-seat: both sides human, AI does not plan for side 2',S.sides[0].human&&S.sides[1].human);
 P.ME=1;P.placeCircle(1,120,50);P.pathExtend(1,130,150);ok('hot-seat: player 2 draws on the top strip with the same API',P.S.sides[1].paths[0].p.length>4&&P.S.sides[1].circle.x===120);P.ME=0;
 P.autoStart();ok('hot-seat start: no AI memory, battle runs',P.S.phase==='battle'&&P.S.ai===null);run(120);ok('hot-seat battle runs',P.S.sides[0].active>0&&P.S.sides[1].active>0);}
{P.startWith({maxBr:0});const b=P.branchBegin(0,184,380);ok('maxBr 0 disables branches',b===null);}
{P.startWith({autoDist:1});P.placeCircle(0,180,456);mainPath();const a=P.branchBegin(0,184,380),b=P.branchBegin(0,196,300);ok('auto-distribute: shares are split automatically and manual share is refused',a.share===b.share&&a.share>0&&P.setShare(0,1,90)===false,[a.share,b.share]);}
{P.startWith({wallMax:100,wsp:10});P.placeCircle(0,180,456);const st=P.wallBegin(0,20,380);P.wallExtend(0,st,340,380);P.wallEnd(0,st);ok('Custom wall meter/segment length apply',P.wallUsed(P.S.sides[0])<=100+1e-6&&P.wallUsed(P.S.sides[0])>=90,P.wallUsed(P.S.sides[0]));}
{P.startWith({zoneH:120});P.placeCircle(0,180,300);ok('Custom placement strip: circle may sit higher',P.S.sides[0].circle.y<=P.C.H-120-8+1&&P.S.sides[0].circle.y>300-1,P.S.sides[0].circle.y);}
{P.startWith({});P.showView('custom');const v1=P.view;P.showView('menu');P.showView('help');P.showView('app');ok('views: custom/menu/help/app switch cleanly',v1==='custom'&&P.view==='app');}
// ================= invariants soak: every mechanic on, both AIs, 2 matches
{let bad=0,tot=0;for(const seed of[31,32]){P.startWith({aiLevel:4,momentum:1,pattern:1,ricoMode:2,converge:2,knockK:24});P.newGame(seed,false);P.setRnd(lcg(seed));P.aiPlan(0);P.startBattle();
  for(let t=0;t<5000&&!P.S.over;t++){P.tick();if(t%50===0){tot++;for(let sd=0;sd<2;sd++){let c=0;const s=P.S.sides[sd];for(let i=sd*CAP;i<sd*CAP+CAP;i++)if(P.pst[i]){c++;if(!isFinite(P.px[i]+P.py[i]+P.pvx[i]+P.pvy[i])||P.php[i]<1||P.php[i]>2)bad++;if(P.pst[i]>=4&&(P.psq[i]<0||!s.sq[P.psq[i]]))bad++;if(!s.paths[P.pid[i]])bad++;}
   if(c!==s.active||c>CAP)bad++;for(const q of s.sq){if(!q)continue;let n=0;for(let i=sd*CAP;i<sd*CAP+CAP;i++)if(P.pst[i]>=4&&P.psq[i]===q.id)n++;if(n!==q.live)bad++;}}}}}
 ok('SOAK 2 matches, all options on (momentum, pulse, hybrid ricochet, area knock-out, Expert AI): invariants hold over '+tot+' samples',bad===0,bad);}
return R;};
(async()=>{const b=await launch();const pg=await open(b,360,800,2);
 const R=await pg.evaluate('('+code.toString()+')()');let p=0,f=0;for(const r of R){if(r.pass)p++;else f++;console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'  ['+r.info+']'));}
 console.log('errors',pg._errs);console.log('MECH2 '+p+' pass / '+f+' fail');await b.close();process.exit(f||pg._errs.length?1:0);})();
