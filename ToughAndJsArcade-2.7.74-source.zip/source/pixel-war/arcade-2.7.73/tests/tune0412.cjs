const {launch,open}=require('./lib.cjs');const {duelPair}=require('./duel0412.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});const out=[];
 const grid=JSON.parse(process.argv[2]);
 for(const [hK,dK,dg] of grid){const SZ_HP=[],SZ_DMG=[],SZ_DG=[];for(let s=1;s<=10;s++){SZ_HP.push(+(2*(1+hK*(s-5)/5)).toFixed(3));SZ_DMG.push(+(1*(1+dK*(s-5)/5)).toFixed(3));SZ_DG.push(s<5?+(dg*(5-s)/4).toFixed(3):0);}
  const tune={SZ_HP,SZ_DMG,SZ_DG};let worst=0;const rs=[];
  for(const [a,c] of [[1,10],[1,5],[5,10],[3,8]]){const r=await duelPair(pg,a,c,600,6,2400,[5,9],tune);rs.push([a,c,r.killShareA,r.frontA]);worst=Math.max(worst,Math.abs(r.killShareA-50),Math.abs(r.frontA-250)/2.5);}
  console.log('CFG',JSON.stringify({hK,dK,dg,worst:+worst.toFixed(1),rs,tune}));}
 await b.close();})();
