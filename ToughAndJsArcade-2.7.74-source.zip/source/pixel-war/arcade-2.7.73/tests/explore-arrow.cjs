const {launch,open}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,1,{});
const res=await pg.evaluate((cfgs)=>{const P=window.__pw;const out=[];
 const mk=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
 function run(seed,enemy,shape,extra){P.CFG=Object.assign({},P.C.DEFCFG,extra||{});P.newGame(seed,false);P.setRnd(mk(seed));
  P.placeCircle(0,180,456);for(const q of [[180,400],[180,300],[180,200],[180,140]])P.pathExtend(0,q[0],q[1]);
  P.placeCircle(1,300,50);const f=P.S.sides[1];f.paths[0].p=[300,50];
  const E=P.S.sides[1];for(const q of [[300,150],[300,250],[240,250],[180,250],[120,250],[60,250]])P.pathExtend(1,q[0],q[1]);
  const m=P.S.sides[0];m.set.release=5;m.set.density=7;m.set.speed=5;m.set.cap=10000;
  E.set.release=enemy.rel;E.set.density=enemy.den;E.set.speed=enemy.spd;E.set.cap=10000;
  m.human=true;E.human=true;P.startBattle();P.S.sides[0].circle.hp=1e9;P.S.sides[1].circle.hp=1e9;m.pool=1e9;E.pool=1e9;
  let crossed=0,minY=1e9,N=0,fired=false,peak=0,lost=0;const ids=new Set();
  for(let t=0;t<900;t++){if(t===200&&!fired){fired=P.useShape(0,0,shape);}
   P.tick();
   if(fired&&t>200){for(let i=0;i<P.POOL;i++)if(P.pst[i]===4&&P.psh[i]===shape){ids.add(i);if(P.py[i]<minY)minY=P.py[i];}}}
  let cross=0;for(const i of ids)if(P.py[i]<235)cross++;
  // pixels of the squad alive at end beyond line
  let alive=0,beyond=0;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){alive++;if(P.py[i]<235)beyond++;}
  return{seed,N:ids.size,everCrossed:cross,minY:Math.round(minY),aliveEnd:alive,beyondEnd:beyond,kills:[m.stats.kills,E.stats.kills],defl:[m.stats.defl,m.stats.ct],surv:m.stats.surv,pushed:[m.stats.pushed,E.stats.pushed]};}
 for(const [name,en,sh,ex] of cfgs){for(const s of [1,2,3])out.push([name,run(s,en,sh,ex)]);}
 return out;},
 [['mid5/5/5',{rel:5,den:5,spd:5},1,{}],['mid7/6/5',{rel:6,den:7,spd:5},1,{}],['loose4/3/7',{rel:4,den:3,spd:7},1,{}],['dense10/7/3',{rel:7,den:10,spd:3},1,{}],['dense10/10/5',{rel:10,den:10,spd:5},1,{}]]);
for(const r of res)console.log(r[0],JSON.stringify(r[1]));await b.close();})();
