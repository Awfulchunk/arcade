// 0.4.2 hits -> out/hits042/*.png (360x800 @2, 320x568 @2, zoom crops @3): HUD at both phone sizes, prep with both paths + walls, branch colours, per-path sliders, sparkle, ricochet bounce, head-on lane fill, walls to the edge, leash fade, sandbox, menus.
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar042/out/hits042/';fs.mkdirSync(OUT,{recursive:true});for(const f of fs.readdirSync(OUT))if(f.endsWith('.png'))fs.unlinkSync(OUT+f);
const HELP=`window.__H={mk(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};},
 game(seed,cfg){const P=__pw;P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed,false);P.setRnd(this.mk(seed));return P;},
 main(P,pts){for(const k of pts||[[180,400],[184,330],[190,260],[196,190],[196,130]])P.pathExtend(0,k[0],k[1]);},
 wall(P,x1,y,x2){const st=P.wallBegin(0,x1,y);P.wallExtend(0,st,x2,y);P.wallEnd(0,st);},
 headon(P){P.placeCircle(0,180,456);this.main(P);P.S.sides[1].human=true;P.S.sides[1].strokes=[];P.placeCircle(1,180,44);for(const k of[[180,100],[180,170],[180,240],[180,310],[180,380]])P.pathExtend(1,k[0],k[1]);const m=P.S.sides[0],e=P.S.sides[1];m.set.release=8;e.set.release=8;m.set.speed=e.set.speed=6;m.set.cap=e.set.cap=4000;m.pool=e.pool=1e9;m.circle.hp=e.circle.hp=1e9;P.startBattle();}};`;
(async()=>{const b=await launch();let pg;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const fresh=async(w,h)=>{pg=await open(b,w||360,h||800,2,{mobile:true});await pg.evaluate(HELP);};
 const snap=async(name,clip)=>{await sleep(200);const o={path:OUT+name+'.png'};if(clip)o.clip=clip;await pg.screenshot(o);};
 const L=()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const zoom=async(name,cx,cy,w,h)=>{const l=await L();await snap(name,{x:Math.max(0,l.x+(cx-w/2)*l.s),y:Math.max(0,l.y+(cy-h/2)*l.s),width:w*l.s,height:h*l.s,scale:3});};
 const run=(f,a)=>pg.evaluate(f,a);
 for(const [w,h] of [[360,800],[320,568]]){
  // prep: AI is drawing (mid-reveal), then prep ready with both paths + walls
  await fresh(w,h);await run(()=>{__tt.setSeed(11);});await sleep(1200);await snap('01-'+w+'-hud-prep-ai-drawing');
  await sleep(2600);await run(()=>{const P=__pw;__H.main(P);__H.wall(P,10,330,150);__H.wall(P,220,330,350);P.S.aiRev=1;});await snap('02-'+w+'-hud-prep-both-paths-and-walls');
  // battle with 2 branches (own colours + meters), branch 1 picked -> its sliders
  await run(()=>{const P=__pw;P.tryStart();for(let i=0;i<700;i++)P.tick();const b1=P.branchBegin(0,184,330);if(b1){P.branchExtend(0,b1,70,300);P.branchEnd(0,b1);}const b2=P.branchBegin(0,196,190);if(b2){P.branchExtend(0,b2,310,160);P.branchEnd(0,b2);}P.selP=1;P.setPathSetting(0,1,'width',8);P.setPathSetting(0,1,'density',3);for(let i=0;i<500;i++)P.tick();});
  await snap('03-'+w+'-hud-battle-branches-slider-panel');
  await run(()=>{document.getElementById('sl').scrollTop=9999;});await snap('04-'+w+'-hud-battle-sliders-scrolled');
  await run(()=>{__pw.selP=0;});await snap('05-'+w+'-hud-battle-main-path-picked');
  await pg.close();}
 // field shots at 360x800
 // 10 head-on lane fill (full field) + zoom at the contact line
 await fresh();await run(()=>{const P=__H.game(45);__H.headon(P);for(let i=0;i<1700;i++)P.tick();P.S.paused=true;P.draw();});await snap('10-head-on-both-streams-fill-the-lane');
 await zoom('10b-head-on-zoom',180,250,70,90);await pg.close();
 // 11 ricochet bounce (glow + trail V): force ricochets so the bounce shows
 await fresh();await run(()=>{const P=__H.game(46,{missP:0,ricoP:100,ricoMode:0});__H.headon(P);let n=0;for(let i=0;i<1500&&n<3;i++){P.tick();if(P.VFX.bounces>40&&i>600)n++;}P.S.paused=true;P.draw();window.__bx=null;let sx=0,sy=0,c=0;for(let i=0;i<2*P.POOL;i++)if(P.pst[i]&&P.pbnc[i]>0){sx+=P.px[i];sy+=P.py[i];c++;}window.__bx=c?[sx/c,sy/c,c]:[180,250,0];});
 const bx=await run(()=>window.__bx);console.log('bounce glow pixels',bx[2]);await zoom('11-ricochet-bounce-glow-and-trail',bx[0],bx[1],70,70);await zoom('11b-ricochet-wide',bx[0],bx[1],140,160);await pg.close();
 // 12 sparkle: destroyed pixels break into 1x1 bits (zoom right after a burst)
 await fresh();await run(()=>{const P=__H.game(47,{missP:0,ricoP:0,ricoMode:0});__H.headon(P);for(let i=0;i<1200;i++)P.tick();window.__sp=0;for(let i=0;i<60;i++){P.tick();if(P.vpN>60){window.__sp=i;break;}}P.S.paused=true;P.draw();let sx=0,sy=0,c=0;for(let k=0;k<P.vpN;k++){sx+=P.vX[k];sy+=P.vY[k];c++;}window.__sx=c?[sx/c,sy/c,c]:[180,250,0];});
 const sx=await run(()=>window.__sx);console.log('sparkle bits alive',sx[2]);await zoom('12-sparkle-bits-1x1-fading',sx[0],sx[1],60,60);await zoom('12b-sparkle-wide',sx[0],sx[1],120,140);
 await run(()=>{const P=__pw;P.S.paused=false;for(let i=0;i<30;i++)P.tick();P.S.paused=true;P.draw();});await zoom('12c-sparkle-30-ticks-later',sx[0],sx[1],60,60);await pg.close();
 // 13 walls reach the screen edges
 await fresh();await run(()=>{const P=__H.game(48);P.placeCircle(0,180,456);__H.main(P);P.S.aiRev=1;P.S.sides[1].strokes=[];const a=P.wallBegin(0,150,300);P.wallExtend(0,a,-40,300);P.wallEnd(0,a);const c=P.wallBegin(0,200,380);P.wallExtend(0,c,500,380);P.wallEnd(0,c);P.S.paused=true;P.draw();});await snap('13-walls-reach-the-screen-edges');await pg.close();
 // 14 leash fade: pixels past 108 fade out gradually (zoom)
 await fresh();await run(()=>{const P=__H.game(49);P.placeCircle(0,180,456);__H.main(P,[[180,400],[180,330],[180,260],[180,190],[180,130]]);P.S.sides[1].human=true;P.startBattle();const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.circle.x=40;f.circle.y=44;f.paths[0].p=[40,44,40,48];P.S.sides[0].set.release=9;P.S.sides[0].set.cap=4000;P.S.sides[0].set.width=9;for(let i=0;i<1500;i++)P.tick();P.S.paused=true;P.draw();});await snap('14-leash-fade-wide-lane-drift');
 await zoom('14b-leash-fade-zoom',180,150,120,120);await pg.close();
 // 15 sandbox: both sides editable, running
 await fresh();await run(()=>{const P=__pw;P.startWith({duel:1,aiLevel:0});for(const k of[[180,380],[180,300],[180,220]])P.pathExtend(0,k[0],k[1]);P.placeCircle(1,120,90);for(const k of[[120,150],[130,220],[180,290]])P.pathExtend(1,k[0],k[1]);const st=P.wallBegin(0,40,330);P.wallExtend(0,st,140,330);P.wallEnd(0,st);P.S.sides[0].set.release=7;P.S.sides[1].set.release=7;P.sandboxStep(500);});await snap('15-sandbox-both-sides-editable');await pg.close();
 // 16 menu + help + custom
 await fresh();await run(()=>__pw.showView('menu'));await snap('16-menu');await run(()=>__pw.showView('help'));await snap('17-help');await run(()=>__pw.showView('custom'));await sleep(200);await snap('18-custom-game');await pg.close();
 await b.close();console.log('done');})();
