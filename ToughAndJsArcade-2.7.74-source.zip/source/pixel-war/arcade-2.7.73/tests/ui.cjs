// 0.4.2 layout tests: plain-words HUD fits 360x800, 320x568 and 720x1600 in every state (prep, prep with drawn paths, battle with branches + selected path, sandbox, result, menu/custom/help)
// checks: nothing overlaps, every tap target >= 44px, no clipped text, nothing off-screen, canvas is DPR native + not smoothed, 0 JS errors.  Writes screenshots to out/shots/.
const {launch,open}=require('./lib.cjs');
const fs=require('fs');const OUT='/workspace/game/build-pixelwar042/out/shots/';fs.mkdirSync(OUT,{recursive:true});
const R=[];const ok=(n,c,i)=>{R.push([c?'PASS':'FAIL',n,c?'':String(i)]);};
const SIZES=[[360,800,2,'360x800'],[320,568,2,'320x568'],[720,1600,1,'720x1600']];
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function domChecks(pg){
 return pg.evaluate(()=>{const out={over:[],small:[],clip:[],offs:[]};
  const sl=document.getElementById('sl'),slR=sl?sl.getBoundingClientRect():null;
  const rectOf=e=>{let r=e.getBoundingClientRect();const o={left:r.left,right:r.right,top:r.top,bottom:r.bottom};
    // elements inside the scrolling slider list are clipped to it (the list scrolls)
    if(slR&&sl.contains(e)&&e!==sl){o.left=Math.max(o.left,slR.left);o.right=Math.min(o.right,slR.right);o.top=Math.max(o.top,slR.top);o.bottom=Math.min(o.bottom,slR.bottom);}return o;};
  const shown=e=>{const r=e.getBoundingClientRect(),cs=getComputedStyle(e);if(!(r.width>0&&r.height>0&&cs.display!=='none'&&cs.visibility!=='hidden'))return false;
    for(let p=e.parentElement;p;p=p.parentElement){if(getComputedStyle(p).display==='none')return false;}return true;};
  const els=[...document.querySelectorAll('#app #top>*,#panel button,#panel input,#panel .lab,#panel .lab2,#panel .bar,#panel #slh,#panel #status2,#stage,#c')].filter(shown);
  const leaf=els.filter(e=>{const o=rectOf(e);return o.right-o.left>1&&o.bottom-o.top>1;});
  for(let i=0;i<leaf.length;i++)for(let j=i+1;j<leaf.length;j++){const a=leaf[i],b=leaf[j];if(a.contains(b)||b.contains(a))continue;const A=rectOf(a),B=rectOf(b);
   const ox=Math.min(A.right,B.right)-Math.max(A.left,B.left),oy=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);if(ox>0.5&&oy>0.5)out.over.push((a.id||a.className||a.tagName)+' x '+(b.id||b.className||b.tagName));}
  for(const e of document.querySelectorAll('#app button,#app input')){if(!shown(e))continue;const r=rectOf(e),W=r.right-r.left,H=r.bottom-r.top;const full=e.getBoundingClientRect();
   if(slR&&sl.contains(e)&&(H<full.height-1))continue; // partly scrolled out of the list: not a tap target at the moment
   if(H<43.5||W<43.5)out.small.push((e.id||e.className||e.textContent.slice(0,8))+':'+Math.round(W)+'x'+Math.round(H));}
  for(const e of document.querySelectorAll('#status,#panel .lab,#panel .lab2,#app button,#slh,#result h2')){if(!shown(e))continue;if(e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+3){if(slR&&sl.contains(e)&&e.getBoundingClientRect().bottom>slR.bottom)continue;out.clip.push(e.id||e.className||e.textContent.slice(0,10));}}
  for(const e of els){const r=e.getBoundingClientRect();if(e.closest('#sl')&&!(e.id==='sl'))continue;if(r.right>window.innerWidth+1||r.left<-1||r.bottom>window.innerHeight+1)out.offs.push(e.id||e.className);}
  const c=document.getElementById('c'),r=c.getBoundingClientRect();out.canvas={cw:c.width,ch:c.height,w:r.width,h:r.height,dpr:devicePixelRatio,smooth:c.getContext('2d').imageSmoothingEnabled};
  const st=document.getElementById('stage').getBoundingClientRect();out.stage=[st.width,st.height];out.scale=__pw.L.LS;
  const pn=document.getElementById('panel').getBoundingClientRect();out.panel=[pn.top,pn.height];
  return out;});}
const bad=r=>r.over.length+r.small.length+r.clip.length+r.offs.length;
async function check(pg,tag,state){const r=await domChecks(pg);ok(tag+' '+state+': nothing overlaps, all taps >=44px, no clipped text, nothing off-screen',bad(r)===0,JSON.stringify({over:r.over,small:r.small,clip:r.clip,offs:r.offs}));return r;}
(async()=>{const b=await launch();
 for(const [w,h,d,tag] of SIZES){const pg=await open(b,w,h,d,{mobile:true});
  await pg.evaluate(()=>__tt.setSeed(5));await wait(300);
  let r=await check(pg,tag,'prep (AI path being drawn)');
  ok(tag+' canvas is DPR-native ('+r.canvas.cw+'x'+r.canvas.ch+' for '+Math.round(r.canvas.w)+'x'+Math.round(r.canvas.h)+' @'+r.canvas.dpr+')',Math.abs(r.canvas.cw-Math.round(r.canvas.w*r.canvas.dpr))<=1&&Math.abs(r.canvas.ch-Math.round(r.canvas.h*r.canvas.dpr))<=1,JSON.stringify(r.canvas));
  ok(tag+' image smoothing off (crisp)',r.canvas.smooth===false);
  console.log(tag,'field scale',r.scale.toFixed(2),'stage',r.stage.map(Math.round),'panel top/height',r.panel.map(Math.round));
  await wait(3200);await pg.screenshot({path:OUT+tag+'-prep.png'});
  // draw main path + defense line through the engine, then re-check
  await pg.evaluate(()=>{const P=__pw;for(const k of[[180,400],[184,330],[190,260],[196,190],[196,130]])P.pathExtend(0,k[0],k[1]);const st=P.wallBegin(0,20,330);P.wallExtend(0,st,330,330);P.wallEnd(0,st);P.S.aiRev=1;});await wait(150);
  r=await check(pg,tag,'prep with both paths and walls');ok(tag+' START is enabled once path + defense are drawn',await pg.evaluate(()=>!document.getElementById('tStart').classList.contains('wait')&&__pw.prepNeeds(__pw.S.sides[0]).length===0));
  await pg.screenshot({path:OUT+tag+'-prep-ready.png'});
  // battle with 2 branches, selected path, sliders panel
  await pg.evaluate(()=>{const P=__pw;P.tryStart();for(let i=0;i<500;i++)P.tick();const b1=P.branchBegin(0,184,330);if(b1){P.branchExtend(0,b1,60,300);P.branchEnd(0,b1);}const b2=P.branchBegin(0,196,190);if(b2){P.branchExtend(0,b2,300,160);P.branchEnd(0,b2);}P.selP=1;P.setPathSetting(0,1,'width',8);for(let i=0;i<200;i++)P.tick();});await wait(150);
  r=await check(pg,tag,'battle, 2 branches, branch 1 selected');
  await pg.screenshot({path:OUT+tag+'-battle.png'});
  {const fit=await pg.evaluate(()=>{const o=[];for(const e of document.querySelectorAll('#slh,#tY,#tF,#lSp,#lDe,#lSpc,#lWd,#lRe,#chips button')){if(e.offsetParent===null)continue;if(e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+1)o.push((e.id||e.textContent)+':'+e.scrollWidth+'/'+e.clientWidth+'x'+e.scrollHeight+'/'+e.clientHeight);}return o;});ok(tag+' battle: labels and path chips fit their boxes',fit.length===0,fit);}
  // every slider row reachable by scrolling the list
  {const sc=await pg.evaluate(async()=>{const sl=document.getElementById('sl');const rows=[...sl.querySelectorAll('.box')].filter(e=>e.offsetParent!==null);const seen=[];for(const r of rows){r.scrollIntoView({block:'nearest'});const a=r.getBoundingClientRect(),b=sl.getBoundingClientRect();seen.push(a.top>=b.top-1&&a.bottom<=b.bottom+1);}sl.scrollTop=0;return{rows:rows.length,seen:seen.filter(Boolean).length,can:sl.scrollHeight>sl.clientHeight};});ok(tag+' every slider row can be scrolled fully into view ('+sc.seen+'/'+sc.rows+')',sc.rows>=5&&sc.seen===sc.rows,JSON.stringify(sc));}
  // result
  await pg.evaluate(()=>{const P=__pw;for(const sd of P.S.sides)sd.set.cap=10000;let t=0;while(!P.S.over&&t<20000){P.tick();t++;}if(!P.S.over)P.endMatch(0);});await wait(400);
  await check(pg,tag,'result');await pg.screenshot({path:OUT+tag+'-result.png'});
  // sandbox
  await pg.evaluate(()=>{__pw.startWith({duel:1,aiLevel:0});});await wait(300);
  await check(pg,tag,'sandbox (paused, both sides editable)');await pg.screenshot({path:OUT+tag+'-sandbox.png'});
  await pg.evaluate(()=>{const P=__pw;P.sandboxStep(300);});await wait(100);await check(pg,tag,'sandbox running');
  // huge pool values (sandbox / custom): labels must stay short, never clip and never touch the bars
  for(const v of[[999999820,1e9],[12345,1234567],[0,9999]]){
   await pg.evaluate(v=>{const P=__pw;P.S.sides[0].pool=v[0];P.S.sides[1].pool=v[1];P.draw();},v);await wait(80);
   const hr=await check(pg,tag,'huge pool '+v.join('/'));
   const lt=await pg.evaluate(()=>{const a=document.getElementById('tY'),b=document.getElementById('tF'),by=document.getElementById('hY'),bf=document.getElementById('hF');
    return {y:a.textContent,f:b.textContent,fitY:a.scrollWidth<=a.clientWidth&&a.getBoundingClientRect().right<=by.getBoundingClientRect().left+0.5,fitF:b.scrollWidth<=b.clientWidth&&b.getBoundingClientRect().right<=bf.getBoundingClientRect().left+0.5};});
   ok(tag+' huge pool '+v.join('/')+': compact labels fit before their bars ("'+lt.y+'" / "'+lt.f+'")',lt.fitY&&lt.fitF&&lt.y.length<=10&&lt.f.length<=10&&!/\d{6,}/.test(lt.y+lt.f),JSON.stringify(lt));}
  for(const v of['menu','custom','help']){await pg.evaluate(v=>__pw.showView(v),v);await wait(80);
   const vr=await pg.evaluate(v=>{const root=document.getElementById(v),R=root.getBoundingClientRect(),out={over:[],small:[],off:[]};const els=[...root.querySelectorAll('button,input')].filter(e=>e.offsetParent!==null);
    for(let i=0;i<els.length;i++)for(let j=i+1;j<els.length;j++){const a=els[i],b=els[j];if(a.contains(b)||b.contains(a))continue;const A=a.getBoundingClientRect(),B=b.getBoundingClientRect();const ox=Math.min(A.right,B.right)-Math.max(A.left,B.left),oy=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);if(ox>0.5&&oy>0.5&&A.top>=R.top&&A.bottom<=R.bottom&&B.top>=R.top&&B.bottom<=R.bottom)out.over.push(a.id+' x '+b.id);}
    for(const e of els){const r=e.getBoundingClientRect();if(/BUTTON/.test(e.tagName)&&r.top>=R.top&&r.bottom<=R.bottom&&(r.height<43.5||r.width<43.5))out.small.push((e.id||e.textContent.slice(0,10))+':'+Math.round(r.width)+'x'+Math.round(r.height));if(r.right>window.innerWidth+1||r.left<-1)out.off.push(e.id);}
    return out;},v);
   ok(tag+' '+v+' view: no overlaps, small targets or off-screen controls',vr.over.length+vr.small.length+vr.off.length===0,JSON.stringify(vr));
   if(v==='help'||v==='menu')await pg.screenshot({path:OUT+tag+'-'+v+'.png'});}
  ok(tag+' 0 JS errors',pg._errs.length===0,pg._errs);
  await pg.close();}
 await b.close();
 let f=0;for(const r of R){console.log(r.join(' '));if(r[0]==='FAIL')f++;}console.log('UI '+(R.length-f)+' pass / '+f+' fail');process.exit(f?1:0);})();
