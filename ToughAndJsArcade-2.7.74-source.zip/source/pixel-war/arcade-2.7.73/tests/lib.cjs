const path=require('path');
const pp=require('/workspace/game/build-needle/gui/node_modules/puppeteer-core');
const FILE='file://'+path.resolve(__dirname,'../index.html');
async function launch(){return pp.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--disable-gpu','--force-device-scale-factor=1']});}
async function open(b,w,h,dpr,opts={}){const pg=await b.newPage();await pg.setViewport({width:w,height:h,deviceScaleFactor:dpr,isMobile:!!opts.mobile,hasTouch:!!opts.mobile});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});pg._errs=errs;
 await pg.goto(FILE);await new Promise(r=>setTimeout(r,700));return pg;}
module.exports={launch,open,FILE};
