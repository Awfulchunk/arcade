const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT=process.argv[2]||'/tmp/shapes/';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const b=await launch();
 for(let t=0;t<7;t++){const pg=await open(b,360,800,2,{mobile:true});
  await pg.evaluate((t)=>{__tt.setSeed(3);const P=__pw;P.placeCircle(0,180,456);
   const pts=[[180,456],[184,380],[196,300],[200,220],[196,140]];for(let i=1;i<pts.length;i++)P.pathExtend(0,pts[i][0],pts[i][1]);
   P.setShape(0,0,t);P.setPull(0,0,t?85:0);P.setAt(0,0,t?10:0);P.S.sides[1].set.release=1;P.S.sides[1].set.cap=250;P.S.sides[1].circle.x=60;
   P.startBattle();P.S.sides[1].paths[0].p=[60,44,60,48];P.S.sides[1].paths[0].kids=[];for(let k=1;k<P.S.sides[1].paths.length;k++)P.S.sides[1].paths[k]=null;
   for(let i=0;i<200;i++)P.tick();P.S.paused=true;P.draw();},t);
  await pg.screenshot({path:OUT+'shape'+t+'.png',clip:{x:90,y:60,width:200,height:520}});await pg.close();}
 await b.close();})();
