// Pixel War 0.4.12 fair runs (t1196): same openings as 0.4.10 (dummy 11, fair 17/11/23, left-wrap variant 19), memory cleared each run,
// played to the real end (circle destroyed, or the 5-minute timer: more HP wins). Bar: AI wins all four fair/variant runs, 0 mid-match walls, 0 JS errors.
const {launch,open}=require('./lib.cjs');const {runFight,SPECS}=require('./fairlib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 const t=await pg.evaluate(()=>document.title);if(t!=='PIXEL WAR 0.4.12'){console.error('LOAD_FAIL',t);process.exit(1);}
 const bad=[],rows=[];
 for(const sp of SPECS){const r=await runFight(pg,sp,18000);const win=r.winner===1?'AI':r.winner===0?'player':'draw';rows.push(r);
  const g=[];for(const tr of r.trace)for(const x of tr.br)if(x.job==='guard')g.push(x.id+':w'+x.w);
  console.log('RUN',JSON.stringify({name:sp.name,winner:win,over:r.over,tick:r.tick,sec:+(r.tick/60).toFixed(1),aiHits:r.aiHits,pHits:r.pHits,aiHp:r.aiHp,pHp:r.pHp,guards:[...new Set(g)],detour:r.detour&&r.detour.ok,offense:r.offense&&r.offense.ok,walls:r.wallsUnchanged,aiNoWallTry:r.aiNeverTried}));
  if(!r.started||!r.locked)bad.push(sp.name+': start/lock');if(!r.wallsUnchanged||!r.aiNeverTried)bad.push(sp.name+': mid-match wall');
  if(sp.kind!=='dummy'&&!(r.detour&&r.detour.ok&&r.offense&&r.offense.ok))bad.push(sp.name+': player detour/offense missing');
  if(r.winner!==1)bad.push(sp.name+': AI did not win');}
 if(pg._errs.length)bad.push('JS errors '+JSON.stringify(pg._errs));
 const fair=rows.filter(r=>r.kind!=='dummy');console.log('BAR',JSON.stringify({fairRuns:fair.length,aiWins:fair.filter(r=>r.winner===1).length}));
 await b.close();if(bad.length){console.error('TEST_FAIL',bad);process.exit(1);}console.log('TEST_OK');})().catch(e=>{console.error(e);process.exit(1);});
