const {launch,open}=require('./lib.cjs');
(async()=>{const b=await launch();const [w,h]=[+process.argv[2]||360,+process.argv[3]||800];const pg=await open(b,w,h,2,{mobile:true});
await pg.evaluate(()=>__tt.setSeed(5));
await new Promise(r=>setTimeout(r,2500));
await pg.screenshot({path:'/workspace/game/build-pixelwar042/out/dbg/prep-'+w+'.png'});
await pg.evaluate(()=>{const P=__pw;P.placeCircle?0:0;});
// draw path+wall via tt commands
await pg.evaluate(()=>{const t=__tt;t.runCommand('drawPath',[180,380]);t.runCommand('drawPath',[170,300]);t.runCommand('drawPath',[200,200]);t.runCommand('drawPath',[220,120]);t.runCommand('wall',[10,330,250,330]);});
await pg.screenshot({path:'/workspace/game/build-pixelwar042/out/dbg/prep2-'+w+'.png'});
await pg.evaluate(()=>{__pw.tryStart();__tt.step(900);});
await pg.screenshot({path:'/workspace/game/build-pixelwar042/out/dbg/battle-'+w+'.png'});
console.log(JSON.stringify(pg._errs));await b.close();})();
