// 0.4 hits -> out/hits04/*.png  (360x800 @2 = 720x1600 device px; zoom crops @4). Views, lane shapes, gates, formations, reform, redraw, result/review.
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar042/out/hits04/';fs.mkdirSync(OUT,{recursive:true});for(const f of fs.readdirSync(OUT))if(f.endsWith('.png'))fs.unlinkSync(OUT+f);
const HELP=`window.__H={mk(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};},
 game(seed,cfg){const P=__pw;P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed,false);P.setRnd(this.mk(seed));return P;},
 main(P,pts){for(const k of pts||[[180,420],[184,350],[190,280],[196,210],[196,140]])P.pathExtend(0,k[0],k[1]);},
 quiet(P){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);f.acc=0;},
 box(P,t){let n=0,a=1e9,b=-1e9,c=1e9,d=-1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){n++;a=Math.min(a,P.px[i]);b=Math.max(b,P.px[i]);c=Math.min(c,P.py[i]);d=Math.max(d,P.py[i]);}return n?{n,x:(a+b)/2,y:(c+d)/2,w:b-a,h:d-c}:null;}};`;
(async()=>{const b=await launch();let pg;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const fresh=async(w,h)=>{pg=await open(b,w||360,h||800,2);await pg.evaluate(HELP);};
 const snap=async(name,clip)=>{await sleep(160);const o={path:OUT+name+'.png'};if(clip)o.clip=clip;await pg.screenshot(o);};
 const L=()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const zoom=async(name,cx,cy,w,h)=>{const l=await L();await snap(name,{x:l.x+(cx-w/2)*l.s,y:l.y+(cy-h/2)*l.s,width:w*l.s,height:h*l.s,scale:3});};
 const show=(seed,cfg,fn)=>pg.evaluate(([seed,cfg,fn])=>{const P=__H.game(seed,JSON.parse(cfg));eval(fn);__pw.S.paused=true;__pw.draw();},[seed,JSON.stringify(cfg),fn]);
 // 01 menu, 02 stages, 03 custom, 04 help
 await fresh();await pg.evaluate(()=>__pw.showView('menu'));await snap('01-menu');
 await pg.click('#mStages');await sleep(200);await snap('02-stages');await pg.click('#stBack');await sleep(150);
 await pg.click('#mCustom');await sleep(250);await snap('03-custom-game-top');await pg.evaluate(()=>{const v=document.getElementById('custom');const s=document.getElementById('clist');s.scrollTop=99999;});await snap('03b-custom-game-bottom');await pg.evaluate(()=>__pw.showView('menu'));
 await pg.evaluate(()=>__pw.showView('help'));await snap('04-help');
 // 05 editor with a saved custom formation (real clicks painted)
 await pg.evaluate(()=>{__pw.PRESETS=[];__pw.showView('menu');});await pg.click('#mForms');await sleep(300);
 const er=await pg.evaluate(()=>{const r=document.getElementById('edc').getBoundingClientRect();return{x:r.left,y:r.top,w:r.width,h:r.height};});
 const cell=(c,r)=>({x:er.x+er.w*(c+0.5)/15,y:er.y+er.h*(r+0.5)/12});
 await pg.mouse.move(cell(1,10).x,cell(1,10).y);await pg.mouse.down();for(let k=2;k<=7;k++){await pg.mouse.move(cell(k,10-k+1).x,cell(k,10-k+1).y,{steps:3});}await pg.mouse.up();
 await pg.click('#edMirror');await sleep(150);await snap('05-editor-painted-mirrored');
 // 06..09 lane shapes in prep (overlay)
 for(const [i,nm] of [[1,'wide'],[2,'narrow'],[3,'tapered'],[4,'arrow']]){await fresh();await show(5,{},"P.placeCircle(0,180,440);__H.main(P);P.setLane(0,0,"+i+");P.S.paused=true");await snap('0'+(5+i)+'-prep-lane-'+nm);await pg.close();}
 // 10 prep: gates + walls + branch
 await fresh();await show(6,{},"P.placeCircle(0,180,440);__H.main(P);P.wallBegin;let st=P.wallBegin(0,60,400);P.wallExtend(0,st,110,388);P.wallExtend(0,st,140,386);P.wallEnd(0,st);st=P.wallBegin(0,150,300,true);P.wallExtend(0,st,230,300);P.wallEnd(0,st);st=P.wallBegin(0,240,380);P.wallExtend(0,st,290,392);P.wallExtend(0,st,330,404);P.wallEnd(0,st);const p=P.S.sides[0].paths[0].p;const B=P.branchBegin(0,p[24],p[25]);for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]-q*16,p[25]-q*12);P.branchEnd(0,B);P.setLane(0,B.id,2);");await snap('10-prep-walls-gate-branch-narrow');await pg.close();
 // 11 battle: arrow formation (front-concentrated) zoom + 12 custom formation zoom
 await fresh();await show(3,{},"P.placeCircle(0,180,440);__H.main(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,1);for(let i=0;i<190;i++)P.tick();");await snap('11-battle-arrow-formation');let bx=await pg.evaluate(()=>__H.box(__pw));if(bx)await zoom('11b-arrow-zoom',bx.x,bx.y,70,70);await pg.close();
 await fresh();await show(3,{},"P.PRESETS=[];P.addPreset('HOOK',(()=>{const c=[];for(let r=0;r<12;r++)c.push([7,r]);for(let k=1;k<6;k++){c.push([7-k,10+(k>>1)-((k>>1)?0:0)]);c.push([7+k,Math.max(0,10-k*2)]);}return c;})());P.placeCircle(0,180,440);__H.main(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,7);for(let i=0;i<190;i++)P.tick();");bx=await pg.evaluate(()=>__H.box(__pw));await snap('12-battle-custom-formation');if(bx)await zoom('12b-custom-zoom',bx.x,bx.y,70,70);await pg.close();
 // 13 impact stretch / 14 reformed (arrow hit by enemy streams)
 await fresh();await show(4,{capDef:4000},"P.placeCircle(0,180,440);__H.main(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,2);for(let i=0;i<150;i++)P.tick();const sd=P.S.sides[0];let q=sd.sq.find(x=>x);const B=P.POOL;let cx=0,cy=0,n=0;for(let m=0;m<q.n;m++){const i=q.slot[m];if(i>=0){cx+=P.px[i];cy+=P.py[i];n++;}}cx/=n;cy/=n;sd.stats;P.S.sides[1].paths[0].p=[cx,cy-30,cx,cy-26];let k=0;for(let m=0;m<q.n&&k<90;m++){const i=q.slot[m];if(i>=0&&m%2===0){P.px[B+k]=P.px[i]+1.2;P.py[B+k]=P.py[i];P.pvx[B+k]=0;P.pvy[B+k]=0;P.php[B+k]=2;P.pst[B+k]=3;P.pcd[B+k]=0;k++;}}P.S.sides[1].active+=k;for(let s=0;s<14;s++){P.movePixels();P.collide();P.S.tick++;}window.__k=k;");bx=await pg.evaluate(()=>__H.box(__pw));await snap('13-formation-after-impact');if(bx)await zoom('13b-impact-zoom',bx.x,bx.y,80,80);
 await pg.evaluate(()=>{const P=__pw;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);P.S.sides[1].active=0;P.S.paused=false;for(let i=0;i<130;i++)P.tick();P.S.paused=true;P.draw();});bx=await pg.evaluate(()=>__H.box(__pw));await snap('14-formation-reformed');if(bx)await zoom('14b-reformed-zoom',bx.x,bx.y,80,80);await pg.close();
 // 15 gate: own stream passes, enemy blocked
 await fresh();await show(7,{capDef:3000},"P.placeCircle(0,180,440);__H.main(P);let st=P.wallBegin(0,150,330,true);P.wallExtend(0,st,215,330);P.wallEnd(0,st);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.paused=false;for(let i=0;i<260;i++)P.tick();P.S.paused=true;P.draw();");await snap('15-gate-own-stream-passes');await zoom('15b-gate-zoom',185,330,90,60);await pg.close();
 // 16 mid-battle branch erase + redraw
 await fresh();await show(8,{capDef:3000},"P.placeCircle(0,180,440);__H.main(P);const p=P.S.sides[0].paths[0].p;let B=P.branchBegin(0,p[24],p[25]);for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]-q*16,p[25]-q*12);P.branchEnd(0,B);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.paused=false;for(let i=0;i<200;i++)P.tick();P.eraseAt(0,p[24]-48,p[25]-36);B=P.branchBegin(0,p[24],p[25]);if(B){for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]+q*16,p[25]-q*12);P.branchEnd(0,B);}for(let i=0;i<120;i++)P.tick();P.S.paused=true;P.draw();");await snap('16-branch-erased-and-redrawn');await pg.close();
 // 17 dense battle with arrow + tapered lane, 18 result stats + review (360x800), 19 result 320x568
 await fresh();await show(11,{capDef:4000,aiLevel:4},"P.placeCircle(0,180,440);__H.main(P);P.setLane(0,0,3);P.aiPlan(1);P.S.sides[1].human=false;P.startBattle();P.useShape(0,0,1);for(let i=0;i<420;i++){P.tick();if(i%120===60)P.useShape(0,0,4);}");await snap('17-battle-brutal-ai-tapered-lane');await pg.close();
 for(const [w,h,tag] of [[360,800,'360'],[320,568,'320']]){await fresh(w,h);await pg.evaluate(()=>{const P=__H.game(12,{capDef:3000,aiLevel:3});P.placeCircle(0,180,440);__H.main(P);P.aiPlan(1);P.S.sides[1].human=false;P.startBattle();for(let i=0;i<6000&&!P.S.over;i++)P.tick();window.__ended=P.S.over;});await sleep(300);await snap('18-result-review-'+tag);await pg.click('#btnRev');await sleep(250);await snap('19-result-stats-'+tag);await pg.close();}
 console.log('done');await b.close();})();
