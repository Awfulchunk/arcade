// A03s-emulated perf: 720x1600 DPR1 (isMobile), CPU throttle x4/x6. usage: node perf.cjs [caps...]   (cap = per-side CAPMAX/ACTIVE)
const {launch,FILE}=require('./lib.cjs');const fs=require('fs'),path=require('path');
const src0=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');const FILE0=FILE;
async function run(b,file,w,h,dpr,rate,label,secs,cap){const pg=await b.newPage();await pg.setViewport({width:w,height:h,deviceScaleFactor:dpr,isMobile:true,hasTouch:true});if(process.env.HALO!==undefined||process.env.NL||process.env.NA)await pg.evaluateOnNewDocument((h,nl,na)=>{window.__halo=h;window.__nb=nl;window.__na=na;},process.env.HALO===undefined?1:+process.env.HALO,+(process.env.NL||0),+(process.env.NA||0));await pg.goto(file);await new Promise(r=>setTimeout(r,600));
 const cdp=await pg.createCDPSession();await cdp.send('Emulation.setCPUThrottlingRate',{rate});
 await pg.evaluate(cap=>{__tt.setSeed(7);const P=__pw;P.startWith({capDef:cap,burn:1,lives:255,poolSize:10000});P.setSetting(0,'release',10);P.setSetting(0,'speed',1);if(window.__halo!==undefined)P.CFG.halo=window.__halo;P.aiPlan(0);P.startBattle();for(const s of P.S.sides){s.set.release=10;s.set.speed=1;s.set.cap=cap;}
  window.__pk=0;window.__ov=false;setInterval(()=>{window.__pk=Math.max(window.__pk,P.S.sides[0].active,P.S.sides[1].active);if(P.S.over)window.__ov=true;},200);
  setInterval(()=>{if(!P.S.over)for(const t of[0,1,2,4,5,6])if(P.useShape(0,0,t))break;},1500);P.stat.ticks=0;P.stat.ms=0;P.stat.maxMs=0;
  window.__ft=[];let l=performance.now();(function f(n){window.__ft.push(n-l);l=n;requestAnimationFrame(f);})(l);},cap);
 await new Promise(r=>setTimeout(r,(secs||12)*1000));
 const r=await pg.evaluate(()=>{const f=window.__ft.slice(60).sort((a,b)=>a-b);const avg=f.reduce((a,b)=>a+b,0)/f.length;const act=__pw.S.sides.map(x=>x.active);
  const t0=performance.now();for(let i=0;i<10;i++)__pw.draw();const dr=(performance.now()-t0)/10;
  return{fps:1000/avg,p95:f[Math.floor(f.length*0.95)],max:f[f.length-1],n:f.length,tickAvg:__pw.stat.ms/__pw.stat.ticks,tickMax:__pw.stat.maxMs,drawMs:dr,act,peak:window.__pk,over:window.__ov,tick:__pw.S.tick};});
 console.log(label,JSON.stringify(r,(k,v)=>typeof v==='number'?Math.round(v*100)/100:v));await pg.close();return r;}
(async()=>{const b=await launch();const caps=process.argv.slice(2).map(Number);const rates=(process.env.RATES||'4,6').split(',').map(Number);
 for(const cap of caps){for(const rate of rates)await run(b,FILE0,+(process.env.W||720),+(process.env.H||1600),+(process.env.DPR||1),rate,'cap'+cap+' '+(process.env.W||720)+'x'+(process.env.H||1600)+'@'+(process.env.DPR||1)+' cpu x'+rate,12,cap);}
 await b.close();})();
