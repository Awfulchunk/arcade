// Pixel War 0.4.12 A03s perf profile: 360x800 @2, CPU throttle x6 (and x4), FLOW 1000 on BOTH sides, pixel sizes min / max / mixed.
// Measures real frame rate from rAF intervals (sim + draw), sim tick ms (stat), and draw() ms.
const {launch}=require('./lib.cjs');const FILE='file://'+'/workspace/game/build-pixelwar0411/index.html';
async function run(b,rate,z0,z1,secs){const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});
  const errs=[];pg.on('pageerror',e=>errs.push(String(e)));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await pg.goto(FILE);await new Promise(r=>setTimeout(r,800));
  await pg.evaluate((z0,z1)=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=11/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;const S=g.S;S.sides[1].human=true;const a=S.sides[0].circle,c=S.sides[1].circle;
    for(let i=1;i<=150;i++){g.pathExtend(0,a.x+(c.x-a.x)*i/150+30*Math.sin(i/150*6.28),a.y+(c.y-a.y)*i/150);g.pathExtend(1,c.x+(a.x-c.x)*i/150-30*Math.sin(i/150*6.28),c.y+(a.y-c.y)*i/150);}
    for(const sd of [0,1]){g.setSetting(sd,'width',8);g.setSetting(sd,'speed',6);g.setSetting(sd,'release',1000);g.setSetting(sd,'size',sd?z1:z0);}
    g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;for(let i=0;i<900;i++)g.tick();   // warm up to a full field
    g.stat.ticks=0;g.stat.ms=0;g.stat.maxMs=0;},z0,z1);
  const cdp=await pg.createCDPSession();await cdp.send('Emulation.setCPUThrottlingRate',{rate});
  const r=await pg.evaluate(secs=>new Promise(res=>{const g=window.__pw;const iv=[];let last=0,dr=0,drN=0,drMax=0;const t0=performance.now();
    const f=t=>{if(last)iv.push(t-last);last=t;const d0=performance.now();g.draw();const d=performance.now()-d0;dr+=d;drN++;if(d>drMax)drMax=d;if(t-t0<secs*1000)requestAnimationFrame(f);else{iv.sort((a,b)=>a-b);const avg=iv.reduce((a,b)=>a+b,0)/iv.length;
      let field=0;for(let i=0;i<g.POOL*2;i++)if(g.pst[i])field++;res({fps:+(1000/avg).toFixed(1),p95ms:+iv[Math.floor(iv.length*0.95)].toFixed(1),frames:iv.length,simAvg:+(g.stat.ms/Math.max(1,g.stat.ticks)).toFixed(2),simMax:+g.stat.maxMs.toFixed(1),drawAvg:+(dr/drN).toFixed(2),drawMax:+drMax.toFixed(1),field,active:[g.S.sides[0].active,g.S.sides[1].active]});}};requestAnimationFrame(f);}),secs);
  await pg.close();return Object.assign({rate,sizes:[z0,z1],errs:errs.length},r);}
(async()=>{const b=await launch();const out=[];
  for(const [z0,z1] of [[5,5],[1,1],[10,10],[1,10]])for(const rate of [6]){const r=await run(b,rate,z0,z1,8);out.push(r);console.log('A03S',JSON.stringify(r));}
  {const r=await run(b,4,1,1,8);out.push(r);console.log('A03S',JSON.stringify(r));}
  await b.close();const bad=out.filter(r=>r.errs||r.fps<55);console.log(bad.length?'PERF_FAIL '+JSON.stringify(bad):'PERF_OK');if(bad.length)process.exit(1);})().catch(e=>{console.error(e);process.exit(1);});
