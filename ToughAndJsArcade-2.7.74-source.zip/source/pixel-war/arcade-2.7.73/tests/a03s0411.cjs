const {launch}=require('./lib.cjs');
const FILE='file:///workspace/game/build-pixelwar0411/index.html';
async function runRate(b, rate, secs){
  const pg=await b.newPage();
  await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});
  const errs=[];
  pg.on('pageerror',e=>errs.push(String(e)));
  pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await pg.goto(FILE);
  await new Promise(r=>setTimeout(r,800));
  const cdp=await pg.createCDPSession();
  await cdp.send('Emulation.setCPUThrottlingRate',{rate});
  await pg.evaluate(()=>{
    const P=window.__pw;
    P.clearAiMem();
    const _r=Math.random; let _u=11/4294967296; Math.random=()=>_u; P.startWith({}); Math.random=_r;
    const pc=P.S.sides[0].circle, ac=P.S.sides[1].circle;
    for(let i=1;i<=140;i++){
      const t=i/140;
      P.pathExtend(0, pc.x+(ac.x-40-pc.x)*t, pc.y+(ac.y+8-pc.y)*t);
    }
    const wy=Math.max(P.C.H/2+24, pc.y-80);
    const w1=P.wallBegin(0,16,wy); if(w1){P.wallExtend(0,w1,150,wy);P.wallEnd(0,w1);}
    const w2=P.wallBegin(0,230,wy); if(w2){P.wallExtend(0,w2,344,wy);P.wallEnd(0,w2);}
    if(P.aiRevisePlan) P.aiRevisePlan();
    P.setSetting(0,'release',600); P.setSetting(0,'width',6); P.setSetting(0,'speed',6); P.setSetting(0,'density',6);
    P.tryStart();
    P.S.paused=false;
    P.stat.ticks=0; P.stat.ms=0; P.stat.maxMs=0;
  });
  await new Promise(r=>setTimeout(r, secs*1000));
  const r=await pg.evaluate(()=>{
    const P=window.__pw, s=P.stat;
    const avg=s.ticks?s.ms/s.ticks:0;
    return {
      title:document.title, tick:P.S.tick, phase:P.S.phase, over:P.S.over,
      ticks:s.ticks, ms:s.ms, maxMs:s.maxMs, avgMs:avg,
      simFps:avg>0?1000/avg:0,
      active:[P.S.sides[0].active,P.S.sides[1].active]
    };
  });
  await pg.close();
  return {rate, secs, errs, r};
}
(async()=>{
  const b=await launch();
  const x4=await runRate(b,4,8);
  const x6=await runRate(b,6,8);
  await b.close();
  const out={profile:'a03s 360x800@2', x4, x6};
  console.log(JSON.stringify(out, null, 2));
  const bad=[];
  for(const q of [x4,x6]){
    const tag='x'+q.rate;
    if(q.errs.length) bad.push(tag+' JS errors '+JSON.stringify(q.errs));
    if(!q.r||q.r.ticks<60) bad.push(tag+' too few ticks '+JSON.stringify(q.r));
    if(q.r&&q.r.avgMs>16) bad.push(tag+' avg tick too slow '+q.r.avgMs.toFixed(2)+'ms');
    if(q.r&&q.r.maxMs>80) bad.push(tag+' max tick too slow '+q.r.maxMs.toFixed(2)+'ms');
  }
  if(bad.length){console.error('PERF_FAIL', bad); process.exit(1);}
  const f=q=>'x'+q.rate+' avgMs='+q.r.avgMs.toFixed(2)+' maxMs='+q.r.maxMs.toFixed(2)+' ticks='+q.r.ticks+' simTick='+q.r.tick+' active='+q.r.active.join('/');
  console.log('PERF_OK', f(x4), '|', f(x6));
})().catch(e=>{console.error(e); process.exit(1);});
