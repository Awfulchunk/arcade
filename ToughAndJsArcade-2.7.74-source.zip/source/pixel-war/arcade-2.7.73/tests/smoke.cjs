const {launch,open}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
 console.log('errs0',pg._errs);
 const r=await pg.evaluate(()=>{__tt.setSeed(5);__pw.aiPlan(0);__pw.startBattle();for(let i=0;i<900;i++)__pw.tick();const S=__pw.S;return JSON.stringify({tick:S.tick,act:S.sides.map(s=>s.active),br:S.sides.map(s=>__pw.brCount(s)),sq:S.sides.map(s=>s.sq.filter(q=>q).length),hp:S.sides.map(s=>s.circle.hp),made:S.sides.map(s=>s.stats.shapeMade),ai:S.ai&&S.ai.lessons});});
 console.log(r);console.log('errs',pg._errs);
 await pg.evaluate(()=>__pw.draw());await pg.screenshot({path:'/tmp/smoke3.png'});await b.close();})();
