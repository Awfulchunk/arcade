// Pixel War 0.4.12 fair-run harness (0.4.11 harness + optional player pixel sizes: spec.ps main, spec.ds detour, spec.os offense): same openings as the 0.4.10 fair runs (dummy 11, fair 17/11/23, left-wrap variant 19)
// plus a per-chunk trace so AI branches/guards can be seen before endMatch clears S.ai.
const SETUP=function(spec){
  const g=window.__pw;
  if(!spec.keepMem) g.clearAiMem();
  const _r=Math.random; let _u=spec.seed/4294967296; Math.random=()=>_u; g.startWith({}); Math.random=_r;
  const Pl=g.S.sides[0], A=g.S.sides[1];
  const pc=Pl.circle, ac=A.circle, W=g.C.W, H=g.C.H;
  window.__fr={spec, trace:[], snap0:null};
  const snap=sd=>({n:sd.strokes.filter(s=>!s.gate).length, pts:sd.strokes.filter(s=>!s.gate).reduce((a,s)=>a+s.pts.length,0), block:sd.wallBlockN||0});
  window.__fr.snapF=snap;
  if(spec.kind==='dummy'){
    for(let i=1;i<=140;i++){const t=i/140;g.pathExtend(0, pc.x+(ac.x-40-pc.x)*t, pc.y+(ac.y+8-pc.y)*t);}
    const wy=Math.max(H/2+24, pc.y-80);
    const w1=g.wallBegin(0,16,wy); if(w1){g.wallExtend(0,w1,150,wy);g.wallEnd(0,w1);}
    const w2=g.wallBegin(0,230,wy); if(w2){g.wallExtend(0,w2,344,wy);g.wallEnd(0,w2);}
    if(g.aiRevisePlan) g.aiRevisePlan();
    g.setSetting(0,'release',360); g.setSetting(0,'width',5); g.setSetting(0,'speed',6); g.setSetting(0,'density',5);
  }else{
    if(spec.kind==='variant'){
      const wx=40, wy0=(pc.y+ac.y)*0.45;
      for(let i=1;i<=200;i++){const t=i/200;
        g.pathExtend(0,(1-t)*(1-t)*pc.x+2*(1-t)*t*wx+t*t*ac.x,(1-t)*(1-t)*pc.y+2*(1-t)*t*wy0+t*t*ac.y);}
    }else{
      for(let i=1;i<=180;i++){const t=i/180;g.pathExtend(0, pc.x+(ac.x-pc.x)*t, pc.y+(ac.y-pc.y)*t);}
    }
    const wy=H/2+28;const pathXs=[];const Mp=Pl.paths[0];
    for(let k=1;k<(Mp.p.length>>1);k++) if(Math.abs(Mp.p[k*2+1]-wy)<18) pathXs.push(Mp.p[k*2]);
    const gapX=pathXs.length?pathXs[pathXs.length>>1]:pc.x;
    const w1=g.wallBegin(0,12,wy); if(w1){g.wallExtend(0,w1,Math.max(20,gapX-26),wy);g.wallEnd(0,w1);}
    const w2=g.wallBegin(0,Math.min(340,gapX+26),wy); if(w2){g.wallExtend(0,w2,348,wy);g.wallEnd(0,w2);}
    if(g.aiRevisePlan) g.aiRevisePlan();
    g.setSetting(0,'release',480); g.setSetting(0,'width',spec.pw||5); g.setSetting(0,'speed',7); g.setSetting(0,'density',6); g.setSetting(0,'size',spec.ps||5);
  }
  const started=g.tryStart();
  window.__fr.started=started; window.__fr.locked=!!Pl.defLocked&&!!A.defLocked;
  window.__fr.snap0={p:snap(Pl),a:snap(A)};
  g.S.paused=false;
  return {started, pc:[pc.x,pc.y], ac:[ac.x,ac.y], aiPlan:g.S.planInfo&&g.S.planInfo[1]};
};
// player moves at fixed ticks (same as 0.4.10 fair runs)
const PLAYER=function(step){
  const g=window.__pw, spec=window.__fr.spec, Pl=g.S.sides[0], A=g.S.sides[1], pc=Pl.circle, ac=A.circle, W=g.C.W, H=g.C.H;
  if(spec.kind==='dummy'){
    if(step!==240) return;
    const M2=Pl.paths[0], n2=M2.p.length>>1, fk2=Math.max(6, Math.floor(n2*0.35));
    const bx2=M2.p[fk2*2], by2=M2.p[fk2*2+1];
    const Br2=g.branchBegin(0,bx2,by2);
    if(Br2){ for(let i=1;i<=50;i++){const t=i/50; g.branchExtend(0,Br2, bx2+80*t, by2-120*t);} g.branchEnd(0,Br2); }
    return;
  }
  const wy=H/2+28, M=Pl.paths[0], n=M.p.length>>1;
  if(step===180){
    let fk=-1, rjk=-1;
    for(let k=8;k<n-8;k++){ if(fk<0 && M.p[k*2+1]<wy-16) fk=k; if(fk>=0 && k>=fk+16 && M.p[k*2+1]<wy-110){rjk=k; break;} }
    if(fk<8) fk=Math.max(8,Math.floor(n*0.40)); if(rjk<0) rjk=Math.min(n-6, fk+22);
    window.__fr.fk=fk;
    const dx0=M.p[fk*2], dy0=M.p[fk*2+1], rx=M.p[rjk*2], ry=M.p[rjk*2+1];
    let midX; if(spec.kind==='variant') midX=Math.max(16,Math.min(344, dx0<W/2?dx0+110:dx0-110)); else midX=Math.max(16,Math.min(344, dx0>180?dx0+80:dx0-80));
    const Det=g.branchBegin(0,dx0,dy0); let detour={ok:false};
    if(Det){
      for(let i=1;i<=20;i++){const t=i/20; g.branchExtend(0,Det, dx0+(midX-dx0)*t, dy0);}
      for(let i=1;i<=28;i++){const t=i/28; g.branchExtend(0,Det, midX, dy0+(ry-dy0)*t);}
      for(let i=1;i<=20;i++){const t=i/20; g.branchExtend(0,Det, midX+(rx-midX)*t, ry);}
      g.branchExtend(0,Det, rx, ry); g.branchEnd(0,Det);
      const P=g.S.sides[0].paths[Det.id];
      if(P){P.share=35; P.set=P.set||{}; P.set.release=400; P.set.speed=7; P.set.width=4; P.set.density=6; P.set.size=spec.ds||spec.ps||5;}
      detour={ok:!!P && P.rj>=0 && (P.rjTo||0)===0, id:Det.id};
    }
    window.__fr.detour=detour;
  }
  if(step===240){
    const fk=window.__fr.fk;
    const fk2=Math.max((fk>=0?fk:8)+12, Math.floor(n*0.58));
    const bx=M.p[Math.min(n-3,fk2)*2], by=M.p[Math.min(n-3,fk2)*2+1];
    const Off=g.branchBegin(0,bx,by); let offense={ok:false};
    if(Off){
      const vx=spec.kind==='variant'?Math.max(20, ac.x-80):Math.min(340, ac.x+70);
      for(let i=1;i<=80;i++){const t=i/80;g.branchExtend(0,Off,bx+(vx-bx)*t*(1-t)*2+(ac.x-bx)*t*t, by+(ac.y-by)*t);}
      g.branchEnd(0,Off);
      const P=g.S.sides[0].paths[Off.id];
      if(P){P.share=50; P.set=P.set||{}; P.set.release=520; P.set.speed=8; P.set.width=spec.ow||3; P.set.density=7; P.set.size=spec.os||spec.ps||5;}
      offense={ok:!!P && (P.p.length>>1)>=8, id:Off.id};
    }
    window.__fr.offense=offense;
  }
};
const TRACE=function(){
  const g=window.__pw, ai=g.S.ai, A=g.S.sides[1], Pl=g.S.sides[0];
  const br=[];for(let b=1;b<A.paths.length;b++){const P=A.paths[b];if(P)br.push({id:b,job:P.job,w:P.set&&P.set.width,z:P.set&&P.set.size,rel:P.set&&P.set.release,n:P.p.length>>1,circ:A.pathCirc[b]||0,rj:P.rj,k:A.pathKill[b]||0,l:A.pathLoss[b]||0});}
  const pb=[];for(let b=0;b<Pl.paths.length;b++){const P=Pl.paths[b];if(P)pb.push({id:b,circ:Pl.pathCirc[b]||0,k:Pl.pathKill[b]||0,l:Pl.pathLoss[b]||0});}
  return {t:g.S.tick,act:[Pl.active,A.active],pool:[Pl.pool,A.pool],mainCirc:A.pathCirc[0]||0,mk:A.pathKill[0]||0,ml:A.pathLoss[0]||0,pb,aiHp:Math.round(A.circle.hp),pHp:Math.round(Pl.circle.hp),aiDmg:A.stats.circleDmg,pDmg:Pl.stats.circleDmg,aiK:A.stats.kills,pK:Pl.stats.kills,br,mw:A.set.width,mz:A.set.size,mrel:A.set.release,lessons:ai?ai.lessons.slice(-3):null};
};
const RESULT=function(){
  const g=window.__pw, A=g.S.sides[1], Pl=g.S.sides[0], fr=window.__fr, snap=fr.snapF;
  const atEnd={p:snap(Pl),a:snap(A)};
  const standing = Pl.circle.hp>A.circle.hp ? 'player ahead' : A.circle.hp>Pl.circle.hp ? 'AI ahead' : 'draw';
  return {tick:g.S.tick, over:!!g.S.over, winner:g.S.winner, standing, aiHits:A.stats.circleDmg, pHits:Pl.stats.circleDmg, aiHp:Math.round(A.circle.hp), pHp:Math.round(Pl.circle.hp),
    aiKills:A.stats.kills, pKills:Pl.stats.kills, started:fr.started, locked:fr.locked, detour:fr.detour, offense:fr.offense,
    wallsUnchanged: JSON.stringify(fr.snap0.p)===JSON.stringify(atEnd.p)&&fr.snap0.a.n===atEnd.a.n&&fr.snap0.a.pts===atEnd.a.pts, aiNeverTried:atEnd.a.block===0,
    mem:{matches:g.AIMEM.matches,wins:g.AIMEM.wins,losses:g.AIMEM.losses}};
};
async function runFight(pg,spec,maxTicks){
  maxTicks=maxTicks||2400;
  const info=await pg.evaluate(SETUP,spec);
  const trace=[];let t=0;
  while(t<maxTicks){
    const r=await pg.evaluate((t,P)=>{const g=window.__pw;(new Function('return '+P)())(t);for(let i=0;i<30;i++){if(g.S.over)break;g.tick();}return {over:!!g.S.over};},t,PLAYER.toString());
    t+=30;
    if(t%120===0||r.over){const tr=await pg.evaluate(TRACE);trace.push(tr);}
    if(r.over)break;
  }
  const res=await pg.evaluate(RESULT);
  return Object.assign({name:spec.name,kind:spec.kind,seed:spec.seed,info},res,{trace});
}
const SPECS=[
  {kind:'dummy', seed:11, name:'dummy-11'},
  {kind:'fair', seed:17, name:'fair-17'},
  {kind:'fair', seed:11, name:'fair-11'},
  {kind:'fair', seed:23, name:'fair-23'},
  {kind:'variant', seed:19, name:'variant-19-leftwrap'}
];
module.exports={runFight,SPECS};
