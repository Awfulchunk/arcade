const {launch,open}=require('./lib.cjs');const {runFight,SPECS}=require('./fairlib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 const only=process.argv[2];
 for(const sp of SPECS){if(only&&sp.name!==only)continue;const r=await runFight(pg,sp,+process.env.MT||2400);
  console.log('RUN',sp.name,r.standing,'aiHits',r.aiHits,'pHits',r.pHits,'hp',r.aiHp,'/',r.pHp,'tick',r.tick,'walls',r.wallsUnchanged,r.aiNeverTried,'plan',JSON.stringify(r.info));
  if(process.env.V)for(const tr of r.trace)console.log('  ',JSON.stringify(tr));}
 console.log('ERRS',JSON.stringify(pg._errs));await b.close();})();
