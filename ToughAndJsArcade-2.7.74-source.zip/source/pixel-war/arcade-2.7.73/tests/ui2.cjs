// 0.4.2 touch flows (real touch input): STEP 1 path, STEP 2 defense, START gate, branches in the match with own colour/meter, tap-to-pick path, +/- slider buttons per path, walls to the screen edge, sandbox, menu/help
const {launch,open}=require('./lib.cjs');
const R=[];const ok=(n,c,i)=>{R.push([c?'PASS':'FAIL',n,c?'':String(i)]);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{try{await main();}catch(e){for(const r of R)console.log(r.join(' '));console.log('CRASH',e.stack.split('\n').slice(0,4).join(' | '));process.exit(2);}})();
async function main(){const b=await launch();
 for(const [w,h,d] of [[360,800,2],[320,568,2]]){
 const pg=await open(b,w,h,d,{mobile:true});const tag=w+'x'+h+' ';
 const L=()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS,r:{l:r.left,t:r.top,w:r.width,h:r.height}};});
 async function tdrag(pts){const l=await L();const q=pts.map(p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s}));const t=await pg.touchscreen.touchStart(q[0].x,q[0].y);for(const p of q.slice(1))await t.move(p.x,p.y);await t.end();}
 async function sdrag(pts){const t=await pg.touchscreen.touchStart(pts[0][0],pts[0][1]);for(const p of pts.slice(1))await t.move(p[0],p[1]);await t.end();}
 const ev=(f,a)=>pg.evaluate(f,a);
 const tp=async sel=>{await wait(120);try{await pg.tap('#status');}catch(e){}await wait(60);await pg.evaluate(s=>{const e=document.querySelector(s);if(e&&e.closest('#sl'))e.scrollIntoView({block:'nearest'});},sel);await wait(60);await pg.tap(sel);};
 await ev(()=>{__tt.setSeed(41);});await wait(3300);
 const c=await ev(()=>({x:__pw.S.sides[0].circle.x,y:__pw.S.sides[0].circle.y}));
 ok(tag+'START is dimmed before the plan is drawn and clicking it does not start',await ev(()=>document.getElementById('tStart').classList.contains('wait')),'');
 await tp('#tStart');ok(tag+'START refused with no path/defense (stays in prep)',await ev(()=>__pw.S.phase)==='prep');
 await tp('#tMain');await tdrag([[c.x,c.y],[c.x+4,c.y-80],[c.x+20,c.y-170],[c.x+10,c.y-260],[c.x-20,c.y-340]]);
 let pu=await ev(()=>__pw.pathUsed(__pw.S.sides[0]));ok(tag+'STEP 1: main path drawn by touch ('+Math.round(pu)+'u)',pu>250,pu);
 await tp('#tStart');ok(tag+'START still refused: the DEFENSE line is missing ('+await ev(()=>__pw.prepNeeds(__pw.S.sides[0]).join('+'))+')',await ev(()=>__pw.S.phase==='prep'&&__pw.prepNeeds(__pw.S.sides[0]).join()==='wall'));
 // wall dragged past the screen edge: ends exactly at the field edge
 const l0=await L();const sy=l0.y+330*l0.s;await tp('#tWall');await sdrag([[l0.x+120*l0.s,sy],[l0.x+60*l0.s,sy],[2,sy]]);
 const wx=await ev(()=>{const st=__pw.S.sides[0].strokes;const p=st[st.length-1].pts;return[p[p.length-2],p[p.length-1],st.length];});ok(tag+'STEP 2: a wall dragged to the screen edge reaches x=0 ('+wx[0].toFixed(1)+')',wx[0]<=0.5&&Math.abs(wx[1]-330)<2,JSON.stringify(wx));
 await tdrag([[250,290],[335,290]]);ok(tag+'a second wall piece can be added ('+await ev(()=>Math.round(__pw.wallUsed(__pw.S.sides[0])))+'u of the wall meter used)',await ev(()=>__pw.S.sides[0].strokes.length>=2));
 await wait(200);ok(tag+'START lights up once the AI has drawn and I have path + defense',await ev(()=>!document.getElementById('tStart').classList.contains('wait')),'');
 await ev(()=>{window.__lc=[];document.addEventListener('click',e=>window.__lc.push(e.target.id||e.target.tagName),true);document.addEventListener('touchstart',e=>window.__lc.push('ts:'+(e.target.id||e.target.tagName)),true);});await tp('#tStart');await wait(700);const bs0=await ev(()=>({lc:window.__lc.join(),ph:__pw.S.phase,t:__pw.S.tick,msg:__pw.S.msg,needs:__pw.prepNeeds(__pw.S.sides[0]).join(),rev:__pw.S.aiRev,paused:__pw.S.paused}));ok(tag+'START begins the match',bs0.ph==='battle'&&bs0.t>20,JSON.stringify(bs0));
 ok(tag+'branch/wall/erase tools shown in battle; circle/path/gate tools hidden or still allowed per rules',await ev(()=>document.getElementById('tBranch').style.display==='block'&&document.getElementById('tCircle').style.display==='none'));
 // branch drawn in the match
 const pm=await ev(()=>{const p=__pw.S.sides[0].paths[0].p;return[p[60],p[61]];});
 await tp('#tBranch');await tdrag([[pm[0],pm[1]],[pm[0]+40,pm[1]-20],[pm[0]+90,pm[1]-60],[pm[0]+120,pm[1]-110]]);
 let br=await ev(()=>({n:__pw.brCount(__pw.S.sides[0]),sel:__pw.selP,chip:[...document.querySelectorAll('#chips button')].map(e=>e.textContent),slh:document.getElementById('slh').textContent,col:document.getElementById('slh').style.color}));
 ok(tag+'BRANCH drawn in the match gets its own chip and its own colour ('+br.chip.join('/')+', '+br.col+')',br.n===1&&br.sel===1&&br.chip.length===2&&/BRANCH 1/.test(br.chip[1])&&/BRANCH 1/.test(br.slh),JSON.stringify(br));
 await tp('#tErase');await tdrag([[30,420],[60,430]]);await tp('#tBranch');
 // per-path sliders with the big +/- buttons
 const w0=await ev(()=>[__pw.S.sides[0].paths[1].set.width,__pw.S.sides[0].set.width]);
 await tp('.pm[data-for="sWd"][data-d="1"]');await tp('.pm[data-for="sWd"][data-d="1"]');await tp('.pm[data-for="sDe"][data-d="-1"]');
 const w1=await ev(()=>[__pw.S.sides[0].paths[1].set.width,__pw.S.sides[0].set.width,__pw.S.sides[0].paths[1].set.density,__pw.S.sides[0].set.density]);
 ok(tag+'big + / - buttons change ONLY the picked branch (branch width '+w0[0]+'->'+w1[0]+', main width stays '+w1[1]+')',w1[0]===w0[0]+2&&w1[1]===w0[1]&&w1[2]===(w0[0]&&w1[3]-1)||w1[0]===w0[0]+2&&w1[1]===w0[1],JSON.stringify([w0,w1]));
 // tap the main path on the field to pick it
 const l1=await L();const mp=await ev(()=>{const p=__pw.S.sides[0].paths[0].p;return[p[120],p[121]];});
 await pg.touchscreen.tap(l1.x+mp[0]*l1.s,l1.y+mp[1]*l1.s);await wait(250);
 ok(tag+'tap on the main path picks it ("'+await ev(()=>document.getElementById('slh').textContent)+'")',await ev(()=>__pw.selP===0&&/MAIN/.test(document.getElementById('slh').textContent)));
 await tp('.pm[data-for="sSp"][data-d="1"]');ok(tag+'pace + on MAIN changes the main path only',await ev(()=>__pw.S.sides[0].set.speed===6&&__pw.S.sides[0].paths[1].set.speed===5),await ev(()=>[__pw.S.sides[0].set.speed,__pw.S.sides[0].paths[1].set.speed]));
 await tp('#btnPause');const a=await ev(()=>__pw.S.tick);await wait(500);const a2=await ev(()=>__pw.S.tick);ok(tag+'PAUSE freezes the match',a===a2);await tp('#btnPause');
 await tp('#btnMenu');await tp('#mHelp');const help=await ev(()=>document.getElementById('hbody').textContent);
 ok(tag+'HELP is plain words: short, covers sandbox/defense/branches/sliders/leash, no jargon ('+help.length+' chars)',help.length<2600&&/sandbox/i.test(help)&&/defen[cs]e/i.test(help)&&/branch/i.test(help)&&/slider/i.test(help)&&/fade|leash/i.test(help)&&!/rho|kSurv|poff|hitbox|DEFCFG/i.test(help),help.slice(0,120));
 await tp('#hBack');
 // sandbox from the menu (HELP returns to the menu)
ok(tag+'menu has a SANDBOX button',await ev(()=>!!document.getElementById('mSandbox')&&document.getElementById('mSandbox').offsetParent!==null));
 await tp('#mSandbox');await wait(300);
 let sb=await ev(()=>({sbx:__pw.sbx(),ph:__pw.S.phase,paused:__pw.S.paused,over:__pw.S.over,swap:document.getElementById('tSwap').style.display,refill:document.getElementById('tRefill').style.display,step:document.getElementById('btnStep').style.display,status:document.getElementById('status').textContent}));
 ok(tag+'SANDBOX opens paused with SIDE, REFILL and STEP buttons ('+sb.status+')',sb.sbx&&sb.ph==='battle'&&sb.paused&&sb.swap!=='none'&&sb.refill!=='none'&&sb.step!=='none',JSON.stringify(sb));
 const c0=await ev(()=>({x:__pw.S.sides[0].circle.x,y:__pw.S.sides[0].circle.y}));
 await tp('#tMain');await tdrag([[c0.x,c0.y],[c0.x,c0.y-100],[c0.x+30,c0.y-200]]);
 await tp('#tSwap');await tp('#tCircle');await tdrag([[200,60],[210,70]]);
 const c1=await ev(()=>({me:__pw.ME,x:__pw.S.sides[1].circle.x,y:__pw.S.sides[1].circle.y}));
 await tp('#tMain');await tdrag([[c1.x,c1.y],[c1.x,c1.y+100],[c1.x-30,c1.y+200]]);
 const both=await ev(()=>[__pw.pathUsed(__pw.S.sides[0]),__pw.pathUsed(__pw.S.sides[1]),__pw.ME]);
 ok(tag+'SANDBOX: I drew a path for BLUE and then, after SIDE, moved the RED circle and drew its path ('+both.map(Math.round)+')',both[0]>60&&both[1]>60&&both[2]===1,JSON.stringify(both));
 await tp('#btnPause');await wait(800);const s1=await ev(()=>__pw.S.tick);await tp('#tWall');await tdrag([[100,250],[200,250]]);
 ok(tag+'SANDBOX: running, I can still draw a wall mid-run ('+await ev(()=>__pw.S.sides[1].strokes.length)+' wall pieces for RED), no one wins',s1>20&&await ev(()=>__pw.S.sides[1].strokes.length>=1&&!__pw.S.over));
 await tp('#tRefill');ok(tag+'REFILL clears the field and restores pools',await ev(()=>__pw.S.sides[0].active+__pw.S.sides[1].active===0));
 ok(tag+'0 JS errors',pg._errs.length===0,pg._errs);await pg.close();}
 await b.close();let f=0;for(const r of R){console.log(r.join(' '));if(r[0]==='FAIL')f++;}console.log('UI2 '+(R.length-f)+' pass / '+f+' fail');process.exit(f?1:0);}
