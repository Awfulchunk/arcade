// 0.3 hits -> out/hits/*.png  (360x800 @2 = 720x1600 device px, "A03s" sized; zoom crops at @4)
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar042/out/hits/';fs.mkdirSync(OUT,{recursive:true});
for(const f of fs.readdirSync(OUT))if(f.endsWith('.png'))fs.unlinkSync(OUT+f);
const SH=['line','arrow','wedge','ring','diamond','double','spiral'];
const HELP=`
window.__H={mk(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};},
 game(seed,cfg){const P=__pw;P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed,false);P.setRnd(this.mk(seed));return P;},
 main(P,pts){for(const k of pts||[[180,400],[184,330],[190,260],[196,190],[196,130]])P.pathExtend(0,k[0],k[1]);},
 quiet(P){const f=P.S.sides[1];f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];f.circle.x=60;f.circle.y=44;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);},
 squad(P){let n=0,sx=0,sy=0,mnx=1e9,mxx=-1e9,mny=1e9,mxy=-1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){n++;sx+=P.px[i];sy+=P.py[i];mnx=Math.min(mnx,P.px[i]);mxx=Math.max(mxx,P.px[i]);mny=Math.min(mny,P.py[i]);mxy=Math.max(mxy,P.py[i]);}return n?{n,x:sx/n,y:sy/n,w:mxx-mnx,h:mxy-mny}:null;},
 shot(P){P.S.paused=true;P.draw();}};`;
(async()=>{const b=await launch();let pg;
 const L=async()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const click=async id=>{await new Promise(r=>setTimeout(r,120));await pg.click('#'+id);};
 async function drag(pts){const l=await L();const q=pts.map(p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s}));await pg.mouse.move(q[0].x,q[0].y);await pg.mouse.down();for(const p of q.slice(1))await pg.mouse.move(p.x,p.y,{steps:4});await pg.mouse.up();}
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const fresh=async(dpr)=>{pg=await open(b,360,800,dpr||2,{mobile:true});await pg.evaluate(HELP);};
 const snap=async(name,clip)=>{await sleep(160);const o={path:OUT+name+'.png'};if(clip)o.clip=clip;await pg.screenshot(o);};
 // 01 prep: path, branches, walls
 await fresh();await pg.evaluate(()=>__tt.setSeed(5));await click('tCircle');await drag([[180,456],[180,456]]);await click('tMain');
 await drag([[180,456],[184,380],[196,300],[200,220],[196,140]]);
 const pt=i=>pg.evaluate(i=>{const p=__pw.S.sides[0].paths[0].p;return[p[i*2],p[i*2+1]];},i);
 await click('tBranch');let a=await pt(30);await drag([a,[a[0]-50,a[1]-25],[a[0]-95,a[1]-70],[a[0]-120,a[1]-130]]);
 a=await pt(60);await drag([a,[a[0]+50,a[1]-20],[a[0]+100,a[1]-55],[a[0]+130,a[1]-110]]);
 await click('tWall');await drag([[40,405],[100,392],[150,390]]);await drag([[215,390],[270,392],[320,405]]);
 await pg.evaluate(()=>{__pw.S.paused=true;});await snap('01-prep-path-branches-walls');
 console.log('prep',await pg.evaluate(()=>({br:__pw.brCount(__pw.S.sides[0]),pu:Math.round(__pw.pathUsed(__pw.S.sides[0])),wu:Math.round(__pw.wallUsed(__pw.S.sides[0]))})),pg._errs);
 await click('tabS');await sleep(150);await snap('02-prep-shape-tab-six-abilities-no-ring');await pg.close();
 // 03..08 each shape on the main path, quiet foe: full screen @2 + zoom @4. Pools 10000 / density 7.
 const order=[0,1,2,4,5,6];let k=3;
 for(const t of order){const nm=String(k).padStart(2,'0')+'-shape-'+SH[t]+'-inside-lane';
  const run=async dpr=>{await fresh(dpr);return pg.evaluate(t=>{const P=__H.game(30+t);P.placeCircle(0,180,456);__H.main(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);const sd=P.S.sides[0];sd.set.density=7;sd.set.speed=5;sd.set.release=9;
   for(let i=0;i<150;i++)P.tick();P.useShape(0,0,t);let g=0;for(;g<200;g++){P.tick();const q=sd.sq.find(x=>x);if(q&&!q.open)break;}for(let i=0;i<70;i++)P.tick();
   const s=__H.squad(P);__H.shot(P);return{shape:t,sq:s,lane:P.laneHW(sd.set),hudTab:document.getElementById('pS').style.display};},t);};
  let r=await run(2);await pg.evaluate(()=>{});await pg.evaluate(()=>{document.getElementById('tabS').click();});await sleep(100);await pg.evaluate(()=>__H.shot(__pw));await snap(nm);console.log(SH[t],JSON.stringify(r));await pg.close();
  r=await run(4);const c=r.sq;const L2=await L();await pg.evaluate(()=>__H.shot(__pw));
  await snap(nm+'-zoom',{x:Math.max(0,L2.x+c.x*L2.s-70),y:Math.max(0,L2.y+c.y*L2.s-70),width:140,height:140});await pg.close();k++;}
 // 09/10 arrow vs enemy straight lines: loose path (punches through) vs dense line (stalls). Impact + aftermath.
 const vs=async(name,en,dpr)=>{await fresh(2);
  const r=await pg.evaluate(en=>{const P=__H.game(2);P.placeCircle(0,180,456);__H.main(P,[[180,400],[180,300],[180,200],[180,140]]);P.placeCircle(1,300,50);const E=P.S.sides[1];for(const q of[[300,150],[300,250],[240,250],[180,250],[120,250],[60,250]])P.pathExtend(1,q[0],q[1]);
   const m=P.S.sides[0];m.set.release=5;m.set.density=7;m.set.speed=5;E.set.release=en.rel;E.set.density=en.den;E.set.speed=en.spd;m.human=true;E.human=true;P.startBattle();
   for(let t=0;t<200;t++)P.tick();P.useShape(0,0,1);let t0=-1,out={};for(let t=0;t<800;t++){P.tick();let ny=1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4&&P.py[i]<ny)ny=P.py[i];if(t0<0&&ny<262)t0=t;if(t0>=0&&t===t0+14){out.impact=__H.squad(P);__H.shot(P);window.__hit1=1;break;}}
   return out;},en);
  document_=0;await pg.evaluate(()=>{document.getElementById('tabS').click();});await sleep(80);await snap(name+'-a-impact');
  const r2=await pg.evaluate(()=>{const P=__pw;P.S.paused=false;for(let t=0;t<130;t++)P.tick();let alive=0,beyond=0,minY=1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){alive++;if(P.py[i]<235)beyond++;minY=Math.min(minY,P.py[i]);}__H.shot(P);return{alive,beyond,minY:Math.round(minY),stats:{defl:P.S.sides[0].stats.defl}};});
  await snap(name+'-b-after');console.log(name,JSON.stringify(r.impact),JSON.stringify(r2));await pg.close();};
 var document_;
 await vs('09-arrow-vs-LOOSE-path-punches-through',{rel:4,den:3,spd:7});
 await vs('10-arrow-vs-DENSE-line-stalls',{rel:7,den:10,spd:3});
 // 11 cooldown UI in battle: ARROW recharging (bar), others READY, WEDGE just fired too
 await fresh();await pg.evaluate(()=>{const P=__H.game(5);P.placeCircle(0,180,456);__H.main(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);for(let i=0;i<260;i++)P.tick();P.useShape(0,0,1);for(let i=0;i<150;i++)P.tick();P.useShape(0,0,2);for(let i=0;i<60;i++)P.tick();__H.shot(P);document.getElementById('tabS').click();});
 await sleep(100);await pg.evaluate(()=>{document.getElementById('tabS').click();__H.shot(__pw);});await snap('11-cooldown-ui-arrow-wedge-recharging');
 console.log('cd',await pg.evaluate(()=>[...document.querySelectorAll('#shbtns button')].map(e=>e.children[0].textContent+':'+e.children[1].textContent+':'+e.children[2].style.width).join(' | ')),pg._errs);await pg.close();
 // 12 dense battle (AI both sides, cap 10000): peak
 await fresh();const d=await pg.evaluate(()=>{const P=__H.game(5,{capDef:10000,burn:1});P.placeCircle(0,180,456);P.aiPlan(0);P.S.sides[1].human=false;P.startBattle();for(const s of P.S.sides){s.set.release=10;s.set.speed=2;s.set.density=7;s.set.cap=10000;}
  let pk=0,g=0;for(;g<2400;g++){P.tick();pk=Math.max(pk,P.S.sides[0].active+P.S.sides[1].active);if(g>600&&P.S.sides[0].active>5500&&P.S.sides[1].active>5500)break;}
  __H.shot(P);document.getElementById('tabF').click();return{act:P.S.sides.map(s=>s.active),pool:P.S.sides.map(s=>s.pool),tick:P.S.tick,over:P.S.over};});
 console.log('dense',JSON.stringify(d));await pg.evaluate(()=>__H.shot(__pw));await snap('12-dense-battle-10k-pool');await pg.close();
 // 13 wall damage -> hole where the enemy keeps hitting
 const wrun=async dpr=>{await fresh(dpr);return pg.evaluate(()=>{const P=__H.game(6,{burn:1});P.placeCircle(0,180,456);for(const q of[[120,420],[60,330],[60,200]])P.pathExtend(0,q[0],q[1]);
  const st=P.wallBegin(0,130,330);P.wallExtend(0,st,230,330);P.wallEnd(0,st);P.placeCircle(1,180,44);const E=P.S.sides[1];for(const q of[[180,150],[180,250],[180,290]])P.pathExtend(1,q[0],q[1]);
  E.set.release=10;E.set.density=9;E.set.speed=4;P.S.sides[0].human=true;E.human=true;P.startBattle();const sd=P.S.sides[0];let first=-1,hole=-1;
  for(let t=0;t<2400;t++){P.tick();const dead=sd.segs.filter(g=>!g.alive).length;if(first<0&&sd.segs.some(g=>g.hp<P.cellHP()))first=t;if(hole<0&&dead>=2){hole=t;}if(hole>=0&&t>hole+90)break;}
  __H.shot(P);return{cells:sd.segs.length,dead:sd.segs.map((g,k)=>g.alive?-1:k).filter(k=>k>=0),firstDamage:first,hole,hp:sd.segs.map(g=>Math.round(g.hp)).join(',')};});};
 const w=await wrun(2);
 console.log('wall',JSON.stringify(w));await pg.evaluate(()=>__H.shot(__pw));await snap('13-wall-damage-hole-at-impact-spot');await pg.close();
 await wrun(4);{const L2=await L();await pg.evaluate(()=>__H.shot(__pw));await snap('13-wall-damage-hole-zoom',{x:L2.x+130*L2.s,y:L2.y+290*L2.s,width:100*L2.s,height:80*L2.s});}await pg.close();
 // 14 result screen (pool = HP, lives stats)
 await fresh();await pg.evaluate(()=>{__tt.setSeed(10);__tt.step(1);let t=0;while(!__tt.getState().over&&t<12000){__tt.step(30);t+=30;}});await sleep(300);await snap('14-result-pool-hp-and-lives');
 console.log('end',await pg.evaluate(()=>({w:__pw.S.winner,t:__pw.S.tick,hp:__pw.S.sides.map(s=>s.circle.hp),r:document.getElementById('rBody').innerText.slice(0,200)})),pg._errs);await pg.close();
 // 15-17 custom game (pool/lives/burn rows), help, menu
 await fresh();await pg.click('#btnMenu');await sleep(200);await pg.click('#mCustom');await sleep(300);await snap('15-custom-game-top');
 await pg.evaluate(()=>{const e=document.getElementById('clist');e.scrollTop=e.scrollHeight*0.3;});await sleep(100);await snap('16-custom-game-mid');
 await pg.click('#cBack');await sleep(200);await pg.click('#mHelp');await sleep(200);await snap('17-help');await pg.close();
 await b.close();})();
