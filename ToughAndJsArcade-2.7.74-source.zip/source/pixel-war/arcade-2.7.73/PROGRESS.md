# Pixel War 0.4.11 — progress

**Status: built and tested in one pass (t1181), NOT shipped.** Staged at `requests/finished-ship/pixelwar-0.4.11-test/`.

Worktree: `/workspace/game/build-pixelwar0411/`. 0.4.10 (build and stage) was not changed.

## t1196 changes (all batched, one build)

1. LANE SHAPE button hidden; LANE WIDTH slider only; every path forced NORMAL.
2. Shapes removed for now (hidden, code kept). No shape logic runs for either side.
3. AI-RULES.md written; the AI follows it (objective, mechanics, SHOULD / SHOULDN'T).
4. Smarter AI:
   - guard branches meet a stream head-on at your width +2;
   - main width match;
   - a spare branch for defense, and a flow budget;
   - side approach;
   - spawn-zone clash fix;
   - no stub branches;
   - habit learning plus counters, with a built-in prior from our own test games.
5. Locked rules kept. Save keys v411 with a v410 fallback. Label 0.4.11.

## The one test pass (2026-11-19, 00:04–00:08 America/Los_Angeles)

- Build: `node --check` clean; `esbuild --target=chrome83` OK.
- Fair runs (`tests/fair0411.cjs`). Memory was cleared each run. Each match was played to the real end (circle destroyed, or the 5-minute timer).

| run | winner | AI hits | player hits | AI HP | time |
|---|---|---:|---:|---:|---:|
| dummy 11 | AI | 501 | 0 | 10000 | 28 s |
| fair 17 | AI | 500 | 34 | 9320 | 223 s |
| fair 11 | AI | 500 | 264 | 4720 | 31 s |
| fair 23 | AI | 500 | 265 | 4700 | 47 s |
| variant 19 | AI | 500 | 117 | 7660 | 90 s |

In 0.4.10, fair 23 and variant 19 were losses. 0 mid-match walls; the player's detour and offense connected in every run.

- Own checks (`tests/checks0411.cjs`): **25 pass / 0 fail**. They cover:
  - lanes and shapes hidden and forced off;
  - no shape pixels;
  - no mid-match walls;
  - guard within 40 ticks, 85% head-on overlap, width 5→7, 8→10, 10→10;
  - wide-player test: 31 hits conceded vs 1000 with the new AI off;
  - 3-match learning series won;
  - habits learned and countered;
  - v410 prefs and memory fallback;
  - DELETE clears v411 and v410;
  - density measured;
  - 0 stuck pixels;
  - 0 JS errors.
- A03s 360x800@2 (sim tick time):
  - x4: avg 0.67 ms, max 12.8 ms;
  - x6: avg 0.97 ms, max 19.9 ms;
  - no JS errors.
- tt `--all --name=pixelwar-0411-t1196`: **pass 67 / fail 0 / warn 3 / skip 4 / info 5**. Soak frame rate: 60 fps at 4x, 59.8 fps at 6x. The warns are the same 3 as 0.4.10: a03s off-screen controls, and uneven-scale letterboxing twice.
