# Pixel War 0.4.12 — AI rule book (Jay t1196, updated for t1199 / t1200)

The AI code follows this file. Each rule names the function that does it.

## Objective

1. **Win the match:** bring the enemy circle to 0 HP first. If the 5-minute timer runs out, the side with more circle HP wins (the existing win condition, `endMatch`).
2. **Protect my own circle.** Defending is half the objective, not an extra.

## How the game works (the AI plays by exactly these rules, same as the player)

- **Paths are roads.** A path or branch only gives direction. The lane (hitbox) is a road: pixels wander inside it and are never pulled to the centerline.
- **Lane width** is set with the LANE WIDTH slider (1–10). 10 = the circle diameter, the max. There is only one lane type (NORMAL); the lane-shape button is gone.
- **Flow** is 200–1000 pixels on the field per path at once, as a steady stream. Every branch has its own flow. A side can have at most `cap` (1000) pixels out at once, so flow given to one path is flow taken from another.
- **Old density is gone** (t1199). Its effect is off for both sides (hidden; the code is kept). Nothing can bring it back: the setters force it to the neutral 5, and old saves and old AI memory (`tune.density`, `habits.density`) are dropped on load (`DENSITY_OFF`, `densOf`).
- **DENSITY slider = PIXEL SIZE** (t1200), 1 tiny to 10 huge, set per path like the other sliders. Size 5 is exactly the 0.4.11 pixel (HP 2, damage 1, the locked values).
  - Bigger pixels draw bigger, have a bigger hit radius (3.5 at size 5, up to 4.0 at 10), are a bit tougher (some spawn with 3 HP) and hit a bit harder (some hits do 2), and hit the circle and walls harder. But fewer come out for the same flow (0.88x at size 10), and they stay a little further in from the lane edges (fewer fit side by side).
  - Smaller pixels are weaker (some spawn with 1 HP, some hits do 0) but harder to hit (up to 6% at size 1), and more come out for the same flow (1.12x at size 1), so they swarm and cover the lane.
  - Flow is a pixel budget: the same flow does the same total circle damage at any size.
  - Measured in head-on duels (same flow and width, sides swapped): big wins slightly more contacts (kills 52–56%), small holds the front; neither wins outright (see FEATURES-0412.md for the numbers).
- **Pace** is how fast the pixels move.
- **Contacts:** when enemy pixels touch they bounce or die. Ricochet is random and short; a bounced pixel keeps flying straight.
- **Past a path end** pixels keep going one way as a loose group, then fade.
- **Branches** are drawn only during the match, from the main path, each with its own meter (400). Erasing a branch is free.
- **Detour merge / loop-connect:** a branch drawn back into its own main lane (anywhere in the lane hitbox, or a finger from it, downstream or upstream) connects, and pixels rejoin. A pixel can loop at most 2 times.
- **Defense line:** drawn in prep, it locks at START. Nobody (player or AI) builds, rebuilds or erases walls during the match.
- **Shapes are off** (hidden). No shape or formation logic runs for either side.

## The AI SHOULD

1. **Block a branch heading for its circle.** When an enemy stream (a branch, or the main once it is really landing) is heading for the AI circle, the AI meets it **head-on** in front of its circle with a **guard branch** that runs back up the enemy lane (`aiThreats`, `aiOpenGuard`, `aiGuardStep`). It reacts within about 1–2 s of seeing a new enemy branch (the AI thinks once a second; `ai.react` adds 0.3–0.75 s, learned).
2. **Match the enemy lane width and catch the outer pixels.** A guard lane is the enemy lane width **+2**, up to 10, the circle diameter (`aiGuardW`). It re-matches whenever the player changes width. When the two main lanes meet, the AI main is never thinner than the enemy main +1 (`aiMainContest`).
3. **Keep one branch spare for defense** until a guard is up (`aiReserve`). If every branch slot is taken when a threat appears, it erases its weakest attack branch to free one (`aiFreeSlot`). Erasing is free.
4. **Feed a guard enough flow** to absorb the incoming stream: at least the enemy flow +80. It steps the guard's pixel size up if the guard is losing contacts. Guards are never starved or dropped for having no circle hits. A guard is released only when its stream is gone or no longer threatens.
5. **Attack the enemy circle from the side.** The main path and attack branches finish on the enemy circle from the side, away from the lanes the enemy streams leave by, so the attack is not a 1:1 head-on trade (`aiApproach`).
6. **Route through the weakest part of the enemy defense**, or around an end (`aiDefenseRoute`). Off-center circles take the shortest outer wrap.
7. **Read the clash honestly.** A losing clash cuts flow (never below 400) and reroutes. The enemy's own spawn zone is not a clash, and a clash needs AI pixels there too (`aiPathClash`).
8. **Surge when the enemy's flow is split** across branches.
9. **Learn the player.** Every match it records what the player did (`aiObserve`) and merges it into its memory at the end (`aiHabitsCommit`): when they branch and how many branches, main width, **main pixel size**, **attack-branch pixel size**, pace and flow, attack-branch width, detours, loops, attack side, straight shots. Next match it counters (`aiCounterHabits`):
   - main pixel size against the player's usual main size: vs big (7+) it meets big with big (7); vs small (3 or less) it goes a bit big (6) and wins the contacts; otherwise 5. (Tested in 0.4.12: going small (3) against a size-8 main lost the 3rd learning match and let 270-360 player pixels through; size 7 let 1-23 through.)
   - flow at least the player's usual +40;
   - faster reaction if the player branches a lot;
   - guards the main early against a straight shooter;
   - meets the stream closer to its circle against a detour player (after their rejoin point);
   - covers the usual attack-branch width.
10. **Start from what it already knows.** Every game recorded in our own test runs (0.4.10 fair 17 / 11 / 23, left-wrap variant 19, dummy 11) is built in as a prior worth 3 matches (`AISEED`). The player's real matches outweigh it fast.

11. **Pick pixel sizes by job** (`aiSizeFor`, switch `AIR.size`):
   - **punch** branch: big (8): survives contacts on the way and hits the circle harder;
   - **intercept**: 7, to win the contacts where it cuts your branch;
   - **guard**: small (3) so more pixels cover your whole lane and catch the outer pixels; 4 against a huge (8+) stream;
   - **block** (wide lane): small (3), for coverage;
   - **main / flank / detour**: the counter to your usual main size (above).
   - A guard that keeps losing contacts steps up one size (at most 6, at most once every 4 s). When the AI is behind, its main switches to the counter of your live main size.
   - After a loss, its remembered setup flips its main size against your usual size (7 vs big, 6 vs small).

## The AI SHOULDN'T

1. **Never leave its circle undefended** against an incoming stream it can see.
2. **Never waste pixels off-field.** That means no stub branches that stop short of the circle, no branch that just retraces its own main, and no branch fed into a zone it is losing for a long time (`aiBranchPointless`, drop rules).
3. **Never build, rebuild or erase walls mid-match** (locked defense line). It never retries a blocked build.
4. **Never cheat.** It uses the same API, meters, caps, cooldowns and sliders as the player, and it reads only what is on screen: lanes, pixels, hits, walls.
5. **Never use hidden features.** No lane shapes, no shapes and no old density, even from old saves or old AI memory (`LANE_SHAPES_ON` / `SHAPES_OFF` forced in `startWith`; `DENSITY_OFF`).
6. **Never pull pixels to the centerline, and never change ricochet, roam/fade or merge rules.** Those are engine rules, the same for both sides.
7. **Never wipe its memory on its own.** Only DELETE AI MEMORY in the menu clears it (that also clears the v411, v410 and older keys). The built-in prior is part of the code and stays.

## Interpretation note

Jay wrote "such as not blocking a branch from attacking its circle". This is read as a **current failure the AI must fix** (it should block such a branch), not as something the AI is forbidden to do.
