// Arcade 2.7.73 = published 2.7.72 bundle + pixelwar:latest 0.4.12 (new v0410=0.4.10), papa-potato:latest 0.4.10 (new v049=0.4.9). Swarm unchanged. Everything else byte-identical.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2773", BASE = B + "/out/base-2772.html", OUT = process.argv[2] || B + "/out/index.html";
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "cedf6243d017ab77b8905066b38c9d46a76712eac49533b3dc030c7c334ef2f7", "2.7.72 base hash");
const rd = (f) => fs.readFileSync(`${B}/out/${f}`, "utf8");
const JOBS = [
 { card: "pixelwar", newKey: "v0410", html: rd("pixel-war-0.4.12.html"), hsha: "1ba7969e6a8035542069f3029913ae286462a9e6c0a5e2997c57b36e3b3dee7d", oldSha: "63a21be4541e8fc55926e4d437fae5fa7235ee4195e0928c1ffc8f76100b7eff",
   oldName: "v0.4.10 – smarter AI, branch-to-lane loops (2.7.72)", name: "v0.4.12 – Latest (pixel size slider, rule-book AI)",
   desc: "Pixel War 0.4.12. The lane-shape button and shapes are gone for now: lane width is set only with the LANE WIDTH slider. The old density is removed; that slider now sets PIXEL SIZE (1 tiny to 10 huge, per path): big pixels are tougher and hit harder but fewer come out, small ones are weaker but swarm and cover the lane. The AI follows a written rule book: it meets a branch heading for its circle head-on with a guard about 2 width notches wider than yours to catch your outer pixels, keeps a spare branch for defense, attacks from the side, picks pixel sizes by job, and learns your habits every match. Your 0.4.10, 0.4.9, 0.4.7, 0.4.6, 0.4.5, 0.4.4, 0.4.3, 0.4.2, 0.4.1 and 0.3 stay playable with their own saves.",
   order: "v03,v041,v042,v043,v044,v045,v046,v047,v049,latest" },
 { card: "papa-potato", newKey: "v049", html: rd("papa-potato-0.4.10.html"), hsha: "ab6995d51417cac3e29200a82fd7deec9d5edc6dae2965abaea7e40d8ee49bb6", oldSha: "56322dfa0677a32e6833a309c48da2ddd7481cb932ddebdd148ab799e579f6e9",
   oldName: "v0.4.9 – wash room, water canal, stacked basin pile (2.7.72)", name: "v0.4.10 – Latest (radio, your own music, decor with real effects)",
   desc: "Papa Potato 0.4.10. The radio gets two built-in stations (POTATO FM, SPUD JAZZ) and MY MUSIC: add songs from your phone and they play small and crackly like a little kitchen radio, louder when Papa is near it (songs last until the game closes; nothing leaves the phone). New decor, every piece with a real effect: Kitchen Mat (energy drains slower), Wall Clock (shorter meals, shows the shift time), Runner Rug (walks faster), Papa Poster (works harder when lazy), Pantry Shelf (+2 food storage), Floor Fan (mess slows him less), Rubber Duck (clears the wash-basin heap faster) and Round Braid Rug (peels faster). The old plant, lamp, rug and radio got small real effects too. Your 0.4.9 save carries over; 0.4.9, 0.4.2, 0.4.1, 0.3, 0.2 and 0.1 stay playable in their own slots.",
   order: "v01,v02,v03,v041,v042,latest" },
];
for (const j of JOBS) assert(sha(j.html) === j.hsha, "staged html sha " + j.card);
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
const before = slots(src); assert(Object.keys(before).length === 175, "175 slots before");
const G0 = GS(src);
for (const j of JOBS) { j.KL = j.card + ":latest"; j.KN = j.card + ":" + j.newKey; assert(before[j.KL] && !before[j.KN], "slot state " + j.card); j.old = G0[j.KL];
  assert(j.oldPrefix ? sha(j.old).startsWith(j.oldSha) : sha(j.old) === j.oldSha, "live latest = previous version " + j.card); }
// replace latest payloads (from the end of the file backwards so offsets stay valid)
let out = src; for (const j of [...JOBS].sort((a, b) => before[b.KL][0] - before[a.KL][0])) out = out.slice(0, before[j.KL][0]) + ex(j.html) + out.slice(before[j.KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + JOBS.map((j) => ',\n"' + j.KN + '":' + ex(j.old)).join("") + out.slice(ei);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
for (const j of JOBS) { const g = GAMES.find((x) => x.id === j.card); const ids = g.versions.map((v) => v.id); if (j.order) assert(ids.join() === j.order, "card versions before " + j.card + " " + ids);
  assert(ids[ids.length - 1] === "latest" && !ids.includes(j.newKey), "latest last " + j.card);
  const L = g.versions[g.versions.length - 1]; const kept = { ...L, id: j.newKey, name: j.oldName, def: false }; const lat = { ...L, name: j.name, desc: j.desc, def: true };
  g.versions = [...g.versions.slice(0, -1), kept, lat]; }
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + (gLine.slice(12).match(/;\s*$/) || [""])[0] + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lJson = out.slice(lA + 1, lE).slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const LEG2 = { ...LEG };
for (const j of JOBS) { const rn = {}, pn = legacyParts(j.html, rn); assert(rn.jsFail.length === 0, "legacy js fail new " + j.card + " " + JSON.stringify(rn.jsFail).slice(0, 300)); assert(joinParts(pn, j.html) === legacyHtml(j.html, {}), "parts mismatch " + j.card);
  const ro = {}, po = legacyParts(j.old, ro); assert(ro.jsFail.length === 0, "legacy js fail old " + j.card); assert(JSON.stringify(LEG[j.KL]) === JSON.stringify(po), "old legacy latest == old parts " + j.card);
  LEG2[j.KL] = pn; LEG2[j.KN] = po; }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out); assert(Object.keys(after).length === 177, "177 slots after");
const changed = JOBS.map((j) => j.KL), added = JOBS.map((j) => j.KN);
for (const k of Object.keys(before)) if (!changed.includes(k)) assert(after[k][2] === before[k][2], "slot text changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k]).sort()) === JSON.stringify([...added].sort()), "only new slots");
const G1 = GS(out); for (const j of JOBS) assert(G1[j.KL] === j.html && G1[j.KN] === j.old, "payloads " + j.card);
for (const k of Object.keys(G0)) if (!changed.includes(k)) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (!changed.includes(k)) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
const cards = JOBS.map((j) => j.card);
assert(JSON.stringify(GAMES.filter((g) => !cards.includes(g.id))) === JSON.stringify(base.filter((g) => !cards.includes(g.id))), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
for (const j of JOBS) { const a = GAMES.find((g) => g.id === j.card), b = base.find((g) => g.id === j.card); const { versions: va, ...ra } = a, { versions: vb, ...rb } = b; assert(JSON.stringify(ra) === JSON.stringify(rb), "card fields " + j.card); assert(JSON.stringify(va.slice(0, -2)) === JSON.stringify(vb.slice(0, -1)), "older versions untouched " + j.card); }
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.73", versionCode: 111, baseBundleSHA256_2772: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), cartridgeSlotsBefore: 175, cartridgeSlotsAfter: 177, changedSlots: changed, newSlots: added,
  games: JOBS.map((j) => ({ card: j.card, latestSHA256: j.hsha, keptSlot: j.KN, keptSHA256: sha(j.old), versions: GAMES.find((g) => g.id === j.card).versions.map((v) => v.id) })),
  swarmUnchanged: true, swarmLatestSHA256: sha(G1["swarm:latest"]) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
