# Pixel War 0.4.11 — missing / held

Held (do not build): shapes and lane shapes (hidden, code kept, t1196), cluster dropped (t1145/t1146), turn-based (future only), 3D, automatic speed–density coupling, friendly pass-through walls, mid-match defense rebuild, per-match AI memory wipe, difficulty picker.

Open questions for Jay:
- **DENSITY barely matters in fights today.** It only calms the sideways wobble. Should it make a stream really pack tighter and win more contacts? That is a design change, so it was not made.

Known gaps:
- Jay's real games live in localStorage on his phone. The AI learns them only from now on, on the device (habits start empty; the v410 memory is kept).
- Every win so far was against scripted players that do not react. A real player who keeps switching lanes will test the guard harder.
- Some matches against a scripted player run long. The AI wins on HP at the 5-minute timer instead of breaking the circle (fair 17 took about 3.7 minutes).
