# Pixel War 0.4.11 — feature checklist (Jay t1196)

Built from 0.4.10, which was not shipped. The 0.4.10 build and stage are left intact. **This version is not shipped.**

Statuses: **added now** (built in 0.4.11) · **carried** (already in 0.4.10) · **held** (on purpose).

## Added now — lanes and shapes

- [added now] **LANE SHAPE button removed from the UI.** It is hidden, not deleted. Lane width is set only with the LANE WIDTH slider (1–10; 10 = circle diameter).
- [added now] **Every path is a NORMAL lane** for the player and the AI. `LANE_SHAPES_ON=false` forces `laneF`, `laneOk`, `setLane` and `mkPath` to NORMAL, so a lane value from an old save or old AI memory is ignored. The CUSTOM "Default lane shape" row is hidden.
- [added now] **Shapes removed for now** (hidden; the code is kept):
  - `SHAPES_OFF=true` forces `shapesOn=0` and `aiForms=0` at every match start, even when an old custom save had them on.
  - `useShape` and `aiShapes` return at once.
  - Hidden: the shape panel (SHAPE DENS, COMPACT, PULL, FORM AT, shape buttons), the SHAPE EDITOR menu button, the CUSTOM SHAPES group and its toggle, and the shape tint row.
  - The stage descriptions no longer list shapes or lane types. The old text is kept in `STG_SHAPES`.

## Added now — AI rule book and a smarter AI

- [added now] **AI-RULES.md**: the objective, how the game works, and SHOULD / SHOULDN'T lists. The code follows it, and each rule names its function.
- [added now] **GUARD**: an enemy stream heading for the AI circle is met head-on in front of the circle by a guard branch running back up the enemy lane. Branches are always guarded; the main is guarded once it is really landing (15 hits, or 5 against a known straight shooter).
- [added now] **Width match**: a guard is the enemy lane width +2, up to 10, so the outer pixels are caught. It re-matches when the player changes width. Where the two main lanes meet, the AI main is at least the enemy main width +1.
- [added now] **Spare branch** for defense until a guard is up. If no slot is free, the weakest attack branch is erased to make one (erasing is free).
- [added now] **Flow budget**: when a guarded stream still lands, the weakest attack flow is trimmed so the guard gets pixels under the 1000 cap. (Paths are fed main first, so a guard behind an over-fed main used to starve.)
- [added now] **Side approach**: the main and attack branches finish on the enemy circle from the side, away from the enemy's own outgoing lanes, instead of trading 1:1 head-on.
- [added now] **Clash fix**: the enemy spawn zone no longer counts as a "losing clash". Before, this made the AI cut its own main flow to about 280 from the first second (the main cause of the seed 23 / variant 19 losses). A clash now needs AI pixels there too, and a cut never goes below 400.
- [added now] **No wasted pixels**: a short stub branch that stops before the circle, or a branch that just retraces the main, is not kept.
- [added now] **Learns your habits** (`aiObserve` → `aiHabitsCommit`, saved in AI memory): when and how often you branch, main width, density, pace and flow, attack-branch width, detours, loops, attack side, straight shots. **Counters them next match** (`aiCounterHabits`).
- [added now] **Built-in prior** (`AISEED`) from every game in our own test runs. It counts as 3 matches; your own matches outweigh it.

## Added now — saves and extras (one-line reason each)

- [added now] Save keys `pixelwar.v411*` with a `v410` fallback, and AI memory `pixelwar.v411.aimem` with a `v410` fallback. Reason: don't collide with 0.4.10; old saves and old AI memory load. Memory is migrated, not wiped; habits start empty.
- [added now] DELETE AI MEMORY also drops the v410 memory key. Reason: a clear should clear older memories too.
- [added now] Help text: the AI's goal, guard and habits; what DENSITY really does; shapes removed. Reason: say what the game actually does.

## Carried (locked rules, unchanged)

- [carried] Hitbox is a road with no centerline pull. Max lane width = circle diameter. Flow 200–1000. Ricochet is random and short. Pixels roam one way past the path end, then fade.
- [carried] Defense line locks at START; no mid-match walls for either side. Detour merge and loop-connect.
- [carried] No cluster. The AI is always at full smart, with persistent memory and the DELETE button.

## Held on purpose

- [held] Shapes and lane shapes (hidden, code kept), cluster, turn-based, 3D, automatic speed–density coupling, friendly pass-through walls, mid-match defense rebuild, per-match AI memory wipe, difficulty picker.
- [held] **DENSITY mechanics are unchanged.** Measured: density 1 vs 10, head-on, same flow and width, ends within 1–3% kills. Today it mostly calms the sideways wobble. Making it matter is a design change for Jay to decide.
