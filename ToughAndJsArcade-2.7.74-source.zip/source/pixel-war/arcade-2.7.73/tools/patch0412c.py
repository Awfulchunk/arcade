import sys
f='/workspace/game/build-pixelwar0412/index.html'
s=open(f).read()
def rep(old,new):
    global s
    n=s.count(old)
    if n!=1: print('FAIL',n,repr(old[:110]));sys.exit(1)
    s=s.replace(old,new,1)
# prior + habit keys (old 'density' habit dropped: it can never come back from memory)
rep("const AISEED={n:3,brT:200,brN:2,width:5,density:6,speed:7,flow:480,offW:3,detour:0.8,loop:0,offense:1,straight:0.8,L:0.2,R:0.2,C:0.6};\nconst HABK=['brT','brN','width','density','speed','flow','offW','detour','loop','offense','straight','L','R','C'];",
 "const AISEED={n:3,brT:200,brN:2,width:5,density:6,size:5,offS:5,speed:7,flow:480,offW:3,detour:0.8,loop:0,offense:1,straight:0.8,L:0.2,R:0.2,C:0.6};   // 0.4.12: those test games all used size 5 (the 0.4.11 pixel); 'density' is kept here only as a dead field\n"
 "const HABK=['brT','brN','width','size','offS','speed','flow','offW','detour','loop','offense','straight','L','R','C'];   // 0.4.12: 'density' removed (old memories cannot bring it back); 'size' = main pixel size, 'offS' = attack-branch pixel size\n"
 "// PIXEL SIZE PICKS (0.4.12, AI-RULES.md 'Pixel size'). Measured in head-on duels (tests/duel0412.cjs): a bigger size wins more contacts (kills 52-59%),\n"
 "// a smaller size swarms (up to 1.2x pixels per flow point) and nudges the front forward; neither wins outright. So the AI picks by JOB:\n"
 "//   punch / intercept = big (survive contacts on the way, hit the circle harder); guard / block = small (more pixels across the lane: catch the outer pixels);\n"
 "//   main / flank / detour = counter the player's usual main size (vs big: go small and swarm; vs small: go big and win the contacts).\n"
 "function aiSizeFor(job,foeS){const h=S.ai&&S.ai.hab,hs=foeS!=null?foeS:(h?h.size:5);\n"
 "  if(!AIR.size)return 5;\n"
 "  if(job==='punch')return 8;if(job==='intercept')return 7;\n"
 "  if(job==='guard'){if(hs>=8)return 4;return 3;}   // vs a huge punch a size-3 guard still catches the edges; a size-4 one holds better\n"
 "  if(job==='block')return 3;\n"
 "  if(hs>=7)return 3;if(hs<=3)return 7;return 5;}")
# guard opening + guard step
rep("B.set.density=clamp(Math.max(sd.set.density,(fs.density|0)+2),7,10);B.set.speed=",
    "B.set.size=aiSizeFor('guard',sizeOf(fs));B.set.speed=")
rep("if(ls>kl+10&&B.set.density<10)setPathSetting(side,b,'density',B.set.density+1);}",
    "if(ls>kl+10&&sizeOf(B.set)<6&&S.tick-(B.szT|0)>=240){B.szT=S.tick;setPathSetting(side,b,'size',sizeOf(B.set)+1);aiLearn('guard '+b+' losing contacts: bigger pixels ('+sizeOf(B.set)+')');}}")
# observe + commit
rep("o.t++;o.w+=fs.width;o.d+=fs.density;o.s+=fs.speed;o.f+=onField(fs);}","o.t++;o.w+=fs.width;o.z+=sizeOf(fs);o.s+=fs.speed;o.f+=onField(fs);}")
rep("const o=ai.obs||(ai.obs={t:0,w:0,d:0,s:0,f:0,offW:0,offN:0,","const o=ai.obs||(ai.obs={t:0,w:0,z:0,s:0,f:0,offW:0,offZ:0,offN:0,")
rep("else{o.off++;o.offW+=pset(foe,P).width;o.offN++;}}}","else{o.off++;o.offW+=pset(foe,P).width;o.offZ+=sizeOf(pset(foe,P));o.offN++;}}}")
rep("width:o.w/o.t,density:o.d/o.t,speed:o.s/o.t,","width:o.w/o.t,size:o.z/o.t,offS:o.offN?o.offZ/o.offN:AISEED.offS,speed:o.s/o.t,")
# counter
rep("  sd.set.density=clamp(Math.max(sd.set.density,Math.round(h.density)+1),6,9);\n",
    "  sd.set.density=DENS_N;sd.set.size=aiSizeFor('main',h.size);   // 0.4.12: old density off; main size counters the player's usual main size\n")
rep("': width '+h.width.toFixed(1)+', density '+h.density.toFixed(1)+', flow '","': width '+h.width.toFixed(1)+', pixel size '+h.size.toFixed(1)+', flow '")
# arm branch default
rep("if(B.set.density==null)B.set.density=set.density;","if(B.set.density==null)B.set.density=set.density;if(B.set.size==null)B.set.size=sizeOf(set);")
# jobs
rep("B.set.width=clamp(sd.set.width,3,8);B.set.density=sd.set.density;B.set.speed=sd.set.speed;B.set.release=clamp(Math.round(Math.max(420,",
    "B.set.width=clamp(sd.set.width,3,8);B.set.density=DENS_N;B.set.size=sizeOf(sd.set);B.set.speed=sd.set.speed;B.set.release=clamp(Math.round(Math.max(420,")
rep("if(B.job==='punch'){B.set.width=2;B.set.density=8;","if(B.job==='punch'){B.set.width=2;B.set.density=DENS_N;B.set.size=aiSizeFor('punch');")
rep("else if(B.job==='block'){B.set.width=9;B.set.density=7;","else if(B.job==='block'){B.set.width=9;B.set.density=DENS_N;B.set.size=aiSizeFor('block');")
rep("else if(B.job==='intercept'){B.set.width=4;B.set.density=7;","else if(B.job==='intercept'){B.set.width=4;B.set.density=DENS_N;B.set.size=aiSizeFor('intercept');")
rep("else{B.set.width=clamp(set.width,3,8);B.set.density=set.density;B.set.speed=set.speed;","else{B.set.width=clamp(set.width,3,8);B.set.density=DENS_N;B.set.size=aiSizeFor('flank');B.set.speed=set.speed;")
# tactics: behind -> size flip toward counter of the player's live main size
rep("else if(set.density<9)step(P,'density',set.density+1,'behind: pack tighter');}",
    "else{const fz=foe.paths[0]?sizeOf(pset(foe,foe.paths[0])):5,want=aiSizeFor('main',fz);if(sizeOf(set)!==want)step(P,'size',want,'behind: pixel size '+want+' against your size '+fz);}}")
# memory tune: size instead of density
rep("for(const k of['speed','density','release','width']){if(!fin(+v.tune[k])){ok=false;break;}t[k]=k==='release'?migRelease(v.tune[k]):clamp(Math.round(+v.tune[k]),1,10);}m.tune=ok?t:null;}",
    "for(const k of['speed','release','width']){if(!fin(+v.tune[k])){ok=false;break;}t[k]=k==='release'?migRelease(v.tune[k]):clamp(Math.round(+v.tune[k]),1,10);}if(ok&&fin(+v.tune.size))t.size=clamp(Math.round(+v.tune.size),1,10);m.tune=ok?t:null;}   // 0.4.12: tune.density from old memories is dropped")
rep("if(AIMEM.tune){for(const k of['speed','density','release','width'])sd1.set[k]=AIMEM.tune[k];",
    "if(AIMEM.tune){for(const k of['speed','release','width'])sd1.set[k]=AIMEM.tune[k];if(AIMEM.tune.size)sd1.set.size=AIMEM.tune.size;sd1.set.density=DENS_N;")
rep("const t={speed:sd.set.speed,density:sd.set.density,release:sd.set.release,width:sd.set.width};\n      if(w===0){t.density=clamp(t.density+1,1,10);t.width=",
    "const t={speed:sd.set.speed,size:sizeOf(sd.set),release:sd.set.release,width:sd.set.width};\n      if(w===0){const hz=AIMEM.habits&&fin(+AIMEM.habits.size)?+AIMEM.habits.size:5;t.size=hz>=6?3:7;t.width=")
rep("habits:null,v:411});","habits:null,v:412});")
open(f,'w').write(s);print('ok c')
