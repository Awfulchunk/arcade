import sys
f='/workspace/game/build-pixelwar0412/index.html'
s=open(f).read()
def rep(old,new):
    global s
    n=s.count(old)
    if n!=1: print('FAIL',n,repr(old[:100]));sys.exit(1)
    s=s.replace(old,new,1)
rep("psz[i]=zs;php[i]=Math.round(CFG.pixHP*SZ_HP[zs-1]*HPQ/8*2/2);","psz[i]=zs;php[i]=Math.round(CFG.pixHP*SZ_HP[zs-1]/2);")
# collide: per-pair contact + size-scaled damage
rep("        if(d2>=CONTACT*CONTACT)continue;","        const ctr=(SZ_CT[psz[i]-1]+SZ_CT[psz[j]-1])*0.5;if(d2>=ctr*ctr)continue;   // 0.4.12: bigger pixels have a bigger hit radius (max 4.0 = CELL)")
rep("        if(sI){s0.stats.misses++;s0.stats.surv++;}else hurt(i,pHP,1,j);\n        if(sJ){s1.stats.misses++;s1.stats.surv++;}else hurt(j,pHP,0,i);",
    "        const hI=pHP*SZ_DMG[psz[j]-1],hJ=pHP*SZ_DMG[psz[i]-1];   // 0.4.12: damage in quarter points from the HITTER's size (size 5 = 1 point, the locked value)\n"
    "        if(sI){s0.stats.misses++;s0.stats.surv++;}else hurt(i,hI,1,j);\n        if(sJ){s1.stats.misses++;s1.stats.surv++;}else hurt(j,hJ,0,i);")
# circle damage scaled by pixel mass
rep("burnPool(S.sides[1-side],cdm*CFG.burn);recall(i);continue;}",
    "burnPool(S.sides[1-side],Math.round(cdm*CFG.burn*SZ_MASS[psz[i]-1]));recall(i);continue;}   // 0.4.12: a big pixel hits the circle harder, a small one softer (same flow = same total)")
rep("sg.hp-=wdm;sg.hitT=S.tick;","sg.hp-=wdm*SZ_MASS[psz[i]-1];sg.hitT=S.tick;")
# render
rep("    const hh=CFG.pixHP*0.5;","    const hh=CFG.pixHP*0.25,szd=SZ_PX.map(v=>Math.max(1,Math.round(v*sc/2)));   // 0.4.12: dot side per size (2x2 device px at size 5, like 0.4.11)")
old="cols[php[i]>hh?0:1],big=false,x=((pox[i]+(px[i]-pox[i])*RA)*sc-1)|0,y=((poy[i]+(py[i]-poy[i])*RA)*sc-1)|0,"
rep(old,"cols[php[i]>hh*SZ_HP[psz[i]-1]?0:1],big=false,dz=szd[psz[i]-1],ho=dz>>1,x=((pox[i]+(px[i]-pox[i])*RA)*sc-ho)|0,y=((poy[i]+(py[i]-poy[i])*RA)*sc-ho)|0,")
rep("        if(x<0||y<0||x>fw-3||y>fh-3)continue;let o=y*fw+x;P32[o]=cf;P32[o+1]=cf;o+=fw;P32[o]=cf;P32[o+1]=cf;",
    "        if(x<0||y<0||x>fw-1-dz||y>fh-1-dz)continue;let o=y*fw+x;if(dz===2){P32[o]=cf;P32[o+1]=cf;o+=fw;P32[o]=cf;P32[o+1]=cf;}else for(let yy=0;yy<dz;yy++,o+=fw)for(let xx=0;xx<dz;xx++)P32[o+xx]=cf;")
# hooks
rep("pix.push({s:i<CAPMAX?0:1,x:px[i],y:py[i],hp:php[i],st:pst[i]});","pix.push({s:i<CAPMAX?0:1,x:px[i],y:py[i],hp:php[i]/HPQ,st:pst[i],size:psz[i]});")
rep("lanes:sd.paths.map(P=>P?P.lane:-1),","lanes:sd.paths.map(P=>P?P.lane:-1),sizes:sd.paths.map(P=>P?sizeOf(pset(sd,P)):-1),")
rep("r.push({id:'p'+i,kind:'pixel',x:LX+px[i]*LS-1,y:LY+py[i]*LS-1,w:2,h:2,noOverlap:false});",
    "{const z=SZ_PX[psz[i]-1];r.push({id:'p'+i,kind:'pixel',x:LX+px[i]*LS-z/2,y:LY+py[i]*LS-z/2,w:z,h:z,noOverlap:false,size:psz[i]});}")
rep("c2.fillRect(Math.round(LX+px[i]*LS)-1,Math.round(LY+py[i]*LS)-1,2,2);","{const z=SZ_PX[psz[i]-1];c2.fillRect(Math.round(LX+px[i]*LS-z/2),Math.round(LY+py[i]*LS-z/2),z,z);}")
rep("case'setSpeed':return setSetting(0,'speed',num(+args[0]));case'setDensity':return setSetting(0,'density',num(+args[0]));",
    "case'setSpeed':return setSetting(0,'speed',num(+args[0]));case'setDensity':return setSetting(0,'size',num(+args[0]));case'setSize':return setSetting(0,'size',num(+args[0]));\n"
    "  case'setPathSize':return setPathSetting(0,Math.floor(num(+args[0])),'size',num(+args[1]));case'setOldDensity':return setSetting(0,'density',num(+args[0]));")
rep("{name:'setDensity',args:[{name:'v',min:1,max:10}]},",
    "{name:'setDensity',args:[{name:'v',min:1,max:10}]},{name:'setSize',args:[{name:'v',min:1,max:10}]},{name:'setPathSize',args:[{name:'path',min:0,max:5},{name:'v',min:1,max:10}]},{name:'setOldDensity',args:[{name:'v',min:1,max:10}]},")
# UI slider
rep("setT('lDe','DENSITY\\n'+ps.density+' '+DW(ps.density));","setT('lDe','DENSITY\\n'+sizeOf(ps)+' '+ZW(sizeOf(ps)));")
rep("const sl=[['sSp',ps.speed],['sDe',ps.density],","const sl=[['sSp',ps.speed],['sDe',sizeOf(ps)],")
rep("for(const q of[['sSp','speed'],['sDe','density'],['sWd','width']])","for(const q of[['sSp','speed'],['sDe','size'],['sWd','width']])")
rep("DW=v=>v<=3?'loose':v<=7?'medium':'tight',","DW=v=>v<=3?'loose':v<=7?'medium':'tight',ZW=v=>v<=2?'tiny':v<=4?'small':v<=6?'medium':v<=8?'big':'huge',")
rep('aria-label="density down">','aria-label="pixel size down">')
rep('aria-label="density">','aria-label="density (pixel size)">')
rep('aria-label="density up">','aria-label="pixel size up">')
# prefs
rep("  if(fin(+v.density)||fin(+v.spacing))setSetting(0,'density',migDensity(v.density,v.spacing));",
    "  if(!DENSITY_OFF&&(fin(+v.density)||fin(+v.spacing)))setSetting(0,'density',migDensity(v.density,v.spacing));   // 0.4.12: old density is never loaded\n"
    "  if(fin(+v.size)&&v.size!==null&&typeof v.size!=='boolean')setSetting(0,'size',+v.size);   // pixel size (0.4.12 saves only; older saves have none, so 5)")
rep("JSON.stringify({speed:s.speed,density:s.density,release:s.release,","JSON.stringify({speed:s.speed,size:sizeOf(s),release:s.release,")
# expose
rep("aiBudget,KEYAI,KEY};","aiBudget,KEYAI,KEY,psz,SZ_CNT,SZ_HP,SZ_DMG,SZ_CT,SZ_IN,SZ_PX,SZ_MASS,DENSITY_OFF,DENS_N,HPQ,densOf,sizeOf,get KEYAI411(){return KEYAI411;}};")
open(f,'w').write(s);print('ok b')
