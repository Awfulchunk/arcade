import re,sys
f='/workspace/game/build-pixelwar0412/index.html'
s=open(f).read()
def rep(old,new,count=1):
    global s
    n=s.count(old)
    if n<count or (count==1 and n!=1):
        print('FAIL',n,repr(old[:90]));sys.exit(1)
    s=s.replace(old,new) if count!=1 else s.replace(old,new,1)
# version labels
s=s.replace('<title>PIXEL WAR 0.4.11</title>','<title>PIXEL WAR 0.4.12</title>')
s=s.replace('<h1>PIXEL WAR 0.4.11</h1>','<h1>PIXEL WAR 0.4.12</h1>')
rep("   PIXEL WAR 0.4.11 — full game","   PIXEL WAR 0.4.12 — full game")
# save keys
rep("const KEY='pixelwar.v411',KEYC='pixelwar.v411.custom',KEYF='pixelwar.v411.forms',",
    "const KEY='pixelwar.v412',KEYC='pixelwar.v412.custom',KEYF='pixelwar.v412.forms',KEY411='pixelwar.v411',KEYC411='pixelwar.v411.custom',KEYF411='pixelwar.v411.forms',")
rep("const KEYAI='pixelwar.v411.aimem',","const KEYAI='pixelwar.v412.aimem',KEYAI411='pixelwar.v411.aimem',")
rep("localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI410)","localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI411)||localStorage.getItem(KEYAI410)")
rep("localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI410);","localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI411);localStorage.removeItem(KEYAI410);")
rep("localStorage.getItem(KEY)||localStorage.getItem(KEY410)","localStorage.getItem(KEY)||localStorage.getItem(KEY411)||localStorage.getItem(KEY410)")
# flags + size tables
rep("const LANE_SHAPES_ON=false,SHAPES_OFF=true;",
 "const LANE_SHAPES_ON=false,SHAPES_OFF=true;\n"
 "// 0.4.12 (Jay t1199/t1200): the old DENSITY (wobble/packing) is OFF for both sides (hidden, code kept: every effect reads densOf() = neutral 5).\n"
 "// The DENSITY slider now sets PIXEL SIZE (set.size 1..10, per path). Index = size-1. Size 5 = the 0.4.11 pixel exactly.\n"
 "//   SZ_CNT  pixels on the field per FLOW point (flow is a pixel budget: big pixels cost more of it, small ones swarm)\n"
 "//   SZ_HP / SZ_DMG  HP and damage in quarter points (size 5 = HP 2, damage 1, the locked values)\n"
 "//   SZ_CT   contact (hit) radius; max 4.0 = the collision grid cell, so no hit is ever missed\n"
 "//   SZ_IN   how far a big pixel stays in from the lane edge (fewer fit side by side)   SZ_PX  drawn dot size in device px at 2x\n"
 "const DENSITY_OFF=true,DENS_N=5,HPQ=4;\n"
 "const SZ_CNT=[1.40,1.30,1.19,1.09,1,0.88,0.78,0.69,0.6,0.52],SZ_HP=[5,6,7,7,8,9,10,11,12,13],SZ_DMG=[2,3,3,4,4,4,5,5,6,6],SZ_CT=[3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,4.0],SZ_IN=[0,0,0,0,0,0.3,0.6,0.9,1.2,1.5],SZ_PX=[1,1,2,2,2,3,3,4,4,5],SZ_MASS=[0.71,0.77,0.84,0.92,1,1.14,1.28,1.45,1.67,1.92];\n"
 "const densOf=set=>DENSITY_OFF?DENS_N:((set&&set.density)|0||DENS_N),sizeOf=set=>clamp((set&&set.size)|0||5,1,10);")
rep("const DEF={speed:5,density:5,release:289,cap:PERFCAP,sdens:7,compact:6,width:5,spacing:5};",
    "const DEF={speed:5,density:5,size:5,release:289,cap:PERFCAP,sdens:7,compact:6,width:5,spacing:5};")
# per pixel size array
rep("const php=new Int8Array(NP),","const psz=new Uint8Array(NP).fill(5),php=new Int8Array(NP),")
# settings
rep("  if(key==='speed'||key==='density'||key==='sdens'||key==='compact'||key==='width')sd.set[key]=clamp(Math.round(v),1,10);\n  else if(key==='spacing'){sd.set.density=migDensity(sd.set.density,v);return true;}",
    "  if(key==='density'&&DENSITY_OFF){sd.set.density=DENS_N;return true;}   // 0.4.12: old density is off; nothing (save, AI memory, command) can set it\n"
    "  if(key==='speed'||key==='density'||key==='size'||key==='sdens'||key==='compact'||key==='width')sd.set[key]=clamp(Math.round(v),1,10);\n  else if(key==='spacing'){if(DENSITY_OFF)return true;sd.set.density=migDensity(sd.set.density,v);return true;}")
rep("  if(key==='speed'||key==='density'||key==='width'){P.set[key]=clamp(Math.round(v),1,10);return true;}\n  if(key==='spacing'){P.set.density=migDensity(P.set.density,v);return true;}",
    "  if(key==='density'&&DENSITY_OFF){P.set.density=DENS_N;return true;}\n"
    "  if(key==='speed'||key==='density'||key==='size'||key==='width'){P.set[key]=clamp(Math.round(v),1,10);return true;}\n  if(key==='spacing'){if(DENSITY_OFF)return true;P.set.density=migDensity(P.set.density,v);return true;}")
# branch copy
rep("P.set={speed:sd.set.speed,density:sd.set.density,width:sd.set.width,","P.set={speed:sd.set.speed,density:sd.set.density,size:sizeOf(sd.set),width:sd.set.width,")
# flow rate: count per flow point by size
rep("return CFG.relMul/120*onField(set)/T;}","return CFG.relMul/120*onField(set)*SZ_CNT[sizeOf(set)-1]/T;}")
# release: size of dest path, cap scaled
rep("function release(side,dest,ago){const sd=S.sides[side];if(sd.active>=sd.set.cap||sd.pool<=0)return false;let i=-1;",
    "function release(side,dest,ago){const sd=S.sides[side],DP=sd.paths[dest|0],zs=sizeOf(pset(sd,DP||sd.paths[0]));if(sd.active>=sd.set.cap*SZ_CNT[zs-1]||sd.pool<=0)return false;let i=-1;")
rep("php[i]=CFG.pixHP;pst[i]=1;","psz[i]=zs;php[i]=Math.round(CFG.pixHP*SZ_HP[zs-1]*HPQ/8*2/2);pst[i]=1;")
# density effects off
rep("rev=0.04*set.density,","rev=0.04*densOf(set),")
rep("pRev.push(0.006*ps.density*(1+0.6*th));","pRev.push(0.006*densOf(ps)*(1+0.6*th));")
rep("wob=(0.90-(ps.density-1)/9*0.56)*(1-0.55*th);freeFwd(i,p,pps[i],lw,spd,stun,vx,vy,wob);",
    "wob=(0.90-(densOf(ps)-1)/9*0.56)*(1-0.55*th);freeFwd(i,p,pps[i],Math.max(1,lw-SZ_IN[psz[i]-1]),spd,stun,vx,vy,wob);")
rep("freeFwd(i,p,pps[i],hwEx,spd,stun,vx,vy,0.5);","freeFwd(i,p,pps[i],Math.max(1,hwEx-SZ_IN[psz[i]-1]),spd,stun,vx,vy,0.5);")
open(f,'w').write(s)
print('ok part1')
