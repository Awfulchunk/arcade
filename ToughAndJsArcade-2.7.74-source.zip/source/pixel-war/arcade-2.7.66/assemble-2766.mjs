// Arcade 2.7.66 = published 2.7.65 bundle: pixelwar:latest -> Pixel War 0.4.3; NEW slot pixelwar:v042 = Pixel War 0.4.2 (frozen); pixelwar:v041 and pixelwar:v03 unchanged.
// Every other slot payload, legacy variant, card and shell text byte-for-byte unchanged.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2766";
const BASE = "/workspace/game/build-ship2765/out/index.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "882ae42eacd1af965c56b4f7f966fc0bfe0e9c9d657a3ac6f1f8fd5c8feb3364", "2.7.65 base hash mismatch: " + sha(src));
const N43 = fs.readFileSync(`${B}/out/pixel-war-0.4.3.html`, "utf8"), N42 = fs.readFileSync(`${B}/out/pixel-war-0.4.2.html`, "utf8");
assert(sha(N42) === "e83017821096e5a30a0bc29e92cd17793414edb861a9982ae66e7cbe04824724", "0.4.2 html != frozen");
const KL = "pixelwar:latest", K42 = "pixelwar:v042", K41 = "pixelwar:v041", K3 = "pixelwar:v03";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && before[K3] && before[K41] && !before[K42], "slot state"); assert(Object.keys(before).length === 165, "165 slots before");
const G0 = GS(src); assert(G0[KL] === N42, "live pixelwar:latest is 0.4.2");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
let out = src.slice(0, before[KL][0]) + ex(N43) + src.slice(before[KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + ',\n"' + K42 + '":' + ex(N42) + out.slice(ei);
// card
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const pw = GAMES.find((g) => g.id === "pixelwar"); assert(pw && pw.versions.map((v) => v.id).join() === "v03,v041,latest", "card versions before");
const v42 = { ...pw.versions[2], id: "v042", name: "v0.4.2 – live branches, sandbox, slow flow (2.7.65)", def: false };
const lat = { ...pw.versions[2], name: "v0.4.3 – Latest (steady flow, smarter AI, smooth motion)",
  desc: "Pixel War 0.4.3 (test build). Pixels leave the circle smoothly along the path's start direction in a constant, even stream; only 200–400 pixels per side are on the field at once (the 10,000 pool is your health and reserve), and every path (main and each branch) has its own FLOW slider for that. Past the end of a path pixels fly straight and spread in a loose cone, fading out past the leash; ricocheted pixels fly straight too and fade the same way, and bounces spray sideways. Thin lanes pack tighter, wide ones stay loose. The defense line you draw is smoothed, and pixels move smoothly between frames. The AI is smarter: it opens branches over time, tunes width / density / flow per path, answers your real path with walls or gates, and REMEMBERS between matches (DELETE AI MEMORY is in the menu). Prep: attack path + defense line; branches are live in the match; SANDBOX is a free playground. Your 0.4.2, 0.4.1 and 0.3 stay playable with their own saves.", def: true };
pw.versions = [pw.versions[0], pw.versions[1], v42, lat];
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// legacy parts
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const r43 = {}; const p43 = legacyParts(N43, r43); assert(r43.jsFail.length === 0, "legacy js fail 0.4.3"); assert(joinParts(p43, N43) === legacyHtml(N43, {}), "parts mismatch 0.4.3");
const r42 = {}; const p42 = legacyParts(N42, r42); assert(r42.jsFail.length === 0, "legacy js fail 0.4.2"); assert(joinParts(p42, N42) === legacyHtml(N42, {}), "parts mismatch 0.4.2");
assert(JSON.stringify(LEG[KL]) === JSON.stringify(p42), "old legacy latest == 0.4.2 parts");
const LEG2 = { ...LEG, [KL]: p43, [K42]: p42 };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// verification
const after = slots(out); assert(Object.keys(after).length === 166, "166 slots after");
for (const k of Object.keys(before)) if (k !== KL) assert(after[k][2] === before[k][2], "slot text changed " + k);
const G1 = GS(out); assert(G1[KL] === N43 && G1[K42] === N42, "new payloads"); for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([K42]), "only new slot is " + K42);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const G64 = JSON.parse(gJson); 
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
assert(JSON.stringify(GAMES.filter((g) => g.id !== "pixelwar")) === JSON.stringify(base.filter((g) => g.id !== "pixelwar")), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.66", versionCode: 104, latest: "pixelwar:latest = Pixel War 0.4.3", newSlot: K42, v041: "unchanged", v03: "unchanged", html043SHA256: sha(N43), html043Bytes: Buffer.byteLength(N43), html042SHA256: sha(N42), baseBundleSHA256_2765: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), cartridgeSlotsBefore: 165, cartridgeSlotsAfter: Object.keys(after).length, changedSlots: [KL], legacy: `css ${r42.css} js ${r42.js}`, menuOrder: GAMES.map((g) => g.id) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
