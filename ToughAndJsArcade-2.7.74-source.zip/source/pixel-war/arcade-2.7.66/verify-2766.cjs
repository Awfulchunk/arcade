// Independent verification of ToughAndJsArcade-2.7.66.apk vs the published 2.7.65 APK. Prints no key material.
const fs=require('fs'),cr=require('crypto'),vm=require('vm'),{execSync,execFileSync}=require('child_process');
const sha=b=>cr.createHash('sha256').update(b).digest('hex');
const B='/workspace/game/build-ship2766',APK=process.argv[2]||B+'/package-2.7.66/out/ToughAndJsArcade-2.7.66.apk';
const OLD='/tmp/arcade-ship-2751/arcade/ToughAndJsArcade-2.7.65.apk';
const BT='/workspace/tools/sdk/build-tools/34.0.0',JH='/workspace/tools/jdk/bin';
const env=Object.assign({},process.env,{PATH:JH+':'+process.env.PATH});
const sh=c=>execSync(c,{maxBuffer:1<<28,env}).toString();
const R={ok:true,checks:[]};const ck=(n,v,x)=>{R.checks.push({n,pass:!!v,...(x?{x}:{})});console.log(v?'PASS':'FAIL',n,x?JSON.stringify(x).slice(0,260):'');if(!v)R.ok=false;};
const fromApk=(f,n)=>execSync(`unzip -p ${f} '${n}'`,{maxBuffer:1<<28});
ck('2.7.65 APK is the published one (sha256 bed79202…)',sha(fs.readFileSync(OLD))==='bed79202759aadde102041abca9fe9fb61ce4f42ed5af86bc4517ae4e22be227');
const v=sh(`${BT}/apksigner verify --verbose --print-certs --min-sdk-version 24 ${APK} 2>&1`);
const cert=(v.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1];
ck('apksigner verify OK (v1+v2+v3)',/Verifies/.test(v)&&/v2 scheme \(APK Signature Scheme v2\): true/.test(v)&&/v3 scheme \(APK Signature Scheme v3\): true/.test(v));
ck('signer cert SHA-256 = e8bae744…6ce3',cert==='e8bae744ff07c16a636dedfb9339ca2c1e262e49254550cf970b3a8f26f66ce3',cert);
const vo=sh(`${BT}/apksigner verify --print-certs ${OLD} 2>&1`);ck('same signer as 2.7.65',(vo.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1]===cert);
const bd=sh(`${BT}/aapt2 dump badging ${APK} 2>&1`);
ck('package com.toughandj.arcade, versionCode 104, versionName 2.7.66',/package: name='com\.toughandj\.arcade' versionCode='104' versionName='2\.7\.66'/.test(bd),bd.split('\n')[0]);
const bo=sh(`${BT}/aapt2 dump badging ${OLD} 2>&1`);ck('2.7.65 was code 103',/versionCode='103'/.test(bo));
ck('same minSdk/targetSdk/permissions as 2.7.65',['sdkVersion','targetSdkVersion'].every(k=>(bd.match(new RegExp(k+":'(\\d+)'"))||[])[1]===(bo.match(new RegExp(k+":'(\\d+)'"))||[])[1])&&JSON.stringify(bd.match(/uses-permission: name='[^']+'/g))===JSON.stringify(bo.match(/uses-permission: name='[^']+'/g)));

// contents vs 2.7.64
const ents=f=>{const o={};for(const l of sh(`unzip -v ${f}`).split('\n')){const m=l.match(/^\s*\d+\s+\S+\s+\d+\s+\d+%\s+\S+\s+\S+\s+([0-9a-f]{8})\s+(\S.*)$/);if(m)o[m[2]]=m[1];}return o;};
const eN=ents(APK),eO=ents(OLD);const diff=Object.keys(eN).filter(k=>eO[k]!==eN[k]&&!/^META-INF\//.test(k)),gone=Object.keys(eO).filter(k=>!(k in eN)&&!/^META-INF\//.test(k)),added=Object.keys(eN).filter(k=>!(k in eO)&&!/^META-INF\//.test(k));
ck('APK entries identical to 2.7.65 except assets/index.html and AndroidManifest.xml (version)',JSON.stringify(diff.sort())===JSON.stringify(['AndroidManifest.xml','assets/index.html']),{diff,gone,added});
ck('no entries added or removed',gone.length===0&&added.length===0);
// bundle + slots
const load=t=>{const a=t.indexOf('const GAME_SRC='),b=t.indexOf('// END_PACKED_GAME_SRC');return{t,G:vm.runInNewContext(t.slice(a,b)+'\nGAME_SRC;')};};
const N=load(fromApk(APK,'assets/index.html').toString('utf8')),O=load(fromApk(OLD,'assets/index.html').toString('utf8'));
ck('assets/index.html == assembled bundle (out/index.html)',N.t===fs.readFileSync(B+'/out/index.html','utf8'));
ck('2.7.65 base bundle sha = 882ae42e…',sha(O.t)==='882ae42eacd1af965c56b4f7f966fc0bfe0e9c9d657a3ac6f1f8fd5c8feb3364');
const kN=Object.keys(N.G),kO=Object.keys(O.G);
ck('166 slots = 165 + pixelwar:v042',kN.length===166&&kO.length===165&&kN.filter(k=>!(k in O.G)).join()==='pixelwar:v042');
ck('every existing slot payload except pixelwar:latest byte-identical to 2.7.65 (164)',kO.filter(k=>k!=='pixelwar:latest').every(k=>O.G[k]===N.G[k])&&kO.filter(k=>k!=='pixelwar:latest').length===164);
ck('pixelwar:latest == frozen 0.4.3 html',N.G['pixelwar:latest']===fs.readFileSync(B+'/out/pixel-war-0.4.3.html','utf8'));
ck('pixelwar:v042 == frozen 0.4.2 html (e8301782…) == old latest',sha(N.G['pixelwar:v042'])==='e83017821096e5a30a0bc29e92cd17793414edb861a9982ae66e7cbe04824724'&&O.G['pixelwar:latest']===N.G['pixelwar:v042']);
ck('pixelwar:v041 + v03 unchanged (f3894f84…, acf3fd27…)',sha(N.G['pixelwar:v041'])==='f3894f84d954042021d352673cfa28b6886c29d1a8902c0142e7b0accf249cde'&&sha(N.G['pixelwar:v03'])==='acf3fd2726f61d4f7f6b8706f06ca3b71e273a56f5445653c78ed80c753e77ba');
const gm=t=>{const a=t.indexOf('const GAMES='),e=t.indexOf('\n',a);return JSON.parse(t.slice(a+12,e).replace(/;\s*$/,''));};
const GN=gm(N.t),GO=gm(O.t);const pw=GN.find(g=>g.id==='pixelwar');
ck('pixelwar card: v03, v041, v042, latest(def)',pw&&pw.versions.map(x=>x.id).join()==='v03,v041,v042,latest'&&pw.versions[3].def===true&&pw.versions.slice(0,3).every(v=>!v.def));
ck('every other card identical (25 cards)',GN.filter(g=>g.id!=='pixelwar').length===GO.filter(g=>g.id!=='pixelwar').length&&GN.filter(g=>g.id!=='pixelwar').every((g,i)=>JSON.stringify(g)===JSON.stringify(GO.filter(g=>g.id!=='pixelwar')[i])));
// secrets: none in the APK assets / source zips
const ZIPS=process.argv.slice(3);
for(const z of ZIPS){const l=sh(`unzip -l ${z}`);ck('source zip has no keystore/key files: '+require('path').basename(z),!/\.jks|\.keystore|KEYSTORE|\.p12|\.pem|storepass/i.test(l));}
const lz=ZIPS.find(z=>/ToughAndJsArcade/.test(z));if(lz){const t=sh(`unzip -p ${lz} 'source/latch-ui/src/lib/bench/model.ts'`);ck('arcade source zip: unlock code is REPLACE-WITH-UNLOCK-CODE',/REPLACE-WITH-UNLOCK-CODE/.test(t));}
fs.writeFileSync(B+'/out/verify-2766.json',JSON.stringify(R,null,1));console.log(R.ok?'VERIFY ALL OK':'VERIFY FAILED');process.exit(R.ok?0:1);
