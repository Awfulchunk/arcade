// Arcade 2.7.67 = published 2.7.66 bundle: pixelwar:latest -> Pixel War 0.4.4; NEW slot pixelwar:v043 = Pixel War 0.4.3 (frozen); pixelwar:v042, v041 and v03 unchanged.
// Every other slot payload, legacy variant, card and shell text byte-for-byte unchanged.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2767";
const BASE = "/workspace/game/build-ship2766/out/index.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "98aacb3359c71462c6c3dc3a2df78924ffff4048a1e57d3ee573687b57b70032", "2.7.66 base hash mismatch: " + sha(src));
const N44 = fs.readFileSync(`${B}/out/pixel-war-0.4.4.html`, "utf8");
const N43 = fs.readFileSync(`${B}/out/pixel-war-0.4.3.html`, "utf8");
const N42 = fs.readFileSync(`${B}/out/pixel-war-0.4.2.html`, "utf8");
assert(sha(N43) === "6dbcb02ac79f094a2e3d5160c7318db984bbb5dd0a1839d3741d377fd12f47d7", "0.4.3 html != frozen");
assert(sha(N42) === "e83017821096e5a30a0bc29e92cd17793414edb861a9982ae66e7cbe04824724", "0.4.2 html != frozen");
const KL = "pixelwar:latest", K43 = "pixelwar:v043", K42 = "pixelwar:v042", K41 = "pixelwar:v041", K3 = "pixelwar:v03";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && before[K3] && before[K41] && before[K42] && !before[K43], "slot state"); assert(Object.keys(before).length === 166, "166 slots before");
const G0 = GS(src); assert(G0[KL] === N43, "live pixelwar:latest is 0.4.3");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
let out = src.slice(0, before[KL][0]) + ex(N44) + src.slice(before[KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + ',\n"' + K43 + '":' + ex(N43) + out.slice(ei);
// card
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const pw = GAMES.find((g) => g.id === "pixelwar"); assert(pw && pw.versions.map((v) => v.id).join() === "v03,v041,v042,latest", "card versions before");
const v043 = { ...pw.versions[3], id: "v043", name: "v0.4.3 – steady flow, smarter AI, smooth motion (2.7.66)", def: false };
const lat = { ...pw.versions[3], name: "v0.4.4 – Latest (hybrid flow, short ricochet)",
  desc: "Pixel War 0.4.4 (test build). Mix of 0.4.2's full-lane stream and 0.4.3's steady flow and smooth motion. The drawn path is only a visual guide for direction, not a rail: pixels move freely forward across the whole hitbox with their own slight wander, and the lane edges hold them in (they never hug or snap to the center line). Only a ricochet spray or a pixel past the path end may leave the hitbox, and both fade on a much shorter leash. Ricochet is a random chance per collision (not every hit), and each spray has its own random angle and speed in that short range. Slightly quicker pace, slightly higher default flow (still 200–400 on the field; the 10,000 pool is health and reserve). Every path has its own FLOW slider. The defense line stays smooth, and the AI still remembers between matches (DELETE AI MEMORY is in the menu). Your 0.4.3, 0.4.2, 0.4.1 and 0.3 stay playable with their own saves.", def: true };
pw.versions = [pw.versions[0], pw.versions[1], pw.versions[2], v043, lat];
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// legacy parts
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const r44 = {}; const p44 = legacyParts(N44, r44); assert(r44.jsFail.length === 0, "legacy js fail 0.4.4"); assert(joinParts(p44, N44) === legacyHtml(N44, {}), "parts mismatch 0.4.4");
const r43 = {}; const p43 = legacyParts(N43, r43); assert(r43.jsFail.length === 0, "legacy js fail 0.4.3"); assert(joinParts(p43, N43) === legacyHtml(N43, {}), "parts mismatch 0.4.3");
assert(JSON.stringify(LEG[KL]) === JSON.stringify(p43), "old legacy latest == 0.4.3 parts");
const LEG2 = { ...LEG, [KL]: p44, [K43]: p43 };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// verification
const after = slots(out); assert(Object.keys(after).length === 167, "167 slots after");
for (const k of Object.keys(before)) if (k !== KL) assert(after[k][2] === before[k][2], "slot text changed " + k);
const G1 = GS(out); assert(G1[KL] === N44 && G1[K43] === N43, "new payloads"); for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([K43]), "only new slot is " + K43);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
assert(JSON.stringify(GAMES.filter((g) => g.id !== "pixelwar")) === JSON.stringify(base.filter((g) => g.id !== "pixelwar")), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.67", versionCode: 105, latest: "pixelwar:latest = Pixel War 0.4.4", newSlot: K43, v042: "unchanged", v041: "unchanged", v03: "unchanged", html044SHA256: sha(N44), html044Bytes: Buffer.byteLength(N44), html043SHA256: sha(N43), baseBundleSHA256_2766: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), cartridgeSlotsBefore: 166, cartridgeSlotsAfter: Object.keys(after).length, changedSlots: [KL], legacy: `css ${r44.css} js ${r44.js}`, menuOrder: GAMES.map((g) => g.id) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
