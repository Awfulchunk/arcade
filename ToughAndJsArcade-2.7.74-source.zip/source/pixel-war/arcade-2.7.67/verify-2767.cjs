// Independent verification of ToughAndJsArcade-2.7.67.apk vs the published 2.7.66 APK. Prints no key material.
const fs=require('fs'),cr=require('crypto'),vm=require('vm'),{execSync}=require('child_process');
const sha=b=>cr.createHash('sha256').update(b).digest('hex');
const B='/workspace/game/build-ship2767',APK=process.argv[2]||B+'/package-2.7.67/out/ToughAndJsArcade-2.7.67.apk';
const OLD='/workspace/game/requests/finished-ship/pixelwar-0.4.3-arcade-2.7.66/ToughAndJsArcade-2.7.66.apk';
const BT='/workspace/tools/sdk/build-tools/34.0.0',JH='/workspace/tools/jdk/bin';
const env=Object.assign({},process.env,{PATH:JH+':'+process.env.PATH});
const sh=c=>execSync(c,{maxBuffer:1<<28,env}).toString();
const R={ok:true,checks:[]};const ck=(n,v,x)=>{R.checks.push({n,pass:!!v,...(x?{x}:{})});console.log(v?'PASS':'FAIL',n,x?JSON.stringify(x).slice(0,260):'');if(!v)R.ok=false;};
const fromApk=(f,n)=>execSync(`unzip -p ${f} '${n}'`,{maxBuffer:1<<28});
ck('2.7.66 APK is the published one (sha256 a7937b8d…)',sha(fs.readFileSync(OLD))==='a7937b8d894742b70db440fd09a1a40022d260e29e591b9453b1ed38bc04b07d');
const v=sh(`${BT}/apksigner verify --verbose --print-certs --min-sdk-version 24 ${APK} 2>&1`);
const cert=(v.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1];
ck('apksigner verify OK (v1+v2+v3)',/Verifies/.test(v)&&/v2 scheme \(APK Signature Scheme v2\): true/.test(v)&&/v3 scheme \(APK Signature Scheme v3\): true/.test(v));
ck('signer cert SHA-256 = e8bae744…6ce3',cert==='e8bae744ff07c16a636dedfb9339ca2c1e262e49254550cf970b3a8f26f66ce3',cert);
const vo=sh(`${BT}/apksigner verify --print-certs ${OLD} 2>&1`);ck('same signer as 2.7.66',(vo.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1]===cert);
const bd=sh(`${BT}/aapt2 dump badging ${APK} 2>&1`);
ck('package com.toughandj.arcade, versionCode 105, versionName 2.7.67',/package: name='com\.toughandj\.arcade' versionCode='105' versionName='2\.7\.67'/.test(bd),bd.split('\n')[0]);
const bo=sh(`${BT}/aapt2 dump badging ${OLD} 2>&1`);ck('2.7.66 was code 104',/versionCode='104'/.test(bo));
ck('same minSdk/targetSdk/permissions as 2.7.66',['sdkVersion','targetSdkVersion'].every(k=>(bd.match(new RegExp(k+":'(\\d+)'"))||[])[1]===(bo.match(new RegExp(k+":'(\\d+)'"))||[])[1])&&JSON.stringify(bd.match(/uses-permission: name='[^']+'/g))===JSON.stringify(bo.match(/uses-permission: name='[^']+'/g)));

const ents=f=>{const o={};for(const l of sh(`unzip -v ${f}`).split('\n')){const m=l.match(/^\s*\d+\s+\S+\s+\d+\s+\d+%\s+\S+\s+\S+\s+([0-9a-f]{8})\s+(\S.*)$/);if(m)o[m[2]]=m[1];}return o;};
const eN=ents(APK),eO=ents(OLD);const diff=Object.keys(eN).filter(k=>eO[k]!==eN[k]&&!/^META-INF\//.test(k)),gone=Object.keys(eO).filter(k=>!(k in eN)&&!/^META-INF\//.test(k)),added=Object.keys(eN).filter(k=>!(k in eO)&&!/^META-INF\//.test(k));
ck('APK entries identical to 2.7.66 except assets/index.html and AndroidManifest.xml (version)',JSON.stringify(diff.sort())===JSON.stringify(['AndroidManifest.xml','assets/index.html']),{diff,gone,added});
ck('no entries added or removed',gone.length===0&&added.length===0);
const load=t=>{const a=t.indexOf('const GAME_SRC='),b=t.indexOf('// END_PACKED_GAME_SRC');return{t,G:vm.runInNewContext(t.slice(a,b)+'\nGAME_SRC;')};};
const N=load(fromApk(APK,'assets/index.html').toString('utf8')),O=load(fromApk(OLD,'assets/index.html').toString('utf8'));
ck('assets/index.html == assembled bundle (out/index.html)',N.t===fs.readFileSync(B+'/out/index.html','utf8'));
ck('2.7.66 base bundle sha = 98aacb33…',sha(O.t)==='98aacb3359c71462c6c3dc3a2df78924ffff4048a1e57d3ee573687b57b70032');
const kN=Object.keys(N.G),kO=Object.keys(O.G);
ck('167 slots = 166 + pixelwar:v043',kN.length===167&&kO.length===166&&kN.filter(k=>!(k in O.G)).join()==='pixelwar:v043');
ck('every existing slot payload except pixelwar:latest byte-identical to 2.7.66 (165)',kO.filter(k=>k!=='pixelwar:latest').every(k=>O.G[k]===N.G[k])&&kO.filter(k=>k!=='pixelwar:latest').length===165);
ck('pixelwar:latest == frozen 0.4.4 html',N.G['pixelwar:latest']===fs.readFileSync(B+'/out/pixel-war-0.4.4.html','utf8'));
ck('pixelwar:v043 == frozen 0.4.3 html (6dbcb02a…) == old latest',sha(N.G['pixelwar:v043'])==='6dbcb02ac79f094a2e3d5160c7318db984bbb5dd0a1839d3741d377fd12f47d7'&&O.G['pixelwar:latest']===N.G['pixelwar:v043']);
ck('pixelwar:v042 + v041 + v03 unchanged (e8301782…, f3894f84…, acf3fd27…)',sha(N.G['pixelwar:v042'])==='e83017821096e5a30a0bc29e92cd17793414edb861a9982ae66e7cbe04824724'&&sha(N.G['pixelwar:v041'])==='f3894f84d954042021d352673cfa28b6886c29d1a8902c0142e7b0accf249cde'&&sha(N.G['pixelwar:v03'])==='acf3fd2726f61d4f7f6b8706f06ca3b71e273a56f5445653c78ed80c753e77ba');
const gm=t=>{const a=t.indexOf('const GAMES='),e=t.indexOf('\n',a);return JSON.parse(t.slice(a+12,e).replace(/;\s*$/,''));};
const GN=gm(N.t),GO=gm(O.t);const pw=GN.find(g=>g.id==='pixelwar');
ck('pixelwar card: v03, v041, v042, v043, latest(def)',pw&&pw.versions.map(x=>x.id).join()==='v03,v041,v042,v043,latest'&&pw.versions[4].def===true&&pw.versions.slice(0,4).every(v=>!v.def));
ck('every other card identical (25 cards)',GN.filter(g=>g.id!=='pixelwar').length===GO.filter(g=>g.id!=='pixelwar').length&&GN.filter(g=>g.id!=='pixelwar').every((g,i)=>JSON.stringify(g)===JSON.stringify(GO.filter(g=>g.id!=='pixelwar')[i])));
const ZIPS=process.argv.slice(3);
for(const z of ZIPS){const l=sh(`unzip -l ${z}`);ck('source zip has no keystore/key files: '+require('path').basename(z),!/\.jks|\.keystore|KEYSTORE|\.p12|\.pem|storepass/i.test(l));}
const lz=ZIPS.find(z=>/ToughAndJsArcade/.test(z));if(lz){const t=sh(`unzip -p ${lz} 'source/latch-ui/src/lib/bench/model.ts'`);ck('arcade source zip: unlock code is REPLACE-WITH-UNLOCK-CODE',/REPLACE-WITH-UNLOCK-CODE/.test(t));}
fs.writeFileSync(B+'/out/verify-2767.json',JSON.stringify(R,null,1));console.log(R.ok?'VERIFY ALL OK':'VERIFY FAILED');process.exit(R.ok?0:1);
