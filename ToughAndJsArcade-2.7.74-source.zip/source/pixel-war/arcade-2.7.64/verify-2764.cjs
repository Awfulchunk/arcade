// Independent verification of ToughAndJsArcade-2.7.64.apk vs the published 2.7.62 APK. Prints no key material.
const fs=require('fs'),cr=require('crypto'),vm=require('vm'),{execSync,execFileSync}=require('child_process');
const sha=b=>cr.createHash('sha256').update(b).digest('hex');
const B='/workspace/game/build-ship2764',APK=process.argv[2]||B+'/package-2.7.64/out/ToughAndJsArcade-2.7.64.apk';
const OLD='/workspace/game/requests/finished-ship/papa-potato-0.4.1-arcade-2.7.62/ToughAndJsArcade-2.7.62.apk';
const BT='/workspace/tools/sdk/build-tools/34.0.0',JH='/workspace/tools/jdk/bin';
const env=Object.assign({},process.env,{PATH:JH+':'+process.env.PATH});
const sh=c=>execSync(c,{maxBuffer:1<<28,env}).toString();
const R={ok:true,checks:[]};const ck=(n,v,x)=>{R.checks.push({n,pass:!!v,...(x?{x}:{})});console.log(v?'PASS':'FAIL',n,x?JSON.stringify(x).slice(0,260):'');if(!v)R.ok=false;};
const fromApk=(f,n)=>execSync(`unzip -p ${f} '${n}'`,{maxBuffer:1<<28});
ck('2.7.62 APK is the published one (sha256 b1ee9da3…)',sha(fs.readFileSync(OLD))==='b1ee9da3cbb7f7624635022470874b75de73b36552c5327ea90b0e2b047a6581');
// signature / cert
const v=sh(`${BT}/apksigner verify --verbose --print-certs --min-sdk-version 24 ${APK} 2>&1`);
const cert=(v.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1];
ck('apksigner verify OK (v1+v2+v3)',/Verifies/.test(v)&&/v2 scheme \(APK Signature Scheme v2\): true/.test(v)&&/v3 scheme \(APK Signature Scheme v3\): true/.test(v));
ck('signer cert SHA-256 = e8bae744…6ce3',cert==='e8bae744ff07c16a636dedfb9339ca2c1e262e49254550cf970b3a8f26f66ce3',cert);
const vo=sh(`${BT}/apksigner verify --print-certs ${OLD} 2>&1`);ck('same signer as 2.7.62',(vo.match(/certificate SHA-256 digest: ([0-9a-f]{64})/)||[])[1]===cert);
// badging
const bd=sh(`${BT}/aapt2 dump badging ${APK} 2>&1`);
ck('package com.toughandj.arcade, versionCode 102, versionName 2.7.64',/package: name='com\.toughandj\.arcade' versionCode='102' versionName='2\.7\.64'/.test(bd),bd.split('\n')[0]);
const bo=sh(`${BT}/aapt2 dump badging ${OLD} 2>&1`);ck('2.7.62 was code 100 (monotonic increase, 101 skipped)',/versionCode='100'/.test(bo));
ck('same minSdk/targetSdk/permissions as 2.7.62',['sdkVersion','targetSdkVersion'].every(k=>(bd.match(new RegExp(k+":'(\\d+)'"))||[])[1]===(bo.match(new RegExp(k+":'(\\d+)'"))||[])[1])&&JSON.stringify(bd.match(/uses-permission: name='[^']+'/g))===JSON.stringify(bo.match(/uses-permission: name='[^']+'/g)));
// contents vs 2.7.62
const ents=f=>{const o={};for(const l of sh(`unzip -v ${f}`).split('\n')){const m=l.match(/^\s*\d+\s+\S+\s+\d+\s+\d+%\s+\S+\s+\S+\s+([0-9a-f]{8})\s+(\S.*)$/);if(m)o[m[2]]=m[1];}return o;};
const eN=ents(APK),eO=ents(OLD);const diff=Object.keys(eN).filter(k=>eO[k]!==eN[k]&&!/^META-INF\//.test(k)),gone=Object.keys(eO).filter(k=>!(k in eN)&&!/^META-INF\//.test(k)),added=Object.keys(eN).filter(k=>!(k in eO)&&!/^META-INF\//.test(k));
ck('APK entries identical to 2.7.62 except assets/index.html and AndroidManifest.xml (version)',JSON.stringify(diff.sort())===JSON.stringify(['AndroidManifest.xml','assets/index.html']),{diff,gone,added});
ck('no entries added or removed',gone.length===0&&added.length===0);
// bundle + slots
const load=t=>{const a=t.indexOf('const GAME_SRC='),b=t.indexOf('// END_PACKED_GAME_SRC');return{t,G:vm.runInNewContext(t.slice(a,b)+'\nGAME_SRC;')};};
const N=load(fromApk(APK,'assets/index.html').toString('utf8')),O=load(fromApk(OLD,'assets/index.html').toString('utf8'));
ck('assets/index.html == assembled bundle (out/index.html)',N.t===fs.readFileSync(B+'/out/index.html','utf8'));
ck('2.7.62 base bundle sha = 2a2b841d…',sha(O.t)==='2a2b841d0a2c7751367a435caebc3c0b03a7e961d902ae1141d38f145831b036');
const kN=Object.keys(N.G),kO=Object.keys(O.G);
ck('164 slots = 162 + pixelwar:latest + pixelwar:v03',kN.length===164&&kO.length===162&&kN.filter(k=>!(k in O.G)).sort().join()==='pixelwar:latest,pixelwar:v03');
ck('every one of the 162 existing slot payloads byte-identical to 2.7.62',kO.every(k=>O.G[k]===N.G[k]));
ck('pixelwar:latest == frozen 0.4.1 html (f3894f84…)',N.G['pixelwar:latest']===fs.readFileSync(B+'/out/pixel-war-0.4.1.html','utf8')&&sha(N.G['pixelwar:latest'])==='f3894f84d954042021d352673cfa28b6886c29d1a8902c0142e7b0accf249cde');
ck('pixelwar:v03 == frozen 0.3 html (acf3fd27…)',sha(N.G['pixelwar:v03'])==='acf3fd2726f61d4f7f6b8706f06ca3b71e273a56f5445653c78ed80c753e77ba');
const gm=t=>{const a=t.indexOf('const GAMES='),e=t.indexOf('\n',a);return JSON.parse(t.slice(a+12,e).replace(/;\s*$/,''));};
const GN=gm(N.t),GO=gm(O.t);const pw=GN.find(g=>g.id==='pixelwar');
ck('pixelwar card: v03 then latest(def)',pw&&pw.versions.map(x=>x.id).join()==='v03,latest'&&pw.versions[1].def===true);
ck('every other card identical (25 cards)',GN.filter(g=>g.id!=='pixelwar').length===GO.length&&GN.filter(g=>g.id!=='pixelwar').every((g,i)=>JSON.stringify(g)===JSON.stringify(GO[i])));
// secrets: none in the APK assets / source zips
const ZIPS=process.argv.slice(3);
for(const z of ZIPS){const l=sh(`unzip -l ${z}`);ck('source zip has no keystore/key files: '+require('path').basename(z),!/\.jks|\.keystore|KEYSTORE|\.p12|\.pem|storepass/i.test(l));}
const lz=ZIPS.find(z=>/ToughAndJsArcade/.test(z));if(lz){const t=sh(`unzip -p ${lz} 'source/latch-ui/src/lib/bench/model.ts'`);ck('arcade source zip: unlock code is REPLACE-WITH-UNLOCK-CODE',/REPLACE-WITH-UNLOCK-CODE/.test(t));}
fs.writeFileSync(B+'/out/verify-2764.json',JSON.stringify(R,null,1));console.log(R.ok?'VERIFY ALL OK':'VERIFY FAILED');process.exit(R.ok?0:1);
