// Arcade 2.7.64 regression: Pixel War card (v03 + latest 0.4.1) opens, game runs (real touch), Back returns, v03 slot boots, save-key isolation (0.4.1 never writes 0.3 keys), other games unaffected, legacy variant too.
// usage: node arcade-reg-2764.cjs <index.html> <outdir>
const puppeteer=require("/workspace/game/build-needle/gui/node_modules/puppeteer-core");const fs=require("fs");const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const shot=async(p,path)=>{const c=await p.createCDPSession();const r=await c.send("Page.captureScreenshot",{format:"png"});fs.writeFileSync(path,Buffer.from(r.data,"base64"));await c.detach();};
const FILE=process.argv[2],OUT=process.argv[3];fs.mkdirSync(OUT,{recursive:true});
const BASE="/workspace/game/build-potato041/package-2.7.62/app/assets/index.html";
(async()=>{const b=await puppeteer.launch({executablePath:"/usr/bin/google-chrome",headless:"new",args:["--no-sandbox","--autoplay-policy=no-user-gesture-required","--allow-file-access-from-files"]});
 const R=[];const ok=(n,v,d="")=>{R.push({n,pass:!!v,d});console.log(v?"PASS":"FAIL",n,d);};
 // baseline card list from the published 2.7.62 bundle
 const baseT=fs.readFileSync(BASE,"utf8");const ga=baseT.indexOf("const GAMES="),ge=baseT.indexOf("\n",ga);const BG=JSON.parse(baseT.slice(ga+12,ge).replace(/;\s*$/,""));
 async function shell(legacy){const p=await b.newPage();const errs=[];p.on("pageerror",e=>errs.push("shell: "+e.message));p.on("console",m=>{if(m.type()==="error"&&!/Failed to load resource/.test(m.text()))errs.push("console: "+m.text().slice(0,200));});
  await p.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});
  await p.evaluateOnNewDocument(leg=>{try{if(leg)localStorage.setItem("arcade.legacy","1");}catch(e){}
   const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,"srcdoc");Object.defineProperty(HTMLIFrameElement.prototype,"srcdoc",{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message))});addEventListener('unhandledrejection',function(e){__errs.push('rejection '+String(e.reason))})<\/script>";d.set.call(this,typeof v==="string"&&v?v.replace(/<head[^>]*>/i,m=>m+inj):v);},get(){return d.get.call(this);}});},legacy);
  await p.goto("file://"+FILE);await sleep(1500);return{p,errs};}
 for(const legacy of [false,true]){const tag=legacy?"[legacy] ":"";const {p,errs}=await shell(legacy);
  const G=await p.evaluate(()=>GAMES.map(g=>({id:g.id,title:g.title,tagline:g.tagline,accent:g.accent,orient:g.orient,attract:g.attract,back:g.back,score:g.score,tool:g.tool,versions:g.versions})));
  const pi=G.findIndex(g=>g.id==="pixelwar");ok(tag+"card present after Papa Potato, 2 versions (v03, latest = default)",pi===G.findIndex(g=>g.id==="papa-potato")+1&&G[pi].versions.length===2&&G[pi].versions[0].id==="v03"&&!G[pi].versions[0].def&&G[pi].versions[1].id==="latest"&&G[pi].versions[1].def,JSON.stringify(G[pi]&&G[pi].versions.map(v=>v.id+":"+v.name)));
  const strip=g=>JSON.stringify(g);const others=G.filter(g=>g.id!=="pixelwar").map(strip),baseS=BG.map(g=>JSON.stringify({id:g.id,title:g.title,tagline:g.tagline,accent:g.accent,orient:g.orient,attract:g.attract,back:g.back,score:g.score,tool:g.tool,versions:g.versions}));
  ok(tag+"every other card (and every version picker) identical to the published 2.7.62 ("+others.length+" cards)",others.length===BG.length&&others.every((s,i)=>s===baseS[i]));
  await p.evaluate(()=>{localStorage.setItem("pixelwar.v3",JSON.stringify({speed:7,density:3,release:6,cap:3000,wins:2,losses:1}));localStorage.setItem("pixelwar.v3.custom",JSON.stringify({poolSize:5000,burn:20}));});const SENT=await p.evaluate(()=>[localStorage.getItem("pixelwar.v3"),localStorage.getItem("pixelwar.v3.custom")]);
  await p.evaluate(i=>ARCADE.go(i),pi);await sleep(900);await shot(p,OUT+"/"+(legacy?"01L":"01")+"-menu-pixelwar-card.png");
  // real tap on the card's PLAY button -> launches the default (latest 0.4.1)
  const box=await p.evaluate(i=>{const r=document.querySelector('.card[data-i="'+i+'"] .play').getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2};},pi);
  await p.touchscreen.tap(box.x,box.y);await sleep(3200);
  let fr=p.frames().find(f=>f!==p.mainFrame());ok(tag+"tapping the card opens the game (iframe loaded)",!!fr&&await p.evaluate(()=>ARCADE.inGame));
  const info=fr&&await fr.evaluate(()=>({title:document.title,pw:!!window.__pw,ver:document.querySelector("h1")&&document.querySelector("h1").textContent,errs:window.__errs,dpr:devicePixelRatio,canvas:(()=>{const c=document.getElementById("c");return c&&[c.width,c.height]})()}));
  ok(tag+"game booted in the arcade frame (0.4.1, hooks, canvas), 0 JS errors",info&&/0\.4\.1/.test(info.title)&&info.pw&&info.errs.length===0&&info.canvas,JSON.stringify(info));
  await shot(p,OUT+"/"+(legacy?"02L":"02")+"-pixelwar-in-arcade-prep.png");
  // play with real touch: circle, path, START, shape
  const iframe=await p.$("#game iframe");const ib=await iframe.boundingBox();
  const cv=async()=>fr.evaluate(()=>{const r=document.getElementById("c").getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
  const tapSel=async sel=>{const r=await fr.evaluate(sel=>{const e=document.querySelector(sel);const r=e.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2};},sel);await p.touchscreen.tap(ib.x+r.x,ib.y+r.y);await sleep(220);};
  const drag=async pts=>{const l=await cv();const q=pts.map(a=>({x:ib.x+l.x+a[0]*l.s,y:ib.y+l.y+a[1]*l.s}));const t=await p.touchscreen.touchStart(q[0].x,q[0].y);for(const a of q.slice(1)){await t.move(a.x,a.y);await sleep(16);}await t.end();await sleep(200);};
  await sleep(2600);
  await tapSel("#tCircle");await drag([[180,456],[180,456]]);await tapSel("#tMain");await tapSel("#tMain");await drag([[180,456],[184,380],[196,300],[200,220],[196,140]]);
  const pu=await fr.evaluate(()=>__pw.pathUsed(__pw.S.sides[0]));ok(tag+"real touch draws a main path in the arcade ("+Math.round(pu)+")",pu>200,pu);
  await tapSel("#tStart");await sleep(900);const dbg=await fr.evaluate(()=>({ph:__pw.S.phase,msg:__pw.S.msg,tool:__pw.S.tool,tab:document.getElementById("tStart").getBoundingClientRect().top|0}));console.log("   start-diag",JSON.stringify(dbg));await sleep(3600);
  const bt=await fr.evaluate(()=>({ph:__pw.S.phase,tick:__pw.S.tick,act:__pw.S.sides.map(s=>s.active),pool:__pw.S.sides.map(s=>s.pool)}));
  ok(tag+"battle runs in the arcade (phase battle, pixels out, tick advancing)",bt.ph==="battle"&&bt.tick>120&&bt.act[0]>200&&bt.act[1]>0,JSON.stringify(bt));
  await tapSel("#tabS");await tapSel("#shb1");await sleep(300);
  const cd=await fr.evaluate(()=>({txt:document.querySelector("#shb1").children[1].textContent,cls:document.querySelector("#shb1").className}));ok(tag+"tapping ARROW starts its cooldown (button shows seconds left)",/^[0-9.]+s$/.test(cd.txt)&&/cd/.test(cd.cls),JSON.stringify(cd));
  await shot(p,OUT+"/"+(legacy?"03L":"03")+"-pixelwar-in-arcade-battle.png");
  const e1=await fr.evaluate(()=>window.__errs);ok(tag+"0 JS errors after play",e1.length===0&&errs.length===0,JSON.stringify([e1,errs]));
  await tapSel("#tabS");await sleep(200);
  const ls=await p.evaluate(()=>Object.keys(localStorage).filter(k=>/pixelwar/i.test(k)).join());const SENT2=await p.evaluate(()=>[localStorage.getItem("pixelwar.v3"),localStorage.getItem("pixelwar.v3.custom")]);
  ok(tag+"save-key isolation: 0.4.1 left the 0.3 keys (pixelwar.v3, pixelwar.v3.custom) byte-identical and writes its own ("+ls+")",SENT2[0]===SENT[0]&&SENT2[1]===SENT[1]&&/pixelwar\.v41/.test(ls)||SENT2[0]===SENT[0]&&SENT2[1]===SENT[1]&&/pixelwar/.test(ls),JSON.stringify([SENT,SENT2]).slice(0,200));
  // Back: swipe down from the top edge (shell shim), then tap the Arcade tab twice ("Tap again to leave")
  {const t=await p.touchscreen.touchStart(180,8);for(const y of[20,40,70]){await t.move(180,y);await sleep(30);}await t.end();await sleep(500);
   const bb=await p.evaluate(()=>{const e=document.getElementById("back"),r=e.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2,peek:e.classList.contains("peek")};});
   await p.touchscreen.tap(bb.x,bb.y);await sleep(500);const sure=await p.evaluate(()=>document.getElementById("back").textContent);
   await p.touchscreen.tap(bb.x,bb.y);await sleep(1000);
   ok(tag+"Back: top-edge swipe shows the tab ("+bb.peek+"), first tap asks ('"+sure+"'), second tap returns to the menu",bb.peek&&/again/i.test(sure)&&!(await p.evaluate(()=>ARCADE.inGame)),JSON.stringify([bb,sure]));
   if(await p.evaluate(()=>ARCADE.inGame)){await p.evaluate(()=>ARCADE.back());await sleep(800);}}
  await shot(p,OUT+"/"+(legacy?"04L":"04")+"-back-in-menu.png");
  // relaunch: Pixel War again works (fresh start), then back
  await p.evaluate(i=>ARCADE.launch(i),pi);await sleep(2800);fr=p.frames().find(f=>f!==p.mainFrame());const again=fr&&await fr.evaluate(()=>({ok:!!window.__pw,errs:window.__errs}));ok(tag+"relaunch after Back works",again&&again.ok&&again.errs.length===0,JSON.stringify(again));await p.evaluate(()=>ARCADE.back());await sleep(700);
  // the 0.3 slot boots in the arcade and plays a little
  await p.evaluate(i=>ARCADE.launch(i,"v03"),pi);await sleep(3000);{const f3=p.frames().find(f=>f!==p.mainFrame());const r3=f3&&await f3.evaluate(()=>({title:document.title,pw:!!window.__pw,errs:window.__errs,c:(()=>{const c=document.getElementById("c");return c&&[c.width,c.height]})()}));
   ok(tag+"v03 slot launches Pixel War 0.3 (title, hooks, canvas), 0 JS errors",r3&&/0\.3/.test(r3.title)&&r3.pw&&r3.errs.length===0&&r3.c,JSON.stringify(r3));
   if(!legacy)await shot(p,OUT+"/05-pixelwar-v03-slot.png");
   const k3=f3&&await f3.evaluate(()=>{const P=__pw;P.aiPlan(0);P.startBattle();for(let i=0;i<300;i++)P.tick();return{ph:P.S.phase,tick:P.S.tick,act:P.S.sides[0].active,errs:window.__errs.length};});
   ok(tag+"v03 slot plays (battle ticks, pixels out), 0 errors",k3&&k3.ph==="battle"&&k3.act>50&&k3.errs===0,JSON.stringify(k3));
   const SENT3=await p.evaluate(()=>[localStorage.getItem("pixelwar.v3"),localStorage.getItem("pixelwar.v3.custom")]);ok(tag+"v03 slot uses its own keys (pixelwar.v3*) and 0.4.1 keys untouched by it",!!SENT3[0],String(SENT3[0]).slice(0,80));
   await p.evaluate(()=>ARCADE.back());await sleep(700);}
  // other games unaffected
  const oth=[["papa-potato",null],["papa-potato","v03"],["papa-potato","v01"],["swarm",null],["tank",null],["funmotion",null],["pool",null],["tg",null],["words",null],["latch",null]];
  for(const [id,v] of oth){await p.evaluate((id,v)=>{const i=GAMES.findIndex(g=>g.id===id);ARCADE.launch(i,v||undefined);},id,v);await sleep(2800);const f2=p.frames().find(f=>f!==p.mainFrame());const r=f2?await f2.evaluate(()=>({len:document.body?document.body.innerText.length+document.querySelectorAll("canvas").length:0,errs:window.__errs||[]})).catch(e=>({len:0,errs:["eval "+e.message]})):{len:0,errs:["no frame"]};
   ok(tag+id+(v?":"+v:"")+" still launches, 0 JS errors",!!f2&&r.len>0&&r.errs.length===0,JSON.stringify(r).slice(0,200));await p.evaluate(()=>ARCADE.back());await sleep(600);}
  ok(tag+"shell 0 JS errors overall",errs.length===0,errs.join("|").slice(0,300));await p.close();}
 const f=R.filter(r=>!r.pass).length;console.log("ARCADE-REG-2764 "+(R.length-f)+" pass / "+f+" fail");fs.writeFileSync(OUT+"/results.json",JSON.stringify(R,null,1));await b.close();process.exit(f?1:0);})();
