// Arcade 2.7.64 = published 2.7.62 bundle + TWO new cartridge slots "pixelwar:latest" (Pixel War 0.4.1) and "pixelwar:v03" (Pixel War 0.3) + one card + legacy parts.
// Every existing slot payload, legacy variant and shell text byte-for-byte unchanged.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2764";
const BASE = "/workspace/game/build-potato041/package-2.7.62/app/assets/index.html";
const NEWF = `${B}/out/pixel-war-0.4.1.html`, OLDF = `${B}/out/pixel-war-0.3.html`;
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "2a2b841d0a2c7751367a435caebc3c0b03a7e961d902ae1141d38f145831b036", "2.7.62 base hash mismatch: " + sha(src));
const NEW = fs.readFileSync(NEWF, "utf8"), OLD = fs.readFileSync(OLDF, "utf8");
const FZ = Object.fromEntries(fs.readFileSync(`${B}/frozen-hashes.sha256`, "utf8").trim().split("\n").map((l) => { const [h, f] = l.trim().split(/\s+/); return [f.replace(/^out\//, ""), h]; }));
assert(sha(NEW) === FZ["pixel-war-0.4.1.html"], "pixel war 0.4.1 html != frozen");
assert(sha(OLD) === FZ["pixel-war-0.3.html"] && sha(OLD) === "acf3fd2726f61d4f7f6b8706f06ca3b71e273a56f5445653c78ed80c753e77ba", "pixel war 0.3 html != frozen");
const KN = "pixelwar:latest", KV = "pixelwar:v03";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(!before[KN] && !before[KV], "slot already exists"); assert(Object.keys(before).length === 162, "162 slots before");
const G0 = GS(src);
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
// append the new slot as the last entry of GAME_SRC
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = src.indexOf(endM); assert(ei > 0, "end marker");
let out = src.slice(0, ei) + ',\n"' + KV + '":' + ex(OLD) + ',\n"' + KN + '":' + ex(NEW) + src.slice(ei);
// card: new game right after papa-potato
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
assert(!GAMES.some((g) => g.id === "pixelwar"), "card exists"); const pi = GAMES.findIndex((g) => g.id === "papa-potato"); assert(pi >= 0, "papa card");
const card = { id: "pixelwar", title: "PIXEL WAR", tagline: "Draw a path, send streams of pixels, break through the enemy. You vs the AI.", accent: "#3b6cff", orient: "portrait", attract: "generic", back: "ml",
  versions: [{ id: "v03", name: "v0.3 – first test build (2.7.64)", desc: "Pixel War 0.3 (test build, kept as an older version). Each circle holds a 10,000-pixel pool that is also its health: every enemy pixel that reaches it burns 20 (500 hits to lose), and each pixel has 20 lives. Shapes (LINE, ARROW, WEDGE, DIAMOND, DOUBLE, SPIRAL) are cooldown abilities that form inside your lane by borrowing pixels from the stream. Tightly packed pixels bounce and survive more than loose ones. Walls block both sides. Keeps its own saves (pixelwar.v3).", def: false }, { id: "latest", name: "v0.4.1 – Latest (soft areas, knock-out, shape editor)", desc: "Pixel War 0.4.1 (test build). Each circle holds a 10,000-pixel pool that is also its health: every enemy pixel that reaches it burns 20 (500 hits to lose), and each pixel has 20 lives. You set DENSITY, FLOW and PACE. Lanes are soft yellow hitboxes: WIDE (about 5x a thin lane), NARROW (hugging the line), ARROW (thin shaft ballooning into a rounded head up to about 3x thin). Shapes (LINE, ARROW, WEDGE, RING, DIAMOND, DOUBLE, SPIRAL) are cooldown abilities: a soft yellow area opens in your lane, borrows pixels from the stream, and its pixels wander freely inside it, denser along the line. Hits knock pixels out of the area; they rejoin when close, and are recalled to the circle 2 inches past the shape edge. Draw your own shape outlines in the SHAPE EDITOR (up to 6). Walls have 1000 HP per section and take 5 damage per hit; erasing a branch is free. Pixels stay a constant crisp 2x2. CUSTOM GAME exposes every rule. Your 0.3 / 0.4 settings carry over; 0.3 stays playable with its own saves.", def: true }] };
GAMES.splice(pi + 1, 0, card);
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// legacy parts for the new slot
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const rep = {}; const pN = legacyParts(NEW, rep); assert(rep.jsFail.length === 0, "legacy js fail 0.4.1");
assert(joinParts(pN, NEW) === legacyHtml(NEW, {}), "parts mismatch 0.4.1");
const rep3 = {}; const pO = legacyParts(OLD, rep3); assert(rep3.jsFail.length === 0, "legacy js fail 0.3");
assert(joinParts(pO, OLD) === legacyHtml(OLD, {}), "parts mismatch 0.3");
const LEG2 = { ...LEG, [KV]: pO, [KN]: pN };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// ---- verification ----
const after = slots(out);
assert(Object.keys(after).length === 164, "164 slots after");
for (const k of Object.keys(before)) assert(after[k][2] === before[k][2], "slot text changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([KV, KN]), "only new slots are " + KV + ", " + KN);
const G1 = GS(out); assert(G1[KN] === NEW && G1[KV] === OLD, "new payloads"); for (const k of Object.keys(G0)) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const ei2 = s.indexOf("\n};})(); // END_PACKED_GAME_SRC"); const k = s.indexOf(',\n"' + KV + '":'); if (k >= 0 && k < ei2) s = s.slice(0, k) + s.slice(ei2); return s; };
assert(strip(out) === strip(src), "shell text changed outside GAMES / new slot / GAME_LEGACY");
// other cards unchanged
const oldCards = GAMES.filter((g) => g.id !== "pixelwar"); const G62 = JSON.parse(gJson); assert(JSON.stringify(oldCards) === JSON.stringify(G62), "other cards changed");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.64", versionCode: 102, newCard: "pixelwar", newSlots: [KV, KN], gameHtmlSHA256: sha(NEW), gameHtmlBytes: Buffer.byteLength(NEW), oldHtmlSHA256: sha(OLD), baseBundleSHA256_2762: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out),
  cartridgeSlotsBefore: 162, cartridgeSlotsAfter: Object.keys(after).length, changedSlots: [], legacy: `css ${rep.css} js ${rep.js}`, menuOrder: GAMES.map((g) => g.id) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
