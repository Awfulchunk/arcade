import sys,re
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
t=e.t
# ---- branch colours
e.ed("const BRC='#7a2fd0';","const BRCOL=['#7a2fd0','#e07a00','#0a9a5a','#d6307a','#1a8fd0'],BRT=['rgb(205,180,240)','rgb(255,205,150)','rgb(165,225,195)','rgb(245,185,210)','rgb(170,215,245)'];\nconst brCol=id=>BRCOL[(id-1)%5];")
t=e.t.replace("P.id?BRC:","P.id?brCol(P.id):");e.t=t
e.ed("ctx.lineWidth=Math.max(1,1.6*sc);ctx.beginPath();ctx.moveTo(X(p[0]),Y(p[1]));for(let k=1;k<n;k++)","ctx.lineWidth=Math.max(1,(sd.id===ME&&P.id===selP&&S.phase!=='prep'?2.6:1.6)*sc);ctx.beginPath();ctx.moveTo(X(p[0]),Y(p[1]));for(let k=1;k<n;k++)")
e.ed("const hw=laneHW(sd.set);for(const P of sd.paths){if(!P||P.p.length<4)continue;key+=","for(const P of sd.paths){if(!P||P.p.length<4)continue;const hw=laneHW(pset(sd,P));key+=")
e.ed("(P.id?'rgb(150,190,255)':YEL)","(P.id?BRT[(P.id-1)%5]:YEL)")
# ---- hud()
a=e.t.index("function hud(){")
b=e.t.index("let revPane=false")
newhud=r'''const PW=['crawl','very slow','slow','easy','steady','steady','brisk','brisk','quick','top'],DW=v=>v<=3?'loose':v<=7?'medium':'tight',SW=v=>v<=3?'close':v<=7?'medium':'far',WW=v=>v<=3?'narrow':v<=7?'medium':'wide';
let chipK='';
function hud(){const me=S.sides[ME],foe=S.sides[1-ME],prep=S.phase==='prep',sb=sbx();
  lastPhase=S.phase;
  setD('main',S.over?'none':'block');setD('result',S.over?'block':'none');
  if(selP>0&&!me.paths[selP])selP=0;
  const sP=me.paths[selP]||me.paths[0],ps=pset(me,sP);
  let st;if(S.over)st=S.winner===0?(sb?'BLUE WINS':'YOU WIN'):S.winner===1?(sb?'RED WINS':'YOU LOSE'):'DRAW';
  else if(prep){const need=prepNeeds(me),left=CFG.prepSec>0?'  '+Math.max(0,Math.ceil(CFG.prepSec-S.prepT))+'s':'';
    st=S.msg||(S.aiRev<1?'The enemy is drawing its plan on its own side. Watch it, then draw yours.':need.indexOf('path')>=0?'STEP 1: draw your ATTACK PATH. Drag from your circle toward the enemy.':need.indexOf('wall')>=0?'STEP 2: draw your DEFENSE LINE across your side. Leave gaps for your own pixels.':'Ready. Press START. Branches are drawn later, during the match.');st+=left;}
  else if(sb)st=S.msg||((S.paused?'SANDBOX paused. ':'SANDBOX. ')+'You are editing the '+(ME===0?'BLUE':'RED')+' side.');
  else st=S.msg||((S.paused?'PAUSED ':'')+fmtT(S.tick)+(CFG.stage?'  STAGE '+CFG.stage:'')+(S.ai&&S.ai.lessons.length?'  Enemy learned '+S.ai.lessons.length:'')+'  Tap a path to change its sliders.');
  setT('status',st);setT('btnPause',S.paused?'PLAY':'PAUSE');setD('btnStep',sb&&S.paused&&!S.over?'block':'none');
  if(selP===0){const pu=pathUsed(me);setT('tP','PATH '+Math.max(0,Math.round(CFG.pathMax-pu)));setW('mP',(CFG.pathMax-pu)/CFG.pathMax*100);$('mP').firstElementChild.style.background='#e8e8f0';}
  else{setT('tP','BR'+selP+' '+Math.round(brLeft(me,sP)));setW('mP',brLeft(me,sP)/CFG.brMax*100);$('mP').firstElementChild.style.background=brCol(selP);}
  const wu=wallUsed(me);setT('tW','WALL '+Math.max(0,Math.round(CFG.wallMax-wu)));setW('mW',(CFG.wallMax-wu)/CFG.wallMax*100);
  setT('tY',(sb?(ME===0?'BLUE ':'RED '):'YOU ')+Math.max(0,me.pool));setW('hY',me.pool/poolN()*100);setT('tF',(sb?(ME===0?'RED ':'BLUE '):'ENEMY ')+Math.max(0,foe.pool));setW('hF',foe.pool/poolN()*100);
  const toolOk={circle:prep||sb,main:prep||sb,branch:canBr(me)&&CFG.maxBr>0,wall:canWall(me),gate:canWall(me)&&!!CFG.gate&&(sb||feat('gate')),erase:canWall(me)||canBr(me)||prep||sb};
  for(const t of['circle','main','branch','wall','gate','erase']){const id='t'+t[0].toUpperCase()+t.slice(1);setD(id,toolOk[t]?'block':'none');setC(id,S.tool===t);}
  const ready=prep&&!sb&&prepNeeds(me).length===0&&S.aiRev>=1;
  setD('tStart',prep&&!sb?'block':'none');if(hudCache.rdy!==ready){hudCache.rdy=ready;$('tStart').classList.toggle('go',ready);$('tStart').classList.toggle('wait',!ready);}
  setT('tStart',ready?'START':'START (finish the steps)');
  setD('tSwap',sb?'block':'none');setT('tSwap',ME===0?'EDIT: BLUE':'EDIT: RED');setD('tRefill',sb?'block':'none');
  // path chips (during the match): MAIN and each branch, each its own colour and its own meter
  const showChips=!prep;setD('chips',showChips?'flex':'none');
  if(showChips){const ck=ME+':'+me.paths.map((P,i)=>P?i:'-').join('')+':'+selP;if(ck!==chipK){chipK=ck;const h=$('chips');h.innerHTML='';me.paths.forEach((P,i)=>{if(!P)return;const b=document.createElement('button');b.className='chip'+(i===selP?' on':'');b.dataset.id=i;b.textContent=i?'BRANCH '+i:'MAIN';b.style.borderColor=i?brCol(i):'#e8e8f0';b.style.color=i&&i!==selP?brCol(i):'';const m=document.createElement('i');b.appendChild(m);b.addEventListener('click',()=>{selP=i;});h.appendChild(b);});}
    for(const b of $('chips').children){const i=+b.dataset.id,P=me.paths[i];if(!P)continue;const f=i?brLeft(me,P)/CFG.brMax:(CFG.pathMax-pathUsed(me))/CFG.pathMax,w=Math.round(clamp(f,0,1)*100)+'%';if(b.firstElementChild.style.width!==w)b.firstElementChild.style.width=w;}}
  // slider rows: they change the selected path only
  const nm=selP?'BRANCH '+selP:'MAIN PATH';setT('slh','Sliders for: '+nm+(selP?'':'   (tap a path or a button to pick another)'));$('slh').style.color=selP?brCol(selP):'#e8e8f0';
  setT('lSp','PACE\n'+ps.speed+' '+PW[ps.speed-1]);setT('lDe','DENSITY\n'+ps.density+' '+DW(ps.density));setT('lSpc','SPACING\n'+ps.spacing+' '+SW(ps.spacing));setT('lWd','LANE WIDTH\n'+ps.width+' '+WW(ps.width));
  const rm=$('sRe');if(rm.dataset.m!==(selP?'b':'m')){rm.dataset.m=selP?'b':'m';rm.min=selP?0:1;rm.max=selP?100:10;rm.step=selP?5:1;}
  setT('lRe',selP?'SHARE\n'+sP.share+'% of main':'FLOW\n'+me.set.release+' of 10');rm.disabled=selP>0&&!!CFG.autoDist;
  setT('tLane','LANE: '+LANES[sP.lane|0]);
  $('legacy').style.display=CFG.shapesOn?'block':'none';
  setT('lAt','AT '+sP.sh.at);setT('lSh',selP?'SHARE '+sP.share:'SHARE -');setT('lCa','OUT '+me.active);setT('lSD','SHAPE D '+me.set.sdens);setT('lCo','COMPACT '+me.set.compact);
  if(S.over){if(!revInit){revInit=true;revPane=!!S.aiReview;}setT('rTitle',st);const rk=S.tick+':'+revPane+':'+(S.aiReview?1:0);if(hudCache.rk!==rk){hudCache.rk=rk;renderResult();}
    setD('btnRev',S.aiReview?'block':'none');setT('btnRev',revPane?'STATS':'AI REVIEW');}else{hudCache.rk=null;revInit=false;revPane=false;}
  const sl=[['sSp',ps.speed],['sDe',ps.density],['sSpc',ps.spacing],['sWd',ps.width],['sRe',selP?sP.share:me.set.release],['sCa',me.set.cap],['sSD',me.set.sdens],['sCo',me.set.compact],['sPu',sP.sh.pull],['sAt',sP.sh.at]];
  for(const q of sl){const el=$(q[0]);if(document.activeElement!==el&&+el.value!==q[1])el.value=q[1];}
}
'''
e.t=e.t[:a]+newhud+e.t[b:]
# setT supports multi-line label text
# ---- handlers
e.ed("for(const q of[['sSp','speed'],['sDe','density'],['sRe','release'],['sCa','cap'],['sSD','sdens'],['sCo','compact']]){$(q[0]).addEventListener('input',e=>setSetting(ME,q[1],+e.target.value));$(q[0]).addEventListener('change',savePrefs);}",
"for(const q of[['sSp','speed'],['sDe','density'],['sSpc','spacing'],['sWd','width']]){$(q[0]).addEventListener('input',e=>setPathSetting(ME,selP,q[1],+e.target.value));$(q[0]).addEventListener('change',savePrefs);}\n$('sRe').addEventListener('input',e=>{if(selP)setShare(ME,selP,+e.target.value);else setSetting(ME,'release',+e.target.value);});$('sRe').addEventListener('change',savePrefs);\nfor(const q of[['sCa','cap'],['sSD','sdens'],['sCo','compact']]){$(q[0]).addEventListener('input',e=>setSetting(ME,q[1],+e.target.value));$(q[0]).addEventListener('change',savePrefs);}\nfor(const b of document.querySelectorAll('.pm')){b.addEventListener('click',()=>{const el=$(b.dataset.for),stp=+el.step||1,v=clamp(+el.value+(+b.dataset.d)*stp,+el.min,+el.max);el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));});}\n$('tRefill').addEventListener('click',()=>{sandboxRefill();S.msg='Pools refilled';});$('btnStep').addEventListener('click',()=>{sandboxStep(10);});")
e.ed("for(const t of['D','S','F'])$('tab'+t).addEventListener('click',()=>{curTab=t;});\n","")
e.ed("$('tSwap').addEventListener('click',()=>{ME=1-ME;selP=0;ptr=null;S.tool='main';chipKey='';});","$('tSwap').addEventListener('click',()=>{ME=1-ME;selP=0;ptr=null;S.tool='main';chipKey='';chipK='';});")
# prefs: width / spacing
e.ed("for(const k of['speed','density','release','cap','sdens','compact'])if(fin(+v[k])","for(const k of['speed','density','release','cap','sdens','compact','width','spacing'])if(fin(+v[k])")
e.ed("compact:s.compact,wins:prefs.wins","compact:s.compact,width:s.width,spacing:s.spacing,wins:prefs.wins")
# legacy chips builder target
e.ed("const h=$('chips');h.innerHTML='';me.paths.forEach((P,i)=>{if(!P)return;const b=document.createElement('button');b.className='chip'","const h=$('chips');h.innerHTML='';me.paths.forEach((P,i)=>{if(!P)return;const b=document.createElement('button');b.className='chip'",0) if False else None
e.save()
