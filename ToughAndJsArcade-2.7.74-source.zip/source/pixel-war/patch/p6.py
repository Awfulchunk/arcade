# 0.4.1 engine: free-wander hitbox AREAS replace slot formations
import sys,re
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
L=e.t.split('\n')
def find(prefix,start=0):
    for k in range(start,len(L)):
        if L[k].startswith(prefix): return k
    print('NO LINE',prefix); sys.exit(1)
def rep(startp,endp,new,incl_end=False):
    a=find(startp); b=find(endp,a)
    if incl_end: b+=1
    L[a:b]=new.split('\n'); 
def one(startp,new):
    a=find(startp); L[a]=new

# ---- constants / keys
one("const MAXCUS=6,NSH=7+MAXCUS","const MAXCUS=6,NSH=7+MAXCUS,POLYMAX=24,MX=22,MY=18;")
one("const KEY='pixelwar.v4'","const KEY='pixelwar.v41',KEYC='pixelwar.v41.custom',KEYF='pixelwar.v41.forms',KEY4='pixelwar.v4',KEYC4='pixelwar.v4.custom',KEYF4='pixelwar.v4.forms',KEY3='pixelwar.v3',KEYC3='pixelwar.v3.custom';")
one("const LANES=['NORMAL'","const LANES=['NORMAL','WIDE','NARROW','TAPERED','ARROW'],LMAX=[1,2.0,0.4,2.0,1.2];")
# ---- lane factors
a=find("function laneF(ty,t)")
L[a:a+2]="""function laneF(ty,t){if(t<0)t=0;else if(t>1)t=1;switch(ty){case 1:return 2.0;case 2:return 0.4;case 3:return 2.0-1.6*t;
  case 4:{if(t<0.45)return 0.4;if(t<0.88)return 0.4+0.8*Math.sin((t-0.45)/0.43*1.5708);const x=(t-0.88)/0.12;return 1.2*Math.sqrt(Math.max(0,1-x*x));}default:return 1;}}""".split('\n')
# ---- forms block
rep("// ---------- FORMATION PRESETS","// ---------- STATE","""// ---------- SHAPE OUTLINES: the outline editor's saved shapes (localStorage, validated like every other save). A form = a closed OUTLINE polygon in a unit box: x 0..1 across, y 0 (front) .. 1 (back).
let PRESETS=[];
function hullPts(pts){const p=pts.map(a=>[a[0],a[1]]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);if(p.length<3)return p;
  const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);const lo=[];for(const q of p){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],q)<=0)lo.pop();lo.push(q);}
  const up=[];for(let k=p.length-1;k>=0;k--){const q=p[k];while(up.length>=2&&cr(up[up.length-2],up[up.length-1],q)<=0)up.pop();up.push(q);}up.pop();lo.pop();return lo.concat(up);}
function polyArea(p){let a=0;for(let k=0,n=p.length;k<n;k++){const u=p[k],v=p[(k+1)%n];a+=u[0]*v[1]-v[0]*u[1];}return a/2;}
function polySelfX(p){const n=p.length;for(let i=0;i<n;i++){const a=p[i],b=p[(i+1)%n];for(let j=i+2;j<n;j++){if(i===0&&j===n-1)continue;const c=p[j],d=p[(j+1)%n];if(segX(a[0],a[1],b[0],b[1],c[0],c[1],d[0],d[1]))return true;}}return false;}
function inPoly(p,x,y){let c=false;for(let i=0,j=p.length-1;i<p.length;j=i++){const a=p[i],b=p[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])c=!c;}return c;}
// accepts {name,poly:[[x,y]..]} or a v4 {name,cells:[[col,row]..]} (converted to its hull). Self-crossing outlines become their convex hull; <=24 points; minimum area.
function cleanForm(f){if(!f||typeof f!=='object')return null;let poly=[];
  if(Array.isArray(f.poly)){for(const c of f.poly){if(poly.length>=POLYMAX*2)break;if(!Array.isArray(c))continue;const x=+c[0],y=+c[1];if(!fin(x)||!fin(y))continue;poly.push([clamp(x,0,1),clamp(y,0,1)]);}}
  else if(Array.isArray(f.cells)){const pts=[];let n=0;for(const c of f.cells){if(n++>=120)break;if(!Array.isArray(c))continue;const x=Math.floor(+c[0]),y=Math.floor(+c[1]);if(!(x>=0&&x<15&&y>=0&&y<12))continue;pts.push([x/15,y/12],[(x+1)/15,y/12],[x/15,(y+1)/12],[(x+1)/15,(y+1)/12]);}poly=hullPts(pts);}
  const q=[];for(const c of poly){const l=q[q.length-1];if(l&&Math.abs(l[0]-c[0])<0.004&&Math.abs(l[1]-c[1])<0.004)continue;q.push(c);}
  if(q.length>1&&Math.abs(q[0][0]-q[q.length-1][0])<0.004&&Math.abs(q[0][1]-q[q.length-1][1])<0.004)q.pop();
  if(q.length<3)return null;let r=q;if(r.length>POLYMAX||polySelfX(r))r=hullPts(r);
  if(r.length>POLYMAX){const st=Math.ceil(r.length/POLYMAX);r=r.filter((a,k)=>k%st===0);}
  if(r.length<3||Math.abs(polyArea(r))<0.03)return null;
  return{name:String(typeof f.name==='string'&&f.name?f.name:'FORM').slice(0,10),poly:r.map(a=>[Math.round(a[0]*1000)/1000,Math.round(a[1]*1000)/1000])};}
function cloneForms(){return PRESETS.map(f=>({name:f.name,poly:f.poly.map(c=>[c[0],c[1]])}));}
function loadForms(){const a=[];let raw=null;try{raw=JSON.parse(localStorage.getItem(KEYF)||localStorage.getItem(KEYF4)||'null');}catch(e){}
  if(Array.isArray(raw))for(const f of raw){if(a.length>=MAXCUS)break;const c=cleanForm(f);if(c)a.push(c);}PRESETS=a;}
function saveForms(){try{localStorage.setItem(KEYF,JSON.stringify(PRESETS.map(f=>({name:f.name,poly:f.poly}))));}catch(e){}}
function syncForms(){if(!S)return;for(const sd of S.sides)if(sd.human){sd.forms=cloneForms();for(let t=7;t<NSH;t++)sd.shReady[t]=0;}}
function addPreset(name,poly){if(PRESETS.length>=MAXCUS)return -1;const c=cleanForm({name:name||('CUSTOM '+(PRESETS.length+1)),poly:poly});if(!c)return -1;PRESETS.push(c);saveForms();syncForms();return PRESETS.length-1;}
function delPreset(i){i=Math.floor(i);if(!(i>=0&&i<PRESETS.length))return false;PRESETS.splice(i,1);saveForms();syncForms();return true;}
const shName=(sd,t)=>t<7?SHAPES[t]:(sd.forms[t-7]?sd.forms[t-7].name:'C'+(t-6));
""")
# remove old blank-lines safety: fine
# ---- state arrays
one("const psq=new Int16Array(NP).fill(-1)","const psq=new Int16Array(NP).fill(-1),pslot=new Int16Array(NP),pgc=new Uint8Array(NP),plu=new Float32Array(NP),plv=new Float32Array(NP);")
e.t='\n'.join(L); L=e.t.split('\n')
# ---- config
e.ed("segHP:700,wallDmg:1,","segHP:1000,wallDmg:5,")
e.ed("laneDef:0,brWaste:30,","laneDef:0,brWaste:0,koMargin:5,knockK:36,")
e.ed("sqN:300,tint:1,","sqN:300,tint:0,")
e.ed("autoDist:0,reslot:0,","autoDist:0,")
e.ed("['brWaste','Branch meter lost when erased in battle %','the rest is refunded; erasing in prep is free; total branch meter = branch meter x max branches','r',0,100,10]","['brWaste','Branch meter lost when erased in battle %','0 = erasing is free (Jay): the meter comes back at once; total branch meter = branch meter x max branches','r',0,100,10]")
e.ed("['tint','Tint shape pixels','shape pixels draw in a brighter color so you can see the formation','b']","['tint','Tint shape pixels','shape pixels draw in a brighter color (off: every pixel is the same blue or red)','b']")
e.ed("['reslot','Re-shape existing formations','when you switch shape','b']","['koMargin','Knock-out distance','how far outside its shape area a pixel must be pushed to count as knocked out','r',2,16,1],['knockK','Collision knock','extra shove a shape pixel takes from every contact','r',0,80,4]")
e.ed("['shapeLane','Shape width vs lane','1 = full lane width; shapes never grow the lane','r',0.4,1,0.1]","['shapeLane','Shape area width','area half-width = this x lane half-width (never above 1.2 x = 3x the thin lane); shapes borrow, they never grow the lane','r',0.4,1,0.1]")
e.ed("['leash','Leash distance','the \"2 inches\"','r',30,140,6]","['leash','Leash distance','the \"2 inches\": past this from the path, or from a shape area edge, a pixel goes home','r',30,140,6]")
e.ed("['laneDef','Default lane shape','the hitbox area the pixels occupy: normal, wide, narrow, tapered, arrow','e']","['laneDef','Default lane shape','the yellow hitbox band the pixels occupy: normal, wide (about 5x thin), narrow (thin, dense), tapered, arrow (a rounded bubble up to 3x thin)','e']")
e.ed("['orient','Formation orientation','','e'],['bias','Pixel weight in formation','','e']","['orient','Shape orientation','','e'],['bias','Pixel weight in shape','','e']")
e.ed("['reformSec','Formation reform time (s)','how long a hit formation takes to get back to its preferred arrangement','r',0.5,8,0.5],['shockK','Formation damage per impact %','how much each impact distorts a formation (stretch, compress, break)','r',0,20,1],['breakLive','Formation breaks below % pixels','a formation with fewer live pixels than this disbands','r',5,60,5]","['reformSec','Shape regroup time (s)','how long a hit shape takes to pull its pixels back in','r',0.5,8,0.5],['shockK','Shape damage per impact %','how much each impact loosens a shape (weaker pull, more jitter)','r',0,20,1],['breakLive','Shape breaks below % pixels','a shape with fewer live pixels than this disbands','r',5,60,5]")
e.ed("['sqN','Pixels borrowed per shape','','r',40,600,20]","['sqN','Pixels borrowed per shape','at SHAPE DENS 7; the stream behind the shape thins by this much','r',40,600,20]")
# ---- stats
e.ed("formBreaks:0,formReforms:0,gatePass:0,","formBreaks:0,formReforms:0,knocked:0,reentered:0,koRecall:0,gatePass:0,")
# ---- old reslot in setShape + duplicate
e.ed("function setShape(side,id,t){const sd=S.sides[side],P=getPath(sd,id);if(!P||!fin(t))return false;t=clamp(Math.round(t),0,6);if(P.sh.t===t)return true;P.sh.t=t;\n  if(CFG.reslot){for(let q=0;q<MAXSQ;q++){const sq=sd.sq[q];if(sq&&sq.pid===id&&t>0)reslot(sd,sq,t);}}return true;}\n","")
e.ed("function setShape(side,id,t){const sd=S.sides[side],P=getPath(sd,id);if(!P||!fin(t))return false;t=clamp(Math.round(t),0,6);P.sh.t=t;return true;}","function setShape(side,id,t){const sd=S.sides[side],P=getPath(sd,id);if(!P||!fin(t))return false;t=Math.round(t);if(!shapeOkS(sd,t)&&t!==0)return false;P.sh.t=t;return true;}")
# ---- arrow = rounded teardrop bubble
e.ed("case 1:{if(u>=-0.45)return Math.abs(v)<=-u*1.556;return Math.abs(v)<=0.1;}                       // ARROW: head + shaft",
"case 1:{const x=-u;let w;if(x<0.3)w=0.7*Math.sqrt(Math.max(0,1-((x-0.3)/0.3)*((x-0.3)/0.3)));else if(x<0.72)w=Math.max(0.12,0.7*Math.sqrt(Math.max(0,1-((x-0.3)/0.42)*((x-0.3)/0.42))));else w=0.12;return Math.abs(v)<=w;}   // ARROW: a rounded teardrop bubble on a thin shaft")
e.ed("// ---------- SHAPES (formations are squads of individual pixels steering toward slots; never rigid bodies)","// ---------- SHAPES (a shape = a soft hitbox AREA riding the path; its pixels wander freely inside it)")
open('/workspace/game/build-pixelwar042/index.html','w',encoding='utf8').write(e.t)
e=E(); L=e.t.split('\n')
# ---- shapeSlots block -> areas
rep("function formPts(F)","function fPos(P)","""// AREAS. areaDef = the soft hitbox of a shape in LOCAL coordinates (u along the path, 0 = front and negative behind; v across): an inside-mask grid plus a signed distance-to-edge grid (world units, negative inside).
// Built-in shapes use inShape; custom shapes rasterize their outline. width: half-width never above 1.2 x lane half-width (3x the thin lane 0.4).
const areaCache=new Map();
function areaDef(t,hw,f0,sd){let F=null;if(t>=7){F=sd&&sd.forms[t-7];if(!F||!F.poly)return areaDef(0,hw,f0,sd);}
  const rad=Math.min(1.2*hw,CFG.shapeLane*hw*Math.max(f0,0.5)),disc=!F&&(t===3||t===6),Lu=disc?2*rad:clamp(CFG.shapeLen*hw,8,48),fl=CFG.orient===1;
  let sig=0;if(F)for(const c of F.poly)sig=(Math.imul(sig,31)+Math.round(c[0]*1000)*7+Math.round(c[1]*1000))|0;
  const key=(F?'C'+sig:t)+'|'+Lu.toFixed(1)+'|'+rad.toFixed(1)+'|'+(fl?1:0);let D=areaCache.get(key);if(D)return D;
  const cu=Lu/MX,cv=2*rad/MY,mask=new Uint8Array(MX*MY),ins=[],out=[];
  for(let iv=0;iv<MY;iv++)for(let iu=0;iu<MX;iu++){const u=-(iu+0.5)*cu,v=(iv+0.5)*cv-rad;let a;
    if(F)a=inPoly(F.poly,(v/rad+1)/2,fl?1+u/Lu:-u/Lu);else a=inShape(t,fl&&!disc?-1-u/Lu:u/Lu,disc?v/(2*rad):v/rad*0.7);
    if(a){mask[iv*MX+iu]=1;ins.push(iv*MX+iu);}else out.push(iv*MX+iu);}
  if(ins.length<6)return areaDef(0,hw,f0,sd);
  const dist=new Float32Array(MX*MY),hc=0.5*Math.min(cu,cv);let su=0;
  for(let a=0;a<MX*MY;a++){const iu=a%MX,iv=(a/MX)|0,ia=mask[a],opp=ia?out:ins;let best=1e9;
    for(let q=0;q<opp.length;q++){const b=opp[q],du=((b%MX)-iu)*cu,dv=(((b/MX)|0)-iv)*cv,d=du*du+dv*dv;if(d<best)best=d;}
    best=best<1e9?Math.sqrt(best):1e3;
    if(ia){const eb=Math.min((iu+0.5)*cu,(MX-iu-0.5)*cu,(iv+0.5)*cv,(MY-iv-0.5)*cv);best=Math.min(best,eb+hc);}
    dist[a]=ia?-Math.max(0.1,best-hc):Math.max(0.1,best-hc);}
  for(const a of ins)su+=(a%MX+0.5)*cu;
  D={t:t,Lu:Lu,rad:rad,cu:cu,cv:cv,mask:mask,dist:dist,list:ins,cu0:-su/ins.length,rot:!F&&t===6,rc:-Lu/2,disc:disc};areaCache.set(key,D);if(areaCache.size>200)areaCache.clear();return D;}
// signed distance (world units) from local point (u,v) to the area edge: negative inside
function sdAt(D,u,v){const eu=u>0?u:(u<-D.Lu?-D.Lu-u:0),ev=v>D.rad?v-D.rad:(v<-D.rad?-D.rad-v:0);
  let iu=(-u/D.cu)|0,iv=((v+D.rad)/D.cv)|0;if(iu<0)iu=0;else if(iu>=MX)iu=MX-1;if(iv<0)iv=0;else if(iv>=MY)iv=MY-1;
  const d=D.dist[iv*MX+iu];return(eu||ev)?Math.max(d,0)+Math.sqrt(eu*eu+ev*ev):d;}
// a wander spot inside the area: denser along the centre line (gaussian across, sigma q.sg), arrow/wedge fronts fuller, orientation and weight as set
function sampleArea(q,out){const D=q.def,Ls=D.list,n=Ls.length,sg=q.sg,af=CFG.arrowFront/100;
  for(let g=0;g<40;g++){const c=Ls[(rnd()*n)|0],iu=c%MX,iv=(c/MX)|0,u=-(iu+rnd())*D.cu,v=(iv+rnd())*D.cv-D.rad;
    if(rnd()>=Math.exp(-v*v/(2*sg*sg)))continue;const un=u/D.Lu,ue=CFG.orient===1?-1-un:un;
    if(af>0&&(D.t===1||D.t===2)&&rnd()>=(1-af)+af*Math.pow(1+ue,1.5))continue;
    if(CFG.bias===1&&rnd()<(-un)*0.55)continue;if(CFG.bias===2&&rnd()<(1+un)*0.55)continue;
    out[0]=u;out[1]=v;return;}
  out[0]=D.cu0;out[1]=0;}
// signed distance of pixel i to its area's edge (area frame: q.cx,cy at the front, q.tx,ty along the path; spiral areas turn with q.ra)
function areaSd(q,i){const D=q.def,ex=px[i]-q.cx,ey=py[i]-q.cy;let lu=ex*q.tx+ey*q.ty,lv=-ex*q.ty+ey*q.tx;
  if(q.ra){const du=lu-D.rc,ca=Math.cos(-q.ra),sa=Math.sin(-q.ra);lu=D.rc+du*ca-lv*sa;lv=du*sa+lv*ca;}return sdAt(D,lu,lv);}
""")
e.t='\n'.join(L); L=e.t.split('\n')
# ---- squad functions
rep("function openSquad(sd,P)","// ---------- AI: plans/plays","""function frameOf(q,P){pathAt(P.p,q.s,tmp);q.cx=tmp[0];q.cy=tmp[1];q.tx=tmp[2];q.ty=tmp[3];}
function openSquad(sd,P){const A=P.arm;let qi=-1;for(let q=0;q<MAXSQ;q++)if(!sd.sq[q]){qi=q;break;}if(qi<0||!A)return null;
  const N=clamp(Math.round(CFG.sqN*clamp(sd.set.sdens/7,0.3,1.5)),20,600),f0=laneF(P.lane,fPos(P)/Math.max(1,pathLen(P))),D=areaDef(A.t,laneHW(sd.set),f0,sd),sg=D.rad*clamp(0.78-0.05*sd.set.compact,0.22,0.7);
  const q={id:qi,pid:P.id,t:A.t,N:N,def:D,sg:sg,rv:0.004,wv:sg*Math.sqrt(24*0.004),slot:new Int32Array(N).fill(-1),n:0,live:0,s:fPos(P),open:true,age:0,coh:1,hits:0,bk:0,ko:0,cx:0,cy:0,tx:1,ty:0,vx:0,vy:0,ra:0};
  frameOf(q,P);sd.sq[qi]=q;sd.openQ[P.id]=qi;A.q=qi;sd.stats.shapeMade[A.t]++;return q;}
const smp=[0,0];
function capture(sd,i,P){const A=P.arm;if(!A)return false;let q=A.q>=0?sd.sq[A.q]:null;if(!q||!q.open||q.pid!==P.id)q=openSquad(sd,P);if(!q)return false;
  const k=q.n++;q.slot[k]=i;q.live++;psq[i]=q.id;pslot[i]=k;pst[i]=4;psh[i]=q.t;sampleArea(q,smp);plu[i]=smp[0];plv[i]=smp[1];pcnt[i]=90;if(q.n>=q.N){q.open=false;sd.openQ[P.id]=-1;P.arm=null;}return true;}
function compact(sd,q){let m=0;for(let k=0;k<q.n;k++){const i=q.slot[k];if(i>=0){q.slot[m]=i;pslot[i]=m;m++;}}for(let k=m;k<q.n;k++)q.slot[k]=-1;q.n=m;}
""")
e.t='\n'.join(L); L=e.t.split('\n')
# ---- squadTick / disband / formErr
rep("function squadTick(sd,spd0,dt)","function movePixels()","""function squadTick(sd,spd0,dt){for(const P of sd.paths)if(P&&P.arm&&P.arm.q<0&&S.tick-P.arm.tick>CFG.armSec*60)P.arm=null;for(let qi=0;qi<MAXSQ;qi++){const q=sd.sq[qi];if(!q)continue;const P=sd.paths[q.pid];if(!P){sd.sq[qi]=null;continue;}
  q.age++;const endS=pathLen(P);q.s=Math.min(endS,q.s+spd0*0.97*dt);frameOf(q,P);q.vx=q.tx*spd0*0.97;q.vy=q.ty*spd0*0.97;q.ra=q.def.rot?S.tick*0.035:0;
  // AREA HEALTH: impacts loosen the area's hold (weaker pull to its wander spots, more jitter); it then REGROUPS over reformSec; too few pixels left = it breaks up
  if(q.hits>0){q.coh=Math.max(0,q.coh-Math.min(0.6,q.hits*CFG.shockK/100));q.hits=0;}
  q.coh+=(1-q.coh)*(dt/Math.max(0.2,CFG.reformSec));if(q.coh>1)q.coh=1;
  if(!q.bk&&q.coh<0.35){q.bk=1;sd.stats.formBreaks++;}else if(q.bk&&q.coh>0.8){q.bk=0;sd.stats.formReforms++;}
  if(q.s>=endS-0.5){disband(sd,qi,true);continue;}
  if(!q.open&&q.n>=8&&q.live<Math.max(3,q.n*CFG.breakLive/100)){disband(sd,qi);continue;}
  if(q.open&&q.age>CFG.borrowSec*60){q.open=false;P.arm=null;if(sd.openQ[q.pid]===qi)sd.openQ[q.pid]=-1;}
  if(!q.open&&q.live<=0){sd.sq[qi]=null;if(sd.openQ[q.pid]===qi)sd.openQ[q.pid]=-1;continue;}
  if(!q.open&&q.live<q.n&&(S.tick+qi)%20===0)compact(sd,q);}}
// the area ends: broken (pixels rejoin the lane) or it reached the path end (pixels fly on straight and drift, like any path end)
function disband(sd,qi,atEnd){const q=sd.sq[qi];if(!q)return;const P=sd.paths[q.pid],endS=P?pathLen(P):0;
  for(let k=0;k<q.n;k++){const i=q.slot[k];if(i>=0){psq[i]=-1;pst[i]=(P&&!atEnd)?2:3;pcap[i]=1;pps[i]=Math.min(endS,q.s);pend[i]=0;pid[i]=q.pid;}}
  q.slot.fill(-1);q.live=0;sd.sq[qi]=null;if(sd.openQ[q.pid]===qi)sd.openQ[q.pid]=-1;if(P&&P.arm&&P.arm.q===qi)P.arm=null;if(!atEnd)sd.stats.formBreaks++;}
// containment error: mean distance the members sit OUTSIDE their area edge (0 for pixels inside). Rises on impact, falls as the area regroups.
function formErr(side,qi){const sd=S.sides[side],q=sd.sq[qi];if(!q)return -1;let sum=0,c=0;
  for(let k=0;k<q.n;k++){const i=q.slot[k];if(i<0)continue;sum+=Math.max(0,areaSd(q,i));c++;}return c?sum/c:-1;}
""")
e.t='\n'.join(L); L=e.t.split('\n')
# ---- movePixels branch
a=find("      }else if(cur===4){ // SQUAD")
b=find("      if(pst[i]===3){ // END",a)
L[a:b]="""      }else if(cur===4||cur===5){ // AREA MEMBER: wanders freely inside its shape's soft hitbox (spring to its own wander spot); a hard knock can push it out (5), it re-enters or goes home past the leash
        const q=sd.sq[psq[i]];
        if(!q){pst[i]=3;psq[i]=-1;pend[i]=0;}
        else{const D=q.def,coh=q.coh;let u=plu[i],v=plv[i];
          if(cur===4){const nu=u+(rnd()-.5)*D.Lu*0.02,nv=v+(rnd()-.5)*q.wv-v*q.rv;if(sdAt(D,nu,nv)<=-0.3){u=nu;v=nv;}else{u+=(D.cu0-u)*0.08;v*=0.92;}plu[i]=u;plv[i]=v;}
          let wu=u,wv=v;if(q.ra){const du=u-D.rc,ca=Math.cos(q.ra),sa=Math.sin(q.ra);wu=D.rc+du*ca-v*sa;wv=du*sa+v*ca;}
          const sdi=areaSd(q,i);
          if(cur===4){if(pcnt[i]>0)pcnt[i]--;else if(sdi>CFG.koMargin){pst[i]=5;cur=5;sd.stats.knocked++;q.ko++;}}
          else if(sdi<=1){pst[i]=4;cur=4;pcnt[i]=0;sd.stats.reentered++;}
          if(sdi>CFG.leash&&(cur===5||pcnt[i]===0)){sd.stats.koRecall++;recall(i);continue;}
          const tx=q.cx+q.tx*wu-q.ty*wv,ty=q.cy+q.ty*wu+q.tx*wv,dx=tx-px[i],dy=ty-py[i];
          const kc=compactK*(0.3+0.7*coh)*(cur===5?0.35:1),jj=jit*(1+3*(1-coh));let wx=q.vx+dx*kc+(rnd()-.5)*jj,wy=q.vy+dy*kc+(rnd()-.5)*jj;
          const wl=Math.sqrt(wx*wx+wy*wy),cap=spd*1.7;if(wl>cap){wx*=cap/wl;wy*=cap/wl;}
          const kk=Math.min(1,(stun?1.0:9)*dt);vx+=(wx-vx)*kk;vy+=(wy-vy)*kk;}
      }""".split('\n')
e.t='\n'.join(L); open('/workspace/game/build-pixelwar042/index.html','w',encoding='utf8').write(e.t)
e=E()
# lane spread: denser along the line
e.ed("php[i]=CFG.pixHP;pst[i]=1;pcnt[i]=EXIT_T;pps[i]=0;poff[i]=rnd()*2-1;","php[i]=CFG.pixHP;pst[i]=1;pcnt[i]=EXIT_T;pps[i]=0;poff[i]=clamp((rnd()+rnd()+rnd()-1.5)*0.8,-1,1);")
e.ed("poff[i]=clamp(poff[i]+(rnd()-.5)*dt*3,-1,1);","poff[i]=clamp(poff[i]+(rnd()-.5)*dt*3-poff[i]*dt*0.25,-1,1);")
# knock
e.ed("function shock(side,i){","function knock(i,nx,ny){const K=CFG.knockK;if(K>0){pvx[i]+=nx*K;pvy[i]+=ny*K;}}\nfunction shock(side,i){")
e.ed("if(psq[i]>=0)shock(0,i);if(psq[j]>=0)shock(1,j);","if(psq[i]>=0){shock(0,i);knock(i,nx,ny);}if(psq[j]>=0){shock(1,j);knock(j,-nx,-ny);}")
e.ed("if(psq[i]>=0)shock(side,i);deflect(i,nx,ny,0.25,true);","if(psq[i]>=0){shock(side,i);knock(i,nx,ny);}deflect(i,nx,ny,0.25,true);")
# render: no stun blob, tint 4/5
e.ed("big=pstun[i]>STUN-8,","big=false,")
e.ed("(CFG.tint&&pst[i]===4)?","(CFG.tint&&pst[i]>=4)?")
# cmds range
e.ed("{name:'setShape',args:[{name:'path',min:0,max:5},{name:'t',min:0,max:6}]},{name:'useShape',args:[{name:'path',min:0,max:5},{name:'t',min:0,max:6}]}","{name:'setShape',args:[{name:'path',min:0,max:5},{name:'t',min:0,max:12}]},{name:'useShape',args:[{name:'path',min:0,max:5},{name:'t',min:0,max:12}]}")
# exports
e.ed("psq,pslot,psh,pcap,","psq,pslot,plu,plv,psh,pcap,")
e.ed("formPts,lanePoly,","areaDef,sdAt,areaSd,sampleArea,lanePoly,")
e.ed("fPos,shapeSlots,inShape,","fPos,inShape,")
e.ed("C:{W,H,CAPMAX,PSP,CONTACT,STUN,MAXP,MAXSQ,DEFCFG,SHAPES,NSH,MAXCUS,FCOLS,FROWS}","C:{W,H,CAPMAX,PSP,CONTACT,STUN,MAXP,MAXSQ,DEFCFG,SHAPES,NSH,MAXCUS,POLYMAX,MX,MY}")
e.save()
