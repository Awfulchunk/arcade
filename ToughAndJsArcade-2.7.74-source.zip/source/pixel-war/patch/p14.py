import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# ---- shapes hidden (code kept): one flag, off by default; Custom Game can turn them back on
e.ed("fadeSec:1.2,","fadeSec:1.2,shapesOn:0,")
e.ed("function feat(k){const st=CFG.stage|0;return !st||st>=STAGEF[k];}","function feat(k){if(!CFG.shapesOn&&(k==='shapes'||k==='shapes2'||k==='forms'||k==='aiForms'))return false;const st=CFG.stage|0;return !st||st>=STAGEF[k];}")
e.ed("function shapeOkS(sd,t){t=Math.round(+t);","function shapeOkS(sd,t){if(!CFG.shapesOn)return false;t=Math.round(+t);")
e.ed("['_','AI'],","['_','HIDDEN FOR NOW'],\n ['shapesOn','Shapes: arrow, wedge, line, diamond, double, spiral, ring, your own outlines, shape buttons','hidden in the game for now (Jay t1122); the code is kept. Turn on to bring them back','b'],\n ['_','AI'],")
# ---- width slider range (bigger max, smaller min) and per-path settings
e.ed("function laneHW(set){return 5+2.4*set.width;}","function laneHW(set){const w=set.width;return 1.5+0.4*w*w;}")
e.ed("compact:6,width:3,spacing:5};","compact:6,width:5,spacing:5};")
e.ed("function laneHW(set){","const pset=(sd,P)=>(P&&P.id&&P.set)?P.set:sd.set;\nfunction laneHW(set){")
# branch: own colour, own settings (copied from the main path at the moment it is drawn)
e.ed("  const P=mkPath(id,0,best);P.p=[p[best*2],p[best*2+1]];sd.paths[id]=P;","  const P=mkPath(id,0,best);P.p=[p[best*2],p[best*2+1]];P.set={speed:sd.set.speed,density:sd.set.density,width:sd.set.width,spacing:sd.set.spacing,compact:sd.set.compact};sd.paths[id]=P;")
e.ed("const canBr=sd=>!S.over&&feat('branch')&&((S.phase==='prep'&&!sd.locked)||(S.phase==='battle'&&!!CFG.liveBr));","const canBr=sd=>!S.over&&feat('branch')&&S.phase==='battle'&&!!CFG.liveBr;   // branches are drawn ONLY during the match (Jay t1122)")
e.ed("function getPath(sd,id){","function setPathSetting(side,id,key,v){const sd=S.sides[side],P=sd.paths[id];if(!P||!fin(v))return false;if(id===0)return setSetting(side,key,v);\n  if(key==='share'||key==='flow')return setShare(side,id,v);\n  if(key==='speed'||key==='density'||key==='width'||key==='spacing'){P.set[key]=clamp(Math.round(v),1,10);return true;}return false;}\nfunction getPath(sd,id){")
# clearance uses each path's own width
e.ed("function clrOf(sd){let m=0.6;for(const P of sd.paths)if(P&&LMAX[P.lane|0]>m)m=LMAX[P.lane|0];return laneHW(sd.set)*Math.max(1,m)+4;}","function clrOf(sd){let m=0;for(const P of sd.paths)if(P){const h=laneHW(pset(sd,P))*Math.max(0.6,LMAX[P.lane|0]);if(h>m)m=h;}return m+4;}")
# ---- movePixels: per-path pace / width / pull / spacing
e.ed("    squadTick(sd,spd0,dt);\n","    const pSpd=[],pHw=[],pRev=[],pSpc=[];for(let k=0;k<np;k++){const P=paths[k];if(!P){pSpd.push(0);pHw.push(1);pRev.push(0);pSpc.push(0);continue;}const ps=pset(sd,P);pSpd.push(speedOf(ps));pHw.push(laneHW(ps));pRev.push(0.04*ps.density);pSpc.push((ps.spacing-1)/9*0.25);}\n    squadTick(sd,spd0,dt);\n")
e.ed("const P=paths[pi],p=P.p,n=pn[pi];let spd=spd0*pspm[i];","const P=paths[pi],p=P.p,n=pn[pi];let spd=pSpd[pi]*pspm[i];")
e.ed("if(spcOn){const rh=rhoAt(side,px[i],py[i]);if(rh>3)po+=(po>0.02?1:po<-0.02?-1:((i&1)?1:-1))*spc*Math.min(1,rh/40)*dt;}\n          poff[i]=clamp(po+(rnd()-.5)*dt*3-po*dt*rev,-1,1);","if(spcOn&&pSpc[pi]>0){const rh=rhoAt(side,px[i],py[i]);if(rh>3)po+=(po>0.02?1:po<-0.02?-1:((i&1)?1:-1))*pSpc[pi]*Math.min(1,rh/40)*dt;}\n          poff[i]=clamp(po+(rnd()-.5)*dt*3-po*dt*pRev[pi],-1,1);")
e.ed("lw=hw*laneF(P.lane,pps[i]/pL[pi])","lw=pHw[pi]*laneF(P.lane,pps[i]/pL[pi])")
# ---- walls: reach the edges, smaller steps (smooth), meter by true length, hp per cell by cell length
e.ed("const WALL_HALF=2,","const WST=3,WALL_HALF=2,")
e.ed("const wallUsed=sd=>{let n=0;for(const s of sd.strokes)n+=(s.pts.length/2-1)*CFG.wsp;return n;};","const plen=q=>{let n=0;for(let k=0;k+3<q.length;k+=2)n+=Math.hypot(q[k+2]-q[k],q[k+3]-q[k+1]);return n;};\nconst wallUsed=sd=>{let n=0;for(const s of sd.strokes)n+=plen(s.pts);return n;};")
e.ed("function wallLen(sd){let n=0;for(const s of sd.strokes)if(!s.gate)n+=(s.pts.length/2-1)*CFG.wsp;return n;}","function wallLen(sd){let n=0;for(const s of sd.strokes)if(!s.gate)n+=plen(s.pts);return n;}")
e.ed("function inWallZone(side,x,y){const sd=S.sides[side];if(x<6||x>W-6)return false;\n  if(side===0){if(y<H/2+8||y>H-6)return false;}else{if(y>H/2-8||y<6)return false;}","function inWallZone(side,x,y){const sd=S.sides[side];if(x<0||x>W)return false;\n  if(side===0){if(y<H/2+8||y>H)return false;}else{if(y>H/2-8||y<0)return false;}")
e.ed("if(sd.strokes.length>=MAX_STROKES||wallUsed(sd)+CFG.wsp>CFG.wallMax+1e-6||","if(sd.strokes.length>=MAX_STROKES||wallUsed(sd)+WST>CFG.wallMax+1e-6||")
e.ed("function wallExtend(side,st,tx,ty){const sd=S.sides[side];if(!st||!canWall(sd)||!fin(tx)||!fin(ty))return 0;let n=0;\n  for(let g=0;g<200;g++){const L=st.pts.length,lx=st.pts[L-2],ly=st.pts[L-1],dx=tx-lx,dy=ty-ly,d=Math.hypot(dx,dy);\n    if(d<CFG.wsp)break;if(wallUsed(sd)+CFG.wsp>CFG.wallMax+1e-6)break;const nx=lx+dx/d*CFG.wsp,ny=ly+dy/d*CFG.wsp;",
"function wallExtend(side,st,tx,ty){const sd=S.sides[side];if(!st||!canWall(sd)||!fin(tx)||!fin(ty))return 0;let n=0;\n  tx=clamp(tx,0,W);ty=side===0?clamp(ty,H/2+8,H):clamp(ty,0,H/2-8);   // a finger past the edge still draws right to the edge\n  for(let g=0;g<400;g++){const L=st.pts.length,lx=st.pts[L-2],ly=st.pts[L-1],dx=tx-lx,dy=ty-ly,d=Math.hypot(dx,dy);\n    if(d<0.5)break;const stp=Math.min(WST,d);if(wallUsed(sd)+stp>CFG.wallMax+1e-6)break;const nx=lx+dx/d*stp,ny=ly+dy/d*stp;")
e.ed("n=Math.max(1,Math.round(L/CFG.wcell));\n","n=Math.max(1,Math.round(L/CFG.wcell)),hpc=Math.max(1,Math.round(hp*L/n/CFG.wcell));\n") if False else None
e.save()
