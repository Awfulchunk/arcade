import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# --- AI plans in prep (visible), replans when the player's circle moves; startBattle only plans if it has not
e.ed("forms:[],brWaste:0,","forms:[],brWaste:0,planned:false,")
e.ed("S={tick:0,phase:'prep',","S={aiRev:1,tick:0,phase:'prep',")
e.ed("  wGrid=new Array(WGW*WGH);resetFree();\n  stat={ticks:0,ms:0,maxMs:0};\n}","  wGrid=new Array(WGW*WGH);resetFree();\n  stat={ticks:0,ms:0,maxMs:0};\n  if(!CFG.duel)aiPrepPlan();\n}")
e.ed("// ---------- MATCH\nfunction startBattle(){if(S.phase!=='prep')return false;\n  for(const sd of S.sides)if(!sd.human)aiPlan(sd.id);",
"""// PREP: the AI draws its plan with the same side API as soon as the prep starts; it is drawn on screen over ~3 seconds (S.aiRev 0..1) and redrawn when the player moves his circle.
// It plans from the circle positions only (it does not read the player's path).
function aiPrepPlan(){const sd=S.sides[1];if(sd.human||S.phase!=='prep'||CFG.duel)return;
  const c=sd.circle,m=mkPath(0,-1,0);m.p=[c.x,c.y];sd.paths=[m];sd.strokes=[];sd.forms=[];sd.segs=[];selP=ME===1?0:selP;
  aiPlan(1);sd.planned=true;S.aiRev=0;}
// what a side still has to draw before START: the attack path and (when walls exist in this stage) a defense line
const MINPATH=60,MINWALL=40;
function wallLen(sd){let n=0;for(const s of sd.strokes)if(!s.gate)n+=(s.pts.length/2-1)*CFG.wsp;return n;}
function prepNeeds(sd){const r=[];if(pathUsed(sd)<MINPATH)r.push('path');if(feat('walls')&&CFG.wallMax>=MINWALL&&wallLen(sd)<MINWALL)r.push('wall');return r;}
// default defense line for a side that has none (prep timer ran out): two wall pieces with a gap, in front of the circle
function autoDefense(sd){if(!feat('walls'))return;const c=sd.circle,dir=sd.dir;
  for(const [dy,gap] of [[56,22],[64,24],[72,22],[84,20],[48,22]]){if(wallLen(sd)>=MINWALL)break;const y=c.y+dir*dy,cx=clamp(c.x,70,W-70);
    for(const seg of [[cx-gap-60,y,cx-gap,y],[cx+gap,y,cx+gap+60,y]]){const st=wallBegin(sd.id,seg[0],seg[1]);if(st){wallExtend(sd.id,st,seg[2],seg[3]);wallEnd(sd.id,st);}}}}
function startBattle(){if(S.phase!=='prep')return false;S.aiRev=1;
  for(const sd of S.sides)if(!sd.human&&!sd.planned)aiPlan(sd.id);""")
# placeCircle: AI replans
e.ed("c.x=x;c.y=y;resetPaths(sd);\n","c.x=x;c.y=y;resetPaths(sd);if(side===0&&S.phase==='prep'&&!CFG.duel)setTimeout0(aiPrepPlan);\n")
e.ed("let selP=0;\nconst zoneOf","let selP=0;\nfunction setTimeout0(f){f();}\nconst zoneOf")
# autoStart (timer): fills what the human did not draw; the hook / tests stay lenient
e.ed("function autoStart(){for(const sd of S.sides)if(sd.human&&sd.paths[0].p.length<4&&sd.strokes.length===0){aiPlan(sd.id);}startBattle();}",
"function autoStart(fill){for(const sd of S.sides)if(sd.human&&sd.paths[0].p.length<4&&sd.strokes.length===0){aiPlan(sd.id);}\n  if(fill)for(const sd of S.sides)if(sd.human&&S.phase==='prep'&&prepNeeds(sd).indexOf('wall')>=0)autoDefense(sd);startBattle();}\nfunction tryStart(){if(S.phase!=='prep')return false;for(const sd of S.sides){if(!sd.human)continue;const n=prepNeeds(sd);if(n.length){if(CFG.duel&&sd.id!==ME){S.msg='Player '+(sd.id+1)+' must draw a '+(n[0]==='path'?'path':'defense line')+' first';}else S.msg=n[0]==='path'?'Draw your attack path first':'Draw your defense line first';return false;}}autoStart(false);return true;}")
e.ed("if(S.phase==='prep'&&CFG.prepSec>0){S.prepT+=dt;if(S.prepT>=CFG.prepSec)autoStart();}","if(S.phase==='prep'&&CFG.prepSec>0){S.prepT+=dt;if(S.prepT>=CFG.prepSec)autoStart(true);}\n    if(S.phase==='prep'&&S.aiRev<1)S.aiRev=Math.min(1,S.aiRev+dt/3);")
e.ed("$('tStart').addEventListener('click',()=>{if(S.phase==='prep'){autoStart();savePrefs();}});","$('tStart').addEventListener('click',()=>{if(S.phase==='prep'&&tryStart())savePrefs();});")
# visibility in prep: both sides (not in hot-seat, where the other player must not peek)
e.ed("function showSide(sd){return sd.id===ME||(S.phase!=='prep'&&!!CFG.reveal);}","function showSide(sd){return sd.id===ME||(S.phase!=='prep'?!!CFG.reveal:!CFG.duel);}\nconst foePrep=sd=>sd.id!==ME&&S.phase==='prep'&&S.aiRev<1;")
# lane layer: foe bands only after its drawing finished
e.ed("for(const sd of S.sides){if(!showSide(sd))continue;const hw=laneHW(sd.set);for(const P of sd.paths){if(!P||P.p.length<4)continue;","for(const sd of S.sides){if(!showSide(sd)||foePrep(sd))continue;const hw=laneHW(sd.set);for(const P of sd.paths){if(!P||P.p.length<4)continue;")
e.ed("let key=S.phase+'|'+ME+'|'+(CFG.reveal?1:0)+'|'+(window.__pwNoFilter?1:0);","let key=S.phase+'|'+ME+'|'+(CFG.reveal?1:0)+'|'+(CFG.duel?1:0)+'|'+(S.aiRev<1?0:1)+'|'+(window.__pwNoFilter?1:0);")
# walls drawing: both sides in prep, foe partially revealed
e.ed("for(const sd of S.sides){if(sd.id!==ME&&S.phase==='prep')continue;\n    for(const st of sd.strokes){if(!st.segs||!st.segs.length){ctx.strokeStyle=st.gate?'#2f6bff':'#000';ctx.setLineDash(st.gate?[3*sc,3*sc]:[]);ctx.beginPath();ctx.moveTo(X(st.pts[0]),Y(st.pts[1]));for(let k=2;k<st.pts.length;k+=2)ctx.lineTo(X(st.pts[k]),Y(st.pts[k+1]));ctx.stroke();continue;}",
"for(const sd of S.sides){if(!showSide(sd))continue;const fpr=foePrep(sd),wf=fpr?clamp((S.aiRev-0.6)/0.4,0,1)*sd.strokes.length:1e9;let sIdx=-1;\n    for(const st of sd.strokes){sIdx++;if(sIdx>=wf)break;if(!st.segs||!st.segs.length){const np=st.pts.length>>1,lim=fpr&&sIdx+1>wf?Math.max(2,Math.ceil(np*(wf-sIdx))):np;ctx.strokeStyle=st.gate?'#2f6bff':(sd.id!==ME?'#5a1a14':'#000');ctx.setLineDash(st.gate?[3*sc,3*sc]:[]);ctx.beginPath();ctx.moveTo(X(st.pts[0]),Y(st.pts[1]));for(let k=1;k<lim;k++)ctx.lineTo(X(st.pts[k*2]),Y(st.pts[k*2+1]));ctx.stroke();continue;}")
# paths drawing partial
e.ed("for(const P of sd.paths){if(!P)continue;const p=P.p,n=p.length>>1;if(n<2)continue;\n      ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=P.id?BRC:'#161616';ctx.lineWidth=Math.max(1,1.6*sc);ctx.beginPath();ctx.moveTo(X(p[0]),Y(p[1]));for(let k=1;k<n;k++)ctx.lineTo(X(p[k*2]),Y(p[k*2+1]));ctx.stroke();",
"for(const P of sd.paths){if(!P)continue;const p=P.p,n0=p.length>>1;if(n0<2)continue;const fpr=foePrep(sd),n=fpr?Math.max(2,Math.ceil(n0*clamp(S.aiRev/0.6,0,1))):n0;\n      ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=P.id?BRC:(sd.id!==ME&&S.phase==='prep'?'#7a1f18':'#161616');ctx.lineWidth=Math.max(1,1.6*sc);ctx.beginPath();ctx.moveTo(X(p[0]),Y(p[1]));for(let k=1;k<n;k++)ctx.lineTo(X(p[k*2]),Y(p[k*2+1]));ctx.stroke();\n      if(fpr&&S.aiRev<0.6&&P.id===0){ctx.fillStyle='#e0261c';ctx.beginPath();ctx.arc(X(p[(n-1)*2]),Y(p[(n-1)*2+1]),2.5*sc,0,6.2832);ctx.fill();}")
e.ed("get stat(){return stat;},","get stat(){return stat;},prepNeeds,tryStart,autoDefense,aiPrepPlan,wallLen,MINPATH,MINWALL,")
e.save()
