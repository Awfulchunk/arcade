import sys; sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# arrays
e.ed("const psq=new Int16Array(NP).fill(-1),pslot=new Int16Array(NP);","const psq=new Int16Array(NP).fill(-1),pslot=new Int16Array(NP),pgc=new Uint8Array(NP);")
e.ed("pst.fill(0);php.fill(0);pcd.fill(0);pwc.fill(0);","pgc.fill(0);pst.fill(0);php.fill(0);pcd.fill(0);pwc.fill(0);")
# shapes
old_start="const shapeCache=new Map();"
t=e.t; i=t.index(old_start); j=t.index("function fPos(P)")
new_shape='''const shapeCache=new Map();
// custom formation cells (FCOLS x FROWS grid, row 0 = front) -> points (u front-first, v lateral); cached on the formation
function formPts(F){if(F.pts)return F.pts;const pts=[];for(const c of F.cells){pts.push([-(c[1]+0.5)/FROWS,((c[0]+0.5)/FCOLS-0.5)*1.4]);}pts.sort((a,b)=>b[0]-a[0]||a[1]-b[1]);F.pts=pts;return pts;}
function formSig(F){let h=F.cells.length;for(const c of F.cells)h=(Math.imul(h,31)+c[0]*17+c[1]+7)|0;return h;}
// LANE-BOUND FOOTPRINT: width = shapeLane * lane half-width (never wider than the lane), length = shapeLen * hw. Spiral is a disc of radius shapeLane*hw so rotation stays inside the lane.
// t>=7 = a custom formation of side `sd` (sd.forms[t-7]). ARROW/WEDGE get FRONT CONCENTRATION: slots are kept with a probability that rises toward the leading edge.
function shapeSlots(t,N,hw,sd){let F=null;if(t>=7){F=sd&&sd.forms[t-7];if(!F||!F.cells||F.cells.length<3)return shapeSlots(0,N,hw);}
  const key=(F?'C'+formSig(F):t)+'|'+N+'|'+hw.toFixed(1)+'|'+CFG.orient+'|'+CFG.bias+'|'+CFG.shapeLane+'|'+CFG.shapeLen+'|'+CFG.arrowFront;let r=shapeCache.get(key);if(r)return r;
  const rad=CFG.shapeLane*hw,ux=new Float32Array(N),vy=new Float32Array(N);
  if(F){const pts=formPts(F),nc=pts.length,Lv=rad/0.7,Lu=clamp(CFG.shapeLen*hw,8,48);
    for(let k=0;k<N;k++){const ci=k%nc,rr=(k/nc)|0,p=pts[ci],ju=rr?(halton(rr*nc+ci+1,2)-0.5)*0.9/FROWS:0,jv=rr?(halton(rr*nc+ci+1,3)-0.5)*1.26/FCOLS:0;ux[k]=(p[0]+ju)*Lu;vy[k]=(p[1]+jv)*Lv;}
    r={ux:ux,vy:vy,L:Lu,W:2*rad,cu:-0.5*Lu};shapeCache.set(key,r);if(shapeCache.size>200)shapeCache.clear();return r;}
  const pts=[],af=CFG.arrowFront/100;
  for(let i=1;pts.length<N&&i<N*60;i++){const u=-halton(i,2),v=(halton(i,3)-0.5)*1.4;if(!inShape(t,u,v))continue;
    if(af>0&&(t===1||t===2)&&halton(i,7)>=(1-af)+af*Math.pow(1+u,1.5))continue;
    if(CFG.bias===1&&halton(i,5)<(-u)*0.55)continue;if(CFG.bias===2&&halton(i,5)<(1+u)*0.55)continue;pts.push([u,v]);}
  let Lu,Lv;if(t===6||t===3){Lu=2*rad;Lv=2*rad;}else{Lv=rad/0.7;Lu=clamp(CFG.shapeLen*hw,8,48);}
  const n=pts.length;for(const p of pts){if(CFG.orient===1)p[0]=-1-p[0];}
  pts.sort((a,b)=>b[0]-a[0]);
  for(let k=0;k<N;k++){const p=pts[Math.min(k,n-1)]||[0,0];ux[k]=p[0]*Lu;vy[k]=p[1]*Lv;}
  r={ux:ux,vy:vy,L:Lu,W:2*rad,cu:-0.5*Lu};shapeCache.set(key,r);if(shapeCache.size>200)shapeCache.clear();return r;}
'''
e.t=t[:i]+new_shape+e.t[j:]
e.ed("const CDMUL=[0.7,1,1,1,1.1,0.9,1.3];\nfunction shapeOk(t){return t>=0&&t<=6&&(t!==3||!!CFG.ring);}\nfunction cdTicks(t){return Math.max(1,Math.round(CFG.shapeCD*60*CDMUL[t]));}",
"const CDMUL=[0.7,1,1,1,1.1,0.9,1.3];\nfunction shapeOk(t){return t>=0&&t<=6&&(t!==3||!!CFG.ring);}\n// per-side availability (stage unlocks + custom formations of that side); the AI goes through the same check\nfunction shapeOkS(sd,t){t=Math.round(+t);if(!fin(t)||t<0)return false;if(t<=6){if(!shapeOk(t)||!feat('shapes'))return false;return t<=2||feat('shapes2');}return t<7+MAXCUS&&!!sd.forms[t-7]&&feat('forms');}\nfunction cdTicks(t){return Math.max(1,Math.round(CFG.shapeCD*60*(CDMUL[t]||1)));}")
e.ed("function useShape(side,id,t){const sd=S.sides[side];t=Math.round(+t);if(!fin(t)||!shapeOk(t)||S.phase!=='battle'||S.over)return false;","function useShape(side,id,t){const sd=S.sides[side];t=Math.round(+t);if(!fin(t)||!shapeOkS(sd,t)||S.phase!=='battle'||S.over)return false;")
e.ed("  const N=clamp(Math.round(CFG.sqN),20,600),sl=shapeSlots(A.t,N,laneHW(sd.set));\n  const q={id:qi,pid:P.id,t:A.t,N:N,ux:sl.ux,vy:sl.vy,cu:sl.cu,slot:new Int32Array(N).fill(-1),n:0,live:0,s:fPos(P),open:true,age:0};",
"  const N=clamp(Math.round(CFG.sqN),20,600),f0=laneF(P.lane,fPos(P)/Math.max(1,pathLen(P))),sl=shapeSlots(A.t,N,laneHW(sd.set)*f0,sd);\n  const q={id:qi,pid:P.id,t:A.t,N:N,ux:sl.ux,vy:sl.vy,cu:sl.cu,slot:new Int32Array(N).fill(-1),n:0,live:0,s:fPos(P),open:true,age:0,f0:f0,coh:1,hits:0,bk:0};")
e.ed("function reslot(sd,q,t){const sl=shapeSlots(t,q.N,laneHW(sd.set));","function reslot(sd,q,t){const sl=shapeSlots(t,q.N,laneHW(sd.set)*q.f0,sd);")
# movePixels
e.ed("const pn=[],pex=[],pey=[],pF=[];for(let k=0;k<np;k++){const P=paths[k];if(!P){pn.push(0);pex.push(0);pey.push(0);pF.push(0);continue;}const n=P.p.length>>1;pn.push(n);","const pn=[],pex=[],pey=[],pF=[],pL=[];for(let k=0;k<np;k++){const P=paths[k];if(!P){pn.push(0);pex.push(0);pey.push(0);pF.push(0);pL.push(1);continue;}const n=P.p.length>>1;pn.push(n);pL.push(Math.max(1,(n-1)*PSP));")
e.ed("if(pcd[i]>0)pcd[i]--;if(pwc[i]>0)pwc[i]--;","if(pcd[i]>0)pcd[i]--;if(pwc[i]>0)pwc[i]--;if(pgc[i]>0)pgc[i]--;")
e.ed("const tx=tmp[0]-tmp[3]*poff[i]*hw,ty=tmp[1]+tmp[2]*poff[i]*hw;","const lw=hw*laneF(P.lane,pps[i]/pL[pi]),tx=tmp[0]-tmp[3]*poff[i]*lw,ty=tmp[1]+tmp[2]*poff[i]*lw;")
e.ed("else{const k=pslot[i],endS=(n-1)*PSP;let u=q.ux[k],v=q.vy[k];\n          if(q.t===6){const a=S.tick*0.035,ca=Math.cos(a),sa=Math.sin(a),du=u-q.cu;u=q.cu+du*ca-v*sa;v=du*sa+v*ca;}",
"else{const k=pslot[i],endS=(n-1)*PSP,coh=q.coh,sU=1+0.6*(1-coh),sV=(1+0.5*(1-coh))*clamp(laneF(P.lane,q.s/pL[pi])/q.f0,0.35,1.6);let u=q.ux[k]*sU,v=q.vy[k]*sV;\n          if(q.t===6){const a=S.tick*0.035,ca=Math.cos(a),sa=Math.sin(a),cu=q.cu*sU,du=u-cu;u=cu+du*ca-v*sa;v=du*sa+v*ca;}")
e.ed("let wx=tmp[2]*spd0*0.97+dx*compactK+(rnd()-.5)*jit,wy=tmp[3]*spd0*0.97+dy*compactK+(rnd()-.5)*jit;","const kc=compactK*(0.3+0.7*coh),jj=jit*(1+3*(1-coh));let wx=tmp[2]*spd0*0.97+dx*kc+(rnd()-.5)*jj,wy=tmp[3]*spd0*0.97+dy*kc+(rnd()-.5)*jj;")
# squadTick: reform + break
e.ed("  q.age++;const endS=pathLen(P);q.s=Math.min(endS,q.s+spd0*0.97*dt);",
"""  q.age++;const endS=pathLen(P);q.s=Math.min(endS,q.s+spd0*0.97*dt);
  // FORMATION HEALTH: impacts distort it (stretch / compress / scatter); it then REFORMS toward its preferred arrangement over reformSec; too few pixels left = it breaks up
  if(q.hits>0){q.coh=Math.max(0,q.coh-Math.min(0.6,q.hits*CFG.shockK/100));q.hits=0;}
  q.coh+=(1-q.coh)*(dt/Math.max(0.2,CFG.reformSec));if(q.coh>1)q.coh=1;
  if(!q.bk&&q.coh<0.35){q.bk=1;sd.stats.formBreaks++;}else if(q.bk&&q.coh>0.8){q.bk=0;sd.stats.formReforms++;}
  if(!q.open&&q.n>=8&&q.live<Math.max(3,q.n*CFG.breakLive/100)){disband(sd,qi);continue;}""")
e.ed("function movePixels(){","""function disband(sd,qi){const q=sd.sq[qi];if(!q)return;const P=sd.paths[q.pid],endS=P?pathLen(P):0;
  for(let k=0;k<q.n;k++){const i=q.slot[k];if(i>=0){psq[i]=-1;pst[i]=P?2:3;pcap[i]=1;pps[i]=Math.min(endS,q.s);pend[i]=0;pid[i]=q.pid;}}
  q.slot.fill(-1);q.live=0;sd.sq[qi]=null;if(sd.openQ[q.pid]===qi)sd.openQ[q.pid]=-1;if(P&&P.arm&&P.arm.q===qi)P.arm=null;sd.stats.formBreaks++;}
// formation error: mean distance of the members from their PREFERRED slot positions (full cohesion). Rises on impact, falls as it reforms.
function formErr(side,qi){const sd=S.sides[side],q=sd.sq[qi];if(!q)return -1;const P=sd.paths[q.pid];if(!P)return -1;const p=P.p,pLn=Math.max(1,(p.length/2-1)*PSP),sV=clamp(laneF(P.lane,q.s/pLn)/q.f0,0.35,1.6);let sum=0,c=0;
  for(let k=0;k<q.n;k++){const i=q.slot[k];if(i<0)continue;let u=q.ux[k],v=q.vy[k]*sV;if(q.t===6){const a=S.tick*0.035,ca=Math.cos(a),sa=Math.sin(a),du=u-q.cu;u=q.cu+du*ca-v*sa;v=du*sa+v*ca;}
    pathAt(p,Math.max(0,q.s+u),tmp);sum+=Math.hypot(tmp[0]-tmp[3]*v-px[i],tmp[1]+tmp[2]*v-py[i]);c++;}
  return c?sum/c:-1;}
function movePixels(){""")
# hurt: interceptions
e.ed("function hurt(i,dmg,ks,kj){php[i]-=dmg;if(php[i]<=0){const vsd=S.sides[1-ks],ksd=S.sides[ks];ksd.stats.kills++;","function hurt(i,dmg,ks,kj){php[i]-=dmg;if(php[i]<=0){const vsd=S.sides[1-ks],ksd=S.sides[ks];ksd.stats.kills++;if(ks===0?py[i]>H/2:py[i]<H/2)ksd.stats.intercepts++;")
# collide: shock + hybrid
e.ed("function collide(){","function shock(side,i){const k=psq[i];if(k>=0){const q=S.sides[side].sq[k];if(q)q.hits++;}}\nfunction collide(){")
e.ed("pcd[i]=pcd[j]=CD_HIT;pmom[i]=pmom[j]=0;let pm=mp,pr=rp;","pcd[i]=pcd[j]=CD_HIT;pmom[i]=pmom[j]=0;let pm=mp,pr=rp,rotv=0.35,dI=0.6,dJ=0.6,base=0.6;if(psq[i]>=0)shock(0,i);if(psq[j]>=0)shock(1,j);")
e.ed("am=Math.min(0.9,mp*2*gl),ar=Math.min(0.95,rp*2*gl);if(mode===1){pm=am;pr=ar;}else{pm=(mp+am)/2;pr=(rp+ar)/2;}}",
"am=Math.min(0.9,mp*2*gl),ar=Math.min(0.95,rp*2*gl);if(mode===1){pm=am;pr=ar;}else{pm=(mp+am)/2;pr=(rp+ar)/2;}\n          if(mode===3){ // FULL HYBRID: impact angle (gl: glancing=1, head-on=0) + closing speed (sfv) + packing (dr below)\n            const sfv=clamp(((pvx[j]-pvx[i])*nx+(pvy[j]-pvy[i])*ny)/RSP,0,1.5);pm=clamp(pm*(1-KSP*(sfv-0.5)),0,0.95);pr=clamp(pr*(1+KSP*(sfv-0.5)),0,0.95);rotv=0.2+0.4*gl;base=0.6*(1+0.8*Math.min(1.2,sfv));dI=dJ=base;}}")
e.ed("const pHP=CFG.pixDmg,mode=CFG.ricoMode,mp=CFG.missP/100,rp=CFG.ricoP/100;","const pHP=CFG.pixDmg,mode=((CFG.stage|0)>0&&!feat('rico3')?Math.min(CFG.ricoMode,(CFG.stage|0)>=3?2:0):CFG.ricoMode),mp=CFG.missP/100,rp=CFG.ricoP/100,KSP=CFG.kSpeed/100,RSP=speedOf(s0.set)+speedOf(s1.set);")
e.ed("const sI=rnd()<svi,sJ=rnd()<svj;let bI=sI,bJ=sJ;","if(mode===3){dI=base*clamp(1-0.25*dr,0.5,1.8);dJ=base*clamp(1+0.25*dr,0.5,1.8);}\n        const sI=rnd()<svi,sJ=rnd()<svj;let bI=sI,bJ=sJ;")
e.ed("deflect(i,nx,ny,0.35,false);px[i]+=nx*0.6;py[i]+=ny*0.6;}","deflect(i,nx,ny,rotv,false);px[i]+=nx*dI;py[i]+=ny*dI;}")
e.ed("deflect(j,-nx,-ny,0.35,false);px[j]-=nx*0.6;py[j]-=ny*0.6;}","deflect(j,-nx,-ny,rotv,false);px[j]-=nx*dJ;py[j]-=ny*dJ;}")
# walls: gates + stats + shock
e.ed("for(let q=0;q<lst.length;q++){const g=lst[q];if(!g.alive)continue;","for(let q=0;q<lst.length;q++){const g=lst[q];if(!g.alive)continue;if(g.gate&&g.side===side){if(pgc[i]===0&&distPtSeg(px[i],py[i],g.x1,g.y1,g.x2,g.y2)<WALL_HALF+1.2){pgc[i]=16;S.sides[side].stats.gatePass++;}continue;}")
e.ed("if(sg.side!==side){sg.hp-=wdm;","if(sg.side!==side){S.sides[sg.side].stats.wallTaken+=wdm;sg.hp-=wdm;")
e.ed("deflect(i,nx,ny,0.25,true);px[i]=bqx+nx*(WALL_HALF+1.6);","if(psq[i]>=0)shock(side,i);deflect(i,nx,ny,0.25,true);px[i]=bqx+nx*(WALL_HALF+1.6);")
e.save()
