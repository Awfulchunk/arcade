import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E();L=e.t.split('\n')
def find(prefix,start=0):
    for k in range(start,len(L)):
        if L[k].startswith(prefix): return k
    print('NO LINE',prefix); sys.exit(1)
a=find("function aiDesignForm(sd)");b=find("function aiLearn(note)")
L[a:b]="""function aiDesignForm(sd){if(sd.forms.length>=MAXCUS)return null;const fam=(rnd()*6)|0,names=['COMB','CRESCENT','CROSS','TRIDENT','WAVE','WINGS'];let pts=[];
  if(fam===0){const k=3+((rnd()*3)|0),w=1/(2*k-1);pts.push([0,1]);for(let t=0;t<k;t++){const x0=2*t*w,x1=x0+w;pts.push([x0,0],[x1,0]);if(t<k-1)pts.push([x1,0.45+rnd()*0.15],[x1+w,0.45+rnd()*0.15]);}pts.push([1,1]);}
  else if(fam===1){const th=0.22+rnd()*0.14,dp=0.45+rnd()*0.2,o=[],n=[];for(let a=0;a<=6;a++){const g=a/6*Math.PI,sn=Math.sin(g);o.push([0.5-0.5*Math.cos(g),dp*(1-sn)]);n.push([0.5-(0.5-th)*Math.cos(g),dp*(1-sn)+th*sn+0.04]);}pts=o.concat(n.reverse());}
  else if(fam===2){const w=0.14+rnd()*0.1,a=0.5-w,b=0.5+w,c=0.25+rnd()*0.2,d=c+0.2;pts=[[a,0],[b,0],[b,c],[1,c],[1,d],[b,d],[b,1],[a,1],[a,d],[0,d],[0,c],[a,c]];}
  else if(fam===3){const h=0.5+rnd()*0.2;pts=[[0,0],[0.2,0],[0.2,h],[0.4,h],[0.4,0],[0.6,0],[0.6,h],[0.8,h],[0.8,0],[1,0],[1,h+0.15],[0.58,h+0.15],[0.58,1],[0.42,1],[0.42,h+0.15],[0,h+0.15]];}
  else if(fam===4){const ph=rnd()*3,am=0.12+rnd()*0.1,t=[],u=[];for(let k=0;k<=8;k++){const x=k/8,y=0.3+am*Math.sin(x*6+ph);t.push([x,y]);u.push([x,y+0.32]);}pts=t.concat(u.reverse());}
  else{const s=0.35+rnd()*0.2;pts=[[0.5,0],[1,s+0.25],[1,1],[0.5,s],[0,1],[0,s+0.25]];}
  for(const p of pts){p[0]=clamp(p[0]+(rnd()-.5)*0.05,0,1);p[1]=clamp(p[1]+(rnd()-.5)*0.05,0,1);}
  const f=cleanForm({name:names[fam],poly:pts});if(!f)return null;sd.forms.push(f);if(S.ai&&S.ai.designs)S.ai.designs.push(f.name);return f;}""".split('\n')
e.t='\n'.join(L)
e.ed("JSON.parse(localStorage.getItem(KEYC)||localStorage.getItem(KEYC3)||'null');if(v&&typeof v==='object'&&!Array.isArray(v)){for(const k in DEFCFG){const d=DEFCFG[k];if(typeof v[k]==='number'&&Number.isFinite(v[k]))CUS[k]=clampCus(k,v[k]);}}",
"JSON.parse(localStorage.getItem(KEYC)||'null'),old=false;if(!v){v=JSON.parse(localStorage.getItem(KEYC4)||localStorage.getItem(KEYC3)||'null');old=true;}if(v&&typeof v==='object'&&!Array.isArray(v)){for(const k in DEFCFG){if(old&&(k==='segHP'||k==='wallDmg'||k==='brWaste'||k==='tint'||k==='shapeLane'))continue;if(typeof v[k]==='number'&&Number.isFinite(v[k]))CUS[k]=clampCus(k,v[k]);}}")
e.ed("function loadCustom(){try{const v=","function loadCustom(){try{let v=")
e.ed("JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(KEY3)||'null')","JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(KEY4)||localStorage.getItem(KEY3)||'null')")
e.save()
