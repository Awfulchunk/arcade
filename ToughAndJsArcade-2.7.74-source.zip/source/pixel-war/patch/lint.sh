#!/bin/bash
# extract <script> and syntax check + chrome83 lint
python3 - <<'PY'
import re
t=open('/workspace/game/build-pixelwar042/index.html',encoding='utf8').read()
m=re.search(r'<script>(.*)</script>',t,re.S)
open('/tmp/pw04.js','w').write(m.group(1))
PY
node --check /tmp/pw04.js && echo "syntax ok"
/workspace/game/build-latch/tool/node_modules/.bin/esbuild /tmp/pw04.js --target=chrome83 --log-level=warning > /dev/null && echo "chrome83 ok"
grep -nE '\?\?=|\|\|=|&&=|\.at\(|replaceAll|roundRect|dvh|aspect-ratio|inset:|[^a-z]gap:' /workspace/game/build-pixelwar042/index.html | cut -c1-120 | head
