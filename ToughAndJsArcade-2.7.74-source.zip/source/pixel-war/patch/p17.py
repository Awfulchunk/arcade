import sys,re
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
t=e.t
# ---------- HTML panel
a=t.index(' <div id="panel">\n')
b=t.index('  <div id="result">')
panel=''' <div id="panel">
  <div id="main">
   <div class="row mrow"><div class="cell"><span class="lab" id="tP">PATH</span><div class="bar" id="mP"><i></i></div></div><div class="cell"><span class="lab" id="tW">WALL</span><div class="bar" id="mW"><i></i></div></div></div>
   <div class="row mrow"><div class="cell"><span class="lab" id="tY">YOU</span><div class="bar" id="hY"><i></i></div></div><div class="cell"><span class="lab" id="tF">ENEMY</span><div class="bar" id="hF"><i></i></div></div></div>
   <div class="row trow" id="tools"><button id="tCircle">MOVE CIRCLE</button><button id="tMain">ATTACK PATH</button><button id="tBranch">BRANCH</button><button id="tWall">DEFENSE LINE</button><button id="tGate">GATE</button><button id="tErase">ERASE</button></div>
   <div class="row trow" id="r2"><button id="tStart" class="go" style="flex:2">START</button><button id="tSwap" style="display:none">SIDE</button><button id="tRefill" style="display:none">REFILL</button><div class="row" id="chips"></div></div>
   <div id="sl">
    <div id="slh"></div>
    <div class="box"><span class="lab2" id="lSp"></span><button class="pm" data-d="-1" data-for="sSp" aria-label="pace down">&minus;</button><input id="sSp" type="range" min="1" max="10" step="1" value="5" aria-label="pace"><button class="pm" data-d="1" data-for="sSp" aria-label="pace up">+</button></div>
    <div class="box"><span class="lab2" id="lDe"></span><button class="pm" data-d="-1" data-for="sDe" aria-label="density down">&minus;</button><input id="sDe" type="range" min="1" max="10" step="1" value="7" aria-label="density"><button class="pm" data-d="1" data-for="sDe" aria-label="density up">+</button></div>
    <div class="box"><span class="lab2" id="lSpc"></span><button class="pm" data-d="-1" data-for="sSpc" aria-label="spacing down">&minus;</button><input id="sSpc" type="range" min="1" max="10" step="1" value="5" aria-label="spacing"><button class="pm" data-d="1" data-for="sSpc" aria-label="spacing up">+</button></div>
    <div class="box"><span class="lab2" id="lWd"></span><button class="pm" data-d="-1" data-for="sWd" aria-label="lane width down">&minus;</button><input id="sWd" type="range" min="1" max="10" step="1" value="5" aria-label="lane width"><button class="pm" data-d="1" data-for="sWd" aria-label="lane width up">+</button></div>
    <div class="box"><span class="lab2" id="lRe"></span><button class="pm" data-d="-1" data-for="sRe" aria-label="flow down">&minus;</button><input id="sRe" type="range" min="1" max="10" step="1" value="9" aria-label="flow"><button class="pm" data-d="1" data-for="sRe" aria-label="flow up">+</button></div>
    <div class="box"><span class="lab2" id="lLn">LANE SHAPE</span><button id="tLane" style="flex:1;margin:0 0 0 4px">NORMAL</button></div>
    <div id="legacy" style="display:none">
     <div class="row" id="chipsL"></div><div class="row" id="shbtns"></div>
     <div class="row srow"><div class="cell"><span class="lab" id="lSh">SHARE</span><input id="sSh" type="range" min="0" max="100" step="5" value="40" aria-label="branch share"></div><div class="cell"><span class="lab" id="lAt">FORM AT</span><input id="sAt" type="range" min="0" max="100" step="5" value="0" aria-label="form at"></div></div>
     <div class="row srow"><div class="cell"><span class="lab" id="lSD">SHAPE DENS</span><input id="sSD" type="range" min="1" max="10" step="1" value="7" aria-label="shape density"></div><div class="cell"><span class="lab" id="lCo">COMPACT</span><input id="sCo" type="range" min="1" max="10" step="1" value="6" aria-label="compactness"></div></div>
     <div class="row srow"><div class="cell"><span class="lab" id="lCa">OUT</span><input id="sCa" type="range" min="250" max="10000" step="250" value="4000" aria-label="active count"></div><div class="cell"><span class="lab" id="lPu">PULL</span><input id="sPu" type="range" min="0" max="100" step="5" value="90" aria-label="shape pull"></div></div>
    </div>
   </div>
   <div id="info" style="display:none"></div><div style="display:none"><button id="shPrev">&lt;</button><span id="shn">LINE</span><button id="shNext">&gt;</button></div>
  </div>
'''
t=t[:a]+panel+t[b:]
e.t=t
# top bar: step button
e.ed('<button id="btnPause">PAUSE</button><button id="btnRestart">NEW</button>','<button id="btnPause">PAUSE</button><button id="btnStep" style="display:none">STEP</button><button id="btnRestart">NEW</button>')
# ---------- CSS
e.ed("#panel{flex:none;height:236px;box-sizing:border-box;padding:2px 6px 2px;background:#131632;border-top:2px solid #2c3270}","#panel{flex:none;height:calc(142px + clamp(92px,19vh,224px));min-height:236px;box-sizing:border-box;padding:2px 6px 2px;background:#131632;border-top:2px solid #2c3270}\n#sl{height:clamp(92px,19vh,224px);overflow-y:auto;overflow-x:hidden;touch-action:pan-y}\n#slh{height:16px;font-size:11px;line-height:16px;font-weight:800;white-space:nowrap;overflow:hidden}\n.box{display:flex;align-items:center;height:46px;margin:0 0 2px;background:#1a1f4a;border:1px solid #2c3270;border-radius:5px;box-sizing:border-box;padding:0 2px}\n.lab2{flex:none;width:72px;font-size:10px;line-height:12px;font-weight:700;white-space:pre-line;overflow:hidden;margin-right:2px}\n.pm{flex:none;width:44px;min-width:44px;height:44px;margin:0;font-size:22px;line-height:22px;padding:0}\n.box input{flex:1;min-width:0;height:44px;margin:0 2px}\n#chips{flex:1;margin-left:0}\n.chip{position:relative;overflow:hidden;flex:1;margin:0 0 0 3px;min-width:0;font-size:10.5px;border-width:3px}.chip i{position:absolute;left:0;bottom:0;height:5px;width:0;background:currentColor;opacity:.9}\n.trow button{white-space:normal;line-height:11px}\nbutton.wait{background:#3a3a55;border-color:#7a7a99;color:#c8c8dd}\n#r2 #tStart{margin:0}")
e.ed("#tools","#tools",0) if False else None
e.save()
