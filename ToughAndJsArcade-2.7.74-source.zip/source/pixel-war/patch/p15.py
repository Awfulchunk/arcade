import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# (1) exit mouth = lane width: lateral spawn offset is the pixel's own lane offset (poff) times the lane half-width at the circle (never wider than the circle itself)
e.ed("  const lat=(rnd()-.5)*10;px[i]=c.x+hx*c.r*0.6-hy*lat;py[i]=c.y+hy*c.r*0.6+hx*lat;","  const po0=clamp((rnd()+rnd()+rnd()-1.5)*(1.4-0.09*sd.set.density),-1,1),hw0=Math.min(c.r*0.95,laneHW(sd.set)*laneF(sd.paths[0].lane,0)),lat=po0*hw0,fwd=Math.min(c.r*0.6,Math.sqrt(Math.max(0,c.r*c.r*0.9-lat*lat)));px[i]=c.x+hx*fwd-hy*lat;py[i]=c.y+hy*fwd+hx*lat;")
e.ed("poff[i]=clamp((rnd()+rnd()+rnd()-1.5)*(1.4-0.09*sd.set.density),-1,1);pdr[i]","poff[i]=po0;pdr[i]")
# (2) ricochet = momentum: the bounced pixel is FREE (no steering, no drift) until it fades past the leash or hits something
e.ed("const pfade=new Uint8Array(NP),","const pfree=new Uint8Array(NP),pfade=new Uint8Array(NP),")
e.ed("pmom[i]=0;psq[i]=-1;pfade[i]=0;\n","pmom[i]=0;psq[i]=-1;pfade[i]=0;pfree[i]=0;\n")
e.ed("pgc.fill(0);pst.fill(0);","pgc.fill(0);pfree.fill(0);pfade.fill(0);pst.fill(0);")
e.ed("function strayStart(i,sd){","function freePix(i){const sd=S.sides[i<POOL?0:1];if(psq[i]>=0)unlink(i,sd);pst[i]=3;pfree[i]=1;pend[i]=0;}\nfunction strayStart(i,sd){")
e.ed("deflect(i,nx,ny,rotv,false);px[i]+=nx*dI;py[i]+=ny*dI;}","deflect(i,nx,ny,rotv,false);freePix(i);px[i]+=nx*dI;py[i]+=ny*dI;}")
e.ed("deflect(j,-nx,-ny,rotv,false);px[j]-=nx*dJ;py[j]-=ny*dJ;}","deflect(j,-nx,-ny,rotv,false);freePix(j);px[j]-=nx*dJ;py[j]-=ny*dJ;}")
e.ed("        if(!stun){let a=Math.atan2(vy,vx);const gain=Math.min(3,0.6+pend[i]*0.9);a+=pdr[i]*dt*gain;vx=Math.cos(a)*spd;vy=Math.sin(a)*spd;}\n        pend[i]+=dt;const dx=px[i]-pex[pi],dy=py[i]-pey[pi];\n        if(dx*dx+dy*dy>L2&&pfade[i]===0)pfade[i]=FADE_T();",
"        if(pfree[i]){pend[i]+=dt;if(pfade[i]===0&&((i+S.tick)&7)===0){let m=1e18;for(let k=0;k<n;k++){const ax=px[i]-p[k*2],ay=py[i]-p[k*2+1],d2=ax*ax+ay*ay;if(d2<m)m=d2;}if(m>L2)pfade[i]=FADE_T();}}\n        else{if(!stun){let a=Math.atan2(vy,vx);const gain=Math.min(3,0.6+pend[i]*0.9);a+=pdr[i]*dt*gain;vx=Math.cos(a)*spd;vy=Math.sin(a)*spd;}\n        pend[i]+=dt;const dx=px[i]-pex[pi],dy=py[i]-pey[pi];\n        if(dx*dx+dy*dy>L2&&pfade[i]===0)pfade[i]=FADE_T();}")
e.ed("get stat(){return stat;},","get stat(){return stat;},pfree,freePix,")
e.save()
