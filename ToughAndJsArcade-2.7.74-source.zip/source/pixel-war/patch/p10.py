import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# ---- title/version
e.ed("<title>PIXEL WAR 0.4.1</title>","<title>PIXEL WAR 0.4.2</title>")
e.ed("<h1>PIXEL WAR 0.4.1</h1>","<h1>PIXEL WAR 0.4.2</h1>")
e.ed("PIXEL WAR 0.4.1 — full game","PIXEL WAR 0.4.2 — full game")
# ---- keys (v42, fall back to v41)
e.ed("const KEY='pixelwar.v41',KEYC='pixelwar.v41.custom',KEYF='pixelwar.v41.forms',KEY4=","const KEY='pixelwar.v42',KEYC='pixelwar.v42.custom',KEYF='pixelwar.v42.forms',KEY41='pixelwar.v41',KEYC41='pixelwar.v41.custom',KEYF41='pixelwar.v41.forms',KEY4=")
e.ed("localStorage.getItem(KEYF)||localStorage.getItem(KEYF4)||'null'","localStorage.getItem(KEYF)||localStorage.getItem(KEYF41)||localStorage.getItem(KEYF4)||'null'")
e.ed("let v=JSON.parse(localStorage.getItem(KEYC)||'null'),old=false;if(!v){v=JSON.parse(localStorage.getItem(KEYC4)||localStorage.getItem(KEYC3)||'null');old=true;}","let v=JSON.parse(localStorage.getItem(KEYC)||localStorage.getItem(KEYC41)||'null'),old=false;if(!v){v=JSON.parse(localStorage.getItem(KEYC4)||localStorage.getItem(KEYC3)||'null');old=true;}")
e.ed("JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(KEY4)||localStorage.getItem(KEY3)||'null')","JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(KEY41)||localStorage.getItem(KEY4)||localStorage.getItem(KEY3)||'null')")
# ---- config: pace, match length
e.ed("pathMax:520,brMax:140","paceMax:36,pathMax:520,brMax:140")
e.ed("['_','PIXELS'],\n","['_','PIXELS'],\n ['paceMax','Fastest pace (units per second)','the PACE slider runs from a quarter of this up to this. 36 is a light brisk walk: about 14 seconds to cross the field','r',12,90,2],\n")
# ---- speed
e.ed("function speedOf(set){return 30+9*set.speed;}","const PACE_REF=75;   // the old (0.4.1) default pace; absolute velocities, knock, jitter and tick timers are scaled by speedOf/PACE_REF so slow pixels behave like slow-motion fast ones\nfunction speedOf(set){const hi=CFG.paceMax;return hi*(0.25+0.75*(set.speed-1)/9);}\nconst vkOf=sp=>clamp(sp/PACE_REF,0.12,1.6),tkOf=sp=>clamp(PACE_REF/sp,1,5);")
e.ed("function laneHW(set){return (30-set.density*2.5)*(1.25-0.05*set.speed);}","function laneHW(set){return 5+2.4*set.width;}   // WIDTH slider: half-width of the lane the pixels follow (units); the lane shape factors (wide 2.0, thin 0.4, arrow 1.2) multiply it")
e.ed("const DEF={speed:5,density:7,release:9,cap:PERFCAP,sdens:7,compact:6};","const DEF={speed:5,density:7,release:9,cap:PERFCAP,sdens:7,compact:6,width:3,spacing:5};")
e.ed("if(key==='speed'||key==='density'||key==='release'||key==='sdens'||key==='compact')","if(key==='speed'||key==='density'||key==='release'||key==='sdens'||key==='compact'||key==='width'||key==='spacing')")
# release: exit time and initial spread
e.ed("php[i]=CFG.pixHP;pst[i]=1;pcnt[i]=EXIT_T;pps[i]=0;poff[i]=clamp((rnd()+rnd()+rnd()-1.5)*0.8,-1,1);","php[i]=CFG.pixHP;pst[i]=1;pcnt[i]=Math.min(90,Math.round(EXIT_T*tkOf(speedOf(sd.set))));pps[i]=0;poff[i]=clamp((rnd()+rnd()+rnd()-1.5)*(1.4-0.09*sd.set.density),-1,1);")
# movePixels: jitter scale, density pull, spacing push
e.ed("const compactK=1.2+0.9*set.compact,jit=(11-set.compact)*2.2,conv=CFG.converge;","const compactK=1.2+0.9*set.compact,vk=vkOf(spd0),jit=(11-set.compact)*2.2*vk,conv=CFG.converge,rev=0.04*set.density,spc=(set.spacing-1)/9*0.25,spcOn=spc>0&&S.phase==='battle';")
e.ed("else{poff[i]=clamp(poff[i]+(rnd()-.5)*dt*3-poff[i]*dt*0.25,-1,1);","else{let po=poff[i];if(spcOn){const rh=rhoAt(side,px[i],py[i]);if(rh>3)po+=(po>0.02?1:po<-0.02?-1:((i&1)?1:-1))*spc*Math.min(1,rh/40)*dt;}\n          poff[i]=clamp(po+(rnd()-.5)*dt*3-po*dt*rev,-1,1);")
# knock/stun/cooldown scaling
e.ed("function knock(i,nx,ny){const K=CFG.knockK;","function knock(i,nx,ny){const K=CFG.knockK*vkOf(speedOf(S.sides[i<POOL?0:1].set));")
e.ed("rx=(vx*c-vy*s)/m*sp,ry=(vx*s+vy*c)/m*sp;pvx[i]=rx;pvy[i]=ry;pstun[i]=STUN;}","rx=(vx*c-vy*s)/m*sp,ry=(vx*s+vy*c)/m*sp;pvx[i]=rx;pvy[i]=ry;pstun[i]=Math.min(120,Math.round(STUN*tkOf(speedOf(S.sides[i<POOL?0:1].set))));}")
e.ed("pcd[i]=pcd[j]=CD_HIT;","pcd[i]=pcd[j]=cdh;")
e.ed("RSP=speedOf(s0.set)+speedOf(s1.set);","RSP=speedOf(s0.set)+speedOf(s1.set),cdh=clamp(Math.round(CD_HIT*2*PACE_REF/RSP),CD_HIT,60);")
e.ed("get stat(){return stat;},","get stat(){return stat;},vkOf,tkOf,PACE_REF,")
e.save()
