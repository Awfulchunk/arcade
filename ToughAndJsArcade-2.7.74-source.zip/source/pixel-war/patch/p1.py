import sys; sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
e.ed('<title>PIXEL WAR 0.3</title>','<title>PIXEL WAR 0.4</title>')
e.ed('PIXEL WAR 0.3 — full game on the 0.1.1 density engine.','PIXEL WAR 0.4 — full game on the 0.1.1 density engine (0.4: lane shapes, arrow front, reforming formations, formation editor, AI formations, gates, full hybrid ricochet, difficulty, stages, stats, AI review).')
e.ed("const SHAPES=['LINE','ARROW','WEDGE','RING','DIAMOND','DOUBLE','SPIRAL'];","const MAXCUS=6,NSH=7+MAXCUS,FCOLS=15,FROWS=12,FMAXC=120;\nconst SHAPES=['LINE','ARROW','WEDGE','RING','DIAMOND','DOUBLE','SPIRAL','C1','C2','C3','C4','C5','C6'];\nconst LANES=['NORMAL','WIDE','NARROW','TAPERED','ARROW'],LMAX=[1,1.4,0.6,1.4,1.3];")
e.ed("const KEY='pixelwar.v3',KEYC='pixelwar.v3.custom';","const KEY='pixelwar.v4',KEYC='pixelwar.v4.custom',KEYF='pixelwar.v4.forms',KEY3='pixelwar.v3',KEYC3='pixelwar.v3.custom';")
# DEFCFG
e.ed("ricoMode:0,leash:72,","ricoMode:3,leash:72,")
e.ed("halo:1,reveal:1,capDef:PERFCAP,relMul:120};","halo:1,reveal:1,capDef:PERFCAP,relMul:120,\n laneDef:0,brWaste:30,gate:1,arrowFront:60,reformSec:2.5,shockK:3,breakLive:20,kSpeed:60,aiForms:1,aiReview:1,stage:0,stageAll:1};")
e.ed("const LBL={ricoMode:['RANDOM','ANGLE','HYBRID'],aiLevel:['OFF','EASY','NORMAL','HARD','EXPERT'],","const LBL={ricoMode:['RANDOM','ANGLE','HYBRID','FULL HYBRID'],aiLevel:['OFF','EASY','NORMAL','HARD','BRUTAL'],laneDef:LANES,stage:['FREE PLAY','1 FUNDAMENTALS','2 TACTICAL','3 ADVANCED','4 STRATEGIC'],")
e.ed("['ricoMode','Ricochet rule','random, impact angle, or both','e'],","['ricoMode','Ricochet rule','random / angle / hybrid (angle + density) / FULL HYBRID (angle + closing speed + packing)','e'],['kSpeed','Impact speed effect %','FULL HYBRID: fast impacts hit harder and push farther, slow ones glance','r',0,150,10],")
e.ed("['liveBr','Redraw branches in battle','','b'],","['liveBr','Redraw branches in battle','erase and redraw a branch mid-match; the main path stays locked','b'],['brWaste','Branch meter lost when erased in battle %','the rest is refunded; erasing in prep is free; total branch meter = branch meter x max branches','r',0,100,10],['laneDef','Default lane shape','the hitbox area the pixels occupy: normal, wide, narrow, tapered, arrow','e'],")
e.ed("['liveWall','Build walls in battle','','b'],","['liveWall','Build walls in battle','','b'],['gate','Friendly gates','a gate is a wall piece your own pixels pass through and enemies cannot','b'],")
e.ed("['ring','RING shape available','moved here from the main game','b'],","['ring','RING shape available','moved here from the main game','b'],['arrowFront','Arrow front concentration %','a fuller leading edge on ARROW and WEDGE','r',0,100,10],['reformSec','Formation reform time (s)','how long a hit formation takes to get back to its preferred arrangement','r',0.5,8,0.5],['shockK','Formation damage per impact %','how much each impact distorts a formation (stretch, compress, break)','r',0,20,1],['breakLive','Formation breaks below % pixels','a formation with fewer live pixels than this disbands','r',5,60,5],")
e.ed("['aiLevel','AI level','intelligence only, never stats','e'],['aiLearn','AI learns during match','memory is wiped when it ends','b'],","['aiLevel','AI difficulty','decision quality, planning and adaptation only, never stats','e'],['aiLearn','AI learns during match','memory is wiped when it ends','b'],['aiForms','AI designs custom formations','same cooldowns and rules as yours','b'],['aiReview','AI match review at the end','shown on the result screen; its tactical memory is wiped','b'],\n ['_','PROGRESSION'],\n ['stage','Stage','FREE PLAY has every mechanic; stages unlock them gradually (1 Fundamentals, 2 Tactical, 3 Advanced, 4 Strategic)','e'],['stageAll','All stages selectable','test build: start any stage without winning the previous one','b'],")
# mkPath / lanes
e.ed("function laneHW(set){return (30-set.density*2.5)*(1.25-0.05*set.speed);}","""function laneHW(set){return (30-set.density*2.5)*(1.25-0.05*set.speed);}
// LANE SHAPES: the hitbox area the pixels occupy. laneF(type,t) = half-width factor at fraction t along the path (allocation-free).
function laneF(ty,t){if(t<0)t=0;else if(t>1)t=1;switch(ty){case 1:return 1.4;case 2:return 0.6;case 3:return 1.4-0.9*t;
  case 4:if(t<0.6)return 0.55;if(t<0.8)return 0.55+(t-0.6)*3.75;return 1.3-(t-0.8)*5.25;default:return 1;}}
// STAGES: which mechanics exist. stage 0 = free play (everything). The AI obeys the same table through the same API.
const STAGEF={walls:2,branch:2,shapes:2,laneAB:2,gate:3,shapes2:3,laneCD:3,forms:3,rico3:4,aiForms:4};
function feat(k){const st=CFG.stage|0;return !st||st>=STAGEF[k];}""")
e.ed("function mkPath(id,par,fk){return{id:id,p:[],par:par,fk:fk,share:id?40:100,sh:{t:1,pull:CFG.sqPull,at:0},rj:-1,kids:[],arm:null};}","function mkPath(id,par,fk){return{id:id,p:[],par:par,fk:fk,share:id?40:100,sh:{t:1,pull:CFG.sqPull,at:0},rj:-1,kids:[],arm:null,lane:(CFG.laneDef|0)};}")
e.ed("stats:{released:0,kills:0,recalled:0,circleDmg:0,burned:0,livesUsed:0,lostForGood:0,wallDmg:0,wallsBroken:0,ricochets:0,misses:0,ct:0,defl:0,surv:0,pushed:0,shapeMade:zeros(7),shapeKill:zeros(7),shapeLoss:zeros(7)},","stats:{released:0,kills:0,recalled:0,circleDmg:0,burned:0,livesUsed:0,lostForGood:0,wallDmg:0,wallsBroken:0,ricochets:0,misses:0,ct:0,defl:0,surv:0,pushed:0,intercepts:0,formBreaks:0,formReforms:0,gatePass:0,wallTaken:0,brRedraws:0,shapeMade:zeros(NSH),shapeKill:zeros(NSH),shapeLoss:zeros(NSH)},forms:[],brWaste:0,")
e.ed("openQ:zeros(MAXP).map(()=>-1),shReady:zeros(7),shUsed:zeros(7)};}","openQ:zeros(MAXP).map(()=>-1),shReady:zeros(NSH),shUsed:zeros(NSH)};}")
e.ed("function resetPaths(sd){const c=sd.circle,m=mkPath(0,-1,0);m.p=[c.x,c.y];m.sh=sd.paths[0].sh;sd.paths=[m];}","function resetPaths(sd){const c=sd.circle,m=mkPath(0,-1,0);m.p=[c.x,c.y];m.sh=sd.paths[0].sh;m.lane=sd.paths[0].lane;sd.paths=[m];}")
# feature gates on build rights
e.ed("const canWall=sd=>!S.over&&((S.phase==='prep'&&!sd.locked)||(S.phase==='battle'&&!!CFG.liveWall));","const canWall=sd=>!S.over&&feat('walls')&&((S.phase==='prep'&&!sd.locked)||(S.phase==='battle'&&!!CFG.liveWall));")
e.ed("const canBr=sd=>!S.over&&((S.phase==='prep'&&!sd.locked)||(S.phase==='battle'&&!!CFG.liveBr));","const canBr=sd=>!S.over&&feat('branch')&&((S.phase==='prep'&&!sd.locked)||(S.phase==='battle'&&!!CFG.liveBr));")
# branch meter
e.ed("const brUsed=P=>pathLen(P);","""const brUsed=P=>pathLen(P);
// branch meter: each branch <= brMax; ALL branches together (+ meter lost to erasing in battle) <= brMax x maxBr, so erase/redraw cannot mint meter
const brTotal=sd=>{let n=sd.brWaste||0;for(let k=1;k<sd.paths.length;k++)if(sd.paths[k])n+=pathLen(sd.paths[k]);return n;};
const brCap=()=>CFG.brMax*Math.max(1,CFG.maxBr);
const brLeft=(sd,P)=>Math.max(0,Math.min(CFG.brMax-brUsed(P),brCap()-brTotal(sd)));
function brErased(sd,len){if(S.phase==='battle'&&len>0){sd.brWaste+=len*CFG.brWaste/100;sd.stats.brRedraws++;}}""")
e.ed("""function branchBegin(side,x,y){const sd=S.sides[side];if(!canBr(sd)||!fin(x)||!fin(y))return null;if(brCount(sd)>=CFG.maxBr)return null;
  const M=sd.paths[0],p=M.p,n=pathN(M);let best=-1,bd=1e9;
  for(let k=1;k<n;k++){const d=Math.hypot(p[k*2]-x,p[k*2+1]-y);if(d<bd&&Math.hypot(p[k*2]-sd.circle.x,p[k*2+1]-sd.circle.y)>CR+6){bd=d;best=k;}}
  if(best<0||bd>18)return null;""","""function branchBegin(side,x,y){const sd=S.sides[side];if(!canBr(sd)||!fin(x)||!fin(y))return null;
  const M=sd.paths[0],p=M.p,n=pathN(M);let best=-1,bd=1e9;
  for(let k=1;k<n;k++){const d=Math.hypot(p[k*2]-x,p[k*2+1]-y);if(d<bd&&Math.hypot(p[k*2]-sd.circle.x,p[k*2+1]-sd.circle.y)>CR+6){bd=d;best=k;}}
  // starting at the END of an existing branch continues (redraws) it
  for(let b=1;b<sd.paths.length;b++){const Q=sd.paths[b];if(!Q)continue;const m=Q.p.length>>1;if(m>=2){const d=Math.hypot(Q.p[m*2-2]-x,Q.p[m*2-1]-y);if(d<9&&d<bd){return PSP>brLeft(sd,Q)+1e-6?null:Q;}}}
  if(brCount(sd)>=CFG.maxBr)return null;if(brCap()-brTotal(sd)<PSP)return null;
  if(best<0||bd>18)return null;""")
e.ed("if(brUsed(P)+PSP>CFG.brMax+1e-6)break;","if(PSP>brLeft(sd,P)+1e-6)break;")
e.ed("function removeBranch(sd,id){const P=sd.paths[id];if(!P)return;const M=sd.paths[0];","function removeBranch(sd,id){const P=sd.paths[id];if(!P)return;brErased(sd,pathLen(P));const M=sd.paths[0];")
e.ed("if(k<=2)removeBranch(sd,b);else{P.p.length=k*2;rejoinOf(sd,P);}","if(k<=2)removeBranch(sd,b);else{brErased(sd,(pathN(P)-k)*PSP);P.p.length=k*2;rejoinOf(sd,P);}")
# gates
e.ed("function crossesOwnWall(sd,ax,ay,bx,by){for(const st of sd.strokes){const q=st.pts;","function crossesOwnWall(sd,ax,ay,bx,by){for(const st of sd.strokes){if(st.gate)continue;const q=st.pts;")
e.ed("function wallBegin(side,x,y){const sd=S.sides[side];if(!canWall(sd)||!fin(x)||!fin(y))return null;\n  if(sd.strokes.length>=MAX_STROKES||wallUsed(sd)+CFG.wsp>CFG.wallMax+1e-6||!inWallZone(side,x,y)||nearOwnPath(sd,x,y,clrOf(sd),true))return null;\n  const st={pts:[x,y],segs:[],hits:0,open:true};","function wallBegin(side,x,y,gate){const sd=S.sides[side];if(!canWall(sd)||!fin(x)||!fin(y))return null;gate=!!gate;if(gate&&(!CFG.gate||!feat('gate')))return null;\n  if(sd.strokes.length>=MAX_STROKES||wallUsed(sd)+CFG.wsp>CFG.wallMax+1e-6||!inWallZone(side,x,y)||(!gate&&nearOwnPath(sd,x,y,clrOf(sd),true)))return null;\n  const st={pts:[x,y],segs:[],hits:0,open:true,gate:gate};")
e.ed("if(!inWallZone(side,nx,ny)||nearOwnPath(sd,nx,ny,clrOf(sd),true))break;st.pts.push(nx,ny);n++;}","if(!inWallZone(side,nx,ny)||(!st.gate&&nearOwnPath(sd,nx,ny,clrOf(sd),true)))break;st.pts.push(nx,ny);n++;}")
e.ed("hp:hp,max:hp,side:sd.id,alive:true,st:st,hitT:-999});}}}","hp:hp,max:hp,side:sd.id,alive:true,st:st,gate:!!st.gate,hitT:-999});}}}")
e.ed("function clrOf(sd){return laneHW(sd.set)+4;}","function clrOf(sd){let m=0.6;for(const P of sd.paths)if(P&&LMAX[P.lane|0]>m)m=LMAX[P.lane|0];return laneHW(sd.set)*Math.max(1,m)+4;}")
e.ed("function nearOwnWall(sd,x,y,clr){for(const st of sd.strokes){const q=st.pts;","function nearOwnWall(sd,x,y,clr){for(const st of sd.strokes){if(st.gate)continue;const q=st.pts;")
# lane setter
e.ed("function setShare(side,id,v){","function laneOk(ty){return ty===0||((ty===1||ty===2)?feat('laneAB'):feat('laneCD'));}\nfunction setLane(side,id,v){const P=getPath(S.sides[side],id);if(!P||!fin(v))return false;v=clamp(Math.round(v),0,4);if(!laneOk(v))return false;P.lane=v;return true;}\nfunction setShare(side,id,v){")
e.save()
