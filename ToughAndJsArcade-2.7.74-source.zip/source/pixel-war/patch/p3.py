import sys; sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# state: planInfo, review reset, forms clone
e.ed("S={tick:0,phase:'prep',over:false,winner:-2,paused:false,msg:'',tool:'main',sides:[mkSide(0),mkSide(1)],prepT:0,ai:null,aiSummary:null,cfg:Object.assign({},CFG)};","S={tick:0,phase:'prep',over:false,winner:-2,paused:false,msg:'',tool:'main',sides:[mkSide(0),mkSide(1)],prepT:0,ai:null,aiSummary:null,aiReview:null,planInfo:[null,null],cfg:Object.assign({},CFG)};\n  S.sides[0].forms=cloneForms();if(CFG.duel)S.sides[1].forms=cloneForms();")
e.ed("// ---------- STATE\nlet S=null,CR=22,ME=0;","""// ---------- FORMATION PRESETS (the formation editor's saved formations; localStorage; validated like every other save)
let PRESETS=[];
function cleanForm(f){if(!f||typeof f!=='object')return null;const cells=[],seen=new Set();
  if(Array.isArray(f.cells))for(const c of f.cells){if(cells.length>=FMAXC)break;if(!Array.isArray(c))continue;const x=Math.floor(+c[0]),y=Math.floor(+c[1]);if(!(x>=0&&x<FCOLS&&y>=0&&y<FROWS))continue;const k=y*FCOLS+x;if(seen.has(k))continue;seen.add(k);cells.push([x,y]);}
  if(cells.length<3)return null;return{name:String(typeof f.name==='string'&&f.name?f.name:'FORM').slice(0,10),cells:cells};}
function cloneForms(){return PRESETS.map(f=>({name:f.name,cells:f.cells.map(c=>[c[0],c[1]])}));}
function loadForms(){const a=[];try{const v=JSON.parse(localStorage.getItem(KEYF)||'null');if(Array.isArray(v))for(const f of v){if(a.length>=MAXCUS)break;const c=cleanForm(f);if(c)a.push(c);}}catch(e){}PRESETS=a;}
function saveForms(){try{localStorage.setItem(KEYF,JSON.stringify(PRESETS.map(f=>({name:f.name,cells:f.cells}))));}catch(e){}}
function syncForms(){if(!S)return;for(const sd of S.sides)if(sd.human){sd.forms=cloneForms();for(let t=7;t<NSH;t++)sd.shReady[t]=0;}}
function addPreset(name,cells){if(PRESETS.length>=MAXCUS)return -1;const c=cleanForm({name:name||('CUSTOM '+(PRESETS.length+1)),cells:cells});if(!c)return -1;PRESETS.push(c);saveForms();syncForms();return PRESETS.length-1;}
function delPreset(i){i=Math.floor(i);if(!(i>=0&&i<PRESETS.length))return false;PRESETS.splice(i,1);saveForms();syncForms();return true;}
const shName=(sd,t)=>t<7?SHAPES[t]:(sd.forms[t-7]?sd.forms[t-7].name:'C'+(t-6));
// ---------- STATE
let S=null,CR=22,ME=0;""")
# AI
e.ed("const sgn=rnd()<0.5?-1:1,style=(rnd()*3)|0;","const sgn=rnd()<0.5?-1:1,style=(rnd()*3)|0;S.planInfo[side]={style:style,walls:0,gates:0,branches:0,lane:0,forms:[]};")
e.ed("const tx=foe.x+(rnd()-.5)*20,ty=foe.y+(rnd()-.5)*10;","const tx=foe.x+(rnd()-.5)*(lv<=1?150:lv===2?50:20),ty=foe.y+(rnd()-.5)*(lv<=1?60:lv===2?24:10);")
e.ed("for(const s of strokes){const st=wallBegin(side,s[0],s[1]);if(!st)continue;wallExtend(side,st,s[2],s[3]);wallEnd(side,st);}","for(const s of strokes){const st=wallBegin(side,s[0],s[1]);if(!st)continue;wallExtend(side,st,s[2],s[3]);wallEnd(side,st);S.planInfo[side].walls++;}\n  if(lv>=4&&laneOk(3)){sd.paths[0].lane=3;S.planInfo[side].lane=3;}\n  if(lv>=3&&CFG.gate&&feat('gate')){const M0=sd.paths[0],n0=pathN(M0);for(const at of(lv>=4?[18,34]:[18])){if(n0<at+3)continue;const gx=M0.p[at*2],gy=M0.p[at*2+1],tx0=M0.p[(at+1)*2]-M0.p[(at-1)*2],ty0=M0.p[(at+1)*2+1]-M0.p[(at-1)*2+1],tl0=Math.hypot(tx0,ty0)||1,gnx=-ty0/tl0,gny=tx0/tl0;\n    const g=wallBegin(side,gx-gnx*18,gy-gny*18,true);if(g){wallExtend(side,g,gx+gnx*18,gy+gny*18);wallEnd(side,g);if(g.pts.length>=4)S.planInfo[side].gates++;}}}")
e.ed("        branchEnd(side,B);if(sd.paths[B.id]===B){B.share=CFG.autoDist?B.share:35+((rnd()*20)|0)*1;B.sh.at=20;}}}","        branchEnd(side,B);if(sd.paths[B.id]===B){B.share=CFG.autoDist?B.share:35+((rnd()*20)|0)*1;B.sh.at=20;S.planInfo[side].branches++;}}}")
e.ed("    sd.paths[0].sh.at=(10+rnd()*30)|0;}\n  sd.settingsPlanned=true;}","    sd.paths[0].sh.at=(10+rnd()*30)|0;}\n  if(lv>=3&&CFG.aiForms&&feat('forms')&&feat('aiForms')){for(let k=0;k<(lv>=4?2:1);k++){const f=aiDesignForm(sd);if(f)S.planInfo[side].forms.push(f.name);}}\n  sd.settingsPlanned=true;}")
e.ed("const aiEvery=lv=>lv>=4?90:lv>=3?150:240;","""const aiEvery=lv=>lv>=4?60:lv>=3?150:240;
// AI formation designer: builds a custom formation on the FCOLS x FROWS grid from a template family + random mutation, then uses it through the same useShape()/cooldown rules.
function aiDesignForm(sd){if(sd.forms.length>=MAXCUS)return null;const fam=(rnd()*6)|0,cells=[],add=(c,r)=>{if(c>=0&&c<FCOLS&&r>=0&&r<FROWS)cells.push([c,r]);};
  const name=['COMB','CRESCENT','CROSS','TRIDENT','WAVE','WINGS'][fam];
  if(fam===0){const k=3+((rnd()*3)|0),len=5+((rnd()*5)|0);for(let t=0;t<k;t++){const c=Math.round(1+t*(FCOLS-3)/(k-1)),r0=(t&1)*2;for(let r=r0;r<r0+len&&r<FROWS;r++)add(c,r);}}
  else if(fam===1){for(let c=1;c<FCOLS-1;c++){const x=(c-7)/7,r=Math.round(6*(1-x*x));add(c,r);add(c,r+1);}}
  else if(fam===2){for(let r=0;r<FROWS;r++)add(7,r);for(let c=2;c<13;c++)add(c,4);}
  else if(fam===3){for(const c of[2,7,12])for(let r=(c===7?0:2);r<9;r++)add(c,r);for(let c=2;c<13;c++)add(c,9);}
  else if(fam===4){const ph=rnd()*3;for(let c=1;c<FCOLS-1;c++){const r=Math.round(4+2.5*Math.sin(c*0.9+ph));add(c,r);add(c,r+1);}}
  else{for(let c=0;c<FCOLS;c++){const r=Math.round(Math.abs(c-7)*0.9);add(c,r);add(c,r+1);}}
  const keep=cells.filter(()=>rnd()>0.08),f=cleanForm({name:name,cells:keep});if(!f)return null;sd.forms.push(f);if(S.ai)S.ai.designs.push(f.name);return f;}""")
# aiAdapt shape learning over NSH with per-side availability
e.ed("let bestT=-1,bestS=0;for(let t=0;t<7;t++)if(shapeOk(t)&&st.shapeMade[t]>0&&(bestT<0||score(t)>bestS)){bestS=score(t);bestT=t;}\n  if(bestT>=0&&bestT!==ai.best){ai.best=bestT;aiLearn(SHAPES[bestT]+' works best ('+bestS.toFixed(2)+' kills per loss)');}",
"let bestT=-1,bestS=0;for(let t=0;t<NSH;t++)if(shapeOkS(sd,t)&&st.shapeMade[t]>0&&(bestT<0||score(t)>bestS)){bestS=score(t);bestT=t;}\n  if(bestT>=0&&bestT!==ai.best){ai.best=bestT;aiLearn(shName(sd,bestT)+' works best ('+bestS.toFixed(2)+' kills per loss)');}\n  if(lv>=4&&CFG.aiForms&&feat('forms')&&feat('aiForms')){let wt=-1,ws=9;for(let t=7;t<NSH;t++)if(sd.forms[t-7]&&st.shapeMade[t]>=2&&score(t)<0.75&&score(t)<ws){ws=score(t);wt=t;}\n    if(wt>=0){const old=sd.forms[wt-7].name;sd.forms.splice(wt-7,1);const nf=aiDesignForm(sd);if(nf){const ni=sd.forms.length-1+7;st.shapeMade[ni]=0;st.shapeKill[ni]=0;st.shapeLoss[ni]=0;aiLearn('dropped formation '+old+' ('+ws.toFixed(2)+'), designed '+nf.name);}}\n    else if(sd.forms.length<2&&st.shapeMade.reduce((x,y)=>x+y,0)>=3){const nf=aiDesignForm(sd);if(nf)aiLearn('designed a new formation: '+nf.name);}}")
e.ed("const avail=[];for(let t=0;t<7;t++)if(shapeOk(t)&&sd.shReady[t]<=S.tick)avail.push(t);if(!avail.length)return;","const avail=[];for(let t=0;t<NSH;t++)if(shapeOkS(sd,t)&&sd.shReady[t]<=S.tick)avail.push(t);if(!avail.length)return;")
e.ed("  if(lv<3&&rnd()<0.6)return;","  if(lv<3&&rnd()<(lv<2?0.8:0.6))return;\n  if(lv>=4){const fb=(1-side)*POOL;let near=1e9;for(let i=fb;i<fb+POOL;i+=6){if(!pst[i])continue;for(const P of sd.paths){if(!P||P.arm||pathN(P)<3)continue;const f=fPos(P);pathAt(P.p,f,tmp);const d=Math.hypot(px[i]-tmp[0],py[i]-tmp[1]);if(d<near)near=d;}}\n    if(near>140&&rnd()<0.85)return;}  // BRUTAL times its formations to meet visible enemy pixels")
# start / end of match: review + wipe
e.ed("S.ai=(CFG.aiLearn&&CFG.aiLevel>=2&&!S.sides[1].human)?{lessons:[],adapts:0,last:0,best:-1}:null;","S.ai=(CFG.aiLearn&&CFG.aiLevel>=2&&!S.sides[1].human)?{lessons:[],adapts:0,last:0,best:-1,designs:[]}:null;")
e.ed("""function endMatch(w){S.over=true;S.winner=w;S.phase='over';
  if(S.ai){S.aiSummary={lessons:S.ai.lessons.slice(),adapts:S.ai.adapts};S.ai=null;}  // memory saved for the result screen, then deleted
}""","""function endMatch(w){S.over=true;S.winner=w;S.phase='over';
  const sd=S.sides[1];
  if(!sd.human&&CFG.aiReview)S.aiReview=buildReview(w);   // the REVIEW is kept for the result screen only
  if(S.ai){S.aiSummary={lessons:S.ai.lessons.slice(),adapts:S.ai.adapts};}
  S.ai=null;if(!sd.human){sd.forms=[];sd.lossGrid.fill(0);}  // tactical memory WIPED: lessons, learned shapes, AI-designed formations
  if(w===0&&(CFG.stage|0)>0&&!S.sides[1].human&&prefs.stage<CFG.stage){prefs.stage=CFG.stage;}
}
const DIFFN=['OFF','EASY','NORMAL','HARD','BRUTAL'];
function buildReview(w){const sd=S.sides[1],me=S.sides[0],st=sd.stats,pi=S.planInfo[1]||{style:0,walls:0,gates:0,branches:0,lane:0,forms:[]},ln=[],lv=CFG.aiLevel|0;
  ln.push('Difficulty '+DIFFN[lv]+'. Opening: '+['a gentle curve','a wide swing','a late hook'][pi.style]+', '+pi.walls+' wall'+(pi.walls===1?'':'s')+(pi.gates?', '+pi.gates+' gate'+(pi.gates===1?'':'s'):'')+(pi.branches?', '+pi.branches+' branch'+(pi.branches===1?'':'es'):'')+(pi.lane?', '+LANES[pi.lane]+' lane':'')+'.');
  const made=[];for(let t=0;t<NSH;t++)if(st.shapeMade[t]>0)made.push([t,st.shapeMade[t],st.shapeKill[t],st.shapeLoss[t]]);
  if(made.length){made.sort((a,b)=>(b[2]+1)/(b[3]+1)-(a[2]+1)/(a[3]+1));const nm=t=>t<7?SHAPES[t]:(pi.forms[t-7]||('C'+(t-6)));ln.push('Formations: '+made.slice(0,3).map(m=>nm(m[0])+' x'+m[1]+' ('+((m[2]+1)/(m[3]+1)).toFixed(2)+' kills/loss)').join(', ')+'.');}
  else ln.push('Formations: none used.');
  if(pi.forms.length)ln.push('It designed '+pi.forms.length+' custom formation'+(pi.forms.length===1?'':'s')+': '+pi.forms.join(', ')+(S.ai&&S.ai.designs.length>pi.forms.length?' (+'+(S.ai.designs.length-pi.forms.length)+' mid-match)':'')+'.');
  const ls=S.ai?S.ai.lessons:[];if(ls.length){ln.push('Adapted '+S.ai.adapts+' times, '+ls.length+' lessons:');for(const l of ls.slice(0,4))ln.push(' - '+l);if(ls.length>4)ln.push(' - and '+(ls.length-4)+' more');}
  else ln.push(lv>=2&&CFG.aiLearn?'It learned nothing worth keeping.':'It does not learn at this setting.');
  ln.push('Its numbers: kills '+st.kills+', interceptions '+st.intercepts+', circle hits '+st.circleDmg+', barrier damage '+st.wallDmg+', formations broke '+st.formBreaks+' / reformed '+st.formReforms+'.');
  ln.push(w===1?'Result: it won.':w===0?'Result: it lost.':'Result: a draw.');
  ln.push('Tactical memory wiped.');
  return{lines:ln,level:lv,lessons:ls.slice(),designs:pi.forms.slice()};}""")
e.save()
