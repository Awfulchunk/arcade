import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
e.ed("if(S.tool==='circle'){if(S.phase!=='prep')return;placeCircle","if(S.tool==='circle'){if(S.phase!=='prep'&&!sbx())return;placeCircle")
e.ed("else if(S.tool==='main'){if(S.phase!=='prep')return;const p=","else if(S.tool==='main'){if(S.phase!=='prep'&&!sbx())return;const p=")
e.ed("if(ptr.mode==='circle'&&S.phase==='prep')placeCircle","if(ptr.mode==='circle'&&(S.phase==='prep'||sbx()))placeCircle")
e.ed("else if(ptr.mode==='wall'){ptr.px+=(q.x-ptr.px)*0.6;ptr.py+=(q.y-ptr.py)*0.6;wallExtend(ME,ptr.st,ptr.px,ptr.py);}","else if(ptr.mode==='wall'){ptr.px=q.x;ptr.py=q.y;wallExtend(ME,ptr.st,ptr.px,ptr.py);}   // walls follow the finger exactly (1:1), in 3-unit steps, right to the screen edge")
# tap a path (no drag) = select it: its sliders open in the panel
e.ed("canvas.addEventListener('pointerdown',e=>{e.preventDefault();if(ptr||S.over)return;","let tapS=null;\nfunction selectAt(q){const me=S.sides[ME];let bd=16,bi=-1;for(let i=0;i<me.paths.length;i++){const P=me.paths[i];if(!P)continue;const p=P.p;for(let k=0;k<p.length;k+=2){const d=Math.hypot(p[k]-q.x,p[k+1]-q.y);if(d<bd){bd=d;bi=i;}}}if(bi>=0){selP=bi;chipK='';return true;}return false;}\ncanvas.addEventListener('pointerdown',e=>{e.preventDefault();tapS={x:e.clientX,y:e.clientY,t:Date.now(),moved:false,q:wpt(e)};if(ptr||S.over)return;")
e.ed("canvas.addEventListener('pointermove',e=>{if(e.pointerId!==ptrId)return;toolMove(wpt(e));});","canvas.addEventListener('pointermove',e=>{if(e.pointerId!==ptrId)return;if(tapS&&Math.hypot(e.clientX-tapS.x,e.clientY-tapS.y)>8)tapS.moved=true;const ev=e.getCoalescedEvents?e.getCoalescedEvents():null;if(ev&&ev.length>1){for(const c of ev)toolMove(wpt(c));}else toolMove(wpt(e));});")
e.ed("const up=e=>{if(e.pointerId!==ptrId)return;ptrId=-1;toolUp();};","const up=e=>{if(e.pointerId!==ptrId)return;ptrId=-1;toolUp();if(tapS&&!tapS.moved&&Date.now()-tapS.t<600&&S.tool!=='erase'&&S.tool!=='circle'&&!S.over)selectAt(tapS.q);tapS=null;};")
# menu: sandbox button, shape editor hidden unless shapes are on
e.ed('<button id="mQuick">QUICK MATCH</button>','<button id="mQuick">QUICK MATCH</button><button id="mSandbox">SANDBOX (test both sides)</button>')
e.ed("$('mQuick').addEventListener('click',()=>startWith({aiLevel:prefs.diff}));","$('mQuick').addEventListener('click',()=>startWith({aiLevel:prefs.diff}));\n$('mSandbox').addEventListener('click',()=>startWith({duel:1,aiLevel:0}));")
e.ed("function showView(v){view=v;if(v==='menu')setT('mDiff','DIFFICULTY: '+DIFFN[prefs.diff]);","function showView(v){view=v;if(v==='menu'){setT('mDiff','DIFFICULTY: '+DIFFN[prefs.diff]);$('mForms').style.display=CUS.shapesOn?'block':'none';}")
e.save()
