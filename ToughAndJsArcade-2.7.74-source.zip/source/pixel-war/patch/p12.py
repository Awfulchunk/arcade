import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
# ---- VFX pool (visual only: own RNG, never touches the sim RNG)
e.ed("// ---------- COLLISION\n","""// ---------- VFX (visual only): destroyed pixels split into 1x1 bits that fade; ricocheting pixels glow and leave a fading trail. Fixed typed-array pool, own RNG, per-tick spawn budget, drops spawns when full.
const VPMAX=1800,VBUD=20,vX=new Float32Array(VPMAX),vY=new Float32Array(VPMAX),vVX=new Float32Array(VPMAX),vVY=new Float32Array(VPMAX),vLife=new Uint8Array(VPMAX),vTot=new Uint8Array(VPMAX),vCol=new Uint32Array(VPMAX),vKind=new Uint8Array(VPMAX);
const pbnc=new Uint8Array(NP),bList=new Int32Array(400);let vpN=0,bN=0,vBud=VBUD,vs=0x9E3779B9;
const VFX={sparkBursts:0,bits:0,bounces:0,trails:0,dropped:0,on:1};
const vr=()=>{vs^=vs<<13;vs^=vs>>>17;vs^=vs<<5;return((vs>>>0)%65536)/65536;};
const K_BITB=[rgba('#1c2fd6'),rgba('#7c88ee')],K_BITR=[rgba('#cf2118'),rgba('#ee8f89')],K_BNC=rgba('#ff8c00');
function vAdd(x,y,dx,dy,life,col,kind){if(vpN>=VPMAX){VFX.dropped++;return;}const k=vpN++;vX[k]=x;vY[k]=y;vVX[k]=dx;vVY[k]=dy;vLife[k]=life;vTot[k]=life;vCol[k]=col;vKind[k]=kind;}
// a destroyed pixel: 4 bits fly apart and fade (1x1 device pixels)
function sparkAt(i){if(!VFX.on||vBud<=0)return;vBud--;const cols=i<POOL?K_BITB:K_BITR;VFX.sparkBursts++;const a0=vr()*6.2832;
  for(let k=0;k<4;k++){const a=a0+k*1.5708+(vr()-.5)*0.7,sp=9+vr()*16;vAdd(px[i],py[i],Math.cos(a)*sp,Math.sin(a)*sp,34+((vr()*26)|0),cols[k&1],0);VFX.bits++;}}
// a ricochet: the pixel glows for ~0.5 s and drops fading trail bits where it has been, so the bounce shows as a visible V
function bounceMark(i){if(!VFX.on)return;VFX.bounces++;if(pbnc[i]===0&&bN<400)bList[bN++]=i;pbnc[i]=32;}
function vfxStep(){vBud=VBUD;
  for(let k=0;k<bN;k++){const i=bList[k];if(pbnc[i]>0){pbnc[i]--;if(pst[i]&&(pbnc[i]&3)===0&&vpN<VPMAX-8){vAdd(px[i],py[i],0,0,26,(i<POOL?K_BITB:K_BITR)[1],1);VFX.trails++;}}
    if(pbnc[i]===0||!pst[i]){pbnc[i]=0;bList[k]=bList[--bN];k--;}}
  for(let k=0;k<vpN;k++){if(--vLife[k]===0){const l=--vpN;vX[k]=vX[l];vY[k]=vY[l];vVX[k]=vVX[l];vVY[k]=vVY[l];vLife[k]=vLife[l];vTot[k]=vTot[l];vCol[k]=vCol[l];vKind[k]=vKind[l];k--;continue;}
    vX[k]+=vVX[k]*STEP;vY[k]+=vVY[k]*STEP;if(vKind[k]===0){vVX[k]*=0.97;vVY[k]*=0.97;}}}
// ---------- COLLISION
""")
e.ed("function hurt(i,dmg,ks,kj){php[i]-=dmg;if(php[i]<=0){","function hurt(i,dmg,ks,kj){php[i]-=dmg;if(php[i]<=0){sparkAt(i);")
e.ed("if(bI&&pst[i]){s0.stats.ricochets++;s0.stats.defl++;deflect(i,nx,ny,rotv,false);","if(bI&&pst[i]){bounceMark(i);s0.stats.ricochets++;s0.stats.defl++;deflect(i,nx,ny,rotv,false);")
e.ed("if(bJ&&pst[j]){s1.stats.ricochets++;s1.stats.defl++;deflect(j,-nx,-ny,rotv,false);","if(bJ&&pst[j]){bounceMark(j);s1.stats.ricochets++;s1.stats.defl++;deflect(j,-nx,-ny,rotv,false);")
e.ed("  movePixels();collide();for(const sd of S.sides)if(!sd.human)aiShapes(sd.id);","  movePixels();collide();vfxStep();for(const sd of S.sides)if(!sd.human)aiShapes(sd.id);")
# release resets
e.ed("pcnt[i]=Math.min(90,","pbnc[i]=0;pcnt[i]=Math.min(90,")
# render: bits under the dots, bouncing pixels glow
e.ed("const anyPx=S.sides[0].active+S.sides[1].active>0;","const anyPx=S.sides[0].active+S.sides[1].active+vpN>0;")
e.ed("    const hh=CFG.pixHP*0.5;\n","""    const hh=CFG.pixHP*0.5;
    for(let k=0;k<vpN;k++){const x=(vX[k]*sc)|0,y=(vY[k]*sc)|0;if(x<0||y<0||x>fw-2||y>fh-2)continue;const a=vKind[k]===0?Math.min(255,Math.round(255*vLife[k]/vTot[k]*1.25)):Math.round(200*vLife[k]/vTot[k]);P32[y*fw+x]=((a<<24)|(vCol[k]&0xffffff))>>>0;}
""")
e.ed("const col=(CFG.tint&&pst[i]>=4)?(sidx?K_SQR:K_SQB):cols[php[i]>hh?0:1],big=false,","const col=pbnc[i]>0?K_BNC:(CFG.tint&&pst[i]>=4)?(sidx?K_SQR:K_SQB):cols[php[i]>hh?0:1],big=false,")
e.ed("get stat(){return stat;},","get stat(){return stat;},VFX,vfxStep,pbnc,get vpN(){return vpN;},VPMAX,vAdd,vX,vY,vLife,vKind,")
e.save()
