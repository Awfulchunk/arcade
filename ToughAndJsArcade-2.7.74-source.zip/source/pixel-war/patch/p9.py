import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
e.ed("function showSide(sd){","""// SOFT FEATHER: the yellow hitbox bands and areas are blurred ONCE when their sprite is built (ctx.filter), never per frame. Fallback without ctx.filter: layered offset copies.
let FEATHER=false;try{const c=document.createElement('canvas');c.width=c.height=9;const x=c.getContext('2d');if('filter' in x){x.filter='blur(2px)';x.fillStyle='#000';x.fillRect(4,4,1,1);x.filter='none';FEATHER=x.getImageData(2,4,1,1).data[3]>0;}}catch(e){FEATHER=false;}
function softCopy(src,w,h,blur,forceFallback){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');
  if(FEATHER&&!forceFallback){x.filter='blur('+blur+'px)';x.drawImage(src,0,0);x.filter='none';}
  else{x.globalAlpha=0.25;x.drawImage(src,0,0);for(const rr of[[0.6,0.08],[1.2,0.05]])for(let a=0;a<8;a++){x.globalAlpha=rr[1];x.drawImage(src,Math.cos(a*0.7854)*blur*rr[0],Math.sin(a*0.7854)*blur*rr[0]);}}
  return c;}
const RS=2,APAD=7,YEL='rgb(255,206,64)';
// an area's sprite (u along x, front at the right edge; v along y), built once per areaDef
function areaSprite(D){if(D.spr)return D.spr;const w=Math.ceil((D.Lu+2*APAD)*RS),h=Math.ceil((2*D.rad+2*APAD)*RS),t=document.createElement('canvas');t.width=w;t.height=h;const x=t.getContext('2d');x.fillStyle=YEL;
  for(let iv=0;iv<MY;iv++)for(let iu=0;iu<MX;iu++)if(D.mask[iv*MX+iu]){const u=-(iu+1)*D.cu,v=iv*D.cv-D.rad;x.fillRect((u+D.Lu+APAD)*RS-0.5,(v+D.rad+APAD)*RS-0.5,D.cu*RS+1,D.cv*RS+1);}
  D.spr=softCopy(t,w,h,2.6*RS/2,!!window.__pwNoFilter);return D.spr;}
// the lane bands of every visible path: ONE half-resolution layer rebuilt only when a path, lane type or setting changes
let LANEL=null,LANEK='';
function laneLayer(){let key=S.phase+'|'+ME+'|'+(CFG.reveal?1:0)+'|'+(window.__pwNoFilter?1:0);const items=[];
  for(const sd of S.sides){if(!showSide(sd))continue;const hw=laneHW(sd.set);for(const P of sd.paths){if(!P||P.p.length<4)continue;key+='|'+sd.id+P.id+':'+(P.p.length>>1)+','+P.lane+','+hw.toFixed(1);items.push([sd,P,hw]);}}
  if(key===LANEK&&LANEL)return LANEL;LANEK=key;const w=W>>1,h=H>>1,t=document.createElement('canvas');t.width=w;t.height=h;const x=t.getContext('2d');x.scale(0.5,0.5);
  for(const it of items){const sd=it[0],P=it[1];x.fillStyle=sd.id!==ME&&sd.id?'rgb(255,170,100)':(P.id?'rgb(150,190,255)':YEL);x.fill(lanePoly(P,it[2]));}
  LANEL=softCopy(t,w,h,2,!!window.__pwNoFilter);return LANEL;}
function showSide(sd){""")
a=e.t.index("  // LANE SHAPES: the hitbox area the pixels occupy, a subtle transparent overlay")
b=e.t.index("  // walls\n  ctx.lineWidth=Math.max(2,WALL_HALF*2*sc)")
e.t=e.t[:a]+"""  // the yellow HITBOX: lane bands (one soft half-res layer) and the shape areas (soft sprites riding the path), both BEHIND the dots
  if(CFG.halo){ctx.imageSmoothingEnabled=true;ctx.globalAlpha=0.5;ctx.drawImage(laneLayer(),fx,fy,fw,fh);
    ctx.globalAlpha=0.5;for(const sd of S.sides){if(!showSide(sd))continue;for(let qi=0;qi<MAXSQ;qi++){const q=sd.sq[qi];if(!q)continue;const D=q.def,spr=areaSprite(D);ctx.save();ctx.translate(X(q.cx),Y(q.cy));ctx.rotate(Math.atan2(q.ty,q.tx)+(D.rot?q.ra:0)*0);
      if(D.rot){ctx.translate(D.rc*sc,0);ctx.rotate(q.ra);ctx.translate(-D.rc*sc,0);}
      ctx.scale(sc/RS,sc/RS);ctx.drawImage(spr,-(D.Lu+APAD)*RS,-(D.rad+APAD)*RS);ctx.restore();}}
    ctx.globalAlpha=1;ctx.imageSmoothingEnabled=false;}
"""+e.t[b:]
e.ed("ctx.drawImage(PL,fx,fy);\n  hud();","ctx.drawImage(PL,fx,fy);\n  hud();")
e.save()
