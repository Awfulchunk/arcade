import sys
sys.path.insert(0,'/workspace/game/build-pixelwar042/patch')
from lib import E
e=E()
e.ed("pdec[i]=0;psh[i]=0;pmom[i]=0;psq[i]=-1;\n","pdec[i]=0;psh[i]=0;pmom[i]=0;psq[i]=-1;pfade[i]=0;\n")
# helper + per-tick fade countdown
e.ed("function movePixels(){","const FADE_T=()=>clamp(Math.round(CFG.fadeSec*60),1,250);\nfunction strayStart(i,sd){if(pfade[i]===0){pfade[i]=FADE_T();sd.stats.strayed=(sd.stats.strayed||0)+1;}if(psq[i]>=0)unlink(i,sd);pst[i]=3;pend[i]=0;}\nfunction movePixels(){")
e.ed("      pox[i]=px[i];poy[i]=py[i];\n","      pox[i]=px[i];poy[i]=py[i];\n      if(pfade[i]>0&&--pfade[i]===0){recall(i);continue;}\n")
e.ed("        else if(bd>L2){recall(i);continue;}","        else if(bd>L2){strayStart(i,sd);}")
e.ed("if(sdi>CFG.leash&&(cur===5||pcnt[i]===0)){sd.stats.koRecall++;recall(i);continue;}}","if(sdi>CFG.leash&&(cur===5||pcnt[i]===0)){sd.stats.koRecall++;strayStart(i,sd);cur=3;}}")
e.ed("        if(dx*dx+dy*dy>L2){recall(i);continue;}\n      }","        if(dx*dx+dy*dy>L2&&pfade[i]===0)pfade[i]=FADE_T();\n      }")
# collisions: a fading pixel only takes part with a chance that drops as it fades
e.ed("for(let i=0;i<CAPMAX;i++){if(!pst[i]||pcd[i]>0)continue;","for(let i=0;i<CAPMAX;i++){if(!pst[i]||pcd[i]>0)continue;if(pfade[i]>0&&rnd()*FT>pfade[i])continue;")
e.ed("for(let j=gHead[gy*GW+gx];j>=0;j=gNext[j]){if(!pst[j]||pcd[j]>0)continue;","for(let j=gHead[gy*GW+gx];j>=0;j=gNext[j]){if(!pst[j]||pcd[j]>0)continue;if(pfade[j]>0&&rnd()*FT>pfade[j])continue;")
e.ed("const pHP=CFG.pixDmg,","const FT=FADE_T(),pHP=CFG.pixDmg,")
# render: fading pixels draw with falling alpha
e.ed("big=false,x=(px[i]*sc-1)|0,y=(py[i]*sc-1)|0;","big=false,x=(px[i]*sc-1)|0,y=(py[i]*sc-1)|0,cf=pfade[i]>0?(((40+215*pfade[i]/FADE_T())<<24)|(col&0xffffff))>>>0:col;")
e.ed("let o=y*fw+x;P32[o]=col;P32[o+1]=col;o+=fw;P32[o]=col;P32[o+1]=col;","let o=y*fw+x;P32[o]=cf;P32[o+1]=cf;o+=fw;P32[o]=cf;P32[o+1]=cf;")
e.ed("get stat(){return stat;},","get stat(){return stat;},pfade,FADE_T,")
e.ed("['leash','Leash distance','the \"2 inches\": past this from the path, or from a shape area edge, a pixel goes home','r',30,140,6]","['leash','Leash distance','how far a pixel may stray from its path (1.5x the old distance); past it the pixel fades out, then goes home','r',30,220,6],['fadeSec','Fade-out time (s)','a pixel past the leash fades for this long; it can still be hit while it fades, with less chance as it fades','r',0.2,4,0.2]")
e.save()
