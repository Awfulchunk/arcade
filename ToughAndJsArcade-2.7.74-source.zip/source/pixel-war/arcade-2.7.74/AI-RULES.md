# Pixel War 0.4.14 — Pixie's rule book (Jay t1196, updated for t1199 / t1200 / t1204 / t1207 / t1208)

The AI code follows this file. Each rule names the function that does it.

## Pixie's book (0.4.14, Jay t1207 / t1208)

The AI is called **Pixie**. She is not taught or trained. She is **given a list** (`PIXIE_BOOK` in the game code): the rules, how things physically work, and for each mechanic how to **use** it and how to **counter** it. Every time she thinks (once a second), she:

1. **looks** at what is on screen (`pixieSee`): every one of her paths and every one of yours, with pixel size, lane width, flow and pace; where her lanes and yours meet, whether the meeting is head-on, and whether there are live pixels there; which of your streams head for her circle; her HP, your HP, the time left; the branch slots she has free;
2. **reads every entry** of the list and checks its *when* against that picture;
3. **does** the entry's *use* when it matches, through the same actions you have (`pixieAct`): move a path slider, open a guard branch, open a branch, draw a branch further. There is **no wall action** in that list, so nothing in the book can build, move or erase a wall mid-match.

Small safety rules: one entry acts on the same path / stream at most once every 4 s; if the older AI code moves a slider the book just set, the book backs off for 15 s (it never fights it). Everything written in the sections below this one still runs exactly as before; the book is a layer on top. The book is code, not memory: DELETE AI MEMORY does not remove it, and nothing in it is saved.

| id | topic | rule | how it works (physics) | when Pixie acts | what she does (use) | counter |
|---|---|---|---|---|---|---|
| `objective` | Objective / win condition | Take the enemy circle to 0 HP first; at the 5-minute timer the side with more HP wins. Defending is half the job. | HP = pixels left in the pool; a pixel that reaches a circle burns it by its mass (size 10: 1.25, size 1: 0.83), so the same flow does the same total damage at any size. | Last minute and she is behind on HP (once a match). | Main flow +150 (max 1000) and pace +1 (max 9). | When ahead late: guard what lands (`guard_main`). |
| `guard_branch` | Branches heading for her circle | Branches are drawn only in the match, from the main path, 400 meter each, erasing is free, 3 slots; keep one spare until a guard is up. | Pixels follow their lane and roam on past its end, so a lane that reaches or points at her circle lands. | One of your branches heads for her circle and is not guarded (max 2 guards). | Frees a slot if needed and opens a guard: head-on, running back up your lane. | Never leave it unblocked: lane +2, flow at least yours +80. |
| `guard_main` | Your main landing | Your main always aims at her circle; her own main pressure is the first answer. | Once it lands, every second unguarded costs HP. | She is behind on HP (or it is the last minute) and your main has landed 5+ hits unguarded. | Opens a guard on your main. | Guard it as soon as it lands instead of waiting for 15 hits. |
| `size_swarm` | Pixel size (DENSITY slider) vs a small swarm | Size 1 tiny to 10 huge, per path, 0.1 steps; size 5 is the standard pixel. | Big (10): HP 2.5, damage 1.25, hit radius 4.0, but 0.8x pixels per flow and they stay 2.5 in from the lane edges. Small (1): HP 1.6, damage 0.82, hit radius 3.1, 1.2x pixels per flow, 3% harder to hit. Head-on: 10 v 1 takes about 70% of the kills, 8 v 3 about 62%, 6 v 4 about 55%. | A small stream (3.5 or less) meets her main / guard / intercept / punch / detour head-on and hers is not at least 3 sizes bigger. Not for a guard against a wide (7+) stream. | Main: the main counter size (7 vs small); a branch: your size +5 (7 to 9). | Big punches straight through; meet a small swarm head-on with big. A guard vs a wide stream keeps coverage sizes 4 to 6. |
| `size_big` | Pixel size vs big pixels | Same slider; big wins straight fights, but it costs coverage. | Big pixels are fewer per flow and stay off the lane edges, so a stream that goes around them or comes in from the side is not fighting their strength. | Your big stream (7+) is beating one of her attack paths head-on and she has a free slot. | Stops trading head-on and opens a flank branch with small pixels (size 3) that goes around (at most once per 10 s per stream). | Against big: do not trade head-on; flank with small / wide or out-angle from the side. |
| `width_catch` | Lane width | LANE WIDTH 1 to 10 in 0.1 steps; 10 = the circle diameter, the max. The lane is a road: direction only, pixels wander inside it, never pulled to the centerline. | Narrow compacts the same pixels into a thin stream; wide spreads them to cover. A stream only fights what its lane overlaps, so the outer pixels of a wider lane slip past a narrower one. | Her intercept / block / detour lane (or a guard, against the stream it guards) meets yours and is narrower than yours +1 (guard +2). | Sets it to your width +1 (guard +2), never past 10. Her main already does this in the older code. | Match or exceed your width to catch the outer pixels; thin lanes (2) only for punching. |
| `flow` | Flow | FLOW 200 to 1000 = pixels of that path on the field at once; each branch has its own; a side has at most 1000 out. | More flow = more pixels in the fight; flow is a budget, flow given to one path is taken from another. | Your stream outnumbers her guard / intercept head-on by more than 60. | Feeds it your flow +80 (max 1000). | Feed a head-on stream at least yours +80; starve paths that land nothing; surge when your flow is split (older code). |
| `pace` | Pace | PACE 1 to 10 = how fast pixels move. | Faster pixels arrive sooner, so more arrive per second for the same count on the field; pace does not change HP or damage. | Her guard / intercept is slower than the stream it meets. | Matches your pace. | Do not let a guard be outrun. |
| `path_end` | Past a path end | Past the end of its path a stream keeps going one way as a loose group, then fades. | Roaming pixels are not steered, so a lane that stops short of the circle wastes most of them. | One of her punch / flank branches stops more than a lane short of your circle and has meter left. | Draws it on toward your circle (same meter). | End every attack lane ON the circle. |
| `spacing` | Spacing | There is no separate spacing control: it was merged into the old density in 0.4.6, and old density is off for both sides. | Only lane width and flow change how tightly a stream packs. | never | nothing | nothing |
| `ricochet` | Contacts and ricochet | When enemy pixels touch they bounce or die; a ricochet is random and short; a bounced pixel keeps flying straight. | Nobody can aim a bounce. | never | nothing | Never count on bounced pixels; win contacts with size, width and flow. |
| `merge` | Detour merge / loop-connect | A branch end drawn back into its own lane (inside the hitbox or a finger from its edge, downstream or upstream) connects and its pixels rejoin; at most 2 loops per pixel. | A detour takes pixels around a fight and back onto the main past it. | (older code) | Detour round a losing clash and rejoin. | Against a detour player: meet the stream after its rejoin point. |
| `defense_line` | Defense line | Drawn in prep, locks at START; nobody builds, rebuilds or erases walls mid-match. The book has no wall action. | Enemy pixels damage only the cell they hit; a side's own pixels bounce off its own wall. | (older code, prep plan) | Keeps her own branches a lane width off her own line by choice (her pixels would bounce off it); routes through the weakest part or round an end. | Your line: round an end or through a gap; never retry a blocked build. |
| `clash` | Clash front | A clash is where both sides' pixels fight; your spawn zone is not a clash. | A clash that keeps losing burns pixels for nothing. | (older code) | Losing: cut flow (never under 400) and reroute. | Surge when your flow is split. |
| `fair` | Same rules | Same sliders, meters, caps, cooldowns and drawing as you; she reads only what is on screen; no hidden features (lane shapes, shapes, old density). | — | always | — | — |

Measured effect (0.4.14 test pass, book on vs off, same openings, 6 to 8 runs each; the game uses randomness in play, so close matchups vary run to run). The plain fair 17 / 23 / variant 19 runs and the small-swarm and big-9 players were won either way, with the same HP margins. The wide-9 player was won either way, but by a bigger margin with the book: 4429 HP vs 3130 in the final pass, and 3941 vs 916 earlier. The left-wrap big-pixel player (8.5 to 9) is close: 5 of 8 wins with the book vs 4 of 8 without in the final pass (7 of 8 vs 2 of 8 in an earlier sample).

## Drawing near a defense line (0.4.14, Jay t1209)

Drawing a branch is not blocked by any defense line any more, for you. Before 0.4.14 every step of a branch was refused inside a band around your own line as wide as your widest lane's half-width + 4 (up to 26 units at width 10), and the stroke froze there. Now you can draw right along your line on either side and near the enemy's line. If your finger goes straight across your own line, the tip slides along the line toward your finger and carries on as soon as your finger goes round an end. The line itself is never drawn through, and it still blocks pixels exactly as before (your own pixels bounce off it, enemy pixels damage its cells). Pixie keeps her old margin off her own line by her own choice, so her drawing is unchanged.

## Objective

1. **Win the match:** bring the enemy circle to 0 HP first. If the 5-minute timer runs out, the side with more circle HP wins (the existing win condition, `endMatch`).
2. **Protect my own circle.** Defending is half the objective, not an extra.

## How the game works (the AI plays by exactly these rules, same as the player)

- **Paths are roads.** A path or branch only gives direction. The lane (hitbox) is a road: pixels wander inside it and are never pulled to the centerline.
- **Lane width** is set with the LANE WIDTH slider (1–10, in 0.1 steps since 0.4.13). 10 = the circle diameter, the max. There is only one lane type (NORMAL); the lane-shape button is gone. The stream fills the whole lane (0.4.13: a pixel that reaches the lane edge turns its own drift around; before, over half of the pixels rode the two edges). Narrowing compacts at once; widening drifts out over about 1–1.5 s. A player branch follows the main width until the player gives that branch its own width. AI branches always set their own width.
- **All sliders are fine-grained** (0.4.13): pace, pixel size and lane width move in 0.1 steps, flow in 5s. The AI reads fractional values as they are (no rounding down) and may set fractional values itself.
- **Flow** is 200–1000 pixels on the field per path at once, as a steady stream. Every branch has its own flow. A side can have at most `cap` (1000) pixels out at once, so flow given to one path is flow taken from another.
- **Old density is gone** (t1199). Its effect is off for both sides (hidden; the code is kept). Nothing can bring it back: the setters force it to the neutral 5, and old saves and old AI memory (`tune.density`, `habits.density`) are dropped on load (`DENSITY_OFF`, `densOf`).
- **DENSITY slider = PIXEL SIZE** (t1200), 1 tiny to 10 huge, set per path like the other sliders. Size 5 is exactly the 0.4.11 pixel (HP 2, damage 1, the locked values).
  - **0.4.13 (t1204): big wins straight head-on fights; small wins by coverage.** Bigger pixels draw bigger, have a bigger hit radius (3.5 at size 5, up to 4.0 at 10), are tougher (HP 2.5 at size 10: half spawn with 3 HP) and hit harder (damage 1.25 at size 10: a quarter of hits do 2), and hit the circle and walls harder. Their cost is coverage: fewer come out for the same flow (0.8x at size 10) and they stay further in from the lane edges (up to 2.5 units at size 10), so fewer fit across a lane.
  - Smaller pixels are weaker (HP 1.6 at size 1, damage 0.82) and only slightly harder to hit (3% at size 1), but 1.2x as many come out for the same flow, so they swarm, cover the lane and fill more branches.
  - Flow is a pixel budget: the same flow does the same total circle damage at any size.
  - Measured in head-on duels (same flow 600, sides swapped, 3 seeds, widths 3 / 6 / 10): size 10 vs 1 takes about 70–72% of the kills, 8 vs 3 about 62%, 6 vs 4 about 55%, and the big side pushes the front forward. When the two lanes only half overlap, small pixels slip past and land a bit more on the circle (see FEATURES-0413.md).
- **Pace** is how fast the pixels move.
- **Contacts:** when enemy pixels touch they bounce or die. Ricochet is random and short; a bounced pixel keeps flying straight.
- **Past a path end** pixels keep going one way as a loose group, then fade.
- **Branches** are drawn only during the match, from the main path, each with its own meter (400). Erasing a branch is free.
- **Detour merge / loop-connect:** a branch drawn back into its own main lane (anywhere in the lane hitbox, or a finger from it, downstream or upstream) connects, and pixels rejoin. A pixel can loop at most 2 times.
- **Defense line:** drawn in prep, it locks at START. Nobody (player or AI) builds, rebuilds or erases walls during the match.
- **Shapes are off** (hidden). No shape or formation logic runs for either side.

## The AI SHOULD

1. **Block a branch heading for its circle.** When an enemy stream (a branch, or the main once it is really landing) is heading for the AI circle, the AI meets it **head-on** in front of its circle with a **guard branch** that runs back up the enemy lane (`aiThreats`, `aiOpenGuard`, `aiGuardStep`). It reacts within about 1–2 s of seeing a new enemy branch (the AI thinks once a second; `ai.react` adds 0.3–0.75 s, learned).
2. **Match the enemy lane width and catch the outer pixels.** A guard lane is the enemy lane width **+2**, up to 10, the circle diameter (`aiGuardW`). It re-matches whenever the player changes width by 0.5 or more (fine 0.1 nudges don't make it thrash). When the two main lanes meet, the AI main is never thinner than the enemy main +1 (`aiMainContest`).
3. **Keep one branch spare for defense** until a guard is up (`aiReserve`). If every branch slot is taken when a threat appears, it erases its weakest attack branch to free one (`aiFreeSlot`). Erasing is free.
4. **Feed a guard enough flow** to absorb the incoming stream: at least the enemy flow +80. It steps the guard's pixel size up (to at most 9) if the guard is losing contacts. Guards are never starved or dropped for having no circle hits. A guard is released only when its stream is gone or no longer threatens.
5. **Attack the enemy circle from the side.** The main path and attack branches finish on the enemy circle from the side, away from the lanes the enemy streams leave by, so the attack is not a 1:1 head-on trade (`aiApproach`).
6. **Route through the weakest part of the enemy defense**, or around an end (`aiDefenseRoute`). Off-center circles take the shortest outer wrap.
7. **Read the clash honestly.** A losing clash cuts flow (never below 400) and reroutes. The enemy's own spawn zone is not a clash, and a clash needs AI pixels there too (`aiPathClash`).
8. **Surge when the enemy's flow is split** across branches.
9. **Learn the player.** Every match it records what the player did (`aiObserve`) and merges it into its memory at the end (`aiHabitsCommit`): when they branch and how many branches, main width, **main pixel size**, **attack-branch pixel size**, pace and flow, attack-branch width, detours, loops, attack side, straight shots. Next match it counters (`aiCounterHabits`):
   - main pixel size against the player's usual main size (0.4.13): vs big (7+) it meets big with bigger (one size up, 8–10); vs small (3 or less) it goes big (7) and wins the contacts head-on; otherwise 6.
   - flow at least the player's usual +40;
   - faster reaction if the player branches a lot;
   - guards the main early against a straight shooter;
   - meets the stream closer to its circle against a detour player (after their rejoin point);
   - covers the usual attack-branch width.
10. **Start from what it already knows.** Every game recorded in our own test runs (0.4.10 fair 17 / 11 / 23, left-wrap variant 19, dummy 11) is built in as a prior worth 3 matches (`AISEED`). The player's real matches outweigh it fast.

11. **Pick pixel sizes by job** (`aiSizeFor`, switch `AIR.size`):
   - **punch** branch: 9: survives contacts on the way and hits the circle harder;
   - **intercept**: 8, to win the head-on contacts where it cuts your branch;
   - **guard**: a guard is a head-on fight, so one size bigger than the stream it meets (6–9). Its lane is already your width +2, which catches the outer pixels. Against a **wide** stream (width 7+) coverage matters more, so the guard goes one size smaller than yours (4–6) to get enough pixels across your lane (tested in 0.4.13: the head-on-bigger guard let 52–58% as many of a width-9 player's hits through as no guard at all; the coverage guard let 26% through);
   - **block** (wide lane): 4, for coverage;
   - **flank** (an attack branch that goes around): 3, coverage and slipping past, not trading head-on;
   - **main / detour**: the counter to your usual main size (above).
   - A guard that keeps losing contacts steps up one size (at most 9, at most once every 4 s). When the AI is behind, its main switches to the counter of your live main size.
   - After a loss, its remembered setup flips its main size against your usual size (one bigger, 8–10, vs big; 7 vs small).

## The AI SHOULDN'T

1. **Never leave its circle undefended** against an incoming stream it can see.
2. **Never waste pixels off-field.** That means no stub branches that stop short of the circle, no branch that just retraces its own main, and no branch fed into a zone it is losing for a long time (`aiBranchPointless`, drop rules).
3. **Never build, rebuild or erase walls mid-match** (locked defense line). It never retries a blocked build.
4. **Never cheat.** It uses the same API, meters, caps, cooldowns and sliders as the player, and it reads only what is on screen: lanes, pixels, hits, walls.
5. **Never use hidden features.** No lane shapes, no shapes and no old density, even from old saves or old AI memory (`LANE_SHAPES_ON` / `SHAPES_OFF` forced in `startWith`; `DENSITY_OFF`).
6. **Never pull pixels to the centerline, and never change ricochet, roam/fade or merge rules.** Those are engine rules, the same for both sides.
7. **Never wipe its memory on its own.** Only DELETE AI MEMORY in the menu clears it (that also clears the v412, v411, v410 and older keys). 0.4.14 saves to pixelwar.v414.aimem and loads v413 / v412 / v411 / v410 memory if there is no v414 one (DELETE AI MEMORY clears all of them). The built-in prior is part of the code and stays.

## Interpretation note

Jay wrote "such as not blocking a branch from attacking its circle". This is read as a **current failure the AI must fix** (it should block such a branch), not as something the AI is forbidden to do.
