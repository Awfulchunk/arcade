import sys,glob,os
from PIL import Image,ImageDraw
d=sys.argv[1];cols=int(sys.argv[2]);cw=int(sys.argv[3]);ch=int(sys.argv[4])
fs=sorted(f for f in glob.glob(d+'/*.png') if not f.endswith('contact.png'))
rows=(len(fs)+cols-1)//cols
sheet=Image.new('RGB',(cols*(cw+8)+8,rows*(ch+30)+8),(14,16,32))
dr=ImageDraw.Draw(sheet)
for i,f in enumerate(fs):
    im=Image.open(f).convert('RGB');im.thumbnail((cw,ch),Image.LANCZOS)
    x=8+(i%cols)*(cw+8);y=8+(i//cols)*(ch+30)
    sheet.paste(im,(x,y+18));dr.text((x,y+3),os.path.basename(f)[:-4],fill=(230,230,255))
sheet.save(d+'/contact.png');print(len(fs),sheet.size)
