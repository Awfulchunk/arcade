// Pixel War 0.4.13 width measurement (Jay t1204): stream spread vs LANE WIDTH at pixel sizes 1/5/10, plus live narrow/widen response.
// Two human sides (duel), side 0 main path straight up the field, side 1 path sideways (no contact). Lateral offset of side-0 lane pixels
// (state 2, along 60..200) from the straight line: p50 / p90 / max. Also reports laneHalf and the actual bound.
const {launch,open}=require('./lib.cjs');
const MEAS=function(a){const g=window.__pw;g.clearAiMem();g.startWith({duel:1});const S=g.S;S.sides[1].human=true;
  const A=S.sides[0].circle,C=S.sides[1].circle;const L=Math.min(300,Math.abs(A.y-C.y)-40);
  for(let i=1;i<=150;i++){g.pathExtend(0,A.x,A.y-L*i/150);}for(let i=1;i<=20;i++)g.pathExtend(1,C.x+i*1.5,C.y);
  g.setSetting(0,'width',a.w0);g.setSetting(0,'speed',6);g.setSetting(0,'release',a.f||600);g.setSetting(0,'size',a.z);g.setSetting(1,'release',200);
  g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;
  const samp=()=>{const o=[];for(let i=0;i<10000;i++){if(g.pst[i]!==2||g.pid[i]!==0)continue;const s=g.pps[i];if(s<60||s>200)continue;o.push(Math.abs(g.px[i]-A.x));}o.sort((x,y)=>x-y);
    const q=f=>o.length?+o[Math.min(o.length-1,Math.floor(f*o.length))].toFixed(2):-1;return {n:o.length,p50:q(0.5),p90:q(0.9),max:o.length?+o[o.length-1].toFixed(2):-1};};
  for(let i=0;i<a.warm;i++)g.tick();const out={ph:S.phase,act:S.sides[0].active,w0:a.w0,z:a.z,steady:samp(),half:+g.laneHalf(S.sides[0].set,0,0).toFixed(2)};
  if(a.w1!=null){g.setSetting(0,'width',a.w1);out.w1=a.w1;out.half1=+g.laneHalf(S.sides[0].set,0,0).toFixed(2);out.trace=[];for(let k=1;k<=a.steps;k++){for(let i=0;i<a.every;i++)g.tick();out.trace.push(samp().p90);}}
  return out;};
module.exports={MEAS};
if(require.main===module)(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
  const ws=(process.argv[2]||'1,2,3,4,5,6,7,8,9,10').split(',').map(Number),zs=(process.argv[3]||'1,5,10').split(',').map(Number);
  const rows=[];for(const z of zs)for(const w of ws){const r=await pg.evaluate(MEAS,{w0:w,z,warm:600});rows.push(r);console.log('W',JSON.stringify(r));}
  for(const z of zs){for(const [a,c] of [[1,10],[10,1]]){const r=await pg.evaluate(MEAS,{w0:a,w1:c,z,warm:600,steps:10,every:15});console.log('LIVE',JSON.stringify(r));}}
  if(pg._errs.length)console.log('ERRS',pg._errs.slice(0,5));await b.close();})();
