// 0.4.13: does SMALL still win by coverage? Two human sides, same flow/width/pace, mains that only half overlap (offset lanes) so pixels slip past each other.
// Reports circle hits (pool burned) each side made, and kill share. Sides swapped, 3 seeds.
const {launch,open}=require('./lib.cjs');
const FL=function(a){const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=a.seed/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;
  const S=g.S;S.sides[1].human=true;const A=S.sides[0].circle,C=S.sides[1].circle;
  for(let i=1;i<=150;i++){const t=i/150;g.pathExtend(0,A.x+a.off*Math.min(1,t*3)+(C.x-A.x)*t,A.y+(C.y-A.y)*t);g.pathExtend(1,C.x-a.off*Math.min(1,t*3)+(A.x-C.x)*t,C.y+(A.y-C.y)*t);}
  for(const sd of [0,1]){const y=sd?C.y+70:A.y-70;const w=g.wallBegin(sd,10,y);if(w){g.wallExtend(sd,w,60,y);g.wallEnd(sd,w);}g.setSetting(sd,'width',a.w);g.setSetting(sd,'speed',6);g.setSetting(sd,'release',a.f);g.setSetting(sd,'size',sd?a.s1:a.s0);}
  g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;for(let i=0;i<a.t&&!S.over;i++)g.tick();
  return {k:[S.sides[0].stats.kills,S.sides[1].stats.kills],burn:[10000-Math.round(S.sides[1].pool),10000-Math.round(S.sides[0].pool)],circ:[S.sides[0].stats.circleDmg,S.sides[1].stats.circleDmg]};};
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
  const off=+(process.argv[2]||16),w=+(process.argv[3]||8);
  for(const [sA,sB] of [[10,1],[8,3]]){let kA=0,kB=0,bA=0,bB=0;for(const seed of [5,9,13])for(const sw of [0,1]){const r=await pg.evaluate(FL,{seed,s0:sw?sB:sA,s1:sw?sA:sB,f:600,w,t:1800,off});const a=sw?1:0,c=1-a;kA+=r.k[a];kB+=r.k[c];bA+=r.burn[a];bB+=r.burn[c];}
    console.log('FLANK',JSON.stringify({sA,sB,off,w,killShareA:+(100*kA/(kA+kB)).toFixed(1),poolBurnedByA:bA,poolBurnedByB:bB}));}
  await b.close();})();
