// 0.4.13 root-cause repro: drive the REAL slider UI with touch on a 360x800@2 mobile page during a vs-AI match.
const {launch,open}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();g.startWith({});const S=g.S,me=S.sides[0],pc=me.circle,ac=S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150*0.8,pc.y+(ac.y-pc.y)*i/150*0.8);g.setSetting(0,'width',5);g.tryStart();S.phase==='prep'&&g.startBattle();});
 const st=async()=>pg.evaluate(()=>{const g=window.__pw,S=g.S,me=S.sides[0];return {phase:S.phase,selP:g.selP,w:me.set.width,ui:+document.getElementById('sWd').value,lab:document.getElementById('lWd').textContent,sz:me.set.size,sp:me.set.speed};});
 console.log('start',JSON.stringify(await st()));
 const box=async id=>{await pg.evaluate(id=>document.getElementById(id).scrollIntoView({block:'center'}),id);await new Promise(r=>setTimeout(r,150));const el=await pg.$('#'+id);return el.boundingBox();};
 // A: tap the right end of the LANE WIDTH track
 let bb=await box('sWd');console.log('bbox',JSON.stringify(bb));
 await pg.touchscreen.tap(bb.x+bb.width-4,bb.y+bb.height/2);await new Promise(r=>setTimeout(r,200));console.log('A tap right end',JSON.stringify(await st()));
 // B: horizontal drag from the right to the left
 const cdp=await pg.target().createCDPSession();
 const drag=async(x0,x1,y)=>{await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:x0,y}]});for(let k=1;k<=12;k++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x0+(x1-x0)*k/12,y}]});await new Promise(r=>setTimeout(r,16));}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await new Promise(r=>setTimeout(r,200));};
 bb=await box('sWd');await drag(bb.x+bb.width-4,bb.x+6,bb.y+bb.height/2);console.log('B drag to left',JSON.stringify(await st()));
 bb=await box('sWd');await drag(bb.x+6,bb.x+bb.width*0.75,bb.y+bb.height/2);console.log('B2 drag to 3/4',JSON.stringify(await st()));
 // C: + button
 const plus=await pg.$('button.pm[data-for="sWd"][data-d="1"]');const pb=await plus.boundingBox();await pg.touchscreen.tap(pb.x+pb.width/2,pb.y+pb.height/2);await new Promise(r=>setTimeout(r,200));console.log('C plus',JSON.stringify(await st()));
 // same for PACE (does a tap fail there too?)
 bb=await box('sSp');await pg.touchscreen.tap(bb.x+bb.width-4,bb.y+bb.height/2);await new Promise(r=>setTimeout(r,200));console.log('D pace tap right',JSON.stringify(await st()));
 console.log('errs',pg._errs.slice(0,5));await b.close();})();
