// win-rate sampler: N repeats per spec, book on vs off (the game uses Math.random in play, so single runs of close matchups are coin flips)
const {launch,open}=require('./lib.cjs');const {runFight}=require('./fairlib0414.cjs');
const N=+(process.env.N||6);const SP=JSON.parse(process.env.SPECS||'[{"kind":"variant","seed":19,"name":"variant-19-big","ps":8.5,"os":9}]');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 for(const sp of SP)for(const book of [0,1]){await pg.evaluate(b=>{window.__pw.AIR.book=b;},book);let w=0,hp=0;const f={};
  for(let i=0;i<N;i++){const r=await runFight(pg,sp,18000);if(r.winner===1)w++;hp+=r.aiHp-r.pHp;for(const tr of r.trace)if(tr.book)for(const k in tr.book)f[k]=Math.max(f[k]||0,tr.book[k]);}
  console.log(sp.name,'book',book,'AI wins',w+'/'+N,'avg HP margin',Math.round(hp/N),JSON.stringify(f));}
 await b.close();})();
