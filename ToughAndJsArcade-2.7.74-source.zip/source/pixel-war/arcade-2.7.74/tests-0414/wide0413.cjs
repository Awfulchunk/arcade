const {launch,open}=require('./lib.cjs');const {runFight,SPECS}=require('./fairlib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 const wide={on:[],off:[]};for(const mode of ['on','off'])for(const base of [SPECS[3],SPECS[4]]){await pg.evaluate(m=>Object.assign(window.__pw.AIR,m==='on'?{guard:1,mainW:1,side:1}:{guard:0,mainW:0,side:0}),mode);
   const r=await runFight(pg,Object.assign({},base,{pw:9,ow:9,name:base.name+'-wide-'+mode}),18000);const gz=[];for(const tr of r.trace)for(const x of tr.br)if(x.job==='guard')gz.push(x.z||x.size);wide[mode].push({name:base.name,winner:r.winner,ai:r.aiHits,p:r.pHits,t:r.tick});}
 const pOn=wide.on.reduce((a,r)=>a+r.p,0),pOff=wide.off.reduce((a,r)=>a+r.p,0);console.log(JSON.stringify(wide),'ratio',(pOn/pOff).toFixed(3));await b.close();})();
