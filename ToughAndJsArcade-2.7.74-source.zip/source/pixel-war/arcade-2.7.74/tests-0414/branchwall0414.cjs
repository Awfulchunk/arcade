// 0.4.14 t1209 regression: REAL touch draws of branches near / along / across defense lines (own + enemy), at lane width 10 (the widest old clearance).
// Usage: node tests/branchwall0414.cjs [html]   (pass the 0.4.13 file to see the old freeze)
const path=require('path');const pp=require('/workspace/game/build-needle/gui/node_modules/puppeteer-core');
const FILE='file://'+path.resolve(process.argv[2]||path.join(__dirname,'../index.html'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));let pass=0,fail=0;const ok=(c,m)=>{if(c)pass++;else fail++;console.log((c?'PASS ':'FAIL ')+m);};
(async()=>{const b=await pp.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--disable-gpu']});
 const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await pg.goto(FILE);await sleep(1200);const cdp=await pg.target().createCDPSession();
 const setup=await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();g.startWith({});const S=g.S,me=S.sides[0],pc=me.circle;
   for(let i=1;i<=120;i++)g.pathExtend(0,pc.x,pc.y-i*3);const yy=pc.y-90;let st=g.wallBegin(0,20,yy);if(st){g.wallExtend(0,st,pc.x-40,yy);g.wallEnd(0,st);}
   g.tryStart();if(S.phase==='prep')g.startBattle();g.setSetting(0,'width',10);
   const fs=S.sides[1].strokes.filter(s=>!s.gate).map(s=>({a:[s.pts[0],s.pts[1]],b:[s.pts[s.pts.length-2],s.pts[s.pts.length-1]]}));
   return{phase:S.phase,pc:[pc.x,pc.y],yy:yy,mine:me.strokes.length,clr:g.clrOf(me),foe:fs};});
 console.log('setup',JSON.stringify(setup));
 const L=async()=>pg.evaluate(()=>{const r=document.querySelector('canvas').getBoundingClientRect(),l=window.__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const el=await pg.$('#tBranch');await pg.evaluate(()=>document.getElementById('tBranch').scrollIntoView({block:'center'}));await sleep(100);const bb=await el.boundingBox();await pg.touchscreen.tap(bb.x+bb.width/2,bb.y+bb.height/2);await sleep(100);
 const clear=()=>pg.evaluate(()=>{const g=window.__pw,me=g.S.sides[0];for(let k=me.paths.length-1;k>0;k--)if(me.paths[k])g.removeBranch(me,k);me.brWaste=0;});
 async function draw(pts){await pg.evaluate(()=>window.scrollTo(0,0));await sleep(80);const l=await L();const sc=p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[sc(pts[0])]});await sleep(20);
   for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i],n=Math.max(4,Math.ceil(Math.hypot(c[0]-a[0],c[1]-a[1])/6));for(let k=1;k<=n;k++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[sc([a[0]+(c[0]-a[0])*k/n,a[1]+(c[1]-a[1])*k/n])]});await sleep(16);}}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(80);
   return pg.evaluate(()=>{const g=window.__pw,S=g.S,me=S.sides[0];let P=null;for(let k=me.paths.length-1;k>0;k--)if(me.paths[k]){P=me.paths[k];break;}if(!P)return{n:0,msg:S.msg};const p=P.p;
     let cross=false;for(let k=0;k+3<p.length;k+=2)if(g.crossesOwnWall(me,p[k],p[k+1],p[k+2],p[k+3]))cross=true;let minWall=1e9;for(const st of me.strokes)for(let k=0;k+3<st.pts.length;k+=2)for(let j=0;j<p.length;j+=2){const ax=st.pts[k],ay=st.pts[k+1],bx=st.pts[k+2],by=st.pts[k+3],ex=bx-ax,ey=by-ay,l2=ex*ex+ey*ey||1;let t=((p[j]-ax)*ex+(p[j+1]-ay)*ey)/l2;t=t<0?0:t>1?1:t;minWall=Math.min(minWall,Math.hypot(p[j]-ax-ex*t,p[j+1]-ay-ey*t));}
     return{id:P.id,n:p.length/2,end:[+p[p.length-2].toFixed(1),+p[p.length-1].toFixed(1)],cross:cross,minWall:+minWall.toFixed(1),pts:p.slice()};});}
 const [cx,cy]=setup.pc,yy=setup.yy;
 // 1 along, 6 above own line, at width 10
 let r=await draw([[cx,yy-6],[cx-40,yy-6],[cx-150,yy-6]]);ok(r.n>0&&r.end[0]<=cx-140&&!r.cross,'own line: branch runs along 6 above the line to x='+(cx-150)+' (end '+r.end+', n '+r.n+', closest '+r.minWall+')');await clear();
 // 2 along, 6 below
 r=await draw([[cx,yy+30],[cx-40,yy+6],[cx-150,yy+6]]);ok(r.n>0&&r.end[0]<=cx-140&&!r.cross,'own line: branch runs along 6 below the line (end '+r.end+', closest '+r.minWall+')');await clear();
 // 3 straight at the line and across it: tip stops ON its side at the line, never crosses; then finger goes round the left end and up -> branch follows
 r=await draw([[cx,yy+40],[80,yy+40],[80,yy-40]]);ok(r.n>0&&!r.cross&&r.end[1]>yy&&r.end[1]-yy<6,'own line: finger across the line -> tip rests at the line on its own side, not frozen early (end '+r.end+')');
 const r3=r;await clear();
 r=await draw([[cx,yy+40],[80,yy+40],[80,yy-30],[6,yy-30],[6,yy-60],[60,yy-80]]);ok(r.n>0&&!r.cross&&r.end[1]<yy-60,'own line: finger across, then round the end -> branch follows round the end (end '+r.end+')');await clear();
 // 4 enemy line: along it and across it
 if(setup.foe.length){const f=setup.foe[0],y=f.a[1];const tip=await pg.evaluate(()=>{const p=window.__pw.S.sides[0].paths[0].p;return[p[p.length-2],p[p.length-1]];});
   r=await draw([[tip[0],tip[1]+6],[f.a[0],y+6],[f.b[0],y+6]]);ok(r.n>0&&Math.abs(r.end[0]-f.b[0])<8&&Math.abs(r.end[1]-(y+6))<4,'enemy line: along it 6 below (end '+r.end+' target '+[f.b[0].toFixed(1),y+6]+')');await clear();
   r=await draw([[tip[0],tip[1]+6],[f.a[0]+10,y+20],[f.a[0]+10,y-40]]);ok(r.n>0&&r.end[1]<y-30,'enemy line: across it (end '+r.end+')');await clear();}
 else ok(false,'no enemy line to test');
 // 5 the line still blocks pixels: branch 3 above the own line for 5 s; track every pixel of that branch and count any that cross the line INSIDE its span
 r=await draw([[cx,yy-3],[cx-40,yy-3],[cx-150,yy-3]]);const bid=r.id;
 const leak=await pg.evaluate((bid,yy)=>new Promise(res=>{const g=window.__pw;const side={};let cross=0,seen=0,t=0;
   const iv=setInterval(()=>{for(let i=0;i<g.POOL;i++){if(!g.pst[i]||g.pid[i]!==bid){delete side[i];continue;}const x=g.px[i],y=g.py[i];if(x<26||x>134){delete side[i];continue;}
     const d=y-yy;if(Math.abs(d)<3)continue;const sg=d>0?1:-1;if(side[i]===undefined){side[i]=sg;seen++;}else if(side[i]!==sg){cross++;side[i]=sg;}}
     if(++t>=100){clearInterval(iv);res({cross,seen,wall:g.S.sides[0].segs.filter(s=>s.alive).length});}},50);}),bid,yy);
 ok(leak.seen>20&&leak.cross===0,'own line still blocks own pixels: '+leak.cross+' crossings among '+leak.seen+' branch pixels tracked over the line span for 5 s (walls alive '+leak.wall+')');await clear();
 // 6 Pixie keeps her own clearance by choice: an AI branch aimed along her own line stops short like before
 const ai=await pg.evaluate(()=>{const g=window.__pw,S=g.S,sd=S.sides[1];const st=sd.strokes.find(s=>!s.gate&&s.pts.length>=4);if(!st||!g.AIR)return null;const M=sd.paths[0],k=Math.min(10,(M.p.length>>1)-1);const P=g.branchBegin(1,M.p[k*2],M.p[k*2+1]);if(!P)return{nob:1};
   const y=st.pts[1],x0=st.pts[0],x1=st.pts[st.pts.length-2];g.branchExtend(1,P,(x0+x1)/2,y+(y<P.p[1]?4:-4));const q=P.p;let md=1e9;for(let k=0;k+3<st.pts.length;k+=2)md=Math.min(md,Math.hypot(q[q.length-2]-st.pts[k],q[q.length-1]-st.pts[k+1]));const res={clr:g.clrOf(sd),near:md};g.removeBranch(sd,P.id);return res;});
 if(ai&&!ai.nob)ok(ai.near>=ai.clr-4.5,'Pixie keeps her own margin off her own line (tip '+ai.near.toFixed(1)+' >= clr '+ai.clr.toFixed(1)+' - step)');else console.log('INFO AI clearance check skipped',JSON.stringify(ai));
 ok(errs.length===0,'0 JS errors '+errs.slice(0,3));
 console.log('RESULT pass',pass,'fail',fail);await b.close();process.exit(fail?1:0);})();
