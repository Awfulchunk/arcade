// Pixel War 0.4.12 size duels: two human sides (duel mode), straight head-on mains, same flow/width/pace, only PIXEL SIZE differs.
// Each pair runs on 3 seeds and with sides swapped (cancels any side bias). Reports kill share of size A, circle HP lost, pixels out.
const {launch,open}=require('./lib.cjs');
const DUEL=function(a){const g=window.__pw;if(a.tune){for(const k in a.tune)for(let q=0;q<10;q++)g[k][q]=a.tune[k][q];g.rebuildSZ&&g.rebuildSZ();}g.clearAiMem();const _r=Math.random;let u=a.seed/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;
  const S=g.S;S.sides[1].human=true;const A=S.sides[0].circle,C=S.sides[1].circle;for(let i=1;i<=150;i++){g.pathExtend(0,A.x+(C.x-A.x)*i/150,A.y+(C.y-A.y)*i/150);g.pathExtend(1,C.x+(A.x-C.x)*i/150,C.y+(A.y-C.y)*i/150);}
  for(const sd of [0,1]){const y=sd?C.y+70:A.y-70;const w=g.wallBegin(sd,10,y);if(w){g.wallExtend(sd,w,90,y);g.wallEnd(sd,w);}g.setSetting(sd,'width',a.w);g.setSetting(sd,'speed',6);g.setSetting(sd,'release',a.f);g.setSetting(sd,'size',sd?a.s1:a.s0);}
  g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;let mx=[0,0];for(let i=0;i<a.t;i++){if(S.over)break;g.tick();mx[0]=Math.max(mx[0],S.sides[0].active);mx[1]=Math.max(mx[1],S.sides[1].active);}
  const fy=sd=>{const L=sd.lossGrid,GY=12,GX=L.length/GY;let n=0,y=0;for(let r=0;r<GY;r++)for(let c=0;c<GX;c++){const v=L[r*GX+c];n+=v;y+=v*(r+0.5)/GY*500;}return n?y/n:250;};
  return {fy:(fy(S.sides[0])+fy(S.sides[1]))/2,k:[S.sides[0].stats.kills,S.sides[1].stats.kills],hp:[Math.round(S.sides[0].circle.hp),Math.round(S.sides[1].circle.hp)],out:mx,tick:S.tick,over:S.over,winner:S.winner};};
async function duelPair(pg,sA,sB,f,w,t,seeds,tune){let fyA=0,kA=0,kB=0,hA=0,hB=0,oA=0,oB=0,wins=[0,0],n=0;
  for(const seed of seeds)for(const swap of [0,1]){const r=await pg.evaluate(DUEL,{seed,s0:swap?sB:sA,s1:swap?sA:sB,f,w,t,tune});const a=swap?1:0,b=1-a;fyA+=swap?(r.fy):(500-r.fy);
    kA+=r.k[a];kB+=r.k[b];hA+=r.hp[a];hB+=r.hp[b];oA+=r.out[a];oB+=r.out[b];n++;if(r.over){if(r.winner===a)wins[0]++;else if(r.winner===b)wins[1]++;}}
  return {sA,sB,f,w,killShareA:+(100*kA/Math.max(1,kA+kB)).toFixed(1),kills:[kA,kB],hpLeft:[Math.round(hA/n),Math.round(hB/n)],outMax:[Math.round(oA/n),Math.round(oB/n)],ko:wins,frontA:+(fyA/n).toFixed(1)};}
module.exports={duelPair,DUEL};
if(require.main===module)(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
  const args=process.argv.slice(2);const pairs=JSON.parse(args[0]||'[[1,10],[5,5],[1,5],[5,10],[3,8]]');const f=+(args[1]||600),w=+(args[2]||6),t=+(args[3]||1800);const seeds=JSON.parse(args[4]||'[5,9,13]');
  for(const [a,c] of pairs){const r=await duelPair(pg,a,c,f,w,t,seeds,process.env.TUNE?JSON.parse(process.env.TUNE):undefined);console.log('DUEL',JSON.stringify(r));}
  if(pg._errs.length)console.log('ERRS',pg._errs.slice(0,5));await b.close();})();
