const {launch,open}=require('./lib.cjs');const fs=require('fs');fs.mkdirSync(__dirname+'/out0413',{recursive:true});
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 for(const z of [1,5,10]){
 await pg.evaluate(z=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;Math.random=()=>0.3;g.startWith({});Math.random=_r;const S=g.S,me=S.sides[0],pc=me.circle,ac=S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150*0.85,pc.y+(ac.y-pc.y)*i/150*0.85);g.setSetting(0,'width',1);g.setSetting(0,'size',z);g.setSetting(0,'release',700);g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=true;},z);
 const meas=()=>pg.evaluate(()=>{const g=window.__pw,S=g.S,me=S.sides[0],P=me.paths[0],p=P.p;const o=[];const by=[0,0,0,0,0,0];
   for(let i=0;i<10000;i++){if(!g.pst[i])continue;by[g.pst[i]]++;if(g.pst[i]!==2||g.pid[i]!==0)continue;
     let bd=1e9,bk=0;for(let k=0;k<p.length;k+=2){const d=Math.hypot(g.px[i]-p[k],g.py[i]-p[k+1]);if(d<bd){bd=d;bk=k;}}o.push(bd);}
   o.sort((a,c)=>a-c);const q=f=>o.length?+o[Math.floor(f*(o.length-1))].toFixed(1):-1;return {w:me.set.width,n:o.length,p50:q(.5),p90:q(.9),states:by,half:+g.laneHalf(me.set,0,0).toFixed(1)};});
 const run=n=>pg.evaluate(n=>{const g=window.__pw;for(let i=0;i<n;i++)g.tick();g.draw();},n);
 await run(500);console.log('z'+z,'w1',JSON.stringify(await meas()));await pg.screenshot({path:__dirname+`/out0413/repro-z${z}-w1.png`});
 await pg.evaluate(()=>window.__pw.setPathSetting(0,0,'width',10));await run(300);console.log('z'+z,'w10',JSON.stringify(await meas()));await pg.screenshot({path:__dirname+`/out0413/repro-z${z}-w10.png`});}
 console.log('errs',pg._errs.slice(0,5));await b.close();})();
