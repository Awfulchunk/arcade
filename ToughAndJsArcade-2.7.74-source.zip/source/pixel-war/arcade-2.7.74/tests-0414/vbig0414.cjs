const {launch,open}=require('./lib.cjs');const {runFight}=require('./fairlib0414.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 for(const book of (process.env.B?[+process.env.B]:[0,1])){await pg.evaluate(b=>{window.__pw.AIR.book=b;},book);
  for(const sp of [{kind:'variant',seed:19,name:'variant-19-big',ps:8.5,os:9}].concat(process.env.ONE?[]:[{kind:'fair',seed:17,name:'fair-17-big9',ps:9,os:9.5,ds:9},{kind:'fair',seed:11,name:'fair-11-big9',ps:9,os:9.5,ds:9},{kind:'fair',seed:23,name:'fair-23-big9',ps:9,os:9.5,ds:9}])){
  const r=await runFight(pg,sp,18000);const book2={};for(const tr of r.trace)if(tr.book)Object.assign(book2,tr.book);
  console.log('book',book,sp.name,r.winner===1?'AI':'player',(r.tick/60).toFixed(1),'aiHp',r.aiHp,'pHp',r.pHp,JSON.stringify(book2));
  if(process.env.V)for(const tr of r.trace)console.log('  t',tr.t,'pool',tr.pool,'mz',tr.mz,'mw',tr.mw,'mainK/L',tr.mk,tr.ml,'br',JSON.stringify(tr.br.map(x=>[x.id,x.job,x.w,x.z,x.k,x.l,x.circ])),'pb',JSON.stringify(tr.pb),JSON.stringify(tr.lessons));}}
 await b.close();})();
