const {launch,open}=require('./lib.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 for(const z of [1,5,10])for(const w of [3,10]){
 const r=await pg.evaluate((z,w)=>{const g=window.__pw;g.clearAiMem();const _r=Math.random;Math.random=()=>0.3;g.startWith({});Math.random=_r;const S=g.S,me=S.sides[0],pc=me.circle,ac=S.sides[1].circle;
   for(let i=1;i<=150;i++)g.pathExtend(0,pc.x+(ac.x-pc.x)*i/150*0.85,pc.y+(ac.y-pc.y)*i/150*0.85);g.setSetting(0,'width',w);g.setSetting(0,'size',z);g.setSetting(0,'release',700);g.tryStart();S.phase==='prep'&&g.startBattle();
   for(let i=0;i<700;i++)g.tick();const P=me.paths[0],p=P.p;const hist=new Array(10).fill(0);let L=0,R=0;const hw=g.laneHalf(me.set,0,0);const bys=[[0,0],[0,0],[0,0]];
   for(let i=0;i<10000;i++){if(g.pst[i]!==2||g.pid[i]!==0)continue;let bd=1e9,bk=0;for(let k=0;k<p.length-2;k+=2){const d=Math.hypot(g.px[i]-p[k],g.py[i]-p[k+1]);if(d<bd){bd=d;bk=k;}}
     const tx=p[bk+2]-p[bk],ty=p[bk+3]-p[bk+1],dd=Math.hypot(tx,ty)||1;const lat=(-(g.px[i]-p[bk])*ty+(g.py[i]-p[bk+1])*tx)/dd;if(lat<0)L++;else R++;
     const seg=Math.min(2,Math.floor(bk/2/((p.length/2)/3)));bys[seg][lat<0?0:1]++;
     hist[Math.max(0,Math.min(9,Math.floor((lat/hw+1)*5)))]++;}
   return {z,w,hw:+hw.toFixed(1),L,R,thirds:bys,hist};},z,w);console.log(JSON.stringify(r));}
 await b.close();})();
