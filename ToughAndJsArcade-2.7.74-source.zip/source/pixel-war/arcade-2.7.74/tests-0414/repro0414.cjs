// 0.4.14 t1209 repro: real touch draws of a BRANCH near the player's own defense line and near the AI's defense line.
const {launch,open}=require('./lib.cjs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await sleep(900);
 const cdp=await pg.target().createCDPSession();
 const setup=await pg.evaluate(()=>{const g=window.__pw;g.clearAiMem();g.startWith({});const S=g.S,me=S.sides[0],pc=me.circle,ac=S.sides[1].circle;
   g.setSetting(0,'width',6);
   for(let i=1;i<=120;i++)g.pathExtend(0,pc.x,pc.y-i*3);   // straight up the middle
   // own defense line: horizontal, left of the main, at y=pc.y-90
   const yy=pc.y-90;let st=g.wallBegin(0,20,yy);if(st){g.wallExtend(0,st,pc.x-40,yy);g.wallEnd(0,st);}
   g.tryStart();if(S.phase==='prep')g.startBattle();
   const foe=S.sides[1];return {phase:S.phase,pc:[pc.x,pc.y],ac:[ac.x,ac.y],myLine:me.strokes.map(s=>[s.pts[0],s.pts[1],s.pts[s.pts.length-2],s.pts[s.pts.length-1]]),foeLine:foe.strokes.map(s=>s.pts.filter((v,i)=>i%10<2)),clr:g.clrOf(me),mainLen:me.paths[0].p.length/2};});
 console.log('setup',JSON.stringify(setup));
 const L=async()=>pg.evaluate(()=>{const r=document.querySelector('canvas').getBoundingClientRect(),l=window.__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const tap=async id=>{const el=await pg.$('#'+id);await pg.evaluate(id=>document.getElementById(id).scrollIntoView({block:'center'}),id);await sleep(100);const bb=await el.boundingBox();await pg.touchscreen.tap(bb.x+bb.width/2,bb.y+bb.height/2);await sleep(100);};
 async function draw(pts){await pg.evaluate(()=>window.scrollTo(0,0));await sleep(100);const l=await L();const sc=p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[sc(pts[0])]});await sleep(20);
   for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i];for(let k=1;k<=8;k++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[sc([a[0]+(c[0]-a[0])*k/8,a[1]+(c[1]-a[1])*k/8])]});await sleep(16);}}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(80);
   return pg.evaluate(()=>{const S=window.__pw.S,me=S.sides[0];let last=null;for(let k=me.paths.length-1;k>0;k--)if(me.paths[k]){last=me.paths[k];break;}if(!last)return{n:0,msg:S.msg};const p=last.p;return{id:last.id,n:p.length/2,end:[+p[p.length-2].toFixed(1),+p[p.length-1].toFixed(1)],msg:S.msg};});}
 const results=[];const [cx,cy]=setup.pc;const yy=cy-90;
 await tap('tBranch');
 // A: own line, branch runs parallel to it, 12 units above it, heading left
 let r=await draw([[cx,yy-12],[cx-30,yy-12],[cx-150,yy-12]]);results.push(['A own: along line 12 above, to x='+(cx-150),r]);
 await pg.evaluate(()=>{const g=window.__pw,me=g.S.sides[0];for(let k=me.paths.length-1;k>0;k--)if(me.paths[k])g.removeBranch(me,k);});
 // B: own line, branch heads toward the line and then along just below
 r=await draw([[cx,yy+30],[cx-40,yy+14],[cx-150,yy+14]]);results.push(['B own: along line 14 below',r]);
 await pg.evaluate(()=>{const g=window.__pw,me=g.S.sides[0];for(let k=me.paths.length-1;k>0;k--)if(me.paths[k])g.removeBranch(me,k);});
 // C: own line, finger crosses the line (should slide/go around, not freeze)
 r=await draw([[cx,yy+30],[cx-60,yy-40],[cx-100,yy-100]]);results.push(['C own: finger crosses the line',r]);
 await pg.evaluate(()=>{const g=window.__pw,me=g.S.sides[0];for(let k=me.paths.length-1;k>0;k--)if(me.paths[k])g.removeBranch(me,k);});
 // D: near the ENEMY defense line: branch from the top of the main, run along the foe line
 const fl=await pg.evaluate(()=>{const s=window.__pw.S.sides[1].strokes[0];if(!s)return null;const q=s.pts;let mx=0,my=0;const n=q.length/2;for(let k=0;k<n;k++){mx+=q[k*2];my+=q[k*2+1];}return{mid:[mx/n,my/n],a:[q[0],q[1]],b:[q[q.length-2],q[q.length-1]]};});
 const tip=await pg.evaluate(()=>{const p=window.__pw.S.sides[0].paths[0].p;return[p[p.length-2],p[p.length-1]];});
 if(fl){r=await draw([[tip[0],tip[1]+8],[fl.a[0],fl.a[1]+10],[fl.b[0],fl.b[1]+10]]);results.push(['D foe: along foe line 10 below '+JSON.stringify(fl),r]);}
 for(const x of results)console.log(x[0],'->',JSON.stringify(x[1]));
 console.log('errs',pg._errs.slice(0,5));await b.close();})();
