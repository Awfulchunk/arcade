#!/bin/bash
# 0.4.14 single hard test pass (t1181 / t1201 / t1202): every suite once, on the final SHA, sequential (no CPU contention for the perf runs)
cd /workspace/game/build-pixelwar0414; L=tests/out0414/logs
sha256sum index.html > $L/sha.txt; date > $L/started.txt
node tests/checks0414.cjs > $L/checks.log 2>&1; echo "checks exit $?" >> $L/summary.txt
node tests/book0414.cjs > $L/book.log 2>&1; echo "book exit $?" >> $L/summary.txt
node tests/branchwall0414.cjs > $L/branchwall.log 2>&1; echo "branchwall exit $?" >> $L/summary.txt
node tests/branchwall0414.cjs ../requests/finished-ship/pixelwar-0.4.13-test/pixel-war-0.4.13.html > $L/branchwall-old0413.log 2>&1; echo "branchwall-on-0.4.13 exit $? (expected fail = repro)" >> $L/summary.txt
node tests/fair0414.cjs all > $L/fair.log 2>&1; echo "fair exit $?" >> $L/summary.txt
N=8 SPECS='[{"kind":"variant","seed":19,"name":"variant-19-big","ps":8.5,"os":9},{"kind":"fair","seed":23,"name":"f23-wide9","pw":9,"ow":9},{"kind":"fair","seed":17,"name":"f17-swarm2","ps":2,"os":1.5,"ds":2}]' node tests/rate0414.cjs > $L/rate.log 2>&1; echo "rate exit $?" >> $L/summary.txt
node tests/play0414.cjs > $L/play.log 2>&1; echo "play exit $?" >> $L/summary.txt
node tests/a03s0414.cjs > $L/a03s.log 2>&1; echo "a03s exit $?" >> $L/summary.txt
(cd /workspace/game/tough-tools && node tt.js test /workspace/game/build-pixelwar0414/index.html --all --name=pixelwar-0414-t1209) > $L/tt.log 2>&1; echo "tt exit $?" >> $L/summary.txt
date > $L/ended.txt; echo ALLDONE >> $L/summary.txt
