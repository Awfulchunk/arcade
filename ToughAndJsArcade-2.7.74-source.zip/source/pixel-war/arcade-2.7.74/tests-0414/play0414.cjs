// Pixel War 0.4.14 — Tough plays it (t1201/t1202/t1207/t1208/t1209). 0.4.14 adds: real touch branch draws along my own defense line and along Pixie's line mid-match, and Pixie's book firings per match.
// (0.4.13 header:) Three scripted matches vs the full-smart AI, memory carried across the series.
// Every feature is used: circle placement, defense line (locks at START), main path, pace, lane width, flow, the PIXEL SIZE slider (labelled DENSITY)
// at min / mid / max through the real +/- buttons and slider, branches (attack), a detour that merges back downstream, a loop-connect upstream,
// erasing a branch mid-match (free) and redrawing it. Hidden SPACING is poked to prove it does nothing. Screenshots in out/.
const {launch,open}=require('./lib.cjs');const fs=require('fs');const path=require('path');
const OUT=path.join(__dirname,'out0414');fs.mkdirSync(OUT,{recursive:true});
const PLANS=[
 {name:'M1 swarm',seed:31,mainSize:1.5,mainW:7.3,pace:6.2,flow:650,detourSize:5,attackSize:9.5,attackW:3,changes:[[600,'width',2.4],[900,'size',5.5],[1200,'width',9.6],[1500,'size',9.8],[1800,'width',4.1],[2100,'flow',820],[2400,'pace',8.3]]},
 {name:'M2 bruiser',seed:47,mainSize:9.6,mainW:4.2,pace:7.1,flow:700,detourSize:10,attackSize:1.2,attackW:6,changes:[[600,'width',8.7],[900,'size',5.2],[1200,'width',1.6],[1500,'size',1.3],[1800,'width',6.5],[2100,'flow',505],[2400,'pace',5.4]]},
 {name:'M3 mixed',seed:59,mainSize:5.4,mainW:6.1,pace:6.8,flow:600,detourSize:2.3,attackSize:8.8,attackW:3.4,changes:[[600,'width',9.9],[900,'size',8.6],[1200,'width',3.2],[1500,'size',2.7],[1800,'width',7.7],[2100,'flow',905],[2400,'pace',6.3]]}];
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,900));
 await pg.evaluate(()=>window.__pw.clearAiMem());const log=[];
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));let cdp=null;const clamp0=(v,a,b)=>v<a?a:v>b?b:v;
 const SL={width:'sWd',size:'sDe',pace:'sSp',flow:'sRe'},KEYS={width:'width',size:'size',pace:'speed',flow:'release'};
 const cur=k=>pg.evaluate(k=>{const s=window.__pw.S.sides[0].set;return k==='size'?window.__pw.sizeOf(s):+s[k];},KEYS[k]);
 async function uiSet(kind,target){if(!cdp)cdp=await pg.target().createCDPSession();await pg.evaluate(()=>{window.__pw.selP=0;window.__pw.draw();});const id=SL[kind];
   await pg.evaluate(id=>document.getElementById(id).scrollIntoView({block:'center'}),id);await sleep(120);const el=await pg.$('#'+id),bb=await el.boundingBox();
   const mn=kind==='flow'?200:1,mx=kind==='flow'?1000:10,off=kind==='flow'?-20:(target>5?-0.4:0.4),fx=bb.x+bb.width*(clamp0(target+off,mn,mx)-mn)/(mx-mn);   // tap a little off target, then fine-tune with +/- (exercises both)
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:fx,y:bb.y+bb.height/2}]});await sleep(50);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(120);
   const afterTap=await cur(kind);let taps=0;const stp=kind==='flow'?5:0.1;
   for(let g=0;g<40;g++){const v=await cur(kind);const d=Math.round((target-v)/stp);if(d===0)break;const b=await pg.$(`button.pm[data-for="${id}"][data-d="${d>0?1:-1}"]`);await pg.evaluate(e=>e.scrollIntoView({block:'center'}),b);const pb=await b.boundingBox();await pg.touchscreen.tap(pb.x+pb.width/2,pb.y+pb.height/2);await sleep(60);taps++;}
   const fin=await cur(kind);const lab=await pg.evaluate(id=>{window.__pw.draw();return document.getElementById(id).parentElement.querySelector('.lab2').textContent.replace('\n',' ');},id);return {afterTap,taps,final:fin,label:lab,hit:Math.abs(fin-target)<1e-6};}
 const spread=()=>pg.evaluate(()=>{const g=window.__pw,S=g.S,P=S.sides[0].paths[0],p=P.p,n=p.length>>1,o=[];for(let i=0;i<g.POOL;i++){if(g.pst[i]!==2||g.pid[i]!==0)continue;const s=g.pps[i];if(s<40||s>(n-1)*4*0.7)continue;let bd=1e9;for(let k=0;k<n;k++){const d=Math.hypot(g.px[i]-p[k*2],g.py[i]-p[k*2+1]);if(d<bd)bd=d;}o.push(bd);}o.sort((a,b)=>a-b);
   return {n:o.length,p90:o.length?+o[Math.floor(o.length*0.9)].toFixed(1):-1,half:+g.laneHalf(S.sides[0].set,0,0).toFixed(1),w:S.sides[0].set.width,z:g.sizeOf(S.sides[0].set)};});

 const cdpT=await pg.target().createCDPSession();
 async function touchBranch(pts){await pg.evaluate(()=>window.scrollTo(0,0));await sleep(60);const el=await pg.$('#tBranch');await pg.evaluate(()=>document.getElementById('tBranch').scrollIntoView({block:'center'}));await sleep(60);const bb=await el.boundingBox();await pg.touchscreen.tap(bb.x+bb.width/2,bb.y+bb.height/2);await sleep(60);await pg.evaluate(()=>window.scrollTo(0,0));await sleep(60);
   const l=await pg.evaluate(()=>{const r=document.querySelector('canvas').getBoundingClientRect(),l=window.__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});const sc=p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s});const before=await pg.evaluate(()=>window.__pw.S.sides[0].paths.map(P=>P?P.id:-1).join());
   await cdpT.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[sc(pts[0])]});await sleep(20);
   for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i],n=Math.max(4,Math.ceil(Math.hypot(c[0]-a[0],c[1]-a[1])/6));for(let k=1;k<=n;k++){await cdpT.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[sc([a[0]+(c[0]-a[0])*k/n,a[1]+(c[1]-a[1])*k/n])]});await sleep(16);}}
   await cdpT.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(60);
   return pg.evaluate(t=>{const g=window.__pw,me=g.S.sides[0];let P=null;for(let k=me.paths.length-1;k>0;k--)if(me.paths[k]){P=me.paths[k];break;}const p=P?P.p:[];let cross=false;for(let k=0;k+3<p.length;k+=2)if(g.crossesOwnWall(me,p[k],p[k+1],p[k+2],p[k+3]))cross=true;return P?{id:P.id,n:p.length>>1,end:[Math.round(p[p.length-2]),Math.round(p[p.length-1])],target:t,cross}:{none:1,msg:g.S.msg};},pts[pts.length-1]);}
 for(let m=0;m<PLANS.length;m++){const P=PLANS[m];
  const pre=await pg.evaluate(P=>{const g=window.__pw;const _r=Math.random;let u=P.seed/4294967296;Math.random=()=>u;g.startWith({});Math.random=_r;const S=g.S,me=S.sides[0];
    // move my circle a little (prep), then the defense line with a gap for my own path
    g.placeCircle(0,P.seed%2?150:210,me.circle.y);const pc=me.circle,ac=S.sides[1].circle;
    const wy=pc.y-70;const gx=pc.x;const w1=g.wallBegin(0,10,wy);if(w1){g.wallExtend(0,w1,gx-30,wy);g.wallEnd(0,w1);}const w2=g.wallBegin(0,gx+30,wy);if(w2){g.wallExtend(0,w2,350,wy);g.wallEnd(0,w2);}
    // main path: up through my gap, a gentle S toward the AI circle
    for(let i=1;i<=200;i++){const t=i/200,x=pc.x+(ac.x-pc.x)*t+(t>0.3?Math.sin((t-0.3)/0.7*Math.PI*2)*40:0),y=pc.y+(ac.y-pc.y)*t;g.pathExtend(0,x,y);}
    g.aiRevisePlan&&g.aiRevisePlan();
    // sliders for the main path through the real UI (selP 0): size via the slider, width / pace / flow via setPathSetting like the slider handlers
    g.selP=0;window.__tt.manual=true;const el=document.getElementById('sDe');el.value=P.mainSize;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
    g.setPathSetting(0,0,'width',P.mainW);g.setPathSetting(0,0,'speed',P.pace);g.setSetting(0,'release',P.flow);
    const spc=g.setSetting(0,'spacing',1);const pathN=me.paths[0].p.length>>1,need=g.prepNeeds?g.prepNeeds(me):[];const started=g.tryStart();S.paused=false;
    return {started,pathN,need,locked:!!me.defLocked,walls:me.strokes.length,mainSize:me.set.size,dens:me.set.density,spacingNoop:spc&&me.set.density===5,aiMainSize:S.sides[1].set.size,aiLessons:S.ai?S.ai.lessons.filter(l=>/remembered|pixel size/.test(l)).slice(-2):[]};},P);
  const ev=[];let t=0,shot=0;const aiSizes={};let bookF={};
  while(t<18000){
   for(const c of P.changes)if(c[0]===t){const pre=await spread();const res=await uiSet(c[1],c[2]);await pg.evaluate(()=>{const g=window.__pw;for(let i=0;i<90;i++)if(!g.S.over)g.tick();});const post=await spread();ev.push({t,ui:c,res,spreadBefore:pre,spreadAfter1_5s:post});}
   if(t===600||t===1500){const geo=await pg.evaluate(t=>{const g=window.__pw,S=g.S,me=S.sides[0],A=S.sides[1];if(S.over)return null;const M=me.paths[0],n=M.p.length>>1;
       if(brCount0(me)>=g.CFG.maxBr){for(let k=me.paths.length-1;k>0;k--)if(me.paths[k]&&me.paths[k].rj<0){g.removeBranch(me,k);break;}}
       function brCount0(sd){let c=0;for(let k=1;k<sd.paths.length;k++)if(sd.paths[k])c++;return c;}
       if(t===600){const st=me.strokes.find(s=>!s.gate);if(!st)return null;const y=st.pts[1],xa=st.pts[0],xb=st.pts[st.pts.length-2];let fk=-1;for(let k=4;k<n;k++)if(Math.abs(M.p[k*2+1]-(y-8))<3){fk=k;break;}if(fk<0)return null;const x0=M.p[fk*2],y0=M.p[fk*2+1],far=Math.abs(xa-x0)>Math.abs(xb-x0)?xa:xb;return{pts:[[x0,y0],[x0+(far-x0)*0.2,y-6],[far,y-6]],kind:'along MY line, 6 above it'};}
       const st=A.strokes.find(s=>!s.gate&&s.pts.length>=4);if(!st)return null;const y=st.pts[1];let fk=-1;for(let k=4;k<n;k++)if(M.p[k*2+1]<y+40){fk=k;break;}if(fk<0)return null;const x0=M.p[fk*2],y0=M.p[fk*2+1];return{pts:[[x0,y0],[st.pts[0],y+6],[st.pts[st.pts.length-2],y+6]],kind:'along PIXIE\'s line, 6 below it'};},t);
     if(geo){const res=await touchBranch(geo.pts);ev.push({t,touchBranch:geo.kind,res});}else ev.push({t,touchBranch:'skipped (no line / match over)'});}
   const r=await pg.evaluate((t,P)=>{const g=window.__pw,S=g.S,me=S.sides[0],A=S.sides[1],out={};const M=me.paths[0],n=M.p.length>>1;
     if(t===180){ // DETOUR: out to the side and back into my main further down (merge)
       const fk=Math.floor(n*0.3),rk=Math.floor(n*0.55),x0=M.p[fk*2],y0=M.p[fk*2+1],x1=M.p[rk*2],y1=M.p[rk*2+1],side=x0<180?1:-1;const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=40;i++){const s=i/40;g.branchExtend(0,B,x0+(x1-x0)*s+side*70*Math.sin(s*Math.PI),y0+(y1-y0)*s);}g.branchExtend(0,B,x1,y1);g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.detourSize);g.setPathSetting(0,B.id,'width',5);g.setPathSetting(0,B.id,'release',380);}out.detour=Q?{id:B.id,rj:Q.rj,loop:Q.loop,size:Q.set.size}:null;}}
     if(t===300){ // LOOP-CONNECT upstream: from late on the main, curl back into an earlier part of it
       const fk=Math.floor(n*0.62),rk=Math.floor(n*0.4),x0=M.p[fk*2],y0=M.p[fk*2+1],x1=M.p[rk*2],y1=M.p[rk*2+1],side=x0<180?1:-1;const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=40;i++){const s=i/40;g.branchExtend(0,B,x0+(x1-x0)*s+side*60*Math.sin(s*Math.PI),y0+(y1-y0)*s);}g.branchExtend(0,B,x1,y1);g.branchEnd(0,B);const Q=me.paths[B.id];out.loop=Q?{id:B.id,rj:Q.rj,loop:Q.loop}:null;if(Q)g.setPathSetting(0,B.id,'release',250);}}
     if(t===420){ // ATTACK branch hooking round to the AI circle
       const fk=Math.floor(n*0.5),x0=M.p[fk*2],y0=M.p[fk*2+1],ac=A.circle,vx=x0<180?Math.min(340,ac.x+90):Math.max(20,ac.x-90);const B=g.branchBegin(0,x0,y0);
       if(B){for(let i=1;i<=80;i++){const s=i/80;g.branchExtend(0,B,x0+(vx-x0)*s*(1-s)*2+(ac.x-x0)*s*s,y0+(ac.y-y0)*s);}g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.attackSize);g.setPathSetting(0,B.id,'width',P.attackW);g.setPathSetting(0,B.id,'release',520);g.setPathSetting(0,B.id,'speed',8);}out.attack=Q?{id:B.id,size:Q.set.size,n:Q.p.length>>1}:null;}}
     if(t===2400){ // ERASE my attack branch (free) and redraw it fresh
       let id=-1;for(let k=me.paths.length-1;k>=1;k--)if(me.paths[k]&&me.paths[k].rj<0){id=k;break;}if(id>0){g.removeBranch(me,id);out.erased=id;}
       const fk=Math.floor(n*0.45),x0=M.p[fk*2],y0=M.p[fk*2+1],ac=A.circle;const B=g.branchBegin(0,x0,y0);if(B){for(let i=1;i<=70;i++){const s=i/70;g.branchExtend(0,B,x0+(ac.x-x0)*s+(x0<180?60:-60)*Math.sin(s*Math.PI),y0+(ac.y-y0)*s);}g.branchEnd(0,B);const Q=me.paths[B.id];if(Q){g.setPathSetting(0,B.id,'size',P.attackSize);g.setPathSetting(0,B.id,'release',500);}out.redraw=Q?{id:B.id,size:Q.set.size}:null;}}
     for(let i=0;i<30;i++){if(S.over)break;g.tick();}
     const aiB=[];for(let k=0;k<A.paths.length;k++){const Q=A.paths[k];if(Q)aiB.push([k,Q.job||'main',k?Q.set.size:A.set.size,k?Q.set.width:A.set.width]);}
     const zc=new Array(101).fill(0);for(let i=0;i<g.POOL;i++)if(g.pst[i])zc[g.psz[i]]++;
     out.st={t:S.tick,over:S.over,w:S.winner,hp:[Math.round(me.circle.hp),Math.round(A.circle.hp)],aiB,mySizes:zc.map((v,i)=>v?(i/10)+':'+v:'').filter(Boolean).join(' '),walls:[me.strokes.length,A.strokes.length],lock:[!!me.defLocked,!!A.defLocked],lessons:S.ai?S.ai.lessons.slice(-2):[],book:S.ai&&S.ai.book?Object.assign({},S.ai.book.fired):null};return out;},t,P);
   if(r.st.book)bookF=r.st.book;
   for(const x of r.st.aiB)if(x[0]>0){const k=x[1]+':'+x[2];aiSizes[k]=(aiSizes[k]||0)+1;}
   if(r.detour||r.loop||r.attack||r.change||r.erased||r.redraw)ev.push(Object.assign({t},r.detour?{detour:r.detour}:{},r.loop?{loop:r.loop}:{},r.attack?{attack:r.attack}:{},r.change?{change:r.change}:{},r.erased?{erased:r.erased}:{},r.redraw?{redraw:r.redraw}:{},{mySizes:r.st.mySizes}));
   if((t===660||t===1260||t===2220)&&shot<3){shot++;const c=await pg.$('canvas');await c.screenshot({path:path.join(OUT,'m'+(m+1)+'-t'+t+'.png')});}
   t+=30;if(r.st.over){ev.push({t,end:r.st});break;}
   if(t%1800===0)ev.push({t,hp:r.st.hp,aiB:r.st.aiB,mySizes:r.st.mySizes,lessons:r.st.lessons});}
  const post=await pg.evaluate(()=>{const g=window.__pw,H=g.AIMEM.habits;return {mem:{matches:g.AIMEM.matches,wins:g.AIMEM.wins,losses:g.AIMEM.losses,tune:g.AIMEM.tune},hab:H?{n:H.n,size:H.size,offS:H.offS,width:+(+H.width).toFixed(2),flow:Math.round(H.flow),brN:H.brN,detour:H.detour,loop:H.loop}:null,winner:g.S.winner,tick:g.S.tick,
    stats:[0,1].map(s=>({kills:g.S.sides[s].stats.kills,hits:g.S.sides[s].stats.circleDmg})),summary:g.S.aiSummary?g.S.aiSummary.lessons.filter(l=>/size|guard|width|habit|book/.test(l)).slice(-6):[]};});
  log.push({match:P.name,pre,aiSizes,events:ev,post,book:bookF});const tb=ev.filter(e=>e.touchBranch);
  console.log('MATCH',P.name,JSON.stringify({pre,winner:post.winner===1?'AI':post.winner===0?'me':'draw',sec:+(post.tick/60).toFixed(1),stats:post.stats,mem:post.mem,hab:post.hab,aiSizes,book:bookF,touch:tb,lessons:post.summary}));}
 fs.writeFileSync(path.join(OUT,'play-log.json'),JSON.stringify(log,null,1));
 console.log('ERRS',JSON.stringify(pg._errs));await b.close();})().catch(e=>{console.error(e);process.exit(1);});
