# Pixel War 0.4.14 — progress

**Status: built and hard-tested once (t1181 / t1201 / t1202). NOT shipped, signed or published.** It is staged at `requests/finished-ship/pixelwar-0.4.14-test/`.

- Worktree: `/workspace/game/build-pixelwar0414/`, copied from 0.4.13 (SHA e5423438…376c). The 0.4.13 build and stage are untouched.
- Final SHA256: `d9a900327cda8b381f59b6593ed41b5c5ca9c19bdae9b50ea4ed48fb20e7ba73`.
- See FEATURES-0414.md for what changed and AI-RULES.md for Pixie's book.
- Single test pass on 2026-11-19, 08:55–09:20 America/Los_Angeles, on the final SHA. Script: `tests/pass0414.sh`. Logs: `tests/out0414/logs/`.

## Results
- **Build:** `node --check` is clean, and `esbuild --target=chrome83` is OK.
- **Own checks:**
  - `checks0414` (all 0.4.13 checks, relabelled 0.4.14 / v414): 58 / 0.
  - `book0414`: 21 / 0.
  - `branchwall0414` (real touch): 9 / 0. The same test on the 0.4.13 file fails the 4 own-line draws, which reproduces the bug.
- **Fair runs** (memory cleared each run): Pixie won dummy 11, fair 17, 11 and 23, and variant 19. There were 0 mid-match walls and 0 book errors. With the book switched off she also wins all of them.
- **Extra runs:**
  - She beat the swarm-2, big-9 and wide-9 players.
  - Against the left-wrap big-pixel player one run was a draw (both circles hit 0).
  - Win-rate samples (n=8): variant-19-big 5/8 with the book vs 4/8 without; wide-9 8/8 either way, HP margin 4429 vs 3130; swarm-2 8/8 either way.
- **Play session** (`play0414`): 3 matches, memory carried over, every feature used.
  - Pixie won all 3.
  - Each match included 2 real touch branch draws: one along my own line 6 units above it, one along Pixie's line. All 6 reached their target, and none crossed a line.
  - The book fired width_catch once and flow twice. 0 JS errors.
- **A03s perf** (`a03s0414`, double-draw harness, so it reads low):
  - x6, flow 1000: 39–46 fps (0.4.13: 39–44).
  - x6, flow 600: 45 fps (0.4.13: 43–45).
  - x4, flow 1000: 59.9 fps.
  - The harness's own 55 fps bar at x6 / flow 600 fails exactly as it did on 0.4.13.
  - One outlier: the size 10 v 10 run had a single 2.8 s draw stall (31.9 fps for that run; 0.4.13 got 43.7). The draw code did not change; this was not re-run.
- **tough-tools** `tt test --all --name=pixelwar-0414-t1209` (hooks): pass 67 / fail 0 / warn 3 / skip 4 / info 5. These are the same 3 warns as 0.4.11–0.4.13.
