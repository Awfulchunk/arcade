// WebView 83 emulator (Android 11, Chrome 83, software rendering), installs the FINAL 2.7.74 APK. Run ALONE and LAST.
const connect = require("/workspace/game/build-latch/fix/cdp.cjs"); const { execSync } = require("child_process"); const fs = require("fs");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const ADB = "/workspace/tools/sdk/platform-tools/adb";
const OUT = process.argv[2] || __dirname + "/out/emu"; fs.mkdirSync(OUT, { recursive: true });
const APK = process.argv[3] || "/workspace/game/build-ship2774/package-2.7.74/out/ToughAndJsArcade-2.7.74.apk";
const sh = (c) => execSync(`${ADB} ${c}`).toString(); const shot = (n) => execSync(`${ADB} exec-out screencap -p > ${OUT}/${n}.png`);
const R = []; const ok = (n, v, d) => { R.push({ n, pass: !!v, d }); console.log(v ? "PASS" : "FAIL", n, JSON.stringify(d === undefined ? "" : d).slice(0, 400)); };
async function startApp() {
  sh("shell am force-stop com.toughandj.arcade"); await sleep(1500); let pid = "";
  for (let a = 0; a < 3 && !pid; a++) { sh("shell am start -n com.toughandj.arcade/.MainActivity"); await sleep(20000); try { pid = sh("shell pidof com.toughandj.arcade").trim(); } catch (e) { pid = ""; } }
  execSync(`${ADB} forward --remove-all`); execSync(`${ADB} forward tcp:9333 localabstract:webview_devtools_remote_${pid}`);
  let c; for (let i = 0; i < 30; i++) { try { c = await connect(9333); if (await c.ev("typeof ARCADE==='object'")) break; c.close(); } catch (e) {} await sleep(2000); }
  await c.ev(`(()=>{ if(window.__inj) return 1; window.__inj=1; const d=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'srcdoc'); Object.defineProperty(HTMLIFrameElement.prototype,'srcdoc',{set(v){const inj="<script>window.__errs=[];addEventListener('error',function(e){__errs.push(String(e.message)+' @'+(e.lineno||''))},true);addEventListener('unhandledrejection',function(e){__errs.push('rej '+(e.reason&&e.reason.message||e.reason))});<\\/script>";d.set.call(this,v?inj+v:v)},get(){return d.get.call(this)}}); return 1})()`);
  return c;
}
async function frameOf(c, n0, main) { let cx; for (let i = 0; i < 25 && !cx; i++) { cx = c.ctx.slice(n0).filter((x) => x.auxData && x.auxData.isDefault && x.auxData.frameId !== main).pop(); if (!cx) await sleep(1000); } if (!cx) throw new Error("no game frame"); return cx; }
(async () => {
  const inst = sh(`install -r ${APK}`).trim();
  const path = sh("shell pm path com.toughandj.arcade").trim().replace(/^package:/, "");
  const devSha = sh(`shell sha256sum ${path}`).trim().split(/\s+/)[0]; const locSha = execSync(`sha256sum ${APK}`).toString().split(" ")[0];
  const ver = (sh("shell dumpsys package com.toughandj.arcade").match(/versionName=([\d.]+)/) || [])[1];
  ok("adb install -r: installed APK byte-identical and versionName 2.7.74", /Success/.test(inst) && devSha === locSha && ver === "2.7.74", { inst, devSha, ver });
  const c = await startApp();
  const main = (await c.send("Page.getFrameTree")).result.frameTree.frame.id;
  const shell = JSON.parse(await c.ev(`JSON.stringify({legacy:document.documentElement.classList.contains('legacy-webview'),ua:(navigator.userAgent.match(/Chrome\\/[\\d.]+/)||[''])[0],n:ARCADE.GAMES.length,pw:ARCADE.GAMES.find(g=>g.id==='pixelwar').versions.map(v=>v.id+(v.def?'*':'')).join(),pp:ARCADE.GAMES.find(g=>g.id==='papa-potato').versions.map(v=>v.id+(v.def?'*':'')).join(),sw:ARCADE.GAMES.find(g=>g.id==='swarm').versions.slice(-3).map(v=>v.id+(v.def?'*':'')).join()})`));
  ok("WebView 83 legacy shell, 26 cards, new version lists", shell.legacy && /Chrome\/83/.test(shell.ua) && shell.n === 26 && /v0410,v0412,v0413,latest\*$/.test(shell.pw) && shell.pp === "v01,v02,v03,v041,v042,v049,v0410,latest*" && shell.sw === "v1613,v1614,latest*", shell);
  const JOBS = [["pixelwar", "latest", /PIXEL WAR 0\.4\.14/], ["papa-potato", "latest", /Papa Potato 0\.4\.11/]];
  let k = 0;
  for (const [g, v, re] of JOBS.filter((j) => !process.env.ONLY || j[0] === process.env.ONLY)) {
    if (await c.ev("ARCADE.inGame")) { await c.ev("ARCADE.back(),1"); await sleep(3000); }
    const n0 = c.ctx.length;
    await c.ev(`(()=>{const i=ARCADE.GAMES.findIndex(g=>g.id==='${g}');ARCADE.launch(i,'${v}');return 1})()`);
    await sleep(12000);
    let cx; try { cx = await frameOf(c, n0, main); } catch (e) { ok(`${g}:${v} boots`, false, e.message); continue; }
    const G = async (e) => JSON.parse(await c.ev(`JSON.stringify(${e})`, cx.id));
    let info; for (let t = 0; t < 4; t++) { info = await G(`({title:document.title,ver:(window.__S13&&__S13.ver)||(typeof VERSION!=='undefined'?VERSION:null),pp:(window.PP&&PP.version)||null,errs:window.__errs||[],canvas:document.querySelectorAll('canvas').length})`); if (info.title && info.canvas > 0) break; await sleep(4000); }
    try { await c.ev(`(()=>{const b=document.getElementById('startBtn');if(b&&'${g}'==='swarm')b.click();return 1})()`, cx.id); } catch (e) {}
    await sleep(5000); shot(String(++k).padStart(2, "0") + "-" + g + "-" + v);
    const after = await G(`({errs:window.__errs||[]})`);
    const label = (info.title || "") + " " + (info.ver || "") + " " + (info.pp || "");
    ok(`${g}:${v} boots in WebView 83 (${label.trim()}), 0 JS errors after 5 s`, re.test(label) && info.canvas > 0 && after.errs.length === 0, { info, after });
  }
  if (await c.ev("ARCADE.inGame")) await c.ev("ARCADE.back(),1");
  const pass = R.every((r) => r.pass); fs.writeFileSync(`${OUT}/emu-2774.json`, JSON.stringify({ pass, R }, null, 1)); console.log(pass ? "EMU ALL PASS" : "EMU FAIL"); c.close(); process.exit(pass ? 0 : 1);
})().catch((e) => { console.error("ERR", e.message.slice(0, 500)); process.exit(1); });
