# Pixel War 0.4.14 — what changed (Jay t1207 / t1208 / t1209)

Built from the staged 0.4.13 (SHA e5423438…376c). The 0.4.13 build and stage are untouched. Patch: `tools/patch0414.py` + `tools/pixie-book.js` (the book, pasted in by the patch).

## 1. Pixie's book (t1207 / t1208)
- The AI is now named **Pixie** (menu line: "You vs Pixie, the AI").
- She is **given** a plain list, `PIXIE_BOOK`, and is not trained. It has 15 entries. Each entry has `id`, `topic`, `rule`, `physics`, `when`, `use` and `counter`.
- Each think tick (once a second at the default level), `pixieRead` does three things:
  - `pixieSee` builds the picture from what is on screen: both sides' paths with size, width, flow and pace; where lanes meet, head-on or not, with live pixels there; threats to her circle; HP; time left; free slots.
  - It checks every entry's `when` against that picture.
  - On a match, it runs the entry's `use` through `pixieAct`. That has only four actions: set / guard / branch / extend. All four go through the existing functions (setPathSetting, aiFreeSlot + aiOpenGuard, aiOpenBranch, branchExtend + branchEnd).
- **There is no wall action**, so the book cannot break the locked defense-line rule.
- Each entry acts on the same path or stream at most once every 4 s. If the older AI code moves a slider the book set, the book backs off for 15 s and never fights it.
- **All older AI code is unchanged.** The only hook is one line in `aiTactics` (`pixieRead(side)` before `aiBudget`). Switch: `AIR.book`.
- Acting entries:
  - objective (late HP surge);
  - guard_branch;
  - guard_main (guard sooner when behind or late);
  - size_swarm (meet a small swarm head-on with big);
  - size_big (vs big, stop trading and flank with small);
  - width_catch (non-main lanes match your width +1, guards +2, max 10);
  - flow (feed a head-on guard or intercept your flow +80);
  - pace (match the pace of what a guard meets);
  - path_end (draw a short punch or flank on to your circle).
- Rule-only entries: spacing, ricochet, merge, defense_line, clash, fair.
- The full list in plain words is in AI-RULES.md.
- Memory: unchanged (persistent, with the delete button). The book is code, not memory.

## 2. Branch drawing near a defense line (t1209)
- **Root cause:** `branchExtend` refused every step that came within `clrOf(sd)` of the side's OWN defense line. That distance is the half-width of the side's WIDEST lane + 4, so at width 10 it is 26 units, even for a thin branch. On a refused step the loop just stopped. Every later finger move retried the same refused step, so the branch froze at the edge of an invisible band. A finger crossing the line froze it too.
- The enemy line never blocked drawing (confirmed by a real-touch repro).
- **Fix (player):**
  - no clearance band, so you can draw right along your own line on either side;
  - a finger across your own line slides the tip along the line while that still gets it closer. It rests at the nearest point on its own side and carries on as soon as the finger goes round an end or through a gate.
  - The drawing never goes through the line, and the line blocks pixels exactly as before.
- **Pixie** keeps the old margin for her own branches by her own choice (`AIR.clear`), so her drawing is unchanged.
- **Main path (prep)** still keeps its clearance from your own line. Jay's report was about branches, so that was left alone.
- Regression: `tests/branchwall0414.cjs`, using real touch at width 10:
  - along your own line 6 above and 6 below;
  - straight across it;
  - across it and then round its end;
  - along and across Pixie's line;
  - your own pixels tracked over the line for 5 s (0 crossings);
  - Pixie keeps her margin.
  - On 0.4.13 it fails the 4 own-line draws (the repro).

## 3. Keys / label
- Label 0.4.14.
- Saves go to `pixelwar.v414`, `.custom`, `.forms` and `.aimem`. They fall back to v413, v412, v411, v410 and older.
- DELETE AI MEMORY also clears v413.
