# Pixel War 0.4.13 — what changed (Jay t1204)

Build: `/workspace/game/build-pixelwar0413/index.html`. SHA256 `e54234382c17abecff030e9fb30c6172e96b52af56c7bce6c5608b592661376c`. Copied from the shipped 0.4.12 (1ba7969e…dee7d). NOT shipped, signed, or published.

## 1. Lane width "doesn't work": root cause
Measured first. The 0.4.12 engine did change the lane: stream p90 went from 1.5 at width 1 to 21.6 at width 10, at sizes 1, 5 and 10. So the bug is not in laneHalf/laneHW, the size inset, old density, the AI, or the forced NORMAL lane. Three real problems made it *look* broken:
1. **Pixels rode the two lane edges.** Each pixel has its own sideways drift. In freeFwd that drift kept pushing it outward, and the edge bounce never turned the drift around, so it stayed pinned to the edge. Over half of a lane's pixels sat in its outer 20%, and the median pixel sat at 88% of the half-width. A wide lane looked like two thin rails with an empty middle, and widening just moved the rails apart. It was not new in 0.4.12 and has nothing to do with density: I measured 0.4.10, 0.4.11 and 0.4.12, and all three show the same edge pile-up.
   **Fix:** when a pixel reaches the lane edge, its own drift turns back inward (new random strength). There is no centerline pull: inside the lane nothing changes. Now the median is about 50–60% of p90, so the stream fills the lane evenly.
2. **A tap on a slider track never did anything (every slider).** The scroll-safe guard fired its own input event while it was still active, so its own listener swallowed and reverted it. Only sideways drags worked. Proven with emulated touch: tapping the right end of LANE WIDTH left it at 5.
   **Fix:** clear the guard before firing. The vertical-swipe-scrolls guard is kept.
3. **Branches ignored the main width.** A branch copied the main width once, when it was drawn. After that, moving LANE WIDTH on MAIN changed nothing downstream of a fork. Also, drawing a branch selects that branch, so the sliders then edit the branch.
   **Fix:** a player branch now follows the main width until you give that branch its own width. AI branches are unchanged.

### Width measurements (straight lane, flow 600, p90 lateral offset; lane half-width 1.6 → 22)
| width | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| size 1 | 1.5 | 3.7 | 5.7 | 7.6 | 9.9 | 11.9 | 14.3 | 16.5 | 18.3 | 20.1 |
| size 5 | 1.5 | 3.6 | 5.5 | 7.6 | 9.6 | 11.8 | 14.1 | 15.8 | 17.7 | 20.8 |
| size 10 | 1.0 | 1.3 | 3.6 | 5.6 | 7.4 | 9.6 | 11.7 | 14.3 | 15.3 | 18.0 |
- Width 10 = circle diameter (half-width 22 = circle radius). No pixel ever goes past 22.5.
- Narrowing 10→1 compacts at once (p90 1.7 after 0.25 s). Widening 1→10 drifts out gradually (p90 3.5 after 0.25 s, about 21 by 1.25–1.5 s).
- In the real matches (Tough's play test), every width change visibly changed the stream within 1.5 s. Examples: 2.4→9.6 took p90 from 4.5 to 19.8; 8.7→1.6 took it from 17.3 to 2.9.

## 2. Size balance: big wins head-on, small wins by coverage
- Tables: HP 1.6…2.5, damage 0.82…1.25 (size 5 unchanged: HP 2, damage 1); small-pixel dodge max 3% (was 6%).
- Coverage cost: 1.2× pixels per flow at size 1, 0.8× at size 10; big pixels stay up to 2.5 units in from the edges.
- Circle and wall damage per pixel = 1/count, so the same flow still does the same total damage.
- Head-on duels (flow 600, 3 seeds × sides swapped):

| size pair | kill share for big (width 3 / 6 / 10) |
|---|---|
| 10 v 1 | 69.7 / 70.8 / 71.6% |
| 8 v 3 | 61.6 / 62.4 / 62.6% |
| 7.5 v 2.5 | 61.9 / 62.6 / 63.4% |
| 6 v 4 | 54.8 / 54.9 / 55.4% |

  At flow 300 / 900: 10v1 71.1 / 70.6%, 8v3 62.6 / 62.1%. The big side pushes the front forward in every pair.
- Half-overlapping lanes (offset 30, width 10): small burned 10–11% more circle pool than big. The coverage edge is real but modest.
- The broken width was not the cause of big losing. 0.4.12's tables simply had big at only 52–56%, and the measure moved little with width.
- AI size picks (see AI-RULES.md):
  - punch 9, intercept 8, block 4, flank 3;
  - guard: one size bigger than the stream it meets (6–9), but one size smaller (4–6) against a wide stream (7+), for coverage;
  - main: meet big with bigger (8–10), beat small with 7, otherwise 6.

## 3. Smooth sliders
- PACE, DENSITY (pixel size) and LANE WIDTH use a 0.1 step; FLOW uses a 5 step; branch SHARE uses a 1 step (was 5).
- Labels show one decimal (e.g. "LANE WIDTH 6.3 medium").
- **−/+** nudge by one fine step. Hold either one and it repeats after 350 ms, speeding up (110 → 70 → 40 ms per step); it stops on release. In the test, a 1.5 s hold gained ≥1.0.
- Tap on the track works again. A sideways drag glides; a vertical swipe still scrolls and never slides.
- Fractional values work end to end:
  - physics: pixel size is stored in tenths and the size tables are interpolated every 0.1; speed and width are continuous;
  - saves (6.3 / 7.2 / 7.5 round-trip);
  - AI memory (loaded at 0.1 precision);
  - the AI guard reads fractional widths (5.5 → 7.5) and re-matches only on a change of 0.5 or more;
  - tt hooks: setSize, setSpeed, plus new setWidth and setPathWidth commands.
- Old integer saves (v412, v411, v410) load unchanged.

## 4. Locked rules kept
Every locked rule is unchanged:
- road hitbox, no centerline pull;
- max width = circle diameter;
- flow 200–1000;
- random short ricochet;
- roam then fade past the end;
- defense line locks; no mid-match walls;
- detour merge;
- shapes, lane-shape button and old density hidden; no cluster;
- full-smart AI with persistent memory and DELETE.

Saves: pixelwar.v413*, falling back to v412 / v411 / v410. DELETE clears v413, v412, v411, v410 and older.
