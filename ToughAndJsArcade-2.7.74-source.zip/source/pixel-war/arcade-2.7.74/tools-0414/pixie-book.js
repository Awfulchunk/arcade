// ===== 0.4.14 PIXIE'S BOOK (Jay t1207 / t1208) ==================================================================================
// Pixie is not taught or trained. She is GIVEN this list: the game's rules, how things physically work, and for each mechanic its USE and its COUNTER.
// Every think tick pixieRead() looks at what is on screen (pixieSee), checks each entry's `when` against her own situation and, when it matches, does the
// entry's `use` through the SAME actions the player has (pixieAct: path sliders, guard / branch drawing, branch extending). There is no wall action in
// pixieAct, so nothing in the book can build, move or erase a wall mid-match. Entries with no `when` are rules she obeys; the engine and the older AI code
// already enforce them. All older AI code (aiTactics, aiGuardStep, aiBudget, memory) runs unchanged; the book is a layer on top. AI-RULES.md mirrors this list.
const PIXIE_CD=240;   // an entry acts on the same path / stream at most once every 4 s (no slider thrash)
const PX_HEAD={main:1,guard:1,intercept:1,punch:1,detour:1};   // jobs that fight head-on
const PIXIE_BOOK=[
 {id:'objective',topic:'Objective / win condition',
  rule:'Take the enemy circle to 0 HP first. If the 5-minute timer runs out, the side with more circle HP wins. Defending my circle is half the job.',
  physics:'Circle HP is the pixels left in the pool. A pixel that reaches a circle burns the pool by its mass (size 10: 1.25, size 1: 0.83), so the same flow does the same total damage at any size.',
  when:o=>(o.secLeft<=60&&o.myHP<o.foeHP&&!o.ai.bkSurge)?[o.mine[0]]:null,
  use:(o,m,a)=>{o.ai.bkSurge=1;a.set(m.P,'release',Math.min(1000,m.flow+150),'behind on HP with a minute left: surge the main');if(m.pace<9)a.set(m.P,'speed',Math.min(9,m.pace+1),'and speed it up');},
  counter:'When ahead late, guard every stream that is landing (guard_main) instead of over-extending.'},
 {id:'guard_branch',topic:'Branches heading for my circle',
  rule:'Branches are drawn only during the match, from the main path, 400 meter each; erasing is free. A side has 3 slots. Keep one spare until a guard is up.',
  physics:'Pixels follow their lane and roam on past its end, so any lane that reaches or points at my circle will land on it.',
  when:o=>o.threats.filter(t=>t.pid>0&&!o.guarded[t.pid]&&o.guardN<AIR.guardMax),
  use:(o,t,a)=>{a.guard(t,'your branch '+t.pid+' heads for my circle: guarded it head-on');},
  counter:'Never leave it unblocked: meet it head-on in front of my circle with a guard branch that runs back up its lane, its width +2, at least its flow +80.'},
 {id:'guard_main',topic:'Main stream landing on my circle',
  rule:'The enemy main always aims at my circle; my own main pressure is the first answer.',
  physics:'Once it is really landing (hits on my circle), every second unguarded costs HP.',
  when:o=>(o.myHP<o.foeHP||o.secLeft<=60)?o.threats.filter(t=>t.pid===0&&t.hit>=5&&!o.guarded[0]&&o.guardN<AIR.guardMax):null,
  use:(o,t,a)=>{a.guard(t,'behind (or late) and your main is landing: guarded it');},
  counter:'Behind on HP or in the last minute, guard their main as soon as it lands instead of waiting.'},
 {id:'size_swarm',topic:'Pixel size (DENSITY slider) vs a small swarm',
  rule:'Size 1 (tiny) to 10 (huge), per path, 0.1 steps. Size 5 is the standard pixel.',
  physics:'BIG (10): HP 2.5, damage 1.25, hit radius 4.0, but only 0.8x pixels per flow and they stay 2.5 in from the lane edges. SMALL (1): HP 1.6, damage 0.82, hit radius 3.1, 1.2x pixels per flow, 3% harder to hit. Head-on, 10 v 1 takes about 70% of the kills, 8 v 3 about 62%, 6 v 4 about 55%.',
  when:o=>o.meets.filter(k=>k.headOn&&k.t.size<=3.5&&PX_HEAD[k.m.job]&&k.m.size<k.t.size+3&&!(k.m.job==='guard'&&k.t.w>=7)),
  use:(o,k,a)=>{const v=k.m.id===0?aiSizeFor('main',k.t.size):clamp(Math.round(k.t.size)+5,7,9);if(v>k.m.size)a.set(k.m.P,'size',v,'your small swarm meets my '+k.m.job+' head-on: big pixels ('+v+') win that');},
  counter:'Use big to punch straight through. Against a small swarm, meet it head-on with big. (A guard against a WIDE stream, 7+, keeps coverage sizes 4-6 instead.)'},
 {id:'size_big',topic:'Pixel size vs big pixels',
  rule:'Same slider. Big pixels win straight fights; they cost coverage.',
  physics:'Big pixels are fewer per flow and stay off the lane edges, so a stream that goes AROUND them, or comes in from the side, is not fighting their strength.',
  when:o=>o.slots>0?o.meets.filter(k=>k.headOn&&k.t.size>=7&&k.m.job!=='guard'&&(k.m.losing||k.m.ls>k.m.kl+10)):null,
  use:(o,k,a)=>{a.branch('flank','your big pixels win my head-on trade: stopped trading, flanking around with small pixels');},cd:600,
  counter:'Against big, do not trade head-on: flank with small pixels / a wide lane, or out-angle them from the side.'},
 {id:'width_catch',topic:'Lane width',
  rule:'LANE WIDTH 1-10 in 0.1 steps; 10 = the circle diameter, the max. The lane is a road: direction only, the pixels wander inside it and are never pulled to the centerline.',
  physics:'Narrow compacts the same pixels into a thin stream; wide spreads them out to cover. A stream only fights what its lane overlaps, so the outer pixels of a wider lane slip past a narrower one.',
  when:o=>o.meets.filter(k=>k.m.id!==0&&k.m.job!=='punch'&&k.m.job!=='flank'&&(k.m.job!=='guard'||k.t.id===k.m.P.guardOf)&&k.m.w<Math.min(10,k.t.w+(k.m.job==='guard'?AIR.edge:1))-0.4),
  use:(o,k,a)=>{const v=Math.min(10,k.t.w+(k.m.job==='guard'?AIR.edge:1));a.set(k.m.P,'width',v,'matched your lane '+k.t.w+' with '+v+' so your outer pixels are caught');},
  counter:'Match or exceed the enemy width (+1, guards +2) to catch the outer pixels; against a lane at 10, sit at 10. Thin lanes are for punching (punch branches run at 2).'},
 {id:'flow',topic:'Flow',
  rule:'FLOW 200-1000 = pixels of that path on the field at once. Every branch has its own. A side has at most 1000 out (cap).',
  physics:'More flow = more pixels in the fight. Flow is a budget: flow given to one path is taken from another.',
  when:o=>o.meets.filter(k=>k.headOn&&(k.m.job==='guard'||k.m.job==='intercept')&&k.t.flow>k.m.flow+60),
  use:(o,k,a)=>{a.set(k.m.P,'release',Math.min(1000,k.t.flow+80),'your flow '+k.t.flow+' outnumbers my '+k.m.job+': fed it '+Math.min(1000,k.t.flow+80));},
  counter:'Feed a head-on stream at least the enemy flow +80; starve paths that land nothing; surge when their flow is split.'},
 {id:'pace',topic:'Pace',
  rule:'PACE 1-10 = how fast pixels move.',
  physics:'Faster pixels reach the end sooner, so more of them arrive per second for the same count on the field. Pace does not change HP or damage.',
  when:o=>o.meets.filter(k=>(k.m.job==='guard'||k.m.job==='intercept')&&k.m.pace<k.t.pace-0.4),
  use:(o,k,a)=>{a.set(k.m.P,'speed',k.t.pace,'matched your pace '+k.t.pace+' so my '+k.m.job+' is not outrun');},
  counter:'Match the pace of a stream you are meeting, so it cannot outrun the guard.'},
 {id:'path_end',topic:'Past a path end',
  rule:'Past the end of its path a stream keeps going one way as a loose group, then fades.',
  physics:'Roaming pixels are not steered, so a lane that stops short of the circle wastes most of them.',
  when:o=>{const fc=o.foe.circle;return o.mine.filter(m=>(m.job==='punch'||m.job==='flank')&&m.P.rj<0&&S.tick-(m.P.born||0)>120&&brLeft(o.sd,m.P)>=PSP*3&&Math.hypot(m.P.p[m.P.p.length-2]-fc.x,m.P.p[m.P.p.length-1]-fc.y)>CR+40);},
  use:(o,m,a)=>{a.extend(m.P,o.foe.circle.x,o.foe.circle.y,'branch '+m.id+' stopped short: drew it on to your circle');},cd:600,
  counter:'End every attack lane ON the enemy circle.'},
 {id:'spacing',topic:'Spacing',rule:'There is no separate spacing control: it was merged into the old density in 0.4.6, and old density is off for both sides.',physics:'Only lane width and flow change how tightly a stream packs.',when:null,use:null,counter:'Nothing to use or counter.'},
 {id:'ricochet',topic:'Contacts and ricochet',rule:'When enemy pixels touch they bounce or die. A ricochet is random and short; a bounced pixel keeps flying straight.',physics:'Bounces cannot be aimed by either side.',when:null,use:null,counter:'Never count on bounced pixels; win the contacts with size, width and flow.'},
 {id:'merge',topic:'Detour merge / loop-connect',rule:'A branch whose end is drawn back into its own lane (inside the hitbox, or a finger from its edge, downstream or upstream) connects; its pixels rejoin. A pixel can loop at most 2 times.',physics:'A detour takes pixels around a fight and puts them back on the main past it.',when:null,use:'Detour around a losing clash and rejoin (older AI: clash evaluator + reroute).',counter:'Against a detour player, meet the stream after its rejoin point (older AI: meetNear).'},
 {id:'defense_line',topic:'Defense line',rule:'Drawn in prep, it locks at START. Nobody (player or Pixie) builds, rebuilds or erases walls during the match. The book has no wall action.',physics:'Enemy pixels damage only the wall cell they hit; a side\'s own pixels bounce off its own wall.',when:null,use:'Keep my own branches a lane width off my own line (my pixels would bounce off it); plan my route through the weakest part or round an end (prep plan).',counter:'Their line: go round an end or through a gap; never retry a blocked build.'},
 {id:'clash',topic:'Clash front',rule:'A clash is where both sides\' pixels fight; the enemy spawn zone is not a clash.',physics:'A clash that keeps losing burns my pixels for nothing.',when:null,use:'Losing clash: cut flow (never under 400) and reroute (older AI).',counter:'Surge when their flow is split across branches (older AI).'},
 {id:'fair',topic:'Same rules',rule:'Pixie uses the same sliders, meters, caps, cooldowns and drawing as the player, reads only what is on screen, and never uses hidden features (lane shapes, shapes, old density).',physics:'',when:null,use:null,counter:''}
];
function pixieMeet(sd,P,foe,F){const ra=laneHalf(pset(sd,P),P.lane||0,0),rb=laneHalf(pset(foe,F),F.lane||0,0),R=ra+rb+3,R2=R*R,n=pathN(P),m=pathN(F);if(n<4||m<3)return null;let hit=0,live=0,dot=0;
  for(let k=2;k<n-1;k+=3){const x=P.p[k*2],y=P.p[k*2+1];let bd=R2,bj=-1;for(let j=1;j<m-1;j++){const dx=F.p[j*2]-x,dy=F.p[j*2+1]-y,d=dx*dx+dy*dy;if(d<bd){bd=d;bj=j;}}if(bj<0)continue;
    hit++;if(aiDens(sd.id,x,y)>=1&&aiDens(foe.id,x,y)>=1)live++;const ax=P.p[(k+1)*2]-P.p[(k-1)*2],ay=P.p[(k+1)*2+1]-P.p[(k-1)*2+1],bx=F.p[(bj+1)*2]-F.p[(bj-1)*2],by=F.p[(bj+1)*2+1]-F.p[(bj-1)*2+1];dot+=(ax*bx+ay*by)/((Math.hypot(ax,ay)*Math.hypot(bx,by))||1);}
  if(hit<3||live<2)return null;return{n:hit,live:live,headOn:dot/hit<-0.4};}
function pixieSee(side){const sd=S.sides[side],foe=S.sides[1-side],ai=S.ai;
  const o={side:side,sd:sd,foe:foe,ai:ai,secLeft:Math.max(0,(CFG.matchSec*60-S.tick)/60),myHP:sd.pool,foeHP:foe.pool,mine:[],theirs:[],meets:[],guarded:{},guardN:0};
  for(const P of sd.paths){if(!P||(P.id&&pathN(P)<2))continue;const s=pset(sd,P);
    o.mine.push({P:P,id:P.id,job:P.id?(P.job||'branch'):'main',size:sizeOf(s),w:r1(+s.width||5),flow:onField(s),pace:+s.speed||5,kl:sd.pathKill[P.id]||0,ls:sd.pathLoss[P.id]||0,ch:sd.pathCirc[P.id]||0,losing:aiPathClash(sd,P).losing});
    if(P.job==='guard'){o.guarded[P.guardOf]=1;o.guardN++;}}
  for(const F of foe.paths){if(!F||pathN(F)<3)continue;const s=pset(foe,F);o.theirs.push({F:F,id:F.id,size:sizeOf(s),w:r1(+s.width||5),flow:onField(s),pace:+s.speed||5,hit:foe.pathCirc[F.id]||0});}
  for(const m of o.mine)for(const t of o.theirs){const k=pixieMeet(sd,m.P,foe,t.F);if(k)o.meets.push({m:m,t:t,headOn:k.headOn,n:k.n});}
  o.threats=aiThreats(side);o.slots=CFG.maxBr-brCount(sd)-aiReserve(side);return o;}
// the ONLY things the book can do (same API as the player): set a path slider, open a guard, open a branch, draw a branch further. No walls.
function pixieAct(side,o){const sd=S.sides[side],tag=()=>'Pixie\'s book ['+(a.e?a.e.id:'?')+']: ';const a={e:null,did:0,
  set(P,key,v,why){if(!P||sd.paths[P.id]!==P||!fin(v))return false;const s=pset(sd,P),cur=key==='size'?sizeOf(s):key==='release'?onField(s):+s[key];const nv=key==='release'?migRelease(v):clamp(r1(v),1,10);if(Math.abs(nv-cur)<0.05)return false;
    // the older AI code wins a tie: if it moved this slider away from what the book set less than 15 s ago, the book does not fight it
    const bk=S.ai&&S.ai.book,ok=bk?(bk.own||(bk.own={})):{},ky=P.id+':'+key+':'+(P.born|0),was=ok[ky];if(was&&Math.abs(cur-was.v)>=0.05&&S.tick-was.t<900)return false;
    setPathSetting(side,P.id,key,nv);ok[ky]={v:nv,t:S.tick};a.did++;aiLearn(tag()+(why||key+' '+nv));return true;},
  guard(T,why){if(!canBr(sd)||!aiFreeSlot(side))return null;const B=aiOpenGuard(side,T);if(B){a.did++;o.guardN++;o.guarded[T.pid]=1;aiLearn(tag()+why);}return B;},
  branch(job,why){if(o.slots<=0||!canBr(sd))return null;const B=aiOpenBranch(side,job);if(B){a.did++;o.slots--;if(S.ai)S.ai.lastBr=S.tick;aiLearn(tag()+why);}return B;},
  extend(P,x,y,why){if(!P||sd.paths[P.id]!==P||!canBr(sd))return 0;let n=0;for(let g=0;g<40;g++){const k=branchExtend(side,P,x,y);if(!k)break;n+=k;const q=P.p;if(Math.hypot(q[q.length-2]-x,q[q.length-1]-y)<6)break;}
    if(n){branchEnd(side,P);a.did++;aiLearn(tag()+why);}return n;}};return a;}
function pixieKey(h){if(h&&h.m&&h.t)return 'P'+h.m.id+'F'+h.t.id;if(h&&h.pid!=null)return 'T'+h.pid;if(h&&h.id!=null)return 'P'+h.id;return 'x';}
function pixieRead(side){const ai=S.ai;if(!ai||!AIR.book||S.phase!=='battle')return 0;const bk=ai.book||(ai.book={reads:0,fired:{},cd:{}});bk.reads++;const o=pixieSee(side),a=pixieAct(side,o);let n=0;
  for(const e of PIXIE_BOOK){if(typeof e.when!=='function'||typeof e.use!=='function')continue;let hits=null;try{hits=e.when(o);}catch(err){bk.err=(bk.err|0)+1;continue;}if(!hits)continue;if(!Array.isArray(hits))hits=[hits];
    for(const h of hits){const key=e.id+':'+pixieKey(h);if(S.tick<(bk.cd[key]||0))continue;a.e=e;a.did=0;try{e.use(o,h,a);}catch(err){bk.err=(bk.err|0)+1;}if(a.did){bk.cd[key]=S.tick+(e.cd||PIXIE_CD);bk.fired[e.id]=(bk.fired[e.id]||0)+1;n++;}}}
  return n;}
