import re,sys
F='/workspace/game/build-pixelwar0413/index.html'
s=open(F,encoding='utf-8').read()
def R(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt: print('COUNT',n,'!=',cnt,'for',old[:90]);sys.exit(1)
    s=s.replace(old,new)
# ---- version + keys
R('<title>PIXEL WAR 0.4.12</title>','<title>PIXEL WAR 0.4.13</title>')
R('<h1>PIXEL WAR 0.4.12</h1>','<h1>PIXEL WAR 0.4.13</h1>')
R("const KEY='pixelwar.v412',KEYC='pixelwar.v412.custom',KEYF='pixelwar.v412.forms',","const KEY='pixelwar.v413',KEYC='pixelwar.v413.custom',KEYF='pixelwar.v413.forms',KEY412='pixelwar.v412',KEYC412='pixelwar.v412.custom',KEYF412='pixelwar.v412.forms',")
R("const KEYAI='pixelwar.v412.aimem',","const KEYAI='pixelwar.v413.aimem',KEYAI412='pixelwar.v412.aimem',")
R("localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI411)","localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI412)||localStorage.getItem(KEYAI411)")
R("localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI411);","localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI412);localStorage.removeItem(KEYAI411);")
R("localStorage.getItem(KEY)||localStorage.getItem(KEY411)","localStorage.getItem(KEY)||localStorage.getItem(KEY412)||localStorage.getItem(KEY411)")
R("localStorage.getItem(KEYF)||localStorage.getItem(KEYF410)","localStorage.getItem(KEYF)||localStorage.getItem(KEYF412)||localStorage.getItem(KEYF411)||localStorage.getItem(KEYF410)")
# ---- size tables: new balance (t1204) + 0.1-step lookup tables
R("const SZ_CNT=[1.12,1.09,1.06,1.03,1,0.976,0.952,0.928,0.904,0.88],SZ_HP=[1.84,1.88,1.92,1.96,2,2.024,2.048,2.072,2.096,2.12],SZ_DMG=[0.88,0.91,0.94,0.97,1,1.018,1.036,1.054,1.072,1.09],SZ_DG=[0.06,0.045,0.03,0.015,0,0,0,0,0,0],",
  "// 0.4.13 (Jay t1204): BIG WINS HEAD-ON, SMALL WINS BY COVERAGE. HP 1.6..2.5 and damage 0.82..1.25 (size 5 unchanged = HP 2, dmg 1); small dodge cut to 3% max;\n"
  "//   the cost of size is coverage: 0.8x pixels per flow at size 10 (1.2x at size 1) and big pixels stay further in from the lane edges (SZ_IN up to 2.5).\n"
  "const SZ_CNT=[1.2,1.15,1.1,1.05,1,0.96,0.92,0.88,0.84,0.8],SZ_HP=[1.6,1.7,1.8,1.9,2,2.1,2.2,2.3,2.4,2.5],SZ_DMG=[0.82,0.86,0.9,0.95,1,1.05,1.1,1.15,1.2,1.25],SZ_DG=[0.03,0.02,0.01,0.005,0,0,0,0,0,0],")
R("SZ_IN=[0,0,0,0,0,0.3,0.6,0.9,1.2,1.5]","SZ_IN=[0,0,0,0,0,0.5,1,1.5,2,2.5]")
R("SZ_MASS=[0.893,0.917,0.943,0.971,1,1.025,1.05,1.078,1.106,1.136];","SZ_MASS=[0.833,0.87,0.909,0.952,1,1.042,1.087,1.136,1.19,1.25];\n"
  "// 0.4.13 (Jay t1204 smooth sliders): sizes are fractional (0.1 steps). A pixel stores its size in tenths (psz 10..100); ZL.* are the SZ_* tables\n"
  "//   linearly interpolated at every tenth (index = tenths), rebuilt by rebuildSZ() if a test retunes SZ_*.\n"
  "const ZL={};function rebuildSZ(){for(const [k,t] of [['CNT',SZ_CNT],['HP',SZ_HP],['DMG',SZ_DMG],['DG',SZ_DG],['CT',SZ_CT],['IN',SZ_IN],['PX',SZ_PX],['MASS',SZ_MASS]]){const a=new Float64Array(101);for(let q=0;q<=100;q++){const z=clamp(q/10,1,10),f=Math.min(8,Math.floor(z-1)),u=z-1-f;a[q]=t[f]+(t[f+1]-t[f])*u;}ZL[k]=a;}ZL.v=(ZL.v|0)+1;}\n"
  "const r1=v=>Math.round(v*10)/10,zq=z=>clamp(Math.round(z*10),10,100);")
R("sizeOf=set=>clamp((set&&set.size)|0||5,1,10);","sizeOf=set=>{const v=set?+set.size:NaN;return fin(v)&&v!==0?clamp(r1(v),1,10):5;};")
# clamp is defined later (line ~192) -> rebuildSZ must run after; call it after clamp definition
R("const clamp=(v,a,b)=>v<a?a:v>b?b:v;","const clamp=(v,a,b)=>v<a?a:v>b?b:v;\nrebuildSZ();")
R("const psz=new Uint8Array(NP).fill(5)","const psz=new Uint8Array(NP).fill(50)")
# flowRate / release / reSize
R("onField(set)*SZ_CNT[sizeOf(set)-1]/T;","onField(set)*ZL.CNT[zq(sizeOf(set))]/T;")
R("if(sd.active>=sd.set.cap*SZ_CNT[zd-1]||sd.pool<=0)","if(sd.active>=sd.set.cap*ZL.CNT[zq(zd)]||sd.pool<=0)")
R("psz[i]=zs;{const hv=CFG.pixHP*SZ_HP[zs-1]/2;","psz[i]=zq(zs);{const hv=CFG.pixHP*ZL.HP[zq(zs)]/2;")
R("const z=sizeOf(pset(sd,P)),o=psz[i];if(z===o)return;const hv=php[i]/HPQ*SZ_HP[z-1]/SZ_HP[o-1];","const z=zq(sizeOf(pset(sd,P))),o=psz[i];if(z===o)return;const hv=php[i]/HPQ*ZL.HP[z]/ZL.HP[o];")
R("SZ_IN[psz[i]-1]","ZL.IN[psz[i]]",2)
R("SZ_DG[psz[i]-1]","ZL.DG[psz[i]]");R("SZ_DG[psz[j]-1]","ZL.DG[psz[j]]")
R("const dI0=pHP*SZ_DMG[psz[j]-1],dJ0=pHP*SZ_DMG[psz[i]-1]","const dI0=pHP*ZL.DMG[psz[j]],dJ0=pHP*ZL.DMG[psz[i]]")
R("const ctr=(SZ_CT[psz[i]-1]+SZ_CT[psz[j]-1])*0.5;","const ctr=(ZL.CT[psz[i]]+ZL.CT[psz[j]])*0.5;")
R("SZ_MASS[psz[i]-1]","ZL.MASS[psz[i]]",2)
R("cols[php[i]>hh*SZ_HP[psz[i]-1]?0:1],big=false,dz=szd[psz[i]-1]","cols[php[i]>hh*ZL.HP[psz[i]]?0:1],big=false,dz=szd[psz[i]]")
R("szd=SZ_PX.map(v=>Math.max(1,Math.round(v*sc/2)));","szd=szdOf(sc);")
R("function draw(){","let SZD=null,SZDk='';function szdOf(sc){const k=sc+':'+ZL.v;if(k!==SZDk){SZDk=k;SZD=new Uint8Array(101);for(let q=0;q<=100;q++)SZD[q]=Math.max(1,Math.round(Math.round(ZL.PX[q])*sc/2));}return SZD;}   // dot side per size tenth (cached; 2x2 device px at size 5)\nfunction draw(){")
R("{const z=SZ_PX[psz[i]-1];r.push(","{const z=Math.round(ZL.PX[psz[i]]);r.push(")
R("noOverlap:false,size:psz[i]});","noOverlap:false,size:psz[i]/10});")
R("{const z=SZ_PX[psz[i]-1];c2.fillRect(","{const z=Math.round(ZL.PX[psz[i]]);c2.fillRect(")
R("st:pst[i],size:psz[i]});","st:pst[i],size:psz[i]/10});")
# ---- lane width: fractional, end to end
R("function laneHW(set){const w=clamp((set&&set.width)|0,1,10),","function laneHW(set){const w0=set?+set.width:NaN,w=clamp(fin(w0)?w0:1,1,10),")
# ---- setters: fine 0.1 values; main width carries to player branches that were never given their own width
R("if(key==='size'){sd.set.size=clamp(Math.round(v),1,10);sizeLive(side,0);return true;}\n  if(key==='speed'||key==='density'||key==='size'||key==='sdens'||key==='compact'||key==='width')sd.set[key]=clamp(Math.round(v),1,10);",
  "if(key==='size'){sd.set.size=clamp(r1(v),1,10);sizeLive(side,0);return true;}\n"
  "  if(key==='width'){sd.set.width=clamp(r1(v),1,10);if(sd.human)for(const P of sd.paths)if(P&&P.id&&P.set&&!P.wOwn)P.set.width=sd.set.width;return true;}   // 0.4.13 (t1204): a player branch follows the main LANE WIDTH until you set that branch's own width\n"
  "  if(key==='speed')sd.set.speed=clamp(r1(v),1,10);\n"
  "  else if(key==='density'||key==='sdens'||key==='compact')sd.set[key]=clamp(Math.round(v),1,10);")
R("if(key==='size'){P.set.size=clamp(Math.round(v),1,10);sizeLive(side,id);return true;}\n  if(key==='speed'||key==='density'||key==='size'||key==='width'){P.set[key]=clamp(Math.round(v),1,10);return true;}",
  "if(key==='size'){P.set.size=clamp(r1(v),1,10);sizeLive(side,id);return true;}\n"
  "  if(key==='width'){P.set.width=clamp(r1(v),1,10);P.wOwn=1;return true;}\n"
  "  if(key==='speed'){P.set.speed=clamp(r1(v),1,10);return true;}\n"
  "  if(key==='density'){P.set.density=clamp(Math.round(v),1,10);return true;}")
# ---- AI: fractional widths read without truncation; guard re-matches on a real change (>= 0.5)
R("function aiGuardW(foeW){const h=S.ai&&S.ai.hab;return clamp(Math.max(foeW|0,","function aiGuardW(foeW){const h=S.ai&&S.ai.hab;return clamp(Math.max(fin(+foeW)?r1(+foeW):5,")
R("w:clamp(fs.width|0,1,10),flow:onField(fs)","w:clamp(r1(+fs.width||5),1,10),flow:onField(fs)")
R("w=aiGuardW(fs.width);if(B.set.width!==w){","w=aiGuardW(fs.width);if(Math.abs((+B.set.width||0)-w)>=0.5||(w>=10&&B.set.width<10)){")
R("const fmw=foe.paths[0]?pset(foe,foe.paths[0]).width|0:5;","const fmw=foe.paths[0]?r1(+pset(foe,foe.paths[0]).width||5):5;")
R("B.set.speed=clamp(Math.max(sd.set.speed,fs.speed|0),1,10);","B.set.speed=clamp(Math.max(sd.set.speed,+fs.speed||5),1,10);")
R("t[k]=k==='release'?migRelease(v.tune[k]):clamp(Math.round(+v.tune[k]),1,10);}if(ok&&fin(+v.tune.size))t.size=clamp(Math.round(+v.tune.size),1,10);",
  "t[k]=k==='release'?migRelease(v.tune[k]):clamp(r1(+v.tune[k]),1,10);}if(ok&&fin(+v.tune.size))t.size=clamp(r1(+v.tune.size),1,10);")
# ---- HUD labels: one decimal
R("setT('lSp','PACE\\n'+ps.speed+' '+PW[ps.speed-1]);setT('lDe','DENSITY\\n'+sizeOf(ps)+' '+ZW(sizeOf(ps)));setT('lWd','LANE WIDTH\\n'+ps.width+' '+WW(ps.width));",
  "setT('lSp','PACE\\n'+(+ps.speed).toFixed(1)+' '+PW[clamp(Math.round(ps.speed),1,10)-1]);setT('lDe','DENSITY\\n'+sizeOf(ps).toFixed(1)+' '+ZW(sizeOf(ps)));setT('lWd','LANE WIDTH\\n'+(+ps.width).toFixed(1)+' '+WW(ps.width));")
R("const sl=[['sSp',ps.speed],['sDe',sizeOf(ps)],['sWd',ps.width],","const sl=[['sSp',r1(+ps.speed)],['sDe',sizeOf(ps)],['sWd',r1(+ps.width)],")
# ---- slider elements: fine steps
R('<input id="sDe" type="range" min="1" max="10" step="1" value="5"','<input id="sDe" type="range" min="1" max="10" step="0.1" value="5"')
R('<input id="sWd" type="range" min="1" max="10" step="1" value="5"','<input id="sWd" type="range" min="1" max="10" step="0.1" value="5"')
R('<input id="sRe" type="range" min="200" max="1000" step="1" value="289"','<input id="sRe" type="range" min="200" max="1000" step="5" value="290"')
R("if(rm.min!=='200'){rm.min=200;rm.max=1000;rm.step=1;}","if(rm.min!=='200'||rm.step!=='5'){rm.min=200;rm.max=1000;rm.step=5;}")
# ---- +/- buttons: fine step + hold-to-repeat (accelerates)
R("for(const b of document.querySelectorAll('.pm')){b.addEventListener('click',()=>{const el=$(b.dataset.for),stp=(el&&el.id==='sRe')?10:(+el.step||1),v=clamp(+el.value+(+b.dataset.d)*stp,+el.min,+el.max);el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));});}",
  "// 0.4.13 (Jay t1204): +/- nudge by the FINE step (0.1, flow 5). Hold to repeat: after 350 ms it repeats, speeding up to 1 step per frame-ish (40 ms).\n"
  "function pmNudge(b){const el=$(b.dataset.for);if(!el)return false;const stp=+el.step||1,v=clamp(Math.round((+el.value+(+b.dataset.d)*stp)/stp)*stp,+el.min,+el.max),vv=stp<1?r1(v):v;if(vv===+el.value)return false;el.value=vv;el.dispatchEvent(new Event('input',{bubbles:true}));return true;}\n"
  "for(const b of document.querySelectorAll('.pm')){let tmr=0,pd=0,n=0,held=false;const stop=()=>{if(tmr){clearTimeout(tmr);tmr=0;}if(held){held=false;const el=$(b.dataset.for);if(el)el.dispatchEvent(new Event('change',{bubbles:true}));}};\n"
  "  const rep=()=>{n++;pmNudge(b);tmr=setTimeout(rep,n<6?110:n<16?70:40);};\n"
  "  b.addEventListener('pointerdown',e=>{if(e.button>0)return;pd=Date.now();n=0;held=true;pmNudge(b);if(tmr)clearTimeout(tmr);tmr=setTimeout(rep,350);});\n"
  "  b.addEventListener('pointerup',stop);b.addEventListener('pointercancel',stop);b.addEventListener('pointerleave',stop);\n"
  "  b.addEventListener('contextmenu',e=>e.preventDefault());\n"
  "  b.addEventListener('click',()=>{if(Date.now()-pd<1500)return;pmNudge(b);const el=$(b.dataset.for);if(el)el.dispatchEvent(new Event('change',{bubbles:true}));});}   // click without a pointerdown (keyboard / synthetic) still nudges once")
# ---- scroll-safe slider: fractional valAt; a TAP on the track works again (root cause #2: the guard swallowed its own synthetic input event)
R("return clamp(min+Math.round((v-min)/step)*step,min,max);};","const q=clamp(min+Math.round((v-min)/step)*step,min,max);return step<1?r1(q):q;};")
R("const up=e=>{if(!st||e.pointerId!==st.id)return;if(st.mode===0){const nv=valAt(st.el,e.clientX);if(nv!==st.v){st.el.value=nv;fire(st.el,'input');fire(st.el,'change');}else revert();}else if(st.mode===1)fire(st.el,'change');else revert();st=null;};",
  "const up=e=>{if(!st||e.pointerId!==st.id)return;const s0=st;st=null;   // 0.4.13: clear the guard BEFORE firing, or its own input listener swallows the tap (0.4.12 bug: a tap on the track never changed anything)\n"
  "    if(s0.mode===0){const nv=valAt(s0.el,e.clientX);if(nv!==s0.v){s0.el.value=nv;fire(s0.el,'input');fire(s0.el,'change');}else if(+s0.el.value!==s0.v)s0.el.value=s0.v;}else if(s0.mode===1)fire(s0.el,'change');else if(+s0.el.value!==s0.v)s0.el.value=s0.v;};")
# ---- exports
R("SZ_MASS,DENSITY_OFF,DENS_N,HPQ,densOf,sizeOf,","SZ_MASS,DENSITY_OFF,DENS_N,HPQ,densOf,sizeOf,ZL,rebuildSZ,zq,r1,get KEYAI412(){return KEYAI412;},KEY412,")
open(F,'w',encoding='utf-8').write(s);print('ok')
# (applied after: freeFwd edge drift turn-around, aiSizeFor 0.4.13 picks, loss-flip size, .pm no-select CSS, sSp step 0.1 — see PROGRESS.md; done as follow-up inline edits)
