import sys
F='/workspace/game/build-pixelwar0414/index.html'
s=open(F,encoding='utf-8').read()
def R(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt: print('COUNT',n,'!=',cnt,'for',old[:90]);sys.exit(1)
    s=s.replace(old,new)
# ---- version + keys (v414, fallback v413 / v412 / v411 / v410 and older)
R('<title>PIXEL WAR 0.4.13</title>','<title>PIXEL WAR 0.4.14</title>')
R('<h1>PIXEL WAR 0.4.13</h1>','<h1>PIXEL WAR 0.4.14</h1>')
R("const KEY='pixelwar.v413',KEYC='pixelwar.v413.custom',KEYF='pixelwar.v413.forms',","const KEY='pixelwar.v414',KEYC='pixelwar.v414.custom',KEYF='pixelwar.v414.forms',KEY413='pixelwar.v413',KEYC413='pixelwar.v413.custom',KEYF413='pixelwar.v413.forms',")
R("KEYAI='pixelwar.v413.aimem',","KEYAI='pixelwar.v414.aimem',KEYAI413='pixelwar.v413.aimem',")
R("localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI412)","localStorage.getItem(KEYAI)||localStorage.getItem(KEYAI413)||localStorage.getItem(KEYAI412)")
R("localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI412);","localStorage.removeItem(KEYAI);localStorage.removeItem(KEYAI413);localStorage.removeItem(KEYAI412);")
R("localStorage.getItem(KEY)||localStorage.getItem(KEY412)","localStorage.getItem(KEY)||localStorage.getItem(KEY413)||localStorage.getItem(KEY412)")
R("localStorage.getItem(KEYF)||localStorage.getItem(KEYF412)","localStorage.getItem(KEYF)||localStorage.getItem(KEYF413)||localStorage.getItem(KEYF412)")
R("localStorage.getItem(KEYC)||localStorage.getItem(KEYC410)","localStorage.getItem(KEYC)||localStorage.getItem(KEYC413)||localStorage.getItem(KEYC412)||localStorage.getItem(KEYC411)||localStorage.getItem(KEYC410)")
R("   PIXEL WAR 0.4.13 (Jay t1204)","   PIXEL WAR 0.4.14 (Jay t1207/t1208/t1209) — the AI (Pixie) is GIVEN a plain rule book (PIXIE_BOOK: rule, physics, when, use, counter per mechanic) that she reads every think tick and applies through the same actions the player has; all older AI code is kept as is. Drawing a branch near or along a defense line no longer freezes (the old lane-width clearance band is gone for the player; a finger across your own line slides the tip along it). Saves pixelwar.v414*.\n   0.4.13 (Jay t1204)")
# ---- t1209 branch drawing near defense lines
R("""    const nx=lx+dx/d*PSP,ny=ly+dy/d*PSP;if(crossesOwnWall(sd,lx,ly,nx,ny)||(sd.strokes.length&&nearOwnWall(sd,nx,ny,clrOf(sd))))break;p.push(nx,ny);n++;}
  if(n)rejoinOf(sd,P);return n;}""","""    let nx=lx+dx/d*PSP,ny=ly+dy/d*PSP;
    if(keep){if(crossesOwnWall(sd,lx,ly,nx,ny)||(sd.strokes.length&&nearOwnWall(sd,nx,ny,clrOf(sd))))break;}
    else if(crossesOwnWall(sd,lx,ly,nx,ny)){const q=brSlide(sd,lx,ly,tx,ty,d);if(!q)break;nx=q[0];ny=q[1];}
    p.push(nx,ny);n++;}
  if(n)rejoinOf(sd,P);return n;}
// 0.4.14 (t1209): a finger across your own defense line no longer freezes the branch: the tip slides along the line toward the finger (only while that gets it closer),
// so it rests at the nearest point on its side and carries on as soon as the finger goes round an end or through a gate. The line itself is never crossed by the drawing.
function brSlide(sd,lx,ly,tx,ty,d){const a0=Math.atan2(ty-ly,tx-lx);for(let s=1;s<=6;s++)for(const sg of[1,-1]){const a=a0+sg*s*0.26,nx=lx+Math.cos(a)*PSP,ny=ly+Math.sin(a)*PSP;
  if(nx<4||nx>W-4||ny<4||ny>H-4||Math.hypot(tx-nx,ty-ny)>=d-0.05)continue;if(!crossesOwnWall(sd,lx,ly,nx,ny))return[nx,ny];}return null;}""")
R("""  tx=clamp(tx,4,W-4);ty=clamp(ty,4,H-4);const p=P.p;let n=0;
  for(let g=0;g<300;g++){""","""  tx=clamp(tx,4,W-4);ty=clamp(ty,4,H-4);const p=P.p;let n=0;
  // 0.4.14 (t1209) ROOT CAUSE: every step used to be refused inside clrOf(sd) of the side's own line = the WIDEST lane half-width of ALL its paths + 4 (up to 26 units at width 10),
  // and the loop just stopped, so the next finger move retried the same refused step: the branch froze at the edge of an invisible band. The player now draws freely near and along
  // the line (the line still blocks pixels exactly as before). Pixie keeps that margin for her OWN branches by choice (keep), so her existing drawing is unchanged.
  const keep=!sd.human&&AIR.clear;
  for(let g=0;g<300;g++){""")
# ---- AIR switches
R("const AIR={guard:1,mainW:1,side:1,size:1,","const AIR={guard:1,mainW:1,side:1,size:1,book:1,clear:1,")
# ---- book hook (only hook into existing AI code): read the book every think tick, before the flow budget
R("""  aiBudget(side);
}
const aiEvery=""","""  pixieRead(side);   // 0.4.14: Pixie reads her book (below) and applies it
  aiBudget(side);
}
"""+open('/workspace/game/build-pixelwar0414/tools/pixie-book.js',encoding='utf-8').read()+"""
const aiEvery=""")
R('<p class="sub">You vs the AI. Destroy','<p class="sub">You vs Pixie, the AI. Destroy')
# ---- test exports
R("get KEYAI412(){return KEYAI412;},KEY412,","get KEYAI412(){return KEYAI412;},KEY412,get KEYAI413(){return KEYAI413;},KEY413,PIXIE_BOOK,pixieRead,pixieSee,pixieMeet,pixieAct,brSlide,aiSizeFor,")
open(F,'w',encoding='utf-8').write(s);print('ok')
