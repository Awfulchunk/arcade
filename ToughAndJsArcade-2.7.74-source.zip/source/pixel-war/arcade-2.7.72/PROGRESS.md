# Pixel War 0.4.10 — progress

**Status: built and hard-tested (AI + loop-connect t1172), NOT shipped.** Staged at `requests/finished-ship/pixelwar-0.4.10-test/`.

Worktree: `/workspace/game/build-pixelwar0410/`. Live 0.4.9 was not mutated.

## t1172 loop-connect

Branches now connect for a loop: finger-sized snap anywhere in (or a finger from) the own main-lane hitbox, including back **upstream**. Pixels rejoin and keep going; a per-pixel loop cap of 2 stops endless recirculation. A short CONNECTED flash marks a successful join. The AI uses the same merge rules. Attack branches aimed at the path tip still do not false-merge. Locked rules kept (road hitbox, no centerline pull on rejoin, no mid-match walls).

Cheap 23-race tweak: when the AI takes the off-center outer wrap, it also gets +1 speed and +80 flow. Centered openings (dummy / fair 17 / fair 11) are unchanged.

## Tests (one hard pass, 2026-11-18 evening America/Los_Angeles)

Lint: `node --check` clean. `esbuild --target=chrome83` builds (5 pre-existing duplicate `__pw` hook-key warnings, not new).

Loop-connect (simulated touch strokes, width 5, lane half-width ≈10.7, finger pad 28):

- Downstream and upstream, 9 end points each (center, both insides, both edges, both in-finger, both misses): **all 18 passed**.
- Upstream connects are flagged as loops; downstream detours are not.
- Attack branch to the path tip: **did not snap-merge**.
- CONNECTED flash fired (t=42).
- Detour pixels: tracked 248, rejoined 170, faded 0, hp lost 0, stuck 0, all 170 moving.
- Upstream loop: max ploop 1 (cap 2; pdec also stops a second peel onto the same branch), 800 alive, 800 moving, 0 stuck.

Fair / dummy (memory cleared each run; 0 mid-match walls):

| run | AI hits | Player hits | HP AI / player | standing |
|---|---:|---:|---|---|
| dummy seed 11 | 500 | 0 | 10000 / 0 | AI ahead |
| fair 17 | 500 | 303 | 3940 / 0 | AI ahead |
| fair 11 | 500 | 381 | 2380 / 0 | AI ahead |
| fair 23 | 365 | 502 | 0 / 2700 | player ahead (was 265 / 4700 before the wrap-pace bump) |
| variant 19 | 28 | 502 | 0 / 9440 | player ahead (unchanged; this opening is not an outer wrap) |

Bar still holds: AI hits in all 4 fair/variant runs, leads in 2 of 4, dummy still steamrolls.

A03s 360x800@2: x4 avg 0.68 ms / max 12.80 ms; **x6** avg 1.11 ms / max 19.10 ms; no JS errors. Comfortably under the 16 ms avg / 80 ms max bars.

`tt.js test --all --name=pixelwar-0410-t1172`: **pass 67 / fail 0 / warn 3 / skip 4 / info 5**. Warns are the same pre-existing a03s hidden-control and uneven-scale letterboxing notes, not new game bugs. Report: `tough-tools/out/pixelwar-0410-t1172/report.md`.

## Gaps

- Seed 23 and the left-wrap variant still **lose** the straight-shot race, though 23 is closer (365 vs 502, player HP 2700 left).
- Mirror learning still not scored in these runs (memory cleared on purpose).
- Still no ship, sign, or publish.
