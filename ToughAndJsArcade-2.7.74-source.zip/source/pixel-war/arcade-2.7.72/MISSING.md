# Pixel War 0.4.10 — missing / held

Held (do not build): shapes hidden (t1122), cluster dropped (t1145/t1146), turn-based future-only, 3D, automatic speed–density coupling, friendly pass-through walls, mid-match defense rebuild, per-match AI memory wipe, difficulty picker.

Known play gap: when the AI circle is far off-center and the player aims straight through a mid-field gap (fair seed 23, left-wrap variant), the AI now reaches and scores via a short outer wrap (and a small wrap-pace bump on 23), but still often loses the race to a straight shot.
