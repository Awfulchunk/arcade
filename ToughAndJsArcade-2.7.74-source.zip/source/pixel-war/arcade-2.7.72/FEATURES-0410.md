# Pixel War 0.4.10 — feature checklist

Built from live 0.4.9 (Arcade 2.7.71, commit 41a0c78). 0.4.9 is left intact. This version is **not shipped**.

Statuses: **added now** (built in 0.4.10) · **carried** (already in 0.4.9) · **held** (on purpose).

## Added now (0.4.10) — AI (Jay t1169)

- [added now] The AI's **main path aims at the player's circle** and finishes on it.
- [added now] **Prep routing** through the thinnest/shortest walkable part of the defense, or around an end. If the AI circle is far off-center and the short gap is a head-on chute on the player's path, it takes the **shortest true outer wrap**.
- [added now] **Clash evaluator**, **mirror memory** (DELETE AI MEMORY still clears it), **build-then-surge** when the player's flow is split.
- [added now] Mid-match offense branches finish on the player's circle and are not launched into a dominated zone.

## Added now — loop-connect (Jay t1172)

- [added now] A branch end **anywhere inside the own main-lane hitbox**, or within a **finger-sized** pad of the lane edge (not only hugging the black line), CONNECTS. Downstream detours and **upstream loops** both work. The AI uses the same rule.
- [added now] **Loop cap** (2 rejoins per pixel) so flow cannot recirculate forever. After the cap, the pixel free-roams forward off the branch end (lives kept). Attack branches that only meet at the same destination (near the path tip) still do not snap-merge.
- [added now] A short **CONNECTED** flash (ring + label) at the junction on a successful connect.

## Added now — extras (t1171 / t1172, one-line reason each)

- [added now] Save keys `pixelwar.v410*` with a `v49` fallback. Reason: don't collide with live 0.4.9; old saves still load.
- [added now] Branch meter **280 → 400**. Reason: an around-the-end offense branch can finish on the circle.
- [added now] Path meter **520 → 640**. Reason: a wrapping main path can still finish on the circle.
- [added now] After a loss, remembered flow bump is capped at **1000** (was 800). Reason: match the live flow cap.
- [added now] DELETE AI MEMORY also drops the v49 and v48 keys. Reason: a clear should clear older memories.
- [added now] Help / about mentions the new AI and loop-connect. Reason: say what the game actually does.
- [added now] Off-center wrap also gets **+1 speed and +80 flow**. Reason: cheap help on the seed-23 straight-shot race without touching centered openings.

## Carried (locked rules, unchanged)

- [carried] Hitbox is a road: no centerline pull. Steady flow 200–1000. Random ricochet with a short leash. One-direction free roam past the path end.
- [carried] Defense locked after START; no mid-match wall / defense-line building; detour merge still rejoins without flow loss (now also for loops).
- [carried] Shapes hidden; no cluster; AI always smart with persistent memory + DELETE.

## Held on purpose

- [held] Shapes hidden (t1122), cluster dropped (t1145/t1146), turn-based future-only, 3D, automatic speed–density coupling, friendly pass-through walls, mid-match defense rebuild, per-match AI memory wipe, difficulty picker.
