// Arcade 2.7.65 = published 2.7.64 bundle: pixelwar:latest -> Pixel War 0.4.2; NEW slot pixelwar:v041 = Pixel War 0.4.1 (frozen); pixelwar:v03 unchanged.
// Every other slot payload, legacy variant, card and shell text byte-for-byte unchanged.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2765";
const BASE = "/workspace/game/build-ship2764/package-2.7.64/app/assets/index.html";
const OUT = process.argv[2];
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "91baeda3220497c2c3c54f530f78d9e825b769713dbbd5718abb8dc7a42252f1", "2.7.64 base hash mismatch: " + sha(src));
const N42 = fs.readFileSync(`${B}/out/pixel-war-0.4.2.html`, "utf8"), N41 = fs.readFileSync(`${B}/out/pixel-war-0.4.1.html`, "utf8");
assert(sha(N41) === "f3894f84d954042021d352673cfa28b6886c29d1a8902c0142e7b0accf249cde", "0.4.1 html != frozen");
const KL = "pixelwar:latest", K41 = "pixelwar:v041", K3 = "pixelwar:v03";
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); assert(i > 0 && j > i, "GAME_SRC block"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const before = slots(src); assert(before[KL] && before[K3] && !before[K41], "slot state"); assert(Object.keys(before).length === 164, "164 slots before");
const G0 = GS(src); assert(G0[KL] === N41, "live pixelwar:latest is 0.4.1");
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
let out = src.slice(0, before[KL][0]) + ex(N42) + src.slice(before[KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + ',\n"' + K41 + '":' + ex(N41) + out.slice(ei);
// card
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
const pw = GAMES.find((g) => g.id === "pixelwar"); assert(pw && pw.versions.map((v) => v.id).join() === "v03,latest", "card versions before");
const v41 = { ...pw.versions[1], id: "v041", name: "v0.4.1 – soft areas, knock-out, shape editor (2.7.64)", desc: pw.versions[1].desc.replace(" Your 0.3 / 0.4 settings carry over; 0.3 stays playable with its own saves.", " Kept as an older version with its own saves (pixelwar.v41)."), def: false };
const lat = { ...pw.versions[1], name: "v0.4.2 – Latest (live branches, sandbox, slow flow)",
  desc: "Pixel War 0.4.2 (test build). Prep: draw an ATTACK PATH and a DEFENSE LINE (walls reach the screen edges and follow your finger) while the enemy visibly draws its own plan. Then START: branches are opened live during the match, each with its own colour and meter; tap any path to get its own PACE, DENSITY, SPACING and LANE WIDTH sliders. Pixels flow slowly (sloth-slow at the low end), fade out gradually past their leash and can still collide while fading; head-on streams fill the whole lane and push or ricochet, with a visible bounce glow and sparkle on death. SANDBOX is a free two-sided playground. Shapes are hidden for now (still in CUSTOM GAME). Plain-words HUD that fits small phones. Your 0.4.1 settings carry over; 0.4.1 and 0.3 stay playable with their own saves.", def: true };
pw.versions = [pw.versions[0], v41, lat];
const gSuf = (gLine.slice(12).match(/;\s*$/) || [""])[0];
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + gSuf + out.slice(gE);
// legacy parts
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lLine = out.slice(lA + 1, lE);
const lJson = lLine.slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const r42 = {}; const p42 = legacyParts(N42, r42); assert(r42.jsFail.length === 0, "legacy js fail 0.4.2"); assert(joinParts(p42, N42) === legacyHtml(N42, {}), "parts mismatch 0.4.2");
const r41 = {}; const p41 = legacyParts(N41, r41); assert(r41.jsFail.length === 0, "legacy js fail 0.4.1"); assert(joinParts(p41, N41) === legacyHtml(N41, {}), "parts mismatch 0.4.1");
assert(JSON.stringify(LEG[KL]) === JSON.stringify(p41), "old legacy latest == 0.4.1 parts");
const LEG2 = { ...LEG, [KL]: p42, [K41]: p41 };
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
// verification
const after = slots(out); assert(Object.keys(after).length === 165, "165 slots after");
for (const k of Object.keys(before)) if (k !== KL) assert(after[k][2] === before[k][2], "slot text changed " + k);
const G1 = GS(out); assert(G1[KL] === N42 && G1[K41] === N41, "new payloads"); for (const k of Object.keys(G0)) if (k !== KL) assert(G0[k] === G1[k], "payload changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k])) === JSON.stringify([K41]), "only new slot is " + K41);
for (const k of Object.keys(LEG)) if (k !== KL) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const G64 = JSON.parse(gJson); 
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
assert(JSON.stringify(GAMES.filter((g) => g.id !== "pixelwar")) === JSON.stringify(base.filter((g) => g.id !== "pixelwar")), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.65", versionCode: 103, latest: "pixelwar:latest = Pixel War 0.4.2", newSlot: K41, v03: "unchanged", html042SHA256: sha(N42), html042Bytes: Buffer.byteLength(N42), html041SHA256: sha(N41), baseBundleSHA256_2764: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), cartridgeSlotsBefore: 164, cartridgeSlotsAfter: Object.keys(after).length, changedSlots: [KL], legacy: `css ${r42.css} js ${r42.js}`, menuOrder: GAMES.map((g) => g.id) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
