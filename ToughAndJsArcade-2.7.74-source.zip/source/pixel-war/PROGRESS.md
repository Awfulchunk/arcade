# Pixel War 0.4.7

Copied from 0.4.6. Jay t1154. Test build — not shipped, not published.

## AI
- Difficulty selector is hidden (menu button and Custom Game AI-level row). The code is still there.
- Every vs-AI start forces aiLevel=4 and aiLearn=1 (sandbox is unchanged).
- The AI no longer auto-picks a TAPERED lane (that pinched the stream to a point).
- At START it reads the player's finished paths and plants intercept walls (same wall API).
- In the match it reads every player path and branch, walls those that enter its half, flanks around the player's defense, opens branches sooner (~3s, then about every 8s), and shifts FLOW/density/width live toward the path that is getting through or closest to the player's circle. It walls earlier when enemy pixels close in on its circle.
- Persistent memory is still used (lessons, loss map, slider tune). Tune will not drop it below default flow 289 or lane width 5.
- AI branches inherit pace/density, at least medium width, and a real flow (about 75% of its main, minimum 420) so they are not a trickle.
- Review text: "The AI plays at full smart."

## Branch fill + path end (Jay's screenshot)
- The red AI branch was a tight single-file line that tapered into a fading tail. Blue main at FLOW 1000 / DENSITY 10 looked good.
- When a pixel peels onto a branch it is re-spread across that branch's full lane width (same hybrid fill as the circle), so branch streams fill like the main path.
- Past the end of a branch or the main path: pixels keep the stream's width and keep heading the path's final direction as one loose, wide-ish body. Slight natural wander only. No fan, no taper to a point, no curl or loop-back. Then fade on the short leash.

Saves: pixelwar.v47* (falls back from v46, then v45, then v44, then v43).
Lint + 3s headless load: 0 JS errors. No test suites. No phone tests. Not published.
