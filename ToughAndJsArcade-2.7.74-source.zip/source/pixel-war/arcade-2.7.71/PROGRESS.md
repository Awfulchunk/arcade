# Pixel War 0.4.9

Copied from 0.4.8 (test drop, not shipped). Jay t1163 / t1164 (2026-11-18): agreed to the longer branch meter, prep circle-move clearing the defense line with a refund, and a noticeable speed raise; also add the other features from the notes, then one hard test pass. Do not ship.

Test build only — not signed, not pushed, not published. No Arcade package was assembled.

## Changes
- Branch meter 140 → **280** (custom cap 400). AI uses the same meter, so a wrap around a wall end can reach the circle.
- Moving the circle in **prep** clears that side's defense strokes and refunds the wall meter so the line can be redrawn. After **START** the line stays locked, same as 0.4.8. Sandbox is unchanged.
- `paceMax` 31 → **38** (~23% faster across the 1–10 PACE range).
- Branch SHARE + AUTO SHARE are on the main HUD when a branch is selected (no longer only in hidden shapes / Custom Game). New branches default to SHARE 40 instead of 0. AUTO SHARE is saved in prefs.
- Version / saves: PIXEL WAR 0.4.9, keys `pixelwar.v49*` with fallback from v48…v43.
- Help text updated for the new prep-circle, meter, and share rules.
- Full audit checklist: FEATURES-049.md. Held on purpose: hidden shapes (t1122), dropped cluster, turn-based future-only.

## Hard test pass (one run, failed items only would have been re-run; none failed)

### tough-tools `node tt.js test index.html --all --name=pixelwar-049`
- RESULT: PASS — pass 67 · fail 0 · warn 3 · skip 4 · info 5. 165s. 0 JS errors. Chrome 83 / WV83 lint clean (pre-existing duplicate `__pw` hook-key warnings only).
- Warns (not failures): mech tap-each-control saw hidden/offscreen prep controls (BRANCH / GATE / ERASE and some slider buttons are hidden or below the fold on a03s during prep); visual uneven-scale on a03s and small (nearest-neighbour at a non-integer CSS scale — pre-existing canvas letterboxing).
- Report: /workspace/game/tough-tools/out/pixelwar-049/report.md

### AI-vs-scripted fight (seed 11, 1800 ticks) plus 0.4.9 checks
- Meters: paceMax 38, brMax 280, speed 1/5/10 = 9.5 / 22.17 / 38. Width 10 = radius 22, WIDE still capped.
- Prep circle-move: 2 defense pieces (wall used 164) cleared to 0 with refund and the “Defense line cleared — redraw it” message; redraw used 164 again. After START the line stayed locked (ERASE ignored, no draw-over, placeCircle refused, 2 pieces still there).
- A long branch used the full 280 meter (past the old 140 cap). New branch SHARE defaulted to 40. Widening 4→10 did not snap pixels to the new edges.
- AI circle hits: **83** (main 11; 3 branches opened, 3 reached, 0 wasted). Player circle hits: 0. Player pool burned: 1660. Adapts: 30. Lessons included flanks around the defense, intercepting the player's new branch, and feeding flow to paths that were getting through. 0 JS errors.

### A03s-profile perf (360x800 @2, CPU x4, ~8s live fight, flow 600)
- 0 JS errors. 481 sim ticks. Tick avg **0.58 ms**, max **9.60 ms**. Comfortable under the A03s budget. ~266 / 222 pixels active.

Saves: pixelwar.v49* (falls back from v48…v43).
Not published.

Staged at /workspace/game/requests/finished-ship/pixelwar-0.4.9-test/
HTML SHA-256: 50742947813aa86033658244a69682a5aec1fbb5cc28d319090cb3d8e3e03205 (170048 bytes)


## t1164 (in-place, still 0.4.9, not shipped)
- No defense-line / wall building during the match for player or AI. Mid-match AI rebuild/intercept loop removed. `wallBegin` hard-returns null for non-gate strokes after START (sandbox exempt). autoDefense and aiCounterStart cannot run after prep/lock. DEFENSE LINE button is hidden after START; a refused mid-match build is counted and never retried in a loop. Gates unchanged (`liveWall`).
- Detour merge (042 C2): a branch end that touches or comes near the same side's main path (or, simply, another of its own branches) connects. Pixels rejoin at the junction, keep their lives and count, and do not double-count toward the cap. A small ring+dot marks the junction. Attack branches that only meet at the path tip / enemy circle do not snap-merge. The AI can open a detour around the player's defense and rejoin.

### Affected-item hard test (one pass)
- Detour to main: connected (rj=65). Branch-to-branch: connected (rjTo=1). 112 pixels rejoined onto the main path, 0 faded at the branch end, 0 lives lost, cap respected.
- AI-vs-scripted fight (1800 ticks): mid-match wallBegin refused for the player; AI `wallBlockN` stayed 0; defense stroke counts/points unchanged after START. AI circle hits 48 (main 1, flank 8, intercept 39). Opened 3 (flank, intercept, detour); detour rejoined the main path (rj=90). 30 adapts. 0 JS errors.
