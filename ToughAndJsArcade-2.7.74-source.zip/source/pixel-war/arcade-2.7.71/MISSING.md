# Pixel War 0.4.9 — test build (not shipped)

Jay t1163: build, hard-test once, do not ship. Not published, no Pages push, no APK signed.

Held on purpose (see FEATURES-049.md):
- Shapes stay hidden (t1122).
- Cluster shape dropped.
- Turn-based mode is future-only.

Not done / gaps:
- No physical-phone playthrough of the 280 branch meter, prep circle-move refund, faster pace, or HUD SHARE / AUTO SHARE.
- Pulse / Wave, converge, and momentum stay Custom Game only (never locked for the main HUD).
- Difficulty code is still hidden, not deleted.
- Mid-match defense rebuild is hard-disabled after START (intentional, t1164).
- 042 C2 is resolved as detour merge (a branch drawn into the main path reconnects). Erase-branch still recalls to the circle.
- No Arcade assemble / sign / publish was started.

Saves use pixelwar.v49* with fallback from v48…v43.
