# Pixel War 0.4.9 — feature checklist

Audit of every Pixel War note, then what 0.4.9 does with it.
Sources: `requests/future/particle-game/` (SUMMARY.md, notes-transcript.md, design-doc-t1105.md, UNDERSTANDING.md, turn-based-option-FUTURE.md), `build-pixelwar042/MISSING.md`, and the PROGRESS / SHIP / MISSING files of 0.4.3–0.4.8.

Statuses: **done** (already in 0.4.8 and carried forward) · **added now** (built in 0.4.9) · **held** (on purpose, do not build).

## Added now (0.4.9)

- [added now] **No defense-line or wall building during the match** for player or AI (Jay t1164). The DEFENSE LINE button is hidden after START. Mid-match AI intercept/rebuild/autoDefense paths are removed or hard-blocked; a refused build increments a guard and is never retried in a loop. Gates still follow `liveWall`. Intercept walls at START still count as the one prep line, then the line locks.
- [added now] **Detour merge** (Jay t1164, resolves 042 C2): if a branch end is drawn into (touching or near) the same side's main path line/lane, the branch CONNECTS. Pixels at the end rejoin the main path at the junction and continue — lives and count kept, no double-counting toward the 200–1000 cap. A small ring+dot marks the junction. A branch may also merge into another of its own branches when that's simple (no 2-cycles). Ends that only meet at the same destination (near the path tip / enemy circle) do not snap-merge, so attack branches still run out. The AI can open a detour around the player's defense and rejoin.
- [added now] Branch meter raised from 140 to **280** (tuned so a wrap around a wall end can still reach the circle). Custom range cap raised 300 → 400. The AI uses the same `CFG.brMax` meter. (Jay t1163 #1)
- [added now] Moving your circle during **prep** clears that side's drawn defense line and **refunds** the wall meter so it can be redrawn. After **START** the line stays locked (ERASE still ignores it; no draw-over). Sandbox is unchanged. Same rule for both sides. (Jay t1163 #2)
- [added now] Pixel speed raised ~**23%** across the 1–10 PACE range by setting `paceMax` 31 → **38**. Custom Game still lets you set 6–90. (Jay t1163 #3)
- [added now] Branch **SHARE** slider and **AUTO SHARE** toggle are on the main HUD when a branch is selected (they were buried in the hidden shapes/legacy row, Custom Game only — 042 C1 / SUMMARY). AUTO SHARE is remembered in prefs.
- [added now] A new player branch keeps the default SHARE of **40** instead of being zeroed, so main-path pixels actually peel onto it unless you turn the slider down.

## Held on purpose

- [held] Shapes stay hidden (on hold, Jay t1122). They can still be turned on in Custom Game.
- [held] The cluster shape is dropped (Jay t1145 / t1146). It was never put back.
- [held] Turn-based mode is future-only (`turn-based-option-FUTURE.md`).
- [held] 3D / depth (042 C5).
- [held] Automatic speed–density coupling (“slow = wider, fast = thinner”). Superseded by independent PACE / DENSITY / LANE WIDTH / FLOW sliders (t1116 and later).
- [held] Friendly pixels passing through their own walls. Superseded: walls block both sides; **gates** are the friendly openings (t1097–t1101).
- [held] Mid-match defense rebuild / live walls for the defense line. Now hard-disabled after START (t1156 / t1158 / t1164). Gates in battle still follow `liveWall`.
- [held] Wipe AI memory at the end of every match. Superseded by persistent memory + DELETE AI MEMORY (t1134).
- [held] Difficulty picker. Hidden; the AI is always full-smart (0.4.7+). The old code is still in the file, not deleted.
- [held] Erasing a branch still recalls those pixels to the circle (the locked recycle rule). Detour merge (added now) is the way to send flow back onto the main path without losing it.
- [held] Pulse/Wave pattern, converge (SEPARATE/MERGE/REFORM), and formation momentum as HUD controls. They already exist in Custom Game and were never locked for the main HUD.
- [held] A printed visual reference sheet (not a game feature).

## Done (carried from 0.4.2–0.4.8)

- [done] Goal: streams of pixels leave your circle, follow your plan, and damage the enemy circle.
- [done] Prep: draw an attack path and a defense line before START. Both sides plan at the same time; you can see the enemy plan.
- [done] The path is a **visual direction guide**, not a rail / not a physical black line.
- [done] Hitbox is a **road**: forward tangent + edges only. No path-centerline attraction, snapping, or re-applied lateral offset (t1160).
- [done] Pixels move freely going straight inside the lane; they cannot leave the hitbox except by ricochet or past the path end.
- [done] Edges are a soft bound only when a pixel actually reaches them. Widening does not snap/hug the new sides; thinning still compacts.
- [done] Lane width 10 = the circle diameter (half-width capped at circle radius), including WIDE / LMAX.
- [done] Steady FLOW 200–1000 (default 289). Combined density + spacing into one DENSITY slider. Sliders do not move when the panel is scrolled (0.4.6).
- [done] Random ricochet with a short leash (t1140–t1148): unpatterned heading, short takeoff, then fade.
- [done] Past the path/branch end: one-direction free roam (loose wide group, no fan, no loop-back), then fade (t1152).
- [done] In-lane chip / knock, pixel HP 2, destroy + fade bits.
- [done] Defense line: required in prep; can be several pieces with a gap; chip/segment damage still applies. Locked after START (t1158). Same rule for the AI.
- [done] Gates as friendly openings in the line.
- [done] Branches: drawn from the main path, own color, own meter, own sliders; erase/redraw in battle is free (meter comes back). Must go around (not through) own walls. Detour merge: a branch drawn into the main path (or simply into another own branch) reconnects; pixels continue on that path; junction is marked.
- [done] Live branch sliders (PACE, DENSITY, LANE WIDTH, FLOW) per selected path.
- [done] Lane shapes: normal / wide / narrow / tapered / arrow (HUD button).
- [done] Pool / lives / recycle / recall; circle HP; match timer; pause / new / menu.
- [done] Sandbox: both sides editable any time, SIDE / STEP / REFILL, no win/lose.
- [done] Custom Game + stages + result stats (time, destroyed, interceptions, efficiency, circle hits, barrier damage, lives, branch redraws) + AI review.
- [done] AI is always smart: plans in prep, reads player path/line, opens branches toward gaps and wall ends, sets flow/width/density for the job, reacts to new player branches, concentrates on paths that hit, starves chipped ones, persistent memory, DELETE AI MEMORY button (t1134, t1160, t1161). Player and AI use the same rules and meters.
- [done] Shapes engine (areas, knock-out, recall, outline editor, AI shapes) remains in the file but hidden unless Custom Game turns it on (t1122).
- [done] `__tt` hook for tough-tools; Chrome 83 / WebView-safe single file; saves `pixelwar.v49*` with fallback from v48…v43.

## Established rules this build must not break

- Hitbox = road, no centerline pull.
- Steady flow 200–1000.
- Random ricochet with a short leash.
- One-direction free roam past the path end.
- Defense line locked after START.
- AI always smart, persistent memory, delete button.
- Player and AI use the same rules and meters.
