// Arcade 2.7.71 = published 2.7.70 bundle + pixelwar:latest 0.4.9 (new v047=0.4.7), papa-potato:latest 0.4.2 (new v041=0.4.1), swarm:latest 1.6.15 (new v1614=1.6.14). Everything else byte-identical.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2771", BASE = "/workspace/game/build-ship2770/out/index.html", OUT = process.argv[2] || B + "/out/index.html";
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "daa873e4dae1ed5bf527464899266a12bf89646cbb1db248ab53f6c1fc7e0e36", "2.7.70 base hash");
const rd = (f) => fs.readFileSync(`${B}/out/${f}`, "utf8");
const JOBS = [
 { card: "pixelwar", newKey: "v047", html: rd("pixel-war-0.4.9.html"), hsha: "50742947813aa86033658244a69682a5aec1fbb5cc28d319090cb3d8e3e03205", oldSha: "4552c821cfb9445d3528fb5c85a93876aeb17039f5819353c5b7ca0b1ee1aeb2",
   oldName: "v0.4.7 – smarter AI, branch fill, one-way end roam (2.7.70)", name: "v0.4.9 – Latest (detour merge, no mid-match walls, faster pixels)",
   desc: "Pixel War 0.4.9. No defense-line or wall building after START, for you or the AI. Draw a branch into your own main path (or another of your branches) and it CONNECTS: those pixels rejoin and keep going, marked by a small junction ring. Branch meter doubled (280), custom range to 400, pixels about 23% faster, SHARE / AUTO SHARE on the main HUD for a selected branch, new branches start at SHARE 40. Moving your circle in prep clears and refunds your defense line. Your 0.4.7, 0.4.6, 0.4.5, 0.4.4, 0.4.3, 0.4.2, 0.4.1 and 0.3 stay playable with their own saves.",
   order: "v03,v041,v042,v043,v044,v045,v046,latest" },
 { card: "papa-potato", newKey: "v041", html: rd("papa-potato-0.4.2.html"), hsha: "dbaa2cbf70714c5ae315776d6cdfd403f94f9ec69609970b8f87b16645290ac2", oldSha: "92f37ae8c8edea91aaa7", oldPrefix: true,
   oldName: "v0.4.1 – inventory, fit-to-screen, editor tray (2.7.62)", name: "v0.4.2 – Latest (no stuck states, rotate, object info)",
   desc: "Papa Potato 0.4.2: move anything in the editor and he no longer gets stuck sweeping or repeating a job. He peels AT the table wherever it is (even against the back wall or turned), reaches the exact shipping X, and moves that would trap him are refused. With the carry bag equipped he sets the sack on the floor by the table and peels the whole pack; with a sink he dumps the potatoes in it. New ROTATE button in the editor, and tapping any object shows its name and what it does on the right HUD. Command sliders are scroll-safe. Your 0.4.1 save carries over; 0.4.1, 0.3, 0.2 and 0.1 stay playable in their own slots.",
   order: "v01,v02,v03,latest" },
 { card: "swarm", newKey: "v1614", html: rd("swarm-v1.6.15.html"), hsha: "6b2846db7988bfee90dc96366345ae61a8d2c0013c9eb4f24421ceafc140f41b", oldSha: "9c3be799041a74e1589b364ba1d585f10f58ca1085c9f842c454e31f6a25a998",
   oldName: "v1.6.14 – Prior", name: "v1.6.15 – Latest",
   desc: "Turret AI panel is scroll-safe: a vertical swipe scrolls the command list and never moves a slider; only a mostly sideways drag on a slider track changes it, and +/− always work. Runs even if storage is blocked. Pixel/chiptune sounds, live range/panic/tag visuals, 7 guns, 7 defenses, 7 abilities, ammo + AMMO RACK retained.",
   order: null },
];
for (const j of JOBS) assert(sha(j.html) === j.hsha, "staged html sha " + j.card);
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
const before = slots(src); assert(Object.keys(before).length === 170, "170 slots before");
const G0 = GS(src);
for (const j of JOBS) { j.KL = j.card + ":latest"; j.KN = j.card + ":" + j.newKey; assert(before[j.KL] && !before[j.KN], "slot state " + j.card); j.old = G0[j.KL];
  assert(j.oldPrefix ? sha(j.old).startsWith(j.oldSha) : sha(j.old) === j.oldSha, "live latest = previous version " + j.card); }
// replace latest payloads (from the end of the file backwards so offsets stay valid)
let out = src; for (const j of [...JOBS].sort((a, b) => before[b.KL][0] - before[a.KL][0])) out = out.slice(0, before[j.KL][0]) + ex(j.html) + out.slice(before[j.KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + JOBS.map((j) => ',\n"' + j.KN + '":' + ex(j.old)).join("") + out.slice(ei);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
for (const j of JOBS) { const g = GAMES.find((x) => x.id === j.card); const ids = g.versions.map((v) => v.id); if (j.order) assert(ids.join() === j.order, "card versions before " + j.card + " " + ids);
  assert(ids[ids.length - 1] === "latest" && !ids.includes(j.newKey), "latest last " + j.card);
  const L = g.versions[g.versions.length - 1]; const kept = { ...L, id: j.newKey, name: j.oldName, def: false }; const lat = { ...L, name: j.name, desc: j.desc, def: true };
  g.versions = [...g.versions.slice(0, -1), kept, lat]; }
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + (gLine.slice(12).match(/;\s*$/) || [""])[0] + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lJson = out.slice(lA + 1, lE).slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const LEG2 = { ...LEG };
for (const j of JOBS) { const rn = {}, pn = legacyParts(j.html, rn); assert(rn.jsFail.length === 0, "legacy js fail new " + j.card + " " + JSON.stringify(rn.jsFail).slice(0, 300)); assert(joinParts(pn, j.html) === legacyHtml(j.html, {}), "parts mismatch " + j.card);
  const ro = {}, po = legacyParts(j.old, ro); assert(ro.jsFail.length === 0, "legacy js fail old " + j.card); assert(JSON.stringify(LEG[j.KL]) === JSON.stringify(po), "old legacy latest == old parts " + j.card);
  LEG2[j.KL] = pn; LEG2[j.KN] = po; }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out); assert(Object.keys(after).length === 173, "173 slots after");
const changed = JOBS.map((j) => j.KL), added = JOBS.map((j) => j.KN);
for (const k of Object.keys(before)) if (!changed.includes(k)) assert(after[k][2] === before[k][2], "slot text changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k]).sort()) === JSON.stringify([...added].sort()), "only new slots");
const G1 = GS(out); for (const j of JOBS) assert(G1[j.KL] === j.html && G1[j.KN] === j.old, "payloads " + j.card);
for (const k of Object.keys(G0)) if (!changed.includes(k)) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (!changed.includes(k)) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
const cards = JOBS.map((j) => j.card);
assert(JSON.stringify(GAMES.filter((g) => !cards.includes(g.id))) === JSON.stringify(base.filter((g) => !cards.includes(g.id))), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
for (const j of JOBS) { const a = GAMES.find((g) => g.id === j.card), b = base.find((g) => g.id === j.card); const { versions: va, ...ra } = a, { versions: vb, ...rb } = b; assert(JSON.stringify(ra) === JSON.stringify(rb), "card fields " + j.card); assert(JSON.stringify(va.slice(0, -2)) === JSON.stringify(vb.slice(0, -1)), "older versions untouched " + j.card); }
fs.writeFileSync(OUT, out);
const info = { arcadeVersion: "2.7.71", versionCode: 109, baseBundleSHA256_2770: sha(src), bundleSHA256: sha(out), bundleBytes: Buffer.byteLength(out), cartridgeSlotsBefore: 170, cartridgeSlotsAfter: 173, changedSlots: changed, newSlots: added,
  games: JOBS.map((j) => ({ card: j.card, latestSHA256: j.hsha, keptSlot: j.KN, keptSHA256: sha(j.old), versions: GAMES.find((g) => g.id === j.card).versions.map((v) => v.id) })) };
fs.writeFileSync(OUT.replace(/\.html$/, "") + ".assemble.json", JSON.stringify(info, null, 2)); console.log(JSON.stringify(info, null, 2));
