# PIXEL WAR 0.4.2: MISSING.md (notes/docs/chat audit)
Re-verified against the FINAL 0.4.2 code (index.html at the time of the run) and the final suites; every 0.4.2 row below names the soft042 test that proves it.
Audited: chat-pixelwar-transcript.txt (every Jay line c7..c143), notes-transcript.md (every Jay turn, Tough_1..35 + docx tail), design-doc-t1105.md (= c126), docx-1/docx-2 "Design Update", UNDERSTANDING.md, SUMMARY.md, plus Jay's t1116, t1122, and the parent's t1123-t1126 steering asks.
Source key: cNN = line of chat-pixelwar-transcript.txt; nNNNN = line of notes-transcript.md (Tough_n page); t1105 = design doc; t1116/t1122 = Jay's latest messages; U# = UNDERSTANDING.md item.
Status key: DONE-0.4.1 (already in the build I copied) | 0.4.2 (asked in t1116/t1122, in this build) | HIDDEN (code kept, hidden per Jay) | AMBIGUOUS (I did not invent; default stated) | FUTURE (noted, not built).
Statuses were assigned against the 0.4.1 code plus the t1116/t1122 asks; the final column "check" says where the test lives.

## A. Things Jay asked for that 0.4.1 lacked (now 0.4.2 scope)
| # | Item | Source | Status |
|---|------|--------|--------|
| A1 | HUD in plain words, short labels, grouped, no jargon | t1116 | 0.4.2 |
| A2 | Each side draws a DEFENSIVE line (walls) as well as the main path before START | t1116, c66, n334 | 0.4.2: START stays dim until path >= 60u AND wall >= 40u; the prep timer auto-draws a defense if you run out of time; stage 1 has no walls so it is not required there. Test: "DEFENSE REQUIRED", ui2 |
| A3 | Both sides see each other's main path being drawn during prep (AI draws visibly) | t1116 (overrides the older "can't see until START", c130 list, Tough_20/21) | 0.4.2: the AI plans from the circle positions only, draws its path + walls over ~3 s, replans when you move your circle; the AI never reads your path. Test: "AI DRAWS ITS MAIN PATH AND WALLS IN PREP" |
| A4 | Speed far slower; fastest is a "sloth running" | t1116, t1122 | 0.4.2: PACE 1..10 = 6..24 units/s (fastest crosses the 500-unit field in ~21 s, slowest ~83 s); Custom 'Fastest pace' rescales it. Test: soft042 "SLOTH SPEED". AI-vs-AI matches last 17 s (pace 10) to 65 s (pace 1) |
| A5 | Destroyed pixels split/sparkle into 1x1 bits then vanish; ricochet shows a visible bounce only | t1116 | 0.4.2: 4 bits per death, pooled (1800), max 20 bursts per tick, fade in ~1 s; a ricochet glows and drops a fading trail so the bounce shows as a V. Tests: "SPARKLE", head-on test (bounce counters) |
| A6 | Live sliders: hitbox/lane width, density, spacing (+pace, flow) | t1116, t1122 | 0.4.2: PACE, DENSITY, SPACING, LANE WIDTH, FLOW rows with big - / + buttons, applied live. Test: "LIVE SLIDERS", ui2 |
| A7 | Branches drawn only during the match (not prep), each its own colour and own meter | t1116, t1122, c66, n332 | 0.4.2 (5 colours, own meter bar and chip each). Test: "BRANCH only in the match", ui2 |
| A8 | Tap a branch or the main path -> panel of per-path sliders (density, spacing, lane width, flow, pace) for that path only | t1122 | 0.4.2 (a branch starts with a copy of the main settings, then keeps its own). Test: "PER-PATH SLIDERS", ui2 |
| A9 | Wall drawing reaches the screen edges and tracks the finger smoothly | t1122 | 0.4.2: walls go to x=0, x=360 and y=500; 3-unit steps follow the finger 1:1 (coalesced pointer events). Gap left: walls still cannot start inside 30u of your own circle. Test: "WALLS reach the screen edges", ui2 |
| A10 | HIDE shapes in-game (arrow, wedge, line, diamond, double, spiral, ring, custom, outline editor, shape cooldown buttons); keep code; Custom Game hidden flag. Main-path lane width/shape (wide/thin) stays | t1122 (overrides c114 "shapes are abilities", c139) | HIDDEN |
| A11 | Turn-based option (later) | t1122 | FUTURE (note only, not built): requests/future/particle-game/turn-based-option-FUTURE.md; not built |
| A12 | Leash 1.5x (72 -> 108) and pixels past it fade out gradually, still able (less likely) to collide while fading | t1123 | 0.4.2: leash 108, fade 1.2 s (Custom: leash, fade time). Tests: "LEASH is 1.5x", "FADE is gradual ..." |
| A13 | Two head-on overlapping main paths: both streams spread over the whole lane (symmetric, no edge hug), collide across the width, push/ricochet | t1124 | 0.4.2: found and fixed in the engine: the old outward spacing push piled pixels on the lane edges; now exit offsets are uniform across the lane, the pull to the line is weak, and SPACING adds sideways mixing instead of a one-way push. Measured head-on: followers fill +-9.4 of +-11.5 each, centred (mean ~0), 50% either side. Test: "HEAD-ON" |
| A14 | Lane width slider: bigger max, smaller min | t1124 | 0.4.2: lane half-width 1.9 .. 41.5 units (0.4.1: 3.75 .. 33), default 11.5. Test: "LANE WIDTH slider" |
| A15 | Mechanics, performance and physics before pretty pixels | t1124 | 0.4.2: A03s emulation, cap 4000 per side: x1 60 fps, x4 59.6, x6 46 fps (0.4.1 was 32-39 at x6). Sparkle bits capped, no per-frame blur, lane bands baked once. |
| A16 | Exit spread at the circle mouth about the lane width | t1125 | 0.4.2. Gap (honest): a lane wider than the circle (half-width above ~21 units, LANE WIDTH 7 to 10) cannot be matched at the mouth, the exit is limited to 95% of the circle radius. Test: "EXIT SPREAD" |
| A17 | After a ricochet the pixel keeps its heading (no steering back) until it fades or is hit again | t1125 | 0.4.2 (path followers and path-end pixels; shape-area members still use knock-out and rejoin, HIDDEN with the shapes). Test: "AFTER A RICOCHET the heading stays straight" |
| A18 | Hot Seat becomes a free SANDBOX: both sides editable any time, live sliders for either, pause/step/reset, no win/lose unless optional | t1126 | 0.4.2: menu SANDBOX button (Custom 'Players = SANDBOX'); SIDE, STEP, REFILL, PAUSE; Custom option to let a circle end the game. Test: "SANDBOX", ui2 |
| A19 | Plain-words HELP | final steps | 0.4.2 (10 short paragraphs, no jargon). Test: ui2 "HELP is plain words" |

## B. Discussed, in 0.4.1 already (checked against code, no action)
| Item | Source | Status |
|------|--------|--------|
| Wall meter never makes a full line (gaps guaranteed) | c12, c66, n13 | DONE-0.4.1 (wallMax 220 < 360 wide) |
| Circle placed anywhere along the bottom strip; Jay vs AI; pixels damage the circle | c62, n15 | DONE-0.4.1 |
| Main path from a meter, locked at START, pixels follow indefinitely, then go straight and drift | c12, c66, c69, n19, n1584 | DONE-0.4.1 |
| Path end: gradual spread ("fluffed"), 2-inch leash recall | n887, n1584, U8 | DONE-0.4.1, CHANGED in 0.4.2 (A12): leash 108 units + gradual fade |
| Pixel 2 HP, 1 damage, 2x2 constant, never fight or shoot | c12, c73, n23, t1105 | DONE-0.4.1 |
| 10,000 pool = circle HP; 20 lives per pixel; each enemy hit burns 20; recycle | c114, c117, c119 | DONE-0.4.1 |
| Walls block both sides, own pixels do no damage, enemy damages only the cell hit, 1000 HP / 5 dmg | c12, c120, n27, n336 | DONE-0.4.1 |
| Deflect back toward where they came from, with ricochet chance both sides | n27, n849, c62 | DONE-0.4.1 |
| Density-scaled ricochet (packed pixels bounce more, esp. vs loose enemy) + hybrid angle/speed/neighbours | c114, t1105 | DONE-0.4.1 (FULL HYBRID default) |
| Release rate separate from speed; straight out of the circle | n1456, n1460, c114 | DONE-0.4.1 |
| Branches only from main path, own meters, pull pixels by a share slider, go around (never over) walls | c66, n441, n616 | DONE-0.4.1 |
| Branch erase is free (frees its meter); redraw mid-match | n1717, n1751, U7 | DONE-0.4.1 (CFG.brWaste 0) |
| Gates (friendly-only openings in walls) | t1105, c133 | DONE-0.4.1 |
| AI: same rules/no extra stats, makes its own formations, learns, memory wiped at end, review | n1273, n1357, c133 | DONE-0.4.1 |
| Difficulty Easy/Normal/Hard/Brutal (decisions only); 4 progression stages; stats screen | t1105, c133 | DONE-0.4.1 (doc says "Expert", code says Brutal: cosmetic) |
| Free-wander hitbox area, knock-out, recall past 2-inch leash from the shape edge | c139, c141 | DONE-0.4.1, then HIDDEN under A10 |
| Lane widths wide ~5x / thin hugging; arrow bubble up to ~3x | t1111, t1112, t1114 | DONE-0.4.1 (wide/thin stay visible; arrow lane lives with shapes) |
| Ring only in Custom Game | c114, U13 | DONE-0.4.1 |
| 4,000 pixels on screen default (A03s), "as many as possible" | c109 | DONE-0.4.1 (perf-capped, 10,000 in Custom) |
| Custom Game holds every constant and every unpicked option | standing rule | DONE-0.4.1 |

## C. Discussed but NOT in the game before 0.4.2 (audit finds)
| # | Item | Source | Status / decision |
|---|------|--------|-------------------|
| C1 | Auto-split ON/OFF button for branch share, in the HUD (Tough_7 answer "A ... off and on setting for auto play") | n439 | CFG.autoDist exists (Custom Game only). Ambiguous wording ("auto play"). NOT built into the HUD (it did not fit the slider panel); stays in Custom Game. Branch FLOW is a per-branch slider instead. |
| C2 | Erasing a branch returns its pixels to the main path (assistant suggestion that Jay then accepted with "go your route") | n1717, n1751 | AMBIGUOUS. Today they go home to the circle (recall) and re-enter. Not changed; Jay never said which. |
| C3 | Branches can have their own formation/shape | n510, t1105 | HIDDEN with A10 (code stays). |
| C4 | "Pixels at path end look bigger/fainter, fan out" (sketch 04) | U5, U2 | Render only, constant 2x2 kept; fade along the drift is the only change. AMBIGUOUS (Q2 default). |
| C5 | "3D" formations | n35 | NOT BUILT, unclear (top-down game). Noted only. |
| C6 | Visual reference sheet (colours, line widths, HUD proportions) from Jay's mockup | n1265 | Not done; Jay's Paint Studio look kept (white field, black path, soft yellow areas, blue/red stipple). |
| C7 | "No unnecessary visual effects that obscure individual pixels; readability over spectacle" | n1262 | Respected: sparkle bits are 1x1, capped, short-lived (A5). |
| C8 | Two paths colliding: path cut short so pixels go off freely, shown in a test picture | c121 | DONE-0.4.1 test scene; kept in hits. |
| C9 | Wall repair / draw defence during combat | n1717-1753 | Live wall drawing already allowed (CFG.liveWall 1). |
| C10 | Hot-seat 2-player | Custom Game option | REPLACED by the free SANDBOX (A18, t1126). |
| C11 | "Shapes originate from the circle too" | c76 | DONE-0.4.1, HIDDEN under A10. |
| C12 | 2-minute time limit | not Jay's | invented in 0.4 (not requested by Jay). With the slower speeds the default is now 300 s (Custom range 30..300 s). |
| C13 | Exact open items: ricochet model, speed/density relation, branch meter cost, recall distance, formation recovery, particle limits | t1105 sec.16 | Left open by Jay ("keep open until tested"); defaults in CFG. Not decided here. |
| C14 | Density vs spacing vs lane width: the three are coupled (spacing ~ sqrt(area / count)) | t1116 | AMBIGUOUS. Mapping used (documented in HELP): WIDTH = half-width of the box, DENSITY = pull of pixels toward the line (denser along the line), SPACING = looseness (extra sideways mixing where the stream is crowded, so it spreads over the whole lane). Final code, checked by test "LIVE SLIDERS". |
| C15 | "Light brisk walk" / "sloth running" scale | t1116, t1122 | AMBIGUOUS in units; pace slider range chosen by the builder: fastest 24 u/s = 21 s across the field, slowest 6 u/s = 83 s (see A4). One Custom Game number (Fastest pace) rescales everything. |
