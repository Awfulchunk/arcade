# Pixel War 0.4 - ricochet / deflection model (ricoMode = FULL HYBRID, default)

Per contact between an A pixel and a B pixel (contact radius 3.5, 12-tick cooldown):

1. Base chances come from Custom Game: miss-ricochet `mp` (20%) and push-away `rp`.
2. ANGLE (`gl` = 1 glancing .. 0 head-on, from the two velocity vectors): `am = min(.9, 2*mp*gl)`, `ar = min(.95, 2*rp*gl)`; HYBRID/FULL use the mean of base and angle value (ANGLE mode uses the angle value only).
3. CLOSING SPEED (`sfv` = relative speed along the contact normal / (speedA+speedB), 0..1.5), weight `kSpeed` (default 100%):
   `survive *= 1 - k*(sfv-0.5)`  and `push *= 1 + k*(sfv-0.5)`. Fast head-on hits push farther and are survived less; slow brushes glance.
   Displacement distance base = `0.6 * (1 + 0.8*min(1.2, sfv))`; deflection spin `0.2 + 0.4*gl`.
4. DENSITY / NEIGHBOUR PACKING: `rho` = same-side pixels in the 3x3 cells (12x12 units) around each pixel.
   `dr = (rho_A - rho_B) / rhoRef` (Custom: Density reference). Per side:
   `survive = clamp(p*(1 +- kSurv*dr), 0, survMax)`, `push = clamp(p*(1 +- kPush*dr), 0, pushMax)`;
   displacement is also scaled by `clamp(1 -/+ 0.25*dr, .5, 1.8)`: the denser side moves less, the looser side more.
5. A formation member hit by this also calls `shock()` (see formation health: stretch, break, reform).

Modes: RANDOM (flat chances), ANGLE, HYBRID (angle + density, the 0.3 rule), FULL HYBRID (all of the above).
Stage 4 (Strategic) gates FULL HYBRID; stages 1-3 limit it to HYBRID. Quick Match, Free Play and Custom Game have everything.
Verified in `tests/soft04.cjs` (angle, speed, packing each measured over 4000 trials with both sides otherwise identical).
