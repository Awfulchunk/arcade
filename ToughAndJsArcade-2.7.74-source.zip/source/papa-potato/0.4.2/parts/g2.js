/* ---- 0.3 redraw: every visible object reads at a glance (top-down, mock 0.1b style) ---- */
function drawShipChute(){drawChuteBase();
  var cx=wx(chute.cx),y0=wy(GEO.ship.top),yl=wy(chute.lip),mw=ws(chute.mouthW);
  /* red up-chevrons inside the funnel: the intake pulls UP into the wall */
  for(var i=0;i<3;i++){var yy=Math.round(y0+(yl-y0)*(0.30+i*0.22)),sp=Math.max(2,Math.round(ws(2)*(0.8+i*0.3)));
    for(var d=0;d<sp;d++){R(cx-d-1,yy+d,2,1,"#d04050");R(cx+d,yy+d,2,1,"#d04050");}}
  /* hazard stripe on the lip */
  var half1=Math.round(mw*0.50),bl=Math.max(2,ws(2.2));for(var x=-half1+2,n=0;x<half1-2;x+=bl,n++)R(cx+x,yl+2,bl,Math.max(1,ws(1.2)),n%2?"#2a2a24":"#e0b020");}
function drawReturnChute(){var G=GEO.ret,x0=G.mouthX,x1=GEO.WALL?RW-WALL:93,y=G.y,hh=G.w/2+0.5,len=x1-x0;
  wr(x0+1,y-hh+2,len,hh*2,"rgba(0,0,0,0.28)");
  wr(x0,y-hh,len+0.5,hh*2,"#323830");wr(x0,y-hh+0.4,len+0.5,hh*2-0.8,"#5a6258");wr(x0,y-hh+1.4,len+0.5,hh*2-2.8,"#6a7268");
  wr(x0,y-hh,len+0.5,1.4,"#9aa49a");wr(x0,y+hh-1.6,len+0.5,1.6,"#3a4038");
  /* pipe rings */
  var rx=[x0+3,x0+9,x0+15];for(var i=0;i<rx.length;i++){wr(rx[i],y-hh-0.8,1.4,hh*2+1.6,"#3a4038");wr(rx[i],y-hh-0.8,0.7,hh*2+1.6,"#7a8478");}
  /* green arrows pointing OUT (west) */
  for(var a=0;a<2;a++){var ax=x0+5.5+a*6,ay=y;for(var d=0;d<3;d++){wr(ax+d*0.9,ay-d*0.9,1,1,"#3ad070");wr(ax+d*0.9,ay+d*0.9,1,1,"#3ad070");}}
  /* wall flange */
  wr(x1-0.5,y-hh-2,4.5,hh*2+4,"#3a4038");wr(x1-0.5,y-hh-2,1,hh*2+4,"#8a9088");
  wr(x1+1,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+1,y+hh-0.2,1.2,1.2,"#c0c8c0");
  /* the open mouth */
  var mx=wx(x0),my=wy(y);oval(mx,my,ws(2.6),ws(hh+0.6),"#9aa49a");oval(mx,my,Math.max(1,ws(2.0)),ws(hh-0.2),"#12141a");oval(mx+1,my,Math.max(1,ws(1.2)),ws(hh-1.2),"#06070a");
  /* spill tray on the floor under the mouth */
  wr(x0-7,y-hh+0.5,6,hh*2-1,"rgba(40,50,40,0.22)");for(var t=0;t<3;t++)wr(x0-6+t*2,y-hh+1,0.6,hh*2-2,"rgba(200,210,200,0.18)");}
function drawTable2(){var G=GEO.table,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  /* cutting board (where the potato sits while he peels) */
  var bx=wx(40),by=wy(G.y0+4),bw=ws(20),bh=ws(12);
  R(bx+1,by+1,bw,bh,"rgba(0,0,0,0.25)");R(bx,by,bw,bh,"#8a6a30");R(bx+1,by+1,bw-2,bh-2,"#d8b878");R(bx+1,by+1,bw-2,1,"#ecd29a");
  for(var j=0;j<5;j++)R(bx+3+j*Math.max(2,Math.round(bw/6)),by+3+(j%2)*2,Math.max(2,Math.round(bw/9)),1,"#b8985c");
  /* knife resting beside the board */
  var kx=wx(62),ky=wy(G.y0+9);R(kx,ky,Math.max(3,ws(3.4)),Math.max(2,ws(1.8)),"#3a2a20");R(kx-Math.max(5,ws(5.5)),ky,Math.max(5,ws(5.5)),Math.max(2,ws(1.5)),"#c8d0d8");R(kx-Math.max(5,ws(5.5)),ky,Math.max(5,ws(5.5)),1,"#f0f4f8");}
function drawBed(){var cx=GEO.mat.x,cy=GEO.mat.y,mw=GEO.mat.w,mh=GEO.mat.h;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.25)");R(x,y,w,h,"#3a3a50");R(x+1,y+1,w-2,h-2,"#e8e4d4");
  /* blanket (blue, folded edge) over the east two thirds; pillow at the west end */
  var bw=Math.round(w*0.66);R(x+w-bw-1,y+1,bw,h-2,"#4a6aa8");R(x+w-bw-1,y+1,bw,Math.max(2,Math.round(h*0.22)),"#6a8ac8");
  for(var i=2;i<bw-2;i+=4)R(x+w-bw-1+i,y+Math.round(h*0.3),1,h-Math.round(h*0.3)-2,"#3a5a98");
  R(x+2,y+2,Math.max(3,ws(4.4)),h-4,"#fffaf0");R(x+2,y+2,Math.max(3,ws(4.4)),1,"#ffffff");R(x+2,y+h-3,Math.max(3,ws(4.4)),1,"#c8c0a8");
  R(x,y,w,1,"#6a6a88");}
function drawCooler2(){var G=GEO.cooler,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#1c3a5a");R(x+1,y+1,w-2,h-2,"#3a6a9a");R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+Math.round(h*0.62),w-2,1,"#24405a");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),Math.max(1,ws(1.5)),"#e8eef4");   /* handle */
  /* a can of food on the lid (the stock lives in here) */
  var cw=Math.max(3,ws(3.4)),chh=Math.max(3,ws(3.6)),cx0=x+Math.round(w*0.12),cy0=y+Math.round(h*0.12);
  R(cx0,cy0,cw,chh,"#7a3a10");R(cx0,cy0+1,cw,chh-2,"#e0a040");R(cx0,cy0,cw,1,"#f0e0b0");R(cx0+1,cy0+Math.round(chh/2),Math.max(1,cw-2),1,"#b04020");}
function drawStool(){var x=wx(GEO.stool.x),y=wy(GEO.stool.y),r=Math.max(4,ws(3.8));
  oval(x+1,y+1,r,r,"rgba(0,0,0,0.28)");oval(x,y,r,r,"#3a2410");oval(x,y,r-1,r-1,"#6a4a28");oval(x,y,Math.max(2,r-2),Math.max(2,r-2),"#9a7a48");oval(x-1,y-1,Math.max(1,r-4),Math.max(1,r-4),"#b49458");}
function drawPileShadow(){var G=GEO.pile;ctx.fillStyle="rgba(40,30,16,0.22)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+1),ws(G.rx+4),ws(G.rz+2),0,0,6.28);ctx.fill();
  ctx.fillStyle="rgba(30,22,10,0.16)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+2),ws(G.rx-4),ws(G.rz-2),0,0,6.28);ctx.fill();}
/* ---------- the pile: 0.2 look (stacked tiers), spread wider and lower along the bottom wall ---------- */
function shadeHex(h,f){var n=parseInt(h.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function c(v){v=Math.round(v*f);return Math.max(0,Math.min(255,v));}return"rgb("+c(r)+","+c(g)+","+c(b)+")";}
var LVF=[0.60,0.74,0.90,1.08,1.25,1.42];
function buildPile(){POS=[];ORDER=[];TIER=[];var G=GEO.pile,cx=G.cx,base=G.base,rx0=G.rx,rz0=G.rz,idx=0;
  var LF=LIFT;
  for(var t=0;idx<PILEMAX;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(100*sc*sc):90;TIER.push(idx);
    for(var j=0;j<cap;j++,idx++){var r=Math.sqrt((j+0.5)/cap),th=j*2.39996+t*1.3;
      var x=cx+rx0*sc*r*Math.cos(th)+(srng(idx*5+2)-0.5)*3,z=base+rz0*sc*r*Math.sin(th)+(srng(idx*3+7)-0.5)*2.2;
      POS.push({x:x,y:z-Math.min(t,9)*LF,z:z,t:t,vi:idx%3,fl:(idx*7)%2});}}
  MAXVIS=POS.length;ORDER=POS.map(function(p,i){return i;});ORDER.sort(function(a,b){var pa=POS[a],pb=POS[b];return pa.t!==pb.t?pa.t-pb.t:pa.y-pb.y;});}
function withCtx(c2,fn){var o=ctx;ctx=c2;try{fn();}finally{ctx=o;}}
function mkSprite(w,h,fn){var c=document.createElement("canvas");c.width=w;c.height=h;withCtx(c.getContext("2d"),fn);return c;}
function buildSprites(){SPR=[];SPRS=[];var sizes=[2.9,3.3,3.7];
  for(var vi=0;vi<3;vi++){var sp=Math.max(3,Math.round(sizes[vi]*k)),hw=Math.max(2,Math.round(sp)),hh=Math.max(2,Math.round(sp*0.72)),w=2*hw+6,hgt=2*hh+7;
    for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++){var base=["#4a2810","#6a4020","#8a5a28","#c48a48"],f=LVF[lv];
      var pal=[shadeHex(base[0],f*0.9),shadeHex(base[1],f),shadeHex(base[2],f),shadeHex(base[3],f)];
      for(var sh=0;sh<2;sh++){(function(sh2){var spr=mkSprite(w,hgt,function(){if(sh2)oval(hw+3+1,hh+4+1,hw+1,hh,"rgba(0,0,0,0.20)");potato(hw+3,hh+3,sp,false,!!fl,0,pal);});
        spr.cx=hw+3;spr.cy=hh+3;(sh2?SPRS:SPR)[(vi*6+lv)*2+fl]=spr;})(sh);}}}
  PEELSPR=[];var pcol=[["#f5e0a8","#e8c070","#b08838"],["#e8c070","#d4a04a","#9a7430"],["#f0d890","#c8a040","#8a6a2a"]];
  var pats=[[".XX.","X..X","...X"],["XX..",".XXX","...."],[".X.","X.X",".XX"],["XXX.","...X",".XX."]];
  for(var q=0;q<12;q++){var pc=pcol[q%3],pt=pats[q%4];PEELSPR[q]=mkSprite(6,5,function(){for(var yy=0;yy<pt.length;yy++)for(var xx=0;xx<pt[yy].length;xx++)if(pt[yy][xx]==="X"){R(1+xx,1+yy+1,1,1,pc[2]);R(1+xx,1+yy,1,1,pc[(xx+yy)%2]);}});}}
/* mess slots: the first peels land right where he works (south of the table), later ones spread out; sorted by distance so the heap grows from his feet */
function buildMess(){MESSPOS=[];var G=GEO.mess,T=GEO.table;
  for(var i=0,tries=0;i<MESSVIS&&tries<6000;tries++){var r=Math.sqrt((i+0.5)/MESSVIS),th2=(i+tries)*2.39996,x=G.cx+G.rx*r*Math.cos(th2)+(srng(tries*3+1)-0.5)*3,y=G.cy+G.rz*r*Math.sin(th2)+(srng(tries*7+3)-0.5)*3;
    if(x<WALL+3||x>RW-WALL-3||y<T.y1+3||y>GEO.pile.base-GEO.pile.rz-8)continue;
    if(Math.abs(x-GEO.mat.x)<GEO.mat.w/2+2&&Math.abs(y-GEO.mat.y)<GEO.mat.h/2+2)continue;
    MESSPOS.push({x:x,y:y,q:(i*5+tries)%12});i++;}}
function renderPile(n){if(!pileLayer||pileLayer.width!==W||pileLayer.height!==H){pileLayer=document.createElement("canvas");pileLayer.width=W;pileLayer.height=H;pileKey=-1;}
  if(pileKey===n)return;pileKey=n;renders.pile++;var c=pileLayer.getContext("2d");c.clearRect(0,0,W,H);
  /* 0.3 shading: a fixed, gentle light ramp by tier (never relative to the heap height) and a soft shadow only under the bottom tier, so a big pile stays readable */
  for(var q=0;q<ORDER.length;q++){var i=ORDER[q];if(i>=n)continue;var p=POS[i],lv=Math.min(4,2+Math.floor(p.t/3)),sp=(p.t===0?SPRS:SPR)[(p.vi*6+lv)*2+p.fl];c.drawImage(sp,wx(p.x)-sp.cx,wy(p.y)-sp.cy);}}
var flying={},messVer=0;
function renderMess(n){if(!messLayer||messLayer.width!==W||messLayer.height!==H){messLayer=document.createElement("canvas");messLayer.width=W;messLayer.height=H;messKey="";}
  var key=n+"|"+messVer;if(messKey===key)return;messKey=key;renders.mess++;var c=messLayer.getContext("2d");c.clearRect(0,0,W,H);
  for(var i=0;i<n&&i<MESSPOS.length;i++){if(flying[i])continue;var p=MESSPOS[i];c.drawImage(PEELSPR[p.q],wx(p.x)-3,wy(p.y)-2);}}
function drawStatic(){drawFloor();drawWalls();
  /* hidden props (0.2.1 t1027, still hidden): drawPipes drawShelf drawToolRack drawMachinePad x3 drawDrain drawPeelBin drawBucket drawSack x4 drawCrate x3 drawLamp; 0.3 also hides drawCentreStripe and the old drawChuteBase/drawCooler/drawMat/drawTable */
  drawPileShadow();drawBed();drawTable2();drawCooler2();drawStool();drawShipChute();drawReturnChute();}
function ensureStatic(){if(staticLayer&&staticLayer.width===W&&staticLayer.height===H)return;drawStatic();var copy=document.createElement("canvas");copy.width=W;copy.height=H;copy.getContext("2d").drawImage(cv,0,0);staticLayer=copy;}
