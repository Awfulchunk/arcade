/* ---------- effects: peels hop off and land flat on the floor; sweep dust; shipping suction (Swarm port) ---------- */
var flights=[],dust=[],sucks=[],dustAcc=0,GX=0,GY=0,GD=0;
function M2(dx,dy){var g=sim.s.g;GX=wx(g.x*roomW);GY=wy(g.y*roomH);GD=g.dir|0;return M(dx,dy);}
function spawnPeel(slot){if(slot<0||slot>=MESSPOS.length||flights.length>60)return;
  var hr=Math.max(5,Math.round(6*k)),o=M2(Math.round((0.8+Math.random()*2.4)*k),-hr-Math.max(4,Math.round(4.2*k))),tp=MESSPOS[slot];
  flights.push({slot:slot,x0:o[0],y0:o[1],tx:wx(tp.x),ty:wy(tp.y),t:0,dur:0.42+Math.random()*0.26,q:tp.q,h:(4+Math.random()*3)*k});flying[slot]=true;messVer++;}
function tickFlights(dt){var np=sim.s.peels;for(var i=flights.length-1;i>=0;i--){var f=flights[i];f.t+=dt;
    if(f.t>=f.dur||f.slot>=np){delete flying[f.slot];flights.splice(i,1);messVer++;}}}
function drawFlights(){for(var i=0;i<flights.length;i++){var f=flights[i],p=Math.min(1,f.t/f.dur),e=1-(1-p)*(1-p);
    var gxp=f.x0+(f.tx-f.x0)*e,gyp=f.y0+(f.ty-f.y0)*e,z=Math.sin(p*Math.PI)*f.h;
    R(Math.round(gxp)-1,Math.round(gyp)+1,3,1,"rgba(40,30,16,0.32)");
    var sp=PEELSPR[(f.q+Math.floor(p*8))%12];ctx.drawImage(sp,Math.round(gxp)-3,Math.round(gyp-z)-2);}}
function tickDust(dt){var g=sim.s.g,a=g.act;
  if(a&&a.t==="sweep"&&a.e>C.sweepWind){var hr2=Math.max(5,Math.round(6*k));var sw=Math.sin(performance.now()/1000*7.5);var o2=M2(Math.round(sw*5*k),-hr2-Math.max(4,Math.round(14*k)));dustAcc+=dt*14;
    while(dustAcc>1){dustAcc-=1;if(dust.length<28)dust.push({x:o2[0]+(Math.random()*6-3),y:o2[1]+(Math.random()*4-2),vx:(Math.random()-0.5)*8,vy:-2-Math.random()*5,life:0.5});}}
  for(var i=dust.length-1;i>=0;i--){var d=dust[i];d.x+=d.vx*dt;d.y+=d.vy*dt;d.life-=dt;if(d.life<=0)dust.splice(i,1);}}
function drawDust(){for(var i=0;i<dust.length;i++){var d=dust[i];ctx.globalAlpha=Math.max(0,d.life*1.6);R(d.x,d.y,2,1,"#d8c898");}ctx.globalAlpha=1;}
/* shipping: the skinned potato is simply sucked up the intake (Swarm's 3 pulsing red rings + a shrinking swirl), 0.5 s, nothing lingers */
var SUCK_T=0.5;
function pushSuck(sloppy){if(sucks.length<6)sucks.push({t:0,sl:!!sloppy});}
function tickSucks(dt){for(var i=sucks.length-1;i>=0;i--){sucks[i].t+=dt;if(sucks[i].t>=SUCK_T)sucks.splice(i,1);}}
function drawSucks(){var cx=wx(chute.cx),topY=wy(GEO.ship.top+4),y0=wy(SPOT.ship.y-16);
  for(var i=0;i<sucks.length;i++){var s=sucks[i],p=s.t/SUCK_T,e=Math.pow(p,1.6),sw=Math.sin(p*Math.PI*2)*ws(3)*(1-p);
    potato(cx+sw,y0+(topY-y0)*e,Math.max(2,Math.round(Math.max(3,ws(3.1))*(1-0.65*p))),true,i%2===1,s.sl?3:0);
    var tt=performance.now()/1000;ctx.save();ctx.globalAlpha=(0.30+0.18*Math.sin(tt*20))*(1-p*0.6);ctx.strokeStyle="#ff3050";ctx.lineWidth=1;
    for(var q=0;q<3;q++){ctx.beginPath();ctx.arc(cx,topY+ws(2),ws(4)+((tt*16+q*5.4)%ws(13)),0,6.28);ctx.stroke();}ctx.restore();}}
/* return chute: raw potatoes come OUT of the mouth (clipped inside the pipe), tumble and bounce, roll and settle onto their slot in the pile.
   The schedule (exit + rest times) comes from PPSim.spill(t0,n): the sim lands each potato at exactly the time drawn here. */
var RT=0,retLight=0;
function drawReturn(){var s=sim.s,kk=s.suck;if(!kk)return;var sc=PPSim.spill(kk.t0,kk.n),mx=GEO.ret.mouthX;retLight=0;
  for(var j=kk.landed;j<kk.n;j++){var ex=sc.ex[j],ld=sc.ld[j],p=(RT-ex)/(ld-ex);if(p<0)break;if(p>1)p=1;
    if(RT-ex<0.3)retLight=1;
    var idx=Math.min(MAXVIS-1,s.pile+(j-kk.landed)),tp=POS[idx],tx=wx(tp.x),ty=wy(tp.y);
    var sy=GEO.ret.y+(srng(Math.round(kk.t0*100)+j*17)-0.5)*3.6,spx=wx(mx),spy=wy(sy);
    var pA=Math.min(1,p/0.18),pB=Math.max(0,(p-0.18)/0.82),bn=2+Math.floor(srng(Math.round(kk.t0*100)+j*31)*2.99),amp=(5+srng(j*7+Math.round(kk.t0*10))*5)*k;
    var ax=spx+ws(4)-ws(13)*pA,x,y,z=0;
    if(pB<=0){x=ax;y=spy;}
    else{var e=1-Math.pow(1-pB,2.3),bx=spx-ws(9);x=bx+(tx-bx)*e;y=spy+(ty-spy)*(0.25+0.75*pB)*1;y=spy+(ty-spy)*Math.pow(pB,0.85);z=Math.abs(Math.sin(pB*Math.PI*bn))*amp*Math.pow(1-pB,1.4);}
    ctx.fillStyle="rgba(0,0,0,0.30)";ctx.beginPath();ctx.ellipse(x,y+ws(2.2),ws(2.8),ws(1.3),0,0,6.28);ctx.fill();
    if(pB<=0){ctx.save();ctx.beginPath();ctx.rect(0,0,spx-ws(1.2),H);ctx.clip();}
    potato(x,y-z,Math.max(3,ws(3.3)),false,Math.floor(p*9)%2===0,0,["#5a3418","#7a4c28","#9a6a34","#d89a54"]);
    if(pB<=0)ctx.restore();}
  if(retLight){var my=wy(GEO.ret.y-GEO.ret.w/2-0.2);R(wx(GEO.ret.mouthX+8),my,2,1,"#40ff70");}}
function drawScene(now){if(W<2||H<2)return;ensureStatic();var s=sim.s;ctx.drawImage(staticLayer,0,0);
  renderMess(Math.min(s.peels,MESSVIS));ctx.drawImage(messLayer,0,0);
  renderPile(Math.min(s.pile,MAXVIS));ctx.drawImage(pileLayer,0,0);
  drawGuy(now);drawFlights();drawDust();drawSucks();drawReturn();}
