
/* ---------- HUD ---------- */
var $=function(id){return document.getElementById(id);};
var hud={};
function coinIcon(){var g=$("coinIco").getContext("2d");var r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};
  r(3,1,8,12,"#c4a020");r(4,0,6,14,"#c4a020");r(2,2,10,10,"#c4a020");r(4,1,6,12,"#ffe066");r(3,2,8,10,"#ffe066");r(5,2,4,10,"#fff3a0");r(4,3,6,8,"#fff3a0");r(6,5,2,5,"#c4a020");r(5,6,4,1,"#c4a020");
  var f=$("foodIco").getContext("2d");var q=function(x,y,w,h,c){f.fillStyle=c;f.fillRect(x,y,w,h);};
  q(1,5,12,7,"#5a3a20");q(2,6,10,5,"#c08040");q(2,4,10,2,"#e8c070");q(3,3,8,1,"#f5e0a8");q(4,7,2,2,"#7a4a20");q(8,8,2,1,"#7a4a20");
  var pl=$("peelIco").getContext("2d");var w=function(x,y,ww,h,c){pl.fillStyle=c;pl.fillRect(x,y,ww,h);};
  w(2,3,9,2,"#b08838");w(2,2,9,2,"#f5e0a8");w(10,4,2,4,"#e8c070");w(3,6,9,2,"#d4a04a");w(3,5,8,2,"#f5e0a8");w(2,8,2,3,"#e8c070");w(3,10,9,2,"#b08838");w(3,9,9,2,"#e8c070");}
function setText(id,v){if(hud[id]!==v){hud[id]=v;$(id).textContent=v;}}
var boxSnap="";
function messPct(){return Math.round((1-sim.messF())*100);}
function updateHud(){var s=sim.s;var bs="",ci;for(ci=0;ci<CMDS.length;ci++)bs+=s.box[CMDS[ci].id]+",";bs+=s.potCap+","+s.up.chute;if(bs!==boxSnap){boxSnap=bs;renderAll();}
  setText("coins",String(s.coins));setText("peels",String(s.peels));var mp=messPct();
  var pe=$("peelRow"),pc="food peels"+(mp>=22?" filthy":(mp>=8?" messy":""));if(hud.pc!==pc){hud.pc=pc;pe.className=pc;}
  var mt=mp>=1?"MESS: "+mp+"% SLOWER":"";if(hud.mt!==mt){hud.mt=mt;var me=$("mess");me.textContent=mt;me.className="mess"+(mp>=8?" on":"");}setText("food",s.food+(s.food>=sim.foodMax()?" MAX":""));
  $("foodRow").className="food"+(s.food<=0?" out":"");
  var h=Math.round(s.hunger),e=Math.round(s.energy);
  if(hud.h!==h){hud.h=h;$("hFill").style.transform="scaleX("+(h/100)+")";$("hPct").textContent=h+"%";$("hBar").className="bar hunger"+(h<20?" low":"");}
  if(hud.e!==e){hud.e=e;$("eFill").style.transform="scaleX("+(e/100)+")";$("ePct").textContent=e+"%";$("eBar").className="bar energy"+(e<20?" low":"");}
  var st=sim.stateName();if(hud.st!==st){hud.st=st;var els=document.querySelectorAll(".st");for(var i=0;i<els.length;i++)els[i].classList.toggle("on",els[i].getAttribute("data-s")===st);}
  var a=s.g.act;setText("doing",a&&a.label?a.label:"");
  /* object labels carry live numbers */
  tagText("tagFood","FOOD x"+s.food);tagText("tagPot","POTATOES "+POTS[s.box.pot]);tagText("tagRet",s.chute>0?"RETURN "+s.chute+"/"+sim.chuteCap():"RETURN");
  var can=s.coins>=Math.min(sim.price(),sim.potPrice()||9999)?" can":"";var sb=$("shopBtn");var sc2="shopb"+can;if(hud.sb!==sc2){hud.sb=sc2;sb.className=can?"can":"";}
  if(ovlMode){$("ovlCoins").textContent=s.coins+"c";if(ovlDirty){ovlDirty=false;buildOvl();}}
  updateHint();}
function tagText(id,t){var key="t"+id;if(hud[key]!==t){hud[key]=t;var el=$(id);el.textContent=t;if(playRect)placeTagsSoon();}}
var tagTimer=0;function placeTagsSoon(){if(tagTimer)return;tagTimer=setTimeout(function(){tagTimer=0;if(playRect)placeTags();},60);}
var hintShown="",migUntil=0;
function updateHint(){var s=sim.s,msg="";
  if(migrated&&performance.now()<migUntil)msg="Welcome back. Your "+migrated+" save was carried over ("+migrated+" itself is untouched).";
  else if(s.peels>=45&&s.box.clean===0&&s.t<7200)msg="The floor is a mess: he works "+messPct()+"% slower. Set CLEAN WHEN PEELS > to make him sweep.";
  else if(s.box.eat===0&&s.box.nap===0&&s.t<240)msg="Tap a box to unlock its slider. Set EAT and NAP or he goes lazy. HELP explains every box.";
  else if(s.box.eat>0&&s.food<=0&&s.hunger<s.box.eat)msg="Out of food! He's slacking. Open the SHOP (or set KEEP FOOD AT LEAST).";
  else if(s.g.lazy&&s.box.eat===0&&s.hunger<C.lazyLow)msg="Hungry and no EAT box set: he's going lazy.";
  else if(s.g.lazy&&s.box.nap===0&&s.energy<C.lazyLow)msg="Tired and no NAP box set: he naps wherever.";
  if(msg!==hintShown){hintShown=msg;var el=$("hint");if(msg){el.textContent=msg;el.className="";}else el.className="off";}}
function popCoin(v,sloppy){var el=document.createElement("div");el.className="pop";el.textContent="+"+v+"c"+(sloppy?" sloppy":"");
  var x=(wx(chute.cx)/W)*playRect.width,y=(wy(chute.lip+6)/H)*playRect.height;el.style.left=Math.round(x+8)+"px";el.style.top=Math.round(y)+"px";$("play").appendChild(el);pops.push({el:el,t:0,y:y});}
function tickPops(dt){for(var i=pops.length-1;i>=0;i--){var p=pops[i];p.t+=dt;p.el.style.transform="translateY("+(-p.t*22)+"px)";p.el.style.opacity=String(Math.max(0,1-p.t/1.2));if(p.t>1.2){p.el.parentNode&&p.el.parentNode.removeChild(p.el);pops.splice(i,1);}}}

/* ---------- command panel: scroll-safe (Jay t1015) ----------
   Built from PPSim.COMMANDS, the same table the HELP screen reads, so the two can never drift apart.
   A slider is LOCKED until you tap its box (the box lights up). Vertical drags always scroll the panel and never move a slider.
   + and - always work (they act on a clean tap). SHOP / HELP also need a clean tap, so scrolling can't open them. A slide applies its value where the finger lifts. */
var cmd=$("cmd"),focusId=null;
function fmt(id,v){
  if(id==="pace")return PACE[v]+" x"+SPD[v];
  if(id==="pot")return String(POTS[v]);
  if(id==="clean")return v>0?"> "+v:"OFF";
  if(id==="style")return STYLE[v].n+" x"+STYLE[v].sp;
  if(id==="wake")return v+"%";
  if(id==="autob")return v>0?">= "+v:"OFF";
  return v>0?"< "+v+"%":"OFF";}
function bmax(id){return id==="pot"?Math.max(1,sim.potMax()):BOX[id].max;}
function pct(id,v){var b=BOX[id];return (v-b.min)/(bmax(id)-b.min);}
var UNSET={eat:1,nap:1,clean:1,autob:1};
function buildPanel(){var h="";
  for(var i=0;i<CMDS.length;i++){var c=CMDS[i];
    h+='<div class="box" data-id="'+c.id+'"><button class="pm" data-d="1" aria-label="'+c.name+' up">+</button><div class="mid"><div class="top"><span class="nm">'+c.name.replace(/</g,"&lt;").replace(/>/g,"&gt;")+'</span><span class="lk"></span><span class="val"></span></div><div class="trk"><div class="ln"></div><div class="fill"></div><div class="kn"></div></div></div><button class="pm" data-d="-1" aria-label="'+c.name+' down">&minus;</button></div>';}
  $("boxes").innerHTML=h;}
function renderTicks(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),trk=el.querySelector(".trk"),b=BOX[id],mx=bmax(id),old=trk.querySelectorAll(".tk");for(var j=0;j<old.length;j++)trk.removeChild(old[j]);
  var n=Math.max(1,Math.round((mx-b.min)/b.step)),tn=Math.min(n,14);for(var i=0;i<=tn;i++){var t=document.createElement("i");t.className="tk";t.style.left=(i/tn*100)+"%";trk.appendChild(t);}}
function renderBox(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),v=sim.s.box[id],p=pct(id,v);
  el.querySelector(".kn").style.left=((1-p)*100)+"%";el.querySelector(".fill").style.width=(p*100)+"%";el.querySelector(".val").textContent=fmt(id,v);
  el.classList.toggle("unset",!!UNSET[id]&&v===0);el.classList.toggle("focus",focusId===id);el.querySelector(".lk").textContent=focusId===id?"<SLIDE>":"";
  var key=id==="pot"?"tk"+sim.potMax():"tk";if(el.getAttribute("data-tk")!==key){el.setAttribute("data-tk",key);renderTicks(id);}}
function renderAll(){for(var id in BOX)renderBox(id);}
function setFocus(id){focusId=id;renderAll();}
buildPanel();
function changed(){renderAll();updateHud();saveGame();}
function valFromX(id,trk,clientX){var r=trk.getBoundingClientRect(),b=BOX[id];var q=(clientX-r.left)/r.width;q=Math.max(0,Math.min(1,q));return b.min+(1-q)*(bmax(id)-b.min);}
var G=null; /* the active gesture */
var SLOP=8;
function doAct(a){
  if(a==="shop")openOvl("shop");else if(a==="help")openOvl("help");else if(a==="close")closeOvl();
  else if(a&&a.indexOf("buy:")===0)shopBuy(a.slice(4));}
cmd.addEventListener("pointerdown",function(e){if(G&&G.id!==e.pointerId)return;
  var t=e.target,box=t.closest?t.closest(".box"):null,pm=t.closest?t.closest(".pm"):null,trk=t.closest?t.closest(".trk"):null,btn=t.closest?t.closest("#bar button"):null;
  G={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:cmd.scrollTop,box:box,bid:box?box.getAttribute("data-id"):null,pm:pm,trk:trk,btn:btn,mode:null};
  if(pm)pm.classList.add("press");if(btn)btn.classList.add("press");
  try{cmd.setPointerCapture(e.pointerId);}catch(x){}
  e.preventDefault();});
cmd.addEventListener("pointermove",function(e){if(!G||G.id!==e.pointerId)return;var dx=e.clientX-G.x0,dy=e.clientY-G.y0;
  if(G.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){
    if(Math.abs(dy)>=Math.abs(dx)*0.75)G.mode="scroll";
    else if(G.bid&&G.bid===focusId&&(G.trk||(!G.pm)))G.mode="slide";
    else G.mode="none";
    if(G.pm)G.pm.classList.remove("press");if(G.btn)G.btn.classList.remove("press");}
  if(G.mode==="scroll")cmd.scrollTop=G.st0-dy;
  else if(G.mode==="slide"){var trk=G.box.querySelector(".trk");if(sim.setBox(G.bid,valFromX(G.bid,trk,e.clientX)))changed();}});
function endG(e,cancel){if(!G||G.id!==e.pointerId)return;var g=G;G=null;if(g.pm)g.pm.classList.remove("press");if(g.btn)g.btn.classList.remove("press");
  /* a slide ends where the finger lifts: a slow WebView may not deliver a final move */
  if(!cancel&&g.mode==="slide"){var tk=g.box.querySelector(".trk");if(sim.setBox(g.bid,valFromX(g.bid,tk,e.clientX)))changed();return;}
  if(cancel||g.mode!==null)return;
  /* slow old WebViews can deliver a swipe as down -> up with few or no moves: judge by where the finger lifted */
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)cmd.scrollTop=g.st0-dy;return;}
  /* a clean tap */
  if(g.pm&&g.bid){var d=+g.pm.getAttribute("data-d");setFocus(g.bid);if(sim.setBox(g.bid,sim.s.box[g.bid]+d*BOX[g.bid].step))changed();return;}
  if(g.btn){doAct(g.btn.getAttribute("data-act"));return;}
  if(g.bid){if(focusId===g.bid&&g.trk){if(sim.setBox(g.bid,valFromX(g.bid,g.trk,e.clientX)))changed();}else setFocus(g.bid);return;}
  setFocus(null);}
cmd.addEventListener("pointerup",function(e){endG(e,false);});
cmd.addEventListener("pointercancel",function(e){endG(e,true);});
cmd.addEventListener("lostpointercapture",function(e){if(G&&G.id===e.pointerId&&G.mode!==null)endG(e,true);});
var GL=[];window.__ppGL=GL;["pointerdown","pointermove","pointerup","pointercancel"].forEach(function(t){cmd.addEventListener(t,function(e){GL.push(t.slice(7)+":"+Math.round(e.clientX)+","+Math.round(e.clientY)+(G?":"+G.mode:""));if(GL.length>40)GL.shift();},true);});
cmd.addEventListener("click",function(e){e.preventDefault();});
$("play").addEventListener("pointerdown",function(){if(focusId)setFocus(null);showLabels(8000);});

/* ---------- shop + help screens (same scroll-safe rule: a tap is judged where the finger lifts; drags scroll) ---------- */
var ovl=$("ovl"),ovlBody=$("ovlBody"),ovlMode=null,ovlDirty=false,OG=null;
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function goBtn(act,price,state){var cls="go"+(state==="poor"?" poor":"")+(state==="done"?" done":"");
  return '<button class="'+cls+'" type="button" data-act="'+act+'">'+(state==="done"?"MAXED":price+"c<br>BUY")+'</button>';}
function buildShop(){var s=sim.s,h="",pr=sim.price(),fm=sim.foodMax();
  h+='<div class="sec">FOOD</div>';
  h+='<div class="row"><div class="tx"><div class="nm">FOOD CAN <b>'+s.food+' / '+fm+'</b></div><div class="fx">One can = +55 hunger when he eats. The price climbs a little with each can and slowly over time.</div></div>'+(s.food>=fm?goBtn("buy:food",pr,"done"):goBtn("buy:food",pr,s.coins<pr?"poor":""))+'</div>';
  h+='<div class="sec">POTATOES</div>';var pp=sim.potPrice(),cap=s.potCap;
  h+='<div class="row"><div class="tx"><div class="nm">MORE POTATOES <b>'+POTS[cap]+(pp===null?'':' &rarr; '+POTS[cap+1])+'</b></div><div class="fx">You own '+POTS[cap]+'. Buying raises your limit to the next stop and puts the new potatoes on the pile. The POTATOES IN PLAY slider goes up to what you own.</div></div>'+(pp===null?goBtn("buy:pot",0,"done"):goBtn("buy:pot",pp,s.coins<pp?"poor":""))+'</div>';
  h+='<div class="sec">UPGRADES</div>';
  for(var i=0;i<UPS.length;i++){var u=UPS[i],lv=sim.up(u.id),p2=sim.upPrice(u.id);
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(u.name)+' <b>LV '+lv+'/'+u.max+'</b></div><div class="fx">'+esc(u.fx)+'</div></div>'+(p2===null?goBtn("buy:up:"+u.id,0,"done"):goBtn("buy:up:"+u.id,p2,s.coins<p2?"poor":""))+'</div>';}
  ovlBody.innerHTML=h;}
function buildHelp(){var s=sim.s,h='<div class="note">Every command box, what it does and what its slider changes. Tap a box to unlock its slider; drag along it or tap + and -. The number is what he is set to right now.</div><div class="sec">COMMANDS ('+CMDS.length+')</div>';
  for(var i=0;i<CMDS.length;i++){var c=CMDS[i],v=s.box[c.id];
    h+='<div class="row cmdrow" data-cmd="'+c.id+'"><div class="nm"><span class="now">NOW '+esc(fmt(c.id,v))+'</span>'+esc(c.name)+'</div><div class="rg">SLIDER: '+esc(c.range)+'</div><div class="wt">'+esc(c.what)+'</div><div class="fx">'+esc(c.effect)+'</div></div>';}
  h+='<div class="sec">THE LOOP</div><div class="note">He grabs a potato from the pile, peels it at the table (peels pop off onto the floor and slow him down), and drops it in the SHIP IN chute where it is sucked up. A full chute sends the batch through the pipe and the potatoes spill back out of the RETURN chute onto the pile with their skin on. Each potato earns coins; spend them in the SHOP.</div>';
  h+='<div class="sec">LABELS</div><div class="note">Tap the room to show the name of every object for a few seconds.</div>';
  ovlBody.innerHTML=h;}
function buildOvl(){var st=ovlBody.scrollTop;if(ovlMode==="shop")buildShop();else if(ovlMode==="help")buildHelp();ovlBody.scrollTop=st;$("ovlCoins").textContent=ovlMode==="shop"?sim.s.coins+"c":"";}
function openOvl(mode){ovlMode=mode;ovl.className="on";$("ovlTitle").textContent=mode==="shop"?"SHOP":"HELP: COMMANDS";ovlBody.scrollTop=0;buildOvl();if(focusId)setFocus(null);}
function closeOvl(){ovlMode=null;ovl.className="";OG=null;}
function flash(btn,txt){if(!btn)return;var old=btn.innerHTML;btn.innerHTML=txt;setTimeout(function(){if(ovlMode)ovlDirty=true;},700);}
function shopBuy(what){var r,btn=ovl.querySelector('[data-act="buy:'+what+'"]'),pr;
  if(what==="food"){pr=sim.price();r=sim.buyFood();}
  else if(what==="pot"){pr=sim.potPrice();r=sim.buyPotatoes();}
  else if(what.indexOf("up:")===0){var id=what.slice(3);pr=sim.upPrice(id);r=sim.buyUp(id);}
  else return "bad";
  if(r==="ok"){if(btn)btn.innerHTML="BOUGHT!";setTimeout(function(){ovlDirty=true;},600);changed();}
  else if(r==="poor"){if(btn)btn.innerHTML="NEED<br>"+pr+"c";setTimeout(function(){ovlDirty=true;},800);}
  else{if(btn)btn.innerHTML=r==="full"?"FULL":"MAXED";setTimeout(function(){ovlDirty=true;},800);}
  updateHud();saveGame();return r;}
ovl.addEventListener("pointerdown",function(e){if(OG&&OG.id!==e.pointerId)return;var t=e.target,btn=t.closest?t.closest("[data-act]"):null;
  OG={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:ovlBody.scrollTop,btn:btn,mode:null};if(btn)btn.classList.add("press");
  try{ovl.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();});
ovl.addEventListener("pointermove",function(e){if(!OG||OG.id!==e.pointerId)return;var dx=e.clientX-OG.x0,dy=e.clientY-OG.y0;
  if(OG.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){OG.mode=Math.abs(dy)>=Math.abs(dx)*0.75?"scroll":"none";if(OG.btn)OG.btn.classList.remove("press");}
  if(OG.mode==="scroll")ovlBody.scrollTop=OG.st0-dy;});
function endO(e,cancel){if(!OG||OG.id!==e.pointerId)return;var g=OG;OG=null;if(g.btn)g.btn.classList.remove("press");if(cancel||g.mode!==null)return;
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)ovlBody.scrollTop=g.st0-dy;return;}
  if(g.btn)doAct(g.btn.getAttribute("data-act"));}
ovl.addEventListener("pointerup",function(e){endO(e,false);});
ovl.addEventListener("pointercancel",function(e){endO(e,true);});
ovl.addEventListener("click",function(e){e.preventDefault();});

/* ---------- main loop: time runs only while the game is open and visible ---------- */
function events(){var ev=sim.s.ev;while(ev.length){var e=ev.shift();if(e.k==="coin"){popCoin(e.v,e.sloppy);pushSuck(e.sloppy);}else if(e.k==="peel")spawnPeel(e.slot);}}
var last=0,acc=0,STEP=0.05,paused=false,frames=0;
function frame(ts){
  var dt=last?Math.min(0.25,(ts-last)/1000):0;last=ts;
  if(!paused){acc+=dt;while(acc>=STEP){sim.step(STEP);acc-=STEP;}events();tickFlights(dt);tickDust(dt);tickSucks(dt);tickPops(dt);}
  RT=sim.s.t+acc;drawScene(ts);frames++;updateLabels();
  if(frames%6===0)updateHud();
  if(ts-lastSave>2000)saveGame();
  requestAnimationFrame(frame);}
document.addEventListener("visibilitychange",function(){if(document.hidden){paused=true;saveGame();}else{paused=false;last=0;}});
window.addEventListener("pagehide",saveGame);window.addEventListener("beforeunload",saveGame);window.addEventListener("unload",saveGame);
window.addEventListener("resize",function(){layout();drawScene(performance.now());});
/* what is on screen, for the HANDOFF object table and the tests */
var OBJECTS=[
  {id:"ship",name:"SHIP IN chute",use:"He drops each peeled potato here: +2c (+1c sloppy). It is sucked in and joins the batch.",gameplay:true},
  {id:"return",name:"RETURN chute",use:"A full batch (or an empty pile) spills back out of its mouth onto the pile, raw again.",gameplay:true},
  {id:"table",name:"PEEL TABLE",use:"Where he stands to peel (never walked over: he goes around it).",gameplay:true},
  {id:"bed",name:"BED",use:"NAP WHEN ENERGY < sends him here; SOFT BED upgrade speeds naps.",gameplay:true},
  {id:"cooler",name:"FOOD cooler",use:"Holds the food cans (HUD FOOD count, BIGGER COOLER upgrade); EAT WHEN HUNGER < sends him here.",gameplay:true},
  {id:"stool",name:"SEAT (stool)",use:"The spot he stands on to eat. Position only: it has no effect of its own.",gameplay:false},
  {id:"pile",name:"POTATOES pile",use:"The raw potatoes (POTATOES IN PLAY, shop potatoes). He grabs from its top edge.",gameplay:true},
  {id:"peels",name:"Peels on the floor",use:"Mess: slows him up to 30%; CLEAN WHEN PEELS > and STIFF BROOM deal with it.",gameplay:true},
  {id:"light",name:"Soft light pool under the table",use:"Lighting only. No gameplay.",gameplay:false}];
coinIcon();buildPanel();layout();renderAll();updateHud();migUntil=performance.now()+9000;RT=sim.s.t;showLabels(30000);drawScene(performance.now());
requestAnimationFrame(frame);
/* test + debug hooks */
window.PP={get sim(){return sim;},Sim:PPSim,save:saveGame,key:SAVE_KEY,reset:function(seed){sim=PPSim.fresh(seed);focusId=null;hud={};boxSnap="";flights=[];flying={};messVer++;sucks=[];renderAll();updateHud();saveGame();},
  reload:function(){sim=loadGame();hud={};flights=[];flying={};messVer++;renderAll();updateHud();},focus:function(){return focusId;},
  pause:function(p){paused=!!p;},layout:function(){return {W:W,H:H,k:k,roomW:roomW,roomH:roomH,offX:offX,offY:offY,detail:DETAIL,fitW:RW*k,fitH:RH*k};},version:"0.3",
  setPileMax:function(n){PILEMAX=n;buildPile();pileLayer=null;pileKey=-1;},forcePile:function(n){sim.s.pile=n;},get migrated(){return migrated;},
  stats:function(){return {pileRenders:renders.pile,messRenders:renders.mess,maxVis:MAXVIS,tiers:TIER.slice(),messVis:MESSPOS.length,flights:flights.length,sucks:sucks.length};},
  objects:function(){return OBJECTS;},labels:function(ms){showLabels(ms||8000);},ovl:function(){return ovlMode;},open:openOvl,close:closeOvl,buy:shopBuy,
  spillView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++)o.push({j:j,ex:sc.ex[j],ld:sc.ld[j],rt:RT});return o;},
  posOf:function(i){return POS[i];},messPos:function(i){return MESSPOS[i];},tagRects:function(){var o={};for(var i=0;i<TAGDEF.length;i++){var r=$(TAGDEF[i].id).getBoundingClientRect();o[TAGDEF[i].id]={x:r.left,y:r.top,w:r.width,h:r.height,on:$(TAGDEF[i].id).className.indexOf("off")<0};}return o;},
  flightsNow:function(){return flights.map(function(f){return {slot:f.slot,t:f.t,dur:f.dur};});}};
window.__PP_READY=true;
})();
