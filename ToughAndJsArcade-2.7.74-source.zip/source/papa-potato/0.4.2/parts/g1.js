/* ===== Papa Potato 0.3 — renderer, HUD, scroll-safe command panel, shop + help screens, save/load ===== */
(function(){
"use strict";
var SAVE_KEY="papaPotato.save.v3",KEY_V2="papaPotato.save.v2",KEY_V1="papaPotato.save.v1";   /* v2 / v1 are only ever READ (the 0.2 and 0.1 slots own them) */
var C=PPSim.C,BOX=PPSim.BOX,SPOT=PPSim.SPOT,PACE=PPSim.PACE,GEO=PPSim.GEO,RW=PPSim.RW,RH=PPSim.RH,CMDS=PPSim.COMMANDS,UPS=PPSim.UPS,STYLE=PPSim.STYLE,SPD=PPSim.SPD,POTS=PPSim.POTS;
var sim=null;
var migrated=false;
/* 0.3 save first; else carry over a 0.2 save, then a 0.1 save (both read only); else a fresh game */
function loadGame(){var s=null;try{var raw=localStorage.getItem(SAVE_KEY);if(raw)s=PPSim.load(raw);}catch(e){}
  if(!s){try{var o2=localStorage.getItem(KEY_V2);if(o2){s=PPSim.load(o2);if(s)migrated="0.2";}}catch(e){}}
  if(!s){try{var o1=localStorage.getItem(KEY_V1);if(o1){s=PPSim.load(o1);if(s)migrated="0.1";}}catch(e){}}
  return s||PPSim.fresh();}
var lastSave=0;
function saveGame(){if(!sim)return false;try{localStorage.setItem(SAVE_KEY,sim.serialize());lastSave=performance.now();return true;}catch(e){return false;}}
sim=loadGame();

/* ---------- art: the whole room is fitted into the play area (no scrolling) ---------- */
var DETAIL=1.10;      /* ~10% finer pixel grid (t1014) */
var cv=document.getElementById("cv"),ctx=cv.getContext("2d");
var W=0,H=0,SC=3,k=1,camX=0,camY=0,offX=0,offY=0,roomW=RW,roomH=RH,WALL=GEO.WALL;
var staticLayer=null,gx=0,gy=0,table=null,chute=null,playRect=null;
var pops=[];
var pileLayer=null,pileKey=-1,messLayer=null,messKey="",POS=[],ORDER=[],MESSPOS=[],SPR=null,SPRS=null,PEELSPR=null,TIER=[],renders={pile:0,mess:0};
var MAXVIS=400,PILEMAX=POTS[POTS.length-1],LIFT=1.1,MESSVIS=140;
function R(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x|0,y|0,Math.max(1,w),Math.max(1,h));}
function wx(x){return Math.round((x-camX)*k);}
function wy(y){return Math.round((y-camY)*k);}
function ws(s){return Math.max(1,Math.round(s*k));}
function wr(x,y,w,h,c){var x0=wx(x),y0=wy(y),x1=wx(x+w),y1=wy(y+h);R(x0,y0,Math.max(1,x1-x0),Math.max(1,y1-y0),c);}
function oval(cx,cy,rw,rh,c){cx=Math.round(cx);cy=Math.round(cy);rw=Math.max(1,Math.round(rw));rh=Math.max(1,Math.round(rh));var rh2=rh*rh||1;ctx.fillStyle=c;
  for(var dy=-rh;dy<=rh;dy++){var t=1-(dy*dy)/rh2;var row=Math.max(1,Math.round(rw*Math.sqrt(Math.max(0,t))));ctx.fillRect(cx-row,cy+dy,row*2+(row>0?0:1),1);}}
function srng(n){var s=(n*1664525+1013904223)>>>0;return (s%10000)/10000;}
var TAGDEF=[
  {id:"tagShip",x:GEO.ship.x+20,y:15,al:"l"},
  {id:"tagRet",x:GEO.ret.mouthX+3,y:GEO.ret.y-13,al:"c"},
  {id:"tagTable",x:50,y:83,al:"c"},
  {id:"tagBed",x:GEO.mat.x,y:GEO.mat.y-9,al:"c"},
  {id:"tagFood",x:78,y:GEO.cooler.y0-6,al:"c"},
  {id:"tagSeat",x:GEO.stool.x,y:GEO.stool.y+8,al:"c"},
  {id:"tagPot",x:50,y:GEO.pile.base+3,al:"c"}];
function layout(){
  var r=document.getElementById("play").getBoundingClientRect();playRect=r;
  var cssW=Math.max(1,r.width),cssH=Math.max(1,r.height);
  var baseSC=cssW>=230?3:2;SC=baseSC/DETAIL;
  W=Math.max(1,Math.round(cssW/SC));H=Math.max(1,Math.round(cssH/SC));cv.width=W;cv.height=H;
  k=Math.min(W/RW,H/RH)*0.985;offX=(W-RW*k)/2;offY=(H-RH*k)/2;camX=-offX/k;camY=-offY/k;
  gx=GEO.table.x0+(GEO.table.x1-GEO.table.x0)/2;gy=GEO.table.y0+(GEO.table.y1-GEO.table.y0)/2;
  table={x:gx,y:gy,w:GEO.table.x1-GEO.table.x0,h:GEO.table.y1-GEO.table.y0};
  chute={cx:GEO.ship.x,mouthW:GEO.ship.mouth*2,lip:GEO.ship.lip};
  staticLayer=null;pileLayer=null;messLayer=null;buildPile();buildMess();buildSprites();placeTags();
}
function clampTag(el,play,pad){var r=el.getBoundingClientRect();var left=parseFloat(el.style.left)||0;
  if(el.style.transform&&el.style.transform.indexOf("translateX(-50%)")>=0){var half=r.width/2;el.style.left=Math.round(Math.max(pad+half,Math.min(play.width-pad-half,left)))+"px";return;}
  if(r.left<play.left+pad)left+=(play.left+pad)-r.left;if(r.right>play.right-pad)left-=r.right-(play.right-pad);
  el.style.left=Math.round(Math.max(pad,left))+"px";}
function placeTags(){var play=playRect;
  for(var i=0;i<TAGDEF.length;i++){var d=TAGDEF[i],el=document.getElementById(d.id);if(!el)continue;
    var px=(wx(d.x)/W)*play.width,py=(wy(d.y)/H)*play.height;
    el.style.transform=d.al==="c"?"translateX(-50%)":"none";el.style.left=Math.round(px)+"px";
    var hh=el.getBoundingClientRect().height||12;var top=Math.round(Math.max(3,Math.min(play.height-hh-3,py-hh/2)));el.style.top=top+"px";clampTag(el,play,3);}}
var labelsUntil=0;
function showLabels(ms){labelsUntil=Math.max(labelsUntil,performance.now()+ms);}
var labelsOn=null;
function updateLabels(){var on=performance.now()<labelsUntil&&!ovlMode;if(on===labelsOn)return;labelsOn=on;
  for(var i=0;i<TAGDEF.length;i++){var el=document.getElementById(TAGDEF[i].id);if(el)el.className="tag"+(on?"":" off");}}
function potato(x,y,s,peeled,flip,spots,pal){
  var body=pal||(peeled?["#a88830","#c8a848","#e8c868","#f0d890"]:["#4a2810","#6a4020","#8a5a28","#c48a48"]);
  var out=body[0],dk=body[1],md=body[2],hi=body[3];
  var hw=Math.max(2,Math.round(s)),hh=Math.max(2,Math.round(s*0.72));x=Math.round(x);y=Math.round(y);
  for(var dy=-hh-1;dy<=hh+1;dy++){var row=Math.abs(dy)/(hh+0.01);var rw=Math.max(1,Math.round(hw*(1-row*row*0.72)));
    if(Math.abs(dy)>hh){if(rw>1)R(x-rw+1,y+dy,Math.max(1,rw*2-2),1,out);continue;}
    R(x-rw-1,y+dy,(rw+1)*2,1,out);R(x-rw,y+dy,rw*2+(flip?1:0),1,md);if(rw>2)R(x-rw,y+dy,1,1,dk);if(rw>2)R(x+rw-1,y+dy,1,1,dk);}
  R(x-1,y-hh,2,1,hi);R(x-(hw>3?2:1),y-hh+1,hw>3?3:2,1,hi);if(hw>3)R(x-1,y-hh+2,2,1,hi);
  if(!peeled){R(x+(flip?1:-2),y,1,1,dk);if(s>3)R(x+(flip?-2:1),y+1,1,1,out);if(s>4)R(x+(flip?2:-3),y-1,1,1,"#6a4020");if(s>5)R(x+(flip?-1:2),y+2,1,1,dk);}
  else{R(x-1,y,2,1,hi);if(s>3)R(x,y+1,1,1,"#fff3a0");
    if(spots){var sp=[[-2,-1],[2,1],[0,2],[-1,1],[1,-1]];for(var i=0;i<Math.min(spots,sp.length);i++)R(x+sp[i][0],y+sp[i][1],1,1,"#6a4020");}}
}
/* ---------- room pieces ---------- */
function drawFloor(){R(0,0,W,H,"#2a2820");var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);var fw=Math.max(1,ix2-ix),fh=Math.max(1,iy2-iy);
  R(ix,iy,fw,fh,"#9a947c");var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,"#8e876e");}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?"#7a7460":"#a8a288");}
  ctx.strokeStyle="rgba(60,55,40,0.28)";ctx.lineWidth=1;ctx.beginPath();
  for(var x2=ix;x2<=ix+fw;x2+=step){ctx.moveTo(x2+0.5,iy);ctx.lineTo(x2+0.5,iy+fh);}for(var y2=iy;y2<=iy+fh;y2+=step){ctx.moveTo(ix,y2+0.5);ctx.lineTo(ix+fw,y2+0.5);}ctx.stroke();
  /* 0.3: the dashed centre stripe had no use and is hidden (drawCentreStripe, not called) */
  var lcx=wx(gx),lcy=wy(gy);for(var j=0;j<7;j++){ctx.fillStyle="rgba(255,240,180,"+(0.07-j*0.009)+")";ctx.beginPath();ctx.ellipse(lcx,lcy,ws(22+j*6),ws(15+j*4.5),0,0,6.28);ctx.fill();}}
function drawCentreStripe(){var cx=wx(roomW*0.5);for(var y3=wy(WALL+8);y3<wy(roomH*0.72);y3+=Math.max(5,ws(5)))R(cx-ws(3.5),y3,ws(7),1,"#8a846c");}
