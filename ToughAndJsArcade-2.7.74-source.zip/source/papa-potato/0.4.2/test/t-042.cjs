// Papa Potato 0.4.2 (copied from the 0.4.1 suite) — four hard tests (mechanics, visuals/GUI, commands, arcade) + buff + perf + editor/inventory/sweep/path.
// Headless Chrome, A03s-like 360x800 @ dpr 2. Not a physical-phone test.
const L = require("./lib.cjs");
const { ok, R } = L.reporter();
const OUT = process.argv[2] || "/workspace/game/build-potato042/out/t-042";
L.fs.mkdirSync(OUT, { recursive: true });
const URL = "file:///workspace/game/build-potato042/out/papa-potato-0.4.2.html";

function hitsBox(path, b) {
  for (let i = 0; i < path.length - 1; i++) {
    const ax = path[i][0], ay = path[i][1], bx = path[i + 1][0], by = path[i + 1][1];
    for (const f of [0.2, 0.4, 0.6, 0.8]) {
      const x = ax + (bx - ax) * f, y = ay + (by - ay) * f;
      if (x > b.x0 + 0.6 && x < b.x1 - 0.6 && y > b.y0 + 0.6 && y < b.y1 - 0.6) return { x, y };
    }
  }
  return null;
}

(async () => {
  const b = await L.browser();
  const p = await b.newPage();
  const errs = [];
  p.on("pageerror", (e) => errs.push(String(e.message || e)));
  await p.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await p.evaluateOnNewDocument(() => {
    try { ["papaPotato.save.v1","papaPotato.save.v2","papaPotato.save.v3","papaPotato.save.v4"].forEach((k) => localStorage.removeItem(k)); } catch (e) {}
  });
  await p.goto(URL, { waitUntil: "domcontentloaded" });
  await p.waitForFunction(() => window.__PP_READY === true, { timeout: 12000 });
  await L.sleep(200);
  const ev = (fn, ...a) => p.evaluate(fn, ...a);

  // ========== MECHANICS ==========
  const mech = await ev(() => {
    const S = PP.Sim, out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }

    check("room-size", S.RW === 108 && S.RH === 280, S.RW + "x" + S.RH);
    const s = S.fresh(7);
    check("fresh-v4", s.s.v === 4 && s.s.level === 1 && Array.isArray(s.s.mess) && s.s.equipped && typeof s.s.equipped === "object", "v=" + s.s.v);

    const kids = S.tableKids(), T = S.GEO.table;
    check("board-on-table", kids.board.x0 >= T.x0 - 0.05 && kids.board.y0 >= T.y0 - 0.05 && kids.board.x1 <= T.x1 + 0.05 && kids.board.y1 <= T.y1 + 0.05,
      JSON.stringify({ board: kids.board, table: T }));
    check("stand-beside-table", kids.stand.y >= T.y1 + 8 && kids.stand.x >= T.x0 && kids.stand.x <= T.x1, JSON.stringify(kids.stand));

    const v3 = { v: 3, seed: 1, rs: 0, rr: 1, t: 12, coins: 40, food: 2, hunger: 80, energy: 70,
      box: { pace: 2, eat: 30, nap: 25, clean: 0, pot: 6, style: 1, wake: 100, autob: 0 },
      potCap: 6, up: { peeler: 0, boots: 0, chute: 0, pantry: 0, broom: 0, mat: 0 },
      pile: 6, chute: 0, suck: null, peels: 0,
      stats: { peeled: 0, earned: 0, meals: 0, naps: 0, lazyNaps: 0, bought: 0, spent: 0, lazyTime: 0, eatTime: 0, napTime: 0, firstBuyT: -1, sucks: 0, swept: 0, sweeps: 0, peelsMade: 0, maxPeels: 0, cleanTime: 0, waitTime: 0, boughtPot: 0, boughtUp: 0, autoBuys: 0 },
      g: { x: 0.5, y: 0.2, dir: 2, hold: null, job: "pile", peel: 0, pgot: 0, sloppy: false, lazy: false, act: null, walkPh: 0 }, ev: [] };
    const m = S.load(JSON.stringify(v3));
    check("migrate-v3", m && m.s.v === 4 && m.s.coins === 40 && m.s.level === 1 && m.total() === S.POTS[6], "v=" + (m && m.s.v) + " tot=" + (m && m.total()));

    // inventory: buy goes to inv, not auto-placed / auto-equipped
    s.s.coins = 80;
    check("buy-level-2", s.buyLevel() === "ok" && s.s.level === 2, "lv=" + s.s.level);
    s.s.coins = 70;
    check("buy-to-inventory", s.buyItem("conveyor") === "ok" && s.owned("conveyor") && !s.placed("conveyor") && s.inInv("conveyor"), "inv");
    check("place-via-api", s.placeItem("conveyor") === "ok" && s.placed("conveyor") && !s.inInv("conveyor"), "placed");
    check("return-to-inventory", s.unplace("conveyor") === "ok" && s.inInv("conveyor"), "back");
    s.placeItem("conveyor");

    const locked = s.buyItem("autoPeeler");
    check("locked-lv3-item", locked === "locked", locked);

    check("no-move-pile", s.moveItem("pile", 40, 40) === false, "pile");
    check("no-move-ship", s.moveItem("ship", 40, 40) === false, "ship");
    check("no-move-ret", s.moveItem("ret", 40, 40) === false, "ret");

    const t0 = { x: (S.GEO.table.x0 + S.GEO.table.x1) / 2, y: (S.GEO.table.y0 + S.GEO.table.y1) / 2 };
    const b0 = { x0: kids.board.x0, y0: kids.board.y0, standY: kids.stand.y, spawnY: kids.peelSpawn.y };
    const stool0 = { x: S.GEO.stool.x, y: S.GEO.stool.y };
    const moved = s.moveItem("table", t0.x + 8, t0.y + 16);
    const k2 = S.tableKids(), T2 = S.GEO.table;
    check("move-table", moved === true, String(moved));
    check("board-follows-table", Math.abs((k2.board.x0 - b0.x0) - 8) < 0.2 && Math.abs((k2.board.y0 - b0.y0) - 16) < 0.2 &&
      k2.board.x0 >= T2.x0 - 0.05 && k2.board.x1 <= T2.x1 + 0.05 && k2.board.y0 >= T2.y0 - 0.05 && k2.board.y1 <= T2.y1 + 0.05,
      JSON.stringify({ board: k2.board, table: T2, d: [k2.board.x0 - b0.x0, k2.board.y0 - b0.y0] }));
    check("stand-and-spawn-follow", Math.abs((k2.stand.y - b0.standY) - 16) < 0.2 && Math.abs((k2.peelSpawn.y - b0.spawnY) - 16) < 0.2, "stand " + b0.standY + "->" + k2.stand.y);
    const cc = { x: (S.GEO.cooler.x0 + S.GEO.cooler.x1) / 2, y: (S.GEO.cooler.y0 + S.GEO.cooler.y1) / 2 };
    s.moveItem("cooler", cc.x - 5, cc.y + 10);
    check("seat-follows-cooler", Math.abs((S.GEO.stool.x - stool0.x) + 5) < 0.3 && Math.abs((S.GEO.stool.y - stool0.y) - 10) < 0.3,
      JSON.stringify({ stool: S.GEO.stool, food: S.SPOT.food }));

    // tools equip
    const B = S.fresh(5);
    B.s.coins = 80;
    check("buy-carry-inv", B.buyItem("carryBag") === "ok" && B.carryCap() === 1 && B.inInv("carryBag"), "cap=" + B.carryCap());
    check("equip-carry", B.equip("carryBag") === "ok" && B.equipped("carryBag") && B.carryCap() === 2, "cap=" + B.carryCap());
    const pile0 = B.s.pile, tot0 = B.total();
    B.s.g.hold = null; B.s.g.held = 0; B.s.g.act = { t: "grab", e: 0, label: "grabbing potatoes" };
    for (let i = 0; i < 20; i++) B.step(0.1);
    check("carry-grabs-cap", B.heldN() === 2 && B.s.g.hold === "raw" && B.s.pile === pile0 - 2 && B.total() === tot0,
      "held=" + B.heldN() + " pile " + pile0 + "->" + B.s.pile);
    B.s.coins = 80; B.buyUp("bag");
    check("carry-cap-upgrade", B.carryCap() === 3, "cap=" + B.carryCap());
    B.unequip("carryBag");
    check("unequip-carry", !B.equipped("carryBag") && B.carryCap() === 1 && B.inInv("carryBag"), "cap=" + B.carryCap());

    // save/load inventory
    B.equip("carryBag");
    const raw = B.serialize();
    const loaded = S.load(raw);
    check("saveload-equip", loaded && loaded.equipped("carryBag") && loaded.carryCap() === 3, "cap=" + (loaded && loaded.carryCap()));

    // pre-inventory v4 migrates owned as placed/equipped
    const raw2 = S.fresh(1).serialize();
    const o = JSON.parse(raw2);
    delete o.equipped;
    o.owned = { sink: 1, betterPeeler: 1 };
    o.place = {};
    const mig = S.load(JSON.stringify(o));
    check("migrate-owned-as-placed", mig && mig.placed("sink") && mig.equipped("betterPeeler"), "sink=" + (mig && mig.placed("sink")) + " peeler=" + (mig && mig.equipped("betterPeeler")));

    // line conservation + shipping (must PLACE machines)
    const Ln = S.fresh(3);
    Ln.s.level = 5; Ln.s.coins = 2000;
    ["conveyor", "suction", "autoPeeler", "outConveyor"].forEach((id) => { Ln.buyItem(id); Ln.placeItem(id); });
    Ln.s.box.suction = 1; Ln.s.box.conveyor = 2; Ln.s.box.apeeler = 2; Ln.s.box.outbelt = 2;
    Ln.s.potCap = 8; Ln.s.box.pot = 8; Ln.retarget();
    const start = Ln.total();
    let minTot = start, maxTot = start;
    for (let i = 0; i < 800; i++) { Ln.step(0.05); const tot = Ln.total(); if (tot < minTot) minTot = tot; if (tot > maxTot) maxTot = tot; }
    const lt = Ln.lineTotals();
    check("line-conservation", minTot === start && maxTot === start, "start=" + start + " min=" + minTot + " max=" + maxTot);
    check("line-ships", lt.shipped > 0, "shipped=" + lt.shipped + " peels=" + Ln.s.peels);
    check("peels-from-line", Ln.s.peels > 0, "peels=" + Ln.s.peels);

    Ln.setBox("apeeler", 0);
    for (let i = 0; i < 200; i++) Ln.step(0.05);
    const shippedAt = Ln.s.line.shipped;
    for (let i = 0; i < 80; i++) Ln.step(0.05);
    check("cmd-peeler-off", Ln.s.line.shipped === shippedAt && Ln.total() === start, "shipped " + Ln.s.line.shipped + " vs " + shippedAt);
    Ln.setBox("apeeler", 2); Ln.setBox("outbelt", 0);
    for (let i = 0; i < 80; i++) Ln.step(0.05);
    const sh2 = Ln.s.line.shipped;
    for (let i = 0; i < 80; i++) Ln.step(0.05);
    check("cmd-outbelt-off", Ln.s.line.shipped === sh2 && Ln.total() === start, "held");
    Ln.setBox("outbelt", 2); Ln.setBox("suction", 0);
    const pileAt = Ln.s.pile;
    for (let i = 0; i < 80; i++) Ln.step(0.05);
    check("cmd-suction-off", Ln.s.pile >= pileAt && Ln.total() === start, "pile " + pileAt + "->" + Ln.s.pile);

    // plant: must be placed
    const D = S.fresh(9);
    D.s.level = 2; D.s.coins = 200; D.buyItem("plant"); D.placeItem("plant");
    D.s.decor.plant = 80; D.setBox("water", 40); D.decide();
    let watered = false;
    for (let i = 0; i < 400; i++) { D.step(0.05); if (D.s.g.act && (D.s.g.act.t === "water" || (D.s.g.act.t === "walk" && D.s.g.act.then === "water"))) watered = true; }
    check("water-job", watered || D.s.decor.plant < 80, "plant=" + D.s.decor.plant + " watered=" + watered);

    // CLEAN walks to peels and removes nearby ones
    const C = S.fresh(4);
    C.peelEmit(16, "table");
    const cl = C.nearestMess();
    const sp = C.sweepSpot();
    check("sweep-spot-near-cluster", cl && sp && Math.hypot(sp.x - cl.x, sp.y - cl.y) <= 18, JSON.stringify({ sp, cx: cl && cl.x, cy: cl && cl.y, n: cl && cl.n }));
    C.s.g.x = sp.x / S.RW; C.s.g.y = sp.y / S.RH;
    const got = C.sweepNear(sp.x, sp.y, 6);
    const maxD = C.lastSweep && C.lastSweep.removed.length ? Math.max.apply(null, C.lastSweep.removed.map((r) => r.d)) : 99;
    check("sweep-removes-near", got === 6 && maxD <= 16, "got=" + got + " maxD=" + maxD + " left=" + C.s.peels);

    // TV must be placed
    const W = S.fresh(6);
    W.s.level = 4; W.s.coins = 200; W.buyItem("tvArmchair"); W.placeItem("tvArmchair");
    W.s.box.tv = 1; W.s.box.watch = 40; W.s.box.eat = 0; W.s.box.nap = 0; W.s.box.clean = 0;
    W.s.energy = 30; W.s.hunger = 100; W.s.g.hold = null; W.s.g.act = null; W.s.g.job = "pile"; W.decide();
    let watching = false;
    for (let i = 0; i < 500; i++) { W.step(0.05); if (W.s.g.act && (W.s.g.act.t === "watch" || (W.s.g.act.t === "walk" && W.s.g.act.then === "watch"))) watching = true; }
    check("watch-job", watching, "act=" + (W.s.g.act && W.s.g.act.t));

    // path around bed and table (no cutting through)
    const Pth = S.fresh(2);
    Pth.rebuildObst();
    const bed = S.GEO.mat, bedBox = { x0: bed.x - bed.w / 2, y0: bed.y - bed.h / 2, x1: bed.x + bed.w / 2, y1: bed.y + bed.h / 2 };
    const side = S.bedside();
    const around = S.route(bed.x - 34, bed.y, side.x, side.y);
    function hits(path, b) {
      for (let i = 0; i < path.length - 1; i++) {
        const ax = path[i][0], ay = path[i][1], bx = path[i + 1][0], by = path[i + 1][1];
        for (const f of [0.2, 0.4, 0.6, 0.8]) {
          const x = ax + (bx - ax) * f, y = ay + (by - ay) * f;
          if (x > b.x0 + 0.6 && x < b.x1 - 0.6 && y > b.y0 + 0.6 && y < b.y1 - 0.6) return { x, y };
        }
      }
      return null;
    }
    const tb = S.GEO.table;
    const work = S.route(S.SPOT.pile.x0 + 10, S.SPOT.pile.y, S.SPOT.ship.x, S.SPOT.ship.y);
    const aroundT = S.route(20, tb.y1 + 20, 90, tb.y1 + 20);
    check("path-around-bed", around.length >= 2 && !hits(around, bedBox), JSON.stringify({ around, hit: hits(around, bedBox) }));
    check("path-around-table", work.length >= 2 && !hits(work, tb) && (aroundT.length < 2 || !hits(aroundT, tb)), JSON.stringify({ work, aroundT, hitW: hits(work, tb), hitT: hits(aroundT, tb) }));
    const bs = S.bedside();
    check("bedside-outside", !(bs.x > bedBox.x0 && bs.x < bedBox.x1 && bs.y > bedBox.y0 && bs.y < bedBox.y1) && bs.y > bedBox.y1, JSON.stringify(bs));

    out.kids = k2;
    return out;
  });
  mech.checks.forEach((c) => ok("mech:" + c.n, c.pass, c.d));

  // ========== GUI / VISUALS ==========
  const gui = await ev(() => {
    const out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }
    check("version", PP.version === "0.4.2", PP.version);
    const z = PP.zoom();
    check("zoom-locked-fit", z.fit === true && z.k === 1 && z.panX === 0 && z.panY === 0, JSON.stringify(z));
    PP.setZoom(4);
    check("zoom-in-ignored", PP.zoom().k === 1 && PP.zoom().fit === true, JSON.stringify(PP.zoom()));
    const panPad = document.getElementById("panPad");
    const zoomRail = document.getElementById("zoomRail");
    const left = document.getElementById("leftRail");
    const right = document.getElementById("rightRail");
    function hidden(el) { if (!el) return true; const cs = getComputedStyle(el); return cs.display === "none" || cs.visibility === "hidden"; }
    check("pan-arrows-hidden", hidden(panPad) && hidden(left), "pan");
    check("zoom-rail-hidden", hidden(zoomRail) && hidden(right), "zoom");
    check("edit-btn-present", !!document.getElementById("editBtn"), "edit");
    check("inv-btn-present", !!document.getElementById("invBtn"), "inv");
    check("labels-hidden", PP.labelsHidden() === true, "labels");
    const tags = PP.tagRects();
    const anyOn = Object.keys(tags).some((id) => tags[id].display !== "none");
    check("all-tags-display-none", !anyOn, JSON.stringify(tags));
    const lay = PP.layout();
    check("room-fits", lay.fitW <= lay.W + 0.5 && lay.fitH <= lay.H + 0.5 && (lay.fitW >= lay.W * 0.96 || lay.fitH >= lay.H * 0.96), JSON.stringify({ W: lay.W, H: lay.H, fitW: lay.fitW, fitH: lay.fitH, k: lay.k }));
    return out;
  });
  gui.checks.forEach((c) => ok("gui:" + c.n, c.pass, c.d));

  async function chromeCheck(label) {
    const r = await ev(() => {
      function box(el) {
        if (!el) return { id: "missing", l: 0, t: 0, r: 0, b: 0, w: 0, h: 0, display: "none" };
        const r = el.getBoundingClientRect();
        return { id: el.id, l: r.left, t: r.top, r: r.right, b: r.bottom, w: r.width, h: r.height, display: getComputedStyle(el).display };
      }
      function hit(a, b, pad) {
        if (a.display === "none" || b.display === "none") return false;
        return a.l < b.r - pad && a.r > b.l + pad && a.t < b.b - pad && a.b > b.t + pad;
      }
      const play = box(document.getElementById("play"));
      const tray = box(document.getElementById("invTray"));
      const hud = box(document.getElementById("hud"));
      const cmd = box(document.getElementById("cmd"));
      const edit = box(document.getElementById("editBtn"));
      const hits = [];
      [hud, cmd].forEach((c) => { if (hit(c, play, 0.5)) hits.push(c.id + " overlaps play"); });
      if (tray.display !== "none" && hit(tray, play, 0.5)) hits.push("invTray overlaps play");
      if (edit.display !== "none" && hit(edit, play, 0.5)) hits.push("editBtn overlaps play");
      return { hits, play: { w: +play.w.toFixed(1), h: +play.h.toFixed(1) }, tray: { d: tray.display, h: +tray.h.toFixed(1) }, editOn: document.getElementById("app").classList.contains("editing") };
    });
    ok("gui:no-overlay@" + label, r.hits.length === 0 && r.play.w > 120 && r.play.h > 80, JSON.stringify(r));
    return r;
  }
  await chromeCheck("360x800-normal");
  await ev(() => { PP.edit(true); });
  await L.sleep(80);
  const trayOn = await ev(() => PP.tray());
  ok("gui:editor-tray-open", trayOn.open === true && trayOn.edit === true, JSON.stringify(trayOn));
  await chromeCheck("360x800-edit");
  await ev(() => { PP.edit(false); });

  await p.setViewport({ width: 320, height: 568, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await L.sleep(80);
  await ev(() => { window.dispatchEvent(new Event("resize")); });
  await L.sleep(40);
  await chromeCheck("320x568-normal");
  await ev(() => { if (!PP.edit()) PP.edit(true); });
  await L.sleep(80);
  await chromeCheck("320x568-edit");
  await ev(() => { if (PP.edit()) PP.edit(false); });
  await p.setViewport({ width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await ev(() => { window.dispatchEvent(new Event("resize")); });
  await L.sleep(40);

  // sit pose at fitted view (zoom locked)
  const sitVis = await ev(() => {
    PP.reset(2); PP.giveAll(); PP.pause(true);
    const s = PP.sim, sit = s.sitSpot();
    s.s.box.tv = 1; s.startAt("watch");
    PP.drawAt(2400);
    const cv = PP.cv(), ctx = cv.getContext("2d"), lay = PP.layout(), dpr = lay.dpr, k = lay.k, offX = lay.offX, offY = lay.offY;
    function sample(wx, wy) {
      const x = Math.round((wx * k + offX) * dpr), y = Math.round((wy * k + offY) * dpr);
      if (x < 0 || y < 0 || x >= cv.width || y >= cv.height) return null;
      const d = ctx.getImageData(x, y, 1, 1).data;
      return [d[0], d[1], d[2], d[3]];
    }
    function near(px, rgb, tol) {
      if (!px || px[3] < 10) return false;
      return Math.abs(px[0] - rgb[0]) <= tol && Math.abs(px[1] - rgb[1]) <= tol && Math.abs(px[2] - rgb[2]) <= tol;
    }
    let hair = 0, shirt = 0, skin = 0;
    for (let dx = -6; dx <= 8; dx += 2) for (let dy = -6; dy <= 6; dy += 2) {
      const px = sample(sit.x + dx, sit.y + dy);
      if (near(px, [42, 32, 24], 28) || near(px, [58, 42, 32], 28) || near(px, [26, 20, 16], 24)) hair++;
      if (near(px, [58, 106, 138], 40) || near(px, [42, 74, 98], 40) || near(px, [90, 136, 168], 40) || near(px, [122, 168, 192], 40) || near(px, [26, 48, 66], 28)) shirt++;
      if (near(px, [196, 160, 112], 36) || near(px, [216, 184, 136], 36)) skin++;
    }
    return { hair, shirt, skin, sit, dir: s.s.g.dir, act: s.s.g.act && s.s.g.act.t };
  });
  ok("gui:watch-sit-pose", sitVis.act === "watch" && sitVis.dir === 1 && sitVis.hair >= 2 && (sitVis.shirt >= 1 || sitVis.skin >= 8), JSON.stringify(sitVis));

  const bagVis = await ev(() => {
    PP.reset(2); PP.giveAll(); PP.pause(true);
    const s = PP.sim;
    s.s.g.hold = "raw"; s.s.g.held = s.carryCap(); s.s.g.act = { t: "idle", e: 0, d: 2, label: "carrying" };
    s.s.g.x = 0.36; s.s.g.y = 0.82; s.s.g.dir = 0;
    PP.drawAt(1800);
    return { held: s.heldN(), cap: s.carryCap(), hold: s.s.g.hold };
  });
  ok("gui:carry-bag-held", bagVis.held >= 2 && bagVis.held === bagVis.cap && bagVis.hold === "raw", JSON.stringify(bagVis));

  // editor follow via PP.follow after moving every starter + a placed item
  const follow = await ev(() => {
    PP.reset(2); PP.pause(true);
    const s = PP.sim, S = PP.Sim, out = { checks: [] };
    function check(n, v, d) { out.checks.push({ n, pass: !!v, d: d == null ? "" : String(d) }); }
    const before = PP.follow("table");
    s.moveItem("table", before.table.x0 / 1 + 17 + 10, (before.table.y0 + before.table.y1) / 2 + 18);
    const after = PP.follow("table");
    const ot = (after.obst || []).find((b) => b.id === "table");
    check("moved-table-board-on-it", after.boardOnTable && after.standBeside, JSON.stringify(after));
    check("obst-follows-table", ot && Math.abs(ot.x0 - after.table.x0) < 0.2 && Math.abs(ot.y0 - after.table.y0) < 0.2, JSON.stringify(ot));
    check("kids-moved", after.board.x0 !== before.board.x0 && after.stand.y !== before.stand.y, "board " + before.board.x0 + "->" + after.board.x0);
    s.s.level = 5; s.s.coins = 5000;
    s.buyItem("sink"); const pr = s.placeItem("sink", 30, 160);
    check("place-sink-editor", pr === "ok" && s.placed("sink"), pr);
    const sink0 = s.placeOf("sink");
    s.moveItem("sink", sink0.x + 6, sink0.y - 8);   // 0.4.2: +8 down would seal the food corner (now refused by the no-trap rule)
    const sink1 = s.placeOf("sink");
    check("sink-spot-follows", Math.abs(sink1.x - (sink0.x + 6)) < 0.2 && Math.abs(sink1.y - (sink0.y - 8)) < 0.2 && Math.abs(S.SPOT.sink.x - sink1.x) < 0.2 && Math.abs(S.SPOT.sink.y - (sink1.y + 12)) < 0.2,
      JSON.stringify({ sink0, sink1, spot: S.SPOT.sink }));
    const un = s.unplace("sink");
    check("return-sink", un === "ok" && !s.placed("sink") && s.inInv("sink"), un);
    out.before = before; out.after = after;
    return out;
  });
  follow.checks.forEach((c) => ok("editor:" + c.n, c.pass, c.d));

  // inventory overlay
  const invUi = await ev(() => {
    PP.reset(2); PP.pause(true);
    const s = PP.sim;
    s.s.coins = 200; s.s.level = 2;
    s.buyItem("betterPeeler"); s.buyItem("sink");
    PP.open("inv");
    const title = document.getElementById("ovlTitle") && document.getElementById("ovlTitle").textContent;
    const body = document.getElementById("ovlBody") && document.getElementById("ovlBody").innerText;
    const on = PP.ovl() === "inv";
    return { on, title, hasEquip: /EQUIP/.test(body || ""), hasPlace: /EDIT TO PLACE/.test(body || ""), body: (body || "").slice(0, 240) };
  });
  ok("gui:inventory-overlay", invUi.on && invUi.title === "INVENTORY" && invUi.hasEquip && invUi.hasPlace, JSON.stringify(invUi));
  await ev(() => PP.close());

  // ========== ARCADE ==========
  await ev(() => { PP.reset(8); PP.giveAll(); PP.pause(false); });
  await ev(() => { const s = PP.sim; s.setBox("eat", 40); s.setBox("nap", 35); s.s.food = 6; });
  const arcade = await ev(() => {
    const s = PP.sim;
    const startT = s.s.t, startC = s.s.coins, startP = s.total();
    for (let i = 0; i < 600; i++) s.step(0.05);
    return { dt: s.s.t - startT, coins: s.s.coins, startC, tot: s.total(), startP, shipped: s.s.line && s.s.line.shipped, peels: s.s.peels, state: s.stateName(), version: PP.version };
  });
  ok("arcade:version", arcade.version === "0.4.2", arcade.version);
  ok("arcade:time-advances", arcade.dt >= 29, "dt=" + arcade.dt);
  ok("arcade:conserved", arcade.tot === arcade.startP, arcade.tot + "/" + arcade.startP);
  ok("arcade:line-or-loop-earns", arcade.coins >= arcade.startC, "coins " + arcade.startC + "->" + arcade.coins);
  ok("arcade:peels-inside-budget", arcade.peels >= 0 && arcade.peels < 200, "peels=" + arcade.peels);

  // ========== BUFF ==========
  const buff = await ev(() => {
    const s = PP.Sim.fresh(11);
    s.s.level = 5; s.s.coins = 5000;
    PP.Sim.ITEMS.forEach((it) => {
      s.s.owned[it.id] = 1;
      if (PP.Sim.isTool(it.id)) s.s.equipped[it.id] = 1;
      if (PP.Sim.isPlaceable(it.id)) s.s.place[it.id] = PP.Sim.defaultPlace(it.id);
    });
    s.syncGeom(); s.rebuildObst();
    s.s.box.suction = 1; s.s.box.conveyor = 3; s.s.box.apeeler = 3; s.s.box.outbelt = 3;
    s.s.box.eat = 40; s.s.box.nap = 30; s.s.box.clean = 40; s.s.food = 12; s.s.potCap = 17; s.s.box.pot = 17; s.retarget();
    const start = s.total();
    let minT = start, maxT = start;
    const t0 = performance.now();
    for (let i = 0; i < 72000; i++) { s.step(0.05); const t = s.total(); if (t < minT) minT = t; if (t > maxT) maxT = t; }
    const ms = performance.now() - t0;
    return { hours: s.s.t / 3600, start, minT, maxT, shipped: s.s.line.shipped, peels: s.s.peels, coins: s.s.coins, ms };
  });
  ok("buff:conservation-1h", buff.minT === buff.start && buff.maxT === buff.start, JSON.stringify({ start: buff.start, minT: buff.minT, maxT: buff.maxT, hours: buff.hours.toFixed(2) }));
  ok("buff:ran", buff.hours >= 0.99, "hours=" + buff.hours.toFixed(2) + " shipped=" + buff.shipped);

  // ========== PERF ==========
  await ev(() => { PP.reset(1); PP.giveAll(); });
  const perf = await ev(() => new Promise((resolve) => {
    const budget = 1000 / 60, warmup = 15, n = 90;
    const times = [];
    let i = 0;
    function tick(ts) {
      const t0 = performance.now();
      PP.drawAt(ts);
      const dt = performance.now() - t0;
      if (i >= warmup) times.push(dt);
      i++;
      if (i < warmup + n) requestAnimationFrame(tick);
      else {
        times.sort((a, b) => a - b);
        const sum = times.reduce((a, b) => a + b, 0);
        let over = 0;
        for (let k = 0; k < times.length; k++) if (times[k] > budget) over++;
        resolve({ n: times.length, avg: sum / times.length, p50: times[Math.floor(times.length * 0.5)], p95: times[Math.min(times.length - 1, Math.floor(times.length * 0.95))], max: times[times.length - 1], over, budget });
      }
    }
    requestAnimationFrame(tick);
  }));
  ok("perf:avg-under-budget", perf.avg < perf.budget, JSON.stringify(perf));
  ok("perf:p95-under-budget", perf.p95 < perf.budget, "p95=" + perf.p95.toFixed(2));
  ok("perf:no-over", perf.over === 0, "over=" + perf.over + "/" + perf.n);

  ok("boot:no-page-errors", errs.length === 0, errs.join(" | "));

  const fail = R.filter((r) => !r.pass);
  const summary = { total: R.length, pass: R.length - fail.length, fail: fail.length, fails: fail, perf, buff, errs };
  L.fs.writeFileSync(OUT + "/results.json", JSON.stringify(summary, null, 2));
  L.fs.writeFileSync(OUT + "/results.txt", R.map((r) => (r.pass ? "PASS" : "FAIL") + "  " + r.n + "  " + r.d).join("\n") + "\n\n" + (fail.length ? "FAILURES: " + fail.length : "ALL GREEN " + R.length + "/" + R.length) + "\n");
  console.log(fail.length ? ("FAILURES " + fail.length + "/" + R.length) : ("ALL GREEN " + R.length + "/" + R.length));
  await b.close();
  process.exit(fail.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
