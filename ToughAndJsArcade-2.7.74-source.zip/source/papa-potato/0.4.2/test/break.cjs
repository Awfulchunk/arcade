// Papa Potato editor break test: move every placeable near each other, run the sim, find stuck states.
const path=require("path").resolve(process.argv[2]||__dirname+"/../src/sim.js");
delete require.cache[require.resolve(path)];
const S=require(path);
const MOVABLE=["table","cooler","stool","mat","sink","smallCooler","basicCot","plant","lamp","radio","rug","tvArmchair","autoPeeler"];
function rng(seed){let a=seed>>>0;return()=>{a=(a+0x6D2B79F5)|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function setup(seed,mode){
  const sim=S.fresh(seed),s=sim.s,r=rng(seed*7+1);
  s.level=5;s.coins=500;s.food=6;
  for(const it of S.ITEMS){if(it.id==="conveyor"||it.id==="outConveyor"||it.id==="suction")continue;s.owned[it.id]=1;if(S.isTool(it.id))s.equipped[it.id]=(mode&1)?1:0;}
  sim.syncGeom();sim.rebuildObst();
  for(const id of MOVABLE){if(S.isPlaceable(id))sim.placeItem(id);}
  s.box.clean=15;s.box.eat=30;s.box.nap=25;s.box.autob=4;s.box.wash=(mode&2)?1:0;s.box.water=40;s.box.tv=1;s.box.watch=0;s.box.radio=1;s.box.pot=8;s.potCap=8;sim.retarget();
  // cluster: everything near a random centre
  const cx=15+r()*78,cy=20+r()*200,spread=mode&4?12:30;
  const moved={};sim._moved=moved;
  for(const id of MOVABLE){const x=cx+(r()-0.5)*2*spread,y=cy+(r()-0.5)*2*spread;moved[id]=sim.moveItem(id,x,y);
    if(sim.rotateItem&&r()<0.5)sim.rotateItem(id);}
  // sometimes table against the back (top) wall
  if(seed%3===0)sim.moveItem("table",20+r()*68,14);
  sim.decide();
  return sim;
}
function run(seed,mode,secs){
  const sim=setup(seed,mode),s=sim.s,dt=0.05;let lastProg=0,lastPeeled=0,maxGap=0,acts={},repeat=0,lastKey="",peelFar=0,dropFar=0,drops=0,peelChecks=0,lastShip=0;
  let prevAct=null;
  for(let i=0;i<secs/dt;i++){
    if(mode&8&&i%400===200){const r2=rng(seed+i);const id=MOVABLE[Math.floor(r2()*MOVABLE.length)];sim.moveItem(id,10+r2()*88,15+r2()*220);if(r2()<0.5)sim.rotateItem&&sim.rotateItem(id);}
    sim.step(dt);
    const a=s.g.act;
    if(a&&a!==prevAct){prevAct=a;const key=a.t+":"+(a.then||"");acts[key]=(acts[key]||0)+1;
      if(a.t==="peel"&&sim.atTable){peelChecks++;if(!sim.atTable())peelFar++;}
      if(a.t==="drop"){drops++;const d=Math.hypot(s.g.x*S.RW-S.SPOT.ship.x,s.g.y*S.RH-S.SPOT.ship.y);if(d>1.0)dropFar++;}
    }
    if(s.stats.peeled!==lastPeeled){lastPeeled=s.stats.peeled;lastProg=s.t;}
    const gap=s.t-lastProg;if(gap>maxGap)maxGap=gap;
  }
  const tot=Object.values(acts).reduce((a,b)=>a+b,0);
  const okMoves=Object.values(sim._moved).filter(Boolean).length;
  return {okMoves,loops:s.stats.loopBreaks|0,seed,mode,peeled:s.stats.peeled,maxGap:+maxGap.toFixed(1),sweeps:s.stats.sweeps,peels:s.peels,acts,peelFar,peelChecks,dropFar,drops,total:sim.total(),want:S.POTS[s.box.pot],lazy:s.stats.lazyTime|0};
}
const N=+process.argv[3]||60,secs=+process.argv[4]||900;let bad=0,rows=[];
for(let seed=1;seed<=N;seed++){const mode=seed%16;const r=run(seed,mode,secs);rows.push(r);
  const stuck=r.maxGap>120||r.peelFar>0||r.dropFar>0||r.total!==r.want||r.peeled<20;
  if(stuck){bad++;console.log("BAD",JSON.stringify(r));}}
console.log("okMoves avg",(rows.reduce((a,r)=>a+r.okMoves,0)/N).toFixed(1),"of",MOVABLE.length,"loopBreaks total",rows.reduce((a,r)=>a+r.loops,0),"peelChecks",rows.reduce((a,r)=>a+r.peelChecks,0),"drops",rows.reduce((a,r)=>a+r.drops,0));
const gaps=rows.map(r=>r.maxGap).sort((a,b)=>a-b);
console.log(`runs=${N} bad=${bad} medianPeeled=${rows.map(r=>r.peeled).sort((a,b)=>a-b)[N>>1]} maxGap(p50/max)=${gaps[N>>1]}/${gaps[N-1]}`);
process.exit(bad?1:0);
