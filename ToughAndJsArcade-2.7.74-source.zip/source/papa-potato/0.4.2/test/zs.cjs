const L=require("./lib.cjs");(async()=>{const b=await L.browser();const {p}=await L.open(b,[360,800],{dpr:2});
await p.evaluate(()=>{PP.reset(9);const s=PP.sim.s;PP.pause(true);s.g.act={t:"idle",d:9999,e:0,label:"x"};s.g.x=0.12;s.g.y=0.45;PP.sim.setBox("pot",8);s.chute=6;s.pile-=6;PP.sim.startSuck();});
const o=[];for(let off=0;off<=6;off+=0.04){o.push(await p.evaluate((o)=>{PP.sim.s.suck.t0=PP.sim.s.t-o;PP.sim.s.suck.landed=0;const v=PP.retView()[0];return v?[+o.toFixed(2),v.p,v.z&&+v.z.toFixed(1)]:null},off));}
console.log(JSON.stringify(o.filter(x=>x&&x[1]>=0)));console.log(JSON.stringify(await p.evaluate(()=>PP.Sim.spill(PP.sim.s.suck.t0,6))));await b.close()})();
