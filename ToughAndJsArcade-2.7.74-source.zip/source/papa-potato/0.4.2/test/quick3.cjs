const L=require("./lib.cjs");
(async()=>{const b=await L.browser();const sz=(process.argv[2]||"360x800").split("x").map(Number);
 const {p,errs}=await L.open(b,sz,{dpr:2,url:"file:///workspace/game/build-potato3/out/papa-potato-0.3.html"});
 await p.evaluate(()=>{PP.open("help")});await L.sleep(400);await p.screenshot({path:`out/b0-${sz[0]}.png`});
 for(const n of [1,5]){await p.evaluate((n)=>{for(let i=0;i<n;i++)PP.flip(1)},n);await L.sleep(600);await p.screenshot({path:`out/b${n}-${sz[0]}.png`});}
 await p.evaluate(()=>{PP.close();PP.open("shop");PP.sim.s.coins=60});await L.sleep(500);await p.screenshot({path:`out/shop-${sz[0]}.png`});
 console.log(errs);await b.close();})();
