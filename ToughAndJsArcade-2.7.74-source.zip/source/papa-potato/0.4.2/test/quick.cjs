const L=require("./lib.cjs");
(async()=>{const b=await L.browser();const sz=(process.argv[2]||"360x800").split("x").map(Number);
 const {p,errs}=await L.open(b,sz,{url:"file:///workspace/game/build-potato3/out/papa-potato-0.3.html"});
 const secs=+(process.argv[3]||5);
 await p.evaluate(()=>{PP.sim.s.box.eat=30;PP.sim.s.box.nap=30;PP.sim.s.box.clean=40;});
 await L.sleep(secs*1000);
 await p.screenshot({path:process.argv[4]||"out/q.png"});
 console.log(JSON.stringify(await p.evaluate(()=>({l:PP.layout(),st:PP.sim.s.stats,pile:PP.sim.s.pile,peels:PP.sim.s.peels}))));
 console.log("errs",errs);await b.close();})();
