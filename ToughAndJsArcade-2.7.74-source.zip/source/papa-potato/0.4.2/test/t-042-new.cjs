// Papa Potato 0.4.2 — new-feature hard test (Jay t1116 notes): table anywhere, sack on the floor, sink dump, exact shipping X,
// ROTATE, tap-for-info on the right HUD, scroll-safe sliders, editor break (stuck states). Headless Chrome 360x800@2 + 320x568@2.
const L = require("./lib.cjs");
const { ok, R } = L.reporter();
const OUT = "/workspace/game/build-potato042/out/t-042-new";
L.fs.mkdirSync(OUT, { recursive: true });
const URL = "file:///workspace/game/build-potato042/out/papa-potato-0.4.2.html";
(async () => {
  const b = await L.browser();
  const { p, errs } = await L.open(b, [360, 800], { dpr: 2, url: URL });
  const ev = (fn, ...a) => p.evaluate(fn, ...a);
  const shot = async (n) => { await ev(() => { PP.drawAt(performance.now()); }); await p.screenshot({ path: OUT + "/" + n + ".png" }); };
  await ev(() => { PP.pause(true); PP.reset(11); });
  const toScreen = async (x, y) => ev((x, y) => { const L = PP.layout(), r = document.getElementById("play").getBoundingClientRect(); return { x: r.left + L.offX + x * L.k, y: r.top + L.offY + y * L.k }; }, x, y);
  const runUntil = (pred, max) => ev((pred, max) => { const f = new Function("s", "S", "return " + pred); const s = PP.sim, S = PP.Sim; for (let i = 0; i < max; i++) { s.step(0.05); if (f(s, S)) return { ok: true, i, t: s.s.t }; } return { ok: false }; }, pred, max);

  // 1) table against the back wall: he peels AT it
  let r = await ev(() => { const s = PP.sim; const ok = PP.move("table", 30, 15) !== false; const T = PP.Sim.GEO.table; return { ok, T: { x0: T.x0, y0: T.y0, x1: T.x1, y1: T.y1 }, stand: PP.Sim.SPOT.table }; });
  ok("table:moved-to-back-wall", r.ok && r.T.y0 <= 11, r);
  let u = await runUntil('s.s.g.act&&s.s.g.act.t==="peel"&&s.s.g.peel>0.3', 6000);
  r = await ev(() => { const s = PP.sim, g = s.s.g, T = PP.Sim.GEO.table; return { at: s.atTable(), x: g.x * PP.Sim.RW, y: g.y * PP.Sim.RH, dir: g.dir, T: { x0: T.x0, y0: T.y0, x1: T.x1, y1: T.y1 } }; });
  ok("table:back-wall-peels-at-table", u.ok && r.at && r.y > r.T.y1 && r.y - r.T.y1 <= 12, r);
  await shot("table-back-wall-peeling");
  // 2) rotate the table: footprint swaps, he still peels at it
  r = await ev(() => { const s = PP.sim; PP.move("table", 40, 120); const a = PP.rotate("table"); const T = PP.Sim.GEO.table; return { a, w: T.x1 - T.x0, h: T.y1 - T.y0, r: T.r, obst: PP.Sim.OBST.find((o) => o.id === "table") }; });
  ok("rotate:table-quarter-turn", r.a && r.r === 1 && Math.abs(r.w - 18) < 0.1 && Math.abs(r.h - 34) < 0.1 && Math.abs(r.obst.x1 - r.obst.x0 - 18) < 0.1, r);
  u = await runUntil('s.s.g.act&&s.s.g.act.t==="peel"&&s.s.g.peel>0.3', 6000);
  r = await ev(() => { const s = PP.sim; return { at: s.atTable(), kids: PP.Sim.tableKids(), T: PP.Sim.GEO.table }; });
  const bOn = r.kids.board.x0 >= r.T.x0 - 0.05 && r.kids.board.x1 <= r.T.x1 + 0.05 && r.kids.board.y0 >= r.T.y0 - 0.05 && r.kids.board.y1 <= r.T.y1 + 0.05;
  ok("rotate:peels-at-rotated-table", u.ok && r.at && bOn, { at: r.at, board: r.kids.board, T: r.T });
  await shot("table-rotated-peeling");
  r = await ev(() => { const s = PP.sim; let n = 0; for (let i = 0; i < 4; i++) if (s.rotateItem("mat")) n++; return { n, r: s.rotOf("mat"), bed: PP.Sim.GEO.mat }; });
  ok("rotate:bed-full-circle", r.n === 4 && r.r === 0, r);
  // 3) sack: only when equipped; set on the floor at the table, peeled one by one
  r = await ev(() => { PP.reset(12); const s = PP.sim; s.s.level = 5; s.s.coins = 999; s.buyItem("carryBag"); return { cap: s.carryCap() }; });
  ok("sack:not-used-unless-equipped", r.cap === 1, r);
  r = await ev(() => { const s = PP.sim; s.equip("carryBag"); return { cap: s.carryCap() }; });
  u = await runUntil('s.s.g.act&&s.s.g.act.t==="peel"&&s.s.g.peel>0.55', 6000);
  r = await ev(() => { const s = PP.sim, g = s.s.g, st = PP.Sim.SPOT.table; return { sack: g.sack, held: s.heldN(), at: s.atTable(), d: g.sack ? Math.hypot(g.sack.x - st.x, g.sack.y - st.y) : -1 }; });
  ok("sack:on-floor-beside-him", u.ok && r.sack && r.sack.n >= 2 && r.d > 3 && r.d < 14 && r.at, r);
  await shot("sack-on-floor");
  u = await runUntil('s.s.g.hold==="peeled"', 4000);
  r = await ev(() => ({ sack: PP.sim.s.g.sack, hold: PP.sim.s.g.hold }));
  ok("sack:picked-up-when-done", u.ok && !r.sack && r.hold === "peeled", r);
  // 4) exact shipping X
  u = await runUntil('s.s.g.act&&s.s.g.act.t==="drop"', 4000);
  r = await ev(() => { const g = PP.sim.s.g, S = PP.Sim; return { d: Math.hypot(g.x * S.RW - S.SPOT.ship.x, g.y * S.RH - S.SPOT.ship.y) }; });
  ok("ship:arrives-exactly-at-x", u.ok && r.d < 0.05, r);
  await shot("drop-at-x");
  // 5) sink: dumps the potatoes in it
  r = await ev(() => { const s = PP.sim; s.buyItem("sink"); const pr = s.placeItem("sink"); return { pr, wash: s.s.box.wash }; });
  ok("sink:placing-turns-wash-on", r.pr === "ok" && r.wash === 1, r);
  u = await runUntil('s.s.g.act&&s.s.g.act.t==="wash"&&s.s.g.act.e>0.6', 6000);
  r = await ev(() => { const s = PP.sim, a = s.s.g.act; return { t: a && a.t, label: a && a.label, n: a && a.n }; });
  ok("sink:dumps-in-sink", u.ok && /dumping/.test(r.label), r);
  await shot("sink-dump");
  // 6) moving furniture while he works never strands him; never on top of him
  r = await ev(() => { const s = PP.sim, g = s.s.g, x = g.x * PP.Sim.RW, y = g.y * PP.Sim.RH; return { onHim: s.moveItem("mat", x, y) && Math.hypot(PP.Sim.GEO.mat.x - x, PP.Sim.GEO.mat.y - y) < 4 }; });
  ok("editor:never-on-papa", !r.onHim, r);
  // 7) tap for info (play mode), right HUD, no overlap with the room
  await ev(() => { PP.reset(13); PP.pause(true); PP.drawAt(performance.now()); });
  const tc = await ev(() => { const T = PP.Sim.GEO.table; return { x: (T.x0 + T.x1) / 2, y: (T.y0 + T.y1) / 2 }; });
  let sc = await toScreen(tc.x, tc.y);
  await L.touchTapXY(p, sc.x, sc.y); await L.sleep(150);
  r = await ev(() => { const i = PP.info(), el = document.getElementById("objInfo").getBoundingClientRect(), pl = document.getElementById("play").getBoundingClientRect(), hud = document.getElementById("hud").getBoundingClientRect(); return { i, inHud: el.left >= hud.left - 0.5 && el.right <= hud.right + 0.5, overPlay: el.left < pl.right - 0.5 && el.right > pl.left + 0.5 && el.top < pl.bottom && el.bottom > pl.top, el: { l: el.left, t: el.top, w: el.width, h: el.height } }; });
  ok("info:tap-table-shows-name", r.i.on && r.i.name === "PEEL TABLE" && r.i.desc.length > 10, r);
  ok("info:on-right-hud-not-over-room", r.inHud && !r.overPlay, r);
  await shot("info-hud");
  // 8) editor: tap selects, ROTATE turns it
  await ev(() => PP.edit(true)); await L.sleep(150);
  const bc = await ev(() => ({ x: PP.Sim.GEO.mat.x, y: PP.Sim.GEO.mat.y }));
  sc = await toScreen(bc.x, bc.y);
  await L.touchTapXY(p, sc.x, sc.y); await L.sleep(150);
  const r0 = await ev(() => PP.sim.rotOf("mat"));
  await L.touchTap(p, "#rotBtn"); await L.sleep(200);
  r = await ev(() => ({ rot: PP.sim.rotOf("mat"), info: PP.info(), rb: getComputedStyle(document.getElementById("rotBtn")).display, h: document.getElementById("rotBtn").getBoundingClientRect().height }));
  ok("editor:rotate-button-turns-bed", r0 === 0 && r.rot === 1 && r.info.name === "BED", r);
  ok("editor:rotate-button-tap-size", r.h >= 44, r.h);
  await shot("editor-rotate-bed");
  await ev(() => PP.edit(false));
  // 9) sliders: scroll never changes values
  const sl = await ev(() => { const box = document.querySelector('#cmd .box[data-id="pace"]'); box.scrollIntoView({ block: "center" }); const t = box.querySelector(".trk").getBoundingClientRect(); return { x: t.left + t.width / 2, y: t.top + t.height / 2, w: t.width }; });
  await L.touchTapXY(p, sl.x, sl.y + 0); await L.sleep(120); // focus (tap on the track of an unfocused box only focuses)
  const v0 = await ev(() => PP.sim.s.box.pace);
  await L.touchDrag(p, sl.x, sl.y, sl.x + 30, sl.y + 120, 12); // mostly vertical, starts on the track
  const v1 = await ev(() => PP.sim.s.box.pace);
  ok("slider:vertical-drag-on-track-scrolls-not-adjusts", v0 === v1, { v0, v1 });
  const s2 = await ev(() => { const box = document.querySelector('#cmd .box[data-id="pace"]'); box.scrollIntoView({ block: "center" }); const t = box.querySelector(".trk").getBoundingClientRect(); return { x: t.left + t.width / 2, y: t.top + t.height / 2, w: t.width, nm: box.querySelector(".nm") ? (function (q) { return { left: q.left, top: q.top, height: q.height }; })(box.querySelector(".nm").getBoundingClientRect()) : null }; });
  await L.touchTapXY(p, s2.x, s2.y); await L.sleep(120);
  const f0 = await ev(() => PP.focus());
  const v2 = await ev(() => PP.sim.s.box.pace);
  await L.touchDrag(p, s2.x, s2.y, s2.x - s2.w * 0.45, s2.y + 4, 10);
  const v3 = await ev(() => PP.sim.s.box.pace);
  ok("slider:horizontal-drag-on-focused-track-adjusts", f0 === "pace" && v3 !== v2, { f0, v2, v3 });
  if (s2.nm) { const v4 = await ev(() => PP.sim.s.box.pace); await L.touchDrag(p, s2.nm.left + 6, s2.nm.top + s2.nm.height / 2, s2.nm.left + 6 + 60, s2.nm.top + s2.nm.height / 2 + 2, 10); const v5 = await ev(() => PP.sim.s.box.pace); ok("slider:sideways-drag-off-track-does-nothing", v4 === v5, { v4, v5 }); }
  const pm = await ev(() => { const b = document.querySelector('#cmd .box[data-id="pace"] .pm[data-d="1"]') || document.querySelector('#cmd .box[data-id="pace"] .pm'); const r = b.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, d: +b.getAttribute("data-d") }; });
  const v6 = await ev(() => PP.sim.s.box.pace);
  await L.touchTapXY(p, pm.x, pm.y); await L.sleep(120);
  const v7 = await ev(() => PP.sim.s.box.pace);
  ok("slider:plus-minus-always-works", v7 !== v6 || (pm.d > 0 && v6 === 4) || (pm.d < 0 && v6 === 0), { v6, v7, d: pm.d });
  // 10) 320x568: info card + ROTATE fit
  await p.setViewport({ width: 320, height: 568, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await L.sleep(300);
  await ev(() => { PP.edit(true); PP.select("table"); }); await L.sleep(200);
  r = await ev(() => { const q = (id) => document.getElementById(id).getBoundingClientRect(); const a = q("rotBtn"), b = q("putAway"), c = q("objInfo"), h = q("hud"), pl = q("play"); return { rot: { l: a.left, r: a.right, t: a.top, b: a.bottom, w: a.width }, info: { l: c.left, r: c.right, t: c.top, b: c.bottom }, hud: { l: h.left, r: h.right, b: h.bottom }, overPlay: c.left < pl.right - 0.5 && c.right > pl.left + 0.5 && c.top < pl.bottom && c.bottom > pl.top, vw: innerWidth }; });
  ok("gui320:rotate-on-screen", r.rot.w > 40 && r.rot.r <= r.vw + 0.5, r.rot);
  ok("gui320:info-in-hud", r.info.l >= r.hud.l - 0.5 && r.info.r <= r.hud.r + 0.5 && r.info.b <= r.hud.b + 0.5 && !r.overPlay, r);
  await shot("gui320-editor-info");
  ok("boot:no-page-errors", errs.length === 0, errs.slice(0, 5).join(" | "));
  await b.close();
  L.fs.writeFileSync(OUT + "/report.json", JSON.stringify(R, null, 1));
  const f = R.filter((x) => !x.pass).length;
  console.log(f ? "FAILURES " + f + "/" + R.length : "ALL GREEN " + R.length + "/" + R.length);
  process.exit(f ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
