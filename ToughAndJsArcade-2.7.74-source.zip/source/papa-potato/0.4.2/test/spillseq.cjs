const L=require("./lib.cjs");
(async()=>{const b=await L.browser();
 const {p,errs}=await L.open(b,[360,800],{dpr:2,url:"file:///workspace/game/build-potato3/out/papa-potato-0.3.html"});
 await p.evaluate(()=>{PP.pause(true);const s=PP.sim.s;s.box.eat=0;s.chute=0;});
 await p.evaluate(()=>{const s=PP.sim.s;s.chute=6;s.pile-=6;PP.sim.startSuck();s.suck.t0=s.t-1.0;PP.pause(false);});
 const clip={x:90,y:470,width:170,height:300};let i=0;
 for(;i<12;i++){await p.screenshot({path:`out/sp${String(i).padStart(2,"0")}.png`,clip});await L.sleep(110);}
 console.log(JSON.stringify(await p.evaluate(()=>PP.retView())),errs);await b.close();})();
