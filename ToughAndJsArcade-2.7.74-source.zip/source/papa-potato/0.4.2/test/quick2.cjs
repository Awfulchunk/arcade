const L=require("./lib.cjs");
(async()=>{const b=await L.browser();const sz=(process.argv[2]||"360x800").split("x").map(Number);
 const {p,errs}=await L.open(b,sz,{url:"file:///workspace/game/build-potato3/out/papa-potato-0.3.html"});
 await p.evaluate(process.argv[3]);await L.sleep(+(process.argv[4]||1500));
 await p.screenshot({path:process.argv[5]||"out/q.png"});console.log("errs",errs);await b.close();})();
