# Papa Potato 0.4.2 — PROGRESS (top section); 0.4.1 history below

Build dir: /workspace/game/build-potato042 (new copy of 0.4.1, the live arcade 2.7.70 slot `papa-potato`). build-potato041 and build-potato05-pack untouched; machine pack NOT wired.
Spec: requests/future/papa-potato-notes-t1116/NOTES.md + scroll-safe slider (swarm-panel-scroll-fix.md).

- [Nov 18 PT] Router: grid BFS fallback, exact stand spots (no 10-unit pad), table stand side picked free+reachable, connectivity check refuses moves that trap Papa or seal a key spot. Anti-loop cooldowns. Sack on floor when bag equipped. Sink dump. ROTATE + tap-for-info HUD. Door drawn under furniture. __tt hook. States list fits short screens.
- Tests: t-042 72/72, t-042-new 23/23, break.cjs 300x900s bad=0, tough-tools --all: 7 FAIL (all identical in shipped 0.4.1) -> fixed -> rerun visual+buff 0 FAIL.
- NOT shipped / signed / published. Staged at requests/finished-ship/papa-potato-0.4.2-test/.

---

# Papa Potato 0.4.1 / Arcade 2.7.62 (code 100) — PROGRESS

Build dir: /workspace/game/build-potato041 (NEW copy of 0.4). Do NOT touch /workspace/game/build-potato04 or build-potato05-pack.
Source: copied from build-potato04 (live 0.4 / Arcade 2.7.61). Save stays v4 (inventory migrates owned items as already placed). Locked 0.3.1 Papa look kept.

## Spec
- t1069: hide (don't delete) scroll arrows and panning; zoom out and fit the whole room to the screen; rails only if needed (EDIT) or remove empty rails and give the room the width; no overlay on the play area. Fix awkward black dot at the return chute. Cutting board fully on the table. Papa walks around furniture and stands beside the table to peel, never over it. Check all furniture.
- t1070/t1071: CLEAN walks to actual peel locations (nearest mess cluster first), broom on the peels, removes those peels. Test: sweep position within a few px of peels removed. Bed and all furniture are solid; he only gets in bed for NAP through its side. Hits: CLEAN at the peels, path around the bed.
- t1072: hide (don't delete) in-game name labels. Every object moves cleanly in the editor (shadows, glows, hits, spots, walk targets, collision). Editor test moves each object and checks followers. Before/after editor hit.
- t1073: board, knife, peel spawn, peel stand and the seat are children of their objects and move with them. Fit-to-screen default layout sensible (not a big empty room with stuff crammed at the edges). Editor test covers moving the table; hit of moved table with the board on it.
- t1074: INVENTORY. Bought items go to inventory first, not auto-placed. Equip/unequip tools (better peeler, carry bag, broom) on Papa; furniture/machines/decor get placed. EDIT opens a tray of owned unplaced placeables (drag into the room, send placed items back). COMP-style UI like the shop, no overlay on the play area. Save v4, migrate existing owned as already placed. HELP updated. Tests: buy, inventory, equip, place via editor, return, save/load. Hits of inventory and editor tray.

4 hard tests + buff + perf + visual overlap/bounds (tough-tools). Signed APK 2.7.62 / code 100, same signer, keep slots latest/v03/v02/v01. WebView 83 emu ALONE, LAST. Stage in finished-ship/papa-potato-0.4.1-arcade-2.7.62/. Do NOT publish.

## Log
- [17:29 PT] Copied potato04 → build-potato041 (excluded packages/build, huge index, keys, previews, apk extracts). potato04 and potato05-pack not edited.

- [17:29–17:48 PT] Built 0.4.1 in place. Inventory, fit-to-screen, hidden rails/labels, board-as-child, peel-cluster CLEAN, solid furniture (bed included), editor tray, HELP, save v4 migrate-owned-as-placed.
- Tests: `node test/t-041.cjs` **ALL GREEN 72/72**. Buff: 800 potatoes conserved 1.00h, 2764 shipped. Perf: avg ~0.42ms, p95 0.50ms, 0/90 over 16.67ms.
- Official hits in `out/preview-papa-041/` (no page errors).
- Signed APK 2.7.62 / versionCode 100 (same signer as 2.7.61). Assemble from the 2.7.61 bundle: only `papa-potato:latest` changed (0.4.1); v03/v02/v01 and 161 other slots byte-identical. Extracted APK slots cmp clean.
- potato04 `game.js` still 2026-11-12 15:34:45 PT; potato05-pack not edited.
- WebView 83 emu is the last step (needle30 already booted, idle with 2.7.61). Not published.

- [18:19 PT] WebView 83 emu (needle30, Chrome/83, this APK alone and last): **29/29 pass**. Staged to finished-ship/papa-potato-0.4.1-arcade-2.7.62/. Not published.
