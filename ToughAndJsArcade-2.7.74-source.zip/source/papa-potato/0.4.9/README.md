# Papa Potato 0.4.9

Shipped as `papa-potato:latest` in Arcade 2.7.72. 0.4.2 is kept as `papa-potato:v042`.

Single-file game: papa-potato-0.4.9.html (SHA-256 56322dfa0677a32e6833a309c48da2ddd7481cb932ddebdd148ab799e579f6e9).
Parts: head.html, game.js, sim.js, sprites04.js; join with build.sh.
Saves write papaPotato.save.v11 and load v11 down to v1.
