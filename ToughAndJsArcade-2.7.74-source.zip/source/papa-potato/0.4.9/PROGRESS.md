# Papa Potato 0.4.9 — shipped in Arcade 2.7.72

SHA-256: 56322dfa0677a32e6833a309c48da2ddd7481cb932ddebdd148ab799e579f6e9  papa-potato-0.4.9.html
Saves write papaPotato.save.v11 and load v11 down to v1. A v10 save is retargeted so the kitchen pile locks at 9999.

Wash room, water canal, stacked basin heap, kitchen pile locked at 9999 (POTATOES IN PLAY slider hidden, not deleted). See README.md and the single-file game.
