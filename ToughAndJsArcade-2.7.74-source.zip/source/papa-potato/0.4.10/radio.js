/* ===== Papa Potato 0.4.10 — the little radio (WebAudio). Two built-in stations are synthesized live (no recorded audio).
   MY MUSIC plays the player's own files (picked with <input type=file>) through the same small-speaker chain:
   highpass + mid bump + soft saturation + lowpass + quiet vinyl crackle. Nothing is uploaded; songs live only for this session. ===== */
var PPRadio=(function(){
  "use strict";
  var ctx=null,R={},noiseBuf=null,crackBuf=null,crackSrc=null;
  var songs=[],cur=-1,el=null,elSrc=null,lastErr="",playing="none",schedT=null,nextT=0,step=0,bar=0,sched=0,suspendT=null,kicks=0;
  var want={on:false,st:0,vol:6,near:1,dist:0,papaWash:false,viewWash:false,placed:false};
  var ST=[
    {name:"POTATO FM",tag:"lo-fi beats",bpm:74,swing:0.16,
      chords:[[53,57,60,64],[52,55,59,62],[50,53,57,60],[48,52,55,59]],bass:[41,40,38,36],bell:[72,74,76,79,81,84]},
    {name:"SPUD JAZZ",tag:"slow jazz",bpm:96,swing:0.34,
      chords:[[53,57,60,64],[53,57,59,64],[52,55,59,62],[49,55,58,61]],bass:[38,43,36,45],bell:null}
  ];
  function rng(){return Math.random();}
  function mtof(n){return 440*Math.pow(2,(n-69)/12);}
  function satCurve(k){var n=1024,c=new Float32Array(n),i,x,t=Math.tanh(k);for(i=0;i<n;i++){x=i*2/(n-1)-1;c[i]=Math.tanh(k*x)/t;}return c;}
  function supported(){return !!(window.AudioContext||window.webkitAudioContext);}
  function ensure(){
    if(ctx)return true;
    var A=window.AudioContext||window.webkitAudioContext;if(!A){lastErr="no WebAudio";return false;}
    try{ctx=new A();}catch(e){ctx=null;lastErr="AudioContext failed";return false;}
    try{build();}catch(e2){lastErr="radio chain failed: "+e2.message;}
    return true;
  }
  function build(){
    var c=ctx,sr=c.sampleRate,i,n,d,j;
    R.music=c.createGain();R.music.gain.value=1.0;
    R.synth=c.createGain();R.synth.gain.value=0.9;
    R.pre=c.createGain();R.pre.gain.value=1.7;
    R.hp=c.createBiquadFilter();R.hp.type="highpass";R.hp.frequency.value=340;R.hp.Q.value=0.8;
    R.pk=c.createBiquadFilter();R.pk.type="peaking";R.pk.frequency.value=1500;R.pk.Q.value=1.1;R.pk.gain.value=6;
    R.sh=c.createWaveShaper();R.sh.curve=satCurve(2.4);
    R.lp=c.createBiquadFilter();R.lp.type="lowpass";R.lp.frequency.value=3200;R.lp.Q.value=1.1;
    R.post=c.createGain();R.post.gain.value=0.34;
    R.master=c.createGain();R.master.gain.value=0;
    R.an=c.createAnalyser();R.an.fftSize=256;
    R.music.connect(R.pre);R.synth.connect(R.pre);
    R.pre.connect(R.hp);R.hp.connect(R.pk);R.pk.connect(R.sh);R.sh.connect(R.lp);R.lp.connect(R.post);R.post.connect(R.master);
    R.master.connect(R.an);R.an.connect(c.destination);
    n=Math.floor(sr);noiseBuf=c.createBuffer(1,n,sr);d=noiseBuf.getChannelData(0);for(i=0;i<n;i++)d[i]=rng()*2-1;
    n=Math.floor(sr*3);crackBuf=c.createBuffer(1,n,sr);d=crackBuf.getChannelData(0);
    for(i=0;i<n;i++)d[i]=(rng()*2-1)*0.010;
    for(j=0;j<46;j++){var at=Math.floor(rng()*(n-200)),amp=0.10+rng()*0.45,len=Math.floor(sr*(0.0006+rng()*0.0018));for(i=0;i<len;i++)d[at+i]+=amp*(rng()*2-1)*(1-i/len);}
    R.crkBp=c.createBiquadFilter();R.crkBp.type="bandpass";R.crkBp.frequency.value=2300;R.crkBp.Q.value=0.6;
    R.crk=c.createGain();R.crk.gain.value=0.55;R.crkBp.connect(R.crk);R.crk.connect(R.post);
  }
  function startCrackle(){if(crackSrc||!ctx||!crackBuf)return;try{crackSrc=ctx.createBufferSource();crackSrc.buffer=crackBuf;crackSrc.loop=true;crackSrc.connect(R.crkBp);crackSrc.start();}catch(e){crackSrc=null;}}
  function stopCrackle(){if(!crackSrc)return;try{crackSrc.stop();crackSrc.disconnect();}catch(e){}crackSrc=null;}
  /* ---------- station instruments ---------- */
  function env(g,t,a,peak,dur,rel){g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(peak,t+a);g.gain.setTargetAtTime(0.0001,t+dur,rel);}
  function keys(t,notes,dur,lvl){
    var c=ctx,f=c.createBiquadFilter(),i;f.type="lowpass";f.frequency.setValueAtTime(1500,t);f.frequency.setTargetAtTime(700,t+0.05,dur*0.5);f.connect(R.synth);
    var wob=(rng()-0.5)*14;
    for(i=0;i<notes.length;i++){var o=c.createOscillator(),o2=c.createOscillator(),g=c.createGain();
      o.type="triangle";o.frequency.value=mtof(notes[i]);o.detune.value=wob;o2.type="sine";o2.frequency.value=mtof(notes[i]+12);o2.detune.value=wob+4;
      o.connect(g);o2.connect(g);g.connect(f);env(g,t,0.03,lvl/notes.length,dur,0.25);
      o.start(t);o2.start(t);o.stop(t+dur+1.2);o2.stop(t+dur+1.2);sched+=3;}
  }
  function bass(t,n,dur,lvl){var c=ctx,o=c.createOscillator(),g=c.createGain();o.type="sine";o.frequency.value=mtof(n);o.connect(g);g.connect(R.synth);env(g,t,0.015,lvl,dur,0.08);o.start(t);o.stop(t+dur+0.6);sched+=2;}
  function kickDrum(t,lvl){var c=ctx,o=c.createOscillator(),g=c.createGain();o.type="sine";o.frequency.setValueAtTime(115,t);o.frequency.exponentialRampToValueAtTime(42,t+0.13);
    o.connect(g);g.connect(R.synth);g.gain.setValueAtTime(lvl,t);g.gain.exponentialRampToValueAtTime(0.001,t+0.28);o.start(t);o.stop(t+0.3);sched+=2;}
  function noiseHit(t,type,freq,q,lvl,dec){var c=ctx,s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();s.buffer=noiseBuf;f.type=type;f.frequency.value=freq;f.Q.value=q;
    s.connect(f);f.connect(g);g.connect(R.synth);g.gain.setValueAtTime(lvl,t);g.gain.exponentialRampToValueAtTime(0.001,t+dec);s.start(t,rng()*0.5);s.stop(t+dec+0.02);sched+=3;}
  function bell(t,n,lvl){var c=ctx,o=c.createOscillator(),g=c.createGain();o.type="sine";o.frequency.value=mtof(n);o.connect(g);g.connect(R.synth);env(g,t,0.01,lvl,0.12,0.35);o.start(t);o.stop(t+1.6);sched+=2;}
  function playStep(st,t,sd){
    var S=ST[st],ci=bar%4,s=step%16,ch=S.chords[ci],bn=S.bass[ci],barLen=sd*16;
    if(st===0){
      if(s===0){keys(t,ch,barLen*0.92,0.20);kickDrum(t,0.55);bass(t,bn,sd*5,0.30);}
      if(s===10){kickDrum(t,0.42);bass(t,bn+(bar%2?7:0),sd*4,0.24);}
      if(s===4||s===12)noiseHit(t,"bandpass",1700,0.8,0.20,0.14);
      if(s%2===0)noiseHit(t,"highpass",7200,0.7,s%4===0?0.05:0.03,0.035);
      if(S.bell&&(s===2||s===6||s===9||s===14)&&rng()<0.32)bell(t,S.bell[Math.floor(rng()*S.bell.length)],0.06);
    }else{
      if(s===0||s===7)keys(t,ch,s===0?sd*3:sd*2,0.16);
      if(s%4===0){var walk=[bn,bn+(rng()<0.5?3:4),bn+7,S.bass[(ci+1)%4]+(rng()<0.5?-1:1)];bass(t,walk[s/4],sd*3.6,0.30);}
      if(s===0||s===8)kickDrum(t,0.22);
      if(s===4||s===12)noiseHit(t,"bandpass",2600,0.5,0.10,0.22);
      if(s===0||s===4||s===6||s===8||s===12||s===14)noiseHit(t,"bandpass",5200,2.0,s===6||s===14?0.035:0.06,0.25);
    }
  }
  function tick(){
    if(!ctx||playing!=="station")return;
    var S=ST[want.st===1?1:0],sd=60/S.bpm/4,now=ctx.currentTime;
    if(nextT<now-0.05)nextT=now+0.06;   /* we were suspended or starved: never burst-schedule the past */
    while(nextT<now+0.40){
      var s=step%16,t=nextT;if(s%4===2)t+=S.swing*sd*2;
      try{playStep(want.st===1?1:0,t,sd);}catch(e){lastErr="station: "+e.message;}
      nextT+=sd;step++;if(step%16===0)bar++;
    }
  }
  function startStation(){stopSong();if(playing==="station")return;playing="station";step=0;bar=0;nextT=ctx.currentTime+0.08;if(!schedT)schedT=setInterval(tick,110);tick();}
  function stopStation(){if(schedT){clearInterval(schedT);schedT=null;}if(playing==="station")playing="none";}
  /* ---------- my music ---------- */
  function okFile(f){var t=(f&&f.type)||"",nm=(f&&f.name)||"";if(/^(image|text)\//.test(t)||t==="application/pdf")return false;
    if(/^(audio|video)\//.test(t))return true;return /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|webm|3gp|amr|mp4|wma)$/i.test(nm)||!t;}
  function addFiles(list){var added=0,first=-1,i,f;if(!list)return {added:0,first:-1};
    for(i=0;i<list.length&&songs.length<60;i++){f=list[i];if(!okFile(f))continue;
      var url=null;try{url=URL.createObjectURL(f);}catch(e){url=null;}if(!url)continue;
      var nm=String(f.name||"song").replace(/\.[a-z0-9]{2,5}$/i,"");if(nm.length>40)nm=nm.slice(0,39)+"\u2026";
      songs.push({name:nm,url:url,bad:false});if(first<0)first=songs.length-1;added++;}
    return {added:added,first:first};}
  function clearSongs(){stopSong();for(var i=0;i<songs.length;i++){try{URL.revokeObjectURL(songs[i].url);}catch(e){}}songs=[];cur=-1;}
  function ensureEl(){if(el)return true;if(!ctx)return false;
    try{el=new Audio();el.preload="auto";
      el.addEventListener("ended",function(){if(playing==="song")next(true);});
      el.addEventListener("error",function(){if(cur>=0&&songs[cur])songs[cur].bad=true;lastErr="could not play that file";if(playing==="song")next(true);});
      elSrc=ctx.createMediaElementSource(el);elSrc.connect(R.music);}catch(e){lastErr="music player failed: "+e.message;el=null;return false;}
    return true;}
  function playSong(i){
    if(!songs.length||!ensureEl())return false;
    i=((i|0)%songs.length+songs.length)%songs.length;
    var tries=0;while(songs[i].bad&&tries<songs.length){i=(i+1)%songs.length;tries++;}
    if(songs[i].bad){lastErr="none of the picked files would play";return false;}
    stopStation();cur=i;playing="song";
    try{if(el.src!==songs[i].url){el.src=songs[i].url;}var p=el.play();if(p&&p.catch)p.catch(function(err){lastErr="play blocked: "+(err&&err.name||"error");});}
    catch(e){lastErr="play failed";songs[i].bad=true;return false;}
    return true;}
  function stopSong(){if(el){try{el.pause();}catch(e){}}if(playing==="song")playing="none";}
  function next(auto){if(!songs.length)return false;return playSong(cur+1);}
  function prev(){if(!songs.length)return false;if(el&&el.currentTime>3&&cur>=0){try{el.currentTime=0;}catch(e){}return true;}return playSong(cur-1);}
  /* ---------- the knob logic (called by the game a few times a second) ---------- */
  function hasGoodSong(){for(var i=0;i<songs.length;i++)if(!songs[i].bad)return true;return false;}
  function apply(){
    if(!ctx)return;
    var on=want.on&&want.placed,t=ctx.currentTime;
    if(on){
      if(suspendT){clearTimeout(suspendT);suspendT=null;}
      if(ctx.state==="suspended"&&!document.hidden){try{var pr=ctx.resume();if(pr&&pr.catch)pr.catch(function(){});}catch(e){}}
      startCrackle();
      if(want.st===2&&hasGoodSong()){if(playing!=="song")playSong(cur<0?0:cur);else if(el&&el.paused&&!document.hidden){try{var p2=el.play();if(p2&&p2.catch)p2.catch(function(){});}catch(e){}}}
      else startStation();
    }else{
      stopStation();stopSong();
      if(!suspendT&&ctx.state==="running")suspendT=setTimeout(function(){suspendT=null;if(!(want.on&&want.placed)){stopCrackle();try{ctx.suspend();}catch(e){}}},500);
    }
    var v=want.vol/10,base=v*v*0.95,nearF=1;
    if(want.near)nearF=want.papaWash?0.55:(0.55+0.45*Math.max(0,1-want.dist/70));
    var viewF=want.viewWash?0.42:1,target=on?base*nearF*viewF:0;
    try{R.master.gain.setTargetAtTime(target,t,0.12);R.lp.frequency.setTargetAtTime(want.viewWash?1300:3200,t,0.2);}catch(e){}
  }
  function update(w){var k;for(k in w)if(k in want)want[k]=w[k];apply();}
  /* any tap: the browser lets sound start only after a tap, so every tap nudges the radio awake if it should be playing */
  function kick(){if(!(want.on&&want.placed))return false;kicks++;if(!ensure())return false;apply();return true;}
  function wake(){if(!ensure())return false;apply();return true;}
  function onHidden(h){if(!ctx)return;if(h){stopStation();if(el){try{el.pause();}catch(e){}}try{ctx.suspend();}catch(e){}}else apply();}
  function level(){if(!ctx||!R.an)return 0;var a=new Uint8Array(R.an.fftSize);R.an.getByteTimeDomainData(a);var s=0,i,x;for(i=0;i<a.length;i++){x=(a[i]-128)/128;s+=x*x;}return Math.sqrt(s/a.length);}
  function bands(){if(!ctx||!R.an)return null;var a=new Uint8Array(R.an.frequencyBinCount),hz=ctx.sampleRate/R.an.fftSize,i,f,o={low:0,mid:0,high:0},n={low:0,mid:0,high:0},k;R.an.getByteFrequencyData(a);
    for(i=1;i<a.length;i++){f=i*hz;k=f<200?"low":(f>=500&&f<=2500?"mid":(f>=6000?"high":null));if(k){o[k]+=a[i];n[k]++;}}
    for(k in o)o[k]=n[k]?Math.round(o[k]/n[k]*10)/10:0;return o;}   /* test/debug only: average analyser level per band */
  function state(){return {supported:supported(),ctx:ctx?ctx.state:"none",playing:playing,station:ST[want.st===1?1:0].name,st:want.st,songs:songs.map(function(s){return {name:s.name,bad:s.bad};}),cur:cur,
    songName:cur>=0&&songs[cur]?songs[cur].name:"",paused:el?el.paused:true,time:el?el.currentTime:0,lastErr:lastErr,sched:sched,gain:R.master?R.master.gain.value:0,lp:R.lp?R.lp.frequency.value:0,want:JSON.parse(JSON.stringify(want)),kicks:kicks,crackle:!!crackSrc};}
  return {ST:ST,bands:bands,supported:supported,ensure:ensure,wake:wake,kick:kick,update:update,addFiles:addFiles,clearSongs:clearSongs,playSong:playSong,next:next,prev:prev,
    songs:function(){return songs;},state:state,level:level,onHidden:onHidden,hasGoodSong:hasGoodSong};
})();
