# Papa Potato 0.4.10 — TEST build (not shipped)

**Not signed. Not in an APK. Not published.** Waiting for Jay to say ship.
Base: Papa 0.4.9 (build-potato049). Built in /workspace/game/build-potato0410/. The arcade repo, PR 2 and shipping were not touched.

Jay t1196: more decor that adds something to the game — a radio, a music player for your own songs that sounds small like a radio, carpets, other things. t1202: run tough-tools fully and wire the new hooks into window.__tt.

## SHA-256
`ab6995d51417cac3e29200a82fd7deec9d5edc6dae2965abaea7e40d8ee49bb6`  papa-potato-0.4.10.html

Saves write `papaPotato.save.v12`. A v11 (0.4.9) save loads and gets the new decor fields (radio station 0, volume 6, louder-near ON, duck out). Older saves (v1 to v11) still load.

## Decor (every item has a real effect; old prices are unchanged)
| item | lv | price | effect |
|---|---|---|---|
| KITCHEN MAT (carpet) | 1 | 12c | energy drains 30% slower while he stands on it |
| WALL CLOCK (wall) | 1 | 10c | meal breaks 30% shorter; shows the shift time |
| RUNNER RUG (carpet) | 2 | 20c | walks 15% faster on it |
| PAPA POSTER (wall) | 2 | 16c | AUTO-LAZY works at 70% speed, not 50% |
| PANTRY SHELF | 2 | 24c | +2 food storage |
| FLOOR FAN | 3 | 26c | peel mess slows him at most 15% instead of 30% |
| RUBBER DUCK (wash basin, from INV, needs key) | 3 | 12c | current pulls potatoes off the heap 25% faster |
| ROUND BRAID RUG (carpet) | 4 | 30c | grab, peel and drop 8% faster on it |
| PLANT (old, 15c Lv2) | | | watered: energy drains 10% slower in the kitchen |
| LAMP (old, 14c Lv2) | | | ON: peeling 8% faster |
| RADIO (old, 22c Lv3) | | | music ON: energy drains 20% slower (10% from the wash room), works 5% faster |
| RUG (old, 18c Lv3) | | | hunger drains 20% slower while he stands on it |
| TV + ARMCHAIR (old, 90c Lv4) | | | unchanged |

Carpets are walk-on, slide under furniture, never sit on another carpet. Wall items snap to the north, east or west wall and stay off the door, scanner and return chute (no rotate). Fan and shelf are furniture (block walking; the room must stay connected). The wash room top half has no default props; the duck floats in the basin (bottom half).

## Radio + MY MUSIC
- RADIO button appears in the top bar once the radio is bought. Tapping it (or the radio in the room) opens POWER / STATION / MY MUSIC / SOUND / NOW.
- Stations are made live by WebAudio (no recorded or copyrighted audio): POTATO FM (lo-fi, 74 bpm) and SPUD JAZZ (96 bpm).
- MY MUSIC: ADD SONGS opens `<input type=file accept=audio/* multiple>`. Songs play from blob URLs, are added to a playlist (play / pause / next / prev / clear), skip files that won't play, and last only until the game closes. Nothing leaves the phone.
- Small-radio sound: highpass 340 Hz, mid bump 1.5 kHz, soft tanh saturation, lowpass 3.2 kHz, quiet vinyl crackle, low overall level. Volume 0–10. LOUDER NEAR PAPA (default on): louder near the radio, quieter across the room; muffled (lowpass 1.3 kHz, quieter) while viewing the wash room.
- Audio starts only after a tap (AudioContext resume on tap), suspends when OFF or the app goes to the background, resumes after.
- The sim bonus counts the radio as playing whenever it is placed and ON (deterministic), even if the phone is muted.

## Tests (one pass on this exact HTML)
- t-0410 own checks (all t-049 locked checks updated + decor + radio + A03s x6): **167/167, 0 page errors.** Perf 360x800@2, 6x CPU: kitchen with all decor + station playing 59.9 fps p95 16.8 ms; wash room with duck + radio 59.6 fps p95 16.8 ms; kitchen with own song playing 60 fps p95 16.8 ms (song time advanced 0.3 s → 8.3 s). test-evidence/t-0410.json, t-0410.log.
- tt `test --all --name=papa0410 --seed=1`: **PASS 60, fail 0, warn 4, skip 7, info 6.** 31 hook commands (9 new decor/radio) x min/mid/max + 250 fuzz + hostile args all held. Soak 12 s @6x 59.3 fps p95 16.7 ms. Finished Thu Nov 19, 2026, ~12:41 AM PT. test-evidence/tt/. Same 4 warns as 0.4.9 (none new).
- Audio tests are headless Chrome audio with real CDP touch taps and real file uploads (generated WAV + noise + broken file + a .txt). **Not a phone test.**

## Fixed during the build
- radio.js had two functions named `kick` (the drum and the tap-wake). The drum calls hit the wake function, so no kick drum played. Renamed the drum to kickDrum.

## Gaps
- File-pick audio on a real phone is untested. The APK chooser uses MODE_OPEN_MULTIPLE, but Android may hand back only one file per pick in the WebView; the playlist appends, so picking again works.
- Songs are session-only (blob URLs die on reload). The radio settings are saved.
- PP.giveAll (dev cheat) stacks default spots and leaves the room disconnected; tests use real placement. Not a player path.
- Kitchen mat art reads as a dark block at small size (minor art note).
