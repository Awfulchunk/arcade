# Papa Potato 0.4.10

Shipped as `papa-potato:latest` in Arcade 2.7.73. 0.4.9 is kept as `papa-potato:v049`.

Single-file game: papa-potato-0.4.10.html (SHA-256 ab6995d51417cac3e29200a82fd7deec9d5edc6dae2965abaea7e40d8ee49bb6).
Parts: head.html, sim.js, sprites04.js, radio.js, game.js; build.sh joins them (it expects them under src/).
Saves write papaPotato.save.v12 and load v12 down to v1. Radio stations are generated live with WebAudio (no recorded audio).
