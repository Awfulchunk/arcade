/* ===== Papa Potato 0.4.10 — renderer (0.4.10: decor that does something — radio with stations + your own music, 4 carpets, wall clock, poster, fan, pantry shelf, rubber duck). Was 0.4.9. Save v12, loads v1-v11. ===== */
(function(){
"use strict";
var SAVE_KEY="papaPotato.save.v12",KEY_V11="papaPotato.save.v11",KEY_V10="papaPotato.save.v10",KEY_V9="papaPotato.save.v9",KEY_V8="papaPotato.save.v8",KEY_V7="papaPotato.save.v7",KEY_V6="papaPotato.save.v6",KEY_V5="papaPotato.save.v5",KEY_V4="papaPotato.save.v4",KEY_V3="papaPotato.save.v3",KEY_V2="papaPotato.save.v2",KEY_V1="papaPotato.save.v1";   /* older keys are only ever READ */
var C=PPSim.C,BOX=PPSim.BOX,SPOT=PPSim.SPOT,PACE=PPSim.PACE,GEO=PPSim.GEO,RW=PPSim.RW,RH=PPSim.RH,CMDS=PPSim.COMMANDS,UPS=PPSim.UPS,STYLE=PPSim.STYLE,SPD=PPSim.SPD,POTS=PPSim.POTS;
var sim=null;
var migrated=false;
var WW=PPSim.WW,WH=PPSim.WH,WASH=PPSim.WASH;
/* 0.4.9 save first; else carry over a 0.4.8 / 0.4.7 / 0.4.6 / 0.4.5 / 0.4.4 / 0.4.3 / 0.4.2 / 0.3 / 0.2 / 0.1 save (those keys are never written). */
function loadGame(){var s=null;try{var raw=localStorage.getItem(SAVE_KEY);if(raw)s=PPSim.load(raw);}catch(e){}
  if(!s){try{var o11=localStorage.getItem(KEY_V11);if(o11){s=PPSim.load(o11);if(s)migrated="0.4.9";}}catch(e){}}
  if(!s){try{var o10=localStorage.getItem(KEY_V10);if(o10){s=PPSim.load(o10);if(s)migrated="0.4.8";}}catch(e){}}
  if(!s){try{var o9=localStorage.getItem(KEY_V9);if(o9){s=PPSim.load(o9);if(s)migrated="0.4.7";}}catch(e){}}
  if(!s){try{var o8=localStorage.getItem(KEY_V8);if(o8){s=PPSim.load(o8);if(s)migrated="0.4.6";}}catch(e){}}
  if(!s){try{var o7=localStorage.getItem(KEY_V7);if(o7){s=PPSim.load(o7);if(s)migrated="0.4.5";}}catch(e){}}
  if(!s){try{var o6=localStorage.getItem(KEY_V6);if(o6){s=PPSim.load(o6);if(s)migrated="0.4.4";}}catch(e){}}
  if(!s){try{var o5=localStorage.getItem(KEY_V5);if(o5){s=PPSim.load(o5);if(s)migrated="0.4.3";}}catch(e){}}
  if(!s){try{var o4=localStorage.getItem(KEY_V4);if(o4){s=PPSim.load(o4);if(s)migrated="0.4.2";}}catch(e){}}
  if(!s){try{var o3=localStorage.getItem(KEY_V3);if(o3){s=PPSim.load(o3);if(s)migrated="0.3";}}catch(e){}}
  if(!s){try{var o2=localStorage.getItem(KEY_V2);if(o2){s=PPSim.load(o2);if(s)migrated="0.2";}}catch(e){}}
  if(!s){try{var o1=localStorage.getItem(KEY_V1);if(o1){s=PPSim.load(o1);if(s)migrated="0.1";}}catch(e){}}
  return s||PPSim.fresh();}
var lastSave=0;
function saveGame(){if(!sim)return false;try{localStorage.setItem(SAVE_KEY,sim.serialize());lastSave=performance.now();return true;}catch(e){return false;}}
sim=loadGame();

/* ---------- art: Swarm-style DPR. Fit by default; +/- zoom and arrow pan live in side rails outside the room (Jay t1065). ---------- */
var DETAIL=1.10;      /* ~10% finer pixel grid (t1014) */
var cv=document.getElementById("cv"),ctx=cv.getContext("2d",{alpha:false});
ctx.imageSmoothingEnabled=false;
var W=0,H=0,SC=1,DPR=1,k=1,camX=0,camY=0,offX=0,offY=0,roomW=RW,roomH=RH,WALL=GEO.WALL;
var ZOOM_STEPS=[0.75,1,1.25,1.5,2,2.5,3],zoomI=1,panX=0,panY=0,editMode=false,dragId=null;
var OUT="#1a1410",ANIM_F=0,ANIM_T=0;
var staticLayer=null,gx=0,gy=0,table=null,chute=null,playRect=null;
var fadeT=0,fadeTo=null,fading=false,kitLayer=null,washLayer=null,roomsPreloaded=false;
var pops=[];
var pileLayer=null,pileKey=-1,messLayer=null,messKey="",POS=[],ORDER=[],MESSPOS=[],SPR=null,SPRS=null,PEELSPR=null,TIER=[],renders={pile:0,mess:0};
var MAXVIS=400,PILEMAX=POTS[POTS.length-1],LIFT=1.1,MESSVIS=140;
function R(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y,Math.max(0.5,w),Math.max(0.5,h));}
function wx(x){return Math.round((x-camX)*k);}
function wy(y){return Math.round((y-camY)*k);}
function ws(s){return Math.max(0.6,s*k);}
function wr(x,y,w,h,c){var x0=wx(x),y0=wy(y),x1=wx(x+w),y1=wy(y+h);R(x0,y0,Math.max(0.6,x1-x0),Math.max(0.6,y1-y0),c);}
function oval(cx,cy,rw,rh,c){rw=Math.max(0.35,rw);rh=Math.max(0.35,rh);ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(cx,cy,rw,rh,0,0,6.283185);ctx.fill();}
function disc(cx,cy,rw,rh,c,out){if(out!==null)oval(cx,cy,rw+0.7,rh+0.7,out||OUT);oval(cx,cy,rw,rh,c);}
function blob(x,y,w,h,r,c,out){r=Math.max(0.4,r||1);ctx.fillStyle=out||OUT;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x-0.7,y-0.7,w+1.4,h+1.4,r+0.7);else ctx.rect(x-0.7,y-0.7,w+1.4,h+1.4);ctx.fill();ctx.fillStyle=c;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x,y,w,h,r);else ctx.rect(x,y,w,h);ctx.fill();}
function softShadow(cx,cy,rx,ry){rx=rx||10;ry=ry||7;var g=ctx.createRadialGradient(cx,cy,0,cx,cy,Math.max(rx,ry));g.addColorStop(0,"rgba(0,0,0,0.28)");g.addColorStop(1,"rgba(0,0,0,0)");ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(cx,cy,rx,ry,0,0,6.283185);ctx.fill();}
function tickAnim(now){ANIM_T=now/1000;ANIM_F=((now/125)|0)%4;}
function resetXform(){ctx.setTransform(DPR,0,0,DPR,0,0);ctx.imageSmoothingEnabled=false;}
function blitLayer(layer){if(!layer)return;ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(layer,0,0);resetXform();}
function srng(n){var s=(n*1664525+1013904223)>>>0;return (s%10000)/10000;}
/* 0.4.2 rotate: draw something turned r quarter turns about its centre (world coords) */
function rotWrap(cx,cy,r,fn){r=(r|0)&3;if(!r){fn();return;}var px=wx(cx),py=wy(cy);ctx.save();ctx.translate(px,py);ctx.rotate(r*Math.PI/2);ctx.translate(-px,-py);try{fn();}finally{ctx.restore();}}
/* rect furniture keeps its turned footprint in GEO; draw it from the unturned rect, turned by the canvas */
function drawRectR(G,fn){var r=(G.r|0)&3;if(!r){fn();return;}var cx=(G.x0+G.x1)/2,cy=(G.y0+G.y1)/2,hx=(G.x1-G.x0)/2,hy=(G.y1-G.y0)/2,s=[G.x0,G.y0,G.x1,G.y1];
  if(r&1){var q=hx;hx=hy;hy=q;}G.x0=cx-hx;G.x1=cx+hx;G.y0=cy-hy;G.y1=cy+hy;G.r=0;
  try{rotWrap(cx,cy,r,fn);}finally{G.x0=s[0];G.y0=s[1];G.x1=s[2];G.y1=s[3];G.r=r;}}
function drawBedR(fn){var m=GEO.mat,r=(m.r|0)&3;if(!r){fn();return;}var w=m.w,h=m.h;if(r&1){m.w=h;m.h=w;}m.r=0;try{rotWrap(m.x,m.y,r,fn);}finally{m.w=w;m.h=h;m.r=r;}}
function itemR(id){var p=sim.placeOf(id);return (p&&p.r|0)&3;}
var TAGDEF=[
  {id:"tagShip",x:GEO.ship.x+20,y:15,al:"l"},
  {id:"tagRet",x:GEO.ret.mouthX+3,y:GEO.ret.y-13,al:"c"},
  {id:"tagTable",x:(GEO.table.x0+GEO.table.x1)/2,y:GEO.table.y0-6,al:"c"},
  {id:"tagBed",x:GEO.mat.x,y:GEO.mat.y-GEO.mat.h/2-3,al:"c"},
  {id:"tagFood",x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:GEO.cooler.y0+2.5,al:"c"},
  {id:"tagSeat",x:GEO.stool.x,y:GEO.stool.y+9,al:"c"},
  {id:"tagPot",x:GEO.pile.cx,y:GEO.pile.base+3,al:"c"},
  {id:"tagPeeler",x:GEO.peeler.x,y:GEO.peeler.y-13,al:"c"},
  {id:"tagLine",x:GEO.outBeltX0+10,y:GEO.outBeltY-8,al:"c"},
  {id:"tagSink",x:GEO.sink.x,y:GEO.sink.y-10,al:"c"},
  {id:"tagTV",x:GEO.tv.x,y:GEO.tv.y-12,al:"c"}];
function viewIsWash(){return !!(sim&&sim.s&&sim.s.viewRoom==="wash");}
function syncRoomSize(){roomW=viewIsWash()?WW:RW;roomH=viewIsWash()?WH:RH;}
function fitK(){return Math.min(W/roomW,H/roomH)*0.98;}
function clampPan(){
  var maxX=Math.max(0,(roomW*k-W)/(2*k)+10), maxY=Math.max(0,(roomH*k-H)/(2*k)+10);
  panX=Math.max(-maxX,Math.min(maxX,panX));
  panY=Math.max(-maxY,Math.min(maxY,panY));
}
function applyCam(){
  /* 0.4.1: pan and zoom stay in the code but are hidden and locked. The whole room always fits the screen. */
  zoomI=1;panX=0;panY=0;
  syncRoomSize();
  k=fitK();
  offX=(W-roomW*k)/2;offY=(H-roomH*k)/2;
  camX=-offX/k;camY=-offY/k;
}
function syncZoomLabel(){
  var el=document.getElementById("zoomLabel");
  if(el)el.textContent="FIT";
}
function zoomBy(d){
  /* hidden: zoom is locked to a fitted view (t1069) */
  zoomI=1;applyCam();staticLayer=null;pileLayer=null;messLayer=null;if(playRect)placeTags();syncZoomLabel();
}
function panBy(dx,dy){/* hidden: panning is off (t1069) */resetView();}
function resetView(){zoomI=1;panX=0;panY=0;applyCam();staticLayer=null;pileLayer=null;messLayer=null;if(playRect)placeTags();syncZoomLabel();}
function fitStates(){var b=document.querySelector(".states");if(!b)return;b.classList.remove("tight");if(b.scrollHeight>b.clientHeight+1)b.classList.add("tight");}

function bustRoomCache(){staticLayer=null;kitLayer=null;washLayer=null;roomsPreloaded=false;}
function beginFade(to){
  if(to!=="kitchen"&&to!=="wash")return false;
  if(to==="wash"&&!sim.hasKey())return false;
  if(viewIsWash()?(to==="wash"):(to==="kitchen"))return false;
  fadeTo=to;fadeT=0.001;fading=true;return true;
}
function tickFade(dt){
  if(!fading)return;
  fadeT+=dt/0.14;
  if(fadeT>=1&&fadeTo){sim.s.viewRoom=fadeTo;sim.s.followRoom=null;fadeTo=null;staticLayer=null;pileLayer=null;messLayer=null;layout();}
  if(fadeT>=2){fading=false;fadeT=0;}
}
function copyLayer(){var c=document.createElement("canvas");c.width=cv.width;c.height=cv.height;var g=c.getContext("2d");g.imageSmoothingEnabled=false;g.drawImage(cv,0,0);return c;}
function preloadRooms(){
  if(!sim||W<2||H<2)return;
  var cur=sim.s.viewRoom||"kitchen";
  sim.s.viewRoom="kitchen";syncRoomSize();applyCam();drawStatic();kitLayer=copyLayer();
  sim.s.viewRoom="wash";syncRoomSize();applyCam();drawStatic();washLayer=copyLayer();
  sim.s.viewRoom=cur;syncRoomSize();applyCam();staticLayer=(cur==="wash"?washLayer:kitLayer);roomsPreloaded=true;
}

function layout(){
  var r=document.getElementById("play").getBoundingClientRect();playRect=r;
  var cssW=Math.max(1,r.width),cssH=Math.max(1,r.height);
  DPR=Math.min(2,window.devicePixelRatio||1);SC=1;
  W=cssW;H=cssH;
  cv.style.width=W+"px";cv.style.height=H+"px";
  cv.width=Math.max(1,Math.round(W*DPR));cv.height=Math.max(1,Math.round(H*DPR));
  resetXform();
  applyCam();
  gx=GEO.table.x0+(GEO.table.x1-GEO.table.x0)/2;gy=GEO.table.y0+(GEO.table.y1-GEO.table.y0)/2;
  table={x:gx,y:gy,w:GEO.table.x1-GEO.table.x0,h:GEO.table.y1-GEO.table.y0};
  chute={cx:GEO.ship.x,mouthW:GEO.ship.mouth*2,lip:GEO.ship.lip};
  staticLayer=null;pileLayer=null;messLayer=null;buildPile();buildMess();buildSprites();placeTags();fitStates();
  if(!roomsPreloaded)preloadRooms();
}
function clampTag(el,play,pad){
  var r=el.getBoundingClientRect();var left=parseFloat(el.style.left)||0,top=parseFloat(el.style.top)||0;
  var centered=el.style.transform&&el.style.transform.indexOf("translateX(-50%)")>=0;
  if(centered){var half=r.width/2;left=Math.max(pad+half,Math.min(play.width-pad-half,left));}
  else{left=Math.max(pad,Math.min(play.width-pad-r.width,left));}
  top=Math.max(pad,Math.min(play.height-pad-(r.height||12),top));
  el.style.left=Math.round(left)+"px";el.style.top=Math.round(top)+"px";
}
function placeTags(){var play=playRect;
  for(var i=0;i<TAGDEF.length;i++){var d=TAGDEF[i],el=document.getElementById(d.id);if(!el)continue;
    var px=(wx(d.x)/W)*play.width,py=(wy(d.y)/H)*play.height;
    el.style.transform=d.al==="c"?"translateX(-50%)":"none";el.style.left=Math.round(px)+"px";
    var hh=el.getBoundingClientRect().height||12;var top=Math.round(Math.max(3,Math.min(play.height-hh-3,py-hh/2)));el.style.top=top+"px";clampTag(el,play,4);}}
var labelsUntil=0;
function showLabels(ms,force){labelsUntil=force?performance.now()+ms:Math.max(labelsUntil,performance.now()+ms);}
var labelsOn=null;
function updateLabels(){var on=performance.now()<labelsUntil&&!ovlMode&&!viewIsWash();if(on===labelsOn)return;labelsOn=on;
  for(var i=0;i<TAGDEF.length;i++){var el=document.getElementById(TAGDEF[i].id);if(el)el.className="tag"+(on?"":" off");}}
function potato(x,y,s,peeled,flip,spots,pal){
  var body=pal||(peeled?["#a88830","#c8a848","#e8c868","#f0d890"]:["#4a2810","#6a4020","#8a5a28","#c48a48"]);
  var out=body[0],dk=body[1],md=body[2],hi=body[3];
  var hw=Math.max(1.2,s),hh=Math.max(0.9,s*0.72),fx=flip?1:-1;
  oval(x+0.7,y+0.7,hw+0.3,hh+0.2,"rgba(0,0,0,0.22)");
  disc(x,y,hw,hh,md,out);
  oval(x+fx*hw*0.16,y-hh*0.18,hw*0.62,hh*0.5,hi);
  oval(x+fx*hw*0.28,y-hh*0.32,hw*0.28,hh*0.22,peeled?"#fff3a0":hi);
  if(!peeled){oval(x+fx*hw*0.12,y+hh*0.05,Math.max(0.5,hw*0.12),Math.max(0.5,hh*0.12),dk);
    oval(x-fx*hw*0.28,y+hh*0.18,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),out);
    if(s>3)oval(x+fx*hw*0.35,y-hh*0.08,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),"#6a4020");}
  else if(spots){var sp=[[-0.45,-0.25],[0.5,0.22],[0,0.45],[-0.28,0.28],[0.3,-0.3]];
    for(var i=0;i<Math.min(spots,sp.length);i++)oval(x+sp[i][0]*hw,y+sp[i][1]*hh,Math.max(0.4,hw*0.1),Math.max(0.4,hh*0.1),"#6a4020");}
}
/* ---------- room pieces ---------- */
function drawFloor(){R(0,0,W,H,"#2a2820");var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);var fw=Math.max(1,ix2-ix),fh=Math.max(1,iy2-iy);
  R(ix,iy,fw,fh,"#9a947c");var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,"#8e876e");}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?"#7a7460":"#a8a288");}
  ctx.strokeStyle="rgba(60,55,40,0.28)";ctx.lineWidth=1;ctx.beginPath();
  for(var x2=ix;x2<=ix+fw;x2+=step){ctx.moveTo(x2+0.5,iy);ctx.lineTo(x2+0.5,iy+fh);}for(var y2=iy;y2<=iy+fh;y2+=step){ctx.moveTo(ix,y2+0.5);ctx.lineTo(ix+fw,y2+0.5);}ctx.stroke();
  /* 0.3: the dashed centre stripe had no use and is hidden (drawCentreStripe, not called) */
  if(!viewIsWash()){var lcx=wx(gx),lcy=wy(gy);for(var j=0;j<7;j++){ctx.fillStyle="rgba(255,240,180,"+(0.07-j*0.009)+")";ctx.beginPath();ctx.ellipse(lcx,lcy,ws(22+j*6),ws(15+j*4.5),0,0,6.28);ctx.fill();}}}
function drawCentreStripe(){var cx=wx(roomW*0.5);for(var y3=wy(WALL+8);y3<wy(roomH*0.72);y3+=Math.max(5,ws(5)))R(cx-ws(3.5),y3,ws(7),1,"#8a846c");}

function drawWalls(){var x0=wx(0),y0=wy(0),x1=wx(roomW),y1=wy(roomH);var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);
  R(x0,y0,x1-x0,iy-y0,"#3a3830");R(x0,iy2,x1-x0,y1-iy2,"#3a3830");R(x0,iy,ix-x0,iy2-iy,"#3a3830");R(ix2,iy,x1-ix2,iy2-iy,"#3a3830");
  var t=Math.max(2,ws(2.4));R(x0,y0,x1-x0,t,"#1a1814");R(x0,y1-t,x1-x0,t,"#1a1814");R(x0,y0,t,y1-y0,"#1a1814");R(x1-t,y0,t,y1-y0,"#1a1814");
  var bs=Math.max(4,ws(5));for(var i=0;i<80;i++){var side=i%4,bx,by;
    if(side===0){bx=x0+t+((i*11)%Math.max(2,x1-x0-t*2));by=y0+t+((i*5)%Math.max(2,iy-y0-t));}
    else if(side===1){bx=x0+t+((i*13)%Math.max(2,x1-x0-t*2));by=iy2+((i*7)%Math.max(2,y1-iy2-t));}
    else if(side===2){bx=x0+t+((i*3)%Math.max(2,ix-x0-t));by=iy+((i*17)%Math.max(2,iy2-iy));}
    else{bx=ix2+((i*3)%Math.max(2,x1-ix2-t));by=iy+((i*19)%Math.max(2,iy2-iy));}
    R(bx,by,bs,Math.max(2,ws(2.2)),(i%3===0)?"#4a4638":"#323028");}
  R(ix,iy,ix2-ix,1,"#5a5648");R(ix,iy2-1,ix2-ix,1,"#2a2820");R(ix,iy,1,iy2-iy,"#5a5648");R(ix2-1,iy,1,iy2-iy,"#2a2820");
  R(ix+1,iy+1,ws(3),iy2-iy-2,"rgba(0,0,0,0.18)");R(ix+1,iy+1,ix2-ix-2,ws(2),"rgba(0,0,0,0.14)");}
function drawChuteBase(){var cx=wx(chute.cx),mouthW=ws(chute.mouthW),y0=wy(2),yLip=wy(chute.lip),wallInner=wy(WALL),y1=yLip;
  for(var y=y0;y<=y1;y++){var t=(y-y0)/Math.max(1,y1-y0);var half=Math.round((mouthW*0.28)+(mouthW*0.22)*t);
    R(cx-half-2,y,(half+2)*2,1,"#3a4038");R(cx-half,y,half*2,1,t<0.18?"#8a9088":"#5a6058");var ih=Math.max(2,half-3);
    if(y>y0+2&&y>wallInner-2)R(cx-ih,y,ih*2,1,"#12141a");else if(y>y0+2)R(cx-ih,y,ih*2,1,"#1a1c18");}
  var half0=Math.round(mouthW*0.28),half1=Math.round(mouthW*0.50);
  R(cx-half0-2,y0,(half0+2)*2,2,"#8a9088");R(cx-half0-1,y0,(half0+1)*2,1,"#c0c8c0");R(cx-half0,y0+1,2,2,"#c0c8c0");R(cx+half0,y0+1,2,2,"#c0c8c0");
  R(cx-(half1-2),y1-1,2,2,"#8a9088");R(cx+(half1-4),y1-1,2,2,"#8a9088");R(cx-half1,y1,half1*2,2,"#4a5048");R(cx-half1,y1,half1*2,1,"#7a8478");
  var ss=[-0.7,-0.35,0.35,0.7];for(var i=0;i<4;i++)R(cx+Math.round(half1*ss[i])-1,y1,2,2,"#9aa49a");
  }
/* ---- HIDDEN PROPS (never called; kept in code, not deleted) ---- */
function drawLamp(){var lx=wx(gx-roomW*0.18),ly=wy((chute.lip+(table.y-table.h/2))*0.5);var r=Math.max(4,ws(4.5));
  oval(lx,ly,r+1,r+1,"#2a2a24");oval(lx,ly,r,r,"#3a3a32");oval(lx,ly,r-2,r-2,"#c8c070");oval(lx,ly,Math.max(1,r-3),Math.max(1,r-3),"#fff3a0");
  R(lx-1,ly-r-Math.max(2,ws(2.2)),2,Math.max(2,ws(2.2)),"#2a2a24");R(lx-2,ly-r-Math.max(2,ws(2.2)),4,1,"#3a3a32");}
function drawDrain(cx,cy,rad){var x=wx(cx),y=wy(cy),r=Math.max(3,ws(rad));oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#5a6058");oval(x,y,r-1,r-1,"#1a1c18");oval(x,y,Math.max(1,r-2),Math.max(1,r-2),"#12141a");
  R(x-(r-2),y,(r-2)*2,1,"#5a6058");R(x,y-(r-2),1,(r-2)*2,"#5a6058");R(x-(r-2),y-Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");R(x-(r-2),y+Math.round((r-2)*0.7),(r-2)*2,1,"#3a4038");}
function drawBucket(cx,cy,rad,inner){var x=wx(cx),y=wy(cy),r=Math.max(4,ws(rad));oval(x+1,y+1,r,r,"rgba(0,0,0,0.28)");oval(x,y,r+1,r+1,"#3a4038");oval(x,y,r,r,"#6a7068");oval(x,y,r-1,r-1,"#4a5048");
  oval(x,y,Math.max(2,r-2),Math.max(2,r-2),inner||"#2a2c28");R(x-1,y-r,2,1,"#c0c8c0");R(x-(r-1),y-1,1,2,"#8a9088");R(x-Math.max(2,r-2),y-r-Math.max(1,ws(1.2)),Math.max(4,(r-2)*2),Math.max(1,ws(1.2)),"#3a2a20");}
function drawPeelBin(cx,cy,bw,bh){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#3a2a18");R(x+1,y+1,w-2,h-2,"#5a4030");R(x+2,y+2,w-4,h-4,"#2a1c10");R(x+1,y+1,w-2,1,"#8a6a40");
  for(var i=0;i<9;i++)R(x+3+srng(i*3)*(w-8),y+3+srng(i*7)*(h-8),Math.max(2,ws(2.2)),Math.max(1,ws(1.2)),i%2?"#e8c070":"#d4a04a");R(x+2,y+h-2,w-4,1,"#2a1c10");}
function drawTable(){var tw=table.w,th=table.h,x=wx(table.x-tw/2),y=wy(table.y-th/2),w=ws(tw),h=ws(th);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  oval(wx(gx)-ws(3),wy(gy)-ws(6),ws(4),ws(2.5),"rgba(80,50,20,0.25)");
  /* old peels on the table */
  var tx=wx(gx),ty=wy(gy);R(tx+ws(6),ty-ws(9),2,1,"#e8c070");R(tx-ws(9),ty-ws(8),2,2,"#d4a04a");R(tx-ws(6),ty-ws(11),2,1,"#f5e0a8");R(tx+ws(9),ty-ws(6),1,1,"#e8c070");}
function drawSack(cx,cy,bw,bh,rot,spill){var x=wx(cx),y=wy(cy),rw=Math.max(4,ws(bw/2)),rh=Math.max(3,ws(bh/2));
  oval(x+1,y+1,rw,rh,"rgba(0,0,0,0.25)");oval(x,y,rw+1,rh+1,"#4a4028");oval(x,y,rw,rh,"#8a7a50");oval(x-1,y-1,Math.max(2,rw-2),Math.max(2,rh-2),"#9a8a60");oval(x-2,y-2,Math.max(1,rw-4),Math.max(1,rh-4),"#a89868");
  R(x-Math.max(1,rw-3),y,Math.max(2,(rw-3)*2),1,"#6a5a38");R(x,y-Math.max(1,rh-3),1,Math.max(2,(rh-3)*2),"#6a5a38");
  if(rot==="n"){R(x-Math.max(2,ws(2)),y-rh-ws(1.5),Math.max(4,ws(4)),Math.max(2,ws(2.2)),"#6a5a38");R(x-1,y-rh-ws(2),2,Math.max(2,ws(1.5)),"#c4b480");}
  else if(rot==="w"){R(x-rw-ws(1.5),y-Math.max(2,ws(2)),Math.max(2,ws(2.2)),Math.max(4,ws(4)),"#6a5a38");R(x-rw-ws(2),y-1,Math.max(2,ws(1.5)),2,"#c4b480");}
  if(spill){potato(x+rw-1,y+rh-1,Math.max(2,ws(2.6)),false,true);potato(x+rw+ws(2),y+1,Math.max(2,ws(2.4)),false,false);}}
function drawCrate(cx,cy,bw,bh,open,lid){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#4a3018");R(x,y,w,1,"#8a6a40");R(x,y,1,h,"#6a4a28");R(x,y+h-1,w,1,"#3a200c");R(x+w-1,y,1,h,"#3a200c");
  R(x+1,y+1,w-2,h-2,"#6a4a28");var sl=Math.max(2,ws(2.4));for(var i=0;i<Math.max(2,Math.floor((h-2)/sl));i++)R(x+1,y+1+i*sl,w-2,1,i%2?"#8a6a40":"#5a3a20");
  var b=Math.max(2,ws(2));R(x,y,b,b,"#3a2a18");R(x+w-b,y,b,b,"#3a2a18");R(x,y+h-b,b,b,"#3a2a18");R(x+w-b,y+h-b,b,b,"#3a2a18");
  if(open){var inset=Math.max(2,ws(2));R(x+inset,y+inset,w-inset*2,h-inset*2,"#2a1c10");potato(x+Math.round(w*0.35),y+Math.round(h*0.45),Math.max(2,ws(2.8)),false,false);potato(x+Math.round(w*0.62),y+Math.round(h*0.4),Math.max(2,ws(2.5)),false,true);potato(x+Math.round(w*0.5),y+Math.round(h*0.65),Math.max(2,ws(2.6)),false,false);}
  else if(lid){R(x+1,y+1,w-2,h-2,"#7a5a30");R(x+2,y+Math.round(h*0.45),w-4,1,"#4a3018");R(x+Math.round(w*0.5)-1,y+2,2,h-4,"#5a3a20");}}
function drawShelf(){var x=WALL,y1=roomH*0.20,y2=roomH*0.62,depth=Math.max(5,WALL*0.7);
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x+depth-0.8,y1,0.8,y2-y1,"#3a200c");for(var i=1;i<=4;i++)wr(x,y1+(y2-y1)*i/5,depth,0.7,"#5a3a20");
  var spots=[0.24,0.30,0.36,0.44,0.50,0.56],kinds=["jar","tin","jar","bag","tin","jar"];
  for(var j=0;j<spots.length;j++){var ix=wx(x+depth*0.55),iy=wy(roomH*spots[j]);
    if(kinds[j]==="jar"){oval(ix,iy,ws(1.8),ws(1.8),"#6a3030");oval(ix,iy,ws(1.2),ws(1.2),"#8a4840");R(ix-1,iy-ws(1.8),2,1,"#c4b480");}
    else if(kinds[j]==="tin"){R(ix-ws(1.8),iy-ws(1.4),ws(3.6),ws(2.8),"#5a6058");R(ix-ws(1.8),iy-ws(1.4),ws(3.6),1,"#8a9088");}
    else oval(ix,iy,ws(2.0),ws(1.6),"#6a5a38");}}
function drawToolRack(){var depth=Math.max(4.5,WALL*0.65),x=roomW-WALL-depth,y1=WALL+2,y2=roomH*0.27;
  wr(x,y1,depth,y2-y1,"#4a3018");wr(x,y1,depth,0.8,"#8a6a40");wr(x,y1+0.8,0.7,y2-y1-1.6,"#5a3a20");
  for(var i=0;i<6;i++){var yy=y1+2+(y2-y1-4)*(i+0.5)/6,hx=wx(x),hy=wy(yy);R(hx-1,hy,2,2,"#8a9088");
    if(i%2===0){R(hx-ws(5.5),hy-1,ws(5.5),Math.max(2,ws(1.6)),"#3a2a20");R(hx-ws(10.5),hy-1,ws(5.2),Math.max(2,ws(1.4)),"#c8d0d8");R(hx-ws(10.5),hy-1,ws(5.2),1,"#e8eef4");}
    else{R(hx-ws(4.8),hy-1,ws(4.8),Math.max(2,ws(1.8)),"#4a3020");R(hx-ws(8.5),hy,ws(4.0),Math.max(1,ws(1.2)),"#c8d0d8");R(hx-ws(8.5),hy,1,Math.max(1,ws(1.2)),"#e8eef4");}}}
function drawPipes(){var x2=chute.cx-chute.mouthW*0.55;wr(WALL+1,WALL+1.4,x2-(WALL+1),2.6,"#4a5048");wr(WALL+1,WALL+1.4,x2-(WALL+1),0.8,"#7a8478");
  var fl=[WALL+4,(WALL+x2)*0.5,x2-3];for(var i=0;i<3;i++)wr(fl[i],WALL+0.7,1.6,4.0,"#6a7068");wr(WALL+1.0,WALL+1.0,3.2,3.2,"#5a6058");
  var px=wx(WALL+2.6),py=wy(WALL+8),r=Math.max(3,ws(3.2));oval(px,py,r+1,r+1,"#3a4038");oval(px,py,r,r,"#6a7068");oval(px,py,r-2,r-2,"#2a2e2a");oval(px,py,Math.max(1,r-3),Math.max(1,r-3),"#12141a");
  var vx=wx(WALL+7),vy=wy(WALL+2.6);oval(vx,vy,ws(2.2),ws(2.2),"#8a9088");R(vx-ws(1.6),vy,ws(3.2),1,"#c0c8c0");R(vx,vy-ws(1.6),1,ws(3.2),"#c0c8c0");
  wr(roomW-WALL-8,WALL+1.4,7,2.4,"#4a5048");wr(roomW-WALL-8,WALL+1.4,7,0.7,"#7a8478");wr(roomW-WALL-9,WALL+0.8,1.6,3.6,"#6a7068");}
function drawMachinePad(cx,cy,bw,bh,kind){var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#3a4038");R(x,y,w,1,"#8a9088");R(x,y,1,h,"#6a7068");R(x,y+h-1,w,1,"#2a2e2a");R(x+w-1,y,1,h,"#2a2e2a");R(x+2,y+2,w-4,h-4,"#4a5048");
  var inx=x+Math.max(3,ws(2.5)),iny=y+Math.max(3,ws(2.5)),inw=w-Math.max(6,ws(5)),inh=h-Math.max(6,ws(5));R(inx,iny,inw,inh,"#323830");
  for(var i=0;i<inw;i+=2){R(inx+i,iny,1,1,"#6a7068");R(inx+i,iny+inh-1,1,1,"#2a2e2a");}
  var b=Math.max(1,ws(1.3)),bolts=[[x+2,y+2],[x+w-3-b,y+2],[x+2,y+h-3-b],[x+w-3-b,y+h-3-b]];for(var j=0;j<4;j++){R(bolts[j][0],bolts[j][1],b+1,b+1,"#8a9088");R(bolts[j][0],bolts[j][1],b,b,"#c0c8c0");}
  if(kind==="drum"){oval(x+w/2,y+h/2,ws(3.2),ws(3.2),"#2a2e2a");oval(x+w/2,y+h/2,ws(1.6),ws(1.6),"#1a1c18");}
  else if(kind==="slot")R(x+Math.round(w*0.25),y+Math.round(h*0.45),Math.round(w*0.5),Math.max(2,ws(2)),"#2a2e2a");}
function drawMat(){var cx=roomW*SPOT.mat.x+2,cy=roomH*SPOT.mat.y,mw=19,mh=9;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.22)");R(x,y,w,h,"#5a2a2a");R(x+1,y+1,w-2,h-2,"#8a3a34");
  for(var i=2;i<w-2;i+=3)R(x+i,y+1,1,h-2,"#a04a40");R(x+1,y+Math.round(h/2),w-2,1,"#6a2a28");
  R(x,y,w,1,"#b06a50");for(var j=0;j<h;j+=2){R(x-1,y+j,1,1,"#c4a070");R(x+w,y+j,1,1,"#c4a070");}
  /* pillow at the west end */
  R(x+2,y+2,Math.max(3,ws(4)),h-4,"#d8d0b8");R(x+2,y+2,Math.max(3,ws(4)),1,"#f0ead8");}
function drawCooler(){var cx=roomW*SPOT.food.x,cy=roomH*SPOT.food.y-8.5,bw=11,bh=8;var x=wx(cx-bw/2),y=wy(cy-bh/2),w=ws(bw),h=ws(bh);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#2a4a6a");R(x+1,y+1,w-2,h-2,"#3a6a9a");R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+Math.round(h*0.55),w-2,1,"#24405a");
  R(x+Math.round(w*0.3),y+Math.round(h*0.25),Math.round(w*0.4),Math.max(1,ws(1.4)),"#e8eef4");
  /* stool in front */
  oval(wx(cx+5.5),wy(cy+7),ws(2.2),ws(2.2),"#5a3a20");oval(wx(cx+5.5),wy(cy+7),ws(1.6),ws(1.6),"#8a6a40");}

/* ---- 0.3.1 redraw: every object he uses, machines-sheet detail, true top-down; labels unchanged ---- */
function drawShipChute(){
  /* 0.3.1: airport X-ray scanner + belt (static body). Moving slats and the lock lamp are drawn in drawShipAnim. */
  var cx=GEO.ship.x, wall=GEO.WALL, boxW=16, boxH=15, boxX0=cx-boxW/2, boxY0=wall, boxY1=boxY0+boxH;
  /* square scanner box, top-down: heavy housing, darker tunnel, lead curtains on the south mouth */
  wr(boxX0+0.6,boxY0+0.6,boxW,boxH,"rgba(0,0,0,0.32)");
  wr(boxX0,boxY0,boxW,boxH,"#3a4038");wr(boxX0+0.6,boxY0+0.6,boxW-1.2,boxH-1.2,"#5a6258");
  wr(boxX0+0.6,boxY0+0.6,boxW-1.2,1.2,"#9aa49a");wr(boxX0+0.6,boxY1-1.6,boxW-1.2,1,"#2a2c28");
  wr(boxX0,boxY0,0.8,boxH,"#8a9088");wr(boxX0+boxW-0.8,boxY0,0.8,boxH,"#2a2c28");
  /* tunnel / viewing window down the centre */
  wr(boxX0+3.2,boxY0+3,boxW-6.4,boxH-6.5,"#12141a");wr(boxX0+3.6,boxY0+3.4,boxW-7.2,boxH-7.3,"#1a2030");
  wr(boxX0+3.6,boxY0+3.4,boxW-7.2,0.6,"#3a5068");
  /* corner bolts */
  var bolts=[[0.8,0.8],[boxW-1.6,0.8],[0.8,boxH-1.6],[boxW-1.6,boxH-1.6]];
  for(var i=0;i<bolts.length;i++){wr(boxX0+bolts[i][0],boxY0+bolts[i][1],1.1,1.1,"#2a2c28");wr(boxX0+bolts[i][0]+0.2,boxY0+bolts[i][1]+0.2,0.7,0.7,"#c0c8c0");}
  /* lead-curtain strips at the south mouth */
  var mx0=cx-4.2, mw=8.4;for(var s=0;s<6;s++)wr(mx0+s*1.4,boxY1-1.2,1.1,2.2,s%2?"#2a2c28":"#3a4038");
  /* hazard lip just south of the mouth */
  var bl=1.6, hy=boxY1+0.4, hx0=cx-5;for(var x=0,n=0;x<10;x+=bl,n++)wr(hx0+x,hy,bl,1.1,n%2?"#2a2a24":"#e0b020");
  /* belt bed from the mouth down toward the drop stand (rails + deck; slats are animated) */
  var beltW=9, beltX0=cx-beltW/2, beltY0=boxY1+1.4, beltY1=GEO.ship.lip+6.5;
  wr(beltX0-0.8,beltY0,beltW+1.6,beltY1-beltY0,"#2a2c28");
  wr(beltX0,beltY0,beltW,beltY1-beltY0,"#4a4a44");
  wr(beltX0,beltY0,beltW,0.5,"#6a6a60");
  wr(beltX0-0.8,beltY0,0.8,beltY1-beltY0,"#6a7068");wr(beltX0+beltW,beltY0,0.8,beltY1-beltY0,"#3a4038");
  /* roller caps at the south end */
  wr(beltX0-1,beltY1-0.8,beltW+2,1.4,"#3a4038");wr(beltX0-0.6,beltY1-0.5,beltW+1.2,0.8,"#8a9088");
  /* small side panel on the east face of the box */
  wr(boxX0+boxW,boxY0+4,2.4,6,"#3a4038");wr(boxX0+boxW,boxY0+4.3,2,1.1,"#1a1c18");wr(boxX0+boxW+0.4,boxY0+7,1.4,1.4,"#2a2010");
  }
function drawKitchenDropHole(){
  /* 0.4.5: a dark arch in the north wall — the kitchen side of the shared drop hole (matches the wash-room inlet). The old X-ray scanner (drawShipChute) is hidden, not deleted. */
  var cx=GEO.ship.x, wall=GEO.WALL, r=14;
  /* cut a deep recess into the north wall so the hole reads even when he stands near it */
  wr(cx-r-6, 0, (r+6)*2, wall+3.2, "#2a2820");
  wr(cx-r-4.2, 0.4, (r+4.2)*2, wall+2.2, "#1a1814");
  wr(cx-r-2.6, 0.8, (r+2.6)*2, wall+1.4, "#0a0c10");
  wr(cx-r-1.4, 1.2, (r+1.4)*2, wall+0.6, "#000000");
  oval(wx(cx),wy(wall+1.2),ws(r+2.4),ws(r*0.78),"#0a0c10");
  oval(wx(cx),wy(wall+0.4),ws(r+0.8),ws(r*0.58),"#000000");
  oval(wx(cx),wy(wall-1.0),ws(r-2.4),ws(r*0.34),"#000000");
  /* wooden posts + sill, same trim as the table / wash bench */
  wr(cx-r-5.2, wall-0.4, 2.4, 5.2, "#4a3018");wr(cx+r+2.8, wall-0.4, 2.4, 5.2, "#4a3018");
  wr(cx-r-4.8, wall-0.2, 1.6, 4.6, "#7a5a30");wr(cx+r+3.2, wall-0.2, 1.6, 4.6, "#7a5a30");
  wr(cx-r-5, wall+2.2, (r+5)*2, 2.8, "#4a3018");
  wr(cx-r-4.2, wall+2.4, (r+4.2)*2, 2.0, "#7a5a30");
  wr(cx-r-4.2, wall+2.2, (r+4.2)*2, 0.6, "#9a7a48");
  ctx.strokeStyle="#8a6a40";ctx.lineWidth=Math.max(1,ws(1.8));ctx.beginPath();ctx.ellipse(wx(cx),wy(wall+1.4),ws(r+1.8),ws(r*0.62),0,0.12,Math.PI-0.12);ctx.stroke();
  ctx.strokeStyle="#5a5648";ctx.lineWidth=Math.max(1,ws(1.2));ctx.beginPath();ctx.ellipse(wx(cx),wy(wall-0.2),ws(r+0.4),ws(r*0.46),0,Math.PI+0.2,Math.PI*2-0.2);ctx.stroke();
}
function drawDoor(){
  /* giant industrial door, west of the drop hole (or the wash-room twin), flush to the north wall. */
  var D=viewIsWash()?WASH.door:WASH.kitDoor,x0=D.x0,y0=D.y0,w=D.w,h=D.h;
  wr(x0+0.8,y0+0.8,w,h,"rgba(0,0,0,0.34)");
  wr(x0,y0,w,h,"#2a2c30");wr(x0+0.6,y0+0.6,w-1.2,h-1.2,"#4a5058");
  wr(x0+0.6,y0+0.6,w-1.2,1.4,"#8a9098");wr(x0,y0,0.8,h,"#6a7078");wr(x0+w-0.8,y0,0.8,h,"#1a1c20");
  /* centre seam + two leaves */
  wr(x0+w/2-0.4,y0+0.6,0.8,h-1.2,"#2a2c30");wr(x0+w/2-0.15,y0+0.6,0.3,h-1.2,"#8a9098");
  /* rivet grid */
  for(var ry=2;ry<h-1.5;ry+=3.2)for(var rx=1.6;rx<w-1.2;rx+=3.2){
    if(Math.abs(rx-w/2)<1.2)continue;
    wr(x0+rx,y0+ry,1.1,1.1,"#1a1c20");wr(x0+rx+0.2,y0+ry+0.15,0.7,0.7,"#c0c8c0");}
  /* hinges on the west edge */
  for(var i=0;i<3;i++){var hy=y0+3+i*5.5;wr(x0-1.2,hy,2.2,2.2,"#3a4038");wr(x0-0.9,hy+0.3,1.6,1.6,"#8a9088");}
  /* heavy bar lock + padlock at the seam (hidden, not deleted, once the KEY is bought) */
  if(!(sim&&sim.hasKey&&sim.hasKey())){
    wr(x0+w/2-4,y0+h*0.58,8,2.2,"#2a2018");wr(x0+w/2-3.6,y0+h*0.58+0.3,7.2,1.6,"#5a4a38");
    var px=x0+w/2,py=y0+h*0.36;
    wr(px-1.4,py-3.6,0.8,2.4,"#c0c8c0");wr(px+0.6,py-3.6,0.8,2.4,"#c0c8c0");wr(px-1.4,py-3.8,2.8,0.8,"#d0d8d0");
    wr(px-2.4,py-1.2,4.8,4.0,"#1a1410");wr(px-2.1,py-0.9,4.2,3.4,"#6a5a40");wr(px-1.7,py-0.5,3.4,2.6,"#8a7a58");
    wr(px-0.55,py+0.35,1.1,1.5,"#1a1410");wr(px-0.35,py+0.55,0.7,0.7,"#c8b890");
  }else{
    /* open leaves: a slightly parted seam */
    wr(x0+w/2-0.9,y0+0.6,1.8,h-1.2,"#1a1c20");
  }
  /* lamp housing on the north (top) edge — the bulb is drawn pulsing in drawShipAnim */
  wr(x0+w/2-2,y0-2.2,4,2.4,"#3a4038");wr(x0+w/2-1.6,y0-1.8,3.2,1.6,"#2a2c28");
  /* plate: LOCKED (red) until the KEY is bought, then OPEN (green) */
  var open=sim&&sim.hasKey&&sim.hasKey();
  wr(x0+w/2-6.6,y0+h-5.4,13.2,4.2,open?"#081a0c":"#1a0808");wr(x0+w/2-6.2,y0+h-5.1,12.4,3.6,open?"#184a20":"#4a1818");wr(x0+w/2-5.8,y0+h-4.8,11.6,3.0,open?"#206a28":"#6a2020");
  var glyphs={L:["100","100","100","100","111"],O:["111","101","101","101","111"],C:["111","100","100","100","111"],K:["101","101","110","101","101"],E:["111","100","110","100","111"],D:["110","101","101","101","110"],P:["111","101","111","100","100"],N:["101","111","111","101","101"]};
  var word=open?"OPEN":"LOCKED",uu=0.48,gap=0.26,tw=word.length*(3*uu+gap)-gap,lx=x0+w/2-tw/2,ly=y0+h-4.55,col=open?"#d8ffd0":"#ffd0d8";
  for(var gi=0;gi<word.length;gi++){var rows=glyphs[word[gi]],bx=lx+gi*(3*uu+gap);
    for(var r=0;r<5;r++)for(var c=0;c<3;c++)if(rows[r][c]==="1")wr(bx+c*uu,ly+r*uu,uu*0.9,uu*0.9,col);}
  }
function drawShipAnim(now){
  if(!viewIsWash()){
  var cx=GEO.ship.x, boxY1=GEO.WALL+15, beltX0=cx-4.5, beltW=9, beltY0=boxY1+1.4, beltY1=GEO.ship.lip+6.5;
  var period=3.2, off=(ANIM_F/4)*period;
  /* slats travel north (toward the scanner), 4 discrete frames — restored 0.4.4 */
  for(var y=beltY0-period+off;y<beltY1;y+=period){
    var y0=Math.max(beltY0,y), y1=Math.min(beltY1,y+1.3);if(y1<=y0)continue;
    wr(beltX0+0.3,y0,beltW-0.6,y1-y0,"#6a6a58");wr(beltX0+0.3,y0,beltW-0.6,0.35,"#8a8a70");}
  /* scanner window glow, stepped with the frame clock */
  var g=[0.08,0.12,0.16,0.11][ANIM_F];ctx.globalAlpha=g;wr(cx-4.6,GEO.WALL+3.4,9.2,8.2,"#40a0ff");ctx.globalAlpha=1;
  }else if(WASH.outlet){
  /* matching glow in the wash-room outlet window */
  var O=WASH.outlet,cx=O.x,boxH=O.boxH||15,boxY0=WH-GEO.WALL-boxH;
  var g2=[0.08,0.12,0.16,0.11][ANIM_F];ctx.globalAlpha=g2;wr(cx-4.6,boxY0+3.4,9.2,8.2,"#40a0ff");ctx.globalAlpha=1;
  }
  /* door lock lamp: red pulse while locked, steady green when the KEY is owned */
  var open=sim&&sim.hasKey&&sim.hasKey();
  var dx=(viewIsWash()?WASH.door.x0+WASH.door.w/2:17+10), dy=(viewIsWash()?WASH.door.y0:GEO.WALL-0.6)-1.1, pulse=[0.35,0.65,1,0.55][ANIM_F];
  if(open){ctx.globalAlpha=0.55;oval(wx(dx),wy(dy),ws(2.2),ws(1.6),"#20ff50");ctx.globalAlpha=0.9;oval(wx(dx),wy(dy),ws(1.3),ws(1.0),"#80ff90");ctx.globalAlpha=1;oval(wx(dx),wy(dy),ws(0.6),ws(0.5),"#e8ffe8");}
  else{ctx.globalAlpha=0.30+0.50*pulse;oval(wx(dx),wy(dy),ws(2.2),ws(1.6),"#ff2030");ctx.globalAlpha=0.65+0.35*pulse;oval(wx(dx),wy(dy),ws(1.3),ws(1.0),"#ff8090");ctx.globalAlpha=1;oval(wx(dx),wy(dy),ws(0.6),ws(0.5),"#ffe8e8");}
  }
function drawCoolerHum(){
  var G=GEO.cooler,lx=wx(G.x1)-ws(2.3),ly=wy(G.y0)+ws(2.4);
  var col=["#1a4a3a","#2a8a60","#50f0a0","#2a8a60"][ANIM_F];
  disc(lx,ly,ws(1.15),ws(1.15),col,"#0a2018");
  if(ANIM_F===2){ctx.globalAlpha=0.35;oval(lx,ly,ws(2.1),ws(2.1),"#40e090");ctx.globalAlpha=1;}
}
function drawReturnRattle(){
  if(sim&&sim.s&&sim.s.suck)retLight=1;
  var G=GEO.ret,x0=G.mouthX,y=G.y,hh=G.w/2+0.5;
  var jx=[ -1.2, 1.1, 0.2, -0.6 ][ANIM_F], jy=[ 0.2, -0.9, 1.2, -0.3 ][ANIM_F];
  if(!retLight){jx*=0.45;jy*=0.45;}
  var mx=wx(x0+jx),my=wy(y+jy);
  /* pipe mouth: rim + receding tunnel (not a flat black dot, t1069) */
  oval(mx,my,ws(2.9),ws(hh+0.9),"#8a9088");
  oval(mx,my,ws(2.4),ws(hh+0.35),"#5a6258");
  oval(mx,my,Math.max(1,ws(1.7)),ws(hh-0.4),"#2a322c");
  oval(mx+ws(0.35),my,Math.max(1,ws(1.05)),ws(hh-1.0),"#1e2622");
  oval(mx-ws(0.7),my-ws(0.7),Math.max(1,ws(0.8)),Math.max(1,ws(0.55)),"#7a8478");
  /* rattling bolts */
  var bx=wx(x0+3+jx), by1=wy(y-hh-0.4+jy), by2=wy(y+hh-0.6+jy);
  oval(bx,by1,ws(0.55),ws(0.55),"#c0c8c0");oval(bx,by2,ws(0.55),ws(0.55),"#c0c8c0");
}

function drawReturnChute(){var G=GEO.ret,x0=G.mouthX,x1=RW-WALL,y=G.y,hh=G.w/2+0.5,len=x1-x0;
  wr(x0+1,y-hh+2,len,hh*2,"rgba(0,0,0,0.28)");
  wr(x0,y-hh,len+0.5,hh*2,"#323830");wr(x0,y-hh+0.4,len+0.5,hh*2-0.8,"#5a6258");wr(x0,y-hh+1.4,len+0.5,hh*2-2.8,"#6a7268");
  wr(x0,y-hh,len+0.5,1.4,"#9aa49a");wr(x0,y+hh-1.6,len+0.5,1.6,"#3a4038");
  /* centre seam */
  wr(x0,y-0.4,len+0.5,0.8,"#4a5248");
  /* pipe rings + bolts */
  var rx=[x0+3,x0+9,x0+15];for(var i=0;i<rx.length;i++){wr(rx[i],y-hh-0.8,1.4,hh*2+1.6,"#3a4038");wr(rx[i],y-hh-0.8,0.7,hh*2+1.6,"#7a8478");
    wr(rx[i]+0.2,y-hh-0.4,0.8,0.8,"#c0c8c0");wr(rx[i]+0.2,y+hh-0.6,0.8,0.8,"#c0c8c0");}
  /* green arrows pointing OUT (west) */
  for(var a=0;a<2;a++){var ax=x0+5.5+a*6,ay=y;for(var d=0;d<3;d++){wr(ax+d*0.9,ay-d*0.9,1,1,"#3ad070");wr(ax+d*0.9,ay+d*0.9,1,1,"#3ad070");}}
  /* wall flange with four bolts */
  wr(x1-0.5,y-hh-2,4.5,hh*2+4,"#3a4038");wr(x1-0.5,y-hh-2,1,hh*2+4,"#8a9088");
  wr(x1+1,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+1,y+hh-0.2,1.2,1.2,"#c0c8c0");
  wr(x1+2.4,y-hh-1,1.2,1.2,"#c0c8c0");wr(x1+2.4,y+hh-0.2,1.2,1.2,"#c0c8c0");
  /* mouth is drawn each frame in drawReturnRattle so it can shake */
  /* spill tray with grate under the mouth */
  wr(x0-7,y-hh+0.5,6,hh*2-1,"rgba(40,50,40,0.28)");wr(x0-7,y-hh+0.5,6,0.6,"#7a8478");wr(x0-7,y+hh-1.1,6,0.6,"#3a4038");
  for(var t=0;t<3;t++)wr(x0-6+t*2,y-hh+1,0.6,hh*2-2,"rgba(200,210,200,0.28)");}
function drawTable2(){var G=GEO.table,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+2,y+2,w,h,"rgba(0,0,0,0.30)");
  /* thick wooden slab + corner irons + legs peeking at the four corners */
  R(x,y,w,h,"#4a3018");R(x,y,w,2,"#8a6a40");R(x,y,2,h,"#6a4a28");R(x,y+h-2,w,2,"#3a200c");R(x+w-2,y,2,h,"#3a200c");
  R(x+2,y+2,w-4,h-4,"#7a5a30");R(x+2,y+2,w-4,1,"#9a7a48");
  for(var i=1;i<=4;i++)R(x+3,y+2+Math.round((h-4)*i/5),w-6,1,"#6a4a28");
  var lg=Math.max(2,ws(2.2));
  R(x-1,y-1,lg,lg,"#3a200c");R(x+w-lg+1,y-1,lg,lg,"#3a200c");R(x-1,y+h-lg+1,lg,lg,"#2a1408");R(x+w-lg+1,y+h-lg+1,lg,lg,"#2a1408");
  R(x,y,3,3,"#5a4030");R(x+w-3,y,3,3,"#5a4030");R(x,y+h-3,3,3,"#3a200c");R(x+w-3,y+h-3,3,3,"#3a200c");
  /* cutting board + knife are children of the table (t1073): always fully on the slab, follow it in the editor */
  var kids=PPSim.tableKids(),B=kids.board,K=kids.knife;
  var bx=wx(B.x0),by=wy(B.y0),bw=Math.max(2,wx(B.x1)-wx(B.x0)),bh=Math.max(2,wy(B.y1)-wy(B.y0));
  R(bx+1,by+1,bw,bh,"rgba(0,0,0,0.25)");R(bx,by,bw,bh,"#8a6a30");R(bx+1,by+1,bw-2,bh-2,"#d8b878");R(bx+1,by+1,bw-2,1,"#ecd29a");
  R(bx+2,by+2,bw-4,1,"#b8985c");R(bx+2,by+bh-3,bw-4,1,"#b8985c");R(bx+2,by+2,1,bh-4,"#b8985c");R(bx+bw-3,by+2,1,bh-4,"#b8985c");
  for(var j=0;j<5;j++)R(bx+3+j*Math.max(2,Math.round(bw/6)),by+3+(j%2)*2,Math.max(2,Math.round(bw/9)),1,"#b8985c");
  var kx=wx(K.x),ky=wy(K.y-0.8),kw=Math.max(3,ws(3.2)),kh=Math.max(2,ws(1.6)),blw=Math.max(5,ws(5.0));
  /* keep the knife inside the table's east margin */
  if(kx+kw>wx(G.x1)-1)kx=wx(G.x1)-1-kw;
  if(kx-blw<wx(B.x1)+1){/* sits just east of the board, still on the table */}
  R(kx,ky,kw,kh,"#3a2a20");R(kx+1,ky,kw-2,1,"#6a4a30");R(kx-1,ky,1,kh,"#2a1c14");
  R(kx-blw,ky,blw,Math.max(2,ws(1.5)),"#c8d0d8");R(kx-blw,ky,blw,1,"#f0f4f8");R(kx-blw,ky+Math.max(1,ws(1.5))-1,blw,1,"#8a9098");}
function drawBed(){var cx=GEO.mat.x,cy=GEO.mat.y,mw=GEO.mat.w,mh=GEO.mat.h;var x=wx(cx-mw/2),y=wy(cy-mh/2),w=ws(mw),h=ws(mh);
  /* full-size wooden frame, mattress, west pillows, east blanket — holds a lying Papa */
  R(x+2,y+2,w,h,"rgba(0,0,0,0.30)");
  blob(x-1.2,y-1.2,w+2.4,h+2.4,2.2,"#5a3a20","#2a1810");
  R(x-1.2,y-1.2,w+2.4,1.4,"#8a6a40");R(x-1.2,y+h,w+2.4,1.2,"#3a200c");
  blob(x+1.4,y+1.4,w-2.8,h-2.8,1.6,"#e8e4d4","#c8c0a8");
  R(x+2,y+2,w-4,1.2,"#fffaf0");
  /* headboard on the west end */
  blob(x-2.2,y-2.2,ws(3.4),h+4.4,1.1,"#7a5a30","#2a1810");R(x-2.2,y-2.2,ws(3.4),1.4,"#9a7a48");
  /* blanket over the east two thirds, folded hem */
  var bw=w*0.62,bx=x+w-bw-1.2;
  blob(bx,y+1.6,bw,h-3.2,1.4,"#4a6aa8","#2a3058");
  R(bx,y+1.6,bw,Math.max(2,h*0.22),"#6a8ac8");R(bx,y+1.6,2,h-3.2,"#d8e0f0");
  for(var i=5;i<bw-3;i+=6)R(bx+i,y+h*0.28,1,h-h*0.28-3.2,"#3a5a98");
  /* two stacked pillows at the west end, room for his head */
  var pw=Math.max(6,ws(6.8)),ph=Math.max(5,h-5.2);
  blob(x+3.2,y+2.6,pw,ph,2.0,"#fffaf0","#a8a090");
  blob(x+4.2,y+3.4,pw-2,ph-2.2,1.6,"#fffef6","#d8d0b8");
  R(x+5,y+3.8,pw-4,1.2,"#ffffff");}
function drawCooler2(){var G=GEO.cooler,x=wx(G.x0),y=wy(G.y0),w=ws(G.x1-G.x0),h=ws(G.y1-G.y0);
  R(x+1,y+1,w,h,"rgba(0,0,0,0.28)");R(x,y,w,h,"#1c3a5a");R(x+1,y+1,w-2,h-2,"#3a6a9a");
  R(x+1,y+1,w-2,1,"#8ab8e0");R(x+1,y+h-2,w-2,1,"#1a2c44");R(x+1,y,1,h,"#8ab8e0");R(x+w-2,y,1,h,"#1a2c44");
  /* lid seam, hinges, latch */
  R(x+1,y+Math.round(h*0.62),w-2,1,"#24405a");R(x+2,y+Math.round(h*0.62)-1,Math.max(2,ws(2)),2,"#c0c8c0");R(x+w-Math.max(4,ws(3.5)),y+Math.round(h*0.62)-1,Math.max(2,ws(2)),2,"#c0c8c0");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),Math.max(1,ws(1.5)),"#e8eef4");
  R(x+Math.round(w*0.3),y+Math.round(h*0.35),Math.round(w*0.4),1,"#ffffff");
  /* rubber gasket just inside the rim */
  R(x+2,y+2,w-4,1,"#1a2840");R(x+2,y+h-3,w-4,1,"#1a2840");
  /* a can of food on the lid (the stock lives in here) */
  var cw=Math.max(3,ws(3.4)),chh=Math.max(3,ws(3.6)),cx0=x+Math.round(w*0.12),cy0=y+Math.round(h*0.12);
  R(cx0,cy0,cw,chh,"#7a3a10");R(cx0,cy0+1,cw,chh-2,"#e0a040");R(cx0,cy0,cw,1,"#f0e0b0");R(cx0+1,cy0+Math.round(chh/2),Math.max(1,cw-2),1,"#b04020");
  /* hum-lamp well (the glow is drawn in drawCoolerHum) */
  R(x+w-ws(3.6),y+ws(1.1),ws(2.6),ws(2.6),"#0a1828");R(x+w-ws(3.3),y+ws(1.4),ws(2.0),ws(2.0),"#1a2840");}
function drawStool(){var x=wx(GEO.stool.x),y=wy(GEO.stool.y),r=Math.max(5,ws(4.4)),q=Math.max(2,Math.round(r*0.34)),lg=Math.round(r*0.95);
  oval(x+1,y+r*0.45,r+1,r*0.7,"rgba(0,0,0,0.30)");
  /* four wooden legs + a foot ring so it reads as a stool, not a cushion */
  ctx.fillStyle="#3a2410";var d=[[-1,-1],[1,-1],[-1,1],[1,1]];for(var i=0;i<4;i++)ctx.fillRect(Math.round(x+d[i][0]*lg-q/2),Math.round(y+d[i][1]*lg*0.8-q/2),q,q);
  oval(x,y,r*0.85,r*0.7,"#5a3a20");oval(x,y,r*0.72,r*0.58,"#3a2410");
  /* round red cushion, dark rim, highlight, centre button, stitch ring */
  oval(x,y,r,r*0.86,"#2a1010");oval(x,y,r-1,r*0.86-1,"#a8302a");oval(x,y,r-2,r*0.86-2,"#c8443a");
  oval(x-r*0.25,y-r*0.2,Math.max(1,r*0.4),Math.max(1,r*0.28),"#e87a64");
  oval(x,y,Math.max(1,r*0.16),Math.max(1,r*0.14),"#6a2018");oval(x,y,Math.max(1,r*0.08),Math.max(1,r*0.07),"#e87a64");}
function drawPileBay(){var G=GEO.pile,x0=G.cx-G.rx-2,x1=G.cx+G.rx+2,y0=G.base+G.rz-3,y1=RH-WALL;
  /* shallow wooden bay against the bottom wall; potatoes draw on top, the curb shows around a small pile */
  wr(x0,y0,x1-x0,y1-y0,"rgba(40,30,16,0.16)");
  wr(x0,y1-2.2,x1-x0,2.2,"#4a3018");wr(x0,y1-2.2,x1-x0,0.8,"#8a6a40");wr(x0,y1-1.2,x1-x0,1.2,"#3a200c");
  wr(x0,y0,1.6,y1-y0,"#4a3018");wr(x0,y0,0.7,y1-y0,"#8a6a40");
  wr(x1-1.6,y0,1.6,y1-y0,"#3a200c");wr(x1-0.8,y0,0.8,y1-y0,"#5a3a18");
  /* corner posts */
  wr(x0-0.4,y1-3.2,2.2,3.2,"#3a200c");wr(x0-0.4,y1-3.2,2.2,0.8,"#8a6a40");
  wr(x1-1.8,y1-3.2,2.2,3.2,"#3a200c");wr(x1-1.8,y1-3.2,2.2,0.8,"#8a6a40");}
function drawPileShadow(){var G=GEO.pile;ctx.fillStyle="rgba(40,30,16,0.22)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+1),ws(G.rx+4),ws(G.rz+2),0,0,6.28);ctx.fill();
  ctx.fillStyle="rgba(30,22,10,0.16)";ctx.beginPath();ctx.ellipse(wx(G.cx),wy(G.base+2),ws(G.rx-4),ws(G.rz-2),0,0,6.28);ctx.fill();}
/* ---------- the pile: 0.2 look (stacked tiers), spread wider and lower along the bottom wall ---------- */
function shadeHex(h,f){var n=parseInt(h.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function c(v){v=Math.round(v*f);return Math.max(0,Math.min(255,v));}return"rgb("+c(r)+","+c(g)+","+c(b)+")";}
var LVF=[0.60,0.74,0.90,1.08,1.25,1.42];
function buildPile(){POS=[];ORDER=[];TIER=[];var G=GEO.pile,cx=G.cx,base=G.base,rx0=G.rx,rz0=G.rz,idx=0;
  var LF=LIFT;
  for(var t=0;idx<PILEMAX;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(100*sc*sc):90;TIER.push(idx);
    for(var j=0;j<cap;j++,idx++){var r=Math.sqrt(((j+0.5)*0.7548776662)%1),th=(((j+0.5)*0.5698402910)%1)*6.28318+t*1.3;   /* R2 low-discrepancy: ANY prefix of a tier is spread over the whole tier, so a small pile already lies wide along the floor */
      var x=cx+rx0*sc*r*Math.cos(th)+(srng(idx*5+2)-0.5)*3,z=base+rz0*sc*r*Math.sin(th)+(srng(idx*3+7)-0.5)*2.2;
      POS.push({x:x,y:z-Math.min(t,9)*LF,z:z,t:t,vi:idx%3,fl:(idx*7)%2});}}
  MAXVIS=POS.length;ORDER=POS.map(function(p,i){return i;});ORDER.sort(function(a,b){var pa=POS[a],pb=POS[b];return pa.t!==pb.t?pa.t-pb.t:pa.y-pb.y;});}
function withCtx(c2,fn){var o=ctx;ctx=c2;try{fn();}finally{ctx=o;}}
function mkSprite(w,h,fn){var c=document.createElement("canvas");c.width=Math.max(1,Math.round(w*DPR));c.height=Math.max(1,Math.round(h*DPR));var g=c.getContext("2d");g.imageSmoothingEnabled=false;g.setTransform(DPR,0,0,DPR,0,0);withCtx(g,fn);c.cssW=w;c.cssH=h;return c;}
function buildSprites(){SPR=[];SPRS=[];var sizes=[2.9,3.3,3.7];
  for(var vi=0;vi<3;vi++){var sp=Math.max(3,Math.round(sizes[vi]*k)),hw=Math.max(2,Math.round(sp)),hh=Math.max(2,Math.round(sp*0.72)),w=2*hw+6,hgt=2*hh+7;
    for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++){var base=["#4a2810","#6a4020","#8a5a28","#c48a48"],f=LVF[lv];
      var pal=[shadeHex(base[0],f*0.9),shadeHex(base[1],f),shadeHex(base[2],f),shadeHex(base[3],f)];
      for(var sh=0;sh<2;sh++){(function(sh2){var spr=mkSprite(w,hgt,function(){if(sh2)oval(hw+3+1,hh+4+1,hw+1,hh,"rgba(0,0,0,0.20)");potato(hw+3,hh+3,sp,false,!!fl,0,pal);});
        spr.cx=hw+3;spr.cy=hh+3;(sh2?SPRS:SPR)[(vi*6+lv)*2+fl]=spr;})(sh);}}}
  PEELSPR=[];var pcol=[["#f5e0a8","#e8c070","#b08838"],["#e8c070","#d4a04a","#9a7430"],["#f0d890","#c8a040","#8a6a2a"]];
  var pats=[[".XX.","X..X","...X"],["XX..",".XXX","...."],[".X.","X.X",".XX"],["XXX.","...X",".XX."]];
  var pw=Math.max(10,Math.round(4.4*k)),ph=Math.max(8,Math.round(3.4*k)),psc=pw/6;
  for(var q=0;q<12;q++){var pc=pcol[q%3],pt=pats[q%4];PEELSPR[q]=mkSprite(pw,ph,function(){for(var yy=0;yy<pt.length;yy++)for(var xx=0;xx<pt[yy].length;xx++)if(pt[yy][xx]==="X"){R((1+xx)*psc,(1+yy+1)*psc,psc,psc,pc[2]);R((1+xx)*psc,(1+yy)*psc,psc,psc,pc[(xx+yy)%2]);}});PEELSPR[q].cx=pw/2;PEELSPR[q].cy=ph/2;}}
/* peels live in sim.s.mess (real positions). MESSPOS mirrors them for the renderer and tests. */
function buildMess(){MESSPOS=[];var mess=sim&&sim.s&&sim.s.mess?sim.s.mess:[];
  for(var i=0;i<mess.length;i++)MESSPOS.push({x:mess[i].x,y:mess[i].y,q:(i*5+3)%12,src:mess[i].src});}
function renderPile(n){if(!pileLayer||pileLayer.width!==cv.width||pileLayer.height!==cv.height){pileLayer=document.createElement("canvas");pileLayer.width=cv.width;pileLayer.height=cv.height;pileKey=-1;}
  if(pileKey===n)return;pileKey=n;renders.pile++;var c=pileLayer.getContext("2d");c.imageSmoothingEnabled=false;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cv.width,cv.height);
  /* 0.3 shading: a fixed, gentle light ramp by tier (never relative to the heap height) and a soft shadow only under the bottom tier, so a big pile stays readable */
  for(var q=0;q<ORDER.length;q++){var i=ORDER[q];if(i>=n)continue;var p=POS[i],lv=Math.min(4,2+Math.floor(p.t/3)),sp=(p.t===0?SPRS:SPR)[(p.vi*6+lv)*2+p.fl];c.drawImage(sp,Math.round((wx(p.x)-sp.cx)*DPR),Math.round((wy(p.y)-sp.cy)*DPR));}}
var flying={},messVer=0;
function renderMess(n){buildMess();if(!messLayer||messLayer.width!==cv.width||messLayer.height!==cv.height){messLayer=document.createElement("canvas");messLayer.width=cv.width;messLayer.height=cv.height;messKey="";}
  var key=(sim&&sim.s?sim.s.peels:n)+"|"+messVer+"|"+MESSPOS.length;if(messKey===key)return;messKey=key;renders.mess++;var c=messLayer.getContext("2d");c.imageSmoothingEnabled=false;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cv.width,cv.height);
  for(var i=0;i<MESSPOS.length;i++){if(flying[i])continue;var p=MESSPOS[i],spr=PEELSPR[p.q];if(!spr)continue;c.drawImage(spr,Math.round((wx(p.x)-spr.cx)*DPR),Math.round((wy(p.y)-spr.cy)*DPR));}}

function streetUp(){return sim&&sim.up?sim.up("channel"):0;}
function peelSz(){return Math.max(2.8,4.0*k*0.82);} /* same on-screen size as the potato he peels */
function drawStreetTrough(fill,widAdd){   /* 0.4.4 diagonal helper kept, hidden */
  var seg=PPSim.streetSeg(),wid=ws(PPSim.streetWidth(streetUp())+(widAdd||0)),x0=wx(seg.x0),y0=wy(seg.y0),x1=wx(seg.x1),y1=wy(seg.y1);
  ctx.save();ctx.strokeStyle=fill;ctx.lineWidth=Math.max(4,wid);ctx.lineCap="round";ctx.lineJoin="round";
  ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.stroke();ctx.restore();
}
function drawCanalTrough(fill,widAdd){   /* 0.4.5 helper kept, hidden; 0.4.6 draws a recessed trench instead */
  var pts=PPSim.canalPts(),wid=ws(PPSim.streetWidth(streetUp())+(widAdd||0)),i;
  if(!pts||pts.length<2)return;
  ctx.save();ctx.strokeStyle=fill;ctx.lineWidth=Math.max(4,wid);ctx.lineCap="round";ctx.lineJoin="round";
  ctx.beginPath();ctx.moveTo(wx(pts[0].x),wy(pts[0].y));
  for(i=1;i<pts.length;i++)ctx.lineTo(wx(pts[i].x),wy(pts[i].y));
  ctx.stroke();ctx.restore();
}
/* visual canal path starts at the basin's east rim so the trench opens out of the pool instead of a line pasted across it */
function canalFilletR(){return 18;}
function canalDrawPts(){
  var L=WASH.land,E=WASH.elbow,H=WASH.hole,r=canalFilletR(),c={x:E.x-r,y:E.y-r},n=10,i,a,pts;
  pts=[{x:L.x+L.rx-8,y:L.y},{x:E.x-r,y:E.y}];
  for(i=1;i<n;i++){a=(Math.PI/2)*(1-i/n);pts.push({x:c.x+r*Math.cos(a),y:c.y+r*Math.sin(a)});}
  pts.push({x:E.x,y:E.y-r});pts.push({x:H.x,y:H.y});
  return pts;
}
function strokeCanalPath(worldW,color,cap,join){
  var L=WASH.land,E=WASH.elbow,H=WASH.hole,r=canalFilletR();
  ctx.save();ctx.strokeStyle=color;ctx.lineWidth=Math.max(2,ws(worldW));ctx.lineCap=cap||"butt";ctx.lineJoin=join||"round";
  ctx.beginPath();ctx.moveTo(wx(L.x+L.rx-8),wy(L.y));ctx.arcTo(wx(E.x),wy(E.y),wx(H.x),wy(H.y),ws(r));ctx.lineTo(wx(H.x),wy(H.y));
  ctx.stroke();ctx.restore();
}
function strokeCanalPts(pts,worldW,color,cap,join){
  var i;if(!pts||pts.length<2)return;
  ctx.save();ctx.strokeStyle=color;ctx.lineWidth=Math.max(2,ws(worldW));ctx.lineCap=cap||"butt";ctx.lineJoin=join||"round";ctx.miterLimit=2.4;
  ctx.beginPath();ctx.moveTo(wx(pts[0].x),wy(pts[0].y));
  for(i=1;i<pts.length;i++)ctx.lineTo(wx(pts[i].x),wy(pts[i].y));
  ctx.stroke();ctx.restore();
}
function forCanalSamples(pts,step,fn){
  var i,dx,dy,len,nx,ny,px,py,t,acc=0;
  for(i=0;i<pts.length-1;i++){
    dx=pts[i+1].x-pts[i].x;dy=pts[i+1].y-pts[i].y;len=Math.hypot(dx,dy)||1;nx=dx/len;ny=dy/len;px=-ny;py=nx;
    for(t=0;t<=len;t+=step)fn(pts[i].x+nx*t,pts[i].y+ny*t,nx,ny,px,py,acc+t);
    acc+=len;
  }
}
function offsetCanalPts(pts,dist){
  var i,dx,dy,len,px,py,out=[];
  for(i=0;i<pts.length;i++){
    if(i===0){dx=pts[1].x-pts[0].x;dy=pts[1].y-pts[0].y;}
    else if(i===pts.length-1){dx=pts[i].x-pts[i-1].x;dy=pts[i].y-pts[i-1].y;}
    else{dx=pts[i+1].x-pts[i-1].x;dy=pts[i+1].y-pts[i-1].y;}
    len=Math.hypot(dx,dy)||1;px=-dy/len;py=dx/len;
    out.push({x:pts[i].x+px*dist,y:pts[i].y+py*dist});
  }
  return out;
}
function drawCanalTrench(){
  var pts=canalDrawPts(),up=streetUp(),ww=PPSim.streetWidth(up),stone=ww+10,cols=["#3a3830","#4a4638","#5a5648","#322e28"];
  /* damp earth cut in the tiles, then a stone bed, then brick lips — water sits down in this */
  strokeCanalPath(stone+7,"#2a2218","butt","round");
  strokeCanalPath(stone+4.2,"#3a3228","butt","round");
  strokeCanalPath(stone,"#4a4638","butt","round");
  /* brick marks follow the lip as short tangent strokes so the elbow stays smooth */
  ctx.save();ctx.lineCap="butt";
  forCanalSamples(pts,5.0,function(x,y,nx,ny,px,py,d){
    var side=stone/2-0.35,c=cols[(Math.floor(d/5.0)+Math.round(x*0.2+y*0.2))&3],hx=nx*2.15,hy=ny*2.15;
    ctx.strokeStyle=c;ctx.lineWidth=Math.max(1.5,ws(2.3));
    ctx.beginPath();ctx.moveTo(wx(x+px*side-hx),wy(y+py*side-hy));ctx.lineTo(wx(x+px*side+hx),wy(y+py*side+hy));ctx.stroke();
    ctx.beginPath();ctx.moveTo(wx(x-px*side-hx),wy(y-py*side-hy));ctx.lineTo(wx(x-px*side+hx),wy(y-py*side+hy));ctx.stroke();
    ctx.strokeStyle="#7a7460";ctx.lineWidth=Math.max(1,ws(0.7));
    ctx.beginPath();ctx.moveTo(wx(x-px*(side-0.9)-hx*0.8),wy(y-py*(side-0.9)-hy*0.8));ctx.lineTo(wx(x-px*(side-0.9)+hx*0.8),wy(y-py*(side-0.9)+hy*0.8));ctx.stroke();
  });
  ctx.restore();
  /* deep inner bed stays visible around the water */
  strokeCanalPath(ww+6.2,"#1c1812","butt","round");
  strokeCanalPath(ww+4.2,"#0a0c10","butt","round");
}
function drawBasinRim(){
  var L=WASH.land,up=streetUp(),ww=PPSim.streetWidth(up),n=22,i,a,x,y,c,skip;
  skip=Math.atan2(ww*0.5+6,L.rx);
  oval(wx(L.x),wy(L.y),ws(L.rx+7.2),ws(L.ry+5.8),"#2a2218");
  oval(wx(L.x),wy(L.y),ws(L.rx+5.6),ws(L.ry+4.4),"#3a3830");
  for(i=0;i<n;i++){
    a=-Math.PI+i*(Math.PI*2/n);
    if(Math.abs(a)<skip)continue;
    x=L.x+Math.cos(a)*(L.rx+3.6);y=L.y+Math.sin(a)*(L.ry+2.8);
    c=i%3===0?"#4a4638":(i%3===1?"#5a5648":"#3a3830");
    wr(x-2.5,y-1.6,5.0,3.2,c);wr(x-2.1,y-1.6,4.2,0.65,"#7a7460");
  }
  /* inner lip shadow — the water sits below this ring */
  oval(wx(L.x),wy(L.y),ws(L.rx+1.8),ws(L.ry+1.2),"#1a1814");
  oval(wx(L.x),wy(L.y),ws(L.rx+0.6),ws(L.ry+0.3),"#0a0c10");
}
function drawHoleStatic(){
  var h=WASH.hole,cx=h.x,cy=h.y,hw=(h.w||30)/2,hh=(h.h||20)/2;
  /* square doorway the canal meets flush: earth cut, stone, chunky wooden jambs and a clear south sill */
  wr(cx-hw-4.4,cy-hh-3.2,(hw+4.4)*2,(hh+3.2)*2+5.4,"#2a2218");
  wr(cx-hw-3.0,cy-hh-2.0,(hw+3.0)*2,(hh+2.0)*2+4.2,"#3a3830");
  wr(cx-hw-1.6,cy-hh-1.0,(hw+1.6)*2,(hh+1.0)*2+2.4,"#4a4638");
  wr(cx-hw-1.6,cy-hh-1.0,(hw+1.6)*2,1.4,"#7a7460");
  /* posts that stand out into the room, south of the mouth */
  wr(cx-hw-2.8,cy-hh-1.4,3.6,hh*2+6.0,"#3a200c");wr(cx-hw-2.4,cy-hh-1.0,2.6,hh*2+5.2,"#4a3018");wr(cx-hw-2.0,cy-hh-0.6,1.4,hh*2+4.4,"#7a5a30");
  wr(cx+hw-0.8,cy-hh-1.4,3.6,hh*2+6.0,"#3a200c");wr(cx+hw-0.4,cy-hh-1.0,2.6,hh*2+5.2,"#4a3018");wr(cx+hw+0.2,cy-hh-0.6,1.4,hh*2+4.4,"#7a5a30");
  /* lintel */
  wr(cx-hw-2.8,cy-hh-1.8,(hw+2.8)*2,2.4,"#4a3018");wr(cx-hw-2.2,cy-hh-1.6,(hw+2.2)*2,1.2,"#9a7a48");
  /* dark square tunnel, stopped short of the sill */
  wr(cx-hw+1.4,cy-hh+1.0,(hw-1.4)*2,hh*2-2.4,"#1a1814");
  wr(cx-hw+2.6,cy-hh+1.6,(hw-2.6)*2,hh*2-3.6,"#0a0c10");
  wr(cx-hw+4.0,cy-hh+2.2,(hw-4.0)*2,hh*2-5.0,"#000000");
  wr(cx-hw+5.0,cy-hh+2.8,(hw-5.0)*2,hh*0.6,"#000000");
  /* chunky south sill the canal runs square into */
  wr(cx-hw-2.8,cy+hh-0.4,(hw+2.8)*2,3.8,"#3a200c");
  wr(cx-hw-2.2,cy+hh-0.2,(hw+2.2)*2,2.8,"#4a3018");
  wr(cx-hw-1.6,cy+hh-0.2,(hw+1.6)*2,1.2,"#9a7a48");
  wr(cx-hw-1.6,cy+hh+1.8,(hw+1.6)*2,0.8,"#3a200c");
}

function drawInletStatic(){
  var I=WASH.inlet,r=I.r,cx=I.x,wallY=WH-GEO.WALL;
  /* matching tunnel in the south wall, with a short sill so water can pour into the basin */
  wr(cx-r-7, wallY-3.2, (r+7)*2, GEO.WALL+4.2, "#2a2820");
  wr(cx-r-5, wallY-1.8, (r+5)*2, GEO.WALL+3.0, "#1a1814");
  wr(cx-r-3.2, wallY-0.6, (r+3.2)*2, GEO.WALL+2.0, "#0a0c10");
  wr(cx-r-1.8, wallY+0.6, (r+1.8)*2, GEO.WALL+1.0, "#000000");
  oval(wx(cx),wy(wallY+0.8),ws(r+2.2),ws(r*0.7),"#0a0c10");
  oval(wx(cx),wy(wallY+1.8),ws(r+0.2),ws(r*0.48),"#000000");
  oval(wx(cx),wy(wallY+3.0),ws(r-3.0),ws(r*0.26),"#000000");
  wr(cx-r-6.2, wallY-6.2, 2.8, 6.4, "#4a3018");wr(cx+r+3.4, wallY-6.2, 2.8, 6.4, "#4a3018");
  wr(cx-r-5.6, wallY-5.6, 1.8, 5.2, "#7a5a30");wr(cx+r+4.0, wallY-5.6, 1.8, 5.2, "#7a5a30");
  wr(cx-r-6, wallY-4.4, (r+6)*2, 2.6, "#4a3018");
  wr(cx-r-5.2, wallY-4.1, (r+5.2)*2, 1.8, "#7a5a30");
  wr(cx-r-5.2, wallY-4.4, (r+5.2)*2, 0.6, "#9a7a48");
  ctx.strokeStyle="#8a6a40";ctx.lineWidth=Math.max(1,ws(1.8));ctx.beginPath();ctx.ellipse(wx(cx),wy(wallY-0.8),ws(r+2),ws(r*0.5),0,Math.PI+0.1,Math.PI*2-0.1);ctx.stroke();
}
function drawWashShelf(){
  var S=WASH.shelf;if(!S)return;
  wr(S.x-S.w/2,S.y,S.w,S.h,"#4a3018");wr(S.x-S.w/2,S.y,S.w,0.8,"#9a7a48");wr(S.x-S.w/2,S.y+S.h-0.8,S.w,0.8,"#3a200c");
  wr(S.x-S.w/2,S.y,0.8,S.h,"#6a4a28");wr(S.x+S.w/2-0.8,S.y,0.8,S.h,"#3a200c");
  wr(S.x-8,S.y-6.2,4.2,6.2,"#3a6a9a");wr(S.x-7.2,S.y-7.2,2.6,1.2,"#8ab8e0");wr(S.x-6.6,S.y-4.6,1.4,2.2,"#c8e0f0");
  wr(S.x+2,S.y-1.6,8,1.6,"#8a5a40");wr(S.x+3,S.y-2.2,6,1.2,"#c48a68");
}
function drawWashGrate(){
  var G=WASH.grate,s=G.s,x=G.x-s/2,y=G.y-s/2,i;
  oval(wx(G.x),wy(G.y),ws(s*0.85),ws(s*0.7),"rgba(40,36,28,0.28)");
  wr(x-1.2,y-1.2,s+2.4,s+2.4,"#2a2820");wr(x,y,s,s,"#3a4038");wr(x+0.8,y+0.8,s-1.6,s-1.6,"#1a1c18");
  for(i=1;i<5;i++)wr(x+1,y+i*(s/5),s-2,0.7,"#5a6058");
  for(i=1;i<5;i++)wr(x+i*(s/5),y+1,0.7,s-2,"#4a5048");
  wr(x,y,s,0.6,"#8a9088");wr(x,y,0.6,s,"#6a7068");
}
function drawWashMop(){
  var B=WASH.bucket;if(!B)return;
  oval(wx(B.x)+ws(0.6),wy(B.y)+ws(0.8),ws(5.2),ws(2.4),"rgba(0,0,0,0.18)");
  drawBucket(B.x,B.y,5.4,"#2a4a58");
  ctx.save();ctx.strokeStyle="#5a3a20";ctx.lineWidth=Math.max(2,ws(1.6));ctx.lineCap="round";
  ctx.beginPath();ctx.moveTo(wx(B.x+2),wy(B.y-2));ctx.lineTo(wx(B.x+10),wy(B.y-28));ctx.stroke();
  ctx.strokeStyle="#8a6a40";ctx.lineWidth=Math.max(1.2,ws(1.1));
  ctx.beginPath();ctx.moveTo(wx(B.x+2),wy(B.y-2));ctx.lineTo(wx(B.x+10),wy(B.y-28));ctx.stroke();
  ctx.restore();
  wr(B.x+8.4,B.y-30,4.2,3.2,"#6a7068");wr(B.x+8.6,B.y-29.4,3.6,2.2,"#c0c8c0");
}
function drawWashOutlet(){
  var O=WASH.outlet;if(!O)return;
  var cx=O.x,wall=WH-GEO.WALL,boxW=O.boxW||16,boxH=O.boxH||15;
  var boxX0=cx-boxW/2,boxY1=wall,boxY0=boxY1-boxH;
  /* matching 0.4.4 X-ray scanner, flipped onto the south wall; mouth faces north into the basin */
  wr(boxX0+0.6,boxY0+0.6,boxW,boxH,"rgba(0,0,0,0.32)");
  wr(boxX0,boxY0,boxW,boxH,"#3a4038");wr(boxX0+0.6,boxY0+0.6,boxW-1.2,boxH-1.2,"#5a6258");
  wr(boxX0+0.6,boxY1-1.8,boxW-1.2,1.2,"#9aa49a");wr(boxX0+0.6,boxY0+0.6,boxW-1.2,1,"#2a2c28");
  wr(boxX0,boxY0,0.8,boxH,"#8a9088");wr(boxX0+boxW-0.8,boxY0,0.8,boxH,"#2a2c28");
  wr(boxX0+3.2,boxY0+3,boxW-6.4,boxH-6.5,"#12141a");wr(boxX0+3.6,boxY0+3.4,boxW-7.2,boxH-7.3,"#1a2030");
  wr(boxX0+3.6,boxY0+3.4,boxW-7.2,0.6,"#3a5068");
  var bolts=[[0.8,0.8],[boxW-1.6,0.8],[0.8,boxH-1.6],[boxW-1.6,boxH-1.6]],i;
  for(i=0;i<bolts.length;i++){wr(boxX0+bolts[i][0],boxY0+bolts[i][1],1.1,1.1,"#2a2c28");wr(boxX0+bolts[i][0]+0.2,boxY0+bolts[i][1]+0.2,0.7,0.7,"#c0c8c0");}
  /* lead curtains at the north mouth (into the room / basin) */
  var mx0=cx-4.2;for(var s=0;s<6;s++)wr(mx0+s*1.4,boxY0-1.0,1.1,2.2,s%2?"#2a2c28":"#3a4038");
  /* hazard lip just north of the mouth */
  var bl=1.6,hy=boxY0-1.6,hx0=cx-5,x,n;for(x=0,n=0;x<10;x+=bl,n++)wr(hx0+x,hy,bl,1.1,n%2?"#2a2a24":"#e0b020");
  /* short metal lip into the basin, not a long belt */
  wr(cx-5.2,boxY0-3.4,10.4,1.8,"#3a4038");wr(cx-4.6,boxY0-3.0,9.2,1.1,"#6a7068");
  wr(boxX0+boxW,boxY0+4,2.4,6,"#3a4038");wr(boxX0+boxW,boxY0+4.3,2,1.1,"#1a1c18");wr(boxX0+boxW+0.4,boxY0+7,1.4,1.4,"#2a2010");
}
function drawWashProps(){
  /* t1187: top half stays empty; flag off, drawers stay */
  if(!WASH.showProps)return;
  drawWashShelf();
  drawCrate(WASH.crate.x,WASH.crate.y,18,14,false,true);
  drawCrate(WASH.crate2.x,WASH.crate2.y,16,12,false,false);
  drawWashGrate();
  drawWashMop();
}
function drawWashStatic(){
  var P=WASH.pile;
  drawDoor();
  /* 0.4.3/0.4.4/0.4.5 intake, circular pool, mouth, diagonal street and floating bench stay in the file (hidden, not deleted). */
  drawWashProps();
  drawCanalTrench();
  drawBasinRim();
  /* 0.4.5 inlet-hole art (drawInletStatic) stays in the file, hidden. */
  /* outlet machine and ship-opening frame are drawn in the live layer so water does not cover them */
}
function drawWashWater(){
  var L=WASH.land,h=WASH.hole,I=WASH.inlet,pts=canalDrawPts(),up=streetUp(),ww=PPSim.streetWidth(up);
  var deep="#163858",mid="#1f6e98",lit="#3a94b8",i,j,t,x,y,nx,ny,len,acc,total=0,u,d,flow,nRip,spl,ph,drop;
  /* one water body: deep bed, mid channel, lit core — inset so the inner stone shadow stays */
  strokeCanalPath(ww-0.1,deep,"butt","round");
  oval(wx(L.x),wy(L.y),ws(L.rx-0.4),ws(L.ry-0.2),deep);
  strokeCanalPath(Math.max(3.2,ww-3.4),mid,"butt","round");
  oval(wx(L.x)-ws(1.2),wy(L.y)-ws(1.4),ws(L.rx-2.4),ws(L.ry-2.2),mid);
  strokeCanalPath(Math.max(1.8,ww-6.2),lit,"butt","round");
  /* south/east shadow in the basin so the water sits down in the stone */
  ctx.globalAlpha=0.38;oval(wx(L.x)+ws(2),wy(L.y)+ws(6),ws(L.rx-6),ws(L.ry-9),"#0a2030");
  /* NW surface highlight */
  ctx.globalAlpha=0.42;oval(wx(L.x)-ws(9),wy(L.y)-ws(8),ws(16),ws(9),"#c8ecff");
  ctx.globalAlpha=0.22;oval(wx(L.x)-ws(11),wy(L.y)-ws(10),ws(8),ws(4),"#eef8ff");
  /* far-bank (inner/NW) highlight along the trench, near-bank dark */
  strokeCanalPts(offsetCanalPts(pts,-(ww*0.28)),Math.max(1.4,ww*0.16),"rgba(210,238,255,0.55)","butt","round");
  strokeCanalPts(offsetCanalPts(pts,ww*0.30),Math.max(1.6,ww*0.22),"rgba(8,24,40,0.45)","butt","round");
  ctx.globalAlpha=1;
  /* moving flow ripples — chevrons traveling land -> elbow -> hole, faster at higher channel */
  for(j=0;j<pts.length-1;j++)total+=Math.hypot(pts[j+1].x-pts[j].x,pts[j+1].y-pts[j].y)||1;
  flow=0.14+0.22*up;nRip=14+up*5;
  ctx.save();ctx.lineCap="round";ctx.lineJoin="round";
  for(i=0;i<nRip;i++){
    u=((i/nRip)+(ANIM_T*flow)%1)%1;d=u*total;acc=0;
    for(j=0;j<pts.length-1;j++){
      len=Math.hypot(pts[j+1].x-pts[j].x,pts[j+1].y-pts[j].y)||1;
      if(acc+len>=d||j===pts.length-2){
        t=(d-acc)/len;t=t<0?0:t>1?1:t;nx=(pts[j+1].x-pts[j].x)/len;ny=(pts[j+1].y-pts[j].y)/len;
        x=pts[j].x+nx*len*t;y=pts[j].y+ny*len*t;
        ctx.strokeStyle="rgba(226,244,255,"+(0.32+0.4*((i+ANIM_F)%4)/4)+")";
        ctx.lineWidth=Math.max(1,ws(1.15+(i%3===0?0.35:0)));
        if(i%3===1){
          /* short surface dash */
          ctx.beginPath();ctx.moveTo(wx(x-nx*2.4),wy(y-ny*2.4));ctx.lineTo(wx(x+nx*2.8),wy(y+ny*2.8));ctx.stroke();
        }else{
          /* small flow chevron */
          ctx.beginPath();
          ctx.moveTo(wx(x-nx*2.2+ny*1.7),wy(y-ny*2.2-nx*1.7));
          ctx.lineTo(wx(x+nx*2.6),wy(y+ny*2.6));
          ctx.lineTo(wx(x-nx*2.2-ny*1.7),wy(y-ny*2.2+nx*1.7));
          ctx.stroke();
        }
        break;
      }
      acc+=len;
    }
  }
  ctx.restore();ctx.globalAlpha=1;
  /* water comes out the outlet machine mouth into the basin, with rings and a small splash */
  var mouthX=(WASH.outlet?WASH.outlet.x:I.x), mouthY=WH-GEO.WALL-(WASH.outlet&&WASH.outlet.boxH||15);
  ctx.save();ctx.strokeStyle="rgba(200,230,250,0.92)";ctx.lineWidth=Math.max(2,ws(2.8));ctx.lineCap="round";
  for(i=0;i<3;i++){
    ctx.globalAlpha=0.85-i*0.2;
    ctx.lineWidth=Math.max(1.6,ws(3.0-i*0.6));
    ctx.beginPath();ctx.moveTo(wx(mouthX-1.6+i*1.5),wy(mouthY-1.2));ctx.lineTo(wx(mouthX-2.2+i*1.7+((ANIM_F+i)%3)*0.45),wy(L.y+L.ry*0.35));ctx.stroke();
  }
  ctx.restore();
  spl=1.0+0.4*((ANIM_F%4)/3);
  ctx.globalAlpha=0.55;oval(wx(mouthX),wy(L.y+L.ry*0.55),ws(8*spl),ws(3.6*spl),"#d8eefc");
  ctx.globalAlpha=0.35;oval(wx(mouthX+3.4),wy(L.y+L.ry*0.4),ws(3.4),ws(1.7),"#eef8ff");
  ctx.save();ctx.strokeStyle="rgba(210,236,255,0.7)";ctx.lineWidth=Math.max(1,ws(1.15));
  for(i=0;i<3;i++){
    ph=(ANIM_T*0.85+i/3)%1;ctx.globalAlpha=0.5*(1-ph);
    ctx.beginPath();ctx.ellipse(wx(mouthX),wy(L.y+L.ry*0.55),ws(5+ph*16),ws(2.4+ph*8),0,0,Math.PI*2);ctx.stroke();
  }
  ctx.restore();
  for(i=0;i<5;i++){
    ph=(ANIM_T*1.1+i*0.17)%1;drop=4+ph*9;
    ctx.globalAlpha=0.55*(1-ph);
    oval(wx(mouthX+Math.cos(i*1.4)*drop*0.55),wy(L.y+L.ry*0.55-ph*5+Math.sin(i*1.7)*drop*0.2),ws(1.3),ws(1.0),"#e8f6ff");
  }
  ctx.globalAlpha=1;
  /* water runs straight into the square ship opening */
  var hw=(h.w||20)/2,hh=(h.h||16)/2;
  ctx.save();ctx.strokeStyle="rgba(160,210,240,0.8)";ctx.lineWidth=Math.max(1.5,ws(2.3));ctx.lineCap="round";
  for(i=0;i<3;i++){
    ctx.globalAlpha=0.72-i*0.18;
    ctx.beginPath();ctx.moveTo(wx(h.x-3+i*1.4),wy(h.y+hh+1));ctx.lineTo(wx(h.x-2+i*1.2),wy(h.y-hh*0.2+((ANIM_F+i)%4)*0.3));ctx.stroke();
  }
  ctx.restore();ctx.globalAlpha=1;
  var w=sim.s.wash,s;
  if(w&&w.splash){for(i=0;i<w.splash.length;i++){s=w.splash[i];if(sim.s.t-s.t>0.8)continue;
    ctx.globalAlpha=Math.max(0,1-(sim.s.t-s.t)/0.8);oval(wx(s.x),wy(s.y),ws(4+(sim.s.t-s.t)*8),ws(2.5+(sim.s.t-s.t)*5),"#d0e8f8");ctx.globalAlpha=1;}}
}

function drawWashPots(){
  var w=sim.s.wash,i,p,bulk,P=WASH.pile,n,j,ang,r,sz=peelSz();
  if(!w)return;
  /* 0.4.8: old dry-pile rendering stays in the file, hidden (t1191) */
  if(WASH.showDryPile){
    bulk=w.bulk|0;
    n=Math.min(bulk,80);
    for(j=0;j<n;j++){ang=srng(j*3)*6.283;r=Math.sqrt(srng(j*7))*P.rz*0.62;potato(wx(P.cx+Math.cos(ang)*r*0.9),wy(P.cy+Math.sin(ang)*r*0.68),Math.max(2.6,sz*0.92),true,j%2===0,0,null);}
  }
  drawCanalPots();
}
function heapVisN(w){
  var live=0,i,p,cap=(PPSim.HEAP_VIS||36)+(PPSim.HEAP_SPILL||24);
  if(!w)return 0;
  for(i=0;i<(w.pots||[]).length;i++){p=w.pots[i];if(p&&!p.onStreet&&PPSim.inLanding&&PPSim.inLanding(p.x,p.y))live++;}
  return Math.min(cap,live+(w.bulk|0));
}
/* build a rising, layered mound (back-to-front). layer 0 sits in the water; the middle lifts. */
var _heapCache=null,_heapCacheN=-1;
function buildBasinHeapSprites(){
  var w=sim.s.wash,L=WASH.land,H,n,caps,i,t,c,j,ang,u,r,sc,base,hx,hy,lift,shade,out=[],bobN=0;
  if(!w)return out;
  n=heapVisN(w);
  if(_heapCache&&_heapCacheN===n)return _heapCache;
  H=PPSim.heapCenter?PPSim.heapCenter():{x:L.x,y:L.y+L.ry*0.34};
  if(n<=0){_heapCache=out;_heapCacheN=0;return out;}
  /* cone of layers so a small heap still rises (not one flat ring) */
  var nLayers=n<=2?1:n<=5?2:n<=11?3:n<=20?4:n<=32?5:n<=48?6:7,weights=[],sumW=0,acc=0,wts;
  for(i=0;i<nLayers;i++){wts=Math.pow(0.60,i);weights.push(wts);sumW+=wts;}
  caps=[];acc=0;
  for(i=0;i<nLayers;i++){
    c=(i===nLayers-1)?(n-acc):Math.max(1,Math.round(n*weights[i]/sumW));
    if(acc+c>n)c=n-acc;
    if(c>0){caps.push(c);acc+=c;}
    if(acc>=n)break;
  }
  base=0.30+0.52*Math.min(1,n/44);
  for(t=0;t<caps.length;t++){
    sc=1-t*0.14;
    for(j=0;j<caps[t];j++){
      ang=(j+0.37)*2.399963+t*0.55;
      u=Math.sqrt((j+0.5)/Math.max(caps[t],1));
      r=u*sc*base*(0.52+0.48*Math.min(1,caps[t]/16));
      hx=H.x+Math.cos(ang)*L.rx*r;
      hy=H.y+Math.sin(ang)*L.ry*r*0.95;
      lift=t*2.05+(1-u)*0.5;
      /* NW faces catch the light; SE faces sit in shade so the mound reads as height */
      shade=0.70+0.22*t/Math.max(1,caps.length-1)+0.16*(-Math.cos(ang)*0.35-Math.sin(ang)*0.65);
      shade=Math.max(0.58,Math.min(1.18,shade));
      out.push({x:hx,y:hy,lift:lift,t:t,r:u,ang:ang,shade:shade,flip:((t*13+j)*7)%2===0,bob:false,sz:1-0.04*u});
    }
  }
  /* a few of the outermost base potatoes bob in the water */
  out.sort(function(a,b){return (b.t===0&&a.t!==0)?-1:(a.t===0&&b.t!==0)?1:b.r-a.r;});
  for(i=0;i<out.length&&bobN<Math.min(5,Math.max(2,Math.floor(n/8)));i++){
    if(out[i].t===0&&out[i].r>0.62){out[i].bob=true;bobN++;}
  }
  out.sort(function(a,b){return a.y!==b.y?a.y-b.y:(a.lift-b.lift);});
  _heapCache=out;_heapCacheN=n;return out;
}
function peeledShade(f){return [shadeHex("#a88830",f),shadeHex("#c8a848",f),shadeHex("#e8c868",f),shadeHex("#f0d890",f)];}
function drawBasinHeapBase(){
  var w=sim.s.wash,L=WASH.land,H,spr,i,n,sz=peelSz(),bob,pal,sh;
  if(!w)return;
  H=PPSim.heapCenter?PPSim.heapCenter():{x:L.x,y:L.y+L.ry*0.34};
  spr=buildBasinHeapSprites();n=spr.length;
  if(n<=0)return;
  /* contact shadow under the mound — grows with heap height */
  sh=0.55+0.35*Math.min(1,n/48);
  ctx.globalAlpha=0.34+0.16*Math.min(1,n/40);
  oval(wx(H.x)+ws(1.6),wy(H.y)+ws(3.2),ws(L.rx*sh),ws(L.ry*sh*0.88),"#061018");
  ctx.globalAlpha=0.22;oval(wx(H.x)+ws(2.4),wy(H.y)+ws(4.2),ws(L.rx*sh*0.62),ws(L.ry*sh*0.55),"#040c12");
  ctx.globalAlpha=1;
  for(i=0;i<spr.length;i++){
    if(spr[i].t>0)continue;
    bob=spr[i].bob?Math.sin(ANIM_T*2.3+spr[i].ang)*0.55:0;
    pal=peeledShade(spr[i].shade*0.92);
    potato(wx(spr[i].x),wy(spr[i].y)+ws(0.55+bob),Math.max(2.5,sz*spr[i].sz),true,spr[i].flip,0,pal);
  }
}
function drawBasinHeapTop(){
  var spr=buildBasinHeapSprites(),i,sz=peelSz(),pal;
  for(i=0;i<spr.length;i++){
    if(spr[i].t<=0)continue;
    pal=peeledShade(spr[i].shade);
    potato(wx(spr[i].x),wy(spr[i].y)-ws(spr[i].lift),Math.max(2.5,sz*spr[i].sz),true,spr[i].flip,0,pal);
  }
}
function drawBasinWaterFilm(){
  var L=WASH.land;
  /* a light surface film around the base of the heap; the peak sits above it */
  ctx.save();
  ctx.globalAlpha=0.16;oval(wx(L.x),wy(L.y)+ws(1),ws(L.rx-1.0),ws(L.ry-1.2),"#165a7c");
  ctx.globalAlpha=0.12;oval(wx(L.x)-ws(8),wy(L.y)-ws(6),ws(16),ws(9),"#d4eefc");
  ctx.globalAlpha=0.08;oval(wx(L.x)+ws(2),wy(L.y)+ws(5),ws(L.rx-7),ws(L.ry-9),"#0c283c");
  ctx.restore();ctx.globalAlpha=1;
}
function drawHeapLandSplash(){
  var w=sim.s.wash,H,L=WASH.land,i,s,ph,age,n,lift,px,py;
  if(!w)return;
  H=PPSim.heapCenter?PPSim.heapCenter():{x:L.x,y:L.y+L.ry*0.34};
  n=heapVisN(w);
  lift=Math.min(7,Math.max(1,Math.ceil(Math.sqrt(n))))*1.85;
  px=wx(H.x);py=wy(H.y)-ws(lift*0.72);
  if(w.heapSplash){
    for(i=0;i<w.heapSplash.length;i++){
      s=w.heapSplash[i];age=sim.s.t-s.t;if(age<0||age>0.7)continue;
      ph=age/0.7;
      ctx.save();ctx.strokeStyle="rgba(210,236,255,"+(0.7*(1-ph))+")";ctx.lineWidth=Math.max(1.1,ws(1.3));
      ctx.beginPath();ctx.ellipse(px,py,ws(3+ph*11),ws(1.6+ph*5.5),0,0,Math.PI*2);ctx.stroke();
      ctx.restore();
    }
  }
  ctx.globalAlpha=1;
}
function drawCanalPots(){
  var w=sim.s.wash,i,p,sz=peelSz();
  if(!w)return;
  for(i=0;i<(w.pots||[]).length;i++){
    p=w.pots[i];if(!p)continue;
    if(!p.onStreet&&PPSim.inLanding&&PPSim.inLanding(p.x,p.y))continue;
    potato(wx(p.x),wy(p.y),sz,true,i%2===0,p.sloppy?3:0,null);
  }
}
function drawWashScene(now){
  drawWashWater();
  drawBasinHeapBase();
  drawBasinWaterFilm();
  drawBasinHeapTop();
  drawHeapLandSplash();
  drawWashOutlet();
  drawHoleStatic();
  drawCanalPots();
  drawDuckWash();
  if(sim.s.g.where==="wash")drawGuy(now);
  drawShipAnim(now);
}

function drawStatic(){drawFloor();drawWalls();
  if(viewIsWash()){drawWashStatic();return;}
  /* hidden props (0.2.1 t1027, still hidden): drawPipes drawShelf drawToolRack drawMachinePad x3 drawDrain drawPeelBin drawBucket drawSack x4 drawCrate x3 drawLamp; 0.3 also hides drawCentreStripe and the old drawChuteBase/drawCooler/drawMat/drawTable */
  drawPileBay();drawPileShadow();drawDoor();   /* 0.4.2: the wall door first, so furniture pushed against the back wall sits in front of it */
  drawRugs04();   /* 0.4.10: carpets lie on the floor, under every piece of furniture (static layer) */
  drawBedR(drawBed);drawRectR(GEO.table,drawTable2);drawRectR(GEO.cooler,drawCooler2);drawStool();drawReturnChute();}
function ensureStatic(){if(staticLayer&&staticLayer.width===cv.width&&staticLayer.height===cv.height)return;drawStatic();var copy=document.createElement("canvas");copy.width=cv.width;copy.height=cv.height;var g=copy.getContext("2d");g.imageSmoothingEnabled=false;g.drawImage(cv,0,0);staticLayer=copy;}

/* ---------- the guy: 0.3.1 slimmer Papa, Swarm hybrid (DPR vectors, flat shading, 1px outline). True top-down, crown + arms only (mock 0.1b look lock). ---------- */
function M(dx,dy){switch(GD){case 1:return[GX-dy,GY+dx];case 2:return[GX-dx,GY-dy];case 3:return[GX+dy,GY-dx];default:return[GX+dx,GY+dy];}}
function O(dx,dy,rw,rh,c){var p=M(dx,dy);if(GD&1)oval(p[0],p[1],rh,rw,c);else oval(p[0],p[1],rw,rh,c);}
function Oout(dx,dy,rw,rh,c,out){var p=M(dx,dy);if(GD&1)disc(p[0],p[1],rh,rw,c,out||OUT);else disc(p[0],p[1],rw,rh,c,out||OUT);}
function limb(x0,y0,x1,y1,x2,y2,w){function seg(a,b,c2,d,ww,col,out){var p0=M(a,b),p1=M(c2,d);
    ctx.lineCap="round";ctx.lineJoin="round";
    ctx.strokeStyle=out||"#5a3a22";ctx.lineWidth=ww+1.3;ctx.beginPath();ctx.moveTo(p0[0],p0[1]);ctx.lineTo(p1[0],p1[1]);ctx.stroke();
    ctx.strokeStyle=col;ctx.lineWidth=ww;ctx.beginPath();ctx.moveTo(p0[0],p0[1]);ctx.lineTo(p1[0],p1[1]);ctx.stroke();}
  seg(x0,y0,x1,y1,w,"#c4a070","#5a3a22");if(x2!=null){seg(x1,y1,x2,y2,w,"#c4a070","#5a3a22");seg((x1+x2)/2,(y1+y2)/2,x2,y2,Math.max(0.8,w-0.5),"#d8b888","#5a3a22");}}
function hand(x,y,hw,fx,fy){if(fx==null)fx=0;if(fy==null)fy=0;
  /* small proportional palm + 3 fingers, skin with a darker outline */
  Oout(x,y,hw,hw*0.82,"#c4a070","#5a3a22");O(x-hw*0.18,y-hw*0.18,hw*0.38,hw*0.3,"#d8b888");
  var fl=hw*1.15,fw=Math.max(0.35,hw*0.32);
  for(var i=-1;i<=1;i++){var px=x+fx*fl+(-fy)*i*(hw*0.9),py=y+fy*fl+fx*i*(hw*0.9);
    Oout(px,py,fw,fw,"#d0a878","#5a3a22");}}
function drawCrown(useO,x,y,hr,u){
  /* hair cap, visible part, fringe, tucked ears, soft shading — no face. useO: local/rotated (standing). else absolute (sleeper). */
  function P(dx,dy,rw,rh,c,ol){if(useO){if(ol===false)O(x+dx,y+dy,rw,rh,c);else Oout(x+dx,y+dy,rw,rh,c,OUT);}else{if(ol===false)oval(x+dx,y+dy,rw,rh,c);else disc(x+dx,y+dy,rw,rh,c,OUT);}}
  P(0,0.4,hr+0.7,hr+0.35,"#2a2018");P(0,0.15,hr-0.15,hr-0.35,"#3a2a20",false);P(-hr*0.22,-hr*0.06,hr*0.55,hr*0.48,"#4a3828",false);
  P(-hr*0.28,-hr*0.18,Math.max(0.8,hr*0.42),Math.max(0.6,hr*0.28),"#5a4630",false);
  P(-hr*0.18,-hr*0.28,Math.max(0.5,hr*0.2),Math.max(0.4,hr*0.14),"#8a7860",false);
  /* hair part */
  P(-hr*0.12,-hr*0.12,Math.max(0.35,hr*0.08),Math.max(1.0,hr*0.55),"#6a5640",false);
  /* fringe along the north hairline */
  P(-hr*0.45,-hr+0.55,Math.max(0.6,hr*0.18),Math.max(0.5,hr*0.14),"#2a2018",false);
  P(-hr*0.05,-hr+0.35,Math.max(0.7,hr*0.22),Math.max(0.5,hr*0.13),"#3a2a20",false);
  P(hr*0.38,-hr+0.55,Math.max(0.55,hr*0.16),Math.max(0.5,hr*0.13),"#2a2018",false);
  P(hr*0.12,-hr+0.42,Math.max(0.45,hr*0.12),Math.max(0.4,hr*0.1),"#4a3828",false);
  /* tucked ears — defined rim + inner skin */
  var ear=Math.max(0.9,1.05*u);
  P(-hr+0.1,hr*0.12,ear,ear*0.92,"#8a6840");P(-hr+0.1,hr*0.12,ear*0.55,ear*0.55,"#c4a070",false);
  P(hr-0.1,hr*0.12,ear,ear*0.92,"#8a6840");P(hr-0.1,hr*0.12,ear*0.55,ear*0.55,"#c4a070",false);
  P(hr*0.32,hr*0.2,Math.max(0.35,hr*0.08),Math.max(0.35,hr*0.08),"#2a2018",false);
  P(-hr*0.42,hr*0.28,Math.max(0.35,hr*0.08),Math.max(0.35,hr*0.08),"#1a1410",false);
}
function drawGuy(now){
  var g=sim.s.g,a=g.act||{t:"idle"};
  if((viewIsWash()&&g.where!=="wash")||(!viewIsWash()&&g.where==="wash"))return;
  if(g.where==="wash"){GX=wx(g.wx);GY=wy(g.wy);}else{GX=wx(g.x*RW);GY=wy(g.y*RH);}GD=g.dir|0;
  /* slimmer than 0.3, a hair larger than the too-tiny 0.3.1 so detail reads; sizes in CSS px via k */
  var u=k*0.82;
  var hr=6.4*u,shW=14.2*u,shH=6.0*u;
  var breath=0;
  if(a.t==="idle")breath=[0,0.7,1.35,0.5][ANIM_F]*u;
  shH+=breath*0.5;
  var shY=hr+Math.max(1.4,shH*0.40)+breath*0.25,armW=1.55*u,workY=-hr-4.0*u;
  var armX=shW*0.40,armRootY=shY-shH*0.42,hw=1.20*u,sl=2.10*u;
  if(a.t==="nap"){drawBedR(function(){drawSleeper(now,hr,shW,shH,false,u);});}
  else if(a.t==="lazynap"){drawSleeper(now,hr,shW,shH,true,u);}
  else if(a.t==="watch"){var tvp=itemXY("tvArmchair");rotWrap(tvp.x,tvp.y,tvp.r,function(){drawSitter(now,u);});}
  else{
    var sp=M(0,shY+1.2);softShadow(sp[0],sp[1],(GD&1?shH*0.7:shW*0.52),(GD&1?shW*0.52:shH*0.7));
    /* tapered shoulders + apron, strap, 1px outline */
    Oout(0,shY+0.25,shW/2+0.15,shH/2+0.45,"#2a4a62");
    O(0,shY-0.15,shW/2-1.0,shH/2-0.25,"#3a6a8a");
    O(-0.4,shY-0.7,Math.max(1.2,shW/2-2.4),Math.max(1.0,shH/2-1.6),"#5a8aaa");
    O(-0.9,shY-1.1,Math.max(0.9,shW/2-3.6),Math.max(0.7,shH/2-2.2),"#7aa8c0");
    /* apron neck strap */
    Oout(0,shY-shH*0.42,Math.max(0.9,shW*0.12),0.85,"#2a4a62");O(0,shY-shH*0.42,Math.max(0.55,shW*0.08),0.45,"#c8d0a8");
    Oout(-armX,armRootY,sl,sl-0.15,"#2a4a62");O(-armX,armRootY,sl-0.45,sl-0.6,"#4a7a9a");
    Oout(armX,armRootY,sl,sl-0.15,"#2a4a62");O(armX,armRootY,sl-0.45,sl-0.6,"#5a8aaa");
    drawCrown(true,0,0,hr,u);
    var t=ANIM_T;
    if(a.t==="peel"){
      var stroke=Math.sin(t*(g.lazy?5:9)*(sim.spd()))*2.4*u,potX=-1.2*u,lH=potX+2.2*u,rH=potX+5.4*u+stroke;
      limb(-armX,armRootY-1,-armX-3.2*u,(armRootY+workY)/2,lH,workY,armW);
      limb(armX,armRootY-1,armX+3.2*u,(armRootY+workY)/2,rH,workY+stroke*0.3,armW);
      hand(lH,workY,hw,0.35,-0.15);hand(rH,workY+stroke*0.3,hw,0.55,0);
      var pp=M(potX,workY-0.4*u);var pr=g.peel;if(g.sack&&g.sack.n>1)pr=(g.peel*g.sack.n)%1;potato(pp[0],pp[1],Math.max(3.2,4.6*u),pr>0.55,(ANIM_F%2)===0,pr>0.55?Math.round((1-pr)*10):0);
      var kb=M(rH-6.8*u+2,workY-1),kh=M(rH,workY-1);
      if(GD===0){R(kh[0],kh[1],Math.max(2.4,3.4*u),Math.max(1.4,1.7*u),"#3a2a20");R(kb[0],kb[1],Math.max(4.4,6.4*u),Math.max(1.3,1.5*u),"#c8d0d8");R(kb[0],kb[1],Math.max(4.4,6.4*u),0.7,"#f0f4f8");}
    }else if(a.t==="eat"){
      var bite=(ANIM_F>=2),mY=bite?-hr+1:workY+2;
      limb(-armX,armRootY-1,-armX-3*u,(armRootY+workY)/2,-2*u,mY,armW);
      limb(armX,armRootY-1,armX+3*u,(armRootY+workY)/2+2,3*u,workY+3,armW);
      hand(-2*u,mY,hw,0,-0.8);hand(3*u,workY+3,hw,0,0.8);
      var fp=M(-2*u,mY-1);R(fp[0]-2,fp[1]-1,4,3,"#e8c070");R(fp[0]-2,fp[1]-1,4,1,"#c08040");
    }else if(a.t==="sweep"){
      var sw2=Math.sin(t*7.5)*3.4*u,hx0=-1.6*u+sw2*0.35,hy0=workY+2.5*u;
      limb(-armX,armRootY-1,-armX-2.6*u,(armRootY+hy0)/2,hx0,hy0,armW);
      limb(armX,armRootY-1,armX+2.6*u,(armRootY+hy0)/2,hx0+3.4*u,hy0+1.2*u,armW);
      hand(hx0,hy0,hw,0.2,-0.8);hand(hx0+3.4*u,hy0+1.2*u,hw,0.2,-0.8);
      var tipY=workY-8*u,tipX=sw2*1.5;
      for(var bi=0;bi<=10;bi++){var bq=bi/10;Oout(hx0+(tipX-hx0)*bq,hy0+(tipY-hy0)*bq,0.55,0.55,"#8a6840");}
      Oout(tipX,tipY,Math.max(2.2,3.2*u),Math.max(1.1,1.4*u),"#5a4020");O(tipX,tipY-0.8,Math.max(2.0,3.0*u),Math.max(0.8,1.05*u),"#c8a860");
    }else if(a.t==="wash"){
      /* 0.4.2: the potatoes are dumped in the sink; both hands work in the basin */
      var sc2=Math.sin(t*8)*1.2*u,wyy=workY+1;
      limb(-armX,armRootY-1,-armX-2.4*u,(armRootY+wyy)/2,-2.2*u+sc2,wyy,armW);
      limb(armX,armRootY-1,armX+2.4*u,(armRootY+wyy)/2,2.2*u-sc2,wyy,armW);
      hand(-2.2*u+sc2,wyy,hw,0.3,-0.6);hand(2.2*u-sc2,wyy,hw,-0.3,-0.6);
    }else if(a.t==="drop"||g.hold){
      var nHold=g.held||1;
      var bob=a.t==="walk"?Math.sin(g.walkPh)*1:0,cy=nHold>1&&a.t!=="drop"?(shY-0.6*u):(workY+2+bob);
      limb(-armX,armRootY-1,-armX-2.6*u,(armRootY+cy)/2,-2*u,cy,armW);
      limb(armX,armRootY-1,armX+2.6*u,(armRootY+cy)/2,2*u,cy,armW);
      hand(-2.4*u,cy,hw,0.3,-0.4);hand(2.4*u,cy,hw,-0.3,-0.4);
      var cp=M(0,cy-1);
      if(a.t==="drop"){
        /* potato leaves the hands and rides onto the belt, always clear of the crown */
        var bx=wx(GEO.ship.x),by=wy(GEO.ship.lip+5.5),p0x=cp[0],p0y=cp[1],pr=Math.max(2.8,4.0*u);
        var need=hr+pr+3,d0=Math.hypot(p0x-GX,p0y-GY),sx=bx-GX,sy=by-GY,sn=Math.hypot(sx,sy)||1;
        if(d0<need){p0x=GX+sx/sn*need;p0y=GY+sy/sn*need;}
        var e=1-Math.pow(1-Math.min(1,a.e/Math.max(0.05,sim.dropTime())),1.5);
        potato(p0x+(bx-p0x)*e,p0y+(by-p0y)*e,pr,true,false,g.sloppy?3:0);
      }else{
        var nHold=g.held||1,pr=Math.max(2.8,4.0*u),peeled=g.hold==="peeled",spots=peeled&&g.sloppy?3:0;
        if(nHold<=1)potato(cp[0],cp[1],pr,peeled,false,spots);
        else{
          disc(cp[0],cp[1]+pr*0.35,pr*1.55,pr*1.7,"#6a4a28","#3a2810");
          oval(cp[0]-pr*0.15,cp[1]-pr*0.15,pr*0.9,pr*0.7,"#8a6840");
          for(var hi=0;hi<Math.min(nHold,4);hi++){
            var ox=(hi%2?1:-1)*pr*(0.42+(hi>1?0.08:0)),oy=(hi<2?-0.45:0.38)*pr;
            potato(cp[0]+ox,cp[1]+oy,pr*0.78,peeled,hi%2===1,spots);
          }
        }
      }
    }else{
      var sw=a.t==="walk"?Math.sin(g.walkPh)*5.4*u:(a.t==="idle"?[0,0.4,0,-0.35][ANIM_F]*u:0);
      var yL=shY-1+sw,yR=shY-1-sw,out= (a.t==="walk"?2.8:2.0)*u;
      var endYL=yL-(a.t==="walk"?4.2:3.0)*u,endYR=yR-(a.t==="walk"?4.2:3.0)*u;
      limb(-armX,armRootY,-armX-out,(armRootY+yL)/2,-armX-1*u,endYL,armW);
      limb(armX,armRootY,armX+out,(armRootY+yR)/2,armX+1*u,endYR,armW);
      hand(-armX-1*u,endYL,hw,0,sw>0?0.9:-0.9);hand(armX+1*u,endYR,hw,0,sw<0?0.9:-0.9);
      if(a.t==="grab"){var gp=M(0,workY+2);potato(gp[0],gp[1],Math.max(2.8,3.8*u),false,false);}
    }
  }
}
function sitWorld(){var tv=itemXY("tvArmchair");return {x:tv.x-8.2+2.6,y:tv.y+0.4};}
function drawSitter(now,u){
  /* Proper SIT in the armchair, facing the TV (east). Layout matches the approved close-tv look;
     crown uses the locked 0.3.1 head/hair/colors, drawn screen-space like the sleeper. */
  var sw=sitWorld(),px=wx(sw.x),py=wy(sw.y),su=k*0.70,sHr=4.8*su,sShN=6.4*su,sShE=4.6*su;
  GX=px;GY=py;GD=1;
  softShadow(px,py+ws(0.5),sShE*0.75,sShN*0.7);
  disc(px-ws(1.0),py,sShE/2+0.25,sShN/2+0.4,"#2a4a62",OUT);
  oval(px-ws(0.85),py-0.2,sShE/2-0.5,sShN/2-0.35,"#3a6a8a");
  oval(px-ws(1.05),py-0.7,Math.max(1.0,sShE/2-1.3),Math.max(0.8,sShN/2-1.1),"#5a8aaa");
  oval(px-ws(1.2),py-1.0,Math.max(0.7,sShE/2-1.8),Math.max(0.6,sShN/2-1.6),"#7aa8c0");
  disc(px-ws(0.15),py,Math.max(0.6,0.7*su),0.7,"#2a4a62",OUT);
  oval(px-ws(0.15),py,Math.max(0.4,0.45*su),0.4,"#c8d0a8");
  disc(px-ws(0.2),py-sShN*0.52,1.2*su,1.05*su,"#c4a070","#5a3a22");
  disc(px-ws(0.2),py+sShN*0.52,1.2*su,1.05*su,"#c4a070","#5a3a22");
  drawCrown(false,px+ws(2.2),py,sHr,su);
}
function drawSleeper(now,hr,shW,shH,lazy,u){
  /* lying in the full-size bed (or on the floor if lazy): only the head shows on the pillow, blanket covers the whole body up to the shoulders. No arms or legs outside the blanket. */
  var G=GEO.mat;
  var hx,hy;
  if(!lazy){hx=wx(G.x-G.w/2+5.4);hy=wy(G.y);}
  else{hx=GX-5;hy=GY;}
  var bodyLen=lazy?22*u:ws(G.w*0.74);
  var hrS=lazy?6.2*u:Math.min(ws(G.h*0.40),bodyLen*0.155);
  var blanketW=lazy?shW*0.78:ws(G.h*0.52);
  /* 4-frame gentle breath: the blanket mound rises and falls (~8 fps) */
  var breathe=[0,0.45,1.0,0.40][ANIM_F];
  var rise=breathe*Math.max(1.1,blanketW*0.10);
  var tx=hx+hrS+0.8, ty=hy;
  softShadow(tx+bodyLen*0.40,hy+1.6,bodyLen*0.52,blanketW*0.58);
  /* a hint of shoulders / apron at the neckline, tucked under the hem — not sticking out */
  disc(tx-0.2,ty,Math.max(1.6,hrS*0.55),blanketW*0.22,"#2a4a62","#1a1410");
  /* blanket from the shoulders to the foot of the bed, covering arms, torso, and legs */
  var bx=hx+hrS*0.62, by=ty-(blanketW*0.50+rise*0.35), bw=bodyLen*0.98, bh=blanketW+rise;
  blob(bx,by,bw,bh,bh*0.46,"#4a6aa8","#2a3058");
  /* folded hem at the shoulders (just under the head) */
  R(bx,by,2.4,bh,"#d8e0f0");
  R(bx+1.2,by+bh*0.12,1.2,bh*0.76,"#c8d4ec");
  /* soft folds; the chest highlight lifts with the breath */
  for(var i=1;i<=4;i++)R(bx+bw*(0.16+i*0.16),by+bh*0.20,1,bh*0.60,"#3a5a98");
  oval(bx+bw*0.34,ty-rise*0.45,bw*0.24,blanketW*0.16+rise*0.40,"#6a8ac8");
  oval(bx+bw*0.55,ty+rise*0.15,bw*0.18,blanketW*0.10+rise*0.15,"#3a5a98");
  /* crown on the pillow — the only part of him left uncovered */
  drawCrown(false,hx,hy,hrS,hrS/6.4);
  /* steam puffs + Zzz, 4 discrete frames (pale, not yellow peel-bits) */
  var zcol=lazy?"#d0d8e8":"#e8eef4";
  var frames=[
    [{x:-2,y:-hrS-4,s:0.7,a:0.9},{x:3,y:-hrS-9,s:0.9,a:0.55},{x:8,y:-hrS-14,s:1.1,a:0.25}],
    [{x:0,y:-hrS-6,s:0.8,a:0.8},{x:5,y:-hrS-11,s:1.0,a:0.45},{x:10,y:-hrS-16,s:1.15,a:0.2}],
    [{x:2,y:-hrS-8,s:0.9,a:0.65},{x:7,y:-hrS-13,s:1.1,a:0.35},{x:11,y:-hrS-17,s:0.7,a:0.15}],
    [{x:-1,y:-hrS-5,s:0.75,a:0.85},{x:4,y:-hrS-10,s:0.95,a:0.5},{x:9,y:-hrS-15,s:1.05,a:0.22}]
  ][ANIM_F];
  for(var i=0;i<frames.length;i++){var z=frames[i],zx=hx+z.x,zy=hy+z.y,sc=z.s*Math.max(1.8,u*2.4);
    ctx.globalAlpha=z.a;
    oval(zx+sc*3.4,zy-sc*0.8,sc*1.1,sc*0.8,"#d8e4f0");
    R(zx,zy,sc*3,sc*0.7,zcol);R(zx+sc*2.1,zy+sc*0.7,sc*0.7,sc*0.7,zcol);R(zx+sc,zy+sc*1.4,sc*0.7,sc*0.7,zcol);R(zx,zy+sc*2.1,sc*3,sc*0.7,zcol);}
  ctx.globalAlpha=1;
}

/* ---------- effects: peels hop off and land flat on the floor; sweep dust; shipping suction (Swarm port) ---------- */
var flights=[],dust=[],sucks=[],dustAcc=0,GX=0,GY=0,GD=0;
function M2(dx,dy){var g=sim.s.g;GX=wx(g.x*roomW);GY=wy(g.y*roomH);GD=g.dir|0;return M(dx,dy);}
function spawnPeel(slot){if(slot<0||slot>=MESSPOS.length||flights.length>60)return;
  var hr=Math.max(3,6*k*0.82),o=M2((0.8+Math.random()*2.4)*k*0.82,-hr-4.2*k*0.82),tp=MESSPOS[slot];
  flights.push({slot:slot,x0:o[0],y0:o[1],tx:wx(tp.x),ty:wy(tp.y),t:0,dur:0.42+Math.random()*0.26,q:tp.q,h:(4+Math.random()*3)*k});flying[slot]=true;messVer++;}
function tickFlights(dt){var np=sim.s.peels;for(var i=flights.length-1;i>=0;i--){var f=flights[i];f.t+=dt;
    if(f.t>=f.dur||f.slot>=np){delete flying[f.slot];flights.splice(i,1);messVer++;}}}
function drawFlights(){for(var i=0;i<flights.length;i++){var f=flights[i],p=Math.min(1,f.t/f.dur),e=1-(1-p)*(1-p);
    var gxp=f.x0+(f.tx-f.x0)*e,gyp=f.y0+(f.ty-f.y0)*e,z=Math.sin(p*Math.PI)*f.h;
    R(Math.round(gxp)-1,Math.round(gyp)+1,3,1,"rgba(40,30,16,0.32)");
    var sp=PEELSPR[(f.q+Math.floor(p*8))%12],cx=sp.cx||sp.cssW/2||3,cy=sp.cy||sp.cssH/2||2,cw=sp.cssW||6,ch=sp.cssH||5;
    ctx.imageSmoothingEnabled=false;ctx.drawImage(sp,gxp-cx,gyp-z-cy,cw,ch);}}
function tickDust(dt){var g=sim.s.g,a=g.act;
  if(a&&a.t==="sweep"&&a.e>C.sweepWind){var hr2=Math.max(5,Math.round(6*k));var sw=Math.sin(performance.now()/1000*7.5);var o2=M2(Math.round(sw*5*k),-hr2-Math.max(4,Math.round(14*k)));dustAcc+=dt*14;
    while(dustAcc>1){dustAcc-=1;if(dust.length<28)dust.push({x:o2[0]+(Math.random()*6-3),y:o2[1]+(Math.random()*4-2),vx:(Math.random()-0.5)*8,vy:-2-Math.random()*5,life:0.5});}}
  for(var i=dust.length-1;i>=0;i--){var d=dust[i];d.x+=d.vx*dt;d.y+=d.vy*dt;d.life-=dt;if(d.life<=0)dust.splice(i,1);}}
function drawDust(){for(var i=0;i<dust.length;i++){var d=dust[i];ctx.globalAlpha=Math.max(0,d.life*1.6);R(d.x,d.y,2,1,"#d8c898");}ctx.globalAlpha=1;}
/* shipping: potato rides the belt into the scanner, then Swarm suction (3 pulsing red rings + shrinking swirl) at the mouth / inside the box. */
var SUCK_T=0.75;
function pushSuck(sloppy){if(sucks.length<6)sucks.push({t:0,sl:!!sloppy});}
function tickSucks(dt){for(var i=sucks.length-1;i>=0;i--){sucks[i].t+=dt;if(sucks[i].t>=SUCK_T)sucks.splice(i,1);}}
function drawSucks(){var cx=wx(chute.cx),startY=wy(GEO.ship.lip+5.5),mouthY=wy(GEO.WALL+15.2),inY=wy(GEO.WALL+8);
  for(var i=0;i<sucks.length;i++){var s=sucks[i],p=s.t/SUCK_T,x=cx,y,sz,ride=0.55;
    if(p<ride){var e=p/ride;y=startY+(mouthY-startY)*e;sz=Math.max(3,ws(3.1));}
    else{var e=Math.pow((p-ride)/(1-ride),1.4);y=mouthY+(inY-mouthY)*e;sz=Math.max(2,Math.round(Math.max(3,ws(3.1))*(1-0.72*e)));
      var tt=performance.now()/1000,ringY=mouthY-ws(1);ctx.save();ctx.globalAlpha=(0.34+0.20*Math.sin(tt*20))*(1-e*0.65);ctx.strokeStyle="#ff3050";ctx.lineWidth=1;
      for(var q=0;q<3;q++){ctx.beginPath();ctx.arc(cx,ringY,ws(3.2)+((tt*16+q*5.4)%ws(10)),0,6.28);ctx.stroke();}ctx.restore();}
    potato(x,y,sz,true,i%2===1,s.sl?3:0);}
}
/* return chute: raw potatoes come OUT of the mouth (clipped inside the pipe), tumble and bounce, roll and settle onto their slot in the pile.
   The schedule (exit + rest times) comes from PPSim.spill(t0,n): the sim lands each potato at exactly the time drawn here. */
var RT=0,retLight=0;
/* where potato j of the batch is at time RT (canvas px): phase A it slides out of the mouth (clipped inside the pipe), phase B it bounces/rolls to its slot. Shared by the drawing and the test hook. */
function retPos(kk,sc,j,rt){var s=sim.s,mx=GEO.ret.mouthX,ex=sc.ex[j],ld=sc.ld[j],p=(rt-ex)/(ld-ex);if(p<0)return null;if(p>1)p=1;
  var idx=Math.min(MAXVIS-1,s.pile+(j-kk.landed)),tp=POS[idx],tx=wx(tp.x),ty=wy(tp.y),key=Math.round(kk.t0*100);
  var sy=GEO.ret.y+(srng(key+j*17)-0.5)*3.6,spx=wx(mx),spy=wy(sy);
  var pA=Math.min(1,p/0.18),pB=Math.min(1,Math.max(0,(p-0.18)/0.82)),bn=2+Math.floor(srng(key+j*31)*2.99),amp=(5+srng(j*7+Math.round(kk.t0*10))*5)*k;
  var x,y,z=0;
  if(pB<=0){x=spx+ws(4)-ws(13)*pA;y=spy;}
  else{var e=1-Math.pow(1-pB,2.3),bx=spx-ws(9);x=bx+(tx-bx)*e;y=spy+(ty-spy)*Math.pow(pB,0.85);z=Math.abs(Math.sin(pB*Math.PI*bn))*amp*Math.pow(1-pB,1.4);}
  return {x:x,y:y,z:z,p:p,inPipe:pB<=0,ex:ex,ld:ld,tx:tx,ty:ty,mouthX:spx,slot:idx};}
function drawReturn(){var s=sim.s,kk=s.suck;if(!kk)return;var sc=PPSim.spill(kk.t0,kk.n);retLight=0;
  for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);if(!q)break;
    if(RT-q.ex<0.3)retLight=1;
    ctx.fillStyle="rgba(0,0,0,0.30)";ctx.beginPath();ctx.ellipse(q.x,q.y+ws(2.2),ws(2.8),ws(1.3),0,0,6.28);ctx.fill();
    if(q.inPipe){ctx.save();ctx.beginPath();ctx.rect(0,0,q.mouthX-ws(1.2),H);ctx.clip();}
    potato(q.x,q.y-q.z,Math.max(3,ws(3.3)),false,Math.floor(q.p*9)%2===0,0,["#5a3418","#7a4c28","#9a6a34","#d89a54"]);
    if(q.inPipe)ctx.restore();}
  if(retLight){var my=wy(GEO.ret.y-GEO.ret.w/2-0.2);R(wx(GEO.ret.mouthX+8),my,2,1,"#40ff70");}}
function bindSprites(){
  if(!window.PPSprites04)return null;
  PPSprites04.bind({ctx:ctx,k:k,camX:camX,camY:camY,frame:ANIM_F,t:ANIM_T,wx:wx,wy:wy,ws:ws});
  return PPSprites04;
}
function itemXY(id){return sim.placeOf(id);}
function drawRugs04(){var S=bindSprites();if(!S)return;var ids=PPSim.RUGS,i;
  for(i=0;i<ids.length;i++){(function(id){if(!sim.placed(id))return;var p=itemXY(id);rotWrap(p.x,p.y,p.r,function(){S.draw(id,"on",p.x,p.y);});})(ids[i]);}}
function duckPos(t){var L=WASH.land,a=t*0.22;return {x:L.x+Math.cos(a)*L.rx*0.70,y:L.y+Math.sin(a)*L.ry*0.58+Math.sin(t*2.1)*0.35,dir:a+1.5708};}
function drawDuckWash(){if(!sim.duckOn())return;var S=bindSprites();if(!S)return;var d=duckPos(RT||0);S.draw("duck","on",d.x,d.y,{dir:d.dir});}
function drawWorkLine04(){
  var S=bindSprites();if(!S)return;
  var stC=sim.lineOn("conveyor")?"on":"off";
  if(sim.placed("conveyor"))S.drawConveyorRun(GEO.beltX,GEO.beltY0,GEO.beltY1,stC);
  if(sim.placed("suction"))S.draw("suction",sim.lineOn("suction")?"on":"off",GEO.suction.x,GEO.suction.y);
  if(sim.placed("autoPeeler")){var p=itemXY("autoPeeler");rotWrap(p.x,p.y,p.r,function(){S.draw("autoPeeler",sim.lineOn("peeler")?"on":"off",p.x,p.y,{bounds:{x0:GEO.WALL+1,y0:GEO.WALL+1,x1:RW-GEO.WALL-1,y1:RH-GEO.WALL-1}});});}
  if(sim.placed("outConveyor")){
    var st=sim.lineOn("outbelt")?"on":"off";
    S.drawConveyorRunH(GEO.outBeltY,GEO.outBeltX0,GEO.outBeltX1,st,{peeled:true,cap1:false,maxP:0.70});
    S.drawConveyorRun(GEO.shipBeltX,GEO.shipBeltY0,GEO.shipBeltY1,st,{peeled:true,cap0:false,cap1:false,minP:0.16,maxP:0.90});
  }
}
function drawItems04(){
  var S=bindSprites();if(!S)return;
  var g=sim.s.g,a=g.act,watching=a&&(a.t==="watch"||(a.t==="walk"&&a.then==="watch"));
  var watering=a&&(a.t==="water"||(a.t==="walk"&&a.then==="water"));
  var tuning=a&&(a.t==="tune"||(a.t==="walk"&&a.then==="tune"));
  var sweeping=a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"));
  var washing=a&&(a.t==="wash"||(a.t==="walk"&&a.then==="wash"));
  function st(id,onId){return sim.owned(id)?(sim.s.box[onId||id]>0?"on":"off"):null;}
  function RD(id,state,o){var p=itemXY(id);rotWrap(p.x,p.y,p.r,function(){S.draw(id,state,p.x,p.y,o);});}
  /* 0.4.10: carpets are in the static layer (under furniture); wall items, fan and shelf are drawn here */
  if(sim.placed("shelf"))RD("shelf","on",{n:Math.min(5,sim.s.food)});
  if(sim.placed("fan"))RD("fan","on",{t:ANIM_T});
  if(sim.placed("poster"))RD("poster","on");
  if(sim.placed("clock")){var ck=itemXY("clock"),tm=sim.clockTime();S.draw("clock","on",ck.x,ck.y,{h:tm.h,m:tm.m});}
  if(sim.placed("lamp"))RD("lamp",sim.s.box.lamp>0?"on":"off");
  if(sim.placed("radio"))RD("radio",tuning?"on":(sim.s.box.radio>0?"on":"off"));
  if(sim.placed("plant")){var dry=sim.s.decor&&sim.s.decor.plant>=70;RD("plant",dry?"off":"on");}
  if(sim.placed("tvArmchair"))RD("tvArmchair",sim.s.box.tv>0?"on":"off");
  if(sim.placed("sink")){RD("sink","on");
    if(a&&a.t==="wash"){/* 0.4.2: the load sits in the basin while he washes it */
      var sk=itemXY("sink"),nn=Math.min(4,Math.max(1,a.n||sim.heldN())),pr2=Math.max(2.2,ws(2.6)),wob=[0,0.5,0,-0.5][ANIM_F];
      for(var si=0;si<nn;si++){var ox2=(si%2?1:-1)*(nn>1?2.2:0),oy2=(si<2?-1:1.6)*(nn>2?1:0);potato(wx(sk.x+ox2)+wob,wy(sk.y+oy2-1),pr2,false,si%2===1);}
      ctx.globalAlpha=0.35;oval(wx(sk.x),wy(sk.y-0.5),ws(5),ws(3.2),"#9fd0ff");ctx.globalAlpha=1;}}
  /* 0.4.2: peeling from the sack: it sits on the floor beside him, raw ones in it until the load is done */
  if(g.sack&&a&&a.t==="peel"){var sx2=g.sack.x,sy2=g.sack.y,n2=g.sack.n|0,done=Math.min(n2,Math.floor((g.peel||0)*n2)),left=Math.max(0,n2-done-1);
    S.draw("carryBag",left>0?"carrying":"on",sx2,sy2);
    var pr3=Math.max(2.0,ws(2.2));for(var bi2=0;bi2<Math.min(3,left);bi2++)potato(wx(sx2-2+bi2*2),wy(sy2-3.2),pr3,false,bi2%2===1);
    for(var di=0;di<Math.min(3,done);di++)potato(wx(sx2-2+di*2),wy(sy2+4.6),pr3,true,di%2===1);}
  if(sim.equipped("betterPeeler")){var kids=PPSim.tableKids();S.draw("betterPeeler",a&&a.t==="peel"?"on":"off",kids.board.x1-2,kids.cy);}
  if(sim.placed("smallCooler"))RD("smallCooler",sim.s.food>0?"on":"off");
  if(sim.placed("basicCot"))RD("basicCot","off");
  /* carry bag is equipped on Papa (drawn with him when he holds potatoes); no leftover bag on the floor */
  if(sim.equipped("broomDustpan")&&sweeping){
    var sx=g.x*RW,sy=g.y*RH,ls=sim.lastSweep,tx=sx,ty=sy+6;
    if(ls&&ls.removed&&ls.removed[0]){tx=ls.removed[0].x;ty=ls.removed[0].y;}
    else{var cl=sim.nearestMess&&sim.nearestMess();if(cl){tx=cl.x;ty=cl.y;}}
    S.draw("broomDustpan","on",tx,ty);
  }
  if(editMode)drawEditOverlay();
}
function drawPeelerPeels(){
  var S=bindSprites();if(!S||!sim.placed("autoPeeler")||!sim.s.line)return;
  var b={x0:GEO.WALL+1,y0:GEO.WALL+1,x1:RW-GEO.WALL-1,y1:RH-GEO.WALL-1};
  var p=itemXY("autoPeeler");
  var peels=S.peelerPeelWorld(p.x,p.y,ANIM_F,b);
  for(var i=0;i<peels.length;i++)S.peelFlake(wx(peels[i].x),wy(peels[i].y),peels[i].ang,ws(peels[i].settled?1.7:2.0));
}
var EDIT_IDS=["table","cooler","stool","mat","sink","smallCooler","basicCot","plant","lamp","radio","rug","tvArmchair","autoPeeler","fan","shelf","clock","poster","kitchenMat","runner","roundRug"];
var WASH_EDIT_IDS=[]; /* 0.4.8: basin heap stays with the basin; dry pile is hidden, not draggable */
function editIds(){return viewIsWash()?WASH_EDIT_IDS:EDIT_IDS;}
function editRect(id){var c=sim.centerOf(id);if(!c)return null;if(id==="washPile"||id==="streetMouth")return sim.footOf(id,c.x,c.y,0);var f=sim.footOf(id,c.x,c.y,id==="table"?(GEO.table.r|0):id==="cooler"?(GEO.cooler.r|0):id==="mat"?(GEO.mat.r|0):(c.r|0));return f;}
function drawEditOverlay(){
  ctx.save();ctx.globalAlpha=0.9;
  var ids=editIds(),i,id,f;
  for(i=0;i<ids.length;i++){
    id=ids[i];
    if(!viewIsWash()&&["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    ctx.strokeStyle=dragId===id?"#ffe066":"#9fc0ff";ctx.lineWidth=dragId===id?2:1;
    ctx.strokeRect(wx(f.x0)+0.5,wy(f.y0)+0.5,Math.max(2,wx(f.x1)-wx(f.x0)-1),Math.max(2,wy(f.y1)-wy(f.y0)-1));
  }
  if(viewIsWash()){
    var h=WASH.hole,xx=wx(h.x),yy=wy(h.y),q=Math.max(3,ws(2.4));
    ctx.strokeStyle="#1a1010";ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(xx,yy,ws(h.r+2),ws(h.r),0,0,6.28);ctx.stroke();
    ctx.restore();
    ctx.font="700 10px Courier New,monospace";ctx.fillStyle="#ffe066";ctx.textAlign="left";
    ctx.fillText("EDITOR: the basin heap, machines, canal and ship opening stay put.",8,16);
    return;
  }
  var sp=SPOT.ship,xx=wx(sp.x),yy=wy(sp.y),q=Math.max(3,ws(2.4));ctx.strokeStyle="#ff8a5a";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(xx-q,yy-q);ctx.lineTo(xx+q,yy+q);ctx.moveTo(xx+q,yy-q);ctx.lineTo(xx-q,yy+q);ctx.stroke();
  ctx.restore();
  ctx.font="700 10px Courier New,monospace";ctx.fillStyle="#ffe066";ctx.textAlign="left";
  ctx.fillText("EDITOR: drag items, ROTATE turns the picked one.",8,16);
}
function worldFromEvent(e){
  var r=playRect||$("play").getBoundingClientRect();
  var sx=(e.clientX-r.left)/r.width*W, sy=(e.clientY-r.top)/r.height*H;
  return {x:sx/k+camX,y:sy/k+camY};
}
function hitEditItem(wx0,wy0){
  /* 0.4.3: a tap on the cooler body is the cooler, even if the seat's margin overlaps the cooler. Strict hits first, then the nearest centre. */
  var hits=[],i,id,f,m=3,strict,d,ids=editIds();
  for(i=0;i<ids.length;i++){
    id=ids[i];
    if(!viewIsWash()&&["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    if(wx0>=f.x0-m&&wx0<=f.x1+m&&wy0>=f.y0-m&&wy0<=f.y1+m){
      strict=wx0>=f.x0&&wx0<=f.x1&&wy0>=f.y0&&wy0<=f.y1;
      d=Math.hypot(wx0-(f.x0+f.x1)/2,wy0-(f.y0+f.y1)/2);
      hits.push({id:id,strict:strict,d:d});}
  }
  if(!hits.length)return null;
  var pool=[],best=null,bestD=1e9;
  for(i=0;i<hits.length;i++)if(hits[i].strict)pool.push(hits[i]);
  if(!pool.length)pool=hits;
  for(i=0;i<pool.length;i++)if(pool[i].d<bestD){bestD=pool[i].d;best=pool[i].id;}
  return best;
}
/* 0.4.2: tap anything in the room for its name and what it does (right HUD) */
var INFO={
  table:["PEEL TABLE","He stands at it and peels on the board. Works wherever you put it."],
  cooler:["FOOD COOLER","Holds the food cans. He stands at the cooler to eat. EAT WHEN HUNGER < or the EAT button sends him here."],
  stool:["SEAT","A seat. It is its own object — it does not move with the cooler, and he eats at the cooler, not here."],
  mat:["BED","NAP WHEN ENERGY < sends him here. He gets in from a free side."],
  sink:["SINK","He dumps the potatoes in it and washes them: +1c each. WASH BEFORE PEEL."],
  smallCooler:["SMALL COOLER","+2 food slots. Hums when stocked."],
  basicCot:["BASIC COT","Extra furniture. Naps still use the bed."],
  plant:["PLANT","Watered: energy drains 10% slower in the kitchen. Dries out; WATER WHEN DRY."],
  lamp:["LAMP","LAMP ON: peeling 8% faster."],
  radio:["RADIO","Music ON: energy drains 20% slower, he works 5% faster. Tap it (or RADIO) for stations and your own songs."],
  rug:["RUG","Carpet. Standing on it: hunger drains 20% slower."],
  tvArmchair:["TV + ARMCHAIR","TV ON + WATCH WHEN ENERGY < : he sits and gets energy back."],
  kitchenMat:["KITCHEN MAT","Carpet. Standing on it: energy drains 30% slower."],
  runner:["RUNNER RUG","Carpet. Walking on it: 15% faster."],
  roundRug:["ROUND BRAID RUG","Carpet. On it: grab, peel and drop 8% faster."],
  clock:function(){var t=sim.clockTime(),h=t.h%12||12;return ["WALL CLOCK","Shift time "+h+":"+(t.m<10?"0":"")+t.m+(t.h<12?" AM":" PM")+" (day "+t.day+"). Meal breaks 30% shorter."];},
  poster:["PAPA POSTER","Papa of the Month. AUTO-LAZY speed 70% (not 50%)."],
  fan:["FLOOR FAN","Peel mess slows him at most 15% (not 30%)."],
  shelf:["PANTRY SHELF","+2 food can storage."],
  duck:["RUBBER DUCK","Floats in the basin. The current pulls potatoes off the heap 25% faster."],
  autoPeeler:["AUTO-PEELER","Peels potatoes from the conveyor. AUTO-PEELER SPEED."],
  pile:["POTATO PILE","Raw potatoes. He grabs here. Fixed in place."],
  ship:["SHIP IN (X-ray)","He walks up to this machine and places each peeled potato on the belt. Unwashed pay 2c here. A sink-washed potato pays 3c. WASH or AUTO-WASH sends them through the scanner into the wash-room machine (3c at the ship opening). Fixed in place."],
  ret:["RETURN CHUTE","Shipped batches come back here raw. Fixed in place."],
  door:["METAL DOOR",""],
  pool:["WATER POOL","Hidden. The landing pool and canal replaced this small pool."],
  street:["CANAL","A recessed trench in the floor. It carries washed potatoes from the basin up the right wall to the ship hole (3c). WIDER CHANNEL makes the current faster."],
  streetMouth:["CHANNEL MOUTH","Hidden. The landing pool replaced this basin."],
  land:["LANDING BASIN","A stone-rimmed basin just past the wash-room scanner. Potatoes come out of that machine and stack into a heap in this water, with the middle rising. The current pulls them into the canal along the right wall."],
  inlet:["OUTLET SCANNER","The wash-room twin of the kitchen X-ray scanner. Potatoes come out of this machine into the basin. Fixed in place."],
  washOutlet:["OUTLET SCANNER","The wash-room twin of the kitchen X-ray scanner. Potatoes come out of this machine into the basin. Fixed in place."],
  hole:["SHIP OPENING","A square opening at the top-right. The canal runs straight into it. Washed potatoes ship through it at 3c and come back raw to the kitchen."],
  washPile:["BASIN HEAP","Peeled potatoes stack into a heap in the basin water under the wash-room scanner. The current slowly pulls them into the canal. The old dry pile is hidden. The basin stays put in EDIT."],
  washIn:["INTAKE","Hidden. Potatoes now come out the south inlet hole."],
  washOut:["SHIP OUT","Hidden. The hole in the wall replaced this north exit."],
  washCrate:["CRATES","Spare kitchen crates stacked against the wall."],
  washGrate:["FLOOR DRAIN","A metal grate in the floor."],
  washBucket:["MOP BUCKET","A mop and a bucket of water."],
  washShelf:["SHELF","A short shelf on the north wall."]};
function doorInfoText(){return sim.hasKey()?["METAL DOOR","OPEN. Tap to go to the wash room (short fade). Peeled potatoes come out a matching scanner at the bottom, pile up in the basin water, and a canal along the right wall pulls them to a ship opening."]:["METAL DOOR (LOCKED)","Buy a ROOM KEY in the SHOP to unlock it. Behind it is a wash room. The kitchen X-ray scanner sends peeled potatoes through the wall to a matching machine there."];}
function hitAny(x,y){
  if(viewIsWash()){
    var pl=WASH.pile,I=WASH.inlet,h=WASH.hole,L=WASH.land,up=sim.up?sim.up("channel"):0;
    if(editMode){var he=hitEditItem(x,y);if(he)return he;}
    if(sim.doorHit(x,y,"wash"))return "door";
    if(Math.hypot(x-h.x,y-h.y)<=(h.r||12)+6)return "hole";
    if(WASH.outlet){var ow=WASH.outlet.boxW||16,oh=WASH.outlet.boxH||15,oy0=WH-GEO.WALL-oh;
      if(x>=WASH.outlet.x-ow/2-2&&x<=WASH.outlet.x+ow/2+4&&y>=oy0-4&&y<=WH-GEO.WALL+2)return "washOutlet";}
    if(Math.hypot(x-I.x,y-I.y)<=I.r+6)return "inlet";
    if(sim.duckOn()){var dk=duckPos(RT||0);if(Math.hypot(x-dk.x,y-dk.y)<=6)return "duck";}
    if(PPSim.inLanding&&PPSim.inLanding(x,y))return "land";
    if(PPSim.inStreet(x,y,up))return "street";
    if(WASH.showDryPile&&Math.abs(x-pl.cx)<=pl.rx&&Math.abs(y-pl.cy)<=pl.rz)return "washPile";
    if(WASH.showProps){
      if(WASH.grate&&Math.abs(x-WASH.grate.x)<=WASH.grate.s/2+2&&Math.abs(y-WASH.grate.y)<=WASH.grate.s/2+2)return "washGrate";
      if(WASH.bucket&&Math.hypot(x-WASH.bucket.x,y-WASH.bucket.y)<=10)return "washBucket";
      if((WASH.crate&&Math.hypot(x-WASH.crate.x,y-WASH.crate.y)<=12)||(WASH.crate2&&Math.hypot(x-WASH.crate2.x,y-WASH.crate2.y)<=11))return "washCrate";
      if(WASH.shelf&&Math.abs(x-WASH.shelf.x)<=WASH.shelf.w/2&&Math.abs(y-WASH.shelf.y)<=8)return "washShelf";
    }
    return null;
  }
  var h=hitEditItem(x,y);if(h)return h;
  if(sim.doorHit(x,y,"kitchen"))return "door";
  var G=GEO.pile;if(Math.abs(x-G.cx)<=G.rx&&y>=G.base-G.rz-4&&y<=RH-GEO.WALL)return "pile";
  if(x>=GEO.ship.x-12&&x<=GEO.ship.x+14&&y>=GEO.WALL-2&&y<=GEO.ship.lip+8)return "ship";
  if(x>=GEO.ret.mouthX-3&&y>=GEO.ret.y-8&&y<=GEO.ret.y+8)return "ret";
  return null;}
var infoUntil=0,infoId=null;
function showInfo(id){var el=$("objInfo");if(!el)return;var d=id==="door"?doorInfoText():INFO[id];if(typeof d==="function")d=d();if(!d){el.className="off";infoId=null;return;}
  infoId=id;$("oiName").textContent=d[0];$("oiDesc").textContent=d[1];el.className="";infoUntil=performance.now()+(editMode?600000:5000);}
function tickInfo(){var el=$("objInfo");if(el&&infoId&&performance.now()>infoUntil){el.className="off";infoId=null;}}
function rotateSelected(){var btn=$("rotBtn");if(!dragId){if(btn)flashBtn(btn,"PICK ONE");return;}
  if(sim.rotateItem(dragId)){staticLayer=null;messLayer=null;messVer++;changed();showInfo(dragId);}else if(btn)flashBtn(btn,"NO ROOM");}
function flashBtn(btn,txt){var old=btn.getAttribute("data-label")||btn.textContent;btn.setAttribute("data-label",old);btn.textContent=txt;setTimeout(function(){btn.textContent=old;},700);}
function drawFade(){if(!fading&&fadeT<=0)return;var a=0;
  if(fading){if(fadeT<=1)a=Math.min(1,fadeT);else a=Math.max(0,2-fadeT);}
  if(a<=0)return;ctx.save();ctx.setTransform(DPR,0,0,DPR,0,0);ctx.globalAlpha=a;ctx.fillStyle="#0c1220";ctx.fillRect(0,0,W,H);ctx.restore();resetXform();}
function drawScene(now){if(W<2||H<2)return;tickAnim(now);ensureStatic();var s=sim.s;blitLayer(staticLayer);
  if(viewIsWash()){drawWashScene(now);}
  else{
    drawWorkLine04();
    drawShipChute();  /* 0.4.7: 0.4.4 X-ray scanner restored; drawKitchenDropHole stays hidden */
    renderMess(Math.min(s.peels,MESSVIS));blitLayer(messLayer);
    if(sim.owned("autoPeeler"))drawPeelerPeels();
    renderPile(Math.min(s.pile,MAXVIS));blitLayer(pileLayer);
    drawItems04();
    drawGuy(now);drawFlights();drawDust();drawShipAnim(now);drawCoolerHum();drawReturnRattle();drawSucks();drawReturn();
  }
  drawFade();}

/* ---------- HUD ---------- */
var $=function(id){return document.getElementById(id);};
var hud={};
function coinIcon(){var g=$("coinIco").getContext("2d");var r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};
  r(3,1,8,12,"#c4a020");r(4,0,6,14,"#c4a020");r(2,2,10,10,"#c4a020");r(4,1,6,12,"#ffe066");r(3,2,8,10,"#ffe066");r(5,2,4,10,"#fff3a0");r(4,3,6,8,"#fff3a0");r(6,5,2,5,"#c4a020");r(5,6,4,1,"#c4a020");
  var f=$("foodIco").getContext("2d");var q=function(x,y,w,h,c){f.fillStyle=c;f.fillRect(x,y,w,h);};
  q(1,5,12,7,"#5a3a20");q(2,6,10,5,"#c08040");q(2,4,10,2,"#e8c070");q(3,3,8,1,"#f5e0a8");q(4,7,2,2,"#7a4a20");q(8,8,2,1,"#7a4a20");
  var pl=$("peelIco").getContext("2d");var w=function(x,y,ww,h,c){pl.fillStyle=c;pl.fillRect(x,y,ww,h);};
  w(2,3,9,2,"#b08838");w(2,2,9,2,"#f5e0a8");w(10,4,2,4,"#e8c070");w(3,6,9,2,"#d4a04a");w(3,5,8,2,"#f5e0a8");w(2,8,2,3,"#e8c070");w(3,10,9,2,"#b08838");w(3,9,9,2,"#e8c070");}
function setText(id,v){if(hud[id]!==v){hud[id]=v;$(id).textContent=v;}}
var boxSnap="";
function messPct(){return Math.round((1-sim.messF())*100);}
function updateHud(){var s=sim.s;var bs="",ci;for(ci=0;ci<CMDS.length;ci++)bs+=s.box[CMDS[ci].id]+",";bs+=s.potCap+","+s.up.chute;if(bs!==boxSnap){boxSnap=bs;renderAll();}
  setText("coins",String(s.coins));setText("peels",String(s.peels));if($("level"))setText("level",s.level+" / 5");
  if($("washedN"))setText("washedN",String(s.stats.washedShip|0));if($("unwashedN"))setText("unwashedN",String(s.stats.unwashedShip|0));
  var mp=messPct();
  var pe=$("peelRow"),pc="food peels"+(mp>=22?" filthy":(mp>=8?" messy":""));if(hud.pc!==pc){hud.pc=pc;pe.className=pc;}
  var mt=mp>=1?"MESS: "+mp+"% SLOWER":"";if(hud.mt!==mt){hud.mt=mt;var me=$("mess");me.textContent=mt;me.className="mess"+(mp>=8?" on":"");}setText("food",s.food+(s.food>=sim.foodMax()?" MAX":""));
  $("foodRow").className="food"+(s.food<=0?" out":"");
  var h=Math.round(s.hunger),e=Math.round(s.energy);
  if(hud.h!==h){hud.h=h;$("hFill").style.transform="scaleX("+(h/100)+")";$("hPct").textContent=h+"%";$("hBar").className="bar hunger"+(h<20?" low":"");}
  if(hud.e!==e){hud.e=e;$("eFill").style.transform="scaleX("+(e/100)+")";$("ePct").textContent=e+"%";$("eBar").className="bar energy"+(e<20?" low":"");}
  var st=sim.stateName();if(hud.st!==st){hud.st=st;var els=document.querySelectorAll(".st");for(var i=0;i<els.length;i++)els[i].classList.toggle("on",els[i].getAttribute("data-s")===st);fitStates();}
  var a=s.g.act;setText("doing",a&&a.label?a.label:"");
  /* object labels carry live numbers */
  tagText("tagFood","FOOD x"+s.food);tagText("tagPot","POTATOES "+(PPSim.POT_LOCK||POTS[s.box.pot]));tagText("tagRet",s.chute>0?"RETURN "+s.chute+"/"+sim.chuteCap():"RETURN");
  var hasP=sim.owned("autoPeeler"),hasL=sim.owned("outConveyor"),hasS=sim.owned("sink"),hasT=sim.owned("tvArmchair");
  function tagOn(id,on){var el=$(id);if(!el)return;el.className="tag"+(on&&(performance.now()<labelsUntil)?" ":" off");}
  tagOn("tagPeeler",hasP);tagOn("tagLine",hasL);tagOn("tagSink",hasS);tagOn("tagTV",hasT);

  var can=s.coins>=Math.min(sim.price(),sim.potPrice()||9999)?" can":"";var sb=$("shopBtn");var sc2="shopb"+can;if(hud.sb!==sc2){hud.sb=sc2;sb.className=can?"can":"";}
  if(ovlMode){$("ovlCoins").textContent=ovlMode==="shop"?s.coins+"c":"";if(ovlDirty){ovlDirty=false;buildOvl();}}
  var rbn=$("radioBtn"),rown=sim.owned("radio");if(rbn&&hud.rown!==rown){hud.rown=rown;rbn.className=rown?"":"off";$("bar").className=rown?"r4":"";}
  radioSync();
  var nb=$("nowBtns");if(nb){var bts=nb.querySelectorAll("button"),bi,act,st;for(bi=0;bi<bts.length;bi++){act=(bts[bi].getAttribute("data-act")||"").slice(4);st=nowBtnState(act);bts[bi].className=st;}}
  updateHint();}
function tagText(id,t){var key="t"+id;if(hud[key]!==t){hud[key]=t;var el=$(id);el.textContent=t;if(playRect)placeTagsSoon();}}
var tagTimer=0;function placeTagsSoon(){if(tagTimer)return;tagTimer=setTimeout(function(){tagTimer=0;if(playRect)placeTags();},60);}
var hintShown="",migUntil=0;
function updateHint(){var s=sim.s,msg="";
  if(migrated&&performance.now()<migUntil)msg="Welcome back. Your "+migrated+" save was carried over ("+migrated+" itself is untouched).";
  else if(s.peels>=45&&s.box.clean===0&&s.t<7200)msg="The floor is a mess: he works "+messPct()+"% slower. Set CLEAN WHEN PEELS > to make him sweep.";
  else if(s.box.eat===0&&s.box.nap===0&&s.t<20)msg="Tap a box to unlock its slider. Set EAT and NAP or he goes lazy. HELP explains every box.";
  else if(s.box.eat>0&&s.food<=0&&s.hunger<s.box.eat)msg="Out of food! He's slacking. Open the SHOP (or set KEEP FOOD AT LEAST).";
  else if(s.g.lazy&&s.box.eat===0&&s.hunger<C.lazyLow)msg="Hungry and no EAT box set: he's going lazy.";
  else if(s.g.lazy&&s.box.nap===0&&s.energy<C.lazyLow)msg="Tired and no NAP box set: he naps wherever.";
  if(msg!==hintShown){hintShown=msg;var el=$("hint");if(msg){el.textContent=msg;el.className="";}else el.className="off";}}
function popCoin(v,sloppy){var el=document.createElement("div");el.className="pop";el.textContent="+"+v+"c"+(sloppy?" sloppy":"");
  var n=pops.length,col=n%3,row=(n/3)|0;
  var cx=viewIsWash()?WASH.hole.x-24:chute.cx,cy=viewIsWash()?WASH.hole.y+24:chute.lip+14;
  var x=(wx(cx)/W)*playRect.width+(col-1)*42,y=(wy(cy)/H)*playRect.height+row*22+(col===1?8:0);
  el.style.left=Math.round(x)+"px";el.style.top=Math.round(y)+"px";$("play").appendChild(el);pops.push({el:el,t:0,y:y,lift:20+col*8});}
function tickPops(dt){for(var i=pops.length-1;i>=0;i--){var p=pops[i];p.t+=dt;p.el.style.transform="translateY("+(-p.t*(p.lift||22))+"px)";p.el.style.opacity=String(Math.max(0,1-p.t/1.2));if(p.t>1.2){p.el.parentNode&&p.el.parentNode.removeChild(p.el);pops.splice(i,1);}}}

/* ---------- command panel: scroll-safe (Jay t1015) ----------
   Built from PPSim.COMMANDS, the same table the HELP screen reads, so the two can never drift apart.
   A slider is LOCKED until you tap its box (the box lights up). Vertical drags always scroll the panel and never move a slider.
   + and - always work (they act on a clean tap). SHOP / HELP also need a clean tap, so scrolling can't open them. A slide applies its value where the finger lifts. */
var cmd=$("cmd"),focusId=null;
function fmt(id,v){
  var c=null,i;for(i=0;i<CMDS.length;i++)if(CMDS[i].id===id)c=CMDS[i];
  if(c&&c.fmt==="onoff")return v>0?"ON":"OFF";
  if(c&&c.fmt==="speed")return (PPSim.SPEED_NAME||["OFF","SLOW","STEADY","FAST"])[v]||String(v);
  if(c&&c.fmt==="dry")return v>0?"> "+v:"OFF";
  if(id==="pace")return PACE[v]+" x"+SPD[v];
  if(id==="pot")return String(POTS[v]);
  if(id==="clean")return v>0?"> "+v:"OFF";
  if(id==="style")return STYLE[v].n+" x"+STYLE[v].sp;
  if(id==="wake")return v+"%";
  if(id==="autob")return v>0?">= "+v:"OFF";
  return v>0?"< "+v+"%":"OFF";}
function bmax(id){return id==="pot"?Math.max(1,sim.potMax()):BOX[id].max;}
function pct(id,v){var b=BOX[id];return (v-b.min)/(bmax(id)-b.min);}
var UNSET={eat:1,nap:1,clean:1,autob:1,suction:1,conveyor:1,apeeler:1,outbelt:1,lamp:1,radio:1,tv:1,watch:1,water:1,wash:1,awash:1};
function visCmds(){return sim.visibleCommands?sim.visibleCommands():CMDS;}
function nowBtnState(id){
  var s=sim.s,st="ok";
  if(id==="eat"&&s.food<=0)st="off";
  if(id==="clean"&&s.peels<=0)st="off";
  if(id==="wash"&&!sim.hasKey())st="need";
  if(s.g&&s.g.holdRepeat===id)st="hold";
  return st;}
function buildNowBtns(){var el=$("nowBtns");if(!el)return;var ids=[["eat","EAT"],["nap","NAP"],["clean","CLEAN"],["wash","WASH"],["work","WORK"]],h="",i,st;
  for(i=0;i<ids.length;i++){st=nowBtnState(ids[i][0]);h+='<button type="button" data-act="now:'+ids[i][0]+'" class="'+st+'">'+ids[i][1]+'</button>';}
  el.innerHTML=h;}
function flashNow(id,txt){var el=$("nowBtns")&&$("nowBtns").querySelector('[data-act="now:'+id+'"]');if(!el)return;var old=el.textContent;el.textContent=txt;setTimeout(function(){if(el)el.textContent=old;},700);}
function doNow(id){var r=sim.commandNow(id);if(r==="ok"){changed();return;}
  if(r==="nofood")flashNow("eat","NO FOOD");
  else if(r==="nokey")flashNow("wash","NEED KEY");
  else if(r==="none"&&id==="clean")flashNow("clean","NO PEELS");
  else if(r==="none"&&id==="wash")flashNow("wash","NONE");}
function buildPanel(){var h="",list=visCmds(),i,c;
  for(i=0;i<list.length;i++){c=list[i];
    h+='<div class="box" data-id="'+c.id+'"><button class="pm" data-d="1" aria-label="'+c.name+' up">+</button><div class="mid"><div class="top"><span class="nm">'+c.name.replace(/</g,"&lt;").replace(/>/g,"&gt;")+'</span><span class="lk"></span><span class="val"></span></div><div class="trk"><div class="ln"></div><div class="fill"></div><div class="kn"></div></div></div><button class="pm" data-d="-1" aria-label="'+c.name+' down">&minus;</button></div>';}
  $("boxes").innerHTML=h;buildNowBtns();}
function renderTicks(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),trk=el.querySelector(".trk"),b=BOX[id],mx=bmax(id),old=trk.querySelectorAll(".tk");for(var j=0;j<old.length;j++)trk.removeChild(old[j]);
  var n=Math.max(1,Math.round((mx-b.min)/b.step)),tn=Math.min(n,14);for(var i=0;i<=tn;i++){var t=document.createElement("i");t.className="tk";t.style.left=(i/tn*100)+"%";trk.appendChild(t);}}
function renderBox(id){var el=cmd.querySelector('.box[data-id="'+id+'"]'),v=sim.s.box[id],p=pct(id,v);
  el.querySelector(".kn").style.left=((1-p)*100)+"%";el.querySelector(".fill").style.width=(p*100)+"%";el.querySelector(".val").textContent=fmt(id,v);
  el.classList.toggle("unset",!!UNSET[id]&&v===0);el.classList.toggle("focus",focusId===id);el.querySelector(".lk").textContent=focusId===id?"<SLIDE>":"";
  var key=id==="pot"?"tk"+sim.potMax():"tk";if(el.getAttribute("data-tk")!==key){el.setAttribute("data-tk",key);renderTicks(id);}}
function renderAll(){var list=visCmds(),i,el;
  for(i=0;i<list.length;i++){el=cmd.querySelector('.box[data-id="'+list[i].id+'"]');if(el)renderBox(list[i].id);}}
function rebuildPanel(){buildPanel();renderAll();}

function setFocus(id){focusId=id;renderAll();}
buildPanel();
function changed(){renderAll();updateHud();saveGame();}
function valFromX(id,trk,clientX){var r=trk.getBoundingClientRect(),b=BOX[id];var q=(clientX-r.left)/r.width;q=Math.max(0,Math.min(1,q));return b.min+(1-q)*(bmax(id)-b.min);}
var G=null; /* the active gesture */
var SLOP=8;
function doAct(a){
  if(a==="shop")openOvl("shop");else if(a==="help")openOvl("help");else if(a==="inv")openOvl("inv");else if(a==="close")closeOvl();
  else if(a==="book:next")flipBook(1);else if(a==="book:prev")flipBook(-1);
  else if(a==="editor")toggleEditor();
  else if(a==="putaway")putAwaySelected();
  else if(a==="rotate")rotateSelected();
  else if(a==="zoom:in")zoomBy(1);else if(a==="zoom:out")zoomBy(-1);
  else if(a==="pan:up")panBy(0,-18);else if(a==="pan:down")panBy(0,18);
  else if(a==="pan:left")panBy(-14,0);else if(a==="pan:right")panBy(14,0);
  else if(a==="pan:reset")resetView();
  else if(a&&a.indexOf("now:")===0)doNow(a.slice(4));
  else if(a&&a.indexOf("buy:")===0)shopBuy(a.slice(4));
  else if(a&&a.indexOf("equip:")===0){sim.equip(a.slice(6));if(ovlMode==="inv")ovlDirty=true;changed();rebuildTray();}
  else if(a&&a.indexOf("unequip:")===0){sim.unequip(a.slice(8));if(ovlMode==="inv")ovlDirty=true;changed();rebuildTray();}
  else if(a&&a.indexOf("return:")===0){sim.unplace(a.slice(7));staticLayer=null;if(ovlMode==="inv")ovlDirty=true;changed();rebuildTray();layout();}
  else if(a&&a.indexOf("toedit:")===0){closeOvl();if(!editMode)toggleEditor();}
  else if(a==="radio"){radioWake();openOvl("radio");}
  else if(a&&a.indexOf("radio:")===0)radioAct(a.slice(6));
  else if(a&&a.indexOf("duck:")===0){var dr=sim.putDuck(a.slice(5)==="in");if(dr==="nokey"){var db=ovl.querySelector('[data-act="'+a+'"]');if(db)db.innerHTML="NEED<br>KEY";setTimeout(function(){ovlDirty=true;},800);}else ovlDirty=true;changed();}}
function toggleEditor(){
  editMode=!editMode;dragId=null;if(!editMode)showInfo(null);
  var b=$("editBtn"),pl=$("play"),app=$("app");
  if(b)b.classList.toggle("on",editMode);
  if(pl)pl.classList.toggle("editing",editMode);
  if(app)app.classList.toggle("editing",editMode);
  rebuildTray();
  layout();
}
function rebuildTray(){
  var el=$("invChips"),away=$("putAway");if(!el)return;
  var list=sim.trayList(),h="",i;
  if(!list.length)h='<div class="invchip empty">No unplaced items. Buy in the SHOP, or PUT AWAY something already in the room.</div>';
  for(i=0;i<list.length;i++)h+='<button class="invchip" type="button" data-place="'+list[i].id+'">'+esc(list[i].name)+'<b>DRAG IN</b></button>';
  el.innerHTML=h;
  if(away)away.className=dragId&&PPSim.isPlaceable(dragId)&&sim.placed(dragId)?"on":"";
  var rb=$("rotBtn");if(rb)rb.className=(dragId&&dragId!=="washPile"&&dragId!=="streetMouth"&&!PPSim.isWall(dragId))?"on":"";
}
function putAwaySelected(){
  if(!dragId||!PPSim.isPlaceable(dragId)||!sim.placed(dragId))return;
  sim.unplace(dragId);dragId=null;staticLayer=null;messLayer=null;changed();rebuildTray();layout();
}

var holdT=null,holdOn=false,holdId=null;
function clearHoldTimer(){if(holdT){clearTimeout(holdT);holdT=null;}}
function stopHold(){clearHoldTimer();if(holdOn){holdOn=false;if(sim&&sim.setHold)sim.setHold(holdId,false);changed();}holdId=null;}
function armHold(id){clearHoldTimer();holdId=id;holdOn=false;
  holdT=setTimeout(function(){holdT=null;if(!G||G.mode)return;holdOn=true;if(sim&&sim.setHold)sim.setHold(id,true);changed();},380);}
cmd.addEventListener("pointerdown",function(e){if(G&&G.id!==e.pointerId)return;
  var t=e.target,box=t.closest?t.closest(".box"):null,pm=t.closest?t.closest(".pm"):null,trk=t.closest?t.closest(".trk"):null,btn=t.closest?t.closest("#bar button, #nowBtns button"):null;
  G={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:cmd.scrollTop,box:box,bid:box?box.getAttribute("data-id"):null,pm:pm,trk:trk,btn:btn,mode:null};
  if(pm)pm.classList.add("press");if(btn)btn.classList.add("press");
  if(btn){var act=btn.getAttribute("data-act")||"";if(act.indexOf("now:")===0){var nid=act.slice(4);if(nid==="eat"||nid==="nap"||nid==="clean"||nid==="wash")armHold(nid);}}
  try{cmd.setPointerCapture(e.pointerId);}catch(x){}
  e.preventDefault();});
cmd.addEventListener("pointermove",function(e){if(!G||G.id!==e.pointerId)return;var dx=e.clientX-G.x0,dy=e.clientY-G.y0;
  if(G.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){
    if(Math.abs(dy)>=Math.abs(dx)*0.75)G.mode="scroll";
    else if(G.bid&&G.bid===focusId&&G.trk)G.mode="slide";   /* 0.4.2: only a sideways drag that starts ON the focused slider's track */
    else G.mode="none";
    if(G.pm)G.pm.classList.remove("press");if(G.btn)G.btn.classList.remove("press");
    if(G.mode==="scroll"||G.mode==="none")stopHold();}
  if(G.mode==="scroll")cmd.scrollTop=G.st0-dy;
  else if(G.mode==="slide"){var trk=G.box.querySelector(".trk");if(sim.setBox(G.bid,valFromX(G.bid,trk,e.clientX)))changed();}});
function endG(e,cancel){if(!G||G.id!==e.pointerId)return;var g=G;G=null;if(g.pm)g.pm.classList.remove("press");if(g.btn)g.btn.classList.remove("press");
  if(holdOn){stopHold();return;}
  clearHoldTimer();
  /* a slide ends where the finger lifts: a slow WebView may not deliver a final move */
  if(!cancel&&g.mode==="slide"){var tk=g.box.querySelector(".trk");if(sim.setBox(g.bid,valFromX(g.bid,tk,e.clientX)))changed();return;}
  if(cancel||g.mode!==null)return;
  /* slow old WebViews can deliver a swipe as down -> up with few or no moves: judge by where the finger lifted */
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)cmd.scrollTop=g.st0-dy;return;}
  /* a clean tap */
  if(g.pm&&g.bid){var d=+g.pm.getAttribute("data-d");setFocus(g.bid);if(sim.setBox(g.bid,sim.s.box[g.bid]+d*BOX[g.bid].step))changed();return;}
  if(g.btn){doAct(g.btn.getAttribute("data-act"));return;}
  if(g.bid){if(focusId===g.bid&&g.trk){if(sim.setBox(g.bid,valFromX(g.bid,g.trk,e.clientX)))changed();}else setFocus(g.bid);return;}
  setFocus(null);}
cmd.addEventListener("pointerup",function(e){endG(e,false);});
cmd.addEventListener("pointercancel",function(e){endG(e,true);});
cmd.addEventListener("lostpointercapture",function(e){if(G&&G.id===e.pointerId&&G.mode!==null)endG(e,true);});
var GL=[];window.__ppGL=GL;["pointerdown","pointermove","pointerup","pointercancel"].forEach(function(t){cmd.addEventListener(t,function(e){GL.push(t.slice(7)+":"+Math.round(e.clientX)+","+Math.round(e.clientY)+(G?":"+G.mode:""));if(GL.length>40)GL.shift();},true);});
cmd.addEventListener("click",function(e){e.preventDefault();});
var PE=null;
$("play").addEventListener("pointerdown",function(e){
  if(focusId)setFocus(null);showLabels(8000);
  var w0=worldFromEvent(e);
  if(editMode){
    var w=w0,hit=hitEditItem(w.x,w.y);
    if(hit){dragId=hit;showInfo(hit);PE={id:e.pointerId,act:"drag",item:hit,keepSel:true,x0:e.clientX,y0:e.clientY,moved:false,ox:w.x-sim.centerOf(hit).x,oy:w.y-sim.centerOf(hit).y};try{e.currentTarget.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();rebuildTray();}
    else{var h2=hitAny(w.x,w.y);if(h2)showInfo(h2);}
  }else{var h3=hitAny(w0.x,w0.y);showInfo(h3);
    if(h3==="door"){if(sim.hasKey())beginFade(viewIsWash()?"kitchen":"wash");}
    else if(h3==="radio"&&sim.placed("radio"))openOvl("radio");}
});
$("play").addEventListener("pointermove",function(e){
  if(!PE||PE.id!==e.pointerId)return;
  if(PE.act==="drag"&&dragId){if(!PE.moved&&Math.abs(e.clientX-PE.x0)<6&&Math.abs(e.clientY-PE.y0)<6)return;PE.moved=true;
    var w=worldFromEvent(e);if(sim.moveItem(dragId,w.x-(PE.ox||0),w.y-(PE.oy||0))){if(dragId==="washPile"||dragId==="streetMouth")bustRoomCache();else{staticLayer=null;messLayer=null;}messVer++;if(playRect)placeTags();}}
});
function endPE(e){
  if(!PE||PE.id!==e.pointerId)return;
  if(PE.btn&&PE.btn.classList)PE.btn.classList.remove("press");
  if(PE.act==="drag"){if(!(PE.keepSel))dragId=null;saveGame();rebuildTray();}
  PE=null;
}
$("play").addEventListener("pointerup",endPE);
$("play").addEventListener("pointercancel",endPE);
function bindRail(el){if(!el)return;
  el.addEventListener("pointerdown",function(e){
    var btn=e.target.closest?e.target.closest("[data-act]"):null;if(!btn||!el.contains(btn))return;
    doAct(btn.getAttribute("data-act"));btn.classList.add("press");
    PE={id:e.pointerId,act:btn.getAttribute("data-act"),btn:btn};
    try{el.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();
  });
  el.addEventListener("pointerup",endPE);
  el.addEventListener("pointercancel",endPE);
}
bindRail($("leftRail"));bindRail($("rightRail"));bindRail($("editBtn"));bindRail($("putAway"));bindRail($("rotBtn"));
/* drag an unplaced item from the editor tray into the room */
(function(){
  var tray=$("invChips"),TD=null;
  if(!tray)return;
  tray.addEventListener("pointerdown",function(e){
    var chip=e.target.closest?e.target.closest("[data-place]"):null;if(!chip)return;
    TD={id:e.pointerId,item:chip.getAttribute("data-place"),x0:e.clientX,y0:e.clientY};
    chip.classList.add("press");
    try{tray.setPointerCapture(e.pointerId);}catch(x){}
    e.preventDefault();
  });
  function endTD(e,cancel){
    if(!TD||TD.id!==e.pointerId)return;
    var item=TD.item,pr=$("play").getBoundingClientRect();TD=null;
    var chips=tray.querySelectorAll(".invchip");for(var i=0;i<chips.length;i++)chips[i].classList.remove("press");
    if(cancel)return;
    if(e.clientX>=pr.left&&e.clientX<=pr.right&&e.clientY>=pr.top&&e.clientY<=pr.bottom){
      var w=worldFromEvent(e);
      if(sim.placeItem(item,w.x,w.y)==="ok"){staticLayer=null;messLayer=null;changed();rebuildTray();layout();}
    }
  }
  tray.addEventListener("pointerup",function(e){endTD(e,false);});
  tray.addEventListener("pointercancel",function(e){endTD(e,true);});
})();


/* ---------- shop + help screens (same scroll-safe rule: a tap is judged where the finger lifts; drags scroll) ---------- */
var ovl=$("ovl"),ovlBody=$("ovlBody"),ovlMode=null,ovlDirty=false,OG=null;
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function goBtn(act,price,state){var cls="go"+(state==="poor"?" poor":"")+(state==="done"?" done":"");
  return '<button class="'+cls+'" type="button" data-act="'+act+'">'+(state==="done"?"MAXED":price+"c<br>BUY")+'</button>';}
function buildInv(){
  var s=sim.s,h="",list=sim.invList(),i,it,btn;
  h+='<div class="sec">TOOLS — EQUIP ON PAPA</div>';
  var tools=0;
  for(i=0;i<list.length;i++){
    it=list[i];if(it.kind!=="tool")continue;tools++;
    btn=it.equipped?'<button class="go done" type="button" data-act="unequip:'+it.id+'">UNEQUIP</button>':'<button class="go" type="button" data-act="equip:'+it.id+'">EQUIP</button>';
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>'+(it.equipped?"ON PAPA":"IN INV")+'</b></div><div class="fx">Equip it on Papa to use it. Unequip sends it back to the inventory.</div></div>'+btn+'</div>';
  }
  if(!tools)h+='<div class="row"><div class="tx"><div class="nm">NO TOOLS YET</div><div class="fx">Buy the better peeler, carry bag or broom in the SHOP. They land here first.</div></div></div>';
  h+='<div class="sec">FURNITURE, MACHINES AND DECOR</div>';
  var places=0;
  for(i=0;i<list.length;i++){
    it=list[i];if(it.kind!=="place")continue;places++;
    if(it.placed)btn='<button class="go done" type="button" data-act="return:'+it.id+'">PUT AWAY</button>';
    else btn='<button class="go" type="button" data-act="toedit:'+it.id+'">EDIT TO PLACE</button>';
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>'+(it.placed?"IN ROOM":"IN INV")+'</b></div><div class="fx">'+(it.placed?"In the room. PUT AWAY sends it back to the inventory.":"In your inventory. Open EDIT and drag it into the room.")+'</div></div>'+btn+'</div>';
  }
  if(!places)h+='<div class="row"><div class="tx"><div class="nm">NOTHING TO PLACE</div><div class="fx">Buy machines, a sink, a cot or decorations in the SHOP. They wait here until you place them.</div></div></div>';
  for(i=0;i<list.length;i++){it=list[i];if(it.kind!=="duck")continue;places++;
    btn=it.placed?'<button class="go done" type="button" data-act="duck:out">TAKE OUT</button>':'<button class="go" type="button" data-act="duck:in">PUT IN<br>BASIN</button>';
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>'+(it.placed?"IN THE BASIN":"IN INV")+'</b></div><div class="fx">'+(sim.hasKey()?"Floats in the wash-room basin: the current pulls potatoes off the heap 25% faster.":"Needs the ROOM KEY: it floats in the wash-room basin.")+'</div></div>'+btn+'</div>';}
  var fxl=sim.decorEffects();if(fxl.length){h+='<div class="sec">DECOR EFFECTS RIGHT NOW</div><div class="row"><div class="tx">';
    for(i=0;i<fxl.length;i++)h+='<div class="fx" style="color:'+(fxl[i].on?'#c4e490':'#6a7a8a')+'">'+(fxl[i].on?'ON  ':'off ')+esc(fxl[i].txt)+'</div>';
    h+='</div></div>';}
  var keys=0,kh='<div class="sec">KEYS</div>';
  for(i=0;i<list.length;i++){it=list[i];if(it.kind!=="key")continue;keys++;
    kh+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>OWNED</b></div><div class="fx">Unlocks the metal door. Tap the door to go to the wash room and its landing pool and canal.</div></div><button class="go done" type="button">UNLOCKED</button></div>';}
  if(keys)h+=kh;
  if(!list.length)h='<div class="sec">INVENTORY</div><div class="row"><div class="tx"><div class="nm">EMPTY</div><div class="fx">Buy items in the SHOP. They come here first. Tools get equipped on Papa. Everything else is placed from EDIT.</div></div></div>';
  ovlBody.innerHTML=h;
}
function buildShop(){var s=sim.s,h="",pr=sim.price(),fm=sim.foodMax(),i,it,st,lp;
  h+='<div class="sec">LEVEL</div>';
  lp=sim.levelPrice();
  h+='<div class="row"><div class="tx"><div class="nm">LEVEL <b>'+s.level+' / 5</b></div><div class="fx">Pay coins to level up. Each level unlocks machines and decorations, then you buy them below. Lv1 is the six starters.</div></div>'+(lp===null?goBtn("buy:lv",0,"done"):goBtn("buy:lv",lp,s.coins<lp?"poor":""))+'</div>';
  h+='<div class="sec">UNLOCKED ITEMS</div>';
  for(i=0;i<PPSim.ITEMS.length;i++){
    it=PPSim.ITEMS[i];
    if(s.level<it.lv)continue;
    st=sim.owned(it.id)?"done":(s.coins<it.price?"poor":"");
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(it.name)+' <b>Lv'+it.lv+'</b></div><div class="fx">'+esc(it.fx)+'</div></div>'+goBtn("buy:item:"+it.id,it.price,st)+'</div>';
  }
  var locked=0;for(i=0;i<PPSim.ITEMS.length;i++)if(s.level<PPSim.ITEMS[i].lv)locked++;
  if(locked)h+='<div class="row"><div class="tx"><div class="nm">LOCKED</div><div class="fx">'+locked+' more item'+(locked>1?"s":"")+' unlock at higher levels. (They are hidden, not deleted.)</div></div></div>';
  h+='<div class="sec">FOOD</div>';
  h+='<div class="row"><div class="tx"><div class="nm">FOOD CAN <b>'+s.food+' / '+fm+'</b></div><div class="fx">One can = +55 hunger when he eats. The price climbs a little with each can and slowly over time.</div></div>'+(s.food>=fm?goBtn("buy:food",pr,"done"):goBtn("buy:food",pr,s.coins<pr?"poor":""))+'</div>';
  if(PPSim.POT_SLIDER){h+='<div class="sec">POTATOES</div>';var pp=sim.potPrice(),cap=s.potCap;
  h+='<div class="row"><div class="tx"><div class="nm">MORE POTATOES <b>'+POTS[cap]+(pp===null?'':' &rarr; '+POTS[cap+1])+'</b></div><div class="fx">You own '+POTS[cap]+'. Buying raises your limit to the next stop and puts the new potatoes on the pile. The POTATOES IN PLAY slider goes up to what you own.</div></div>'+(pp===null?goBtn("buy:pot",0,"done"):goBtn("buy:pot",pp,s.coins<pp?"poor":""))+'</div>';}
  /* 0.4.9: MORE POTATOES shop row hidden (stock locked at 9999). The buyPotatoes path stays in the file. */
  h+='<div class="sec">UPGRADES</div>';
  for(var i=0;i<UPS.length;i++){var u=UPS[i],lv=sim.up(u.id),p2=sim.upPrice(u.id);
    h+='<div class="row"><div class="tx"><div class="nm">'+esc(u.name)+' <b>LV '+lv+'/'+u.max+'</b></div><div class="fx">'+esc(u.fx)+'</div></div>'+(p2===null?goBtn("buy:up:"+u.id,0,"done"):goBtn("buy:up:"+u.id,p2,s.coins<p2?"poor":""))+'</div>';}
  ovlBody.innerHTML=h;}
/* ---- the HELP booklet: cover, one page per command (generated from PPSim.COMMANDS), a last page on the loop. Flip with PREV / NEXT or a sideways swipe. ---- */
var bookPage=0;
function bookPages(){return CMDS.length+8;}      /* cover + every command + levels + line + editor + inventory + decor + loop */
function icoDraw(cv2,id){var g=cv2.getContext("2d"),r=function(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);};g.clearRect(0,0,16,16);
  if(id==="cover"){r(2,2,12,12,"#8a5a28");r(3,3,10,10,"#c48a48");r(4,4,8,2,"#e8c070");r(5,8,2,2,"#6a4020");r(9,9,2,2,"#6a4020");r(6,11,2,1,"#6a4020");}
  else if(id==="pace"){r(1,6,3,1,"#8a6a40");r(0,9,4,1,"#8a6a40");r(2,12,3,1,"#8a6a40");r(5,3,3,10,"#c0361e");r(8,5,2,6,"#c0361e");r(10,6,2,4,"#c0361e");r(12,7,2,2,"#c0361e");}
  else if(id==="eat"){r(3,4,10,9,"#7a3a10");r(3,5,10,7,"#e0a040");r(3,4,10,1,"#f0e0b0");r(4,8,8,2,"#b04020");r(6,2,4,2,"#9aa49a");}
  else if(id==="nap"){r(1,5,14,8,"#3a3a50");r(2,6,12,6,"#e8e4d4");r(6,7,8,5,"#4a6aa8");r(2,7,4,4,"#fffaf0");r(9,3,3,1,"#4a6aa8");r(11,2,3,1,"#4a6aa8");r(9,4,3,1,"#4a6aa8");}
  else if(id==="clean"){for(var i=0;i<9;i++)r(11-i,1+i,2,2,"#8a6840");r(1,10,8,5,"#c8a860");r(1,13,8,2,"#8a6a30");for(var j=0;j<4;j++)r(2+j*2,10,1,5,"#5a4020");}
  else if(id==="pot"){r(4,5,8,7,"#8a5a28");r(3,6,10,5,"#8a5a28");r(5,4,6,1,"#c48a48");r(5,5,3,1,"#e8c070");r(6,8,1,1,"#4a2810");r(9,9,1,1,"#4a2810");r(7,11,1,1,"#4a2810");r(4,12,8,1,"#4a2810");}
  else if(id==="style"){r(2,10,5,3,"#3a2a20");r(6,8,8,3,"#c8d0d8");r(7,8,7,1,"#f0f4f8");r(12,7,2,1,"#c8d0d8");r(3,3,2,1,"#e8c070");r(6,2,3,1,"#e8c070");r(10,4,2,1,"#e8c070");}
  else if(id==="wake"){r(6,6,4,4,"#ffe066");r(5,7,6,2,"#ffe066");r(7,2,2,2,"#ffd060");r(7,12,2,2,"#ffd060");r(2,7,2,2,"#ffd060");r(12,7,2,2,"#ffd060");r(4,4,1,1,"#ffd060");r(11,4,1,1,"#ffd060");r(4,11,1,1,"#ffd060");r(11,11,1,1,"#ffd060");}
  else if(id==="autob"){r(2,6,9,8,"#7a3a10");r(2,7,9,6,"#e0a040");r(2,6,9,1,"#f0e0b0");r(9,1,5,5,"#c4a020");r(10,2,3,3,"#ffe066");r(11,3,1,1,"#c4a020");}
  else{r(1,7,3,3,"#8a6a40");r(3,6,10,5,"#3a4038");r(4,7,8,3,"#12141a");r(5,3,6,1,"#c0361e");r(7,2,2,1,"#c0361e");r(5,12,6,1,"#3ad070");}}
function miniSlider(c,v){var mx=c.id==="pot"?Math.max(1,sim.potMax()):c.max,p=(v-c.min)/(mx-c.min),n=Math.max(1,Math.round((mx-c.min)/c.step)),tn=Math.min(n,14),tk="";
  for(var i=0;i<=tn;i++)tk+='<i class="tk" style="left:'+(i/tn*100)+'%"></i>';
  return '<div class="mini"><span class="e">'+esc(c.hi)+'</span><div class="mt"><div class="ln"></div><div class="mf" style="width:'+(p*100)+'%"></div>'+tk+'<div class="mk" style="left:'+((1-p)*100)+'%"></div></div><span class="e r">'+esc(c.lo)+'</span></div>';}
function pageHtml(pg){var s=sim.s,N=bookPages(),pn='<span class="pn">'+(pg+1)+' / '+N+'</span>';
  if(pg===0)return '<div id="pg" class="cover"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><div class="t1">PAPA POTATO</div><div class="t2">HANDBOOK</div><button class="go2" type="button" data-act="book:next">OPEN THE BOOK</button><div class="note" style="margin-top:12px;color:#d8b878">'+CMDS.length+' commands, plus levels, the line, the editor, inventory, decor and the wash room</div></div>';
  if(pg===N-1)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="loop" width="16" height="16"></canvas><b>THE LOOP</b></div><div class="lb">WHAT HE DOES</div><div class="chips"><span>PILE</span><span>&gt; PEEL TABLE</span><span>&gt; KITCHEN SHIP 2c</span><span>&gt; RETURN</span><span>&gt; PILE</span></div><div class="tx">After he peels, he puts potatoes in the hole in the north kitchen wall. Unwashed pay 2c there (3c if already washed in the sink) and come back raw. WASH, a hold on WASH, or AUTO-WASH sends them through that same hole: they come out into the wash-room basin and pile up in the water, and a canal along the right wall pulls them to a ship opening for 3c. The work line uses the same split. Peels land on the floor. CLEAN (or the CLEAN button) sends him to the peels.</div><div class="lb">YOUR COINS GO TO</div><div class="chips"><span>LEVELS</span><span>ITEMS</span><span>FOOD</span><span>POTATOES</span><span>UPGRADES</span></div><div class="tx">Open the SHOP to buy. New items go to your INVENTORY. Equip tools on Papa, or open EDIT and drag furniture and machines into either room. The view always fits the whole room. EDIT moves furniture (not the kitchen pile, return, shipping, or the wash-room hole).</div></div>';
  if(pg===N-7)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><b>LEVELS</b></div><div class="lb">PAY TO LEVEL UP</div><div class="tx">You start at Level 1. Pay coins in the SHOP to reach the next level (up to 5). Each level UNLOCKS items; you still BUY them in the shop. Bought items go to your inventory first. Lv1 is the starters (room key, better peeler, carry bag, sink, broom, small cooler, cot).</div><div class="lb">UPGRADES</div><div class="tx">Old upgrades (sharp peeler, boots, chute, cooler, broom, soft bed) stay. New ones speed the auto-peeler and belts and grow the carry bag. Unused items stay in the game, just hidden until unlocked.</div></div>';
  if(pg===N-6)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="loop" width="16" height="16"></canvas><b>THE WORK LINE</b></div><div class="lb">MACHINES</div><div class="tx">CONVEYOR, AUTO SUCTION, AUTO-PEELER and OUT-CONVEYOR. Buy them, then place them from EDIT. Each has an on/off or speed slider once bought. The out-conveyor butts the shipping intake and is drawn under it. Peels always land inside the room.</div><div class="lb">COMMANDS</div><div class="tx">SUCTION, CONVEYOR SPEED, AUTO-PEELER SPEED, OUT-CONVEYOR SPEED. Faster belts and peelers come from the BETTER BELTS / FASTER AUTO-PEELER upgrades.</div></div>';
  if(pg===N-5)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="wake" width="16" height="16"></canvas><b>EDITOR</b></div><div class="lb">EDITOR</div><div class="tx">Tap EDIT. The room always fits the screen (no zoom or scroll arrows). Drag any item except the potato pile, the return chute and the shipping chute. Those three stay put. The cutting board, knife and peel stand move with the table. The seat is its own object and does not follow the cooler. Your layout is saved with the game.</div><div class="lb">ROTATE + INFO</div><div class="tx">Pick an item and tap ROTATE to turn it a quarter. Things can sit close together, but never on top of each other or on the shipping X, and never so packed he cannot get through. Tap anything in the room (editing or not) to see its name and what it does on the right.</div><div class="lb">THE TRAY</div><div class="tx">EDIT opens an inventory tray under the room (never over it). Drag an unplaced item from the tray into the room. Select a placed item and tap PUT AWAY to send it back to the inventory.</div></div>';
  if(pg===N-4)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="cover" width="16" height="16"></canvas><b>INVENTORY</b></div><div class="lb">BUY, THEN USE</div><div class="tx">Bought items go to your inventory first, not straight into the room. Open INV (same style as the shop). Tools (better peeler, carry bag, broom) can be equipped or unequipped on Papa. Furniture, machines and decorations are placed in the room from the EDIT tray.</div><div class="lb">OLD SAVES</div><div class="tx">If you already owned items before inventory, they stay in the room (and tools stay equipped). Nothing is lost.</div></div>';
  if(pg===N-3)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="nap" width="16" height="16"></canvas><b>DECORATIONS</b></div><div class="lb">EVERY ONE DOES SOMETHING</div><div class="tx">RADIO: music = energy drains 20% slower, works 5% faster (RADIO button: 2 stations or your own songs). LAMP ON: peel 8% faster. PLANT watered: energy 10% slower. CLOCK: meals 30% shorter. POSTER: lazy speed 70%. FAN: mess slows him 15% max. SHELF: +2 food. DUCK (wash basin): heap pull 25% faster. TV + ARMCHAIR: WATCH WHEN ENERGY &lt;.</div><div class="lb">CARPETS (STAND ON THEM)</div><div class="tx">KITCHEN MAT: energy 30% slower. RUG: hunger 20% slower. RUNNER: walk 15% faster. ROUND RUG: work 8% faster. Carpets slide under furniture but never on each other. Wall items hang on the north, east or west wall.</div></div>';
  if(pg===N-2)return '<div id="pg">'+pn+'<div class="hd"><canvas class="ic" data-ic="wash" width="16" height="16"></canvas><b>THE WASH ROOM</b></div><div class="lb">THE KEY</div><div class="tx">Buy a ROOM KEY (40c) in the SHOP. It unlocks the metal door on the north wall. Both rooms are ready from the start; tapping the open door swaps instantly with a short fade. This back room is a WASH room, not a shipping room.</div><div class="lb">THE INLET, POOL AND CANAL</div><div class="tx">He walks up to the kitchen X-ray scanner and places each peeled potato on the belt. That machine sends them through the wall; they come out a matching scanner at the bottom of the wash room into a basin, and a canal along the right wall runs straight into a ship opening at the top-right, where they ship at full pay (3c) and come back raw. Unwashed potatoes that he places in the kitchen scanner without WASH still pay 2c there (1c if sloppy) and never appear in this room. A sink wash before peeling also counts as washed and pays 3c at the kitchen scanner. They pile up in the basin water when more come out than the current can carry, and the heap shrinks when the canal keeps up. The current is very slow at first. WIDER CHANNEL (70c, then 180c) speeds it up a lot and makes the canal a little wider. AUTO-WASH (220c, level 4) lets him take peeled potatoes to the kitchen scanner on his own. EDIT works in this room too, but the basin heap, machines, canal and ship opening stay put.</div><div class="lb">INSTANT COMMANDS</div><div class="tx">EAT, NAP, CLEAN, WASH and WORK at the bottom make him do that job right now. Hold a button to keep going (hold WASH to keep sending peeled potatoes through the hole). WASH makes him drop peeled potatoes into the kitchen hole so they come out in the pool. WORK sends him back to peeling.</div></div>';
  if(pg-1>=CMDS.length)return '<div id="pg">'+pn+'<div class="tx">Missing page.</div></div>';
  var c=CMDS[pg-1],v=s.box[c.id];
  return '<div id="pg" data-cmd="'+c.id+'">'+pn+'<div class="hd"><canvas class="ic" data-ic="'+c.id+'" width="16" height="16"></canvas><b>'+esc(c.name)+'</b></div><div class="lb">DOES</div><div class="tx">'+esc(c.does)+'</div><div class="lb">SLIDER</div>'+miniSlider(c,v)+'<div class="now">NOW: '+esc(fmt(c.id,v))+'</div><div class="lb">AFFECTS</div><div class="tx">'+esc(c.affects)+'</div><div class="lb">RANGE</div><div class="rg">'+esc(c.range)+'</div></div>';}
function buildBook(dir){var N=bookPages(),h='<div id="book">'+pageHtml(bookPage)+'<div id="bkNav"><button type="button" data-act="book:prev"'+(bookPage<=0?' class="dis"':'')+'>&lt; PREV</button><div class="dots">';
  for(var i=0;i<N;i++)h+='<i'+(i===bookPage?' class="on"':'')+'></i>';h+='</div><button type="button" data-act="book:next"'+(bookPage>=N-1?' class="dis"':'')+'>NEXT &gt;</button></div></div>';
  ovlBody.innerHTML=h;var cs=ovlBody.querySelectorAll("canvas.ic");for(var j=0;j<cs.length;j++)icoDraw(cs[j],cs[j].getAttribute("data-ic"));
  if(dir){var pg=$("pg");pg.className=(pg.className?pg.className+" ":"")+(dir>0?"flipn":"flipp");}}
function flipBook(d){d=+d;d=d>0?1:(d<0?-1:0);var n=Math.max(0,Math.min(bookPages()-1,bookPage+d));if(n===bookPage)return false;bookPage=n;buildBook(d);return true;}
function buildOvl(){var st=ovlBody.scrollTop;ovlBody.className=ovlMode==="help"?"book":"";if(ovlMode==="shop")buildShop();else if(ovlMode==="help")buildBook(0);else if(ovlMode==="inv")buildInv();else if(ovlMode==="radio")buildRadio();ovlBody.scrollTop=(ovlMode==="shop"||ovlMode==="inv"||ovlMode==="radio")?st:0;$("ovlCoins").textContent=(ovlMode==="shop"||ovlMode==="inv")?sim.s.coins+"c":"";}
function openOvl(mode){ovlMode=mode;ovl.className="on";$("ovlTitle").textContent=mode==="shop"?"SHOP":(mode==="inv"?"INVENTORY":(mode==="radio"?"RADIO":"HELP BOOKLET"));ovlBody.scrollTop=0;if(mode==="help")bookPage=0;buildOvl();if(focusId)setFocus(null);}
function closeOvl(){ovlMode=null;ovl.className="";OG=null;}
function flash(btn,txt){if(!btn)return;var old=btn.innerHTML;btn.innerHTML=txt;setTimeout(function(){if(ovlMode)ovlDirty=true;},700);}
/* ---------- 0.4.10 RADIO: stations + MY MUSIC (your own files) through the little speaker ---------- */
function radioPlaced(){return sim.placed("radio");}
function radioWant(){var s=sim.s,d=s.decor||{},g=s.g,dist=99;
  if(radioPlaced()&&g.where!=="wash"){var p=sim.placeOf("radio");dist=Math.hypot(g.x*RW-p.x,g.y*RH-p.y);}
  return {on:s.box.radio>0,placed:radioPlaced(),st:d.radioSt|0,vol:d.radioVol==null?6:d.radioVol|0,near:d.radioNear?1:0,dist:dist,papaWash:g.where==="wash",viewWash:viewIsWash()};}
function radioSync(){if(window.PPRadio)PPRadio.update(radioWant());}
function radioWake(){if(window.PPRadio){PPRadio.update(radioWant());PPRadio.wake();}}
function radioPickInput(){var inp=$("musicPick");if(inp)return inp;inp=document.createElement("input");inp.type="file";inp.id="musicPick";inp.accept="audio/*";inp.multiple=true;
  inp.style.cssText="position:absolute;left:-9999px;top:0;width:1px;height:1px;opacity:0";
  inp.addEventListener("change",function(){var r={added:0,first:-1};try{r=PPRadio.addFiles(inp.files);}catch(e){}
    try{inp.value="";}catch(e2){}
    if(r.added>0){var d=sim.s.decor;d.radioSt=2;sim.setBox("radio",1);radioWake();PPRadio.playSong(r.first);changed();}
    radioNote=r.added>0?("Added "+r.added+" song"+(r.added>1?"s":"")+"."):"No music picked.";ovlDirty=true;});
  document.body.appendChild(inp);return inp;}
var radioNote="";
function radioAct(c){var d=sim.s.decor;radioWake();
  if(c==="power"){sim.setBox("radio",sim.s.box.radio>0?0:1);}
  else if(c.indexOf("st:")===0){d.radioSt=Math.max(0,Math.min(2,+c.slice(3)|0));if(sim.s.box.radio<=0)sim.setBox("radio",1);if(d.radioSt===2&&!PPRadio.hasGoodSong())radioNote="Pick songs first (ADD SONGS). Playing POTATO FM until then.";}
  else if(c==="pick"){radioNote="";try{radioPickInput().click();}catch(e){radioNote="This phone did not open a file picker.";}}
  else if(c.indexOf("song:")===0){d.radioSt=2;if(sim.s.box.radio<=0)sim.setBox("radio",1);radioWake();PPRadio.playSong(+c.slice(5)|0);}
  else if(c==="next"||c==="prev"){d.radioSt=2;if(sim.s.box.radio<=0)sim.setBox("radio",1);radioWake();if(c==="next")PPRadio.next();else PPRadio.prev();}
  else if(c==="vol+")d.radioVol=Math.min(10,(d.radioVol|0)+1);
  else if(c==="vol-")d.radioVol=Math.max(0,(d.radioVol|0)-1);
  else if(c==="near")d.radioNear=d.radioNear?0:1;
  else if(c==="clear"){PPRadio.clearSongs();if(d.radioSt===2)d.radioSt=0;radioNote="Song list cleared.";}
  radioSync();ovlDirty=true;changed();}
function rBtn(act,label,state){return '<button class="go'+(state?" "+state:"")+'" type="button" data-act="radio:'+act+'">'+label+'</button>';}
function buildRadio(){var s=sim.s,d=s.decor||{},on=s.box.radio>0,st=d.radioSt|0,h="",i,R=window.PPRadio?PPRadio.state():{songs:[],cur:-1,supported:false};
  var songs=R.songs||[],good=window.PPRadio&&PPRadio.hasGoodSong();
  h+='<div class="sec">POWER</div>';
  h+='<div class="row"><div class="tx"><div class="nm">RADIO <b>'+(on?"ON":"OFF")+'</b></div><div class="fx">Music ON: energy drains 20% slower and he works 5% faster.</div></div>'+rBtn("power",on?"TURN<br>OFF":"TURN<br>ON",on?"done":"")+'</div>';
  if(!radioPlaced())h+='<div class="row"><div class="tx"><div class="nm">NOT IN THE ROOM</div><div class="fx">Place the radio from EDIT to hear it (and get the bonus).</div></div></div>';
  if(!R.supported)h+='<div class="row"><div class="tx"><div class="nm">NO SOUND</div><div class="fx">This phone has no WebAudio. The bonus still works.</div></div></div>';
  h+='<div class="sec">STATION</div>';
  var names=[["POTATO FM","Lo-fi beats, made live by the game."],["SPUD JAZZ","Slow jazz, made live by the game."],["MY MUSIC","Your own songs from this phone."]];
  for(i=0;i<3;i++){var sel=st===i,ok=i<2||good;
    h+='<div class="row"><div class="tx"><div class="nm">'+names[i][0]+(sel?' <b>'+(on?"ON AIR":"TUNED")+'</b>':'')+'</div><div class="fx">'+names[i][1]+(i===2&&!good?' Pick songs below first.':'')+'</div></div>'+rBtn("st:"+i,sel?"TUNED":"TUNE",sel?"done":(ok?"":"poor"))+'</div>';}
  h+='<div class="sec">MY MUSIC</div>';
  h+='<div class="row"><div class="tx"><div class="nm">ADD SONGS <b>'+songs.length+'</b></div><div class="fx">Pick music files on your phone. They play out of the little radio. Nothing leaves the phone. The list lasts until you close the game.</div></div>'+rBtn("pick","ADD<br>SONGS","")+'</div>';
  for(i=0;i<songs.length;i++){var now=st===2&&R.cur===i&&R.playing==="song";
    h+='<div class="row"><div class="tx"><div class="nm">'+(i+1)+'. '+esc(songs[i].name)+(now?' <b>PLAYING</b>':'')+(songs[i].bad?' <b>WON\'T PLAY</b>':'')+'</div></div>'+rBtn("song:"+i,now?"&#9654;":"PLAY",now?"done":(songs[i].bad?"poor":""))+'</div>';}
  if(songs.length)h+='<div class="row"><div class="tx"><div class="nm">CONTROLS</div></div><div class="btns">'+rBtn("prev","&lt;&lt;","")+rBtn("power",on?"||":"&#9654;",on?"done":"")+rBtn("next","&gt;&gt;","")+rBtn("clear","CLEAR","poor")+'</div></div>';
  h+='<div class="sec">SOUND</div>';
  h+='<div class="row"><div class="tx"><div class="nm">VOLUME <b>'+(d.radioVol|0)+' / 10</b></div></div><div class="btns">'+rBtn("vol-","&minus;","")+rBtn("vol+","+","")+'</div></div>';
  h+='<div class="row"><div class="tx"><div class="nm">LOUDER NEAR PAPA <b>'+(d.radioNear?"ON":"OFF")+'</b></div><div class="fx">Louder when he is near the radio, quieter across the room, muffled from the wash room.</div></div>'+rBtn("near",d.radioNear?"ON":"OFF",d.radioNear?"done":"")+'</div>';
  var stLine=!on?"Off.":(!radioPlaced()?"On, but the radio is not in the room.":(st===2&&good?("Playing: "+(R.songName||"your songs")):("Playing: "+(st===1?"SPUD JAZZ":"POTATO FM"))));
  if(R.lastErr&&st===2)stLine+=" ("+R.lastErr+")";
  h+='<div class="row"><div class="tx"><div class="nm">NOW</div><div class="fx">'+esc(stLine)+(radioNote?'<br>'+esc(radioNote):'')+'</div></div></div>';
  ovlBody.innerHTML=h;}
function shopBuy(what){var r,btn=ovl.querySelector('[data-act="buy:'+what+'"]'),pr;
  if(what==="food"){pr=sim.price();r=sim.buyFood();}
  else if(what==="pot"){pr=sim.potPrice();r=sim.buyPotatoes();}
  else if(what==="lv"){pr=sim.levelPrice();r=sim.buyLevel();}
  else if(what.indexOf("item:")===0){var iid=what.slice(5);pr=sim.itemPrice(iid);r=sim.buyItem(iid);if(r==="ok"){rebuildPanel();rebuildTray();}}
  else if(what.indexOf("up:")===0){var id=what.slice(3);pr=sim.upPrice(id);r=sim.buyUp(id);if(r==="ok"&&id==="channel")bustRoomCache();}
  else return "bad";
  if(r==="ok"){if(btn)btn.innerHTML="BOUGHT!";setTimeout(function(){ovlDirty=true;},600);changed();}
  else if(r==="poor"){if(btn)btn.innerHTML="NEED<br>"+pr+"c";setTimeout(function(){ovlDirty=true;},800);}
  else{if(btn)btn.innerHTML=r==="full"?"FULL":"MAXED";setTimeout(function(){ovlDirty=true;},800);}
  updateHud();saveGame();return r;}
ovl.addEventListener("pointerdown",function(e){if(OG&&OG.id!==e.pointerId)return;var t=e.target,btn=t.closest?t.closest("[data-act]"):null;
  OG={id:e.pointerId,x0:e.clientX,y0:e.clientY,st0:ovlBody.scrollTop,btn:btn,mode:null};if(btn)btn.classList.add("press");
  try{ovl.setPointerCapture(e.pointerId);}catch(x){}e.preventDefault();});
ovl.addEventListener("pointermove",function(e){if(!OG||OG.id!==e.pointerId)return;var dx=e.clientX-OG.x0,dy=e.clientY-OG.y0;
  if(OG.mode===null&&(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP)){OG.mode=Math.abs(dy)>=Math.abs(dx)*0.75?"scroll":"none";if(OG.btn)OG.btn.classList.remove("press");}
  if(OG.mode==="scroll")ovlBody.scrollTop=OG.st0-dy;});
function endO(e,cancel){if(!OG||OG.id!==e.pointerId)return;var g=OG;OG=null;if(g.btn)g.btn.classList.remove("press");if(cancel)return;
  var dx=e.clientX-g.x0,dy=e.clientY-g.y0;
  if(ovlMode==="help"&&Math.abs(dx)>=40&&Math.abs(dx)>=Math.abs(dy)*1.2){flipBook(dx<0?1:-1);return;}   /* sideways swipe turns the page, judged where the finger lifts */
  if(g.mode!==null)return;
  if(Math.abs(dx)>SLOP||Math.abs(dy)>SLOP){if(Math.abs(dy)>=Math.abs(dx)*0.75)ovlBody.scrollTop=g.st0-dy;return;}
  if(g.btn)doAct(g.btn.getAttribute("data-act"));}
ovl.addEventListener("pointerup",function(e){endO(e,false);});
ovl.addEventListener("pointercancel",function(e){endO(e,true);});
ovl.addEventListener("click",function(e){e.preventDefault();});

/* ---------- main loop: time runs only while the game is open and visible ---------- */
function events(){var ev=sim.s.ev;while(ev.length){var e=ev.shift();if(e.k==="coin"){popCoin(e.v,e.sloppy);pushSuck(e.sloppy);}else if(e.k==="peel")spawnPeel(e.slot);else if(e.k==="room"||e.k==="view"){if(e.room&&e.room!==sim.s.viewRoom)beginFade(e.room);}}}
var last=0,acc=0,STEP=0.05,paused=false,frames=0;
function frame(ts){
  var dt=last?Math.min(0.25,(ts-last)/1000):0;last=ts;
  var man=window.__tt&&window.__tt.manual;
  if(!paused&&!man){acc+=dt;while(acc>=STEP){sim.step(STEP);acc-=STEP;}events();tickFlights(dt);tickDust(dt);tickSucks(dt);tickPops(dt);}
  if(sim.s.followRoom&&sim.s.followRoom!==sim.s.viewRoom&&!fading)beginFade(sim.s.followRoom);
  tickFade(dt);
  RT=sim.s.t+acc;drawScene(ts);frames++;updateLabels();if(frames%10===0)tickInfo();
  if(frames%6===0)updateHud();
  if(ts-lastSave>2000)saveGame();
  requestAnimationFrame(frame);}
document.addEventListener("visibilitychange",function(){if(document.hidden){paused=true;saveGame();}else{paused=false;last=0;}if(window.PPRadio)PPRadio.onHidden(document.hidden);});
/* 0.4.10: phones only allow sound after a tap, so any tap wakes the radio if it should be playing */
["pointerup","touchend","click"].forEach(function(t){document.addEventListener(t,function(){if(window.PPRadio&&sim&&sim.s.box.radio>0&&sim.placed("radio")){PPRadio.update(radioWant());PPRadio.kick();}},true);});
window.addEventListener("pagehide",saveGame);window.addEventListener("beforeunload",saveGame);window.addEventListener("unload",saveGame);
window.addEventListener("resize",function(){layout();drawScene(performance.now());});
/* what is on screen, for the HANDOFF object table and the tests */
var OBJECTS=[
  {id:"ship",name:"DROP HOLE",use:"He puts each peeled potato in the hole in the north kitchen wall: unwashed pay 2c, sink-washed pay 3c (1c sloppy unwashed). WASH or AUTO-WASH sends them through that same hole into the wash-room pool.",gameplay:true},
  {id:"door",name:"METAL DOOR",use:"Locked until you buy a ROOM KEY in the SHOP. Then tap it to swap to the wash room (instant, with a short fade).",gameplay:true},
  {id:"return",name:"RETURN chute",use:"A full batch (or an empty pile) spills back out of its mouth onto the pile, raw again.",gameplay:true},
  {id:"table",name:"PEEL TABLE",use:"Where he stands to peel (never walked over: he goes around it).",gameplay:true},
  {id:"bed",name:"BED",use:"NAP WHEN ENERGY < sends him here; SOFT BED upgrade speeds naps.",gameplay:true},
  {id:"cooler",name:"FOOD cooler",use:"Holds the food cans (HUD FOOD count, BIGGER COOLER upgrade). He stands at the cooler to eat. EAT WHEN HUNGER < or the EAT button sends him here.",gameplay:true},
  {id:"stool",name:"SEAT (stool)",use:"A seat. Its own object: it does not move with the cooler, and he eats at the cooler, not here.",gameplay:false},
  {id:"pile",name:"POTATOES pile",use:"The raw potatoes in the kitchen (stock locked at 9999). He grabs from its top edge.",gameplay:true},
  {id:"peels",name:"Peels on the floor",use:"Mess: slows him up to 30%; CLEAN WHEN PEELS > and STIFF BROOM deal with it. Auto-peeler peels always land inside the room.",gameplay:true},
  {id:"light",name:"Soft light pool under the table",use:"Lighting only. No gameplay.",gameplay:false},
  {id:"conveyor",name:"CONVEYOR",use:"Inbound belt, pile to auto-peeler. CONVEYOR SPEED. Hidden until bought.",gameplay:true},
  {id:"suction",name:"AUTO SUCTION",use:"Swarm intake on the pile. SUCTION on/off. Hidden until bought.",gameplay:true},
  {id:"autoPeeler",name:"AUTO-PEELER",use:"Peels potatoes onto the out-conveyor; peels shoot to the floor. AUTO-PEELER SPEED.",gameplay:true},
  {id:"outConveyor",name:"OUT-CONVEYOR",use:"Butts the shipping intake (drawn under it). OUT-CONVEYOR SPEED.",gameplay:true},
  {id:"sink",name:"SINK",use:"WASH BEFORE PEEL sends him here for a +1c clean potato.",gameplay:true},
  {id:"tv",name:"TV + ARMCHAIR",use:"WATCH WHEN ENERGY < sits him in the chair facing the glowing TV.",gameplay:true},
  {id:"radio",name:"RADIO",use:"Music ON: energy drains 20% slower, works 5% faster. Stations or your own songs.",gameplay:true},
  {id:"plant",name:"PLANT",use:"Watered: energy drains 10% slower in the kitchen. WATER WHEN DRY.",gameplay:true},
  {id:"lamp",name:"LAMP",use:"ON: peeling 8% faster.",gameplay:true},
  {id:"rug",name:"RUG",use:"Carpet. Standing on it: hunger drains 20% slower.",gameplay:true},
  {id:"kitchenMat",name:"KITCHEN MAT",use:"Carpet. Standing on it: energy drains 30% slower.",gameplay:true},
  {id:"runner",name:"RUNNER RUG",use:"Carpet. Walk 15% faster on it.",gameplay:true},
  {id:"roundRug",name:"ROUND BRAID RUG",use:"Carpet. Grab / peel / drop 8% faster on it.",gameplay:true},
  {id:"clock",name:"WALL CLOCK",use:"Shift time. Meal breaks 30% shorter.",gameplay:true},
  {id:"poster",name:"PAPA POSTER",use:"AUTO-LAZY speed 70% instead of 50%.",gameplay:true},
  {id:"fan",name:"FLOOR FAN",use:"Mess slow-down capped at 15% instead of 30%.",gameplay:true},
  {id:"shelf",name:"PANTRY SHELF",use:"+2 food storage.",gameplay:true},
  {id:"duck",name:"RUBBER DUCK",use:"Wash basin: heap pull 25% faster.",gameplay:true},
  {id:"cot",name:"BASIC COT",use:"Extra furniture. Naps still use the 0.3.1 soft bed (sleep locked).",gameplay:false}];
coinIcon();layout();rebuildPanel();rebuildTray();syncZoomLabel();updateHud();migUntil=performance.now()+9000;RT=sim.s.t;showLabels(30000);drawScene(performance.now());
requestAnimationFrame(frame);
/* test + debug hooks */
window.PP={get sim(){return sim;},Sim:PPSim,save:saveGame,key:SAVE_KEY,reset:function(seed){sim=PPSim.fresh(seed);focusId=null;hud={};boxSnap="";flights=[];flying={};messVer++;sucks=[];staticLayer=null;messLayer=null;kitLayer=null;washLayer=null;roomsPreloaded=false;fading=false;fadeT=0;fadeTo=null;if(editMode)toggleEditor();rebuildPanel();rebuildTray();updateHud();saveGame();layout();},
  reload:function(){sim=loadGame();hud={};flights=[];flying={};messVer++;renderAll();updateHud();},focus:function(){return focusId;},
  pause:function(p){paused=!!p;},layout:function(){return {W:W,H:H,k:k,roomW:roomW,roomH:roomH,offX:offX,offY:offY,detail:DETAIL,fitW:roomW*k,fitH:roomH*k,dpr:DPR,SC:SC};},version:"0.4.10",rotate:function(id){var r=sim.rotateItem(id);staticLayer=null;return r;},info:function(){var el=$("objInfo");return {id:infoId,on:!!el&&el.className!=="off",name:el?$("oiName").textContent:"",desc:el?$("oiDesc").textContent:""};},tapWorld:function(x,y){return hitAny(x,y);},commandNow:function(id){return sim.commandNow(id);},setHold:function(id,on){return sim.setHold(id,on);},setView:function(r,instant){if(instant){sim.s.viewRoom=r;sim.s.followRoom=null;staticLayer=null;roomsPreloaded=false;layout();drawScene(performance.now());return true;}return beginFade(r);},viewRoom:function(){return sim.s.viewRoom;},hasKey:function(){return sim.hasKey();},fade:function(){return {on:fading,t:fadeT,to:fadeTo};},select:function(id){dragId=id;rebuildTray();showInfo(id);},zoom:function(){return {i:1,k:1,panX:0,panY:0,fit:true};},setZoom:function(i){resetView();},edit:function(on){if(on==null)return editMode;if(!!on!==editMode)toggleEditor();return editMode;},move:function(id,x,y){var r=sim.moveItem(id,x,y);if(r){if(id==="washPile"||id==="streetMouth")bustRoomCache();else{staticLayer=null;messLayer=null;}messVer++;saveGame();}return r;},
  drawAt:function(t){drawScene(t);},animF:function(){return ANIM_F;},sitWorld:sitWorld,setPan:function(x,y){panX=+x||0;panY=+y||0;applyCam();if(playRect)placeTags();syncZoomLabel();},seedSucks:function(arr){sucks=arr||[];},
  setPileMax:function(n){PILEMAX=n;buildPile();pileLayer=null;pileKey=-1;},forcePile:function(n){sim.s.pile=n;},get migrated(){return migrated;},
  stats:function(){return {pileRenders:renders.pile,messRenders:renders.mess,maxVis:MAXVIS,tiers:TIER.slice(),messVis:MESSPOS.length,flights:flights.length,sucks:sucks.length};},
  giveAll:function(){var s=sim.s,i;s.level=5;s.coins=Math.max(s.coins,999);if(!s.owned)s.owned={};if(!s.place)s.place={};if(!s.equipped)s.equipped={};for(i=0;i<PPSim.ITEMS.length;i++){var it=PPSim.ITEMS[i];s.owned[it.id]=1;if(PPSim.isTool(it.id))s.equipped[it.id]=1;if(PPSim.isPlaceable(it.id))s.place[it.id]=PPSim.defaultPlace(it.id);}s.box.suction=1;s.box.conveyor=2;s.box.apeeler=2;s.box.outbelt=2;s.box.lamp=1;s.box.radio=1;s.box.tv=1;s.box.watch=30;s.box.water=40;s.box.wash=1;s.box.clean=20;s.box.eat=40;s.box.nap=35;sim.syncGeom();sim.rebuildObst();bustRoomCache();rebuildPanel();rebuildTray();changed();},
  radio:function(){return window.PPRadio?PPRadio.state():null;},radioLevel:function(){return window.PPRadio?PPRadio.level():0;},radioAct:radioAct,radioPick:function(){return radioPickInput();},duckPos:function(){return duckPos(RT||0);},
  objects:function(){return OBJECTS;},labels:function(ms,force){showLabels(ms||8000,force);updateLabels();if(playRect)placeTags();},placeTags:function(){if(playRect)placeTags();},ovl:function(){return ovlMode;},book:function(){return {page:bookPage,pages:bookPages()};},flip:flipBook,open:openOvl,close:closeOvl,buy:shopBuy,
  retView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++){var q=retPos(kk,sc,j,RT);o.push(q?{j:j,x:q.x,y:q.y,z:q.z,p:q.p,inPipe:q.inPipe,mouthX:q.mouthX,tx:q.tx,ty:q.ty}:{j:j,p:-1});}return o;},spillView:function(){var s=sim.s,kk=s.suck;if(!kk)return [];var sc=PPSim.spill(kk.t0,kk.n),o=[];for(var j=kk.landed;j<kk.n;j++)o.push({j:j,ex:sc.ex[j],ld:sc.ld[j],rt:RT});return o;},
  posOf:function(i){return POS[i];},messPos:function(i){buildMess();return MESSPOS[i];},messAll:function(){buildMess();return MESSPOS.slice();},
  tableKids:function(){return PPSim.tableKids();},bedside:function(){return PPSim.bedside();},
  lastSweep:function(){return sim.lastSweep||null;},
  labelsHidden:function(){var el=$("tagTable");if(!el)return true;var cs=getComputedStyle(el);return cs.display==="none"||cs.visibility==="hidden"||+cs.opacity===0;},
  follow:function(id){var k=PPSim.tableKids(),T=PPSim.GEO.table,S=PPSim.SPOT,o={id:id};
    o.table={x0:T.x0,y0:T.y0,x1:T.x1,y1:T.y1};
    o.board=k.board;o.knife=k.knife;o.peelSpawn=k.peelSpawn;o.stand=k.stand;
    o.boardOnTable=k.board.x0>=T.x0-0.05&&k.board.y0>=T.y0-0.05&&k.board.x1<=T.x1+0.05&&k.board.y1<=T.y1+0.05;
    o.standBeside=o.stand.y>=T.y1+4&&o.stand.x>=T.x0&&o.stand.x<=T.x1;
    o.stool={x:PPSim.GEO.stool.x,y:PPSim.GEO.stool.y};o.food=S.food;o.mat=S.mat;o.bed=PPSim.GEO.mat;
    o.obst=PPSim.OBST.map(function(b){return {id:b.id,x0:b.x0,y0:b.y0,x1:b.x1,y1:b.y1};});
    return o;},
  tray:function(){var tr=$("invTray");return {edit:editMode,chips:sim.trayList(),open:editMode&&!!tr&&getComputedStyle(tr).display!=="none"};},
  tagRects:function(){var o={};for(var i=0;i<TAGDEF.length;i++){var r=$(TAGDEF[i].id).getBoundingClientRect();o[TAGDEF[i].id]={x:r.left,y:r.top,w:r.width,h:r.height,on:$(TAGDEF[i].id).className.indexOf("off")<0,display:getComputedStyle($(TAGDEF[i].id)).display};}return o;},

  flightsNow:function(){return flights.map(function(f){return {slot:f.slot,t:f.t,dur:f.dur,x0:f.x0,y0:f.y0,tx:f.tx,ty:f.ty,h:f.h};});},cv:function(){return cv;}};
/* 0.4.9: tough-tools hook (HOOKS.md). Fixed 0.05 s ticks, seeded RNG, every player-visible command. */
var TT_MOV=["table","cooler","stool","mat"];
window.__tt={version:1,manual:false,
  getState:function(){var s=sim.s,g=s.g,a=g.act;return {tick:Math.round(s.t/STEP),over:false,paused:paused,entityCount:s.peels+Math.min(s.pile,MAXVIS),caps:{maxEntities:C.peelMax+MAXVIS},
    coins:s.coins,food:s.food,hunger:Math.round(s.hunger*100)/100,energy:Math.round(s.energy*100)/100,peels:s.peels,pile:s.pile,total:sim.total(),peeled:s.stats.peeled,
    act:a?a.t:"none",then:a&&a.then||"",x:Math.round(g.x*RW*100)/100,y:Math.round(g.y*RH*100)/100,hold:g.hold||"",box:JSON.parse(JSON.stringify(s.box)),viewRoom:s.viewRoom||"kitchen",where:g.where||"kitchen",hasKey:!!sim.hasKey(),wash:s.wash?s.wash.pots.length+(s.wash.bulk|0):0,washedShip:s.stats.washedShip|0,unwashedShip:s.stats.unwashedShip|0,
    table:{x0:GEO.table.x0,y0:GEO.table.y0,r:GEO.table.r|0},loopBreaks:s.stats.loopBreaks|0,
    decor:ttDecorState()};},
  step:function(n){n=Math.max(0,Math.min(100000,n|0));for(var i=0;i<n;i++)sim.step(STEP);drawScene(performance.now());},
  setSeed:function(sd){sim=PPSim.fresh((sd>>>0)||1);hud={};boxSnap="";flights=[];flying={};messVer++;sucks=[];staticLayer=null;messLayer=null;kitLayer=null;washLayer=null;roomsPreloaded=false;fading=false;fadeT=0;fadeTo=null;focusId=null;rebuildPanel();rebuildTray();updateHud();layout();},
  listCommands:function(){var o=[],i;for(i=0;i<CMDS.length;i++)o.push({name:"set_"+CMDS[i].id,args:[{name:"v",min:CMDS[i].min,max:CMDS[i].id==="pot"?POTS.length-1:CMDS[i].max}]});
    o.push({name:"buyFood"});o.push({name:"move",args:[{name:"i",min:0,max:3},{name:"x",min:0,max:RW},{name:"y",min:0,max:RH}]});o.push({name:"rotate",args:[{name:"i",min:0,max:3}]});
    var nd=TT_DECOR.length-1;
    o.push({name:"giveDecor"});o.push({name:"placeDecor",args:[{name:"i",min:0,max:nd},{name:"x",min:0,max:RW},{name:"y",min:0,max:RH}]});o.push({name:"unplaceDecor",args:[{name:"i",min:0,max:nd}]});o.push({name:"rotateDecor",args:[{name:"i",min:0,max:nd}]});
    o.push({name:"duck",args:[{name:"on",min:0,max:1}]});o.push({name:"radioPower"});o.push({name:"radioSt",args:[{name:"v",min:0,max:2}]});o.push({name:"radioVol",args:[{name:"v",min:0,max:10}]});o.push({name:"radioNear"});return o;},
  runCommand:function(name,args){args=args||[];
    if(name.indexOf("set_")===0){var id=name.slice(4);if(!BOX[id])throw new Error("bad cmd");var v=+args[0];if(!isFinite(v))throw new Error("bad v");sim.setBox(id,v);renderAll();return true;}
    if(name==="buyFood")return sim.buyFood(false);
    if(name==="move"||name==="rotate"){var i=Math.floor(+args[0]);if(!(i>=0&&i<TT_MOV.length))throw new Error("bad i");var id2=TT_MOV[i];
      var r=name==="move"?sim.moveItem(id2,+args[1],+args[2]):sim.rotateItem(id2);staticLayer=null;messLayer=null;messVer++;return r;}
    if(name==="giveDecor"){var so=sim.s;if(!so.owned)so.owned={};for(var k=0;k<TT_DECOR.length;k++){so.owned[TT_DECOR[k]]=1;if(!sim.placed(TT_DECOR[k]))sim.placeItem(TT_DECOR[k]);}so.owned.duck=1;sim.syncGeom();sim.rebuildObst();bustRoomCache();rebuildTray();radioSync();return true;}
    if(name==="placeDecor"||name==="unplaceDecor"||name==="rotateDecor"){var j=Math.floor(+args[0]);if(!(j>=0&&j<TT_DECOR.length))throw new Error("bad i");var id3=TT_DECOR[j],r3;
      if(name==="placeDecor"){var px=+args[1],py=+args[2];if(!isFinite(px)||!isFinite(py))throw new Error("bad xy");r3=sim.placed(id3)?sim.moveItem(id3,px,py):sim.placeItem(id3,px,py);}
      else if(name==="unplaceDecor")r3=sim.unplace(id3);else r3=sim.rotateItem(id3);
      bustRoomCache();messVer++;rebuildTray();radioSync();return r3;}
    if(name==="duck"){var on=+args[0];if(!isFinite(on))throw new Error("bad on");return sim.putDuck(on>0);}
    var dd=sim.s.decor;
    if(name==="radioPower"){sim.setBox("radio",sim.s.box.radio>0?0:1);radioSync();return true;}
    if(name==="radioSt"||name==="radioVol"){var rv=Math.floor(+args[0]);if(!isFinite(rv))throw new Error("bad v");if(name==="radioSt")dd.radioSt=Math.max(0,Math.min(2,rv));else dd.radioVol=Math.max(0,Math.min(10,rv));radioSync();return true;}
    if(name==="radioNear"){dd.radioNear=dd.radioNear?0:1;radioSync();return true;}
    throw new Error("unknown "+name);},
  render:function(){drawScene(performance.now());}};
var TT_DECOR=["plant","lamp","radio","rug","tvArmchair","kitchenMat","runner","roundRug","clock","poster","fan","shelf"];
function ttDecorState(){var s=sim.s,d=s.decor||{},pl={},i,id,q,f=sim.decorEffects?sim.decorEffects():null;
  for(i=0;i<TT_DECOR.length;i++){id=TT_DECOR[i];if(sim.placed(id)){q=sim.placeOf(id);pl[id]=[Math.round(q.x*10)/10,Math.round(q.y*10)/10,q.r|0];}}
  var m=function(v){return Math.round(v*1000)/1000;};
  return {placed:pl,duckIn:sim.duckOn()?1:0,radio:{on:s.box.radio>0?1:0,st:d.radioSt|0,vol:d.radioVol|0,near:d.radioNear?1:0},
    fx:{energy:m(sim.energyMul()),hunger:m(sim.hungerMul()),work:m(sim.workMul()),walk:m(sim.walkDecor()),eat:m(sim.eatTime()),lazy:m(sim.s.g.lazy?sim.spd():0),food:sim.foodMax(),mess:m(sim.messF())},n:f?f.length:0};}
window.__PP_READY=true;
})();
