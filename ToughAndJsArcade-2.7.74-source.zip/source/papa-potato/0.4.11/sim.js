/* ===== Papa Potato 0.4.11 — simulation (0.4.11: 24 new decor items (wall, floor, table-top, wash room, basin, cosmetic themes), a TABLE SINK built into the peel table (hand hygiene + RINSE command), a MOOD meter that decor lifts. Save v13, loads v1-v12. Was 0.4.10: decor with real effects: radio music, 4 carpets, wall clock, poster, fan, pantry shelf, rubber duck). Was 0.4.9. Save v12, loads v1-v11. ===== */
var PPSim=(function(){
  var RW=108,RH=280;                    /* 0.4: longer and slightly wider. x,y in the save are fractions of this */
  var PACE=["CHILL","EASY","STEADY","BRISK","GRIND"];
  var SPD=[0.6,0.8,1.0,1.25,1.5];      /* work + walk speed */
  var DRN=[0.55,0.75,1.0,1.45,2.0];    /* hunger + energy drain */
  var STYLE=[{n:"NEAT",sp:0.8,peels:2},{n:"NORMAL",sp:1.0,peels:3},{n:"QUICK",sp:1.3,peels:5}];
  var C={
    walk:34,            /* room units / s (0.2: 18 in a 150-tall room; 0.3's room is taller so he walks faster) */
    grab:0.7, peel:6.0, drop:0.5, eat:3.0,
    meal:55, foodPrice:8, foodMax:9,
    hungerDrain:0.30, hungerDrainNap:0.10,
    energyDrain:0.42,
    napRegen:6.0, lazyNapRegen:4.0, napWake:98,
    value:2, sloppyValue:1, washValue:3, sloppyWashValue:2,   /* 0.4.3: unwashed 2c (same as 0.4.2), washed (pool or sink) 3c full pay; sloppy 1c / 2c */
    lazyLow:25, lazySpeed:0.5,
    startCoins:0, startFood:1,
    chuteCap:6, tPipe:1.6,              /* a full chute's batch spends tPipe in the pipe, then spills out of the return chute */
    peelPer:3, peelPerSloppy:5, peelMax:200, messFull:90, messMax:0.30,
    sweepRate:6, sweepWind:0.8, sweepTidy:0.10,
    priceGrow:1.05, priceCap:14, priceEvery:900,
    potBase:6, potLegacy:9, potPrice0:15, potPriceGrow:1.4
  };
  var POTS=[4,8,12,16,24,32,48,64,96,128,160,200,250,300,400,500,650,800];
  var POT_MAX=POTS.length-1;
  var POT_LOCK=9999; /* t1193: kitchen raw-pile stock is locked very high; visual draw stays capped */
  var POT_SLIDER=false; /* t1193: hide the POTATOES IN PLAY slider; command stays in the table */
  /* ---- room geometry (units; room = 100 wide x 240 tall). The renderer draws from these; the router avoids OBST. ---- */
  var GEO={WALL:7,INFL:9,
    ship:{x:54,lip:22,top:2,mouth:18},                 /* FIXED: shipping chute hangs from the top wall */
    /* 0.4.1 default layout: work loop uses the mid-room so a fitted view is not a long empty hallway */
    table:{x0:36,y0:112,x1:70,y1:130},
    cooler:{x0:80,y0:108,x1:94,y1:118},
    stool:{x:87,y:154},   /* 0.4.3: sits clear of the cooler so he can eat at the cooler front */
    mat:{x:74,y:200,w:32,h:18},
    pile:{cx:54,base:258,rx:45,rz:14},                 /* FIXED */
    ret:{wallX:101,mouthX:86,y:244,w:9},               /* FIXED: return chute */
    mess:{cx:53,cy:146,rx:22,rz:14},
    peeler:{x:22,y:52},
    beltX:22,beltY0:66,beltY1:246,
    outBeltY:52,outBeltX0:31,outBeltX1:59.4,
    shipBeltX:54,shipBeltY0:28.5,shipBeltY1:36.6,
    suction:{x:22,y:255},
    spill:{x:34,y:68},
    sink:{x:26,y:150},
    broom:{x:96,y:150},
    bag:{x:40,y:248},
    cot:{x:74,y:222},
    rug:{x:68,y:168},
    tv:{x:68,y:164},
    lamp:{x:96,y:154},
    radio:{x:96,y:142},
    plant:{x:50,y:170},
    betterPeeler:{x:60,y:121},
    smallCooler:{x:92,y:90},
    /* 0.4.10 decor defaults (the editor spirals out to a free spot if these are taken) */
    kitchenMat:{x:53,y:141},runner:{x:44,y:196},roundRug:{x:62,y:168},
    clock:{x:80,y:3.5},poster:{x:94,y:3.5},fan:{x:96,y:182},shelf:{x:90,y:72},
    /* 0.4.11 decor defaults (wall items snap to the nearest free wall spot; floor items spiral out to a free spot) */
    window:{x:3.5,y:60},spiceRack:{x:104.5,y:70},coatHook:{x:12,y:3.5},calendar:{x:3.5,y:84},potsPans:{x:104.5,y:96},photos:{x:3.5,y:110},
    stringLights:{x:86,y:3.5},neonSign:{x:104.5,y:40},trophyShelf:{x:3.5,y:136},
    sideTable:{x:20,y:96},compost:{x:16,y:150},sackPile:{x:96,y:232},bookshelf:{x:84,y:14},catBed:{x:20,y:206},statue:{x:98,y:92},
    fruitBowl:{x:20,y:96},cookbook:{x:20,y:96},aquarium:{x:20,y:96}};
  var GEO0=JSON.parse(JSON.stringify(GEO));
  var FIXED=["pile","ret","ship"]; /* editor must never move these */
  var TOOLS=["betterPeeler","carryBag","broomDustpan"];
  var PLACEABLES=["sink","smallCooler","basicCot","conveyor","suction","plant","lamp","autoPeeler","outConveyor","radio","rug","tvArmchair","kitchenMat","runner","roundRug","clock","poster","fan","shelf",
    "window","spiceRack","coatHook","calendar","potsPans","photos","stringLights","neonSign","trophyShelf","sideTable","compost","sackPile","bookshelf","catBed","statue","fruitBowl","cookbook","aquarium","towelRack","soap","mopBucket"];
  var RUGS=["rug","kitchenMat","runner","roundRug"];   /* 0.4.10 carpets: walkable, never block, may slide under furniture, never on each other */
  var WALLS=["clock","poster","window","spiceRack","coatHook","calendar","potsPans","photos","stringLights","neonSign","trophyShelf"];   /* wall items: hang on the north / east / west wall, never on the floor */
  var TOPS=["fruitBowl","cookbook","aquarium"];          /* 0.4.11 table-top items: sit in a slot on the SIDE TABLE (2) or the food cooler lid (1); no floor footprint */
  var WASHW=["towelRack","soap"];                       /* 0.4.11 wash-room wall items: north wall (off the door and ship opening) or west wall */
  var WASHF=["mopBucket"];                              /* 0.4.11 wash-room floor items: off the basin, canal, outlet, door and his walking lane */
  var BASIN=["duck","toyBoat","bubbles"];               /* float in the wash basin, put in from INV */
  var FLOOR11=["sideTable","compost","sackPile","bookshelf","catBed","statue"];
  var THEMES={wall:["CLASSIC","MINT STRIPE","ROSE TILE","NAVY PANEL"],floor:["CLASSIC","BLACK + WHITE","TERRACOTTA","OAK PLANK"]};
  function isTop(id){return TOPS.indexOf(id)>=0;}
  function isWashItem(id){return WASHW.indexOf(id)>=0||WASHF.indexOf(id)>=0;}
  function isWashWall(id){return WASHW.indexOf(id)>=0;}
  function isBasin(id){return BASIN.indexOf(id)>=0;}
  function isRug(id){return RUGS.indexOf(id)>=0;}
  function isWall(id){return WALLS.indexOf(id)>=0;}
  var STARTER=["table","cooler","stool","mat"];
  function isTool(id){return TOOLS.indexOf(id)>=0;}
  function isPlaceable(id){return PLACEABLES.indexOf(id)>=0;}
  /* 0.4.2: rotation in 90-degree steps. rot(dx,dy,r) turns an offset clockwise r quarter turns (screen coords, +y down). */
  function rot(dx,dy,r){r=((r|0)%4+4)%4;if(r===1)return [-dy,dx];if(r===2)return [-dx,-dy];if(r===3)return [dy,-dx];return [dx,dy];}
  function tableKids(){
    var T=GEO.table,cx=(T.x0+T.x1)/2,cy=(T.y0+T.y1)/2,r=GEO.table.r|0,odd=r&1;
    var tw=odd?(T.y1-T.y0):(T.x1-T.x0),th=odd?(T.x1-T.x0):(T.y1-T.y0);       /* unrotated slab size */
    var bw=Math.min(18,tw-12),bh=Math.min(11,th-6);
    /* board in the unrotated frame (offsets from the centre), then turned with the table */
    var b0x=-tw/2+4,b0y=-th/2+3.5,c=rot(b0x+bw/2,b0y+bh/2,r),hw=(odd?bh:bw)/2,hh=(odd?bw:bh)/2;
    var board={x0:cx+c[0]-hw,y0:cy+c[1]-hh,x1:cx+c[0]+hw,y1:cy+c[1]+hh};
    var kn=rot(b0x+bw+3,0,r);
    var skx=tw/2-3.6,sc0=rot(skx,0,r),shw=(odd?3.5:2.0),shh=(odd?2.0:3.5);   /* 0.4.11 TABLE SINK: built into the far end of the slab, past the knife */
    var st=GEO.tableStand||{x:cx,y:T.y1+10,dir:0,side:0};
    var nx=st.side===1?0:st.side===2?-1:st.side===3?1:0,ny=st.side===0?1:st.side===1?-1:0;
    return {
      cx:cx,cy:cy,r:r,
      board:board,
      knife:{x:cx+kn[0],y:cy+kn[1],ok:b0x+bw+6<tw/2-1},
      sink:{x:cx+sc0[0],y:cy+sc0[1],hw:shw,hh:shh,r:r},
      peelSpawn:{x:st.side===2?T.x0-2:st.side===3?T.x1+2:cx,y:st.side===0?T.y1+2:st.side===1?T.y0-2:cy,nx:nx,ny:ny},
      stand:{x:st.x,y:st.y,dir:st.dir,side:st.side}
    };
  }
  function bedside(){
    if(GEO.bedSide)return {x:GEO.bedSide.x,y:GEO.bedSide.y,dir:0};
    var m=GEO.mat,c=[[0,m.h/2+GEO.INFL+3],[0,-(m.h/2+GEO.INFL+3)],[-(m.w/2+GEO.INFL+3),0],[m.w/2+GEO.INFL+3,0]],i,x,y;
    for(i=0;i<4;i++){x=m.x+c[i][0];y=m.y+c[i][1];if(x>GEO.WALL+3&&x<RW-GEO.WALL-3&&y>GEO.WALL+3&&y<RH-GEO.WALL-3&&(i===0||freePtX(x,y,"bed")))return {x:x,y:y,dir:0};}
    return {x:m.x,y:m.y+m.h/2+GEO.INFL+3,dir:0};
  }
  function freePtX(x,y,skip){for(var j=0;j<OBST.length;j++){var o=OBST[j];if(o.id===skip)continue;var I=GEO.INFL;if(x>o.x0-I&&x<o.x1+I&&y>o.y0-I&&y<o.y1+I)return false;}return true;}
  var OBST=[{id:"table",x0:GEO.table.x0,y0:GEO.table.y0,x1:GEO.table.x1,y1:GEO.table.y1},{id:"cooler",x0:GEO.cooler.x0,y0:GEO.cooler.y0,x1:GEO.cooler.x1,y1:GEO.cooler.y1}];
  var SPOT={
    ship:{x:54,y:32,dir:0},  /* 0.4.7: right at the belt end, facing the scanner */
    table:{x:53,y:140,dir:0},
    food:{x:87,y:130,dir:0},
    mat:{x:74,y:221,dir:0},
    sweep:{x:53,y:146,dir:0},
    pile:{y:233,x0:28,x1:80},
    sink:{x:26,y:162,dir:0},
    tv:{x:60,y:176,dir:1},
    radio:{x:88,y:142,dir:1},
    plant:{x:50,y:182,dir:0},
    lamp:{x:88,y:154,dir:1},
    cot:{x:74,y:234,dir:0},
    bag:{x:40,y:242,dir:2}};
  var SPOT0=JSON.parse(JSON.stringify(SPOT));
  function copyBox(a,b){var k;for(k in b){if(b[k]&&typeof b[k]==="object"){if(!a[k])a[k]={};copyBox(a[k],b[k]);}else a[k]=b[k];}}
  /* ---- the command table: ONE source for the panel, the sim's BOX limits and the HELP screen ---- */
  var COMMANDS=[
    {id:"pace",does:"How fast he walks and works.",affects:"Speed x0.6 up to x1.5. Faster drains hunger and energy faster (x0.55 up to x2.0).",hi:"GRIND",lo:"CHILL",name:"WORK PACE",min:0,max:4,step:1,def:2,
      what:"How fast he walks and works.",
      effect:"Faster pace = more potatoes per minute, but hunger and energy drain faster. CHILL x0.6 speed (0.55 drain) up to GRIND x1.5 speed (2.0 drain).",
      range:"5 steps: CHILL, EASY, STEADY, BRISK, GRIND"},
    {id:"eat",does:"Sends him to eat when he gets hungry.",affects:"Hunger under the number = go eat (1 food = +55 hunger). OFF = never.",hi:"70%",lo:"OFF",name:"EAT WHEN HUNGER <",min:0,max:70,step:5,def:0,
      what:"Sends him to the cooler to eat when his hunger drops below the number.",
      effect:"Higher = he eats sooner and never gets hungry. Eating takes 3 s and uses 1 food (+55 hunger). OFF = he never eats on his own and goes lazy at 25%.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"nap",does:"Sends him to bed when he gets tired.",affects:"Energy under the number = go nap. OFF = he dozes on the floor instead.",hi:"70%",lo:"OFF",name:"NAP WHEN ENERGY <",min:0,max:70,step:5,def:0,
      what:"Sends him to the bed to nap when his energy drops below the number.",
      effect:"Higher = he naps sooner. OFF = he never goes to bed and dozes on the floor when he gets too tired. Pair it with NAP UNTIL.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"clean",does:"Sends him to sweep up peels.",affects:"Peels over the number = sweep. Lower = tidier floor but more sweeping.",hi:"90",lo:"OFF",name:"CLEAN WHEN PEELS >",min:0,max:90,step:5,def:0,
      what:"Sends him to sweep when the peel count on the floor goes over the number.",
      effect:"Lower = he sweeps earlier and keeps the floor clean, but spends more time sweeping. He sweeps until the floor is nearly clear (under 10% of the trigger). OFF = never. Peels slow him up to 30% at 90 peels.",
      range:"OFF, 5 to 90 peels (step 5)"},
    {id:"rinse",does:"Rinses his hands at the table sink.",affects:"Clean hands under the number = rinse (1 s, at the table). Under 25% his hands are sticky: peeling 15% slower.",hi:"70%",lo:"OFF",name:"RINSE WHEN HANDS <",min:0,max:70,step:5,def:30,
      what:"Sends him to rinse his hands at the TABLE SINK (built into the peel table) when his clean hands drop below the number.",
      effect:"Peeling makes his hands dirty. Rinsing takes about 1 second right at the table and brings CLEAN HANDS back to 100%. Under 25% his hands are sticky and peeling is 15% slower. OFF = he never rinses.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"pot",does:"How many potatoes are in the loop.",affects:"More = bigger pile, no waiting. The top of the slider is what you own (buy more in the SHOP).",hi:"OWNED",lo:"4",name:"POTATOES IN PLAY",min:0,max:POT_MAX,step:1,def:6,dyn:"potCap",
      what:"How many potatoes are in the loop (pile + hands + chute + pipe).",
      effect:"The kitchen pile is fully stocked (9999 potatoes in the loop). The POTATOES IN PLAY slider is hidden, not deleted. Visual pile drawing stays capped for perf.",
      range:"Locked at 9999 (slider hidden)"},
    {id:"style",does:"How carefully he peels.",affects:"NEAT: slow, 2 peels. NORMAL: 3 peels. QUICK: fast, 5 peels (messy).",hi:"QUICK",lo:"NEAT",name:"PEEL STYLE",min:0,max:2,step:1,def:1,
      what:"How carefully he peels.",
      effect:"NEAT x0.8 speed, 2 peels per potato (clean floor). NORMAL x1.0, 3 peels. QUICK x1.3 speed, 5 peels per potato (fast but very messy).",
      range:"3 steps: NEAT, NORMAL, QUICK"},
    {id:"wake",does:"How rested he is when he gets up.",affects:"Lower = short naps, back to work sooner. 100% = fully rested. Needs NAP WHEN.",hi:"100%",lo:"50%",name:"NAP UNTIL ENERGY >",min:50,max:100,step:10,def:100,
      what:"How rested he is before he gets up from a nap.",
      effect:"Lower = short naps, back to work sooner (but he tires again sooner). 100% = sleeps until fully rested. Only matters if NAP WHEN is set.",
      range:"50% to 100% (step 10)"},
    {id:"autob",does:"Buys food for you.",affects:"Keeps at least this many cans stocked while you have the coins. OFF = buy in the SHOP.",hi:"9",lo:"OFF",name:"KEEP FOOD AT LEAST",min:0,max:9,step:1,def:0,
      what:"Automatically buys food (at the shop price) whenever you have fewer cans than the number and enough coins.",
      effect:"Higher = he never runs out, but it spends your coins as soon as they come in. OFF = you buy food yourself in the SHOP. Cannot go over the cooler size.",
      range:"OFF, 1 to 9 food (step 1)"},
    {id:"suction",does:"Auto suction on the pile intake.",affects:"ON pulls potatoes from the pile onto the inbound conveyor. Needs the suction unit in the shop.",hi:"ON",lo:"OFF",name:"SUCTION",min:0,max:1,step:1,def:0,fmt:"onoff",need:"suction",
      what:"Turns the auto suction intake on the pile on or off.",
      effect:"ON = potatoes are pulled from the pile onto the inbound conveyor (if that belt is on). OFF = the pile sits still and he can still grab by hand.",
      range:"OFF or ON"},
    {id:"conveyor",does:"Inbound conveyor, pile to the auto-peeler.",affects:"Speed of the inbound belt. OFF = stopped. Needs the conveyor in the shop.",hi:"FAST",lo:"OFF",name:"CONVEYOR SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"conveyor",
      what:"How fast the inbound belt carries raw potatoes from the suction intake to the auto-peeler.",
      effect:"OFF = the belt is stopped. SLOW / STEADY / FAST change how quickly potatoes reach the peeler. Needs the conveyor bought.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"apeeler",does:"The auto-peeler.",affects:"How fast it peels each potato. OFF = idle. Needs the auto-peeler in the shop.",hi:"FAST",lo:"OFF",name:"AUTO-PEELER SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"autoPeeler",
      what:"Turns the auto-peeler on and sets how fast it peels.",
      effect:"OFF = potatoes wait on the inbound belt. SLOW / STEADY / FAST peel faster and shoot more peels onto the floor (always inside the room). Capacity grows with the peeler upgrade.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"outbelt",does:"Outbound conveyor into shipping.",affects:"Speed of the belt from the peeler into the shipping intake. OFF = stopped.",hi:"FAST",lo:"OFF",name:"OUT-CONVEYOR SPEED",min:0,max:3,step:1,def:0,fmt:"speed",need:"outConveyor",
      what:"How fast peeled potatoes ride from the auto-peeler into the shipping unit.",
      effect:"OFF = the peeler holds finished potatoes and shipping receives nothing. SLOW / STEADY / FAST. The belt butts the shipping intake and never draws over it.",
      range:"OFF, SLOW, STEADY, FAST"},
    {id:"lamp",does:"The floor lamp.",affects:"ON lights the living nook. Needs the lamp bought.",hi:"ON",lo:"OFF",name:"LAMP",min:0,max:1,step:1,def:0,fmt:"onoff",need:"lamp",
      what:"Turns the floor lamp on or off.",
      effect:"ON = a warm light pool in the living nook (looped shade). OFF = dark. Decoration with a real on/off, no other stat effect.",
      range:"OFF or ON"},
    {id:"radio",does:"The radio.",affects:"ON = music (energy drains 20% slower, works 5% faster). Pick a station or your own songs with the RADIO button.",hi:"ON",lo:"OFF",name:"RADIO",min:0,max:1,step:1,def:0,fmt:"onoff",need:"radio",
      what:"Turns the radio on or off. When it's on he will walk over and tune it now and then.",
      effect:"ON = music plays through the little radio: energy drains 20% slower (10% in the wash room) and he works 5% faster. He walks to it to tune. OFF = silent.",
      range:"OFF or ON"},
    {id:"tv",does:"The TV.",affects:"ON plays a looped picture. Pair with WATCH WHEN.",hi:"ON",lo:"OFF",name:"TV",min:0,max:1,step:1,def:0,fmt:"onoff",need:"tvArmchair",
      what:"Turns the TV on or off. The screen only glows when ON.",
      effect:"ON = the set plays (looped frames). He sits in the armchair and watches when WATCH WHEN ENERGY < is set. Watching restores energy slowly, not as fast as a nap.",
      range:"OFF or ON"},
    {id:"watch",does:"Sends him to watch TV when he gets a little tired.",affects:"Energy under the number = go watch (needs TV on and the armchair). OFF = never.",hi:"70%",lo:"OFF",name:"WATCH WHEN ENERGY <",min:0,max:70,step:5,def:0,fmt:"pct",need:"tvArmchair",
      what:"Sends him to sit in the armchair and watch TV when his energy drops below the number.",
      effect:"Only works if you bought the TV + armchair and TV is ON. Restores energy slowly (weaker than a nap). OFF = he never watches on his own.",
      range:"OFF, 5% to 70% (step 5)"},
    {id:"water",does:"Sends him to water the plant when it dries out.",affects:"Dryness over the number = water. OFF = never. Needs the plant.",hi:"80",lo:"OFF",name:"WATER WHEN DRY >",min:0,max:90,step:10,def:0,fmt:"dry",need:"plant",
      what:"Sends him to water the plant when its dryness goes over the number.",
      effect:"The plant dries slowly over time. If it gets too dry it droops (off look). Watering brings it back. OFF = he never waters it.",
      range:"OFF, 10 to 90 dryness (step 10)"},
    {id:"wash",does:"Sends him to the sink with a raw potato for a cleaner peel.",affects:"ON = he washes a potato at the sink before peeling (worth +1c). Needs the sink.",hi:"ON",lo:"OFF",name:"WASH BEFORE PEEL",min:0,max:1,step:1,def:0,fmt:"onoff",need:"sink",
      what:"When ON, he walks a raw potato to the sink and washes it before he peels.",
      effect:"A washed potato ships at full pay (3c) instead of 2c (still 1c / 2c if sloppy) from the kitchen chute. Takes a few seconds at the sink. Needs the sink bought.",
      range:"OFF or ON"},
    {id:"awash",does:"After peeling, he places potatoes in the kitchen scanner; they come out the wash-room machine into the basin.",affects:"ON = he drops peeled potatoes in the kitchen wall hole and they come out into the wash-room pool (3c through the ship hole). OFF = they pay 2c at that same kitchen hole. Needs AUTO-WASH and the key.",hi:"ON",lo:"OFF",name:"AUTO-WASH",min:0,max:1,step:1,def:0,fmt:"onoff",need:"autoWash",
      what:"When ON, he places peeled potatoes in the kitchen X-ray scanner; they come out the matching wash-room machine into the basin and the canal carries them to the ship opening at full pay.",
      effect:"ON = 3c washed path, on his own, after each peel (and for the auto-line too). OFF = kitchen chute at 2c (or 3c if already sink-washed). Needs AUTO-WASH bought and the ROOM KEY.",
      range:"OFF or ON"}
  ];
  var BOX={};for(var ci=0;ci<COMMANDS.length;ci++){var cm=COMMANDS[ci];BOX[cm.id]={min:cm.min,max:cm.max,step:cm.step,def:cm.def};}
  /* ---- the shop ---- */
  var UPS=[
    {id:"peeler",name:"SHARP PEELER",max:3,prices:[40,110,260],fx:"Peeling takes 15% less time per level."},
    {id:"boots",name:"GOOD BOOTS",max:3,prices:[30,90,220],fx:"Walks 10% faster per level."},
    {id:"chute",name:"BIGGER CHUTE",max:3,prices:[35,100,240],fx:"Drops go in 30% quicker and each batch holds 2 more potatoes per level."},
    {id:"pantry",name:"BIGGER COOLER",max:2,prices:[25,80],fx:"The cooler holds 3 more food per level (9, then 12, then 15)."},
    {id:"broom",name:"STIFF BROOM",max:3,prices:[30,90,200],fx:"Sweeps 50% faster per level."},
    {id:"mat",name:"SOFT BED",max:2,prices:[30,90],fx:"Naps restore energy 35% faster per level."},
    {id:"apeeler",name:"FASTER AUTO-PEELER",max:3,prices:[50,140,300],fx:"Auto-peeler works 20% faster and holds 1 more potato per level."},
    {id:"belts",name:"BETTER BELTS",max:3,prices:[40,120,260],fx:"All conveyor belts run 15% faster per level."},
    {id:"bag",name:"BIGGER CARRY BAG",max:2,prices:[25,80],fx:"He can carry 1 extra potato per level (2, then 3)."},
    {id:"channel",name:"WIDER CHANNEL",max:2,prices:[70,180],fx:"The canal is very slow at first. Each level makes the current meaningfully faster and the canal a little wider. Level 2 also pulls nearby potatoes in from farther."}
  ];

  /* ---- 0.4 shop items (unlocked by level, then bought). Unused stay in the table, hidden in the shop until unlocked. ---- */
  var ITEMS=[
    {id:"roomKey",name:"ROOM KEY",lv:1,price:40,group:"starter",kind:"key",fx:"Unlocks the metal door. Behind it is a wash room. Peeled potatoes go into the kitchen X-ray scanner, which sends them through the wall; they come out a matching machine at the bottom of the wash room into a basin, and a canal along the right wall carries them to a ship opening (3c). Unwashed still ship at the kitchen scanner for 2c."},
    {id:"betterPeeler",name:"BETTER PEELER",lv:1,price:20,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa. Peeling is 10% faster while equipped."},
    {id:"carryBag",name:"SMALL CARRY BAG",lv:1,price:18,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa to carry 2 potatoes at a time (3 / 4 with upgrades)."},
    {id:"sink",name:"SINK",lv:1,price:25,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. WASH BEFORE PEEL dumps raw potatoes here so they already count as washed and ship at full pay (3c) from the kitchen chute."},
    {id:"broomDustpan",name:"SMALL BROOM + DUSTPAN",lv:1,price:16,group:"starter",kind:"tool",fx:"Goes to your inventory. Equip it on Papa. He sweeps at the peel mess, broom on the peels. Stiff Broom still upgrades speed."},
    {id:"smallCooler",name:"SMALL COOLER",lv:1,price:22,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Adds 2 food slots. Hums when stocked."},
    {id:"basicCot",name:"BASIC COT",lv:1,price:28,group:"starter",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. A second bed he can nap on (enters from the side)."},
    {id:"kitchenMat",name:"KITCHEN MAT",lv:1,price:12,group:"decor",kind:"place",fx:"CARPET. Energy drains 30% slower while he stands on it. Best under his peel spot."},
    {id:"clock",name:"WALL CLOCK",lv:1,price:10,group:"decor",kind:"place",fx:"WALL. Shows the shift time. Meal breaks are 30% shorter (he watches the clock)."},
    {id:"conveyor",name:"CONVEYOR",lv:2,price:70,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Inbound belt from the pile toward the auto-peeler."},
    {id:"suction",name:"AUTO SUCTION",lv:2,price:55,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Swarm-style intake on the pile."},
    {id:"plant",name:"PLANT",lv:2,price:15,group:"decor",kind:"place",fx:"Fresh air: energy drains 10% slower in the kitchen while it is watered. Set WATER WHEN DRY."},
    {id:"lamp",name:"LAMP",lv:2,price:14,group:"decor",kind:"place",fx:"Good light: peeling is 8% faster while LAMP is ON."},
    {id:"runner",name:"RUNNER RUG",lv:2,price:20,group:"decor",kind:"place",fx:"CARPET. He walks 15% faster on it. Lay it on his pile / table / scanner path."},
    {id:"poster",name:"PAPA POSTER",lv:2,price:16,group:"decor",kind:"place",fx:"WALL. Papa of the Month. When he goes AUTO-LAZY he still works at 70% speed, not 50%."},
    {id:"shelf",name:"PANTRY SHELF",lv:2,price:24,group:"decor",kind:"place",fx:"+2 food can storage. The cans sit on the shelf."},
    {id:"autoPeeler",name:"AUTO-PEELER",lv:3,price:120,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Peels shoot onto the floor inside the room."},
    {id:"outConveyor",name:"OUT-CONVEYOR",lv:3,price:80,group:"machine",kind:"place",fx:"Goes to your inventory. Drag it into the room from EDIT. Belt into the shipping intake."},
    {id:"radio",name:"RADIO",lv:3,price:22,group:"decor",kind:"place",fx:"Music ON: energy drains 20% slower and he works 5% faster. Two built-in stations or your own songs (RADIO button)."},
    {id:"rug",name:"RUG",lv:3,price:18,group:"decor",kind:"place",fx:"CARPET. Hunger drains 20% slower while he stands on it. Slides under furniture."},
    {id:"fan",name:"FLOOR FAN",lv:3,price:26,group:"decor",kind:"place",fx:"Cool air: the peel mess slows him at most 15% instead of 30%. Always on."},
    {id:"duck",name:"RUBBER DUCK",lv:3,price:12,group:"decor",kind:"duck",fx:"WASH ROOM. Put it in the basin from INV. The current pulls potatoes off the heap 25% faster. Needs the ROOM KEY."},
    {id:"tvArmchair",name:"TV + ARMCHAIR",lv:4,price:90,group:"decor",kind:"place",fx:"TV ON + WATCH WHEN ENERGY < : he sits and gets energy back (slower than a nap)."},
    {id:"roundRug",name:"ROUND BRAID RUG",lv:4,price:30,group:"decor",kind:"place",fx:"CARPET. Grabbing, peeling and dropping are 8% faster while he stands on it."},
    {id:"autoWash",name:"AUTO-WASH",lv:4,price:220,group:"machine",kind:"toggle",fx:"An expensive late upgrade. Once bought, the AUTO-WASH command appears. When ON, he places peeled potatoes in the kitchen X-ray scanner; they come out the matching wash-room machine into the basin, then ride the canal to the ship opening (3c). Needs the ROOM KEY."},
    /* ---- 0.4.11 decor (Jay t1205). cat: wall / floor / top / wash / basin / theme ---- */
    {id:"coatHook",name:"COAT HOOK + APRON",lv:1,price:10,group:"decor",kind:"place",cat:"wall",fx:"WALL. Papa's apron. QUICK peeling drops 4 peels a potato, not 5."},
    {id:"calendar",name:"CALENDAR",lv:1,price:8,group:"decor",kind:"place",cat:"wall",fx:"WALL. Shows the shift day. Each new shift day (every 24 shift hours) pays a 10c payday."},
    {id:"spiceRack",name:"SPICE RACK",lv:1,price:12,group:"decor",kind:"place",cat:"wall",fx:"WALL. Tastier meals: each food can gives +65 hunger, not +55."},
    {id:"window",name:"WINDOW + CURTAINS",lv:1,price:14,group:"decor",kind:"place",cat:"wall",fx:"WALL. Daylight (6 AM to 8 PM shift time): he works 4% faster."},
    {id:"sideTable",name:"SIDE TABLE",lv:1,price:12,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Holds 2 table-top items (fruit bowl, cookbook, aquarium)."},
    {id:"compost",name:"COMPOST BIN",lv:1,price:16,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Short trip to the bin: sweeping is 25% faster, and every 20 peels swept turn into 1c of compost."},
    {id:"fruitBowl",name:"FRUIT BOWL",lv:1,price:10,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP (side table or cooler lid). He snacks: hunger drains 10% slower in the kitchen."},
    {id:"wallpaper",name:"WALLPAPER BOOK",lv:1,price:15,group:"decor",kind:"theme",cat:"theme",fx:"COSMETIC ONLY. Kitchen walls: CLASSIC, MINT STRIPE, ROSE TILE or NAVY PANEL. Change it in INV."},
    {id:"potsPans",name:"HANGING POTS + PANS",lv:2,price:18,group:"decor",kind:"place",cat:"wall",fx:"WALL. Cooking at home: food cans cost 1c less."},
    {id:"photos",name:"FRAMED POTATO PHOTOS",lv:2,price:14,group:"decor",kind:"place",cat:"wall",fx:"WALL. Family photos keep his spirits up: he only goes AUTO-LAZY under 20%, not 25%."},
    {id:"sackPile",name:"POTATO SACK PILE",lv:2,price:18,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Spare sacks by the pile: grabbing potatoes is 20% faster."},
    {id:"cookbook",name:"COOKBOOK STAND",lv:2,price:16,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP. NEAT peeling works at 90% speed, not 80%."},
    {id:"towelRack",name:"TOWEL RACK",lv:2,price:14,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM WALL. Dry hands: energy drains 15% slower while he is in the wash room. Needs the ROOM KEY."},
    {id:"soap",name:"SOAP DISPENSER",lv:2,price:12,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM WALL. Soapy water: the current pulls potatoes off the basin heap 15% faster. Needs the ROOM KEY."},
    {id:"mopBucket",name:"MOP BUCKET",lv:2,price:12,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM FLOOR. Dry floor: he walks 10% faster in the wash room. Needs the ROOM KEY."},
    {id:"floorTiles",name:"FLOOR TILES",lv:2,price:20,group:"decor",kind:"theme",cat:"theme",fx:"COSMETIC ONLY. Kitchen floor: CLASSIC, BLACK + WHITE, TERRACOTTA or OAK PLANK. Change it in INV."},
    {id:"stringLights",name:"STRING LIGHTS",lv:3,price:22,group:"decor",kind:"place",cat:"wall",fx:"WALL. Night shift (8 PM to 6 AM shift time): he works 4% faster. They twinkle."},
    {id:"neonSign",name:"NEON OPEN SIGN",lv:3,price:30,group:"decor",kind:"place",cat:"wall",fx:"WALL. Open for business: every 20th potato shipped gets a +1c tip."},
    {id:"bookshelf",name:"BOOKSHELF",lv:3,price:28,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Self-help books: buying the next LEVEL costs 10% less."},
    {id:"catBed",name:"CAT BED + CAT",lv:3,price:35,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. A cat wanders the kitchen and naps here. Purring: his naps restore energy 10% faster."},
    {id:"toyBoat",name:"TOY BOAT",lv:3,price:16,group:"decor",kind:"basin",cat:"basin",fx:"WASH BASIN. Put it in from INV. It rides the canal: the current is 15% stronger. Needs the ROOM KEY."},
    {id:"trophyShelf",name:"TROPHY SHELF",lv:4,price:40,group:"decor",kind:"place",cat:"wall",fx:"WALL. Shows your progress: one cup per level reached, a gold cup per 500 potatoes shipped (up to 3). He works 1% faster per cup."},
    {id:"aquarium",name:"AQUARIUM",lv:4,price:45,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP. Calm fish: hunger and energy drain 5% slower."},
    {id:"bubbles",name:"BUBBLE MAKER",lv:4,price:24,group:"decor",kind:"basin",cat:"basin",fx:"WASH BASIN. Put it in from INV. Sloppy potatoes that ship through the wash room pay the full 3c. Needs the ROOM KEY."},
    {id:"statue",name:"PAPA STATUE",lv:5,price:60,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. A golden potato Papa. Pride: he works 5% faster."}
  ];
  var ITEMI={};for(var ii=0;ii<ITEMS.length;ii++){var it0=ITEMS[ii];ITEMI[it0.id]=it0;if(!it0.cat)it0.cat=it0.group==='machine'?'machine':it0.group==='starter'?(it0.kind==='place'?'floor':it0.kind):(RUGS.indexOf(it0.id)>=0?'rug':WALLS.indexOf(it0.id)>=0?'wall':it0.kind==='duck'?'basin':'floor');}
  var LEVEL_PRICE=[0,0,80,160,280,450]; /* cost to BUY that level (reach Lv N). Max 5. */
  var BELT_SPD=[0,0.55,1.0,1.45];
  var SPEED_NAME=["OFF","SLOW","STEADY","FAST"];
  var UPI={};for(var ui=0;ui<UPS.length;ui++)UPI[UPS[ui].id]=UPS[ui];
  function upsFresh(){var o={};for(var i=0;i<UPS.length;i++)o[UPS[i].id]=0;return o;}
  /* ---- 0.4.8 wash room: peeled heap accumulates in the basin water under the outlet; the current peels it into the canal. Wash scanner is scaled to the same on-screen size as the kitchen scanner (world * WH/RH). Old dry west pile stays hidden (t1191). Top half stays empty (t1187). ---- */
  var WW=180,WH=400,WASH_LIVE=48,WASH_R=3.2,HEAP_VIS=36,HEAP_SPILL=24;
  var WASH={
    door:{x0:22,y0:7-0.6,w:24,h:20},
    intake:{x:90,y:32},          /* 0.4.3 north intake; hidden */
    ship:{x:150,y:32},           /* 0.4.3 north ship-out; hidden */
    pile:{cx:64,cy:230,rx:52,rz:50}, /* 0.4.x dry west pile; hidden in 0.4.8, not deleted */
    pool:{x:148,y:200,rx:16,ry:12}, /* 0.4.3 circular pool; hidden */
    mouth:{x:112,y:230},           /* 0.4.4 diagonal mouth; hidden */
    inlet:{x:90,y:400-7,r:14},     /* 0.4.5 south-wall inlet hole; hidden, not deleted */
    outlet:{x:90,boxW:23,boxH:21}, /* 0.4.8: same on-screen size as the 16x15 kitchen scanner (scale WH/RH) */
    land:{x:90,y:342,rx:36,ry:22}, /* basin just north of the larger outlet mouth, with a clear pour gap */
    bench:{y:352,x0:54,x1:126},    /* 0.4.5 floating bench; hidden, not deleted */
    elbow:{x:164,y:342},           /* canal turns north; same x as the ship opening (no diagonal stub) */
    hole:{x:164,y:20,r:14,w:30,h:20}, /* square ship opening, wider than lv2 canal, top-right */
    showProps:false,               /* t1187: top half stays empty for future machinery/decor; props stay, hidden */
    showDryPile:false,             /* t1191: old dry west pile stays in the file, hidden */
    crate:{x:30,y:88},             /* west-wall utility crates; hidden while showProps is false */
    crate2:{x:38,y:106},
    bucket:{x:28,y:150},           /* mop bucket; hidden while showProps is false */
    grate:{x:114,y:126,s:16},      /* floor drain; hidden while showProps is false */
    shelf:{x:100,y:16,w:28,h:8},   /* short north-wall shelf; hidden while showProps is false */
    doorSpot:{x:34,y:32,dir:0},
    kitDoor:{x0:17,y0:7-0.6,w:20,h:18.5},
    kitDoorSpot:{x:27,y:30,dir:0}
  };
  var WASH0=JSON.parse(JSON.stringify(WASH));
  function canalWidth(up){return 12+6*(up|0);}
  function streetWidth(up){return canalWidth(up);}
  function currentReach(up){return (up|0)<=0?0:((up|0)===1?12:22);}
  function streetFlow(up){return (up|0)<=0?10:((up|0)===1?32:62);}
  function heapPullRate(up){return (up|0)<=0?1.6:((up|0)===1?5:11);} /* potatoes/sec from the basin heap onto the canal */
  function heapCenter(){var L=WASH.land;return {x:L.x,y:L.y+L.ry*0.34};}
  function inCanalProper(x,y,up){if(inLanding(x,y))return false;var p=projectCanal(x,y);return !!(p&&p.d<=canalWidth(up)/2);}
  function inHeap(p){return !!(p&&!p.onStreet&&inLanding(p.x,p.y));}
  function washHeapCount(w){w=w||{pots:[],bulk:0};var n=w.bulk|0,i;for(i=0;i<(w.pots||[]).length;i++)if(inHeap(w.pots[i]))n++;return n;}
  function clampToBasin(p){if(!p||p.onStreet)return;var L=WASH.land,dx=(p.x-L.x)/L.rx,dy=(p.y-L.y)/L.ry,m=dx*dx+dy*dy;if(m>0.92){var sc=Math.sqrt(0.92/m);p.x=L.x+dx*L.rx*sc;p.y=L.y+dy*L.ry*sc;p.vx*=0.4;p.vy*=0.4;}}
  function canalPts(){return [{x:WASH.land.x,y:WASH.land.y},{x:WASH.elbow.x,y:WASH.elbow.y},{x:WASH.hole.x,y:WASH.hole.y}];}
  function mouthOf(){return {x:WASH.land.x,y:WASH.land.y};}
  function streetSeg(){var p=canalPts();return {x0:p[0].x,y0:p[0].y,x1:p[p.length-1].x,y1:p[p.length-1].y};}
  function distToSeg(x,y,s){var dx=s.x1-s.x0,dy=s.y1-s.y0,l=dx*dx+dy*dy||1,t=((x-s.x0)*dx+(y-s.y0)*dy)/l;t=t<0?0:t>1?1:t;var px=s.x0+dx*t,py=s.y0+dy*t,len=Math.sqrt(l);return {d:Math.hypot(x-px,y-py),px:px,py:py,t:t,nx:dx/len,ny:dy/len};}
  function projectCanal(x,y){
    var pts=canalPts(),best=null,acc=0,i,s,len,total=0,j;
    for(j=0;j<pts.length-1;j++)total+=Math.hypot(pts[j+1].x-pts[j].x,pts[j+1].y-pts[j].y)||1;
    for(i=0;i<pts.length-1;i++){
      len=Math.hypot(pts[i+1].x-pts[i].x,pts[i+1].y-pts[i].y)||1;
      s=distToSeg(x,y,{x0:pts[i].x,y0:pts[i].y,x1:pts[i+1].x,y1:pts[i+1].y});
      s.seg=i;s.len=len;s.progress=(acc+s.t*len)/total;s.total=total;
      /* at the elbow, prefer the segment farther along so potatoes turn the corner instead of pinning to the wall */
      if(!best||s.d<best.d-1.2||(s.d<=best.d+1.2&&s.progress>best.progress))best=s;
      acc+=len;
    }
    return best;
  }
  function pointAlongCanal(u){
    var pts=canalPts(),total=0,j,len,acc=0,t,d;
    u=u<0?0:u>1?1:u;
    for(j=0;j<pts.length-1;j++)total+=Math.hypot(pts[j+1].x-pts[j].x,pts[j+1].y-pts[j].y)||1;
    d=u*total;
    for(j=0;j<pts.length-1;j++){
      len=Math.hypot(pts[j+1].x-pts[j].x,pts[j+1].y-pts[j].y)||1;
      if(acc+len>=d||j===pts.length-2){
        t=(d-acc)/len;t=t<0?0:t>1?1:t;
        return {x:pts[j].x+(pts[j+1].x-pts[j].x)*t,y:pts[j].y+(pts[j+1].y-pts[j].y)*t};
      }
      acc+=len;
    }
    return {x:pts[pts.length-1].x,y:pts[pts.length-1].y};
  }
  function inLanding(x,y){var L=WASH.land,dx=(x-L.x)/L.rx,dy=(y-L.y)/L.ry;return dx*dx+dy*dy<=1;}
  function inStreet(x,y,up){var p=projectCanal(x,y);return !!(p&&p.d<=canalWidth(up)/2)||inLanding(x,y);}
  function inPool(x,y){return inLanding(x,y);}
  function washFresh(){return {pots:[],bulk:0,bulkW:0,bulkS:0,bulkSW:0,splash:[],heapSplash:[],pullAcc:0};}
  function shipPay(p){
    if(p&&p.sloppy)return p.washed?C.sloppyWashValue:C.sloppyValue;
    return (p&&p.washed)?C.washValue:C.value;
  }
  function washCount(w){w=w||{pots:[],bulk:0};return (w.pots?w.pots.length:0)+(w.bulk|0);}
  function ensureWash(s){if(!s.wash||typeof s.wash!=="object")s.wash=washFresh();
    if(!Array.isArray(s.wash.pots))s.wash.pots=[];if(!Array.isArray(s.wash.splash))s.wash.splash=[];if(!Array.isArray(s.wash.heapSplash))s.wash.heapSplash=[];
    s.wash.bulk=Math.max(0,s.wash.bulk|0);s.wash.bulkW=Math.max(0,s.wash.bulkW|0);
    s.wash.bulkS=Math.max(0,s.wash.bulkS|0);s.wash.bulkSW=Math.max(0,s.wash.bulkSW|0);
    if(s.viewRoom!=="wash")s.viewRoom="kitchen";if(s.followRoom==null)s.followRoom=null;
    if(!s.g)s.g={};if(s.g.where!=="wash")s.g.where="kitchen";
    if(!isFinite(+s.g.wx))s.g.wx=WASH.doorSpot.x;if(!isFinite(+s.g.wy))s.g.wy=WASH.doorSpot.y;
    if(!s.placeWash||typeof s.placeWash!=="object")s.placeWash={};}
  function hash(a,b){var x=Math.imul((Math.round(a*1000)|0)^0x9e3779b9,0x85ebca6b)^Math.imul((b|0)+1,0xc2b2ae35);x^=x>>>13;x=Math.imul(x,0x27d4eb2f);x^=x>>>15;x=Math.imul(x,0x165667b1);x^=x>>>16;return (x>>>0)/4294967296;}
  /* the spill schedule of one batch: when potato j leaves the return chute (ex) and when it comes to rest on the pile (ld). Pure function of (t0,n): sim and renderer share it. */
  function spill(t0,n){var ex=[],ld=[],t=t0+C.tPipe,pl=0;
    for(var j=0;j<n;j++){t+=(j===0?hash(t0,900)*0.25:0.10+hash(t0,j*7+1)*0.55);ex.push(t);
      var l=t+0.75+hash(t0,j*7+3)*0.6;if(l<pl+0.05)l=pl+0.05;ld.push(l);pl=l;}
    return {ex:ex,ld:ld};}
  /* ---- routing: shortest path round the inflated obstacles (visibility graph) ---- */
  function inflated(){var r=[],I=GEO.INFL;for(var i=0;i<OBST.length;i++){var o=OBST[i];r.push({x0:o.x0-I,y0:o.y0-I,x1:o.x1+I,y1:o.y1+I});}return r;}
  var INF=inflated(),EPS=0.01;
  function inside(b,x,y){return x>b.x0+EPS&&x<b.x1-EPS&&y>b.y0+EPS&&y<b.y1-EPS;}
  function segHits(b,ax,ay,bx,by){var t0=0,t1=1,dx=bx-ax,dy=by-ay,p=[-dx,dx,-dy,dy],q=[ax-(b.x0+EPS),(b.x1-EPS)-ax,ay-(b.y0+EPS),(b.y1-EPS)-ay];
    for(var i=0;i<4;i++){if(p[i]===0){if(q[i]<=0)return false;}else{var r=q[i]/p[i];if(p[i]<0){if(r>t1)return false;if(r>t0)t0=r;}else{if(r<t0)return false;if(r<t1)t1=r;}}}
    return t1-t0>1e-9;}
  function clearSeg(ax,ay,bx,by){for(var i=0;i<INF.length;i++)if(segHits(INF[i],ax,ay,bx,by))return false;return true;}
  function route(sx,sy,tx,ty){
    var pre=[];
    for(var i=0;i<INF.length;i++){var b=INF[i];if(inside(b,sx,sy)){ /* started inside an obstacle's margin: step out by the shortest way */
        var dl=sx-b.x0,dr=b.x1-sx,dt=sy-b.y0,db=b.y1-sy,m=Math.min(dl,dr,dt,db);
        if(m===dl)sx=b.x0;else if(m===dr)sx=b.x1;else if(m===dt)sy=b.y0;else sy=b.y1;pre.push([sx,sy]);}}
    if(clearSeg(sx,sy,tx,ty))return pre.concat([[tx,ty]]);
    var N=[[sx,sy],[tx,ty]],lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3;
    for(var k=0;k<INF.length;k++){var c=INF[k],cs=[[c.x0,c.y0],[c.x1,c.y0],[c.x0,c.y1],[c.x1,c.y1]];
      for(var q=0;q<4;q++){var p=cs[q];if(p[0]<lo||p[0]>hx||p[1]<lo||p[1]>hy)continue;var bad=false;for(var m2=0;m2<INF.length;m2++)if(inside(INF[m2],p[0],p[1])){bad=true;break;}if(!bad)N.push(p);}}
    var n=N.length,D=[],P=[],U=[],i2,j2;for(i2=0;i2<n;i2++){D.push(i2===0?0:1e9);P.push(-1);U.push(false);}
    for(var it=0;it<n;it++){var u=-1;for(i2=0;i2<n;i2++)if(!U[i2]&&(u<0||D[i2]<D[u]))u=i2;if(u<0||D[u]>=1e9)break;U[u]=true;if(u===1)break;
      for(j2=0;j2<n;j2++){if(U[j2])continue;if(!clearSeg(N[u][0],N[u][1],N[j2][0],N[j2][1]))continue;
        var d=D[u]+Math.sqrt((N[u][0]-N[j2][0])*(N[u][0]-N[j2][0])+(N[u][1]-N[j2][1])*(N[u][1]-N[j2][1]));if(d<D[j2]){D[j2]=d;P[j2]=u;}}}
    if(P[1]<0){
      /* no full path: still refuse a straight cut through furniture; walk to the closest reachable node toward the target */
      var best=-1,bd=1e9,bi;
      for(bi=2;bi<n;bi++){if(D[bi]>=1e9)continue;var dd=D[bi]+Math.sqrt((N[bi][0]-tx)*(N[bi][0]-tx)+(N[bi][1]-ty)*(N[bi][1]-ty));if(dd<bd){bd=dd;best=bi;}}
      if(best<0)return pre.concat([[sx,sy]]);
      var path2=[],cur2=best;while(cur2>0){path2.unshift(N[cur2]);cur2=P[cur2];}
      return pre.concat(path2);
    }
    var path=[],cur=1;while(cur>0){path.unshift(N[cur]);cur=P[cur];}
    return pre.concat(path);}
  /* ---- 0.4.2 grid router: used when the visibility graph cannot find a way (objects packed together, a start or goal inside a margin).
     2-unit cells, 8-way BFS, then string-pulled with the same clearSeg test so paths never cut furniture. ---- */
  var GC=2,GNX=Math.ceil(RW/GC),GNY=Math.ceil(RH/GC),GRID=null,GVER=0,GBUILT=-1;
  function gridBuild(){if(GBUILT===GVER&&GRID)return GRID;GRID=new Uint8Array(GNX*GNY);var lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3,i,j,x,y,k,b,bad;
    for(j=0;j<GNY;j++)for(i=0;i<GNX;i++){x=i*GC+GC/2;y=j*GC+GC/2;bad=x<lo||x>hx||y<lo||y>hy;
      if(!bad)for(k=0;k<INF.length;k++){b=INF[k];if(x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1){bad=true;break;}}
      GRID[j*GNX+i]=bad?0:1;}
    GBUILT=GVER;return GRID;}
  function gcell(x,y){return [Math.max(0,Math.min(GNX-1,Math.floor(x/GC))),Math.max(0,Math.min(GNY-1,Math.floor(y/GC)))];}
  function gnear(x,y){var G=gridBuild(),c=gcell(x,y),best=-1,bd=1e9,r,i,j,d;if(G[c[1]*GNX+c[0]])return c[1]*GNX+c[0];
    for(r=1;r<=12&&best<0;r++)for(j=c[1]-r;j<=c[1]+r;j++)for(i=c[0]-r;i<=c[0]+r;i++){if(i<0||j<0||i>=GNX||j>=GNY)continue;if(!G[j*GNX+i])continue;d=(i-c[0])*(i-c[0])+(j-c[1])*(j-c[1]);if(d<bd){bd=d;best=j*GNX+i;}}
    return best;}
  function gflood(start){var G=gridBuild(),D=new Int32Array(GNX*GNY).fill(-1),q=new Int32Array(GNX*GNY),h=0,t2=0,u,ux,uy,dx,dy,vx,vy,v;
    if(start<0)return D;D[start]=start;q[t2++]=start;
    while(h<t2){u=q[h++];ux=u%GNX;uy=(u/GNX)|0;
      for(dy=-1;dy<=1;dy++)for(dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;vx=ux+dx;vy=uy+dy;if(vx<0||vy<0||vx>=GNX||vy>=GNY)continue;v=vy*GNX+vx;if(D[v]>=0||!G[v])continue;
        if(dx&&dy&&(!G[uy*GNX+vx]||!G[vy*GNX+ux]))continue;D[v]=u;q[t2++]=v;}}
    return D;}
  function cellPt(c){return [(c%GNX)*GC+GC/2,((c/GNX)|0)*GC+GC/2];}
  function gridRoute(sx,sy,tx,ty){var a=gnear(sx,sy),b=gnear(tx,ty);if(a<0||b<0)return null;var D=gflood(a);if(D[b]<0)return null;
    var cells=[],c=b;while(c!==a){cells.push(c);c=D[c];}cells.reverse();
    var pts=[[sx,sy]];for(var i=0;i<cells.length;i++)pts.push(cellPt(cells[i]));
    var gp=cellPt(b);if(Math.abs(gp[0]-tx)<GC*1.5&&Math.abs(gp[1]-ty)<GC*1.5&&clearSeg(gp[0],gp[1],tx,ty))pts.push([tx,ty]);
    /* string-pull */
    var out=[],cur=0;while(cur<pts.length-1){var nx=cur+1;for(var j=pts.length-1;j>cur+1;j--){if(clearSeg(pts[cur][0],pts[cur][1],pts[j][0],pts[j][1])){nx=j;break;}}out.push(pts[nx]);cur=nx;}
    return out;}
  function freePt(x,y){var lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3;if(x<lo||x>hx||y<lo||y>hy)return false;for(var j=0;j<INF.length;j++){var b=INF[j];if(x>b.x0+EPS&&x<b.x1-EPS&&y>b.y0+EPS&&y<b.y1-EPS)return false;}return true;}
  /* the full route, safe version: visibility graph first (same paths as 0.4.1 in open rooms), grid when that fails */
  function routeSafe(sx,sy,tx,ty){var r=route(sx,sy,tx,ty),e=r[r.length-1];
    if(e&&Math.abs(e[0]-tx)<0.01&&Math.abs(e[1]-ty)<0.01)return r;
    var g=gridRoute(sx,sy,tx,ty);if(g&&g.length){var ge=g[g.length-1];if(Math.abs(ge[0]-tx)<0.01&&Math.abs(ge[1]-ty)<0.01)return g;
      /* goal not exactly reachable: end on the nearest reachable cell, never straight through furniture */
      return g;}
    return r;}
  function lineFresh(){return {beltIn:[],peeler:null,beltOut:[],shipQ:0,emitted:0,shipped:0};}
  function defaultPlace(id){
    var g=GEO[id]||GEO.tv;
    if(id==="betterPeeler")return {x:GEO.betterPeeler.x,y:GEO.betterPeeler.y};
    if(id==="smallCooler")return {x:GEO.smallCooler.x,y:GEO.smallCooler.y};
    if(id==="tvArmchair")return {x:GEO.tv.x,y:GEO.tv.y};
    if(id==="broomDustpan")return {x:GEO.broom.x,y:GEO.broom.y};
    if(id==="carryBag")return {x:GEO.bag.x,y:GEO.bag.y};
    if(typeof g.x==="number"){if(isWall(id)&&(g.x<=GEO.WALL||g.x>=RW-GEO.WALL))return {x:g.x,y:g.y,r:g.x<=GEO.WALL?3:1};return {x:g.x,y:g.y};}
    return {x:(g.x0+g.x1)/2,y:(g.y0+g.y1)/2};
  }
  var WDEF={towelRack:{x:3.5,y:250,r:3},soap:{x:3.5,y:290,r:3},mopBucket:{x:22,y:330}};   /* 0.4.11 wash-room decor defaults (defaults sit in the bottom half: t1187 bans default props up top; the player may drag them anywhere legal) */
  function decorFresh(){return {lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0,radioSt:0,radioVol:6,radioNear:1,day:0,paydays:0,shipN:0,tips:0,compostN:0,compost:0};}
  function fixDecor(d){var f=decorFresh(),k;if(!d||typeof d!=="object")return f;for(k in f)if(typeof d[k]!=="number"||!isFinite(d[k]))d[k]=f[k];
    d.radioSt=Math.max(0,Math.min(2,Math.floor(d.radioSt)));d.radioVol=Math.max(0,Math.min(10,Math.floor(d.radioVol)));d.radioNear=d.radioNear?1:0;return d;}
  function fresh(seed){
    seed=(seed>>>0)||((Math.random()*4294967295)>>>0);
    var b={};for(var id in BOX)b[id]=BOX[id].def;b.pot=POT_MAX;
    return {v:13,seed:seed,rs:0,rr:seed|0,t:0,level:1,duckIn:0,hyg:100,basin:{},theme:{wall:0,floor:0},
      coins:C.startCoins,food:C.startFood,hunger:100,energy:100,
      box:b,potCap:POT_MAX,up:upsFresh(),
      owned:{},place:{},equipped:{},line:lineFresh(),
      decor:decorFresh(),
      wash:washFresh(),viewRoom:"kitchen",followRoom:null,placeWash:{},
      pile:POT_LOCK,chute:0,suck:null,peels:0,mess:[],
      stats:{peeled:0,earned:0,meals:0,naps:0,lazyNaps:0,bought:0,spent:0,lazyTime:0,eatTime:0,napTime:0,firstBuyT:-1,
        sucks:0,swept:0,sweeps:0,peelsMade:0,maxPeels:0,cleanTime:0,waitTime:0,boughtPot:0,boughtUp:0,autoBuys:0,washedShip:0,unwashedShip:0},
      g:{x:0.5,y:0.20,dir:2,hold:null,held:0,washed:false,job:"pile",peel:0,pgot:0,sloppy:false,lazy:false,act:null,walkPh:0,where:"kitchen",wx:WASH.doorSpot.x,wy:WASH.doorSpot.y,force:null},
      ev:[]};
  }
  function Sim(st){
    this.s=st||fresh();if(typeof this.s.rr!=="number")this.s.rr=this.s.seed|0;
    if(!this.s.equipped||typeof this.s.equipped!=="object")this.s.equipped={};
    if(!this.s.place||typeof this.s.place!=="object")this.s.place={};
    if(!this.s.mess)this.s.mess=[];
    var g0=this.s.g;if(g0){if(g0.sack&&!(typeof g0.sack==="object"&&isFinite(+g0.sack.x)&&isFinite(+g0.sack.y)))g0.sack=null;if(g0.sack&&g0.hold!=="raw")g0.sack=null;
      if(g0.cool&&typeof g0.cool!=="object")g0.cool={};if(g0.cool)for(var ck in g0.cool)if(!isFinite(+g0.cool[ck]))delete g0.cool[ck];
      if(g0.miss&&!Array.isArray(g0.miss))g0.miss=[];if(Array.isArray(g0.miss))g0.miss=g0.miss.filter(function(m){return m&&isFinite(+m.x)&&isFinite(+m.y)&&isFinite(+m.t);}).slice(-8);
      if(g0.lp&&typeof g0.lp!=="object")g0.lp=null;if(g0.sweepTo&&!(isFinite(+g0.sweepTo.x)&&isFinite(+g0.sweepTo.y)))g0.sweepTo=null;}
    for(var pk in this.s.place){var pp=this.s.place[pk];if(!pp||typeof pp!=="object"||!isFinite(+pp.x)||!isFinite(+pp.y)){delete this.s.place[pk];continue;}if(pp.r!=null){pp.r=(Math.floor(+pp.r)||0)&3;}}
    ensureWash(this.s);this.syncGeom();this.syncWashGeom();this.rebuildObst();
    if(!this.s.g.act)this.decide();
  }
  var P=Sim.prototype;
  P.rand=function(){var a=this.s.rr=(this.s.rr+0x6D2B79F5)|0;this.s.rs=(this.s.rs|0)+1;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  P.emit=function(e){if(this.s.ev.length<64)this.s.ev.push(e);};
  P.up=function(id){return Math.max(0,Math.min(UPI[id].max,this.s.up[id]|0));};
  P.spd=function(){var g=this.s.g;return g.lazy?(this.placed("poster")?0.70:C.lazySpeed):SPD[this.s.box.pace];};
  P.lazyLow=function(){return this.placed("photos")?20:C.lazyLow;};
  P.messF=function(){return 1-(this.placed("fan")?0.15:C.messMax)*Math.min(1,this.s.peels/C.messFull);};
  P.wspd=function(){return this.spd()*this.messF();};
  P.price=function(){var b=this.s.stats.bought;return Math.max(1,Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery))-(this.placed("potsPans")?1:0));};
  P.foodMax=function(){return C.foodMax+3*this.up("pantry")+(this.placed("smallCooler")?2:0)+(this.placed("shelf")?2:0);};
  P.chuteCap=function(){return C.chuteCap+2*this.up("chute");};
  P.peelTime=function(){var st=this.s.box.style,sp=STYLE[st].sp;if(st===0&&this.placed("cookbook"))sp=0.9;return C.peel*Math.pow(0.85,this.up("peeler"))*(this.equipped("betterPeeler")?0.90:1)/(this.lampOn()?1.08:1)/sp/(this.sticky()?0.85:1);};
  /* ---- 0.4.11 table sink: clean hands (hygiene). Peeling dirties them; he rinses at the sink built into the peel table. ---- */
  P.hyg=function(){var h=+this.s.hyg;return isFinite(h)?Math.max(0,Math.min(100,h)):100;};
  P.sticky=function(){return this.hyg()<25;};
  P.wantRinse=function(){var b=this.s.box;return b.rinse>0&&this.hyg()<b.rinse;};
  P.peelsPer=function(){var st=this.s.box.style;if(st===2&&this.placed("coatHook"))return 4;return STYLE[st].peels;};
  P.grabTime=function(){return C.grab*(this.placed("sackPile")?0.8:1);};
  P.mealGain=function(){return C.meal+(this.placed("spiceRack")?10:0);};
  P.isDay=function(){var h=this.clockTime().h;return h>=6&&h<20;};
  P.trophies=function(){return Math.max(1,Math.min(5,this.s.level|0))+Math.min(3,Math.floor(((this.s.stats.washedShip|0)+(this.s.stats.unwashedShip|0))/500));};
  /* MOOD (0.4.11): read-only, from his needs and the room. Decor lifts it; mood 60+ = work +3%, 80+ = +6%, under 30 = -5%. */
  P.decorCount=function(){var n=0,i,it;for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(it.group!=="decor"||it.kind==="theme")continue;if(it.kind==="duck"?this.duckOn():it.kind==="basin"?this.basinOn(it.id):this.placed(it.id))n++;}return n;};
  P.mood=function(){var s=this.s,m=50+Math.min(30,this.decorCount()*2);if(this.musicOn())m+=8;if(this.plantOk())m+=4;if(this.ownTheme())m+=3;
    if(s.hunger<25)m-=15;if(s.energy<25)m-=10;if(this.sticky())m-=10;if(s.peels>=60)m-=10;else if(s.peels>=30)m-=5;
    return Math.max(0,Math.min(100,Math.round(m)));};
  P.moodMul=function(){var m=this.mood();return m>=80?1.06:m>=60?1.03:1;   /* bonus only: a bare starter room is never slower than 0.4.10 */};
  P.ownTheme=function(){var t=this.s.theme||{};return (this.owned("wallpaper")&&(t.wall|0)>0)||(this.owned("floorTiles")&&(t.floor|0)>0);};
  P.basinOn=function(id){if(id==="duck")return this.duckOn();return this.owned(id)&&this.hasKey()&&!!(this.s.basin&&this.s.basin[id]);};
  P.putBasin=function(id,on){if(id==="duck")return this.putDuck(on);if(!isBasin(id)||!this.owned(id))return "bad";if(on&&!this.hasKey())return "nokey";if(!this.s.basin||typeof this.s.basin!=="object")this.s.basin={};this.s.basin[id]=on?1:0;return "ok";};
  P.setTheme=function(which,v){var own=which==="wall"?"wallpaper":which==="floor"?"floorTiles":null;if(!own||!this.owned(own))return "bad";v=Math.floor(+v);if(!isFinite(v))return "bad";var L=THEMES[which].length;v=((v%L)+L)%L;if(!this.s.theme)this.s.theme={wall:0,floor:0};this.s.theme[which]=v;return "ok";};
  P.theme=function(){var t=this.s.theme||{};return {wall:this.owned("wallpaper")?(t.wall|0):0,floor:this.owned("floorTiles")?(t.floor|0):0};};
  /* ---- 0.4.10 decor effects (all deterministic: the sim counts the radio as playing while it is placed and ON) ---- */
  P.lampOn=function(){return this.placed("lamp")&&this.s.box.lamp>0;};
  P.musicOn=function(){return this.placed("radio")&&this.s.box.radio>0;};
  P.plantOk=function(){return this.placed("plant")&&!(this.s.decor&&this.s.decor.plant>=70);};
  P.onRug=function(id){if(!this.placed(id))return false;var g=this.s.g;if(g.where==="wash")return false;
    var p=this.placeOf(id),x=g.x*RW,y=g.y*RH,f=this.footOf(id,p.x,p.y,p.r|0);
    if(id==="rug"||id==="roundRug"){var dx=(x-p.x)/f.hx,dy=(y-p.y)/f.hy;return dx*dx+dy*dy<=1;}
    return x>=f.x0&&x<=f.x1&&y>=f.y0&&y<=f.y1;};
  P.energyMul=function(){var m=1,kit=this.s.g.where!=="wash";if(this.musicOn())m*=kit?0.8:0.9;if(kit&&this.plantOk())m*=0.9;if(this.onRug("kitchenMat"))m*=0.7;if(this.placed("aquarium"))m*=0.95;if(!kit&&this.placed("towelRack")&&this.hasKey())m*=0.85;return m;};
  P.hungerMul=function(){var m=this.onRug("rug")?0.8:1;if(this.placed("fruitBowl")&&this.s.g.where!=="wash")m*=0.9;if(this.placed("aquarium"))m*=0.95;return m;};
  P.workMul=function(){var m=1;if(this.musicOn())m*=1.05;if(this.onRug("roundRug"))m*=1.08;
    if(this.placed("window")&&this.isDay())m*=1.04;if(this.placed("stringLights")&&!this.isDay())m*=1.04;
    if(this.placed("trophyShelf"))m*=1+0.01*this.trophies();if(this.placed("statue"))m*=1.05;
    return m*this.moodMul();};
  P.washWalk=function(){return (this.placed("mopBucket")&&this.hasKey())?1.10:1;};
  P.pullMul=function(){return (this.duckOn()?1.25:1)*((this.placed("soap")&&this.hasKey())?1.15:1);};
  P.flowMul=function(){return this.basinOn("toyBoat")?1.15:1;};
  P.walkDecor=function(){return this.onRug("runner")?1.15:1;};
  P.eatTime=function(){return C.eat*(this.placed("clock")?0.7:1);};
  P.duckOn=function(){return this.owned("duck")&&this.hasKey()&&!!this.s.duckIn;};
  P.putDuck=function(on){if(!this.owned("duck"))return "bad";if(on&&!this.hasKey())return "nokey";this.s.duckIn=on?1:0;return "ok";};
  P.clockTime=function(){var m=Math.floor(this.s.t/1)+6*60,d=Math.floor(m/1440);m-=d*1440;return {h:Math.floor(m/60),m:m%60,day:d+1};};   /* 1 real second = 1 shift minute; the shift starts 6:00 */
  /* what each owned decor item is doing for him right now (inventory + tests) */
  P.decorEffects=function(){var o=[],self=this;function add(id,on,txt){if(self.owned(id))o.push({id:id,on:!!on,txt:txt});}
    add("radio",this.musicOn(),"RADIO: energy -20% drain, work +5%");
    add("plant",this.plantOk()&&this.s.g.where!=="wash","PLANT: energy -10% drain");
    add("lamp",this.lampOn(),"LAMP: peel +8%");
    add("kitchenMat",this.onRug("kitchenMat"),"KITCHEN MAT: energy -30% drain (standing on it)");
    add("rug",this.onRug("rug"),"RUG: hunger -20% drain (standing on it)");
    add("runner",this.onRug("runner"),"RUNNER: walk +15% (on it)");
    add("roundRug",this.onRug("roundRug"),"ROUND RUG: work +8% (on it)");
    add("clock",this.placed("clock"),"CLOCK: meals 30% shorter");
    add("poster",this.placed("poster"),"POSTER: lazy speed 70%");
    add("fan",this.placed("fan"),"FAN: mess slow-down max 15%");
    add("shelf",this.placed("shelf"),"SHELF: +2 food storage");
    add("duck",this.duckOn(),"DUCK: basin pull +25%");
    add("tvArmchair",this.placed("tvArmchair")&&this.s.box.tv>0,"TV: watch for energy");
    add("window",this.placed("window")&&this.isDay(),"WINDOW: work +4% (daytime)");
    add("stringLights",this.placed("stringLights")&&!this.isDay(),"STRING LIGHTS: work +4% (night)");
    add("spiceRack",this.placed("spiceRack"),"SPICE RACK: meals +10 hunger");
    add("coatHook",this.placed("coatHook"),"APRON: QUICK = 4 peels");
    add("calendar",this.placed("calendar"),"CALENDAR: 10c payday each shift day");
    add("potsPans",this.placed("potsPans"),"POTS + PANS: food -1c");
    add("photos",this.placed("photos"),"PHOTOS: lazy only under 20%");
    add("neonSign",this.placed("neonSign"),"NEON: +1c tip every 20th ship");
    add("trophyShelf",this.placed("trophyShelf"),"TROPHIES: work +"+this.trophies()+"%");
    add("sideTable",this.placed("sideTable"),"SIDE TABLE: 2 table-top slots");
    add("compost",this.placed("compost"),"COMPOST: sweep +25%, 1c per 20 peels");
    add("sackPile",this.placed("sackPile"),"SACKS: grab +20%");
    add("bookshelf",this.placed("bookshelf"),"BOOKS: level -10%");
    add("catBed",this.placed("catBed"),"CAT: naps +10%");
    add("statue",this.placed("statue"),"STATUE: work +5%");
    add("fruitBowl",this.placed("fruitBowl")&&this.s.g.where!=="wash","FRUIT: hunger -10% (kitchen)");
    add("cookbook",this.placed("cookbook"),"COOKBOOK: NEAT at 90%");
    add("aquarium",this.placed("aquarium"),"AQUARIUM: hunger + energy -5%");
    add("towelRack",this.placed("towelRack")&&this.hasKey()&&this.s.g.where==="wash","TOWELS: energy -15% (wash room)");
    add("soap",this.placed("soap")&&this.hasKey(),"SOAP: basin pull +15%");
    add("mopBucket",this.placed("mopBucket")&&this.hasKey(),"MOP: wash-room walk +10%");
    add("toyBoat",this.basinOn("toyBoat"),"BOAT: current +15%");
    add("bubbles",this.basinOn("bubbles"),"BUBBLES: sloppy wash pay 3c");
    add("wallpaper",false,"WALLPAPER: cosmetic");add("floorTiles",false,"FLOOR TILES: cosmetic");
    return o;};
  P.dropTime=function(){return C.drop*Math.pow(0.7,this.up("chute"));};
  P.walkMul=function(){return 1+0.10*this.up("boots");};
  P.sweepRate=function(){return C.sweepRate*(1+0.5*this.up("broom"))*(this.placed("compost")?1.25:1);};
  P.napRegen=function(){return C.napRegen*(1+0.35*this.up("mat"))*(this.placed("catBed")?1.10:1);};
  P.potMax=function(){return Math.max(0,Math.min(POT_MAX,this.s.potCap));};
  P.target=function(){return POT_LOCK;}; /* 0.4.9: kitchen stock is locked; box.pot stays in the save */
  P.total=function(){var s=this.s,k=s.suck,L=s.line;var ln=L?((L.beltIn?L.beltIn.length:0)+(L.peeler?1:0)+(L.beltOut?L.beltOut.length:0)):0;return s.pile+this.heldN()+s.chute+(k?k.n-k.landed:0)+ln+washCount(s.wash);};
  /* a full chute (or an empty pile) sends the batch up the pipe; it spills out of the return chute onto the pile */
  P.startSuck=function(){var s=this.s;if(s.suck||s.chute<=0)return false;s.suck={t0:s.t,n:s.chute,landed:0};s.chute=0;s.stats.sucks++;this.emit({k:"suck"});return true;};
  P.retarget=function(){var s=this.s,d=this.target()-this.total();if(d>0){s.pile+=d;return;}
    var r=-d,t=Math.min(r,s.pile);s.pile-=t;r-=t;
    if(r>0){t=Math.min(r,s.chute);s.chute-=t;r-=t;}
    if(r>0&&s.suck){var k=s.suck;t=Math.min(r,k.n-k.landed);k.n-=t;r-=t;if(k.n<=k.landed)s.suck=null;}};
  P.drn=function(){var g=this.s.g;return g.lazy?DRN[0]:DRN[this.s.box.pace];};
  P.needState=function(){
    var s=this.s,b=s.box;
    var eatThr=b.eat>0?b.eat:0,napThr=b.nap>0?b.nap:0;
    var wantEat=eatThr>0&&s.hunger<eatThr&&s.food>0;
    var wantNap=napThr>0&&s.energy<napThr;
    var LL=this.lazyLow(),hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<LL);
    var energyUnmet=napThr>0?false:(s.energy<LL);
    var lazy=(hungerUnmet||energyUnmet);
    var wantWatch=this.placed("tvArmchair")&&b.tv>0&&b.watch>0&&s.energy<b.watch&&!s.g.hold;
    var wantWater=this.placed("plant")&&b.water>0&&(s.decor&&s.decor.plant>=b.water)&&!s.g.hold;
    return {wantEat:wantEat,wantNap:wantNap,lazy:lazy,hungerUnmet:hungerUnmet,energyUnmet:energyUnmet,
      wantClean:b.clean>0&&s.peels>b.clean&&!lazy&&!s.g.hold&&!this.cooling("sweep"),
      wantWatch:wantWatch&&!lazy&&!this.cooling("watch"),wantWater:wantWater&&!lazy&&!this.cooling("water")};
  };
  P.walkTo=function(xu,yu,dir,then,label){var g=this.s.g,dest=this.standBeside(xu,yu);xu=dest.x;yu=dest.y;
    var r=routeSafe(g.x*RW,g.y*RH,xu,yu),wp=[];for(var i=0;i<r.length-1;i++)wp.push([r[i][0]/RW,r[i][1]/RH]);
    var e=r[r.length-1];if(e&&(Math.abs(e[0]-xu)>0.01||Math.abs(e[1]-yu)>0.01)){xu=e[0];yu=e[1];}   /* only as far as he can really get */
    g.act={t:"walk",x:xu/RW,y:yu/RH,dir:dir,then:then,label:label,wp:wp};};
  /* 0.4.2 anti-loop: a task that ends (or fails) the instant it starts, again and again, goes on a short cooldown so he gets back to work */
  P.cooling=function(k){var c=this.s.g.cool;return !!(c&&c[k]&&this.s.t<c[k]);};
  P.coolDown=function(k,sec){var g=this.s.g;if(!g.cool||typeof g.cool!=="object")g.cool={};g.cool[k]=this.s.t+sec;this.s.stats.loopBreaks=(this.s.stats.loopBreaks|0)+1;};
  P.loopGuard=function(k){var g=this.s.g,t=this.s.t;if(!g.lp||typeof g.lp!=="object")g.lp={k:"",n:0,t:-9};
    if(g.lp.k===k&&t-g.lp.t<1.5)g.lp.n++;else{g.lp.k=k;g.lp.n=0;}g.lp.t=t;
    if(g.lp.n>=4&&(k==="sweep"||k==="water"||k==="watch"||k==="wash"||k==="tune")){this.coolDown(k,25);g.lp.n=0;return false;}
    return true;};
  P.decide=function(){
    var s=this.s,g=s.g,n=this.needState();
    if(g.where==="wash"){this.decideWash();return;}
    if(g.force==="eat"&&s.food>0){g.lazy=false;this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the cooler");return;}
    if(g.force==="nap"){g.lazy=false;this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the bed");return;}
    if(g.force==="clean"&&s.peels>0){var swf=this.sweepSpot();if(swf.n){this.walkTo(swf.x,swf.y,swf.dir,"sweep","to sweep");return;}g.force=null;}
    if(g.force==="washPool"){if(!this.hasKey()){if(!g.holdRepeat)g.force=null;}
      else if(g.hold==="peeled"&&this.heldN()>0){this.walkTo(SPOT.ship.x,SPOT.ship.y,SPOT.ship.dir,"drop","to the scanner");return;}
      else if(this.washUnwashed()>0){this.goToWashRoom();return;}
      else if(!(g.holdRepeat==="wash"||this.wantsAutoWash())){if(!g.holdRepeat)g.force=null;}}
    if(n.wantEat){g.lazy=false;this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the cooler");return;}
    if(n.wantNap){g.lazy=false;this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the bed");return;}
    g.lazy=n.lazy;
    if(n.wantClean){var sw=this.sweepSpot();
      if(sw.n&&this.loopGuard("sweep")){this.walkTo(sw.x,sw.y,sw.dir,"sweep","to sweep");return;}
      if(!sw.n)this.coolDown("sweep",20);   /* every pile of peels is out of reach right now: work, look again soon */
    }
    if(n.wantWater&&this.loopGuard("water")){var pl=this.placeOf("plant");this.walkTo(pl.x,pl.y+12,0,"water","to water the plant");return;}
    if(n.wantWatch&&this.loopGuard("watch")){var sp=this.sitSpot();this.walkTo(sp.x,sp.y+10,0,"watch","to watch TV");return;}
    if(g.lazy){
      var r=this.rand();
      if(s.energy<15||(s.energy<70&&r<0.30)){g.act={t:"lazynap",until:Math.min(100,60+this.rand()*35),label:"dozing on the floor"};s.stats.lazyNaps++;this.emit({k:"lazynap"});return;}
      if(r>0.72){g.act={t:"idle",d:1.5+this.rand()*2.5,e:0,label:"slacking off"};return;}
    }
    /* if the full work line is running, leave the peeling to the machines and do a little living */
    if(this.lineRunning()&&!g.hold){
      if(this.wantsAutoWash()&&this.washUnwashed()>0){this.goToWashRoom();return;}
      if(this.placed("radio")&&s.box.radio>0&&this.rand()<0.08){var rd=this.placeOf("radio");this.walkTo(rd.x-7.5,rd.y,1,"tune","to tune the radio");return;}
      g.act={t:"idle",d:1.2+this.rand()*2.0,e:0,label:"watching the line"};return;
    }
    if(g.job==="pile"){var px=SPOT.pile.x0+this.rand()*(SPOT.pile.x1-SPOT.pile.x0);this.walkTo(px,SPOT.pile.y,2,"grab","to the pile");}
    else if(g.job==="wash"&&this.placed("sink")&&!this.cooling("wash")&&this.loopGuard("wash")){this.walkTo(SPOT.sink.x,SPOT.sink.y,SPOT.sink.dir,"wash","to the sink");}
    else if(g.job==="wash"){g.job="table";this.walkTo(SPOT.table.x,SPOT.table.y,SPOT.table.dir,"peel","to the table");}
    else if(g.job==="table"||g.job==="peel"){this.walkTo(SPOT.table.x,SPOT.table.y,SPOT.table.dir,"peel","to the table");}
    else this.walkTo(SPOT.ship.x,SPOT.ship.y,SPOT.ship.dir,"drop","to the scanner");
  };
  P.startAt=function(kind){
    var g=this.s.g;
    if(kind==="grab")g.act={t:"grab",e:0,label:this.carryCap()>1?"grabbing potatoes":"grabbing a potato"};
    else if(kind==="wash"){g.act={t:"wash",e:0,n:this.heldN(),label:this.heldN()>1?"dumping potatoes in the sink":"dumping a potato in the sink"};}
    else if(kind==="peel"){
      if(!this.atTable()){g.job="peel";g.tmiss=(g.tmiss|0)+1;if(g.tmiss<=3){this.walkTo(SPOT.table.x,SPOT.table.y,SPOT.table.dir,"peel","to the table");return;}}
      g.tmiss=0;g.job="peel";g.dir=SPOT.table.dir;
      if(this.wantRinse()){g.act={t:"rinse",e:0,label:"rinsing his hands at the table sink"};return;}
      /* carry bag equipped and a load in it: set the sack on the floor beside him and peel them one by one until it is done */
      if(this.equipped("carryBag")&&this.heldN()>1&&g.hold==="raw"){var sd=this.sackSpot();g.sack={x:sd.x,y:sd.y,n:this.heldN()};}else g.sack=null;
      g.act={t:"peel",label:g.lazy?"peeling (sloppy)":(g.sack?"peeling from the sack":"peeling")};}
    else if(kind==="watch"){var sp=this.sitSpot();g.x=sp.x/RW;g.y=sp.y/RH;g.dir=sp.dir;g.act={t:"watch",e:0,label:"watching TV"};}
    else if(kind==="water")g.act={t:"water",e:0,label:"watering the plant"};
    else if(kind==="tune")g.act={t:"tune",e:0,label:"tuning the radio"};
    else if(kind==="drop")g.act={t:"drop",e:0,label:this.wantsWashDivert()?(this.heldN()>1?"sending them through the scanner":"placing it in the scanner"):(this.heldN()>1?"shipping them":"placing it in the scanner")};
    else if(kind==="eat"){
      /* 0.4.3: food comes out of the cooler, so he eats standing at it, facing it */
      if(!this.atCooler()){g.emiss=(g.emiss|0)+1;if(g.emiss<=3){this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the cooler");return;}}
      g.emiss=0;g.dir=SPOT.food.dir;g.act={t:"eat",e:0,label:"eating at the cooler"};}
    else if(kind==="sweep"){var tg=this.s.g.sweepTo;g.act={t:"sweep",e:0,acc:0,label:"sweeping up the peels",cx:tg?tg.x:null,cy:tg?tg.y:null};}
    else if(kind==="nap"){g.x=GEO.mat.x/RW;g.y=GEO.mat.y/RH;g.dir=1;g.act={t:"nap",label:"napping on the bed"};this.s.stats.naps++;this.emit({k:"nap"});}
    else if(kind==="enterWash")this.enterWashRoom();
    else if(kind==="leaveWash")this.leaveWashRoom();
    else if(kind==="scoop")this.doScoop();
    else if(kind==="dumpPool")this.doDumpPool();
  };
  P.peelEmit=function(n,src){var s=this.s;if(!s.mess)s.mess=[];src=src||"table";
    for(var i=0;i<n;i++){if(s.mess.length>=C.peelMax)break;
      var pos=this.spawnPeelPos(src,s.mess.length);
      s.mess.push(pos);s.peels=s.mess.length;s.stats.peelsMade++;if(s.peels>s.stats.maxPeels)s.stats.maxPeels=s.peels;
      this.emit({k:"peel",slot:s.mess.length-1,x:pos.x,y:pos.y,src:src});}};
  P.spawnPeelPos=function(src,i){
    var x,y,h=hash(this.s.seed||1,i*11+7);
    if(src==="peeler"&&this.placed("autoPeeler")){
      var p=this.placeOf("autoPeeler");
      var ang=h*6.283,r=6+hash(this.s.seed||1,i*13+3)*10;
      var po=rot(8,14,p.r|0);x=p.x+po[0]+Math.cos(ang)*r*0.4;y=p.y+po[1]+Math.sin(ang)*r*0.55;
    }else{
      var k=tableKids(),sp=k.peelSpawn;
      var ang=h*6.283,r=4+hash(this.s.seed||1,i*17+5)*16;
      if(!sp.nx&&sp.ny!==-1){x=sp.x+Math.cos(ang)*r*0.85;y=sp.y+2+Math.abs(Math.sin(ang))*r;}   /* front: same spray as 0.4.1 */
      else{var a1=Math.cos(ang)*r*0.85,a2=Math.abs(Math.sin(ang))*r+2;x=sp.x+(sp.nx?sp.nx*a2:a1);y=sp.y+(sp.ny?sp.ny*a2:a1);}
    }
    x=Math.max(GEO.WALL+4,Math.min(RW-GEO.WALL-4,x));
    y=Math.max(GEO.WALL+4,Math.min(GEO.pile.base-GEO.pile.rz-8,y));
    /* keep peels off the table, bed and cooler tops */
    var T=GEO.table,M=GEO.mat,C=GEO.cooler;
    if(x>T.x0-1&&x<T.x1+1&&y>T.y0-1&&y<T.y1+2)y=T.y1+4;
    if(Math.abs(x-M.x)<M.w/2+2&&Math.abs(y-M.y)<M.h/2+2)y=M.y+M.h/2+4;
    if(x>C.x0-1&&x<C.x1+1&&y>C.y0-1&&y<C.y1+2)y=C.y1+4;
    /* 0.4.2: never under any other object either (table against a wall, things packed together) */
    for(var oi=0;oi<OBST.length;oi++){var o=OBST[oi];if(x>o.x0-1&&x<o.x1+1&&y>o.y0-1&&y<o.y1+1){
        var c4=[[x,o.y1+3],[x,o.y0-3],[o.x0-3,y],[o.x1+3,y]];for(var ci2=0;ci2<4;ci2++){var qx=c4[ci2][0],qy=c4[ci2][1];if(qx>GEO.WALL+3&&qx<RW-GEO.WALL-3&&qy>GEO.WALL+3&&qy<GEO.pile.base-GEO.pile.rz-4){x=qx;y=qy;break;}}}}
    x=Math.max(GEO.WALL+4,Math.min(RW-GEO.WALL-4,x));y=Math.max(GEO.WALL+4,Math.min(GEO.pile.base-GEO.pile.rz-8,y));
    return {x:x,y:y,src:src||"table"};
  };
  P.syncPeelCount=function(){var s=this.s;if(!s.mess)s.mess=[];s.peels=s.mess.length;};
  P.step=function(dt){
    var s=this.s,g=s.g,a=g.act,sp=this.spd(),dr=this.drn(),wsp=sp*this.messF(),wk=wsp*this.workMul(),em=this.energyMul(),hm=this.hungerMul();
    s.t+=dt;
    if(s.suck){var k=s.suck,sc=spill(k.t0,k.n);
      while(k.landed<k.n&&s.t>=sc.ld[k.landed]){s.pile++;k.landed++;this.emit({k:"land"});}
      if(k.landed>=k.n)s.suck=null;}
    if(!s.suck&&s.chute>=this.chuteCap())this.startSuck();
    this.lineStep(dt);
    this.decorStep(dt);
    this.washStep(dt);
    if(s.box.autob>0&&s.food<s.box.autob&&s.food<this.foodMax()&&s.coins>=this.price()){this.buyFood(true);}
    if(a&&(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep")))s.stats.cleanTime+=dt;
    var resting=a&&(a.t==="nap"||a.t==="lazynap"),eating=a&&a.t==="eat";
    if(resting){s.hunger-=C.hungerDrainNap*dt*hm;}
    else if(!eating){s.hunger-=C.hungerDrain*dr*dt*hm;s.energy-=C.energyDrain*dr*dt*(a&&a.t==="idle"?0.4:1)*em;}
    if(s.hunger<0)s.hunger=0;if(s.energy<0)s.energy=0;
    if(g.lazy)s.stats.lazyTime+=dt;
    if(eating||(a&&a.t==="walk"&&a.then==="eat"))s.stats.eatTime+=dt;
    if(resting||(a&&a.t==="walk"&&a.then==="nap"))s.stats.napTime+=dt;
    if(g.where==="wash"){this.washGuyStep(dt,wsp);return;}
    if(!a){this.decide();return;}
    switch(a.t){
      case "walk":{
        var fin=!(a.wp&&a.wp.length),gt=fin?[a.x,a.y]:a.wp[0];
        var dx=(gt[0]-g.x)*RW,dy=(gt[1]-g.y)*RH,d=Math.sqrt(dx*dx+dy*dy),mv=C.walk*wsp*this.walkMul()*this.walkDecor()*dt;
        g.walkPh+=mv*0.35;
        if(Math.abs(dx)>Math.abs(dy)*0.8)g.dir=dx>0?1:3;else g.dir=dy>0?2:0;
        if(d<=mv||d<0.01){g.x=gt[0];g.y=gt[1];if(fin){g.dir=a.dir;this.startAt(a.then);}else a.wp.shift();}
        else{g.x+=dx/d*mv/RW;g.y+=dy/d*mv/RH;}
        break;}
      case "grab":a.e+=dt*wk;if(a.e>=this.grabTime()){
          if(s.pile<=0){a.e=this.grabTime();a.label="waiting for potatoes";s.stats.waitTime+=dt;if(s.chute>0&&!s.suck)this.startSuck();break;}
          var take=Math.min(this.carryCap(),s.pile);s.pile-=take;g.hold="raw";g.held=take;g.washed=false;g.job=(this.owned("sink")&&s.box.wash>0)?"wash":"table";g.peel=0;g.pgot=0;g.sloppy=false;this.emit({k:"grab",n:take});this.decide();}break;
      case "peel":{
        if(g.lazy)g.sloppy=true;
        var nHold=Math.max(1,this.heldN());
        var np=(g.sloppy?C.peelPerSloppy:this.peelsPer())*nHold;
        s.hyg=Math.max(0,this.hyg()-1.5*dt*wk);
        g.peel+=dt*wk/(this.peelTime()*(0.70+0.30*nHold));
        /* the skin comes off progressively: one peel pops off at each fraction of the load */
        while(g.pgot<np&&g.peel>=(g.pgot+1)/(np+1)&&g.peel<1){g.pgot++;this.peelEmit(1);}
        if(g.peel>=1){g.peel=1;g.hold="peeled";g.job="chute";g.sack=null;if(g.pgot<np)this.peelEmit(np-g.pgot);g.pgot=0;
          this.emit({k:"peeled",n:nHold});this.decide();}
        break;}
      case "drop":a.e+=dt*wk;if(a.e>=this.dropTime()){
          if(this.wantsWashDivert()){
            this.intakeWash({washed:true,sloppy:!!g.sloppy,fromHole:true});s.stats.peeled++;
            this.emit({k:"toWash",washed:true,sloppy:!!g.sloppy,fromHole:true});
            g.held=this.heldN()-1;
            if(g.held<=0){g.hold=null;g.held=0;g.job="pile";g.peel=0;g.sloppy=false;g.washed=false;if(!g.holdRepeat)g.force=g.force==="washPool"&&!this.wantsAutoWash()?null:g.force;this.decide();}
            else{a.e=0;a.label="sending them through";}
            break;}
          if(s.chute>=this.chuteCap()){if(!s.suck)this.startSuck();a.e=this.dropTime();a.label="waiting for the hole";s.stats.waitTime+=dt;break;}
          this.kitchenShipOne({washed:!!g.washed,sloppy:!!g.sloppy});
          g.held=this.heldN()-1;this.emit({k:"ship",washed:!!g.washed,sloppy:!!g.sloppy});
          if(g.held<=0){g.hold=null;g.held=0;g.job="pile";g.peel=0;g.sloppy=false;g.washed=false;this.decide();}
          else{a.e=0;a.label="shipping them";}}break;
      case "eat":a.e+=dt;if(a.e>=this.eatTime()){
          if(s.food>0){s.food--;s.hunger=Math.min(100,s.hunger+this.mealGain());s.stats.meals++;this.emit({k:"ate"});}
          if(g.force==="eat"){if(g.holdRepeat==="eat"&&s.food>0&&s.hunger<98){a.e=0;break;}g.force=null;this.decide();break;}
          var n=this.needState();if(n.wantEat){a.e=0;}else this.decide();}break;
      case "nap":{s.energy=Math.min(100,s.energy+this.napRegen()*dt);var wk=s.box.wake>=100?C.napWake:s.box.wake;if(g.force==="nap"&&(wk<80||g.holdRepeat==="nap"))wk=100;if(s.energy>=wk){var bs=bedside();g.x=bs.x/RW;g.y=bs.y/RH;g.dir=bs.dir;if(g.force==="nap")g.force=null;this.decide();}break;}
      case "lazynap":s.energy=Math.min(100,s.energy+C.lazyNapRegen*dt);if(s.energy>=a.until)this.decide();break;
      case "idle":a.e+=dt;if(a.e>=a.d)this.decide();break;
      case "sweep":{
        var nn=this.needState();
        if((s.box.clean<=0&&g.force!=="clean")||(g.force!=="clean"&&(nn.wantEat||nn.wantNap||nn.lazy))){if(g.force==="clean"&&s.peels<=0)g.force=null;this.decide();break;}
        a.e+=dt*sp;
        if(a.e>C.sweepWind){a.acc+=dt*sp*this.sweepRate();var kk=Math.floor(a.acc);if(kk>0){a.acc-=kk;var got=this.sweepNear(g.x*RW,g.y*RH,kk,a.reach||16);
          if(got===0&&!a.reach){a.reach=26;got=this.sweepNear(g.x*RW,g.y*RH,kk,26);}   /* 0.4.2: stretch the broom once before giving up on this spot */
          var tidy=g.force==="clean"?0:Math.floor(s.box.clean*C.sweepTidy);
          if(got>0){a.swept=(a.swept|0)+got;}
          if(got===0&&s.peels>tidy){if(!a.swept)this.missAt(a.cx!=null?a.cx:g.x*RW,a.cy!=null?a.cy:g.y*RH);this.decide();break;}}}
        if(s.peels<=(g.force==="clean"?0:Math.floor(s.box.clean*C.sweepTidy))){s.stats.sweeps++;if(g.force==="clean")g.force=null;this.emit({k:"swept"});this.decide();}
        break;}
      case "wash":{
        a.e+=dt*sp;if(a.e>=1.6+0.3*Math.max(1,this.heldN())){g.washed=true;g.job="table";this.decide();}break;}
      case "watch":{
        var nn=this.needState();
        if(!this.placed("tvArmchair")||s.box.tv<=0||nn.wantEat||nn.wantNap){this.decide();break;}
        s.energy=Math.min(100,s.energy+1.8*dt);
        a.e+=dt;if(s.energy>=(s.box.watch>0?Math.min(100,s.box.watch+25):80)||a.e>12)this.decide();
        break;}
      case "water":{
        a.e+=dt*sp;if(a.e>=2.4){if(s.decor){s.decor.plant=0;s.decor.plantT=s.t;}this.emit({k:"watered"});this.decide();}break;}
      case "tune":{
        a.e+=dt;if(a.e>=1.8){if(s.decor)s.decor.radioTune=s.t;this.decide();}break;}
      case "rinse":{   /* 0.4.11: at the table sink, right where he peels */
        a.e+=dt*sp;if(a.e>=1.0){s.hyg=100;s.stats.rinses=(s.stats.rinses|0)+1;this.emit({k:"rinse"});if(g.hold==="raw")this.startAt("peel");else this.decide();}break;}
    }
  };
  P.run=function(sec,h){h=h||0.1;var n=Math.round(sec/h);for(var i=0;i<n;i++)this.step(h);};
  P.poke=function(){var g=this.s.g,a=g.act,n=this.needState();
    if(a&&(a.t==="idle"||a.t==="lazynap"))this.decide();
    else if(a&&a.t==="walk"&&/grab|peel|drop|sweep|wash|watch|water|tune/.test(a.then)&&(n.wantEat||n.wantNap))this.decide();
    else if(g.lazy&&!n.lazy){g.lazy=false;}};
  P.setBox=function(id,v){var b=BOX[id];if(!b)return false;v=Number(v);if(v!==v)return false;var mx=id==="pot"?this.potMax():b.max;
    v=Math.max(b.min,Math.min(mx,Math.round((v-b.min)/b.step)*b.step+b.min));if(this.s.box[id]===v)return false;this.s.box[id]=v;if(id==="pot")this.retarget();this.poke();return true;};
  P.buyFood=function(auto){var s=this.s,pr=this.price();if(s.food>=this.foodMax())return "full";if(s.coins<pr)return "poor";
    s.coins-=pr;s.food++;s.stats.bought++;s.stats.spent+=pr;if(auto)s.stats.autoBuys++;if(s.stats.firstBuyT<0)s.stats.firstBuyT=s.t;this.poke();return "ok";};
  P.potPrice=function(){if(POT_LOCK)return null; /* 0.4.9: stock is locked, shop row hidden */ var i=this.s.potCap+1;if(i>POT_MAX)return null;return Math.round(C.potPrice0*Math.pow(C.potPriceGrow,i-C.potBase));};
  /* buying potatoes raises the limit to the next stop and puts them in play right away */
  P.buyPotatoes=function(){var s=this.s,pr=this.potPrice();if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.potCap++;s.box.pot=s.potCap;s.stats.boughtPot++;s.stats.spent+=pr;this.retarget();this.poke();return "ok";};
  P.upPrice=function(id){var u=UPI[id],l=this.up(id);return l>=u.max?null:u.prices[l];};
  P.buyUp=function(id){var s=this.s;if(!UPI[id])return "bad";var pr=this.upPrice(id);if(pr===null)return "max";if(s.coins<pr)return "poor";
    s.coins-=pr;s.up[id]=this.up(id)+1;s.stats.boughtUp++;s.stats.spent+=pr;this.poke();return "ok";};
  P.stateName=function(){var g=this.s.g,a=g.act;if(g.lazy)return "AUTO-LAZY";if(!a)return "PEELING";
    if(a.t==="eat"||(a.t==="walk"&&a.then==="eat"))return "EATING";
    if(a.t==="nap"||(a.t==="walk"&&a.then==="nap"))return "NAPPING";
    if(a.t==="sweep"||(a.t==="walk"&&a.then==="sweep"))return "CLEANING";
    if(a.t==="watch"||(a.t==="walk"&&a.then==="watch"))return "WATCHING";
    if(a.t==="water"||(a.t==="walk"&&a.then==="water"))return "WATERING";
    if(a.t==="tune"||(a.t==="walk"&&a.then==="tune"))return "TUNING";
    if(a.t==="rinse")return "PEELING";
    if(a.t==="wash"||(a.t==="walk"&&a.then==="wash"))return "WASHING";
    if(a.t==="scoop"||a.t==="dumpPool"||a.t==="wdump"||(a.t==="wwalk"&&(a.then==="scoop"||a.then==="dumpPool"||a.then==="enterWash")))return "WASHING";
    if(g.force==="washPool"||g.holdRepeat==="wash"||this.wantsAutoWash()){
      if(a.t==="drop"||(a.t==="walk"&&a.then==="drop")||(a.t==="idle"&&g.where==="wash"))return "WASHING";}
    if(g.where==="wash"&&!(a.t==="wwalk"&&a.then==="leaveWash"))return "WASHING";
    if(a.t==="wwalk"&&a.then==="leaveWash")return "PEELING";
    return "PEELING";};

  P.owned=function(id){return !!(this.s.owned&&this.s.owned[id]);};
  P.unlocked=function(id){var it=ITEMI[id];return !!(it&&this.s.level>=it.lv);};
  P.placed=function(id){if(!this.owned(id))return false;if(isWashItem(id))return !!(this.s.placeWash&&this.s.placeWash[id]);return !!(this.s.place&&this.s.place[id]);};
  P.equipped=function(id){return this.owned(id)&&!!(this.s.equipped&&this.s.equipped[id]);};
  P.inInv=function(id){if(!this.owned(id))return false;if(isTool(id))return !this.equipped(id);if(isPlaceable(id))return !this.placed(id);return false;};
  P.placeOf=function(id){if(isWashItem(id))return (this.s.placeWash&&this.s.placeWash[id])||WDEF[id];var p=(this.s.place&&this.s.place[id])||defaultPlace(id);return p;};
  P.equip=function(id){if(!isTool(id)||!this.owned(id))return "bad";if(!this.s.equipped)this.s.equipped={};this.s.equipped[id]=1;this.poke();return "ok";};
  P.unequip=function(id){if(!isTool(id)||!this.owned(id))return "bad";if(this.s.equipped)this.s.equipped[id]=0;this.poke();return "ok";};
  P.placeItem=function(id,x,y){if(!isPlaceable(id)||!this.owned(id))return "bad";
    if(isWashItem(id))return this.placeWashItem(id,x,y);
    if(isTop(id)){if(x==null||y==null||!isFinite(+x)||!isFinite(+y)){x=GEO.sideTable.x;y=GEO.sideTable.y;}return this.placeTop(id,+x,+y);}
    if(x==null||y==null||!isFinite(+x)||!isFinite(+y)){var d=defaultPlace(id);x=d.x;y=d.y;}x=+x;y=+y;
    if(!this.s.place)this.s.place={};
    if(id==="conveyor"||id==="outConveyor"||id==="suction"){var dp=defaultPlace(id);this.s.place[id]={x:dp.x,y:dp.y};this.refresh();this.replan();this.poke();return "ok";}   /* fixed work-line machines */
    if(isWall(id)){var wsp=this.wallSnap(id,x,y);if(!wsp)return "blocked";this.s.place[id]={x:wsp.x,y:wsp.y};if(wsp.r)this.s.place[id].r=wsp.r;this.refresh();this.replan();this.poke();return "ok";}
    /* 0.4.2: the nearest spot (spiralling out) where it fits AND he can still get everywhere */
    var placed=false,ra,i2,a2,px,py,W0=GEO.WALL+1;
    for(ra=0;ra<=90&&!placed;ra+=3){var nA=ra?Math.max(8,Math.round(ra*0.7)):1;
      for(i2=0;i2<nA&&!placed;i2++){a2=i2*2*Math.PI/nA;px=x+Math.cos(a2)*ra;py=y+Math.sin(a2)*ra;
        if(!this.fits(id,px,py,0))continue;
        this.s.place[id]={x:px,y:py};this.refresh();
        if(this.connected())placed=true;else{delete this.s.place[id];this.refresh();}}}
    if(!placed)return "blocked";
    /* 0.4.2 (Jay t1116): with a sink he dumps the potatoes in it. The first time a sink goes in, WASH BEFORE PEEL turns on (you can still turn it off). */
    if(id==="sink"&&!this.s.sinkAuto){this.s.sinkAuto=1;this.s.box.wash=1;}
    this.replan();this.poke();return "ok";};
  P.unplace=function(id){if(!isPlaceable(id)||!this.placed(id))return "bad";
    if(isWashItem(id)){delete this.s.placeWash[id];this.poke();return "ok";}
    delete this.s.place[id];this.refresh();this.replan();this.poke();return "ok";};
  P.invList=function(){var out=[],i,it;
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(!this.owned(it.id))continue;
      out.push({id:it.id,name:it.name,kind:it.kind||(isTool(it.id)?"tool":"place"),equipped:this.equipped(it.id),placed:it.kind==="duck"?this.duckOn():this.placed(it.id),inInv:this.inInv(it.id)});
    }return out;};
  P.trayList=function(room){var out=[],i,it;room=room||"any";
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(!(isPlaceable(it.id)&&this.owned(it.id)&&!this.placed(it.id)))continue;
      if(room==="wash"&&!isWashItem(it.id))continue;if(room==="kitchen"&&isWashItem(it.id))continue;
      out.push({id:it.id,name:it.name,cat:isWashItem(it.id)?"wash":(it.cat||"floor")});}
    return out;};
  /* ---- 0.4.11 TABLE-TOP slots: 2 on the side table, 1 on the food cooler lid ---- */
  P.topSlots=function(){var o=[],p,r,a,b;
    if(this.placed("sideTable")){p=this.placeOf("sideTable");r=(p.r|0)&3;a=rot(-3.4,-0.4,r);b=rot(3.4,-0.4,r);o.push({on:"sideTable",slot:0,x:p.x+a[0],y:p.y+a[1]});o.push({on:"sideTable",slot:1,x:p.x+b[0],y:p.y+b[1]});}
    var K=GEO.cooler;o.push({on:"cooler",slot:0,x:(K.x0+K.x1)/2,y:(K.y0+K.y1)/2-0.6});
    return o;};
  P.topOwner=function(on,slot,skip){var pl=this.s.place||{},i,q;for(i=0;i<TOPS.length;i++){if(TOPS[i]===skip)continue;q=pl[TOPS[i]];if(q&&this.owned(TOPS[i])&&q.on===on&&(q.slot|0)===slot)return TOPS[i];}return null;};
  P.syncTops=function(){var pl=this.s.place||{},sl=this.topSlots(),i,j,q,f;
    for(i=0;i<TOPS.length;i++){q=pl[TOPS[i]];if(!q)continue;f=null;for(j=0;j<sl.length;j++)if(sl[j].on===q.on&&sl[j].slot===(q.slot|0)){f=sl[j];break;}
      if(!f){delete pl[TOPS[i]];continue;}   /* its surface was put away: back to the inventory */
      q.x=f.x;q.y=f.y;}};
  P.placeTop=function(id,x,y){if(!isTop(id)||!this.owned(id))return "bad";var sl=this.topSlots(),best=null,bd=1e9,i,d;
    for(i=0;i<sl.length;i++){if(this.topOwner(sl[i].on,sl[i].slot,id))continue;d=Math.hypot(sl[i].x-x,sl[i].y-y);if(d<bd){bd=d;best=sl[i];}}
    if(!best)return "blocked";if(!this.s.place)this.s.place={};this.s.place[id]={x:best.x,y:best.y,on:best.on,slot:best.slot};this.poke();return "ok";};
  /* ---- 0.4.11 WASH-ROOM decor: wall items on the north wall (off the door and ship opening) or the west wall; floor items off the basin, canal, outlet, door and his walk lanes ---- */
  P.fitsWashWall=function(id,x,y,r){r=(r|0)&3;var f=this.footOf(id,x,y,r),W=GEO.WALL,D=WASH.door,h=WASH.hole,i,q,f2;
    if(r===0){if(Math.abs(y-W/2)>0.01)return false;if(f.x0<W+1||f.x1>WW-W-1)return false;if(f.x1>D.x0-2&&f.x0<D.x0+D.w+2)return false;if(f.x1>h.x-h.w/2-4)return false;}
    else if(r===3){if(Math.abs(x-W/2)>0.01)return false;if(f.y0<W+2||f.y1>WH-W-2)return false;}
    else return false;
    for(i=0;i<WASHW.length;i++){if(WASHW[i]===id||!this.placed(WASHW[i]))continue;q=this.placeOf(WASHW[i]);f2=this.footOf(WASHW[i],q.x,q.y,q.r|0);if(f.x0<f2.x1+1&&f.x1>f2.x0-1&&f.y0<f2.y1+1&&f.y1>f2.y0-1)return false;}
    return true;};
  P.washWallSnap=function(id,x,y){var W=GEO.WALL,walls=[{r:0,d:Math.abs(y)},{r:3,d:Math.abs(x)}],i,j,o,px,py;walls.sort(function(a1,b1){return a1.d-b1.d;});
    for(i=0;i<walls.length;i++){var r=walls[i].r;for(j=0;j<=800;j++){o=(j&1?1:-1)*Math.ceil(j/2);if(r===0){px=x+o;py=W/2;}else{px=W/2;py=y+o;}if(this.fitsWashWall(id,px,py,r))return {x:px,y:py,r:r};}}
    return null;};
  P.washLanes=function(){var d=WASH.doorSpot,L=WASH.land;return [{x0:d.x,y0:d.y,x1:L.x-18,y1:L.y-2},{x0:d.x,y0:d.y,x1:L.x,y1:L.y-L.ry},{x0:d.x,y0:d.y,x1:L.x+L.rx,y1:L.y},{x0:d.x,y0:d.y,x1:L.x-L.rx,y1:L.y}];};
  P.fitsWashFloor=function(id,x,y){if(!this.fitsWash(id,x,y))return false;var f=this.footOf(id,x,y,0),ln=this.washLanes(),i,c,q,f2;
    for(i=0;i<ln.length;i++){c=distToSeg(x,y,ln[i]);if(c.d<Math.max(f.hx,f.hy)+9)return false;}   /* he walks the door-to-basin lanes in straight lines: never in his way */
    for(i=0;i<WASHF.length;i++){if(WASHF[i]===id||!this.placed(WASHF[i]))continue;q=this.placeOf(WASHF[i]);f2=this.footOf(WASHF[i],q.x,q.y,0);if(f.x0<f2.x1+1&&f.x1>f2.x0-1&&f.y0<f2.y1+1&&f.y1>f2.y0-1)return false;}
    return true;};
  P.placeWashItem=function(id,x,y){if(!isWashItem(id)||!this.owned(id))return "bad";if(!this.hasKey())return "nokey";
    if(x==null||y==null||!isFinite(+x)||!isFinite(+y)){var d0=WDEF[id];x=d0.x;y=d0.y;}x=+x;y=+y;
    if(!this.s.placeWash)this.s.placeWash={};
    if(isWashWall(id)){var sn=this.washWallSnap(id,x,y);if(!sn)return "blocked";this.s.placeWash[id]={x:sn.x,y:sn.y,r:sn.r};this.poke();return "ok";}
    var ra,i2,a2,px,py;for(ra=0;ra<=120;ra+=3){var nA=ra?Math.max(8,Math.round(ra*0.7)):1;for(i2=0;i2<nA;i2++){a2=i2*2*Math.PI/nA;px=x+Math.cos(a2)*ra;py=y+Math.sin(a2)*ra;
      if(this.fitsWashFloor(id,px,py)){this.s.placeWash[id]={x:px,y:py};this.poke();return "ok";}}}
    return "blocked";};
  /* 0.4.2: the EXACT spot first (0.4.1 always added a 10-unit pad, so he stopped short of the shipping X and stood off the table).
     Then the nearest free spot he can actually walk to, closest first. */
  P.standBeside=function(x,y){
    var lo=GEO.WALL+3,hx=RW-GEO.WALL-3,hy=RH-GEO.WALL-3,g=this.s.g,i,a,r,px,py;
    var D=gflood(gnear(g.x*RW,g.y*RH));
    function reach(px,py){var c=gcell(px,py),id=c[1]*GNX+c[0];if(D[id]>=0)return true;
      /* a free spot right next to a reachable cell is fine too (cells are 2 units) */
      var n=gnear(px,py);return n>=0&&D[n]>=0&&Math.hypot(cellPt(n)[0]-px,cellPt(n)[1]-py)<=GC*1.5&&clearSeg(cellPt(n)[0],cellPt(n)[1],px,py);}
    px=Math.max(lo,Math.min(hx,x));py=Math.max(lo,Math.min(hy,y));
    if(freePt(px,py)&&reach(px,py))return {x:px,y:py,dir:0};
    for(r=2;r<=40;r+=2){for(i=0;i<16;i++){a=i*Math.PI/8;px=x+Math.cos(a)*r;py=y+Math.sin(a)*r;
        if(px<lo||px>hx||py<lo||py>hy)continue;if(freePt(px,py)&&reach(px,py))return {x:px,y:py,dir:0};}}
    return {x:Math.max(lo,Math.min(hx,x)),y:Math.max(lo,Math.min(hy,y)),dir:0};
  };
  P.atCooler=function(){var g=this.s.g,x=g.x*RW,y=g.y*RH,K=GEO.cooler,dx=Math.max(K.x0-x,0,x-K.x1),dy=Math.max(K.y0-y,0,y-K.y1);return Math.hypot(dx,dy)<=GEO.INFL+4;};
  P.atTable=function(){var g=this.s.g,x=g.x*RW,y=g.y*RH,T=GEO.table,dx=Math.max(T.x0-x,0,x-T.x1),dy=Math.max(T.y0-y,0,y-T.y1);return Math.hypot(dx,dy)<=GEO.INFL+4;};
  P.sackSpot=function(){var st=tableKids().stand,o=rot(8,4,st.side===0?0:st.side===1?2:st.side===2?1:3),x=st.x+o[0],y=st.y+o[1];
    x=Math.max(GEO.WALL+3,Math.min(RW-GEO.WALL-3,x));y=Math.max(GEO.WALL+3,Math.min(RH-GEO.WALL-3,y));return {x:x,y:y};};
  P.missAt=function(x,y){var g=this.s.g;if(!Array.isArray(g.miss))g.miss=[];g.miss.push({x:x,y:y,t:this.s.t});if(g.miss.length>8)g.miss.shift();};
  P.nearestMess=function(){
    var s=this.s,mess=s.mess||[],gx=s.g.x*RW,gy=s.g.y*RH;
    if(!mess.length)return null;
    var used={},clusters=[],i,j,k,p,q,c;
    for(i=0;i<mess.length;i++){
      if(used[i])continue;
      c={x:0,y:0,n:0,ps:[]};q=[i];used[i]=1;
      while(q.length){
        k=q.pop();p=mess[k];c.ps.push(p);c.x+=p.x;c.y+=p.y;c.n++;
        for(j=0;j<mess.length;j++)if(!used[j]&&Math.hypot(mess[j].x-p.x,mess[j].y-p.y)<16){used[j]=1;q.push(j);}
      }
      c.x/=c.n;c.y/=c.n;clusters.push(c);
    }
    var miss=Array.isArray(s.g.miss)?s.g.miss:[],now=s.t;
    clusters=clusters.filter(function(c){for(var m=0;m<miss.length;m++)if(now-miss[m].t<30&&Math.hypot(miss[m].x-c.x,miss[m].y-c.y)<10)return false;return true;});
    clusters.sort(function(a,b){return Math.hypot(a.x-gx,a.y-gy)-Math.hypot(b.x-gx,b.y-gy);});
    return clusters[0]||null;
  };
  P.sweepSpot=function(){
    var c=this.nearestMess();
    if(!c){var k=tableKids();this.s.g.sweepTo=null;return {x:k.stand.x,y:k.stand.y,dir:0,n:0};}
    var pt=this.standBeside(c.x,c.y);this.s.g.sweepTo={x:c.x,y:c.y};
    return {x:pt.x,y:pt.y,dir:0,cx:c.x,cy:c.y,n:c.n};
  };
  P.sweepNear=function(x,y,n,reach){
    var s=this.s;if(!s.mess)s.mess=[];
    reach=reach||16;var near=[],far=[],i,d,p,take,left;
    for(i=0;i<s.mess.length;i++){p=s.mess[i];d=Math.hypot(p.x-x,p.y-y);if(d<=reach)near.push({d:d,p:p});else far.push(p);}
    near.sort(function(a,b){return a.d-b.d;});
    take=near.slice(0,n);left=near.slice(n);
    for(i=0;i<left.length;i++)far.push(left[i].p);
    s.mess=far;s.peels=s.mess.length;
    var removed=[];for(i=0;i<take.length;i++)removed.push({x:take[i].p.x,y:take[i].p.y,d:take[i].d});
    if(removed.length){s.stats.swept+=removed.length;
      if(this.placed("compost")){var dc=s.decor||(s.decor=decorFresh());dc.compostN=(dc.compostN|0)+removed.length;while(dc.compostN>=20){dc.compostN-=20;s.coins+=1;s.stats.earned+=1;dc.compost=(dc.compost|0)+1;}}}
    this.lastSweep={x:x,y:y,removed:removed};
    return removed.length;
  };
  P.syncGeom=function(){
    var s=this.s,pl=s.place||{},k,bs,tv,sk,rd,lp,pn,ct;
    copyBox(GEO,GEO0);copyBox(SPOT,SPOT0);
    var tr=pl.table?(pl.table.r|0)&3:0,cr=pl.cooler?(pl.cooler.r|0)&3:0,mr=(pl.mat||pl.bed)?((pl.mat||pl.bed).r|0)&3:0;
    GEO.table.r=tr;GEO.cooler.r=cr;GEO.mat.r=mr;GEO.tableStand=null;GEO.bedSide=null;
    if(pl.table||tr){var tc=pl.table||{x:(GEO.table.x0+GEO.table.x1)/2,y:(GEO.table.y0+GEO.table.y1)/2},thx=(tr&1)?9:17,thy=(tr&1)?17:9;
      GEO.table.x0=tc.x-thx;GEO.table.x1=tc.x+thx;GEO.table.y0=tc.y-thy;GEO.table.y1=tc.y+thy;}
    k=tableKids();SPOT.table.x=k.stand.x;SPOT.table.y=k.stand.y;SPOT.table.dir=0;
    GEO.mess.cx=k.cx;GEO.mess.cy=GEO.table.y1+16;
    if(pl.cooler||cr){var cc=pl.cooler||{x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:(GEO.cooler.y0+GEO.cooler.y1)/2},chx=(cr&1)?5:7,chy=(cr&1)?7:5;
      GEO.cooler.x0=cc.x-chx;GEO.cooler.x1=cc.x+chx;GEO.cooler.y0=cc.y-chy;GEO.cooler.y1=cc.y+chy;}
    if(pl.stool){GEO.stool.x=pl.stool.x;GEO.stool.y=pl.stool.y;}
    else{GEO.stool.x=GEO0.stool.x;GEO.stool.y=GEO0.stool.y;}   /* 0.4.3: the seat is its own object; it never follows the cooler */
    SPOT.food.x=(GEO.cooler.x0+GEO.cooler.x1)/2;SPOT.food.y=GEO.cooler.y1+GEO.INFL+1;SPOT.food.dir=0;   /* refined to a free cooler side in pickStand */
    if(pl.mat||pl.bed){var m=pl.mat||pl.bed;GEO.mat.x=m.x;GEO.mat.y=m.y;}
    if(mr&1){var mw0=GEO0.mat.w,mh0=GEO0.mat.h;GEO.mat.w=mh0;GEO.mat.h=mw0;}
    bs=bedside();SPOT.mat.x=bs.x;SPOT.mat.y=bs.y;SPOT.mat.dir=bs.dir;
    if(this.placed("sink")){sk=this.placeOf("sink");var so=rot(0,12,sk.r|0);SPOT.sink.x=sk.x+so[0];SPOT.sink.y=sk.y+so[1];SPOT.sink.dir=(sk.r|0)&3;}
    if(this.placed("tvArmchair")){tv=this.placeOf("tvArmchair");SPOT.tv.x=tv.x-8;SPOT.tv.y=tv.y+12;}
    if(this.placed("radio")){rd=this.placeOf("radio");SPOT.radio.x=rd.x-8;SPOT.radio.y=rd.y;}
    if(this.placed("lamp")){lp=this.placeOf("lamp");SPOT.lamp.x=lp.x-8;SPOT.lamp.y=lp.y;}
    if(this.placed("plant")){pn=this.placeOf("plant");SPOT.plant.x=pn.x;SPOT.plant.y=pn.y+12;}
    if(this.placed("basicCot")){ct=this.placeOf("basicCot");SPOT.cot.x=ct.x;SPOT.cot.y=ct.y+14;}
    this.syncTops();
  };
  P.lineOn=function(which){
    var b=this.s.box;
    if(which==="suction")return this.placed("suction")&&b.suction>0&&this.placed("conveyor")&&b.conveyor>0;
    if(which==="conveyor")return this.placed("conveyor")&&b.conveyor>0;
    if(which==="peeler")return this.placed("autoPeeler")&&b.apeeler>0;
    if(which==="outbelt")return this.placed("outConveyor")&&b.outbelt>0;
    return false;
  };
  P.lineRunning=function(){return this.lineOn("suction")&&this.lineOn("conveyor")&&this.lineOn("peeler")&&this.lineOn("outbelt");};
  P.beltSpd=function(){return BELT_SPD[this.s.box.conveyor]||0;};
  P.outSpd=function(){return BELT_SPD[this.s.box.outbelt]||0;};
  P.peelSpd=function(){return (BELT_SPD[this.s.box.apeeler]||0)*Math.pow(1.20,this.up("apeeler"));};
  P.beltMul=function(){return Math.pow(1.15,this.up("belts"));};
  P.peelCap=function(){return 1+this.up("apeeler");};
  P.carryCap=function(){return this.equipped("carryBag")?(2+this.up("bag")):1;};
  P.heldN=function(){var g=this.s.g;if(!g.hold)return 0;var n=g.held|0;return n>0?n:1;};
  P.sitSpot=function(){var tv=this.placeOf("tvArmchair"),r=tv.r|0,o=rot(-5.6,0.4,r);return {x:tv.x+o[0],y:tv.y+o[1],dir:(1+r)&3};};
  P.levelPrice=function(){var n=this.s.level+1;if(n>5)return null;return this.placed("bookshelf")?Math.round(LEVEL_PRICE[n]*0.9):LEVEL_PRICE[n];};
  P.buyLevel=function(){var s=this.s,pr=this.levelPrice();if(pr===null)return "max";if(s.coins<pr)return "poor";s.coins-=pr;s.level++;s.stats.spent+=pr;s.stats.boughtUp++;this.emit({k:"level",lv:s.level});return "ok";};
  P.itemPrice=function(id){var it=ITEMI[id];if(!it)return null;if(this.owned(id))return null;return it.price;};
  P.buyItem=function(id){var s=this.s,it=ITEMI[id];if(!it)return "bad";if(!this.unlocked(id))return "locked";if(this.owned(id))return "have";if(s.coins<it.price)return "poor";
    s.coins-=it.price;s.owned[id]=1;if(!s.place)s.place={};if(!s.equipped)s.equipped={};
    /* 0.4.1: bought items go to the inventory first, not auto-placed / auto-equipped */
    s.stats.spent+=it.price;s.stats.boughtUp++;this.poke();this.emit({k:"item",id:id});return "ok";};
  /* 0.4.2 footprints (half sizes, unrotated) for every object the editor can move */
  var FOOT={table:[17,9],cooler:[7,5],stool:[5,5],mat:[16,9],bed:[16,9],autoPeeler:[12,12],sink:[8,8],basicCot:[14,8],tvArmchair:[16,8],smallCooler:[7,6],plant:[6,6],lamp:[5,6],radio:[5,5],suction:[8,8],conveyor:[6,18],outConveyor:[14,6],rug:[12,8],
    kitchenMat:[9,6],runner:[6,20],roundRug:[11,11],clock:[4,3.5],poster:[5,3.5],fan:[5,5],shelf:[10,4],
    window:[7,3.5],spiceRack:[5,3.5],coatHook:[3.5,3.5],calendar:[3.5,3.5],potsPans:[7,3.5],photos:[6,3.5],stringLights:[12,3.5],neonSign:[7,3.5],trophyShelf:[8,3.5],
    sideTable:[7,5],compost:[5,5],sackPile:[8,6],bookshelf:[10,4],catBed:[6,5],statue:[5,5],fruitBowl:[3,3],cookbook:[3,3],aquarium:[3.2,2.6],towelRack:[9.6,3.5],soap:[4.8,3.5],mopBucket:[8,8]};   /* wash items are drawn 1.6x (the wash room is drawn at a smaller scale) */
  Sim.FOOT=FOOT;
  P.rotOf=function(id){if(id==="bed")id="mat";var p=this.s.place&&this.s.place[id];if(p&&typeof p.r==="number")return p.r&3;return 0;};
  P.centerOf=function(id){
    if(id==="washPile"){this.syncWashGeom();return {x:WASH.pile.cx,y:WASH.pile.cy};}
    if(id==="streetMouth"){this.syncWashGeom();return {x:WASH.mouth.x,y:WASH.mouth.y};}
    if(id==="table")return {x:(GEO.table.x0+GEO.table.x1)/2,y:(GEO.table.y0+GEO.table.y1)/2};
    if(id==="cooler")return {x:(GEO.cooler.x0+GEO.cooler.x1)/2,y:(GEO.cooler.y0+GEO.cooler.y1)/2};
    if(id==="stool")return {x:GEO.stool.x,y:GEO.stool.y};if(id==="mat"||id==="bed")return {x:GEO.mat.x,y:GEO.mat.y};
    return this.placeOf(id);};
  P.footOf=function(id,x,y,r){if(id==="washPile"||id==="streetMouth"){var wf=this.washFoot(id,x,y);wf.hx=(wf.x1-wf.x0)/2;wf.hy=(wf.y1-wf.y0)/2;return wf;}
    var f=FOOT[id]||[6,6],hx=f[0],hy=f[1];if(r&1){hx=f[1];hy=f[0];}return {x0:x-hx,y0:y-hy,x1:x+hx,y1:y+hy,hx:hx,hy:hy};};
  /* can this object sit here? inside the room, off the fixed pile / return / shipping, off the shipping X, and not on top of another object */
  P.fits=function(id,x,y,r){if(isWall(id))return this.fitsWall(id,x,y,r);
    var f=this.footOf(id,x,y,r),W0=GEO.WALL+1;
    if(f.x0<W0||f.y0<W0||f.x1>RW-W0||f.y1>RH-W0)return false;
    if(!sanePlace(id,x,y,f))return false;
    if(isRug(id)){   /* carpets never lie on top of each other */
      for(var ri=0;ri<RUGS.length;ri++){var rid=RUGS[ri];if(rid===id||!this.placed(rid))continue;var rp=this.placeOf(rid),rf=this.footOf(rid,rp.x,rp.y,rp.r|0);
        if(f.x0<rf.x1-0.01&&f.x1>rf.x0+0.01&&f.y0<rf.y1-0.01&&f.y1>rf.y0+0.01)return false;}
      return true;}
    {
      var sp=SPOT.ship,I=GEO.INFL+0.5;if(f.x0<sp.x+I&&f.x1>sp.x-I&&f.y0<sp.y+I&&f.y1>sp.y-I)return false;   /* keep his shipping X clear */
      for(var j=0;j<OBST.length;j++){var o=OBST[j];if(o.id===id||(id==="mat"&&o.id==="bed")||o.id==="ship"||o.id==="ret")continue;
        if(f.x0<o.x1-0.01&&f.x1>o.x0+0.01&&f.y0<o.y1-0.01&&f.y1>o.y0+0.01)return false;}
      var g=this.s.g,gx=g.x*RW,gy=g.y*RH;   /* never drop furniture on top of Papa */
      if(gx>f.x0-1&&gx<f.x1+1&&gy>f.y0-1&&gy<f.y1+1&&!(g.act&&(g.act.t==="nap"||g.act.t==="watch")))return false;
    }
    return true;};
  /* 0.4.10 wall items: r=0 north wall, r=1 east wall, r=3 west wall. They sit IN the wall band, off the door, the scanner housing and the return chute. */
  P.fitsWall=function(id,x,y,r){r=(r|0)&3;var f=this.footOf(id,x,y,r),W=GEO.WALL,i,id2,q,f2;
    if(r===0){if(Math.abs(y-W/2)>0.01)return false;if(f.x0<W+1||f.x1>RW-W-1)return false;
      var D=WASH.kitDoor;if(f.x1>D.x0-1&&f.x0<D.x0+D.w+1)return false;
      var sx=GEO.ship.x;if(f.x1>sx-12&&f.x0<sx+14)return false;}
    else if(r===1||r===3){if(Math.abs(x-(r===1?RW-W/2:W/2))>0.01)return false;if(f.y0<W+2||f.y1>RH-W-2)return false;
      if(r===1){var rt=GEO.ret;if(f.y1>rt.y-rt.w/2-4&&f.y0<rt.y+rt.w/2+4)return false;}}
    else return false;
    for(i=0;i<WALLS.length;i++){id2=WALLS[i];if(id2===id||!this.placed(id2))continue;q=this.placeOf(id2);f2=this.footOf(id2,q.x,q.y,q.r|0);
      if(f.x0<f2.x1+1&&f.x1>f2.x0-1&&f.y0<f2.y1+1&&f.y1>f2.y0-1)return false;}
    return true;};
  /* the nearest wall spot to (x,y) where it fits: try the closest wall first, slide along it */
  P.wallSnap=function(id,x,y){var W=GEO.WALL,walls=[{r:0,d:Math.abs(y)},{r:3,d:Math.abs(x)},{r:1,d:Math.abs(RW-x)}],i,j,o,px,py,a;
    walls.sort(function(a1,b1){return a1.d-b1.d;});
    for(i=0;i<walls.length;i++){var r=walls[i].r;
      for(j=0;j<=240;j++){o=(j&1?1:-1)*Math.ceil(j/2)*1;
        if(r===0){px=x+o;py=W/2;}else{px=r===1?RW-W/2:W/2;py=y+o;}
        if(this.fitsWall(id,px,py,r))return {x:px,y:py,r:r};}}
    return null;};
  P.findFree=function(id,x,y,r){var f=this.footOf(id,x,y,r),W0=GEO.WALL+1,ra,i,a,px,py;
    x=Math.max(W0+f.hx,Math.min(RW-W0-f.hx,x));y=Math.max(W0+f.hy,Math.min(RH-W0-f.hy,y));
    if(this.fits(id,x,y,r))return {x:x,y:y};
    for(ra=2;ra<=14;ra+=2)for(i=0;i<12;i++){a=i*Math.PI/6;px=x+Math.cos(a)*ra;py=y+Math.sin(a)*ra;if(this.fits(id,px,py,r))return {x:px,y:py};}
    return null;};
  P.canMove=function(id){if(id==="washPile")return false; /* 0.4.8: dry pile hidden; basin heap stays with the basin */ if(id==="streetMouth")return false;
    if(FIXED.indexOf(id)>=0)return false;
    if(id==="pile"||id==="ret"||id==="ship"||id==="return"||id==="shipping")return false;
    if(isTool(id))return false;
    if(isPlaceable(id))return this.placed(id);
    return STARTER.indexOf(id)>=0||id==="bed";};
  /* apply a new centre / rotation; refuse (and undo) anything that would trap him away from a key spot */
  P.applyPlace=function(id,x,y,r){
    if(id==="bed")id="mat";
    if(!this.s.place)this.s.place={};
    var key=id,old=this.s.place[key]?JSON.parse(JSON.stringify(this.s.place[key])):null,oldStool=this.s.place.stool?JSON.parse(JSON.stringify(this.s.place.stool)):null;
    var c0=this.centerOf(id);
    this.s.place[key]={x:x,y:y};if(r)this.s.place[key].r=r;
    this.refresh();
    if(!this.connected()){if(old)this.s.place[key]=old;else delete this.s.place[key];
      this.refresh();return false;}
    this.replan();return true;};
  P.moveItem=function(id,x,y){
    if(id==="streetMouth")return "bad"; /* 0.4.5: mouth is hidden; inlet/canal/hole stay on the walls */
    if(id==="washPile")return "bad"; /* 0.4.8: do not drag the hidden dry pile; moveWashItem stays in the file */
    x=+x;y=+y;if(!isFinite(x)||!isFinite(y))return false;
    if(!this.canMove(id))return false;
    var key=id==="bed"?"mat":id,r=this.rotOf(key);
    if(isWashItem(key)){if(isWashWall(key)){var ww=this.washWallSnap(key,x,y);if(!ww)return false;this.s.placeWash[key]={x:ww.x,y:ww.y,r:ww.r};return true;}
      if(!this.fitsWashFloor(key,x,y))return false;this.s.placeWash[key]={x:x,y:y};return true;}
    if(isTop(key)){var old=this.s.place[key];var rr=this.placeTop(key,x,y);return rr==="ok";}
    if(isWall(key)){var wsn=this.wallSnap(key,x,y);if(!wsn)return false;return this.applyPlace(key,wsn.x,wsn.y,wsn.r);}
    var sp=this.findFree(key,x,y,r);if(!sp)return false;
    return this.applyPlace(key,sp.x,sp.y,r);
  };
  /* ROTATE (0.4.2): a quarter turn clockwise. If the turned shape does not fit where it is, it shifts a little; if it cannot fit at all it stays. */
  P.rotateItem=function(id){
    if(id==="washPile"||id==="streetMouth")return false;
    if(isWall(id)||isTop(id)||isWashItem(id))return false;   /* wall items turn with the wall they hang on; table-tops sit in a slot; wash decor stays upright */
    if(!this.canMove(id))return false;
    var key=id==="bed"?"mat":id,r=(this.rotOf(key)+1)&3,c=this.centerOf(key);
    for(var tries=0;tries<4;tries++){var sp=this.findFree(key,c.x,c.y,r);if(sp&&this.applyPlace(key,sp.x,sp.y,r))return true;r=(r+1)&3;if(r===this.rotOf(key))break;}
    return false;
  };
  function sanePlace(id,x,y,fp){
    /* may not cover the fixed pile, return mouth, or shipping unit (0.4.2: the whole footprint, not just the middle) */
    var ship={x0:GEO.ship.x-10,y0:GEO.WALL,x1:GEO.ship.x+12,y1:GEO.ship.lip+8};
    var pile={x0:GEO.pile.cx-GEO.pile.rx,y0:GEO.pile.base-8,x1:GEO.pile.cx+GEO.pile.rx,y1:RH-GEO.WALL};
    var ret={x0:GEO.ret.mouthX-2,y0:GEO.ret.y-8,x1:RW-GEO.WALL,y1:GEO.ret.y+8};
    var box=fp||{x0:x-6,y0:y-6,x1:x+6,y1:y+6};
    function hit(a,b){return a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0;}
    if(hit(box,ship)||hit(box,ret))return false;
    /* suction is built to sit on the pile; other items may not cover it */
    if(id!=="suction"&&hit(box,pile))return false;
    return true;
  }
  P.rebuildObst=function(){
    var list=[],p,m=GEO.mat,sh=GEO.ship,rt=GEO.ret;
    list.push({id:"table",x0:GEO.table.x0,y0:GEO.table.y0,x1:GEO.table.x1,y1:GEO.table.y1});
    list.push({id:"cooler",x0:GEO.cooler.x0,y0:GEO.cooler.y0,x1:GEO.cooler.x1,y1:GEO.cooler.y1});
    list.push({id:"stool",x0:GEO.stool.x-5,y0:GEO.stool.y-5,x1:GEO.stool.x+5,y1:GEO.stool.y+5});
    list.push({id:"bed",x0:m.x-m.w/2,y0:m.y-m.h/2,x1:m.x+m.w/2,y1:m.y+m.h/2});
    list.push({id:"ship",x0:sh.x-10,y0:GEO.WALL,x1:sh.x+12,y1:GEO.WALL+16}); /* 0.4.7: housing only; belt stays walkable */
    list.push({id:"ret",x0:rt.mouthX,y0:rt.y-rt.w/2-1,x1:RW-GEO.WALL,y1:rt.y+rt.w/2+1});
    function add(id,hx,hy){if(!this.placed(id))return;p=this.placeOf(id);if((p.r|0)&1){var tq=hx;hx=hy;hy=tq;}list.push({id:id,x0:p.x-hx,y0:p.y-hy,x1:p.x+hx,y1:p.y+hy});}
    add.call(this,"autoPeeler",12,12);
    add.call(this,"sink",8,8);
    add.call(this,"basicCot",14,8);
    add.call(this,"tvArmchair",16,8);
    add.call(this,"smallCooler",7,6);
    add.call(this,"plant",6,6);
    add.call(this,"lamp",5,6);
    add.call(this,"radio",5,5);
    add.call(this,"suction",8,8);
    add.call(this,"fan",5,5);     /* 0.4.10 */
    add.call(this,"shelf",10,4);
    for(var fi=0;fi<FLOOR11.length;fi++){var ff=FOOT[FLOOR11[fi]];add.call(this,FLOOR11[fi],ff[0],ff[1]);}   /* 0.4.11 floor decor blocks walking */
    /* 0.4.2: the inbound / outbound belts are low runs along the walls (drawn at GEO.beltX / outBeltY). 0.4.1 put an invisible 12x36 block at the TV spot for them; gone. */
    OBST=list;INF=inflated();Sim.OBST=OBST;GVER++;
    this.pickStand();
  };
  /* 0.4.2: where he stands to peel. The side of the table that is free and reachable: front (south) first, then the far sides.
     Wherever the table goes (against the back wall, a side wall, next to the bed), he peels AT it, facing it, never off on the floor. */
  P.pickStand=function(){
    var T=GEO.table,cx=(T.x0+T.x1)/2,cy=(T.y0+T.y1)/2,d=GEO.INFL+1,odd=(T.r|0)&1;
    var C0=[{side:0,x:cx,y:T.y1+d,dir:0},{side:1,x:cx,y:T.y0-d,dir:2},{side:2,x:T.x0-d,y:cy,dir:1},{side:3,x:T.x1+d,y:cy,dir:3}];
    var order=odd?[3,2,0,1]:[0,1,2,3],ship=this.shipSpot(),D=gflood(gnear(ship.x,ship.y)),i,c,cell,f,q;
    var best=null,FR=[0,-0.2,0.2,-0.35,0.35,-0.45,0.45];
    /* centre of the side first, then slide along the edge (still touching the table) */
    for(i=0;i<4&&!best;i++){c=C0[order[i]];for(f=0;f<FR.length;f++){
        q={side:c.side,dir:c.dir,x:c.side>=2?c.x:cx+FR[f]*(T.x1-T.x0),y:c.side<2?c.y:cy+FR[f]*(T.y1-T.y0)};
        if(!freePt(q.x,q.y))continue;cell=gcell(q.x,q.y);if(D[cell[1]*GNX+cell[0]]<0)continue;best=q;break;}}
    this.standOk=!!best;
    if(!best){for(i=0;i<4;i++){c=C0[order[i]];if(freePt(c.x,c.y)){best=c;break;}}}
    if(!best)best=C0[0];
    GEO.tableStand={x:best.x,y:best.y,dir:best.dir,side:best.side};
    SPOT.table.x=best.x;SPOT.table.y=best.y;SPOT.table.dir=best.dir;
    var mo=best.side===0?[0,16]:best.side===1?[0,-16]:best.side===2?[-16,0]:[16,0];
    GEO.mess.cx=best.x+mo[0]*0.3;GEO.mess.cy=best.y+mo[1]*0.4;
    /* the bedside he gets in / out from: a free side he can walk to (0.4.1 always used the south side, even when that was boxed in) */
    var m=GEO.mat,I=GEO.INFL+3,B=[[m.x,m.y+m.h/2+I],[m.x,m.y-m.h/2-I],[m.x-m.w/2-I,m.y],[m.x+m.w/2+I,m.y]],bb=null;
    for(i=0;i<4&&!bb;i++){for(f=0;f<FR.length;f++){var bx=B[i][0]+(i<2?FR[f]*m.w:0),by=B[i][1]+(i>=2?FR[f]*m.h:0);
        if(!freePt(bx,by))continue;cell=gcell(bx,by);if(D[cell[1]*GNX+cell[0]]<0)continue;bb={x:bx,y:by};break;}}
    this.bedOk=!!bb;GEO.bedSide=bb||{x:B[0][0],y:B[0][1]};
    SPOT.mat.x=GEO.bedSide.x;SPOT.mat.y=GEO.bedSide.y;SPOT.mat.dir=0;
    /* 0.4.3: he eats AT THE COOLER (Jay t1174), from its front if that is open, else the nearest free side he can reach */
    var K=GEO.cooler,kx=(K.x0+K.x1)/2,ky=(K.y0+K.y1)/2,kd=GEO.INFL+1,kr=(K.r|0)&3;
    var KS=[{s:0,x:kx,y:K.y1+kd,dir:0},{s:1,x:kx,y:K.y0-kd,dir:2},{s:2,x:K.x0-kd,y:ky,dir:1},{s:3,x:K.x1+kd,y:ky,dir:3}];
    var KO=[[0,2,3,1],[2,0,1,3],[1,3,2,0],[3,1,0,2]][kr],kb=null;
    for(i=0;i<4&&!kb;i++){c=KS[KO[i]];for(f=0;f<FR.length;f++){
        q={side:c.s,dir:c.dir,x:c.s>=2?c.x:kx+FR[f]*(K.x1-K.x0),y:c.s<2?c.y:ky+FR[f]*(K.y1-K.y0)};
        if(!freePt(q.x,q.y))continue;cell=gcell(q.x,q.y);if(D[cell[1]*GNX+cell[0]]<0)continue;kb=q;break;}}
    this.foodOk=!!kb;if(!kb)kb={x:KS[KO[0]].x,y:KS[KO[0]].y,dir:KS[KO[0]].dir,side:KO[0]};
    GEO.coolerSide=kb;SPOT.food.x=kb.x;SPOT.food.y=kb.y;SPOT.food.dir=kb.dir;
  };
  P.shipSpot=function(){return {x:SPOT.ship.x,y:SPOT.ship.y};};
  /* every place he must reach, for the editor's no-trap check */
  P.keySpots=function(){var o=[{k:"ship",x:SPOT.ship.x,y:SPOT.ship.y},{k:"table",x:SPOT.table.x,y:SPOT.table.y},{k:"food",x:SPOT.food.x,y:SPOT.food.y},{k:"bed",x:SPOT.mat.x,y:SPOT.mat.y},{k:"pile",x:(SPOT.pile.x0+SPOT.pile.x1)/2,y:SPOT.pile.y,wide:true}];
    if(this.placed("sink"))o.push({k:"sink",x:SPOT.sink.x,y:SPOT.sink.y});
    return o;};
  /* true when he can walk from the shipping X to every key spot (or a free spot within 6 of it) */
  P.connected=function(){var sp=this.keySpots(),D=gflood(gnear(sp[0].x,sp[0].y)),i,j,c,ok,x;
    if(!freePt(sp[0].x,sp[0].y))return false;
    var c0=gnear(sp[0].x,sp[0].y);if(c0<0)return false;var cp0=cellPt(c0);
    if(Math.hypot(cp0[0]-sp[0].x,cp0[1]-sp[0].y)>GC*1.5||!clearSeg(cp0[0],cp0[1],sp[0].x,sp[0].y))return false;   /* the shipping X itself must be walkable, not just something near it */
    if(!this.standOk||!this.bedOk||!this.foodOk)return false;   /* he must be able to stand AT the table, AT the cooler, and get to the bed */
    for(i=1;i<sp.length;i++){ok=false;
      if(sp[i].wide){for(x=SPOT.pile.x0;x<=SPOT.pile.x1&&!ok;x+=2){c=gcell(x,sp[i].y);if(D[c[1]*GNX+c[0]]>=0)ok=true;}}
      else{for(j=0;j<=12&&!ok;j+=2){for(var a=0;a<16&&!ok;a++){var px=sp[i].x+Math.cos(a*0.3927)*j,py=sp[i].y+Math.sin(a*0.785)*j;if(!freePt(px,py))continue;c=gcell(px,py);if(D[c[1]*GNX+c[0]]>=0)ok=true;if(j===0)break;}}}
      if(!ok)return false;}
    /* and Papa himself must not be boxed in where he stands now (in bed / in the chair: from where he gets up) */
    var g=this.s.g,at=g.act,px=g.x*RW,py=g.y*RH;
    if(at&&at.t==="nap"){var bs=bedside();px=bs.x;py=bs.y;}else if(at&&at.t==="watch"){var ts=this.sitSpot();px=ts.x;py=ts.y+10;}
    var pc=gnear(px,py);if(pc<0||D[pc]<0)return false;
    return true;};
  /* peels that end up under furniture after a move are pushed out to the nearest free floor */
  P.fixMess=function(){var s=this.s,m=s.mess||[],i,j,o,p,d,best,bd,cs;
    for(i=0;i<m.length;i++){p=m[i];for(j=0;j<OBST.length;j++){o=OBST[j];if(p.x>o.x0-1&&p.x<o.x1+1&&p.y>o.y0-1&&p.y<o.y1+1){
          cs=[[o.x0-3,p.y],[o.x1+3,p.y],[p.x,o.y0-3],[p.x,o.y1+3]];best=null;bd=1e9;
          for(var q=0;q<4;q++){var x=cs[q][0],y=cs[q][1];if(x<GEO.WALL+3||x>RW-GEO.WALL-3||y<GEO.WALL+3||y>GEO.pile.base-GEO.pile.rz-4)continue;d=Math.abs(x-p.x)+Math.abs(y-p.y);if(d<bd){bd=d;best=cs[q];}}
          if(best){p.x=best[0];p.y=best[1];}break;}}}};
  /* after the room changes: if what he is doing now no longer makes sense where he stands, re-plan */
  P.replan=function(){var s=this.s,g=s.g,a=g.act;if(!a)return;
    if(a.t==="nap"){g.x=GEO.mat.x/RW;g.y=GEO.mat.y/RH;return;}
    if(a.t==="watch"){var sp=this.sitSpot();g.x=sp.x/RW;g.y=sp.y/RH;return;}
    if(a.t==="lazynap"||a.t==="idle")return;
    var x=g.x*RW,y=g.y*RH,inside=false;for(var j=0;j<OBST.length;j++){var o=OBST[j];if(x>o.x0&&x<o.x1&&y>o.y0&&y<o.y1){inside=true;break;}}
    var spot=(a.t==="peel"||a.t==="rinse")?SPOT.table:a.t==="drop"?SPOT.ship:a.t==="wash"?SPOT.sink:a.t==="eat"?SPOT.food:null;
    if(a.t==="walk"||inside||(spot&&Math.hypot(spot.x-x,spot.y-y)>3)||(a.t==="sweep")){g.sack=null;this.decide();}
  };
  P.refresh=function(){this.syncGeom();this.rebuildObst();this.fixMess();};
  P.lineStep=function(dt){
    var s=this.s;if(!s.line)s.line=lineFresh();
    var L=s.line,mul=this.beltMul();
    /* suction + inbound */
    if(this.lineOn("suction")&&this.lineOn("conveyor")&&s.pile>0&&L.beltIn.length<4){
      s.pile--;L.beltIn.push({p:0,raw:true});this.emit({k:"suction"});
    }
    var vIn=(this.lineOn("conveyor")?this.beltSpd():0)*mul*0.22*dt;
    var i,p,it;
    if(vIn>0){
      for(i=0;i<L.beltIn.length;i++)L.beltIn[i].p=Math.min(1,L.beltIn[i].p+vIn);
      /* feed peeler when a potato arrives */
      if(L.beltIn.length&&L.beltIn[0].p>=1&&this.lineOn("peeler")&&!L.peeler){
        L.beltIn.shift();L.peeler={t:0,done:false,emitted:false};
      }else if(L.beltIn.length&&L.beltIn[0].p>=1&&!this.lineOn("peeler")){
        /* wait at the end of the belt */
        L.beltIn[0].p=1;
      }
    }
    if(L.peeler){
      if(this.lineOn("peeler")){
        L.peeler.t+=dt*this.peelSpd()*0.55;
        if(!L.peeler.emitted&&L.peeler.t>=0.45){L.peeler.emitted=true;this.peelEmit(3,"peeler");L.emitted=(L.emitted||0)+3;}
        if(L.peeler.t>=1)L.peeler.done=true;
      }
      if(L.peeler.done){
        if(this.lineOn("outbelt")&&L.beltOut.length<4){L.beltOut.push({p:0});L.peeler=null;}
        /* else hold the finished potato so conservation stays honest */
      }
    }
    var vOut=(this.lineOn("outbelt")?this.outSpd():0)*mul*0.22*dt;
    if(vOut>0){
      for(i=0;i<L.beltOut.length;i++)L.beltOut[i].p=Math.min(1,L.beltOut[i].p+vOut);
      if(L.beltOut.length&&L.beltOut[0].p>=1){
        L.beltOut.shift();L.shipped=(L.shipped||0)+1;L.shipQ++;
        if(this.wantsWashDivert()){this.intakeWash({washed:true,sloppy:false,auto:true,fromHole:true});s.stats.peeled++;this.emit({k:"toWash",washed:true,sloppy:false,auto:true,fromHole:true});}
        else{this.kitchenShipOne({washed:false,sloppy:false,auto:true});this.emit({k:"ship",washed:false,sloppy:false,auto:true});}
      }
    }
  };
  P.neonTip=function(){var d=this.s.decor;if(!d||!this.placed("neonSign"))return 0;d.shipN=(d.shipN|0)+1;if(d.shipN>=20){d.shipN=0;d.tips=(d.tips|0)+1;this.emit({k:"tip"});return 1;}return 0;};
  P.decorStep=function(dt){
    var s=this.s;if(!s.decor)s.decor=decorFresh();
    /* 0.4.11 calendar payday: 10c at each new shift day while it hangs (no back pay for days before it went up) */
    var day=this.clockTime().day;if(!(s.decor.day>0))s.decor.day=day;
    if(day>s.decor.day){if(this.placed("calendar")){s.coins+=10;s.stats.earned+=10;s.decor.paydays=(s.decor.paydays|0)+1;this.emit({k:"payday"});}s.decor.day=day;}
    if(this.placed("plant"))s.decor.plant=Math.min(100,s.decor.plant+dt*0.15);
    /* 0.4.10: the old flat radio energy tick is replaced by energyMul (music = 20% slower drain) */
  };
  P.lineTotals=function(){
    var s=this.s,L=s.line||lineFresh(),k=s.suck;
    var n=s.pile+this.heldN()+s.chute+(k?k.n-k.landed:0)+(L.beltIn?L.beltIn.length:0)+(L.peeler?1:0)+(L.beltOut?L.beltOut.length:0)+washCount(s.wash);
    return {potatoes:n,pile:s.pile,hold:this.heldN(),chute:s.chute,pipe:k?k.n-k.landed:0,beltIn:L.beltIn.length,peeler:L.peeler?1:0,beltOut:L.beltOut.length,shipped:L.shipped||0,peels:s.peels,wash:washCount(s.wash)};
  };

  P.hasKey=function(){return this.owned("roomKey");};
  P.wantsAutoWash=function(){return this.hasKey()&&this.owned("autoWash")&&this.s.box.awash>0;};
  P.wantsWashDivert=function(){var g=this.s.g;return this.hasKey()&&(g.force==="washPool"||g.holdRepeat==="wash"||this.wantsAutoWash());};
  P.setHold=function(id,on){
    var g=this.s.g;
    if(on){g.holdRepeat=id;if(id==="work"){g.force=null;return "ok";}return this.commandNow(id);}
    g.holdRepeat=null;return "ok";};
  P.kitchenShipOne=function(opt){
    opt=opt||{};var s=this.s,p={washed:!!opt.washed,sloppy:!!opt.sloppy};
    if(s.chute>=this.chuteCap()&&!s.suck)this.startSuck();
    if(s.chute>=this.chuteCap())return false;
    var v=shipPay(p)+this.neonTip();
    s.chute++;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;
    if(p.washed)s.stats.washedShip=(s.stats.washedShip|0)+1;else s.stats.unwashedShip=(s.stats.unwashedShip|0)+1;
    if(s.chute>=this.chuteCap())this.startSuck();
    this.emit({k:"coin",v:v,sloppy:!!p.sloppy,washed:!!p.washed,from:"kitchen"});
    return true;};
  P.syncWashGeom=function(){
    var pl=this.s.placeWash||{},P=WASH0.pile,M=WASH0.mouth;
    if(pl.washPile&&isFinite(+pl.washPile.x)&&isFinite(+pl.washPile.y)){WASH.pile.cx=+pl.washPile.x;WASH.pile.cy=+pl.washPile.y;}
    else{WASH.pile.cx=P.cx;WASH.pile.cy=P.cy;}
    if(pl.streetMouth&&isFinite(+pl.streetMouth.x)&&isFinite(+pl.streetMouth.y)){WASH.mouth.x=+pl.streetMouth.x;WASH.mouth.y=+pl.streetMouth.y;}
    else{WASH.mouth.x=M.x;WASH.mouth.y=M.y;}
  };
  P.washFoot=function(id,x,y){
    if(id==="washPile")return {x0:x-16,y0:y-14,x1:x+16,y1:y+14};
    if(id==="streetMouth")return {x0:x-10,y0:y-10,x1:x+10,y1:y+10};
    return {x0:x-8,y0:y-8,x1:x+8,y1:y+8};};
  P.fitsWash=function(id,x,y){
    var f=this.washFoot(id,x,y),W0=GEO.WALL+2,h=WASH.hole,D=WASH.door,L=WASH.land,I=WASH.inlet,O=WASH.outlet,hit,ox0,oy0;
    if(f.x0<W0||f.x1>WW-W0||f.y0<W0||f.y1>WH-W0)return false;
    if(!(f.x1<h.x-h.r-4||f.x0>h.x+h.r+4||f.y1<h.y-h.r-6||f.y0>h.y+h.r+6))return false;
    if(!(f.x1<D.x0-2||f.x0>D.x0+D.w+2||f.y1<D.y0-2||f.y0>D.y0+D.h+6))return false;
    if(!(f.x1<L.x-L.rx-6||f.x0>L.x+L.rx+6||f.y1<L.y-L.ry-6||f.y0>L.y+L.ry+6))return false;
    if(Math.hypot(x-I.x,y-I.y)<28)return false;
    if(O){ox0=O.x-(O.boxW||16)/2;oy0=WH-GEO.WALL-(O.boxH||15);if(!(f.x1<ox0-2||f.x0>ox0+(O.boxW||16)+2||f.y1<oy0-2||f.y0>WH-GEO.WALL+2))return false;}
    hit=projectCanal(x,y);if(hit&&hit.d<canalWidth(2)/2+10)return false;
    if(id==="streetMouth"&&Math.hypot(x-h.x,y-h.y)<40)return false;
    return true;};
  P.moveWashItem=function(id,x,y){
    if(id!=="washPile"&&id!=="streetMouth")return "bad";
    x=+x;y=+y;if(!isFinite(x)||!isFinite(y))return "bad";
    if(!this.fitsWash(id,x,y))return "blocked";
    if(!this.s.placeWash)this.s.placeWash={};
    this.s.placeWash[id]={x:x,y:y};this.syncWashGeom();this.poke();return "ok";};
  P.heapCount=function(){return washHeapCount(this.s.wash);};
  P.washUnwashed=function(){var w=this.s.wash||washFresh(),n=0,i,p,up=this.up("channel");
    for(i=0;i<(w.pots||[]).length;i++){p=w.pots[i];if(p&&!p.washed&&!p.onStreet&&!inStreet(p.x,p.y,up))n++;}
    return n+Math.max(0,(w.bulk|0)-(w.bulkW|0));};
  P.commandNow=function(id){
    var g=this.s.g,s=this.s;
    if(id==="work"){g.force=null;if(g.where==="wash"){this.leaveWashRoom();return "ok";}this.decide();this.poke();return "ok";}
    if(id==="eat"){if(s.food<=0)return "nofood";g.force="eat";g.lazy=false;if(g.where==="wash"){this.leaveWashRoom();return "ok";}this.walkTo(SPOT.food.x,SPOT.food.y,SPOT.food.dir,"eat","to the cooler");this.poke();return "ok";}
    if(id==="nap"){g.force="nap";g.lazy=false;if(g.where==="wash"){this.leaveWashRoom();return "ok";}this.walkTo(SPOT.mat.x,SPOT.mat.y,SPOT.mat.dir,"nap","to the bed");this.poke();return "ok";}
    if(id==="clean"){if(s.peels<=0)return "none";g.force="clean";if(g.where==="wash"){this.leaveWashRoom();return "ok";}var sw=this.sweepSpot();if(!sw.n)return "none";this.walkTo(sw.x,sw.y,sw.dir,"sweep","to sweep");this.poke();return "ok";}
    if(id==="wash"){
      if(!this.hasKey())return "nokey";
      g.force="washPool";g.lazy=false;
      if(g.hold==="peeled"&&this.heldN()>0){
        if(g.where==="wash"){this.dumpHandsOnStreet();this.poke();return "ok";}
        this.walkTo(SPOT.ship.x,SPOT.ship.y,SPOT.ship.dir,"drop","to the scanner");this.poke();return "ok";}
      if(this.washUnwashed()>0){if(g.where!=="wash"){this.goToWashRoom();this.poke();return "ok";}this.startScoop();this.poke();return "ok";}
      this.poke();return "ok";}
    return "bad";};
  P.goToWashRoom=function(){var g=this.s.g,d=WASH.kitDoorSpot;
    if(g.where==="wash"){if(g.hold==="peeled"&&this.heldN()>0){this.dumpHandsOnStreet();return;}this.startScoop();return;}
    this.walkTo(d.x,d.y,0,"enterWash","to the door");};
  P.enterWashRoom=function(){var g=this.s.g,s=this.s,d=WASH.doorSpot;
    g.where="wash";g.wx=d.x;g.wy=d.y;g.dir=2;g.act=null;s.followRoom="wash";this.emit({k:"room",room:"wash"});
    if(g.hold==="peeled"&&this.heldN()>0){this.dumpHandsOnStreet();return;}
    if(g.force==="washPool"||this.wantsAutoWash())this.startScoop();else this.decideWash();};
  P.leaveWashRoom=function(){var g=this.s.g,s=this.s,d=WASH.kitDoorSpot;
    g.where="kitchen";g.x=d.x/RW;g.y=d.y/RH;g.dir=2;g.act=null;s.followRoom="kitchen";this.emit({k:"room",room:"kitchen"});
    this.decide();};
  P.decideWash=function(){
    var s=this.s,g=s.g,n=this.needState();
    if(g.force==="eat"||g.force==="nap"||g.force==="clean"||n.wantEat||n.wantNap){this.wwalkTo(WASH.doorSpot.x,WASH.doorSpot.y,0,"leaveWash","to the door");return;}
    var want=g.force==="washPool"||g.holdRepeat==="wash"||this.wantsAutoWash();
    if(want&&g.hold==="peeled"&&this.heldN()>0){this.dumpHandsOnStreet();return;}
    if(want&&this.hasKey()&&this.washUnwashed()>0){this.startScoop();return;}
    if(want&&(g.holdRepeat==="wash"||this.wantsAutoWash())){g.act={t:"idle",d:0.5,e:0,label:"waiting on potatoes"};return;}
    if(g.force==="washPool")g.force=null;
    this.wwalkTo(WASH.doorSpot.x,WASH.doorSpot.y,0,"leaveWash","to the door");};
  P.wwalkTo=function(x,y,dir,then,label){var g=this.s.g;
    g.act={t:"wwalk",x:x,y:y,dir:dir,then:then,label:label};};
  P.startScoop=function(){
    var g=this.s.g,n=this.washUnwashed();
    if(n<=0){if(g.holdRepeat==="wash"||this.wantsAutoWash()){g.act={t:"idle",d:0.5,e:0,label:"waiting on potatoes"};return;}if(!g.holdRepeat)g.force=null;this.decideWash();return;}
    var t=this.nearestUnwashed();
    if(!t){this.releaseBulk(Math.min(6,n));t=this.nearestUnwashed();}
    if(!t){g.act={t:"idle",d:0.6,e:0,label:"waiting on potatoes"};return;}
    this.wwalkTo(t.x,t.y,0,"scoop","to the peeled pile");};
  P.startDumpPool=function(){   /* 0.4.3 name kept; dumps into the landing pool */
    var g=this.s.g,m=mouthOf();
    if(!(g.whold>0)){this.startScoop();return;}
    this.wwalkTo(m.x-18,m.y-2,1,"dumpPool","to the landing pool");};
  P.startDumpStreet=P.startDumpPool;
  P.doScoop=function(){
    var g=this.s.g,take=Math.min(4,this.washUnwashed()),got=0,w=this.s.wash,i,p,up=this.up("channel");
    if(take<=0){if(!g.holdRepeat)g.force=null;this.decideWash();return;}
    for(i=w.pots.length-1;i>=0&&got<take;i--){p=w.pots[i];if(!p||p.washed||p.onStreet||inStreet(p.x,p.y,up))continue;w.pots.splice(i,1);got++;}
    while(got<take&&(w.bulk-w.bulkW)>0){w.bulk--;if(w.bulkS>w.bulkSW)w.bulkS--;got++;}
    g.whold=got;g.act={t:"wdump",e:0,n:got,label:got>1?"carrying them to the landing pool":"carrying one to the landing pool"};
    if(got<=0){if(!g.holdRepeat)g.force=null;this.decideWash();return;}
    this.startDumpPool();};
  P.doDumpPool=function(){
    var g=this.s.g,L=WASH.land,n=g.whold|0,i,off;
    for(i=0;i<n;i++){off=(this.rand()-0.5)*10;
      this.spawnWash({x:L.x+off,y:L.y+(this.rand()-0.5)*8,vx:10+this.rand()*10,vy:(this.rand()-0.5)*8,washed:true,sloppy:!!g.sloppy,age:0,onStreet:false});}
    g.whold=0;if(n>0)this.heapLandSplash();this.emit({k:"dumpStreet",n:n});
    if(this.washUnwashed()>0&&(g.force==="washPool"||g.holdRepeat==="wash"||this.wantsAutoWash()))this.startScoop();
    else{if(!g.holdRepeat&&!this.wantsAutoWash())g.force=null;this.decideWash();}};
  P.dumpHandsOnStreet=function(){
    var g=this.s.g,n=this.heldN(),L=WASH.land,i,off;
    if(n<=0){this.decideWash();return;}
    for(i=0;i<n;i++){off=(this.rand()-0.5)*10;
      this.spawnWash({x:L.x+off,y:L.y+(this.rand()-0.5)*8,vx:10+this.rand()*10,vy:(this.rand()-0.5)*8,washed:true,sloppy:!!g.sloppy,age:0,onStreet:false});}
    g.hold=null;g.held=0;g.job="pile";g.peel=0;g.washed=false;g.sloppy=false;
    if(n>0)this.heapLandSplash();this.emit({k:"dumpStreet",n:n,from:"hands"});
    if(this.washUnwashed()>0&&(g.force==="washPool"||g.holdRepeat==="wash"||this.wantsAutoWash()))this.startScoop();
    else this.decideWash();};
  P.nearestUnwashed=function(){var w=this.s.wash,g=this.s.g,best=null,bd=1e9,i,p,d,up=this.up("channel");
    for(i=0;i<(w.pots||[]).length;i++){p=w.pots[i];if(!p||p.washed||p.onStreet||inStreet(p.x,p.y,up))continue;d=Math.hypot((p.x-g.wx),(p.y-g.wy));if(d<bd){bd=d;best=p;}}
    return best;};
  P.washGuyStep=function(dt,wsp){
    var s=this.s,g=s.g,a=g.act,mv,dx,dy,d;
    if(!a){this.decideWash();return;}
    if(a.t==="wwalk"){
      dx=a.x-g.wx;dy=a.y-g.wy;d=Math.sqrt(dx*dx+dy*dy);mv=C.walk*wsp*this.walkMul()*this.washWalk()*dt;
      g.walkPh+=mv*0.35;
      if(Math.abs(dx)>Math.abs(dy)*0.8)g.dir=dx>0?1:3;else g.dir=dy>0?2:0;
      if(d<=mv||d<0.01){g.wx=a.x;g.wy=a.y;g.dir=a.dir;this.startAt(a.then);}
      else{g.wx+=dx/d*mv;g.wy+=dy/d*mv;}
      return;}
    if(a.t==="scoop"){this.doScoop();return;}
    if(a.t==="dumpPool"){this.doDumpPool();return;}
    if(a.t==="wdump"){a.e=(a.e||0)+dt;if(a.e>=0.15)this.doDumpPool();return;}
    if(a.t==="idle"){a.e+=dt;if(a.e>=a.d)this.decideWash();return;}
    this.decideWash();};
  P.heapLandSplash=function(){
    var w=this.s.wash,H=heapCenter();
    if(!w)return;
    if(!w.heapSplash)w.heapSplash=[];
    w.heapSplash.push({x:H.x,y:H.y,t:this.s.t});
    if(w.heapSplash.length>8)w.heapSplash.shift();
    this.emit({k:"heapLand",x:H.x,y:H.y});
  };
  P.intakeWash=function(opt){
    opt=opt||{};ensureWash(this.s);
    var w=this.s.wash,L=WASH.land,O=WASH.outlet,mouthY=WH-GEO.WALL-(O&&O.boxH||15);
    if((w.pots.length>=WASH_LIVE)){
      w.bulk++;if(opt.washed)w.bulkW++;if(opt.sloppy)w.bulkS++;if(opt.washed&&opt.sloppy)w.bulkSW++;
      return;}
    this.spawnWash({x:L.x+(this.rand()-0.5)*10,y:Math.min(L.y+L.ry-5,mouthY-8)+(this.rand()-0.5)*3,vx:(this.rand()-0.5)*8,vy:-10-this.rand()*8,washed:opt.washed!==false,sloppy:!!opt.sloppy,age:0,auto:!!opt.auto,onStreet:false,fromHole:!!opt.fromHole});
    this.heapLandSplash();};
  P.spawnWash=function(p){
    var w=this.s.wash;if(!w.pots)w.pots=[];
    p.r=WASH_R;p.age=p.age||0;p.vx=p.vx||0;p.vy=p.vy||0;
    if(w.pots.length>=WASH_LIVE){w.bulk++;if(p.washed)w.bulkW++;if(p.sloppy)w.bulkS++;if(p.washed&&p.sloppy)w.bulkSW++;return;}
    w.pots.push(p);};
  P.releaseBulk=function(n){
    var w=this.s.wash,H=heapCenter(),L=WASH.land,i,washed,sloppy,ang,r;
    n=Math.max(0,n|0);if(!n||w.bulk<=0)return;
    for(i=0;i<n&&w.bulk>0&&w.pots.length<WASH_LIVE;i++){
      w.bulk--;washed=true;sloppy=false; /* basin potatoes count as washed */
      if(w.bulkW>0){w.bulkW--;if(w.bulkSW>0){w.bulkSW--;sloppy=true;}}
      else if(w.bulkS>0){w.bulkS--;sloppy=true;}
      /* 0.4.8: bulk lives in the basin heap, not the hidden dry west pile */
      ang=this.rand()*6.283;r=this.rand()*Math.min(L.rx,L.ry)*0.45;
      this.spawnWash({x:H.x+Math.cos(ang)*r,y:H.y+Math.sin(ang)*r*0.7,vx:(this.rand()-0.5)*4,vy:(this.rand()-0.5)*4,washed:true,sloppy:sloppy,age:0.8,onStreet:false});}};
  P.shipWashOne=function(p){
    var s=this.s,v;
    if(s.chute>=this.chuteCap()&&!s.suck)this.startSuck();
    if(s.chute>=this.chuteCap())return false;   /* hold it until the pipe takes a batch */
    v=(p&&p.washed&&p.sloppy&&this.basinOn("bubbles"))?C.washValue:shipPay(p);v+=this.neonTip();
    s.chute++;s.coins+=v;s.stats.earned+=v;
    if(p.washed)s.stats.washedShip=(s.stats.washedShip|0)+1;else s.stats.unwashedShip=(s.stats.unwashedShip|0)+1;
    if(s.chute>=this.chuteCap())this.startSuck();
    this.emit({k:"coin",v:v,sloppy:!!p.sloppy,washed:!!p.washed,from:"wash"});
    return true;};
  P.washStep=function(dt){
    var s=this.s;ensureWash(s);this.syncWashGeom();
    var w=s.wash,i,p,H=heapCenter(),hole=WASH.hole,lo=GEO.WALL+4,hx=WW-GEO.WALL-4,hy=WH-GEO.WALL-4;
    var j,q,dx,dy,d,nx,ny,sp,push,gx,gy,up=this.up("channel"),wid=streetWidth(up),reach=currentReach(up),flow=streetFlow(up)*this.flowMul(),hit,on,keep,best,bd,east,score;
    if(w.bulk>0&&w.pots.length<WASH_LIVE-4)this.releaseBulk(Math.min(4,WASH_LIVE-4-w.pots.length));
    if(s.g.where==="wash"){gx=s.g.wx;gy=s.g.wy;}
    /* current peels potatoes off the basin heap into the canal; faster at higher channel levels */
    w.pullAcc=(w.pullAcc||0)+heapPullRate(up)*this.pullMul()*dt;
    while(w.pullAcc>=1){
      w.pullAcc-=1;
      best=null;bd=-1e9;
      for(i=0;i<w.pots.length;i++){
        p=w.pots[i];if(!inHeap(p))continue;
        score=(p.x-WASH.land.x)+this.rand()*2;
        if(score>bd){bd=score;best=p;}
      }
      if(best){
        east=WASH.land.x+WASH.land.rx-3;
        best.onStreet=true;best.washed=true;
        if(best.x<east-4)best.x=Math.min(east,best.x+8);
        best.vx+=(12+flow*0.15);best.vy*=0.5;
      }else if(w.bulk>0){
        this.releaseBulk(1);
        p=w.pots[w.pots.length-1];
        if(p&&!p.onStreet){p.onStreet=true;p.washed=true;p.x=WASH.land.x+WASH.land.rx-3;p.y=WASH.land.y+(this.rand()-0.5)*4;p.vx=12+flow*0.15;p.vy=(this.rand()-0.5)*4;}
        else{w.pullAcc+=1;break;}
      }else{w.pullAcc+=1;break;}
    }
    for(i=w.pots.length-1;i>=0;i--){
      p=w.pots[i];if(!p){w.pots.splice(i,1);continue;}
      p.age=(p.age||0)+dt;
      if(inLanding(p.x,p.y)&&!p.onStreet)p.washed=true;
      on=!!p.onStreet||inCanalProper(p.x,p.y,up);
      if(on)p.onStreet=true;
      if(!on&&inLanding(p.x,p.y)){
        /* settle into a heap under the outlet, in the water */
        dx=H.x-p.x;dy=H.y-p.y;d=Math.hypot(dx,dy)||1;
        if(d>3){p.vx+=dx/d*22*dt;p.vy+=dy/d*22*dt;}
      }else if(!on){
        var mouthY=WH-GEO.WALL-(WASH.outlet&&WASH.outlet.boxH||15);
        if(Math.abs(p.x-WASH.land.x)<WASH.land.rx+4&&p.y>=WASH.land.y-2&&p.y<=mouthY+4){
          /* still in the pour under the machine: pull into the basin heap, do not fall onto the dry floor */
          dx=H.x-p.x;dy=H.y-p.y;d=Math.hypot(dx,dy)||1;
          p.vx+=dx/d*28*dt;p.vy+=dy/d*28*dt;p.washed=true;
        }else{
          /* leftover on the dry floor: the hidden west pile no longer attracts them; a nearby current can still catch them */
          if(p.age<0.55)p.vy+=40*dt;
          if(reach>0){hit=projectCanal(p.x,p.y);if(hit.d<wid/2+reach&&hit.d>0.2){p.vx+=(hit.px-p.x)/hit.d*16*dt;p.vy+=(hit.py-p.y)/hit.d*16*dt;}}
        }
      }
      if(on){
        if(!p.washed){p.washed=true;w.splash.push({x:p.x,y:p.y,t:s.t});if(w.splash.length>12)w.splash.shift();this.emit({k:"streetWash",x:p.x,y:p.y});}
        p.onStreet=true;
        hit=projectCanal(p.x,p.y);
        var look=pointAlongCanal(Math.min(1,hit.progress+Math.max(0.03,10/(hit.total||1)))),ddx=look.x-p.x,ddy=look.y-p.y,dd=Math.hypot(ddx,ddy)||1;
        p.vx+=ddx/dd*flow*dt;p.vy+=ddy/dd*flow*dt;
        keep=inLanding(p.x,p.y)?Math.max(wid/2,WASH.land.rx-3):wid/2-1;
        if(hit.d>keep){var side=hit.d||1,sx=(hit.px-p.x)/side,sy=(hit.py-p.y)/side;p.vx+=sx*40*dt;p.vy+=sy*40*dt;}
      }
      if(s.g.where==="wash"){dx=p.x-gx;dy=p.y-gy;d=Math.hypot(dx,dy);if(d<11&&d>0.2){push=(11-d)*18;p.vx+=dx/d*push*dt*8;p.vy+=dy/d*push*dt*8;}}
      p.vx*=Math.pow(0.55,dt);p.vy*=Math.pow(0.55,dt);
      sp=Math.hypot(p.vx,p.vy);if(sp>160){p.vx*=160/sp;p.vy*=160/sp;}
      p.x+=p.vx*dt;p.y+=p.vy*dt;
      if(p.x<lo){p.x=lo;p.vx=Math.abs(p.vx)*0.4;}if(p.x>hx){p.x=hx;p.vx=-Math.abs(p.vx)*0.4;}
      if(p.y<lo){p.y=lo;p.vy=Math.abs(p.vy)*0.4;}if(p.y>hy){p.y=hy;p.vy=-Math.abs(p.vy)*0.4;}
      if(!p.onStreet&&inLanding(p.x,p.y))clampToBasin(p);
      /* the hole ships washed potatoes that arrived on the water; unwashed never leave through it */
      if(p.washed&&Math.hypot(p.x-hole.x,p.y-hole.y)<hole.r+3){
        if(this.shipWashOne(p)){w.pots.splice(i,1);continue;}
        else{p.vx*=0.2;p.vy*=0.2;p.x=hole.x-hole.r-6;}
      }
    }
    for(i=0;i<w.pots.length;i++){
      p=w.pots[i];
      for(j=i+1;j<w.pots.length;j++){
        q=w.pots[j];dx=q.x-p.x;dy=q.y-p.y;d=Math.hypot(dx,dy);if(d<0.01)d=0.01;
        if(d<WASH_R*2-0.2){nx=dx/d;ny=dy/d;var ov=(WASH_R*2-d)*0.5;p.x-=nx*ov;p.y-=ny*ov;q.x+=nx*ov;q.y+=ny*ov;}
      }
      if(!p.onStreet&&inLanding(p.x,p.y))clampToBasin(p);
    }
  };
  P.setView=function(room){
    if(room!=="kitchen"&&room!=="wash")return false;
    if(room==="wash"&&!this.hasKey())return false;
    if(this.s.viewRoom===room)return true;
    this.s.followRoom=room;this.s.viewRoom=room;this.emit({k:"view",room:room});return true;};
  P.doorHit=function(x,y,room){
    var D=(room==="wash")?WASH.door:WASH.kitDoor;
    return x>=D.x0-2&&x<=D.x0+D.w+2&&y>=D.y0-2&&y<=D.y0+D.h+4;};

  P.visibleCommands=function(){
    var out=[],i,c;
    for(i=0;i<COMMANDS.length;i++){
      c=COMMANDS[i];
      if(c.id==="pot"&&!POT_SLIDER)continue; /* 0.4.9: hide POTATOES IN PLAY; command stays in COMMANDS */
      if(c.need&&!this.owned(c.need))continue;
      out.push(c);
    }
    return out;
  };

  P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];o.v=13;return JSON.stringify(o);};

  function synthMess(n,seed){
    var out=[],i,k,sp,ang,r,x,y;
    if(!n)return out;
    k=tableKids();sp=k.peelSpawn;
    for(i=0;i<n&&i<C.peelMax;i++){
      ang=hash(seed||1,i*17+5)*6.283;r=4+hash(seed||1,i*11+3)*16;
      x=sp.x+Math.cos(ang)*r*0.85;y=sp.y+2+Math.abs(Math.sin(ang))*r;
      x=Math.max(GEO.WALL+4,Math.min(RW-GEO.WALL-4,x));
      y=Math.max(GEO.table.y1+3,Math.min(GEO.pile.base-GEO.pile.rz-8,y));
      out.push({x:x,y:y,src:"table"});
    }
    return out;
  }
  function ensure04(o){
    o.v=4;
    if(typeof o.level!=="number"||o.level<1)o.level=1;
    if(o.level>5)o.level=5;
    if(!o.owned||typeof o.owned!=="object")o.owned={};
    if(!o.place||typeof o.place!=="object")o.place={};
    if(!o.line||typeof o.line!=="object")o.line=lineFresh();
    if(!o.line.beltIn)o.line.beltIn=[];if(!o.line.beltOut)o.line.beltOut=[];
    if(!o.decor||typeof o.decor!=="object")o.decor=decorFresh();
    if(typeof o.g.washed!=="boolean")o.g.washed=false;
    var id;
    for(id in BOX)if(typeof o.box[id]!=="number")o.box[id]=BOX[id].def;
    /* 0.4.1 inventory: missing equipped means this is a pre-inventory v4 (or v1-v3) save.
       Migrate owned items as already placed / tools already equipped. */
    if(!o.equipped||typeof o.equipped!=="object"){
      o.equipped={};
      for(id in o.owned){
        if(!o.owned[id])continue;
        if(isTool(id))o.equipped[id]=1;
        if(isPlaceable(id)&&!o.place[id])o.place[id]=defaultPlace(id);
      }
    }
    if(!Array.isArray(o.mess))o.mess=synthMess(Math.max(0,o.peels|0),o.seed||1);
    o.peels=o.mess.length;
  }
  function ensure05(o){
    ensure04(o);o.v=5;ensureWash(o);
    if(typeof o.stats.washedShip!=="number")o.stats.washedShip=0;
    if(typeof o.stats.unwashedShip!=="number")o.stats.unwashedShip=0;
    if(o.g.force!=null&&o.g.force!=="eat"&&o.g.force!=="nap"&&o.g.force!=="clean"&&o.g.force!=="washPool")o.g.force=null;
    if(typeof o.g.whold!=="number")o.g.whold=0;
  }
  function ensure06(o){
    ensure05(o);o.v=6;
    if(!o.placeWash||typeof o.placeWash!=="object")o.placeWash={};
    if(typeof o.box.awash!=="number")o.box.awash=0;
    if(!o.up||typeof o.up!=="object")o.up=upsFresh();
    if(typeof o.up.channel!=="number")o.up.channel=0;
    if(o.g){if(typeof o.g.holdRepeat!=="string")o.g.holdRepeat=null;
      /* v5 potatoes mid-path to the old wash-room ship exit stay on the pile; they do not auto-ship unwashed */
      var w=o.wash,ii,pp;
      if(w&&w.pots){for(ii=0;ii<w.pots.length;ii++){pp=w.pots[ii];if(!pp)continue;if(pp.shipping&&!pp.washed&&!pp.onStreet){pp.shipping=false;pp.vx=0;pp.vy=0;}}}
    }
  }
  function ensure07(o){
    ensure06(o);o.v=7;
    var w=o.wash,ii,pp,L=WASH.land;
    if(w&&w.pots){
      for(ii=0;ii<w.pots.length;ii++){
        pp=w.pots[ii];if(!pp)continue;
        /* v6 potatoes mid-diagonal or at the old mid-east hole land in the new pool; they do not auto-ship out the new hole */
        if(pp.onStreet||pp.washed||Math.hypot((pp.x||0)-(180-7),(pp.y||0)-148)<22){
          pp.x=L.x+((ii%5)-2)*4;pp.y=L.y+((ii%3)-1)*3;pp.vx=0;pp.vy=0;pp.onStreet=true;pp.shipping=false;pp.washed=true;
        }else{pp.shipping=false;pp.vx=pp.vx||0;pp.vy=pp.vy||0;}
      }
    }
  }
  function ensure08(o){ensure07(o);o.v=8;}
  function ensure09(o){ensure08(o);o.v=9;}
  function ensure10(o){
    ensure09(o);o.v=10;
    var w=o.wash,ii,pp,L=WASH.land,P=WASH.pile,H=heapCenter(),hit,onDry,inLand,onCanal;
    if(w&&typeof w.pullAcc!=="number")w.pullAcc=0;
    if(w&&w.pots){
      for(ii=0;ii<w.pots.length;ii++){
        pp=w.pots[ii];if(!pp)continue;
        onDry=Math.hypot((pp.x||0)-P.cx,(pp.y||0)-P.cy)<=Math.max(P.rx,P.rz)*0.85;
        inLand=inLanding(pp.x,pp.y);
        hit=projectCanal(pp.x,pp.y);
        onCanal=!!(hit&&hit.d<=canalWidth(2)/2+2&&!inLand&&((pp.x||0)>L.x+L.rx-2||(pp.y||0)<L.y-L.ry-4));
        if(onDry){
          /* old dry-pile leftovers move into the basin heap and count as washed */
          pp.x=H.x+((ii%7)-3)*3.2;pp.y=H.y+((ii%5)-2)*2.4;
          pp.vx=0;pp.vy=0;pp.onStreet=false;pp.shipping=false;pp.washed=true;
        }else if(inLand){
          pp.onStreet=false;pp.shipping=false;pp.washed=true;pp.vx=0;pp.vy=0;
        }else if(onCanal&&(pp.onStreet||pp.washed)){pp.washed=true;pp.onStreet=true;}
      }
    }
  }
  function ensure11(o){
    ensure10(o);o.v=11;
    if(!o.box||typeof o.box!=="object")o.box={};
    o.box.pot=POT_MAX;o.potCap=POT_MAX;
    var w=o.wash;if(w&&!Array.isArray(w.heapSplash))w.heapSplash=[];
  }
  function ensure12(o){
    ensure11(o);o.v=12;
    o.decor=fixDecor(o.decor);
    o.duckIn=o.duckIn&&o.owned&&o.owned.duck?1:0;
  }
  function ensure13(o){
    ensure12(o);o.v=13;
    var h=+o.hyg;o.hyg=isFinite(h)?Math.max(0,Math.min(100,h)):100;
    if(!o.basin||typeof o.basin!=="object")o.basin={};var b2={};for(var i=0;i<BASIN.length;i++)if(BASIN[i]!=="duck"&&o.basin[BASIN[i]]&&o.owned&&o.owned[BASIN[i]])b2[BASIN[i]]=1;o.basin=b2;
    if(!o.theme||typeof o.theme!=="object")o.theme={wall:0,floor:0};
    o.theme={wall:((Math.floor(+o.theme.wall)||0)%4+4)%4,floor:((Math.floor(+o.theme.floor)||0)%4+4)%4};
    if(o.box&&typeof o.box.rinse!=="number")o.box.rinse=BOX.rinse.def;
    if(o.placeWash&&typeof o.placeWash==="object"){for(var k in o.placeWash){var q=o.placeWash[k];if(!q||typeof q!=="object"||!isFinite(+q.x)||!isFinite(+q.y))delete o.placeWash[k];}}
  }
  /* accepts a 0.4.11 save (v:13), a 0.4.10 save (v:12), a 0.4.9 save (v:11), a 0.4.8 save (v:10), a 0.4.7 save (v:9), a 0.4.6 save (v:8), a 0.4.5 save (v:7), a 0.4.4 save (v:6), a 0.4.3 save (v:5), a 0.4 save (v:4), a 0.3 save (v:3), a 0.2 save (v:2) or a 0.1 save (v:1). Older saves are migrated in memory; the old keys are never written. */
  Sim.load=function(str){try{var o=JSON.parse(str);if(!o||(o.v!==1&&o.v!==2&&o.v!==3&&o.v!==4&&o.v!==5&&o.v!==6&&o.v!==7&&o.v!==8&&o.v!==9&&o.v!==10&&o.v!==11&&o.v!==12&&o.v!==13)||typeof o.coins!=="number"||!o.g||typeof o.g!=="object"||!o.box||typeof o.box!=="object")return null;
      var old=o.v<3,from1=o.v===1,from3=o.v===3;ensure13(o);
      var f=fresh(o.seed);for(var k in f)if(!(k in o))o[k]=f[k];
      if(!o.stats||typeof o.stats!=="object")o.stats={};for(var k2 in f.stats)if(typeof o.stats[k2]!=="number"||!isFinite(o.stats[k2]))o.stats[k2]=f.stats[k2];
      var oldPot=+o.box.pot;
      for(var id in BOX){var v=+o.box[id];if(!(v>=BOX[id].min&&v<=BOX[id].max))o.box[id]=BOX[id].def;else o.box[id]=Math.round((v-BOX[id].min)/BOX[id].step)*BOX[id].step+BOX[id].min;}
      if(old){o.potCap=Math.max(C.potLegacy,o.box.pot);o.up=upsFresh();}
      if(!o.up||typeof o.up!=="object")o.up=upsFresh();for(var ui2=0;ui2<UPS.length;ui2++){var uu=Math.floor(+o.up[UPS[ui2].id]);o.up[UPS[ui2].id]=(uu>=0&&uu<=UPS[ui2].max)?uu:0;}
      o.potCap=Math.floor(+o.potCap);if(!(o.potCap>=0&&o.potCap<=POT_MAX))o.potCap=C.potBase;if(o.box.pot>o.potCap)o.potCap=o.box.pot;
      o.hunger=Math.max(0,Math.min(100,+o.hunger||0));o.energy=Math.max(0,Math.min(100,+o.energy||0));
      o.coins=Math.max(0,Math.min(1e9,Math.floor(+o.coins||0)));
      var fmx=C.foodMax+3*o.up.pantry,cmx=C.chuteCap+2*o.up.chute;
      o.food=Math.max(0,Math.min(fmx,Math.floor(+o.food||0)));o.ev=[];
      o.t=Math.max(0,+o.t||0);if(!isFinite(o.t))o.t=0;
      o.peels=Math.max(0,Math.min(C.peelMax,Math.floor(+o.peels||0)));
      o.chute=Math.max(0,Math.min(cmx,Math.floor(+o.chute||0)));
      o.pile=Math.max(0,Math.floor(+o.pile||0));
      var kk=o.suck;if(kk&&typeof kk==="object"&&isFinite(+kk.t0)&&+kk.n>0&&+kk.n<=cmx&&+kk.landed>=0&&+kk.landed<=+kk.n){o.suck={t0:+kk.t0,n:Math.floor(+kk.n),landed:Math.floor(+kk.landed)};if(o.suck.t0>o.t)o.suck.t0=o.t;}else o.suck=null;
      var g=o.g;if(g.act&&typeof g.act!=="object")g.act=null;
      if(old)g.act=null;      /* geometry changed in 0.3: let him re-decide from where he stands */
      var ok={walk:1,wwalk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1,wash:1,watch:1,water:1,tune:1,scoop:1,dumpPool:1,wdump:1,rinse:1};if(g.act&&!ok[g.act.t])g.act=null;
      if(g.act&&g.act.t==="walk"&&!(isFinite(+g.act.x)&&isFinite(+g.act.y)))g.act=null;
      if(typeof g.x!=="number"||!(g.x>=0&&g.x<=1))g.x=0.5;if(typeof g.y!=="number"||!(g.y>=0&&g.y<=1))g.y=0.2;if(typeof g.dir!=="number"||!(g.dir>=0&&g.dir<=3))g.dir=2;
      if(old){g.x=Math.max(0.12,Math.min(0.88,g.x));g.y=Math.max(0.08,Math.min(0.92,g.y));}
      if(g.hold!==null&&g.hold!=="raw"&&g.hold!=="peeled")g.hold=null;
      if(!g.hold)g.held=0;else{var hn=Math.floor(+g.held||0);g.held=(hn>=1&&hn<=6)?hn:1;}
      var h=g.hold;g.job=h==="raw"?(g.job==="wash"||g.job==="peel"?g.job:"table"):(h==="peeled"?"chute":"pile");
      if(g.act){var at=g.act,wt=at.t==="walk"?at.then:null;
        var walkOk=["grab","peel","drop","eat","nap","sweep","wash","watch","water","tune","enterWash","leaveWash","scoop","dumpPool"];
        if((at.t==="peel"&&h!=="raw")||(at.t==="drop"&&h!=="peeled")||(at.t==="wash"&&h!=="raw")||(at.t==="grab"&&h!==null)||(at.t==="sweep"&&h!==null)||((at.t==="watch"||at.t==="water"||at.t==="tune")&&h!==null)||
           (at.t==="walk"&&(walkOk.indexOf(wt)<0||(wt==="peel"&&h!=="raw")||(wt==="drop"&&h!=="peeled")||(wt==="wash"&&h!=="raw")||(wt==="grab"&&h!==null)||(wt==="sweep"&&h!==null)||((wt==="watch"||wt==="water"||wt==="tune")&&h!==null))))g.act=null;}
      if(g.peel!==0&&!(g.peel>0&&g.peel<=1))g.peel=0;
      g.pgot=Math.max(0,Math.min(5,Math.floor(+g.pgot||0)));
      if(g.act&&g.act.t==="walk"){var rr=routeSafe(g.x*RW,g.y*RH,g.act.x*RW,g.act.y*RH),wp=[];for(var ri=0;ri<rr.length-1;ri++)wp.push([rr[ri][0]/RW,rr[ri][1]/RH]);g.act.wp=wp;}
      var sim=new Sim(o);sim.rebuildObst();
      var want=POT_LOCK,have=sim.total();
      if(from1||have!==want){if(have>want){o.pile=Math.max(0,o.pile-(have-want));}else o.pile+=want-have;}
      return sim;}catch(e){return null;}};
  Sim.fresh=function(seed){return new Sim(fresh(seed));};
  Sim.C=C;Sim.POTS=POTS;Sim.BOX=BOX;Sim.PACE=PACE;Sim.SPOT=SPOT;Sim.SPD=SPD;Sim.DRN=DRN;Sim.GEO=GEO;Sim.OBST=OBST;Sim.RW=RW;Sim.RH=RH;Sim.WW=WW;Sim.WH=WH;Sim.WASH=WASH;Sim.WASH0=WASH0;Sim.shipPay=shipPay;Sim.inPool=inPool;Sim.inStreet=inStreet;Sim.inLanding=inLanding;Sim.streetWidth=streetWidth;Sim.canalWidth=canalWidth;Sim.streetSeg=streetSeg;Sim.canalPts=canalPts;Sim.projectCanal=projectCanal;Sim.pointAlongCanal=pointAlongCanal;Sim.currentReach=currentReach;Sim.streetFlow=streetFlow;Sim.heapPullRate=heapPullRate;Sim.heapCenter=heapCenter;Sim.inCanalProper=inCanalProper;Sim.inHeap=inHeap;Sim.washHeapCount=washHeapCount;Sim.HEAP_VIS=HEAP_VIS;Sim.HEAP_SPILL=HEAP_SPILL;Sim.POT_LOCK=POT_LOCK;Sim.POT_SLIDER=POT_SLIDER;Sim.RUGS=RUGS;Sim.WALLS=WALLS;Sim.TOPS=TOPS;Sim.WASHW=WASHW;Sim.WASHF=WASHF;Sim.BASIN=BASIN;Sim.FLOOR11=FLOOR11;Sim.THEMES=THEMES;Sim.isTop=isTop;Sim.isWashItem=isWashItem;Sim.isWashWall=isWashWall;Sim.isBasin=isBasin;Sim.isRug=isRug;Sim.isWall=isWall;Sim.FOOT=FOOT;
  Sim.COMMANDS=COMMANDS;Sim.UPS=UPS;Sim.STYLE=STYLE;Sim.ITEMS=ITEMS;Sim.ITEMI=ITEMI;Sim.LEVEL_PRICE=LEVEL_PRICE;Sim.SPEED_NAME=SPEED_NAME;Sim.FIXED=FIXED;Sim.TOOLS=TOOLS;Sim.PLACEABLES=PLACEABLES;Sim.STARTER=STARTER;Sim.isTool=isTool;Sim.isPlaceable=isPlaceable;Sim.tableKids=tableKids;Sim.bedside=bedside;Sim.spill=spill;Sim.route=route;Sim.INFL=function(){return INF;};Sim.defaultPlace=defaultPlace;Sim.rot=rot;Sim.routeSafe=routeSafe;Sim.gridRoute=gridRoute;Sim.freePt=freePt;
  return Sim;
})();
if(typeof module!=="undefined")module.exports=PPSim;
