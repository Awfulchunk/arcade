# Papa Potato 0.4.11 — TEST build (not shipped, not published, not signed)

- **File:** papa-potato-0.4.11.html
- **SHA256:** f9c4772ddfc627d61e73097f2428f9aa030e5d3ad5746950fbf83ef1fe1687e5
- **Built from:** /workspace/game/build-potato0411 (a copy of 0410; 0410 is untouched). Arcade repo and PR 2 were not touched.
- **Save:** papaPotato.save.v13, falling back to v12 → v11 → older chain.

## What's in it
- See DECOR-AUDIT.md for the full item table (24 new items), the mat fix, the table sink, mood, hygiene, and the discussed-but-missing list (built / skipped / why).

## Test pass on the final build (all headless Chrome; NO physical-phone test)
- **tough-tools** `test --all --name=papa0411 --seed=1`: 60 pass, 1 FAIL, 3 warn.
  - The FAIL is buff/rapid-taps: "Input.dispatchTouchEvent timed out" (harness protocol timeout).
  - Re-running just that check alone passed: 1220 rapid taps, ok (test-evidence/tt-rapid-rerun).
  - A per-control tap-timing probe matched 0.4.10 (36.3 s vs 36.4 s for all buttons ×30).
  - Likely harness contention, but it is not proven.
  - The 3 warns are the same as 0.4.10 (untappable controls in the scrolled panel, WV83 roundRect/flex-gap, edge softness 0.359).
- **t-0411.cjs:** 237 pass, 0 fail. This covers every 0.4.10 check plus the new decor, placement, tray, wash, sink, mood and save checks. 0 page errors.
- **A03s ×6 CPU, 360x800@2:**
  - Kitchen with all 40 placeables placed, themes and radio: 59.8 fps, p95 16.7 ms.
  - Wash room with decor, duck, boat, bubbles and radio: 59.3 fps.
  - Own song playing: 57.2 fps.
- **play-0411.cjs:** 7/7, 0 errors. It ran this scripted session with real CDP touch:
  - 20 shift minutes of work (4 rinses)
  - shop taps (21 items)
  - EDIT with drags from tabs and pages
  - radio
  - INV themes and basin
  - door to the wash room and wash decor drags
  - save, then reload
- A dry run before this (same suites) found real bugs, which were fixed before this final pass:
  - The HUD pushed EDIT off small and landscape screens.
  - Low mood slowed a fresh room below 0.4.10.
  - 3 of my own test thresholds were wrong.
