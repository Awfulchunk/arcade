/* ===== Papa Potato 0.4.11 — decor sprite pack (24 items + the cat). Same C-look: flat shading, 1px dark outline,
   top-down, wall items drawn for the NORTH wall band (the game turns them for east / west walls).
   (x, y) is the world-unit centre. Registers into PPSprites04. ===== */
(function(){
  var S=window.PPSprites04;if(!S)return;
  var P=S.primitives(),wr=P.wr,oval=P.oval,disc=P.disc,blob=P.blob,softShadow=P.softShadow,wx=P.wx,wy=P.wy,ws=P.ws,OUT=P.OUT;
  function C(){return S.getCtx();}
  function A(){return S.anim();}
  function shadow(x0,y0,w,h){wr(x0+0.5,y0+0.6,w,h,"rgba(0,0,0,0.26)");}
  function plate(x0,y0,w,h,fill,edge){wr(x0,y0,w,h,edge||"#2a1c10");wr(x0+0.45,y0+0.45,w-0.9,h-0.9,fill);}
  function poly(pts,c){var g=C();g.fillStyle=c;g.beginPath();for(var i=0;i<pts.length;i++){var X=wx(pts[i][0]),Y=wy(pts[i][1]);if(i)g.lineTo(X,Y);else g.moveTo(X,Y);}g.closePath();g.fill();}
  function line(x0,y0,x1,y1,c,w){var g=C();g.strokeStyle=c;g.lineWidth=Math.max(0.7,ws(w||0.3));g.beginPath();g.moveTo(wx(x0),wy(y0));g.lineTo(wx(x1),wy(y1));g.stroke();}
  function potatoFace(x,y,r){disc(wx(x),wy(y),ws(r),ws(r*0.8),"#c08a48",OUT);oval(wx(x-r*0.35),wy(y-r*0.25),ws(r*0.35),ws(r*0.25),"#e0b070");
    wr(x-r*0.42,y-r*0.1,r*0.22,r*0.22,"#1a1410");wr(x+r*0.2,y-r*0.1,r*0.22,r*0.22,"#1a1410");wr(x-r*0.25,y+r*0.32,r*0.5,r*0.15,"#5a3418");}

  /* ---------------- WALL (north band, 7 units deep) ---------------- */
  function drawWindow(cx,cy,st,o){o=o||{};var w=14,h=6.4,x0=cx-w/2,y0=cy-h/2,day=o.day!==false;
    shadow(x0,y0,w,h);plate(x0,y0,w,h,"#7a5430");
    wr(x0+1,y0+1,w-2,h-2,day?"#9fd4f0":"#1c2850");
    if(day){wr(x0+1,y0+h-2.6,w-2,1.6,"#bfe6c8");oval(wx(x0+w-3.4),wy(y0+2.2),ws(1.0),ws(1.0),"#fff3a0");}
    else{wr(x0+3,y0+2,0.5,0.5,"#ffffff");wr(x0+7.5,y0+1.6,0.5,0.5,"#e8f0ff");oval(wx(x0+w-3.4),wy(y0+2.3),ws(0.9),ws(0.9),"#f0f0d0");}
    wr(cx-0.3,y0+1,0.6,h-2,"#7a5430");wr(x0+1,cy-0.3,w-2,0.6,"#7a5430");
    /* gingham curtains */
    var i;for(i=0;i<2;i++){var cxp=i?x0+w-3.2:x0+0.2;wr(cxp,y0+0.3,3,h-0.6,"#c0361e");wr(cxp+0.5,y0+0.3,0.6,h-0.6,"#e86a50");wr(cxp+1.8,y0+0.3,0.6,h-0.6,"#e86a50");wr(cxp,y0+2,3,0.5,"#f0d0c0");wr(cxp,y0+4,3,0.5,"#f0d0c0");}
    wr(x0-0.4,y0-0.2,w+0.8,0.7,"#4a3018");}
  function drawSpiceRack(cx,cy){var w=10,h=6,x0=cx-w/2,y0=cy-h/2,i,cols=["#c0361e","#e0a020","#4a7a30","#7a3a8a","#d8d0b0"];
    shadow(x0,y0,w,h);plate(x0,y0,w,h,"#8a5a2c","#3a2410");wr(x0+0.5,y0+h-1.6,w-1,0.6,"#5a3818");
    for(i=0;i<5;i++){var jx=x0+1.3+i*1.8,jy=y0+2.9;disc(wx(jx),wy(jy),ws(0.75),ws(0.75),"#e8f0f0",OUT);oval(wx(jx),wy(jy),ws(0.55),ws(0.55),cols[i]);wr(jx-0.2,jy-0.3,0.3,0.3,"#ffffff");}}
  function drawCoatHook(cx,cy){var x0=cx-3.2,y0=cy-3.2;
    wr(x0+1,y0,4.4,1.1,"#4a3018");oval(wx(cx),wy(y0+0.6),ws(0.5),ws(0.5),"#c8c0a0");
    poly([[cx-1.8,y0+1.2],[cx+1.8,y0+1.2],[cx+2.6,y0+6.2],[cx-2.6,y0+6.2]],OUT);
    poly([[cx-1.5,y0+1.4],[cx+1.5,y0+1.4],[cx+2.2,y0+5.9],[cx-2.2,y0+5.9]],"#f0e8d4");
    wr(cx-1.6,y0+3.2,3.2,0.45,"#c0361e");wr(cx-0.9,y0+4.1,1.8,1.3,"#c0361e");wr(cx-0.6,y0+4.3,1.2,0.8,"#e86a50");
    line(cx-1.4,y0+1.4,cx,y0+0.6,"#c0361e",0.25);line(cx+1.4,y0+1.4,cx,y0+0.6,"#c0361e",0.25);}
  function drawCalendar(cx,cy,st,o){o=o||{};var w=6,h=6.2,x0=cx-w/2,y0=cy-h/2,i,j,d=((o.day|0)-1)%28;
    shadow(x0,y0,w,h);plate(x0,y0,w,h,"#f4efe0","#3a2a18");wr(x0+0.45,y0+0.45,w-0.9,1.4,"#c0361e");wr(cx-0.3,y0-0.3,0.6,0.8,"#6a6a6a");
    for(j=0;j<4;j++)for(i=0;i<5;i++){var n=j*5+i;wr(x0+0.8+i*0.95,y0+2.3+j*0.95,0.6,0.55,n===d%20?"#c0361e":"#9a9080");}}
  function drawPotsPans(cx,cy){var w=14,x0=cx-w/2,y0=cy-3.2;
    wr(x0,y0+0.3,w,0.7,"#6a6a68");wr(x0,y0+0.3,w,0.25,"#b0b0a8");
    function pan(x,r,c,c2){line(x,y0+0.8,x,y0+1.8,"#3a3a38",0.3);disc(wx(x),wy(y0+1.8+r),ws(r),ws(r),c,OUT);oval(wx(x),wy(y0+1.8+r),ws(r*0.7),ws(r*0.7),c2);oval(wx(x-r*0.35),wy(y0+1.5+r*0.7),ws(r*0.25),ws(r*0.18),"rgba(255,255,255,0.45)");}
    pan(x0+2.4,1.9,"#b86a30","#8a4a20");pan(x0+6.4,2.2,"#3a3a3a","#1e1e1e");pan(x0+10.8,1.7,"#c88a48","#a06a30");
    wr(x0+12.6,y0+0.9,1.1,3.6,"#c8c0a8");oval(wx(x0+13.15),wy(y0+0.9),ws(0.7),ws(0.4),"#c8c0a8");}
  function drawPhotos(cx,cy){var x0=cx-6,y0=cy-3,i,fr=["#c8a050","#7a5430","#3a3a3a"];
    for(i=0;i<3;i++){var fx=x0+0.4+i*4,fy=y0+(i===1?0.3:0.9),fw=3.4,fh=i===1?5.2:4.2;shadow(fx,fy,fw,fh);plate(fx,fy,fw,fh,"#e8dcc0",fr[i]);
      wr(fx+0.6,fy+0.6,fw-1.2,fh-1.2,i===0?"#a8d0e0":i===1?"#d8c0a0":"#c0d8a8");potatoFace(fx+fw/2,fy+fh/2+0.2,i===1?1.2:1.0);}}
  function drawStringLights(cx,cy,st,o){o=o||{};var w=24,x0=cx-w/2,y0=cy-2.4,i,a=A(),cols=["#ff5a4a","#ffd040","#6ae070","#6ab0ff","#ff8ad8"],n=9,night=!!o.night;
    var g=C();g.strokeStyle="#2a2a20";g.lineWidth=Math.max(0.7,ws(0.25));g.beginPath();
    for(i=0;i<=24;i++){var t=i/24,x=x0+t*w,y=y0+1.0+Math.sin(t*Math.PI*3)*0.9;if(i)g.lineTo(wx(x),wy(y));else g.moveTo(wx(x),wy(y));}g.stroke();
    for(i=0;i<n;i++){var tt=(i+0.5)/n,bx=x0+tt*w,by=y0+1.6+Math.sin(tt*Math.PI*3)*0.9,on=((i+a.f)%4)!==0||night;
      if(on&&night)oval(wx(bx),wy(by),ws(1.7),ws(1.7),"rgba(255,230,160,0.22)");
      disc(wx(bx),wy(by),ws(0.65),ws(0.8),on?cols[i%5]:"#5a5a50",OUT);if(on)oval(wx(bx-0.2),wy(by-0.25),ws(0.25),ws(0.25),"#ffffff");}}
  function drawNeonSign(cx,cy,st,o){var w=14,h=6,x0=cx-w/2,y0=cy-h/2,a=A(),flick=(Math.floor(a.t*3)%17)===0;
    shadow(x0,y0,w,h);plate(x0,y0,w,h,"#141018","#000000");
    var g=C();g.save();g.font="700 "+Math.max(5,Math.round(ws(3.6)))+"px Courier New,monospace";g.textAlign="center";g.textBaseline="middle";
    g.shadowColor="#ff3a9a";g.shadowBlur=flick?0:Math.max(2,ws(1.2));g.fillStyle=flick?"#7a2a50":"#ff6ab8";g.fillText("OPEN",wx(cx),wy(cy+0.2));g.restore();
    wr(x0+0.8,y0+0.8,w-1.6,0.35,flick?"#2a2040":"#6ad8ff");wr(x0+0.8,y0+h-1.15,w-1.6,0.35,flick?"#2a2040":"#6ad8ff");}
  function drawTrophyShelf(cx,cy,st,o){o=o||{};var w=16,x0=cx-w/2,y0=cy-3,n=Math.max(1,Math.min(8,o.n|0)),gold=Math.max(0,o.gold|0),i;
    shadow(x0,y0+4.4,w,1.4);wr(x0,y0+4.4,w,1.4,"#5a3818");wr(x0,y0+4.4,w,0.45,"#9a6a40");
    for(i=0;i<n;i++){var tx=x0+1.2+i*1.85,isG=i>=n-gold,c=isG?"#ffd040":(i%2?"#c8c8d0":"#d08a48"),c2=isG?"#fff3a0":"#f0f0f8";
      wr(tx-0.6,y0+3.6,1.2,0.8,"#3a2a18");wr(tx-0.25,y0+2.6,0.5,1.0,c);disc(wx(tx),wy(y0+1.9),ws(0.8),ws(0.75),c,OUT);oval(wx(tx-0.25),wy(y0+1.7),ws(0.25),ws(0.25),c2);}}

  /* ---------------- FLOOR ---------------- */
  function drawSideTable(cx,cy){var w=14,h=10,x0=cx-w/2,y0=cy-h/2;
    softShadow(wx(cx+0.5),wy(cy+1),ws(8),ws(6));blob(wx(x0),wy(y0),ws(w),ws(h),ws(1.6),"#8a5a2c","#2a1808");
    blob(wx(x0+0.9),wy(y0+0.9),ws(w-1.8),ws(h-1.8),ws(1.2),"#a87440","#6a4420");wr(x0+1.4,y0+1.2,w-2.8,0.5,"#c89060");
    oval(wx(cx),wy(cy+0.2),ws(5.2),ws(3.4),"rgba(250,245,230,0.85)");oval(wx(cx),wy(cy+0.2),ws(4.4),ws(2.7),"rgba(230,220,200,0.6)");}
  function drawCompost(cx,cy){var X=wx(cx),Y=wy(cy);softShadow(X,wy(cy+0.8),ws(5.4),ws(4.6));
    disc(X,Y,ws(4.5),ws(4.5),"#3a6a2a",OUT);oval(X,Y,ws(3.8),ws(3.8),"#4a8a36");oval(X,Y,ws(2.9),ws(2.9),"#3a6a2a");
    wr(cx-2.8,cy-0.45,5.6,0.9,"#2a4a1c");poly([[cx-1.2,cy+1.6],[cx,cy-0.6],[cx+1.2,cy+1.6]],"#c4e490");line(cx,cy+1.6,cx,cy+0.2,"#2a4a1c",0.22);
    oval(X-ws(1.4),Y-ws(1.8),ws(1.1),ws(0.6),"rgba(255,255,255,0.18)");}
  function drawSackPile(cx,cy){var i,pos=[[-3.8,1.2,4.2],[3.6,1.6,4.0],[0,-1.8,4.4]];softShadow(wx(cx),wy(cy+1.5),ws(9),ws(6));
    for(i=0;i<3;i++){var x=cx+pos[i][0],y=cy+pos[i][1],r=pos[i][2];disc(wx(x),wy(y),ws(r),ws(r*0.85),"#b08a54",OUT);oval(wx(x),wy(y),ws(r*0.82),ws(r*0.68),"#c8a46a");
      var k;for(k=-2;k<=2;k++)wr(x+k*1.4-0.15,y-r*0.6,0.3,r*1.2,"rgba(120,90,50,0.35)");
      disc(wx(x),wy(y),ws(1.1),ws(0.9),"#8a6a3a","#4a3418");wr(x-0.9,y-0.15,1.8,0.3,"#5a3a18");}
    disc(wx(cx+5.8),wy(cy-3.2),ws(1.3),ws(1.05),"#b07a3c","#5a3418");}
  function drawBookshelf(cx,cy){var w=20,h=8,x0=cx-w/2,y0=cy-h/2,i,cols=["#c0361e","#2c5a8a","#e0a020","#4a7a30","#7a3a8a","#d8d0b0","#8a5a2c","#3a8a8a"];
    shadow(x0,y0,w,h);plate(x0,y0,w,h,"#6a4220","#2a1808");wr(x0+0.5,y0+0.5,w-1,0.7,"#9a6a40");
    var x=x0+1.0;for(i=0;x<x0+w-1.6;i++){var bw=1.0+((i*7)%3)*0.35;wr(x,y0+1.5,bw-0.15,h-2.4,cols[i%cols.length]);wr(x,y0+1.5,bw-0.15,0.5,"rgba(255,255,255,0.25)");x+=bw;}
    wr(x0+0.5,y0+h-1.0,w-1,0.5,"#3a2410");}
  function drawCatBed(cx,cy,st,o){o=o||{};var X=wx(cx),Y=wy(cy);softShadow(X,wy(cy+0.8),ws(7),ws(5.6));
    disc(X,Y,ws(6),ws(5),"#7a4a8a",OUT);oval(X,Y,ws(4.6),ws(3.7),"#c890d0");oval(X,Y,ws(3.9),ws(3.0),"#e8d0ec");
    if(o.cat)drawCatSprite(cx,cy+0.2,"sleep",{dir:0});}
  function drawStatue(cx,cy){var x0=cx-5,y0=cy-5;softShadow(wx(cx),wy(cy+1),ws(6),ws(5.4));
    plate(x0,y0,10,10,"#a8a49a","#3a3830");wr(x0+0.8,y0+0.8,8.4,0.6,"#d0ccc0");wr(x0+0.8,y0+8.6,8.4,0.6,"#7a766c");
    disc(wx(cx),wy(cy+0.4),ws(3.4),ws(2.8),"#e0a020","#6a4a10");oval(wx(cx-1.0),wy(cy-0.5),ws(1.4),ws(0.9),"#fff3a0");
    wr(cx-1.6,cy-0.1,0.6,0.6,"#6a4a10");wr(cx+1.0,cy-0.1,0.6,0.6,"#6a4a10");
    poly([[cx-1.8,cy-2.0],[cx-1.2,cy-3.4],[cx-0.4,cy-2.4],[cx,cy-3.7],[cx+0.4,cy-2.4],[cx+1.2,cy-3.4],[cx+1.8,cy-2.0]],"#ffd040");
    var a=A();if(a.f===0)wr(cx+2.0,cy-2.6,0.5,0.5,"#ffffff");}

  /* ---------------- TABLE-TOP ---------------- */
  function drawFruitBowl(cx,cy){var X=wx(cx),Y=wy(cy);disc(X,wy(cy+0.4),ws(2.8),ws(2.3),"#e8e0d0",OUT);oval(X,wy(cy+0.4),ws(2.2),ws(1.8),"#c8bca8");
    disc(wx(cx-0.9),wy(cy),ws(0.95),ws(0.95),"#d8362a","#5a1410");disc(wx(cx+0.9),wy(cy+0.2),ws(0.95),ws(0.95),"#f09020","#6a3a08");disc(wx(cx),wy(cy+0.9),ws(0.85),ws(0.85),"#7ab030","#2a4a10");
    poly([[cx-1.6,cy-0.9],[cx+1.4,cy-1.4],[cx+1.6,cy-0.9],[cx-1.2,cy-0.3]],"#f0d040");wr(cx-0.95,cy-1.1,0.3,0.4,"#3a2a10");}
  function drawCookbook(cx,cy){var x0=cx-2.6,y0=cy-2.2;wr(x0+0.4,y0+0.5,5.2,4.2,"rgba(0,0,0,0.25)");wr(x0,y0+3.4,5.2,0.9,"#5a3818");
    plate(x0,y0,2.6,3.8,"#f4efe0","#7a2a18");plate(x0+2.6,y0,2.6,3.8,"#f4efe0","#7a2a18");
    var i;for(i=0;i<3;i++){wr(x0+0.5,y0+0.9+i*0.8,1.6,0.25,"#9a9080");wr(x0+3.1,y0+0.9+i*0.8,1.6,0.25,"#9a9080");}potatoFace(x0+1.3,y0+3.0,0.6);}
  function drawAquarium(cx,cy){var a=A(),w=6.4,h=5.2,x0=cx-w/2,y0=cy-h/2;shadow(x0,y0,w,h);plate(x0,y0,w,h,"#4a9ad0","#1a2a3a");
    wr(x0+0.45,y0+0.45,w-0.9,0.6,"#8ad0f0");wr(x0+0.45,y0+h-1.3,w-0.9,0.85,"#d8c890");
    var fx=cx+Math.sin(a.t*0.9)*1.8,fy=cy-0.4+Math.sin(a.t*1.7)*0.4,dir=Math.cos(a.t*0.9)>0?1:-1;
    disc(wx(fx),wy(fy),ws(0.8),ws(0.5),"#ff8a20",null);poly([[fx-dir*0.7,fy],[fx-dir*1.4,fy-0.5],[fx-dir*1.4,fy+0.5]],"#ff8a20");
    var gx=cx-Math.sin(a.t*0.6+1)*1.5;disc(wx(gx),wy(cy+0.7),ws(0.55),ws(0.35),"#ffe040",null);
    wr(x0+1.0,y0+h-2.6,0.4,1.4,"#3a8a3a");wr(x0+w-1.4,y0+h-2.2,0.4,1.0,"#3a8a3a");
    if(a.f&1)wr(cx+1.6,y0+1.2-0.3*(a.f>>1),0.35,0.35,"#e0f4ff");}

  /* ---------------- WASH ROOM ---------------- */
  function drawTowelRack(cx,cy){var w=12,x0=cx-w/2,y0=cy-3;wr(x0,y0+0.6,w,0.6,"#b0b4b8");wr(x0,y0+0.4,0.7,1.0,"#7a7e82");wr(x0+w-0.7,y0+0.4,0.7,1.0,"#7a7e82");
    plate(x0+1,y0+1,4.6,4.8,"#4a8ad0","#1a3a6a");wr(x0+1.45,y0+4.4,3.7,0.5,"#ffffff");
    plate(x0+6.2,y0+1,4.6,4.0,"#f4f0e8","#7a766c");wr(x0+6.65,y0+3.6,3.7,0.5,"#c0361e");}
  function drawSoap(cx,cy){var x0=cx-2.4,y0=cy-3;wr(x0+0.4,y0+0.6,4.8,6,"rgba(0,0,0,0.25)");plate(x0+0.2,y0+2,4.4,4.0,"#f08ab8","#6a2a4a");
    wr(x0+0.65,y0+2.4,1.0,3.2,"#ffc0dc");wr(x0+1.8,y0+0.6,1.2,1.5,"#e8e8e8");wr(x0+2.8,y0+0.6,1.4,0.5,"#e8e8e8");
    oval(wx(cx+1.4),wy(cy+1.6),ws(0.5),ws(0.5),"rgba(255,255,255,0.7)");}
  function drawMopBucket(cx,cy){var X=wx(cx),Y=wy(cy);softShadow(X,wy(cy+0.8),ws(5.4),ws(4.6));
    disc(X,Y,ws(4.4),ws(4.4),"#e0b020",OUT);oval(X,Y,ws(3.6),ws(3.6),"#6aa8d0");oval(X-ws(1),Y-ws(1),ws(1.2),ws(0.7),"rgba(255,255,255,0.4)");
    line(cx+0.6,cy+0.6,cx+5.6,cy-4.4,"#8a5a2c",0.6);disc(wx(cx+0.4),wy(cy+0.5),ws(1.5),ws(1.3),"#e8e0c8","#7a7060");}
  function drawToyBoat(cx,cy,st,o){o=o||{};var a=A(),bob=Math.sin(a.t*2.3)*0.25;cy+=bob;
    oval(wx(cx),wy(cy+1.2),ws(3.6),ws(1.2),"rgba(255,255,255,0.25)");
    poly([[cx-3,cy-0.2],[cx+3,cy-0.2],[cx+2,cy+1.4],[cx-2,cy+1.4]],OUT);poly([[cx-2.6,cy],[cx+2.6,cy],[cx+1.8,cy+1.1],[cx-1.8,cy+1.1]],"#d8362a");
    wr(cx-2.2,cy,4.4,0.35,"#ffffff");wr(cx-0.15,cy-3.6,0.3,3.6,"#5a3418");poly([[cx+0.15,cy-3.4],[cx+2.4,cy-0.6],[cx+0.15,cy-0.6]],"#f4f0e8");}
  function drawBubbles(cx,cy,st,o){var a=A(),i;disc(wx(cx),wy(cy),ws(1.6),ws(1.3),"#4ac0c8",OUT);oval(wx(cx),wy(cy),ws(0.9),ws(0.7),"#a0f0f4");
    for(i=0;i<7;i++){var ph=(a.t*0.6+i/7)%1,bx=cx+Math.sin(i*2.3+a.t)*4*ph+(i-3)*0.8,by=cy-ph*9,r=0.5+0.6*((i*3)%4)/3;
      var g=C();g.globalAlpha=Math.max(0,1-ph);g.strokeStyle="#e8fcff";g.lineWidth=Math.max(0.6,ws(0.2));g.beginPath();g.ellipse(wx(bx),wy(by),ws(r),ws(r),0,0,6.283);g.stroke();
      g.fillStyle="rgba(255,255,255,0.8)";g.fillRect(wx(bx-r*0.4),wy(by-r*0.5),Math.max(1,ws(0.25)),Math.max(1,ws(0.25)));g.globalAlpha=1;}}

  /* ---------------- THE CAT (wanders; renderer-only) ---------------- */
  function drawCatSprite(cx,cy,st,o){o=o||{};var a=A(),g=C(),dir=o.dir||0,X=wx(cx),Y=wy(cy);
    if(st==="sleep"){disc(X,Y,ws(2.6),ws(2.1),"#e08a30",OUT);oval(X-ws(0.6),Y-ws(0.5),ws(1.2),ws(0.8),"#f8b060");
      disc(wx(cx+1.6),wy(cy-0.8),ws(1.2),ws(1.05),"#e08a30",OUT);wr(cx+1.0,cy-0.9,0.5,0.15,"#3a2010");wr(cx+1.8,cy-0.9,0.5,0.15,"#3a2010");
      g.strokeStyle="#c06a20";g.lineWidth=Math.max(0.8,ws(0.5));g.beginPath();g.arc(X,Y,ws(2.4),1.0,2.6);g.stroke();
      if(a.f<2){g.fillStyle="#ffffff";g.font="700 "+Math.max(6,Math.round(ws(2.2)))+"px monospace";g.fillText("z",wx(cx+2.6),wy(cy-2.4-a.f*0.6));}
      return;}
    g.save();g.translate(X,Y);g.rotate(dir);
    var step=st==="walk"?Math.sin(a.t*14)*0.5:0;
    g.strokeStyle="#c06a20";g.lineWidth=Math.max(0.8,ws(0.45));g.beginPath();g.moveTo(-ws(2.0),0);g.quadraticCurveTo(-ws(3.2),ws(1.2+step),-ws(3.8),ws(0.2));g.stroke();
    oval(ws(-0.8+step*0.3),ws(1.2),ws(0.45),ws(0.35),"#c06a20");oval(ws(0.9-step*0.3),ws(-1.2),ws(0.45),ws(0.35),"#c06a20");
    disc(0,0,ws(2.2),ws(1.4),"#e08a30",OUT);oval(-ws(0.4),-ws(0.3),ws(1.2),ws(0.6),"#f8b060");
    disc(ws(2.2),0,ws(1.15),ws(1.05),"#e08a30",OUT);
    g.fillStyle="#e08a30";g.beginPath();g.moveTo(ws(2.0),-ws(0.7));g.lineTo(ws(2.4),-ws(1.6));g.lineTo(ws(2.9),-ws(0.6));g.closePath();g.fill();
    g.beginPath();g.moveTo(ws(2.0),ws(0.7));g.lineTo(ws(2.4),ws(1.6));g.lineTo(ws(2.9),ws(0.6));g.closePath();g.fill();
    g.fillStyle="#1a1410";g.fillRect(ws(2.6),-ws(0.5),Math.max(1,ws(0.3)),Math.max(1,ws(0.3)));g.fillRect(ws(2.6),ws(0.25),Math.max(1,ws(0.3)),Math.max(1,ws(0.3)));
    g.restore();}

  var REG={window:[drawWindow,14,7],spiceRack:[drawSpiceRack,10,7],coatHook:[drawCoatHook,7,7],calendar:[drawCalendar,7,7],potsPans:[drawPotsPans,14,7],photos:[drawPhotos,12,7],
    stringLights:[drawStringLights,24,7],neonSign:[drawNeonSign,14,7],trophyShelf:[drawTrophyShelf,16,7],sideTable:[drawSideTable,14,10],compost:[drawCompost,10,10],
    sackPile:[drawSackPile,16,12],bookshelf:[drawBookshelf,20,8],catBed:[drawCatBed,12,10],statue:[drawStatue,10,10],fruitBowl:[drawFruitBowl,6,6],cookbook:[drawCookbook,6,6],
    aquarium:[drawAquarium,6.4,5.2],towelRack:[drawTowelRack,12,7],soap:[drawSoap,6,7],mopBucket:[drawMopBucket,10,10],toyBoat:[drawToyBoat,6,5],bubbles:[drawBubbles,6,10],cat:[drawCatSprite,8,4]};
  for(var id in REG)S.register(id,REG[id][0],{name:id.toUpperCase(),group:"decor",w:REG[id][1],h:REG[id][2],states:["on"],animated:[],blurb:"0.4.11 decor"});
})();
