# Papa Potato 0.4.11 — decor audit (t1205 + t1206)

## What 0.4.10 had
- **Furniture:** sink, small cooler, basic cot, plant, lamp, radio, fan, pantry shelf, TV + armchair. Starters: table, cooler, stool, bed.
- **Carpets:** kitchen mat, rug, runner, round rug.
- **Wall:** clock, poster.
- **Wash room:** rubber duck (basin) only. There was no player decor at all in the wash room.
- **Missing categories:**
  - table-top items
  - wash-room wall and floor decor
  - more basin floaters
  - cosmetic themes
  - side-wall decor (only 2 wall items existed)
  - a sink at the cutting table
- **Kitchen Mat:** looked like a dark block at small size.
- **Editor tray:** one endless horizontal scroll.

## Added in 0.4.11: 24 items, each with a real effect
| Lv | Item | Price | Where | Effect |
|---|---|---|---|---|
| 1 | COAT HOOK + APRON | 10c | wall | QUICK = 4 peels, not 5 |
| 1 | CALENDAR | 8c | wall | 10c payday each new shift day (no back pay) |
| 1 | SPICE RACK | 12c | wall | meals +65 hunger (not +55) |
| 1 | WINDOW + CURTAINS | 14c | wall | +4% work in the day (6 AM–8 PM) |
| 1 | SIDE TABLE | 12c | floor (blocker) | 2 table-top slots |
| 1 | COMPOST BIN | 16c | floor (blocker) | sweep +25%, 1c per 20 peels swept |
| 1 | FRUIT BOWL | 10c | table-top | hunger −10% in the kitchen |
| 1 | WALLPAPER BOOK | 15c | theme | COSMETIC (4 wall looks) |
| 2 | HANGING POTS + PANS | 18c | wall | food cans −1c |
| 2 | FRAMED PHOTOS | 14c | wall | auto-lazy at 20% (not 25%) |
| 2 | POTATO SACK PILE | 18c | floor (blocker) | grab 20% faster |
| 2 | COOKBOOK STAND | 16c | table-top | NEAT at 0.9 speed (not 0.8) |
| 2 | TOWEL RACK | 14c | wash wall | energy −15% while in the wash room |
| 2 | SOAP DISPENSER | 12c | wash wall | heap pull +15% |
| 2 | MOP BUCKET | 12c | wash floor (kept off his path) | walk +10% in the wash room |
| 2 | FLOOR TILES | 20c | theme | COSMETIC (4 floor looks) |
| 3 | STRING LIGHTS | 22c | wall | +4% work at night |
| 3 | NEON OPEN SIGN | 30c | wall | +1c tip every 20th ship |
| 3 | BOOKSHELF | 28c | floor (blocker) | next level −10% |
| 3 | CAT BED + CAT | 35c | floor (blocker) | a wandering cat; naps +10% regen |
| 3 | TOY BOAT | 16c | basin (INV) | canal flow ×1.15 |
| 4 | TROPHY SHELF | 40c | wall | +1% work per cup (cup per level, gold cup per 500 shipped, max +3) |
| 4 | AQUARIUM | 45c | table-top | hunger and energy −5% |
| 4 | BUBBLE MAKER | 24c | basin (INV) | sloppy potatoes washed in the wash room pay the full 3c |
| 5 | PAPA STATUE | 60c | floor (blocker) | +5% work |

- No existing price changed. Level prices and upgrade prices are untouched.

## Fixes and systems
- **Kitchen Mat redrawn:** cream stitched border, sage field, light ribs, tassels on the short ends. The footprint is the same (18×12).
- **TABLE SINK (t1206):**
  - Built into the far end of the peel table on every save. It is not shop-only.
  - Peeling makes his hands dirty (CLEAN HANDS meter). The new command box RINSE WHEN HANDS < (default 30) makes him rinse for 1 s at the table sink, right where he stands.
  - Under 25% clean, peeling is 15% slower. You can tap the sink for info.
- **MOOD (t1116 / IDEA.md "mood"):** a derived meter, shown on the HUD.
  - Raises it: +2 per decor (cap +30), +8 music, +4 watered plant, +3 theme.
  - Lowers it: hunger or energy under 25%, sticky hands, peel mess.
  - Effect: 60%+ gives +3% work; 80%+ gives +6%. It is bonus only: low mood never slows him below 0.4.10.
- **Tray:** category tabs (FLOOR / RUG / WALL / TOP / MACH; WASH in the wash room) with pages (< 1/N >). There is no endless scroll.
- **Wash-room decor:**
  - Can be placed in EDIT in the wash room (needs the key).
  - Defaults sit in the bottom half (t1187). The player may drag items to the top half.
  - Floor items are refused on his door→basin lanes and at the door.
- **Placement rules:**
  - Carpets go under furniture and never on each other.
  - Wall items snap to the N/E/W walls, clear of the door, scanner/drop and chute.
  - New floor decor is a blocker.
  - Table-tops snap to free slots and go back to INV when their surface goes.
- **Save:** papaPotato.save.v13, which loads v12 and v11 (and older through the existing chain).

## Discussed for Papa but never built (t1206 sweep)
Sources: requests/future/papa-potato-notes-t1116/NOTES.md, requests/future/potato-peeler/IDEA.md, 0.4-levels-plan.md, the build-potato04x PROGRESS docs, machines-sheet.

| Item (source) | Status | Why |
|---|---|---|
| Mood (IDEA.md needs) | BUILT | Derived meter that only moves through decor and care, so it needs no new command |
| Hygiene (IDEA.md needs) | BUILT | CLEAN HANDS, driven by the RINSE command box and the new table sink |
| Sink at the cutting table (t1206) | BUILT | Default part of the table |
| Compost bin (machines sheet) | BUILT | As decor with a real effect |
| Manual update (levels plan) | BUILT | New help page: TABLE SINK, MOOD, the 24 items, and a RINSE command page |
| Hand cramps (IDEA.md) | SKIPPED | Overlaps energy and hygiene, and Jay wanted to work out its details together |
| Upgraded starter tiers (levels plan) | ALREADY THERE | Covered by the UPS upgrades |
| Peel thickness (IDEA.md) | ALREADY THERE | Covered by STYLE (NEAT / STEADY / QUICK) |
| Neglect → auto (IDEA.md) | ALREADY THERE | AUTO-LAZY |
| All t1116 notes | ALREADY THERE | Done in 0.4.2+ |
| 0.5 machine pack in build-potato05-pack (fryer, sorter, sweeper bot, scale, truck dock, upgrade bench, bagger, oven, washer tub, storage crate, vending machine) | SKIPPED | Not trivially wireable: sprites05/sim05 are a separate unwired sim, each machine needs new flow logic, and the repairman/factory side is still to be worked out with Jay |
