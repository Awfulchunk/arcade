import sys
P='/workspace/game/build-potato0411/src/game.js'
s=open(P).read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit("count %d != %d for: %s"%(n,cnt,a[:100]))
    s=s.replace(a,b)
# tray with tabs + paging
rep('''function rebuildTray(){
  var el=$("invChips"),away=$("putAway");if(!el)return;
  var list=sim.trayList(),h="",i;
  if(!list.length)h='<div class="invchip empty">No unplaced items. Buy in the SHOP, or PUT AWAY something already in the room.</div>';
  for(i=0;i<list.length;i++)h+='<button class="invchip" type="button" data-place="'+list[i].id+'">'+esc(list[i].name)+'<b>DRAG IN</b></button>';
  el.innerHTML=h;''','''/* 0.4.11 tray: category tabs + pages (no endless scroll). Kitchen tabs: FLOOR / RUGS / WALL / TABLE-TOP / MACHINES. Wash room: WASH only. */
var TRAY_TABS_K=[["floor","FLOOR"],["rug","RUGS"],["wall","WALL"],["top","TOP"],["machine","MACH"]],TRAY_TABS_W=[["wash","WASH"]];
var trayTab="floor",trayPage=0;
function trayPer(){var el=$("invChips");var w=el?el.clientWidth:200;return Math.max(1,Math.floor((w+6)/96));}
function rebuildTray(){
  var el=$("invChips"),away=$("putAway"),tb=$("trayTabs");if(!el)return;
  var wash=viewIsWash(),list=sim.trayList(wash?"wash":"kitchen"),h="",i,tabs=wash?TRAY_TABS_W:TRAY_TABS_K,cnt={},th="";
  for(i=0;i<list.length;i++){var ct=list[i].cat==="starter"?"floor":list[i].cat;if(ct!=="rug"&&ct!=="wall"&&ct!=="top"&&ct!=="machine"&&ct!=="wash")ct="floor";list[i].tab=ct;cnt[ct]=(cnt[ct]|0)+1;}
  var okTab=false;for(i=0;i<tabs.length;i++)if(tabs[i][0]===trayTab)okTab=true;
  if(!okTab){trayTab=tabs[0][0];trayPage=0;}
  if(!(cnt[trayTab]>0)){for(i=0;i<tabs.length;i++)if(cnt[tabs[i][0]]>0){trayTab=tabs[i][0];trayPage=0;break;}}
  var shown=list.filter(function(q){return q.tab===trayTab;}),per=trayPer(),pages=Math.max(1,Math.ceil(shown.length/per));
  if(trayPage>=pages)trayPage=pages-1;if(trayPage<0)trayPage=0;
  for(i=0;i<tabs.length;i++)th+='<button type="button" class="ttab'+(tabs[i][0]===trayTab?' on':'')+'" data-tab="'+tabs[i][0]+'">'+tabs[i][1]+(cnt[tabs[i][0]]?' <b>'+cnt[tabs[i][0]]+'</b>':'')+'</button>';
  th+='<span class="tpg"><button type="button" class="tpb" data-tpage="-1"'+(trayPage<=0?' disabled':'')+'>&lt;</button><i>'+(trayPage+1)+'/'+pages+'</i><button type="button" class="tpb" data-tpage="1"'+(trayPage>=pages-1?' disabled':'')+'>&gt;</button></span>';
  if(tb)tb.innerHTML=th;
  if(!list.length)h='<div class="invchip empty">'+(wash?'No wash-room decor to place. Buy towels, soap or a mop bucket in the SHOP.':'No unplaced items. Buy in the SHOP, or PUT AWAY something already in the room.')+'</div>';
  else if(!shown.length)h='<div class="invchip empty">Nothing in this tab.</div>';
  for(i=trayPage*per;i<Math.min(shown.length,(trayPage+1)*per);i++)h+='<button class="invchip" type="button" data-place="'+shown[i].id+'">'+esc(shown[i].name)+'<b>DRAG IN</b></button>';
  el.innerHTML=h;''')
rep('''  var rb=$("rotBtn");if(rb)rb.className=(dragId&&dragId!=="washPile"&&dragId!=="streetMouth"&&!PPSim.isWall(dragId))?"on":"";''',
    '''  var rb=$("rotBtn");if(rb)rb.className=(dragId&&dragId!=="washPile"&&dragId!=="streetMouth"&&!PPSim.isWall(dragId)&&!PPSim.isTop(dragId)&&!PPSim.isWashItem(dragId))?"on":"";''')
# tab clicks + tray drop busting caches
rep('''  tray.addEventListener("pointerdown",function(e){
    var chip=e.target.closest?e.target.closest("[data-place]"):null;if(!chip)return;''','''  var tabs=$("trayTabs");if(tabs)tabs.addEventListener("pointerdown",function(e){var b=e.target.closest?e.target.closest("[data-tab],[data-tpage]"):null;if(!b||b.disabled)return;e.preventDefault();
    if(b.hasAttribute("data-tab")){trayTab=b.getAttribute("data-tab");trayPage=0;}else trayPage+=+b.getAttribute("data-tpage");rebuildTray();});
  tray.addEventListener("pointerdown",function(e){
    var chip=e.target.closest?e.target.closest("[data-place]"):null;if(!chip)return;''')
rep('''      if(sim.placeItem(item,w.x,w.y)==="ok"){staticLayer=null;messLayer=null;changed();rebuildTray();layout();}''',
    '''      var pr2=sim.placeItem(item,w.x,w.y);if(pr2==="ok"){bustRoomCache();messLayer=null;changed();rebuildTray();layout();dragId=item;showInfo(item);rebuildTray();}
      else showInfoText(sim.s&&PPSim.ITEMI[item]?PPSim.ITEMI[item].name:"",pr2==="nokey"?"Needs the ROOM KEY.":(PPSim.isTop(item)?"No free table-top slot. Place a SIDE TABLE (2 slots) or clear the cooler lid.":"No room there. Try another spot."));''')
rep('''    var w=worldFromEvent(e);if(sim.moveItem(dragId,w.x-(PE.ox||0),w.y-(PE.oy||0))){if(dragId==="washPile"||dragId==="streetMouth")bustRoomCache();else{staticLayer=null;messLayer=null;}messVer++;if(playRect)placeTags();}}''',
    '''    var w=worldFromEvent(e);if(sim.moveItem(dragId,w.x-(PE.ox||0),w.y-(PE.oy||0))){bustRoomCache();messLayer=null;messVer++;if(playRect)placeTags();}}''')
rep('''function putAwaySelected(){
  if(!dragId||!PPSim.isPlaceable(dragId)||!sim.placed(dragId))return;
  sim.unplace(dragId);dragId=null;staticLayer=null;''','''function putAwaySelected(){
  if(!dragId||!PPSim.isPlaceable(dragId)||!sim.placed(dragId))return;
  sim.unplace(dragId);dragId=null;bustRoomCache();''')
rep('''else if(a&&a.indexOf("return:")===0){sim.unplace(a.slice(7));staticLayer=null;''','''else if(a&&a.indexOf("return:")===0){sim.unplace(a.slice(7));bustRoomCache();''')
rep('''function toggleEditor(){
  editMode=!editMode;dragId=null;if(!editMode)showInfo(null);''','''function toggleEditor(){
  editMode=!editMode;dragId=null;if(!editMode)showInfo(null);trayPage=0;''')
# basin + theme acts
rep('''  else if(a&&a.indexOf("duck:")===0){''','''  else if(a&&a.indexOf("basin:")===0){var pa=a.split(":"),br=sim.putBasin(pa[1],pa[2]==="in");if(br==="nokey"){var bb=ovl.querySelector('[data-act="'+a+'"]');if(bb)bb.innerHTML="NEED<br>KEY";setTimeout(function(){ovlDirty=true;},800);}else ovlDirty=true;changed();}
  else if(a&&a.indexOf("theme:")===0){var tq=a.split(":"),th0=sim.theme();sim.setTheme(tq[1],(tq[1]==="wall"?th0.wall:th0.floor)+1);bustRoomCache();ovlDirty=true;changed();}
  else if(a&&a.indexOf("duck:")===0){''')
# showInfoText helper
rep('''function tickInfo(){''','''function showInfoText(n,d){var el=$("objInfo");if(!el)return;infoId="msg";$("oiName").textContent=n;$("oiDesc").textContent=d;el.className="";infoUntil=performance.now()+3500;}
function tickInfo(){''')
# INFO entries
rep('''  shelf:["PANTRY SHELF","+2 food can storage."],''','''  shelf:["PANTRY SHELF","+2 food can storage."],
  tableSink:function(){return ["TABLE SINK","Built into the peel table. He rinses his hands here (RINSE WHEN HANDS <). Clean hands now "+Math.round(sim.hyg())+"%. Under 25% peeling is 15% slower."];},
  window:function(){return ["WINDOW + CURTAINS","Daylight 6 AM to 8 PM: works 4% faster. Now: "+(sim.isDay()?"DAY (on)":"NIGHT (off)")+"."];},
  spiceRack:["SPICE RACK","Each food can gives +65 hunger (not +55)."],
  coatHook:["COAT HOOK + APRON","QUICK peeling drops 4 peels a potato, not 5."],
  calendar:function(){return ["CALENDAR","Shift day "+sim.clockTime().day+". Pays a 10c payday at each new shift day ("+((sim.s.decor&&sim.s.decor.paydays)|0)+" so far)."];},
  potsPans:["HANGING POTS + PANS","Cooking at home: food cans cost 1c less."],
  photos:["FRAMED POTATO PHOTOS","He only goes AUTO-LAZY under 20%, not 25%."],
  stringLights:function(){return ["STRING LIGHTS","Night shift 8 PM to 6 AM: works 4% faster. Now: "+(sim.isDay()?"DAY (off)":"NIGHT (on)")+"."];},
  neonSign:function(){return ["NEON OPEN SIGN","Every 20th potato shipped gets a +1c tip ("+((sim.s.decor&&sim.s.decor.tips)|0)+" tips so far)."];},
  trophyShelf:function(){return ["TROPHY SHELF",sim.trophies()+" cups: one per level reached, a gold cup per 500 shipped (max 3). Works "+sim.trophies()+"% faster."];},
  sideTable:["SIDE TABLE","Holds 2 table-top items. Put it away and they go back to INV."],
  compost:function(){return ["COMPOST BIN","Sweeping 25% faster. Every 20 peels swept = 1c ("+((sim.s.decor&&sim.s.decor.compost)|0)+"c so far)."];},
  sackPile:["POTATO SACK PILE","Grabbing potatoes is 20% faster."],
  bookshelf:["BOOKSHELF","The next LEVEL costs 10% less."],
  catBed:["CAT BED + CAT","The cat wanders and naps here. Purring: his naps restore 10% faster."],
  statue:["PAPA STATUE","Pride: he works 5% faster."],
  fruitBowl:["FRUIT BOWL","Table-top. Hunger drains 10% slower in the kitchen."],
  cookbook:["COOKBOOK STAND","Table-top. NEAT peeling at 90% speed, not 80%."],
  aquarium:["AQUARIUM","Table-top. Hunger and energy drain 5% slower."],
  towelRack:["TOWEL RACK","Wash room. Energy drains 15% slower while he is in here."],
  soap:["SOAP DISPENSER","Wash room. The current pulls potatoes off the heap 15% faster."],
  mopBucket:["MOP BUCKET","Wash room. He walks 10% faster in here."],
  toyBoat:["TOY BOAT","Rides the canal. The current is 15% stronger."],
  bubbles:["BUBBLE MAKER","Sloppy potatoes that ship through the wash room pay the full 3c."],
  papa:function(){return ["PAPA","MOOD "+sim.mood()+"% ("+(sim.moodMul()>1?"works +"+Math.round((sim.moodMul()-1)*100)+"%":sim.moodMul()<1?"works -5%":"no bonus")+"). Decor, music and a clean, fed Papa raise it. CLEAN HANDS "+Math.round(sim.hyg())+"%."];},''')
# hitAny: tops/sink/papa in kitchen and wash floaters
rep('''    if(sim.duckOn()){var dk=duckPos(RT||0);if(Math.hypot(x-dk.x,y-dk.y)<=6)return "duck";}''','''    if(sim.duckOn()){var dk=duckPos(RT||0);if(Math.hypot(x-dk.x,y-dk.y)<=6)return "duck";}
    if(sim.basinOn("toyBoat")){var bt=boatPos(RT||0);if(Math.hypot(x-bt.x,y-bt.y)<=6)return "toyBoat";}
    if(sim.basinOn("bubbles")){var bbx=WASH.land.x-WASH.land.rx*0.62,bby=WASH.land.y+WASH.land.ry*0.30;if(Math.hypot(x-bbx,y-bby)<=5)return "bubbles";}
    var wi=["towelRack","soap","mopBucket"];for(var wj=0;wj<wi.length;wj++){if(!sim.placed(wi[wj]))continue;var wq=sim.placeOf(wi[wj]),wf=sim.footOf(wi[wj],wq.x,wq.y,wq.r|0);if(x>=wf.x0-2&&x<=wf.x1+2&&y>=wf.y0-2&&y<=wf.y1+2)return wi[wj];}''')
rep('''  var h=hitEditItem(x,y);if(h)return h;
  if(sim.doorHit(x,y,"kitchen"))return "door";''','''  var gq=sim.s.g;if(gq.where!=="wash"&&Math.hypot(x-gq.x*RW,y-gq.y*RH)<=4.5)return "papa";
  var tsk=PPSim.tableKids().sink;if(tsk&&Math.abs(x-tsk.x)<=tsk.hw+1&&Math.abs(y-tsk.y)<=tsk.hh+1)return "tableSink";
  var h=hitEditItem(x,y);if(h)return h;
  if(sim.doorHit(x,y,"kitchen"))return "door";''')
open(P,'w').write(s)
print("ok g2")
