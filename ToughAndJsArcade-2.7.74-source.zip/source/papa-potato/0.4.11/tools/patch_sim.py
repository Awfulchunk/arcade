import re,sys
P='/workspace/game/build-potato0411/src/sim.js'
s=open(P).read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit("count %d != %d for: %s"%(n,cnt,a[:90]))
    s=s.replace(a,b)
rep('/* ===== Papa Potato 0.4.10 — simulation (0.4.10:','/* ===== Papa Potato 0.4.11 — simulation (0.4.11: 24 new decor items (wall, floor, table-top, wash room, basin, cosmetic themes), a TABLE SINK built into the peel table (hand hygiene + RINSE command), a MOOD meter that decor lifts. Save v13, loads v1-v12. Was 0.4.10:')
# GEO defaults
rep("clock:{x:80,y:3.5},poster:{x:94,y:3.5},fan:{x:96,y:182},shelf:{x:90,y:72}};",
 "clock:{x:80,y:3.5},poster:{x:94,y:3.5},fan:{x:96,y:182},shelf:{x:90,y:72},\n"
 "    /* 0.4.11 decor defaults (wall items snap to the nearest free wall spot; floor items spiral out to a free spot) */\n"
 "    window:{x:3.5,y:60},spiceRack:{x:104.5,y:70},coatHook:{x:12,y:3.5},calendar:{x:3.5,y:84},potsPans:{x:104.5,y:96},photos:{x:3.5,y:110},\n"
 "    stringLights:{x:86,y:3.5},neonSign:{x:104.5,y:40},trophyShelf:{x:3.5,y:136},\n"
 "    sideTable:{x:20,y:96},compost:{x:16,y:150},sackPile:{x:96,y:232},bookshelf:{x:84,y:14},catBed:{x:20,y:206},statue:{x:98,y:92},\n"
 "    fruitBowl:{x:20,y:96},cookbook:{x:20,y:96},aquarium:{x:20,y:96}};")
rep('var PLACEABLES=["sink","smallCooler","basicCot","conveyor","suction","plant","lamp","autoPeeler","outConveyor","radio","rug","tvArmchair","kitchenMat","runner","roundRug","clock","poster","fan","shelf"];',
 'var PLACEABLES=["sink","smallCooler","basicCot","conveyor","suction","plant","lamp","autoPeeler","outConveyor","radio","rug","tvArmchair","kitchenMat","runner","roundRug","clock","poster","fan","shelf",\n'
 '    "window","spiceRack","coatHook","calendar","potsPans","photos","stringLights","neonSign","trophyShelf","sideTable","compost","sackPile","bookshelf","catBed","statue","fruitBowl","cookbook","aquarium","towelRack","soap","mopBucket"];')
rep('var WALLS=["clock","poster"];                        /* 0.4.10 wall items: hang on the north / east / west wall, never on the floor */',
 'var WALLS=["clock","poster","window","spiceRack","coatHook","calendar","potsPans","photos","stringLights","neonSign","trophyShelf"];   /* wall items: hang on the north / east / west wall, never on the floor */\n'
 '  var TOPS=["fruitBowl","cookbook","aquarium"];          /* 0.4.11 table-top items: sit in a slot on the SIDE TABLE (2) or the food cooler lid (1); no floor footprint */\n'
 '  var WASHW=["towelRack","soap"];                       /* 0.4.11 wash-room wall items: north wall (off the door and ship opening) or west wall */\n'
 '  var WASHF=["mopBucket"];                              /* 0.4.11 wash-room floor items: off the basin, canal, outlet, door and his walking lane */\n'
 '  var BASIN=["duck","toyBoat","bubbles"];               /* float in the wash basin, put in from INV */\n'
 '  var FLOOR11=["sideTable","compost","sackPile","bookshelf","catBed","statue"];\n'
 '  var THEMES={wall:["CLASSIC","MINT STRIPE","ROSE TILE","NAVY PANEL"],floor:["CLASSIC","BLACK + WHITE","TERRACOTTA","OAK PLANK"]};\n'
 '  function isTop(id){return TOPS.indexOf(id)>=0;}\n'
 '  function isWashItem(id){return WASHW.indexOf(id)>=0||WASHF.indexOf(id)>=0;}\n'
 '  function isWashWall(id){return WASHW.indexOf(id)>=0;}\n'
 '  function isBasin(id){return BASIN.indexOf(id)>=0;}')
# ITEMS: append new entries before autoWash closing; insert by level: simply append before "  ];\n  var ITEMI"
new_items='''    /* ---- 0.4.11 decor (Jay t1205). cat: wall / floor / top / wash / basin / theme ---- */
    {id:"coatHook",name:"COAT HOOK + APRON",lv:1,price:10,group:"decor",kind:"place",cat:"wall",fx:"WALL. Papa's apron. QUICK peeling drops 4 peels a potato, not 5."},
    {id:"calendar",name:"CALENDAR",lv:1,price:8,group:"decor",kind:"place",cat:"wall",fx:"WALL. Shows the shift day. Each new shift day (every 24 shift hours) pays a 10c payday."},
    {id:"spiceRack",name:"SPICE RACK",lv:1,price:12,group:"decor",kind:"place",cat:"wall",fx:"WALL. Tastier meals: each food can gives +65 hunger, not +55."},
    {id:"window",name:"WINDOW + CURTAINS",lv:1,price:14,group:"decor",kind:"place",cat:"wall",fx:"WALL. Daylight (6 AM to 8 PM shift time): he works 4% faster."},
    {id:"sideTable",name:"SIDE TABLE",lv:1,price:12,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Holds 2 table-top items (fruit bowl, cookbook, aquarium)."},
    {id:"compost",name:"COMPOST BIN",lv:1,price:16,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Short trip to the bin: sweeping is 25% faster, and every 20 peels swept turn into 1c of compost."},
    {id:"fruitBowl",name:"FRUIT BOWL",lv:1,price:10,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP (side table or cooler lid). He snacks: hunger drains 10% slower in the kitchen."},
    {id:"wallpaper",name:"WALLPAPER BOOK",lv:1,price:15,group:"decor",kind:"theme",cat:"theme",fx:"COSMETIC ONLY. Kitchen walls: CLASSIC, MINT STRIPE, ROSE TILE or NAVY PANEL. Change it in INV."},
    {id:"potsPans",name:"HANGING POTS + PANS",lv:2,price:18,group:"decor",kind:"place",cat:"wall",fx:"WALL. Cooking at home: food cans cost 1c less."},
    {id:"photos",name:"FRAMED POTATO PHOTOS",lv:2,price:14,group:"decor",kind:"place",cat:"wall",fx:"WALL. Family photos keep his spirits up: he only goes AUTO-LAZY under 20%, not 25%."},
    {id:"sackPile",name:"POTATO SACK PILE",lv:2,price:18,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Spare sacks by the pile: grabbing potatoes is 20% faster."},
    {id:"cookbook",name:"COOKBOOK STAND",lv:2,price:16,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP. NEAT peeling works at 90% speed, not 80%."},
    {id:"towelRack",name:"TOWEL RACK",lv:2,price:14,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM WALL. Dry hands: energy drains 15% slower while he is in the wash room. Needs the ROOM KEY."},
    {id:"soap",name:"SOAP DISPENSER",lv:2,price:12,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM WALL. Soapy water: the current pulls potatoes off the basin heap 15% faster. Needs the ROOM KEY."},
    {id:"mopBucket",name:"MOP BUCKET",lv:2,price:12,group:"decor",kind:"place",cat:"wash",fx:"WASH ROOM FLOOR. Dry floor: he walks 10% faster in the wash room. Needs the ROOM KEY."},
    {id:"floorTiles",name:"FLOOR TILES",lv:2,price:20,group:"decor",kind:"theme",cat:"theme",fx:"COSMETIC ONLY. Kitchen floor: CLASSIC, BLACK + WHITE, TERRACOTTA or OAK PLANK. Change it in INV."},
    {id:"stringLights",name:"STRING LIGHTS",lv:3,price:22,group:"decor",kind:"place",cat:"wall",fx:"WALL. Night shift (8 PM to 6 AM shift time): he works 4% faster. They twinkle."},
    {id:"neonSign",name:"NEON OPEN SIGN",lv:3,price:30,group:"decor",kind:"place",cat:"wall",fx:"WALL. Open for business: every 20th potato shipped gets a +1c tip."},
    {id:"bookshelf",name:"BOOKSHELF",lv:3,price:28,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. Self-help books: buying the next LEVEL costs 10% less."},
    {id:"catBed",name:"CAT BED + CAT",lv:3,price:35,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. A cat wanders the kitchen and naps here. Purring: his naps restore energy 10% faster."},
    {id:"toyBoat",name:"TOY BOAT",lv:3,price:16,group:"decor",kind:"basin",cat:"basin",fx:"WASH BASIN. Put it in from INV. It rides the canal: the current is 15% stronger. Needs the ROOM KEY."},
    {id:"trophyShelf",name:"TROPHY SHELF",lv:4,price:40,group:"decor",kind:"place",cat:"wall",fx:"WALL. Shows your progress: one cup per level reached, a gold cup per 500 potatoes shipped (up to 3). He works 1% faster per cup."},
    {id:"aquarium",name:"AQUARIUM",lv:4,price:45,group:"decor",kind:"place",cat:"top",fx:"TABLE-TOP. Calm fish: hunger and energy drain 5% slower."},
    {id:"bubbles",name:"BUBBLE MAKER",lv:4,price:24,group:"decor",kind:"basin",cat:"basin",fx:"WASH BASIN. Put it in from INV. Sloppy potatoes that ship through the wash room pay the full 3c. Needs the ROOM KEY."},
    {id:"statue",name:"PAPA STATUE",lv:5,price:60,group:"decor",kind:"place",cat:"floor",fx:"FLOOR. A golden potato Papa. Pride: he works 5% faster."}
  ];
  var ITEMI={};'''
rep('''  ];
  var ITEMI={};''',new_items)
# categorise old items
rep("for(var ii=0;ii<ITEMS.length;ii++)ITEMI[ITEMS[ii].id]=ITEMS[ii];",
 "for(var ii=0;ii<ITEMS.length;ii++){var it0=ITEMS[ii];ITEMI[it0.id]=it0;if(!it0.cat)it0.cat=it0.group==='machine'?'machine':it0.group==='starter'?(it0.kind==='place'?'floor':it0.kind):(RUGS.indexOf(it0.id)>=0?'rug':WALLS.indexOf(it0.id)>=0?'wall':it0.kind==='duck'?'basin':'floor');}")
open(P,'w').write(s)
print("ok part1")
