import sys
P='/workspace/game/build-potato0411/src/sim.js'
s=open(P).read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit("count %d != %d for: %s"%(n,cnt,a[:90]))
    s=s.replace(a,b)
rep('      range:"OFF, 5 to 90 peels (step 5)"},',
'''      range:"OFF, 5 to 90 peels (step 5)"},
    {id:"rinse",does:"Rinses his hands at the table sink.",affects:"Clean hands under the number = rinse (1 s, at the table). Under 25% his hands are sticky: peeling 15% slower.",hi:"70%",lo:"OFF",name:"RINSE WHEN HANDS <",min:0,max:70,step:5,def:30,
      what:"Sends him to rinse his hands at the TABLE SINK (built into the peel table) when his clean hands drop below the number.",
      effect:"Peeling makes his hands dirty. Rinsing takes about 1 second right at the table and brings CLEAN HANDS back to 100%. Under 25% his hands are sticky and peeling is 15% slower. OFF = he never rinses.",
      range:"OFF, 5% to 70% (step 5)"},''')
# effects block
rep('P.spd=function(){var g=this.s.g;return g.lazy?(this.placed("poster")?0.70:C.lazySpeed):SPD[this.s.box.pace];};',
    'P.spd=function(){var g=this.s.g;return g.lazy?(this.placed("poster")?0.70:C.lazySpeed):SPD[this.s.box.pace];};\n  P.lazyLow=function(){return this.placed("photos")?20:C.lazyLow;};')
rep('return Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery));};',
    'return Math.max(1,Math.min(C.priceCap,Math.round(C.foodPrice*Math.pow(C.priceGrow,b))+Math.floor(this.s.t/C.priceEvery))-(this.placed("potsPans")?1:0));};')
rep('P.peelTime=function(){return C.peel*Math.pow(0.85,this.up("peeler"))*(this.equipped("betterPeeler")?0.90:1)/(this.lampOn()?1.08:1)/STYLE[this.s.box.style].sp;};',
    'P.peelTime=function(){var st=this.s.box.style,sp=STYLE[st].sp;if(st===0&&this.placed("cookbook"))sp=0.9;return C.peel*Math.pow(0.85,this.up("peeler"))*(this.equipped("betterPeeler")?0.90:1)/(this.lampOn()?1.08:1)/sp/(this.sticky()?0.85:1);};\n'
    '  /* ---- 0.4.11 table sink: clean hands (hygiene). Peeling dirties them; he rinses at the sink built into the peel table. ---- */\n'
    '  P.hyg=function(){var h=+this.s.hyg;return isFinite(h)?Math.max(0,Math.min(100,h)):100;};\n'
    '  P.sticky=function(){return this.hyg()<25;};\n'
    '  P.wantRinse=function(){var b=this.s.box;return b.rinse>0&&this.hyg()<b.rinse;};\n'
    '  P.peelsPer=function(){var st=this.s.box.style;if(st===2&&this.placed("coatHook"))return 4;return STYLE[st].peels;};\n'
    '  P.grabTime=function(){return C.grab*(this.placed("sackPile")?0.8:1);};\n'
    '  P.mealGain=function(){return C.meal+(this.placed("spiceRack")?10:0);};\n'
    '  P.isDay=function(){var h=this.clockTime().h;return h>=6&&h<20;};\n'
    '  P.trophies=function(){return Math.max(1,Math.min(5,this.s.level|0))+Math.min(3,Math.floor(((this.s.stats.washedShip|0)+(this.s.stats.unwashedShip|0))/500));};\n'
    '  /* MOOD (0.4.11): read-only, from his needs and the room. Decor lifts it; mood 60+ = work +3%, 80+ = +6%, under 30 = -5%. */\n'
    '  P.decorCount=function(){var n=0,i,it;for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(it.group!=="decor"||it.kind==="theme")continue;if(it.kind==="duck"?this.duckOn():it.kind==="basin"?this.basinOn(it.id):this.placed(it.id))n++;}return n;};\n'
    '  P.mood=function(){var s=this.s,m=50+Math.min(30,this.decorCount()*2);if(this.musicOn())m+=8;if(this.plantOk())m+=4;if(this.ownTheme())m+=3;\n'
    '    if(s.hunger<25)m-=15;if(s.energy<25)m-=10;if(this.sticky())m-=10;if(s.peels>=60)m-=10;else if(s.peels>=30)m-=5;\n'
    '    return Math.max(0,Math.min(100,Math.round(m)));};\n'
    '  P.moodMul=function(){var m=this.mood();return m>=80?1.06:m>=60?1.03:m<30?0.95:1;};\n'
    '  P.ownTheme=function(){var t=this.s.theme||{};return (this.owned("wallpaper")&&(t.wall|0)>0)||(this.owned("floorTiles")&&(t.floor|0)>0);};\n'
    '  P.basinOn=function(id){if(id==="duck")return this.duckOn();return this.owned(id)&&this.hasKey()&&!!(this.s.basin&&this.s.basin[id]);};\n'
    '  P.putBasin=function(id,on){if(id==="duck")return this.putDuck(on);if(!isBasin(id)||!this.owned(id))return "bad";if(on&&!this.hasKey())return "nokey";if(!this.s.basin||typeof this.s.basin!=="object")this.s.basin={};this.s.basin[id]=on?1:0;return "ok";};\n'
    '  P.setTheme=function(which,v){var own=which==="wall"?"wallpaper":which==="floor"?"floorTiles":null;if(!own||!this.owned(own))return "bad";v=Math.floor(+v);if(!isFinite(v))return "bad";var L=THEMES[which].length;v=((v%L)+L)%L;if(!this.s.theme)this.s.theme={wall:0,floor:0};this.s.theme[which]=v;return "ok";};\n'
    '  P.theme=function(){var t=this.s.theme||{};return {wall:this.owned("wallpaper")?(t.wall|0):0,floor:this.owned("floorTiles")?(t.floor|0):0};};')
rep('P.foodMax=function(){return C.foodMax+3*this.up("pantry")+(this.placed("smallCooler")?2:0)+(this.placed("shelf")?2:0);};',
    'P.foodMax=function(){return C.foodMax+3*this.up("pantry")+(this.placed("smallCooler")?2:0)+(this.placed("shelf")?2:0);};')
rep('P.energyMul=function(){var m=1,kit=this.s.g.where!=="wash";if(this.musicOn())m*=kit?0.8:0.9;if(kit&&this.plantOk())m*=0.9;if(this.onRug("kitchenMat"))m*=0.7;return m;};',
    'P.energyMul=function(){var m=1,kit=this.s.g.where!=="wash";if(this.musicOn())m*=kit?0.8:0.9;if(kit&&this.plantOk())m*=0.9;if(this.onRug("kitchenMat"))m*=0.7;if(this.placed("aquarium"))m*=0.95;if(!kit&&this.placed("towelRack")&&this.hasKey())m*=0.85;return m;};')
rep('P.hungerMul=function(){return this.onRug("rug")?0.8:1;};',
    'P.hungerMul=function(){var m=this.onRug("rug")?0.8:1;if(this.placed("fruitBowl")&&this.s.g.where!=="wash")m*=0.9;if(this.placed("aquarium"))m*=0.95;return m;};')
rep('P.workMul=function(){var m=1;if(this.musicOn())m*=1.05;if(this.onRug("roundRug"))m*=1.08;return m;};',
    'P.workMul=function(){var m=1;if(this.musicOn())m*=1.05;if(this.onRug("roundRug"))m*=1.08;\n'
    '    if(this.placed("window")&&this.isDay())m*=1.04;if(this.placed("stringLights")&&!this.isDay())m*=1.04;\n'
    '    if(this.placed("trophyShelf"))m*=1+0.01*this.trophies();if(this.placed("statue"))m*=1.05;\n'
    '    return m*this.moodMul();};\n'
    '  P.washWalk=function(){return (this.placed("mopBucket")&&this.hasKey())?1.10:1;};\n'
    '  P.pullMul=function(){return (this.duckOn()?1.25:1)*((this.placed("soap")&&this.hasKey())?1.15:1);};\n'
    '  P.flowMul=function(){return this.basinOn("toyBoat")?1.15:1;};')
rep('add("tvArmchair",this.placed("tvArmchair")&&this.s.box.tv>0,"TV: watch for energy");',
'''add("tvArmchair",this.placed("tvArmchair")&&this.s.box.tv>0,"TV: watch for energy");
    add("window",this.placed("window")&&this.isDay(),"WINDOW: work +4% (daytime)");
    add("stringLights",this.placed("stringLights")&&!this.isDay(),"STRING LIGHTS: work +4% (night)");
    add("spiceRack",this.placed("spiceRack"),"SPICE RACK: meals +10 hunger");
    add("coatHook",this.placed("coatHook"),"APRON: QUICK = 4 peels");
    add("calendar",this.placed("calendar"),"CALENDAR: 10c payday each shift day");
    add("potsPans",this.placed("potsPans"),"POTS + PANS: food -1c");
    add("photos",this.placed("photos"),"PHOTOS: lazy only under 20%");
    add("neonSign",this.placed("neonSign"),"NEON: +1c tip every 20th ship");
    add("trophyShelf",this.placed("trophyShelf"),"TROPHIES: work +"+this.trophies()+"%");
    add("sideTable",this.placed("sideTable"),"SIDE TABLE: 2 table-top slots");
    add("compost",this.placed("compost"),"COMPOST: sweep +25%, 1c per 20 peels");
    add("sackPile",this.placed("sackPile"),"SACKS: grab +20%");
    add("bookshelf",this.placed("bookshelf"),"BOOKS: level -10%");
    add("catBed",this.placed("catBed"),"CAT: naps +10%");
    add("statue",this.placed("statue"),"STATUE: work +5%");
    add("fruitBowl",this.placed("fruitBowl")&&this.s.g.where!=="wash","FRUIT: hunger -10% (kitchen)");
    add("cookbook",this.placed("cookbook"),"COOKBOOK: NEAT at 90%");
    add("aquarium",this.placed("aquarium"),"AQUARIUM: hunger + energy -5%");
    add("towelRack",this.placed("towelRack")&&this.hasKey()&&this.s.g.where==="wash","TOWELS: energy -15% (wash room)");
    add("soap",this.placed("soap")&&this.hasKey(),"SOAP: basin pull +15%");
    add("mopBucket",this.placed("mopBucket")&&this.hasKey(),"MOP: wash-room walk +10%");
    add("toyBoat",this.basinOn("toyBoat"),"BOAT: current +15%");
    add("bubbles",this.basinOn("bubbles"),"BUBBLES: sloppy wash pay 3c");
    add("wallpaper",false,"WALLPAPER: cosmetic");add("floorTiles",false,"FLOOR TILES: cosmetic");''')
rep('P.sweepRate=function(){return C.sweepRate*(1+0.5*this.up("broom"));};','P.sweepRate=function(){return C.sweepRate*(1+0.5*this.up("broom"))*(this.placed("compost")?1.25:1);};')
rep('P.napRegen=function(){return C.napRegen*(1+0.35*this.up("mat"));};','P.napRegen=function(){return C.napRegen*(1+0.35*this.up("mat"))*(this.placed("catBed")?1.10:1);};')
rep('var hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<C.lazyLow);\n    var energyUnmet=napThr>0?false:(s.energy<C.lazyLow);',
    'var LL=this.lazyLow(),hungerUnmet=(eatThr>0)?(s.hunger<eatThr&&s.food<=0):(s.hunger<LL);\n    var energyUnmet=napThr>0?false:(s.energy<LL);')
# step: grab, peel, meal, rinse
rep('case "grab":a.e+=dt*wk;if(a.e>=C.grab){\n          if(s.pile<=0){a.e=C.grab;','case "grab":a.e+=dt*wk;if(a.e>=this.grabTime()){\n          if(s.pile<=0){a.e=this.grabTime();')
rep('var np=(g.sloppy?C.peelPerSloppy:STYLE[s.box.style].peels)*nHold;','var np=(g.sloppy?C.peelPerSloppy:this.peelsPer())*nHold;\n        s.hyg=Math.max(0,this.hyg()-2.0*dt*wk);')
rep('s.hunger=Math.min(100,s.hunger+C.meal);','s.hunger=Math.min(100,s.hunger+this.mealGain());')
rep('''      case "tune":{
        a.e+=dt;if(a.e>=1.8){if(s.decor)s.decor.radioTune=s.t;this.decide();}break;}''','''      case "tune":{
        a.e+=dt;if(a.e>=1.8){if(s.decor)s.decor.radioTune=s.t;this.decide();}break;}
      case "rinse":{   /* 0.4.11: at the table sink, right where he peels */
        a.e+=dt*sp;if(a.e>=1.0){s.hyg=100;s.stats.rinses=(s.stats.rinses|0)+1;this.emit({k:"rinse"});if(g.hold==="raw")this.startAt("peel");else this.decide();}break;}''')
rep('''      g.tmiss=0;g.job="peel";g.dir=SPOT.table.dir;''','''      g.tmiss=0;g.job="peel";g.dir=SPOT.table.dir;
      if(this.wantRinse()&&!g.lazy){g.act={t:"rinse",e:0,label:"rinsing his hands at the table sink"};return;}''')
rep("var ok={walk:1,wwalk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1,wash:1,watch:1,water:1,tune:1,scoop:1,dumpPool:1,wdump:1};",
    "var ok={walk:1,wwalk:1,grab:1,peel:1,drop:1,eat:1,nap:1,lazynap:1,idle:1,sweep:1,wash:1,watch:1,water:1,tune:1,scoop:1,dumpPool:1,wdump:1,rinse:1};")
rep('''var spot=a.t==="peel"?SPOT.table:''','''var spot=(a.t==="peel"||a.t==="rinse")?SPOT.table:''')
rep('''    if(a.t==="tune"||(a.t==="walk"&&a.then==="tune"))return "TUNING";''','''    if(a.t==="tune"||(a.t==="walk"&&a.then==="tune"))return "TUNING";
    if(a.t==="rinse")return "PEELING";''')
# level price
rep('P.levelPrice=function(){var n=this.s.level+1;if(n>5)return null;return LEVEL_PRICE[n];};',
    'P.levelPrice=function(){var n=this.s.level+1;if(n>5)return null;return this.placed("bookshelf")?Math.round(LEVEL_PRICE[n]*0.9):LEVEL_PRICE[n];};')
# coins: neon tip + bubbles in ship functions
rep('''    var v=shipPay(p);
    s.chute++;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;''','''    var v=shipPay(p)+this.neonTip();
    s.chute++;s.coins+=v;s.stats.earned+=v;s.stats.peeled++;''')
rep('''    var s=this.s,v=shipPay(p);
    if(s.chute>=this.chuteCap()&&!s.suck)this.startSuck();
    if(s.chute>=this.chuteCap())return false;   /* hold it until the pipe takes a batch */
    s.chute++;''','''    var s=this.s,v;
    if(s.chute>=this.chuteCap()&&!s.suck)this.startSuck();
    if(s.chute>=this.chuteCap())return false;   /* hold it until the pipe takes a batch */
    v=(p&&p.washed&&p.sloppy&&this.basinOn("bubbles"))?C.washValue:shipPay(p);v+=this.neonTip();
    s.chute++;''')
rep('''  P.decorStep=function(dt){
    var s=this.s;if(!s.decor)s.decor=decorFresh();''','''  P.neonTip=function(){var d=this.s.decor;if(!d||!this.placed("neonSign"))return 0;d.shipN=(d.shipN|0)+1;if(d.shipN>=20){d.shipN=0;d.tips=(d.tips|0)+1;this.emit({k:"tip"});return 1;}return 0;};
  P.decorStep=function(dt){
    var s=this.s;if(!s.decor)s.decor=decorFresh();
    /* 0.4.11 calendar payday: 10c at each new shift day while it hangs (no back pay for days before it went up) */
    var day=this.clockTime().day;if(!(s.decor.day>0))s.decor.day=day;
    if(day>s.decor.day){if(this.placed("calendar")){s.coins+=10;s.stats.earned+=10;s.decor.paydays=(s.decor.paydays|0)+1;this.emit({k:"payday"});}s.decor.day=day;}''')
rep('''    if(removed.length)s.stats.swept+=removed.length;''','''    if(removed.length){s.stats.swept+=removed.length;
      if(this.placed("compost")){var dc=s.decor||(s.decor=decorFresh());dc.compostN=(dc.compostN|0)+removed.length;while(dc.compostN>=20){dc.compostN-=20;s.coins+=1;s.stats.earned+=1;dc.compost=(dc.compost|0)+1;}}}''')
rep('w.pullAcc=(w.pullAcc||0)+heapPullRate(up)*(this.duckOn()?1.25:1)*dt;','w.pullAcc=(w.pullAcc||0)+heapPullRate(up)*this.pullMul()*dt;')
rep('reach=currentReach(up),flow=streetFlow(up),hit','reach=currentReach(up),flow=streetFlow(up)*this.flowMul(),hit')
rep('dx=a.x-g.wx;dy=a.y-g.wy;d=Math.sqrt(dx*dx+dy*dy);mv=C.walk*wsp*this.walkMul()*dt;','dx=a.x-g.wx;dy=a.y-g.wy;d=Math.sqrt(dx*dx+dy*dy);mv=C.walk*wsp*this.walkMul()*this.washWalk()*dt;')
# decorFresh
rep('function decorFresh(){return {lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0,radioSt:0,radioVol:6,radioNear:1};}',
    'function decorFresh(){return {lamp:0,radio:0,tv:0,plant:0,plantT:0,radioTune:0,radioSt:0,radioVol:6,radioNear:1,day:0,paydays:0,shipN:0,tips:0,compostN:0,compost:0};}')
# fresh v13
rep('return {v:12,seed:seed,rs:0,rr:seed|0,t:0,level:1,duckIn:0,','return {v:13,seed:seed,rs:0,rr:seed|0,t:0,level:1,duckIn:0,hyg:100,basin:{},theme:{wall:0,floor:0},')
rep('P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];o.v=12;return JSON.stringify(o);};',
    'P.serialize=function(){var s=this.s;var o=JSON.parse(JSON.stringify(s));o.ev=[];o.v=13;return JSON.stringify(o);};')
rep('''    o.duckIn=o.duckIn&&o.owned&&o.owned.duck?1:0;
  }''','''    o.duckIn=o.duckIn&&o.owned&&o.owned.duck?1:0;
  }
  function ensure13(o){
    ensure12(o);o.v=13;
    var h=+o.hyg;o.hyg=isFinite(h)?Math.max(0,Math.min(100,h)):100;
    if(!o.basin||typeof o.basin!=="object")o.basin={};var b2={};for(var i=0;i<BASIN.length;i++)if(BASIN[i]!=="duck"&&o.basin[BASIN[i]]&&o.owned&&o.owned[BASIN[i]])b2[BASIN[i]]=1;o.basin=b2;
    if(!o.theme||typeof o.theme!=="object")o.theme={wall:0,floor:0};
    o.theme={wall:((Math.floor(+o.theme.wall)||0)%4+4)%4,floor:((Math.floor(+o.theme.floor)||0)%4+4)%4};
    if(o.box&&typeof o.box.rinse!=="number")o.box.rinse=BOX.rinse.def;
    if(o.placeWash&&typeof o.placeWash==="object"){for(var k in o.placeWash){var q=o.placeWash[k];if(!q||typeof q!=="object"||!isFinite(+q.x)||!isFinite(+q.y))delete o.placeWash[k];}}
  }''')
rep("o.v!==11&&o.v!==12)||typeof o.coins","o.v!==11&&o.v!==12&&o.v!==13)||typeof o.coins")
rep("var old=o.v<3,from1=o.v===1,from3=o.v===3;ensure12(o);","var old=o.v<3,from1=o.v===1,from3=o.v===3;ensure13(o);")
rep("/* accepts a 0.4.10 save (v:12),","/* accepts a 0.4.11 save (v:13), a 0.4.10 save (v:12),")
rep("Sim.RUGS=RUGS;Sim.WALLS=WALLS;","Sim.RUGS=RUGS;Sim.WALLS=WALLS;Sim.TOPS=TOPS;Sim.WASHW=WASHW;Sim.WASHF=WASHF;Sim.BASIN=BASIN;Sim.FLOOR11=FLOOR11;Sim.THEMES=THEMES;Sim.isTop=isTop;Sim.isWashItem=isWashItem;Sim.isWashWall=isWashWall;Sim.isBasin=isBasin;")
open(P,'w').write(s)
print("ok part2")
