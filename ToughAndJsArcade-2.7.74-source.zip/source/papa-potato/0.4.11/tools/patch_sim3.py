import sys
P='/workspace/game/build-potato0411/src/sim.js'
s=open(P).read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit("count %d != %d for: %s"%(n,cnt,a[:90]))
    s=s.replace(a,b)
rep('P.placed=function(id){return this.owned(id)&&!!(this.s.place&&this.s.place[id]);};',
    'P.placed=function(id){if(!this.owned(id))return false;if(isWashItem(id))return !!(this.s.placeWash&&this.s.placeWash[id]);return !!(this.s.place&&this.s.place[id]);};')
rep('P.placeOf=function(id){var p=(this.s.place&&this.s.place[id])||defaultPlace(id);return p;};',
    'P.placeOf=function(id){if(isWashItem(id))return (this.s.placeWash&&this.s.placeWash[id])||WDEF[id];var p=(this.s.place&&this.s.place[id])||defaultPlace(id);return p;};')
rep('''  function decorFresh(){''','''  var WDEF={towelRack:{x:70,y:3.5,r:0},soap:{x:3.5,y:120,r:3},mopBucket:{x:22,y:210}};   /* 0.4.11 wash-room decor defaults (top half is fine for PLAYER-placed decor; t1187 only bans default props) */
  function decorFresh(){''')
# placeItem dispatch
rep('''    if(isWall(id)){var wsp=this.wallSnap(id,x,y);''','''    if(isWashItem(id))return this.placeWashItem(id,x,y);
    if(isTop(id))return this.placeTop(id,x,y);
    if(isWall(id)){var wsp=this.wallSnap(id,x,y);''')
rep('''  P.unplace=function(id){if(!isPlaceable(id)||!this.placed(id))return "bad";
    delete this.s.place[id];''','''  P.unplace=function(id){if(!isPlaceable(id)||!this.placed(id))return "bad";
    if(isWashItem(id)){delete this.s.placeWash[id];this.poke();return "ok";}
    delete this.s.place[id];''')
rep('''  P.trayList=function(){var out=[],i,it;
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(isPlaceable(it.id)&&this.owned(it.id)&&!this.placed(it.id))out.push({id:it.id,name:it.name});}
    return out;};''','''  P.trayList=function(room){var out=[],i,it;room=room||"any";
    for(i=0;i<ITEMS.length;i++){it=ITEMS[i];if(!(isPlaceable(it.id)&&this.owned(it.id)&&!this.placed(it.id)))continue;
      if(room==="wash"&&!isWashItem(it.id))continue;if(room==="kitchen"&&isWashItem(it.id))continue;
      out.push({id:it.id,name:it.name,cat:isWashItem(it.id)?"wash":(it.cat||"floor")});}
    return out;};
  /* ---- 0.4.11 TABLE-TOP slots: 2 on the side table, 1 on the food cooler lid ---- */
  P.topSlots=function(){var o=[],p,r,a,b;
    if(this.placed("sideTable")){p=this.placeOf("sideTable");r=(p.r|0)&3;a=rot(-3.4,-0.4,r);b=rot(3.4,-0.4,r);o.push({on:"sideTable",slot:0,x:p.x+a[0],y:p.y+a[1]});o.push({on:"sideTable",slot:1,x:p.x+b[0],y:p.y+b[1]});}
    var K=GEO.cooler;o.push({on:"cooler",slot:0,x:(K.x0+K.x1)/2,y:(K.y0+K.y1)/2-0.6});
    return o;};
  P.topOwner=function(on,slot,skip){var pl=this.s.place||{},i,q;for(i=0;i<TOPS.length;i++){if(TOPS[i]===skip)continue;q=pl[TOPS[i]];if(q&&this.owned(TOPS[i])&&q.on===on&&(q.slot|0)===slot)return TOPS[i];}return null;};
  P.syncTops=function(){var pl=this.s.place||{},sl=this.topSlots(),i,j,q,f;
    for(i=0;i<TOPS.length;i++){q=pl[TOPS[i]];if(!q)continue;f=null;for(j=0;j<sl.length;j++)if(sl[j].on===q.on&&sl[j].slot===(q.slot|0)){f=sl[j];break;}
      if(!f){delete pl[TOPS[i]];continue;}   /* its surface was put away: back to the inventory */
      q.x=f.x;q.y=f.y;}};
  P.placeTop=function(id,x,y){if(!isTop(id)||!this.owned(id))return "bad";var sl=this.topSlots(),best=null,bd=1e9,i,d;
    for(i=0;i<sl.length;i++){if(this.topOwner(sl[i].on,sl[i].slot,id))continue;d=Math.hypot(sl[i].x-x,sl[i].y-y);if(d<bd){bd=d;best=sl[i];}}
    if(!best)return "blocked";if(!this.s.place)this.s.place={};this.s.place[id]={x:best.x,y:best.y,on:best.on,slot:best.slot};this.poke();return "ok";};
  /* ---- 0.4.11 WASH-ROOM decor: wall items on the north wall (off the door and ship opening) or the west wall; floor items off the basin, canal, outlet, door and his walk lanes ---- */
  P.fitsWashWall=function(id,x,y,r){r=(r|0)&3;var f=this.footOf(id,x,y,r),W=GEO.WALL,D=WASH.door,h=WASH.hole,i,q,f2;
    if(r===0){if(Math.abs(y-W/2)>0.01)return false;if(f.x0<W+1||f.x1>WW-W-1)return false;if(f.x1>D.x0-2&&f.x0<D.x0+D.w+2)return false;if(f.x1>h.x-h.w/2-4)return false;}
    else if(r===3){if(Math.abs(x-W/2)>0.01)return false;if(f.y0<W+2||f.y1>WH-W-2)return false;}
    else return false;
    for(i=0;i<WASHW.length;i++){if(WASHW[i]===id||!this.placed(WASHW[i]))continue;q=this.placeOf(WASHW[i]);f2=this.footOf(WASHW[i],q.x,q.y,q.r|0);if(f.x0<f2.x1+1&&f.x1>f2.x0-1&&f.y0<f2.y1+1&&f.y1>f2.y0-1)return false;}
    return true;};
  P.washWallSnap=function(id,x,y){var W=GEO.WALL,walls=[{r:0,d:Math.abs(y)},{r:3,d:Math.abs(x)}],i,j,o,px,py;walls.sort(function(a1,b1){return a1.d-b1.d;});
    for(i=0;i<walls.length;i++){var r=walls[i].r;for(j=0;j<=800;j++){o=(j&1?1:-1)*Math.ceil(j/2);if(r===0){px=x+o;py=W/2;}else{px=W/2;py=y+o;}if(this.fitsWashWall(id,px,py,r))return {x:px,y:py,r:r};}}
    return null;};
  P.washLanes=function(){var d=WASH.doorSpot,L=WASH.land;return [{x0:d.x,y0:d.y,x1:L.x-18,y1:L.y-2},{x0:d.x,y0:d.y,x1:L.x,y1:L.y-L.ry},{x0:d.x,y0:d.y,x1:L.x+L.rx,y1:L.y},{x0:d.x,y0:d.y,x1:L.x-L.rx,y1:L.y}];};
  P.fitsWashFloor=function(id,x,y){if(!this.fitsWash(id,x,y))return false;var f=this.footOf(id,x,y,0),ln=this.washLanes(),i,c,q,f2;
    for(i=0;i<ln.length;i++){c=distToSeg(x,y,ln[i]);if(c.d<Math.max(f.hx,f.hy)+9)return false;}   /* he walks the door-to-basin lanes in straight lines: never in his way */
    for(i=0;i<WASHF.length;i++){if(WASHF[i]===id||!this.placed(WASHF[i]))continue;q=this.placeOf(WASHF[i]);f2=this.footOf(WASHF[i],q.x,q.y,0);if(f.x0<f2.x1+1&&f.x1>f2.x0-1&&f.y0<f2.y1+1&&f.y1>f2.y0-1)return false;}
    return true;};
  P.placeWashItem=function(id,x,y){if(!isWashItem(id)||!this.owned(id))return "bad";if(!this.hasKey())return "nokey";
    if(x==null||y==null||!isFinite(+x)||!isFinite(+y)){var d0=WDEF[id];x=d0.x;y=d0.y;}x=+x;y=+y;
    if(!this.s.placeWash)this.s.placeWash={};
    if(isWashWall(id)){var sn=this.washWallSnap(id,x,y);if(!sn)return "blocked";this.s.placeWash[id]={x:sn.x,y:sn.y,r:sn.r};this.poke();return "ok";}
    var ra,i2,a2,px,py;for(ra=0;ra<=120;ra+=3){var nA=ra?Math.max(8,Math.round(ra*0.7)):1;for(i2=0;i2<nA;i2++){a2=i2*2*Math.PI/nA;px=x+Math.cos(a2)*ra;py=y+Math.sin(a2)*ra;
      if(this.fitsWashFloor(id,px,py)){this.s.placeWash[id]={x:px,y:py};this.poke();return "ok";}}}
    return "blocked";};''')
# FOOT
rep('kitchenMat:[9,6],runner:[6,20],roundRug:[11,11],clock:[4,3.5],poster:[5,3.5],fan:[5,5],shelf:[10,4]};',
    'kitchenMat:[9,6],runner:[6,20],roundRug:[11,11],clock:[4,3.5],poster:[5,3.5],fan:[5,5],shelf:[10,4],\n'
    '    window:[7,3.5],spiceRack:[5,3.5],coatHook:[3.5,3.5],calendar:[3.5,3.5],potsPans:[7,3.5],photos:[6,3.5],stringLights:[12,3.5],neonSign:[7,3.5],trophyShelf:[8,3.5],\n'
    '    sideTable:[7,5],compost:[5,5],sackPile:[8,6],bookshelf:[10,4],catBed:[6,5],statue:[5,5],fruitBowl:[3,3],cookbook:[3,3],aquarium:[3.2,2.6],towelRack:[6,3.5],soap:[3,3.5],mopBucket:[5,5]};')
# moveItem dispatch
rep('''    var key=id==="bed"?"mat":id,r=this.rotOf(key);
    if(isWall(key)){''','''    var key=id==="bed"?"mat":id,r=this.rotOf(key);
    if(isWashItem(key)){if(isWashWall(key)){var ww=this.washWallSnap(key,x,y);if(!ww)return false;this.s.placeWash[key]={x:ww.x,y:ww.y,r:ww.r};return true;}
      if(!this.fitsWashFloor(key,x,y))return false;this.s.placeWash[key]={x:x,y:y};return true;}
    if(isTop(key)){var old=this.s.place[key];var rr=this.placeTop(key,x,y);return rr==="ok";}
    if(isWall(key)){''')
rep('''    if(isWall(id))return false;   /* 0.4.10: wall items turn with the wall they hang on; drag them to another wall */''',
    '''    if(isWall(id)||isTop(id)||isWashItem(id))return false;   /* wall items turn with the wall they hang on; table-tops sit in a slot; wash decor stays upright */''')
rep('''    add.call(this,"shelf",10,4);''','''    add.call(this,"shelf",10,4);
    for(var fi=0;fi<FLOOR11.length;fi++){var ff=FOOT[FLOOR11[fi]];add.call(this,FLOOR11[fi],ff[0],ff[1]);}   /* 0.4.11 floor decor blocks walking */''')
rep('''    if(this.placed("basicCot")){ct=this.placeOf("basicCot");SPOT.cot.x=ct.x;SPOT.cot.y=ct.y+14;}
  };''','''    if(this.placed("basicCot")){ct=this.placeOf("basicCot");SPOT.cot.x=ct.x;SPOT.cot.y=ct.y+14;}
    this.syncTops();
  };''')
open(P,'w').write(s)
print("ok part3")
