import sys
P='/workspace/game/build-potato0411/src/game.js'
s=open(P).read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit("count %d != %d for: %s"%(n,cnt,a[:100]))
    s=s.replace(a,b)
rep('/* ===== Papa Potato 0.4.10 — renderer (0.4.10:','/* ===== Papa Potato 0.4.11 — renderer (0.4.11: 24 new decor items + tabbed editor tray, wash-room decor, table sink, mood, themes). Save v13, loads v1-v12. Was 0.4.10 (0.4.10:')
rep('var SAVE_KEY="papaPotato.save.v12",KEY_V11=','var SAVE_KEY="papaPotato.save.v13",KEY_V12="papaPotato.save.v12",KEY_V11=')
rep('''  if(!s){try{var o11=localStorage.getItem(KEY_V11);''','''  if(!s){try{var o12=localStorage.getItem(KEY_V12);if(o12){s=PPSim.load(o12);if(s)migrated="0.4.10";}}catch(e){}}
  if(!s){try{var o11=localStorage.getItem(KEY_V11);''')
rep('version:"0.4.10",','version:"0.4.11",')
# theme floor + walls
rep('''  R(ix,iy,fw,fh,"#9a947c");var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,"#8e876e");}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?"#7a7460":"#a8a288");}
  ctx.strokeStyle="rgba(60,55,40,0.28)";''','''  var FT=FLOOR_THEMES[(!viewIsWash()&&sim.theme)?sim.theme().floor:0]||FLOOR_THEMES[0];
  R(ix,iy,fw,fh,FT.a);var step=Math.max(5,ws(6));var ox=ix-((ix%step)+step)%step,oy=iy-((iy%step)+step)%step;
  if(FT.plank){var ph=Math.max(4,ws(4));for(var py=iy,rw=0;py<iy+fh;py+=ph,rw++){R(ix,py,fw,1,FT.line);var off=(rw%3)*Math.round(step*1.7);for(var px=ix-off;px<ix+fw;px+=step*5){if(px>ix)R(px,py,1,ph,FT.line);}if(rw%2)R(ix,py+1,fw,Math.max(1,ph-2),FT.b);}}
  else for(var y=oy;y<iy+fh;y+=step)for(var x=ox;x<ix+fw;x+=step){if(x+1>=ix&&y+1>=iy){var cw=Math.min(step,ix+fw-x),ch=Math.min(step,iy+fh-y);if((((x-ox)+(y-oy))/step)%2===0)R(x,y,cw,ch,FT.b);}}
  for(var i=0;i<130;i++){R(ix+((i*73)%Math.max(2,fw)),iy+((i*47)%Math.max(2,fh)),1,1,i%3===0?FT.s1:FT.s2);}
  ctx.strokeStyle=FT.plank?"rgba(0,0,0,0)":FT.grid;''')
rep('''function drawWalls(){var x0=wx(0),y0=wy(0),x1=wx(roomW),y1=wy(roomH);var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);
  R(x0,y0,x1-x0,iy-y0,"#3a3830");R(x0,iy2,x1-x0,y1-iy2,"#3a3830");R(x0,iy,ix-x0,iy2-iy,"#3a3830");R(ix2,iy,x1-ix2,iy2-iy,"#3a3830");''','''/* 0.4.11 cosmetic themes (kitchen only; index 0 = the original look) */
var FLOOR_THEMES=[{a:"#9a947c",b:"#8e876e",s1:"#7a7460",s2:"#a8a288",grid:"rgba(60,55,40,0.28)"},
  {a:"#e4e0d4",b:"#3a3a3e",s1:"#c8c4b8",s2:"#f4f0e8",grid:"rgba(20,20,20,0.30)"},
  {a:"#b8663e",b:"#a85a34",s1:"#8a4426",s2:"#cc7a50",grid:"rgba(250,230,200,0.30)"},
  {a:"#a8784a",b:"#9a6c40",s1:"#7a522c",s2:"#c08e5c",line:"#6a4626",plank:true}];
var WALL_THEMES=[{w:"#3a3830",b1:"#4a4638",b2:"#323028",hi:"#5a5648"},
  {w:"#5a8a78",b1:"#7ab09a",b2:"#4a7a68",hi:"#9ad0b8",stripe:true},
  {w:"#a86a72",b1:"#c88a90",b2:"#985a62",hi:"#e0aab0"},
  {w:"#2e3c5a",b1:"#44587e",b2:"#26324c",hi:"#6a80a8"}];
function drawWalls(){var x0=wx(0),y0=wy(0),x1=wx(roomW),y1=wy(roomH);var ix=wx(WALL),iy=wy(WALL),ix2=wx(roomW-WALL),iy2=wy(roomH-WALL);
  var WT=WALL_THEMES[(!viewIsWash()&&sim.theme)?sim.theme().wall:0]||WALL_THEMES[0];
  R(x0,y0,x1-x0,iy-y0,WT.w);R(x0,iy2,x1-x0,y1-iy2,WT.w);R(x0,iy,ix-x0,iy2-iy,WT.w);R(ix2,iy,x1-ix2,iy2-iy,WT.w);''')
rep('''    R(bx,by,bs,Math.max(2,ws(2.2)),(i%3===0)?"#4a4638":"#323028");}
  R(ix,iy,ix2-ix,1,"#5a5648");''','''    R(bx,by,bs,Math.max(2,ws(2.2)),(i%3===0)?WT.b1:WT.b2);}
  if(WT.stripe){var sp2=Math.max(4,ws(4));for(var sx2=x0+t;sx2<x1-t;sx2+=sp2*2)R(sx2,y0+t,Math.max(1,ws(1.4)),iy-y0-t,WT.b1);for(var sy2=iy;sy2<iy2;sy2+=sp2*2){R(x0+t,sy2,ix-x0-t,Math.max(1,ws(1.4)),WT.b1);R(ix2,sy2,x1-ix2-t,Math.max(1,ws(1.4)),WT.b1);}}
  R(ix,iy,ix2-ix,1,WT.hi);''')
# static layer: new decor
rep('''  drawBedR(drawBed);drawRectR(GEO.table,drawTable2);drawRectR(GEO.cooler,drawCooler2);drawStool();drawReturnChute();}''',
    '''  drawBedR(drawBed);drawRectR(GEO.table,drawTable2);drawRectR(GEO.cooler,drawCooler2);drawStool();drawReturnChute();
  drawDecorStatic11();}''')
rep('''function drawWashStatic(){
  var P=WASH.pile;
  drawDoor();''','''function drawWashStatic(){
  var P=WASH.pile;
  drawDoor();
  drawWashDecor11();   /* 0.4.11 player-placed wash decor (no default props: t1187) */''')
rep('''  drawDuckWash();
  if(sim.s.g.where==="wash")drawGuy(now);''','''  drawDuckWash();drawBasin11();
  if(sim.s.g.where==="wash")drawGuy(now);''')
# dynamic kitchen items
rep('''  if(sim.placed("shelf"))RD("shelf","on",{n:Math.min(5,sim.s.food)});''','''  drawDecorLive11(S,RD,a);
  if(sim.placed("shelf"))RD("shelf","on",{n:Math.min(5,sim.s.food)});''')
# helpers block after drawDuckWash def
rep('''function drawDuckWash(){if(!sim.duckOn())return;var S=bindSprites();if(!S)return;var d=duckPos(RT||0);S.draw("duck","on",d.x,d.y,{dir:d.dir});}''',
'''function drawDuckWash(){if(!sim.duckOn())return;var S=bindSprites();if(!S)return;var d=duckPos(RT||0);S.draw("duck","on",d.x,d.y,{dir:d.dir});}
/* ---------- 0.4.11 decor drawing ---------- */
var STATIC11=["window","spiceRack","coatHook","calendar","potsPans","photos","trophyShelf","sideTable","compost","sackPile","bookshelf","catBed","statue","fruitBowl","cookbook"];
var LIVE11=["stringLights","neonSign","aquarium"];
function decorOpt11(id){var t=sim.clockTime();if(id==="window")return {day:sim.isDay()};if(id==="calendar")return {day:t.day};if(id==="stringLights")return {night:!sim.isDay()};
  if(id==="trophyShelf"){var n=sim.trophies();return {n:n,gold:n-Math.max(1,Math.min(5,sim.s.level|0))};}return {};}
function decorKey11(){var t=sim.theme?sim.theme():{wall:0,floor:0};return [sim.isDay()?1:0,sim.placed("calendar")?sim.clockTime().day:0,sim.placed("trophyShelf")?sim.trophies():0,t.wall,t.floor].join(",");}
function drawDecorStatic11(){var S=bindSprites();if(!S||!S.register)return;var i,id,p;
  for(i=0;i<STATIC11.length;i++){id=STATIC11[i];if(!sim.placed(id))continue;p=itemXY(id);
    (function(id,p){var o=decorOpt11(id);if(PPSim.isTop(id)){S.draw(id,"on",p.x,p.y,o);return;}rotWrap(p.x,p.y,p.r,function(){S.draw(id,"on",p.x,p.y,o);});})(id,p);}}
function drawDecorLive11(S,RD,a){if(!S.register)return;var i,id;
  for(i=0;i<LIVE11.length;i++){id=LIVE11[i];if(!sim.placed(id))continue;if(PPSim.isTop(id)){var q=itemXY(id);S.draw(id,"on",q.x,q.y,decorOpt11(id));}else RD(id,"on",decorOpt11(id));}
  if(a&&a.t==="rinse")drawTableSink(PPSim.tableKids().sink,true);
  if(sim.placed("catBed"))drawCat11(S);}
function drawWashDecor11(){var S=bindSprites();if(!S||!S.register||!sim.hasKey())return;var ids=PPSim.WASHW.concat(PPSim.WASHF),i;
  for(i=0;i<ids.length;i++)(function(id){if(!sim.placed(id))return;var p=sim.placeOf(id);rotWrap(p.x,p.y,p.r,function(){S.draw(id,"on",p.x,p.y);});})(ids[i]);}
function boatPos(t){var u=(t*0.035)%1,q=PPSim.pointAlongCanal(0.12+u*0.76);return {x:q.x,y:q.y};}
function drawBasin11(){var S=bindSprites();if(!S||!S.register)return;var L=WASH.land;
  if(sim.basinOn("bubbles"))S.draw("bubbles","on",L.x-L.rx*0.62,L.y+L.ry*0.30);
  if(sim.basinOn("toyBoat")){var b=boatPos(RT||0);S.draw("toyBoat","on",b.x,b.y);}}
/* the cat: renderer-only, wanders between free spots he can walk to, naps in its bed now and then (never blocks Papa) */
var CAT={x:null,y:null,path:[],wait:0,mode:"walk",dir:0,seed:7,last:0};
function catRand(){CAT.seed=(CAT.seed*1103515245+12345)&0x7fffffff;return CAT.seed/0x7fffffff;}
function catHome(){var p=sim.placeOf("catBed");return {x:p.x,y:p.y};}
function catStep(t){var dt=Math.min(0.1,Math.max(0,t-(CAT.last||t)));CAT.last=t;var h=catHome();
  if(CAT.x==null||!isFinite(CAT.x)){CAT.x=h.x;CAT.y=h.y;CAT.mode="sleep";CAT.wait=4;}
  if(CAT.mode==="sleep"){CAT.x=h.x;CAT.y=h.y;CAT.wait-=dt;if(CAT.wait<=0){CAT.mode="walk";CAT.path=[];}return;}
  if(CAT.mode==="sit"){CAT.wait-=dt;if(CAT.wait<=0){CAT.mode="walk";CAT.path=[];}return;}
  if(!CAT.path.length){var goHome=catRand()<0.25,tx,ty,k2;
    if(goHome){tx=h.x;ty=h.y+7;}else{for(k2=0;k2<12;k2++){tx=12+catRand()*(RW-24);ty=14+catRand()*(GEO.pile.base-30);if(PPSim.freePt(tx,ty))break;}}
    var r=PPSim.routeSafe(CAT.x,CAT.y,tx,ty)||[[tx,ty]];CAT.path=r.slice(0,24);CAT.home=goHome;if(!CAT.path.length){CAT.mode="sit";CAT.wait=2;return;}}
  var g=CAT.path[0],dx=g[0]-CAT.x,dy=g[1]-CAT.y,d=Math.hypot(dx,dy),mv=11*dt;
  if(d<=mv){CAT.x=g[0];CAT.y=g[1];CAT.path.shift();if(!CAT.path.length){if(CAT.home){CAT.mode="sleep";CAT.wait=8+catRand()*10;}else{CAT.mode="sit";CAT.wait=1.5+catRand()*3;}}}
  else{CAT.x+=dx/d*mv;CAT.y+=dy/d*mv;CAT.dir=Math.atan2(dy,dx);}}
function drawCat11(S){catStep(RT||0);if(CAT.mode==="sleep"){S.draw("cat","sleep",CAT.x,CAT.y+0.2,{});return;}S.draw("cat",CAT.mode==="walk"?"walk":"sit",CAT.x,CAT.y,{dir:CAT.dir});}''')
# static key check in drawScene
rep('''function drawScene(now){if(W<2||H<2)return;tickAnim(now);ensureStatic();''','''var decorKeyLast="";
function drawScene(now){if(W<2||H<2)return;tickAnim(now);if(!viewIsWash()){var dk=decorKey11();if(dk!==decorKeyLast){decorKeyLast=dk;staticLayer=null;kitLayer=null;}}ensureStatic();''')
# edit ids
rep('''var EDIT_IDS=["table","cooler","stool","mat","sink","smallCooler","basicCot","plant","lamp","radio","rug","tvArmchair","autoPeeler","fan","shelf","clock","poster","kitchenMat","runner","roundRug"];
var WASH_EDIT_IDS=[]; /* 0.4.8: basin heap stays with the basin; dry pile is hidden, not draggable */''',
'''var EDIT_IDS=["fruitBowl","cookbook","aquarium","table","cooler","stool","mat","sink","smallCooler","basicCot","plant","lamp","radio","rug","tvArmchair","autoPeeler","fan","shelf","clock","poster","kitchenMat","runner","roundRug",
  "window","spiceRack","coatHook","calendar","potsPans","photos","stringLights","neonSign","trophyShelf","sideTable","compost","sackPile","bookshelf","catBed","statue"];
var WASH_EDIT_IDS=["towelRack","soap","mopBucket"]; /* 0.4.11 player wash decor. The basin heap stays with the basin; dry pile is hidden, not draggable */''')
rep('''    if(!viewIsWash()&&["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    ctx.strokeStyle''','''    if(["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    ctx.strokeStyle''')
rep('''    if(!viewIsWash()&&["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    if(wx0>=''','''    if(["table","cooler","stool","mat"].indexOf(id)<0&&!sim.placed(id))continue;
    f=editRect(id);if(!f)continue;
    if(wx0>=''')
rep('''ctx.fillText("EDITOR: the basin heap, machines, canal and ship opening stay put.",8,16);''','''ctx.fillText("EDITOR: drag your wash decor. Basin, machines, canal stay put.",8,16);''')
# table-top strict hit first: hitEditItem prefers strict & nearest — tops listed first is fine.
open(P,'w').write(s)
print("ok g1")
