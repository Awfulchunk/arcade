import sys; sys.path.insert(0,'/workspace/game/build-pixelwar041/patch')
from lib import E
e=E()
# ---------------- CSS
e.ed(".shb{flex:1;min-width:0;margin:0;padding:0 1px;",".shb{flex:1 0 54px;min-width:54px;margin:0;padding:0 1px;")
e.ed("#shbtns{height:44px}","#shbtns{height:44px;overflow-x:auto;overflow-y:hidden;touch-action:pan-x;white-space:nowrap}")
e.ed("#result button{width:100%;margin-top:6px}","#rBody{height:146px;overflow-y:auto;touch-action:pan-y;padding-right:2px}\n#rBody p{margin:0 0 2px;font-size:11.5px;line-height:14px}\n#rBody b{color:#9aa4ff;font-weight:700}\n#result .rb{display:flex;margin-top:3px}#result .rb button{flex:1;width:auto;margin:0}#result .rb button+button{margin-left:6px}\n#edwrap{flex:1;min-height:0;position:relative;margin:0 10px}\n.edrow{display:flex;padding:4px 10px 0}.edrow button{flex:1;margin:0;min-height:44px}.edrow button+button{margin-left:6px}\n#edlist{display:flex;flex-wrap:wrap;padding:4px 10px 0}#edlist button{flex:0 0 31%;margin:0 2% 4px 0;font-size:11px}\n#edmsg{padding:2px 10px 0;font-size:11px;line-height:14px;color:#9aa4ff;min-height:14px}\n.stg{display:block;width:100%;text-align:left;margin:0 0 8px;min-height:62px;padding:4px 10px}.stg b{display:block;font-size:14px}.stg small{display:block;font-size:10px;line-height:12px;font-weight:500;color:#aab0e8}.stg.lock{opacity:.45}")
# ---------------- HTML
e.ed('<button id="tWall">WALL</button><button id="tErase">ERASE</button>','<button id="tWall">WALL</button><button id="tGate">GATE</button><button id="tErase">ERASE</button>')
e.ed('<button id="tStart" class="go" style="flex:2">START</button><button id="tSwap" style="display:none">P1/P2</button>','<button id="tStart" class="go" style="flex:2">START</button><button id="tSwap" style="display:none">P1/P2</button><button id="tLane" style="flex:2;margin-left:3px">LANE</button>')
e.ed('<div id="result"><h2 id="rTitle">-</h2><p id="rS1"></p><p id="rS2"></p><p id="rS3"></p><p id="rS4"></p><p id="rS5"></p><p id="rS6"></p><button id="btnAgain" class="go">PLAY AGAIN</button></div>','<div id="result"><h2 id="rTitle">-</h2><div id="rBody"></div><div class="rb"><button id="btnRev">AI REVIEW</button><button id="btnAgain" class="go">PLAY AGAIN</button></div></div>')
e.ed('<div class="view" id="menu"><h1>PIXEL WAR 0.3</h1><p class="sub">You vs the AI. Destroy the enemy circle with streams of pixels.</p>\n <div class="btns"><button id="mResume" class="go">RESUME</button><button id="mQuick">QUICK MATCH</button><button id="mCustom">CUSTOM GAME</button><button id="mHelp">HELP</button></div></div>',
 '<div class="view" id="menu"><h1>PIXEL WAR 0.4</h1><p class="sub">You vs the AI. Destroy the enemy circle with streams of pixels.</p>\n <div class="btns"><button id="mResume" class="go">RESUME</button><button id="mQuick">QUICK MATCH</button><button id="mStages">STAGES</button><button id="mCustom">CUSTOM GAME</button><button id="mForms">FORMATION EDITOR</button><button id="mHelp">HELP</button></div></div>\n<div class="view" id="stages"><h1>STAGES</h1><p class="sub">Four stages unlock the mechanics one step at a time. QUICK MATCH and CUSTOM GAME have everything.</p><div class="btns" id="stlist" style="flex:1;overflow-y:auto"></div><div class="btns" style="padding-top:0"><button id="stBack">BACK</button></div></div>\n<div class="view" id="editor"><h1>FORMATION EDITOR</h1><p class="sub">Tap or drag dots onto the grid; the top edge is the FRONT. Saved formations are shape abilities in the SHAPE tab (the AI designs its own).</p><div id="edwrap"><canvas id="edc"></canvas></div><div id="edmsg"></div><div id="edlist"></div>\n <div class="edrow"><button id="edClear">CLEAR</button><button id="edMirror">MIRROR ON</button><button id="edSave" class="go">SAVE</button><button id="edDel">DELETE</button></div><div class="btns" style="padding:4px 10px 6px"><button id="edBack" style="margin:0">BACK</button></div></div>')
e.ed("for(const id of['menu','custom','help'])$(id).style.display=id===v?'flex':'none';","for(const id of['menu','custom','help','stages','editor'])$(id).style.display=id===v?'flex':'none';")
# ---------------- render: lane overlay
t=e.t;i=t.index("  // lanes (faint yellow, flat");j=t.index("  // walls\n  ctx.lineWidth=Math.max(2,WALL_HALF*2*sc)")
e.t=t[:i]+"""  // LANE SHAPES: the hitbox area the pixels occupy, a subtle transparent overlay (flat fill + hairline edge, no blur)
  if(CFG.halo)for(const sd of S.sides){if(!showSide(sd))continue;const hw=laneHW(sd.set);
    for(const P of sd.paths){if(!P||P.p.length<4)continue;const pp=lanePoly(P,hw);ctx.save();ctx.translate(fx,fy);ctx.scale(sc,sc);
      ctx.fillStyle=P.id?'rgba(190,140,255,0.12)':'rgba(255,205,60,0.14)';ctx.fill(pp);ctx.lineWidth=1/sc;ctx.strokeStyle=P.id?'rgba(150,100,230,0.30)':'rgba(214,160,20,0.34)';ctx.stroke(pp);ctx.restore();}}
"""+e.t[j:]
e.ed("function showSide(sd){","""function lanePoly(P,hw){const p=P.p,n=p.length>>1,key=n+'|'+P.lane+'|'+hw.toFixed(1);if(P.pk===key)return P.pp;
  const pp=new Path2D(),L=Math.max(1,(n-1)*PSP),lx=new Array(n),ly=new Array(n),rx=new Array(n),ry=new Array(n);
  for(let k=0;k<n;k++){const a=k>0?k-1:0,b=k<n-1?k+1:n-1;let tx=p[b*2]-p[a*2],ty=p[b*2+1]-p[a*2+1];const tl=Math.hypot(tx,ty)||1;tx/=tl;ty/=tl;const w=hw*laneF(P.lane,k*PSP/L);lx[k]=p[k*2]-ty*w;ly[k]=p[k*2+1]+tx*w;rx[k]=p[k*2]+ty*w;ry[k]=p[k*2+1]-tx*w;}
  pp.moveTo(lx[0],ly[0]);for(let k=1;k<n;k++)pp.lineTo(lx[k],ly[k]);for(let k=n-1;k>=0;k--)pp.lineTo(rx[k],ry[k]);pp.closePath();P.pk=key;P.pp=pp;return pp;}
function showSide(sd){""")
# gates render
e.ed("if(!st.segs||!st.segs.length){ctx.strokeStyle='#000';","if(!st.segs||!st.segs.length){ctx.strokeStyle=st.gate?'#2f6bff':'#000';ctx.setLineDash(st.gate?[3*sc,3*sc]:[]);")
e.ed("ctx.strokeStyle=fl?'#e0261c':'rgb('+g+','+g+','+g+')';\n        ctx.beginPath();","if(sg.gate){ctx.setLineDash([3*sc,3*sc]);ctx.strokeStyle=fl?'#e0261c':(sg.side?'#d4402f':'#2f6bff');}else{ctx.setLineDash([]);ctx.strokeStyle=fl?'#e0261c':'rgb('+g+','+g+','+g+')';}\n        ctx.beginPath();")
e.ed("  // paths (main black, branches purple, thin) + formation markers","  ctx.setLineDash([]);\n  // paths (main black, branches purple, thin) + formation markers")
# ---------------- HUD: shape buttons + lane + tools + meter + results
e.ed("setT('tP','BR'+selP+' '+Math.max(0,Math.round(CFG.brMax-bu)));setW('mP',(CFG.brMax-bu)/CFG.brMax*100);}","setT('tP','BR'+selP+' '+Math.round(brLeft(me,sP)));setW('mP',brLeft(me,sP)/CFG.brMax*100);}")
e.ed("const toolOk={circle:prep,main:prep,branch:canBr(me)&&CFG.maxBr>0,wall:canWall(me),erase:canWall(me)||canBr(me)||prep};\n  for(const t of['circle','main','branch','wall','erase']){","const toolOk={circle:prep,main:prep,branch:canBr(me)&&CFG.maxBr>0,wall:canWall(me),gate:canWall(me)&&!!CFG.gate&&feat('gate'),erase:canWall(me)||canBr(me)||prep};\n  for(const t of['circle','main','branch','wall','gate','erase']){")
e.ed("setD('tStart',prep?'block':'none');","setD('tStart',prep?'block':'none');setT('tLane',(selP?'BR'+selP:'MAIN')+' '+LANES[(me.paths[selP]||me.paths[0]).lane|0]);")
e.ed("st=(S.paused?'PAUSED ':'BATTLE ')+fmtT(S.tick)+(S.ai&&S.ai.lessons.length?'  AI learned '+S.ai.lessons.length:'');","st=(S.paused?'PAUSED ':'BATTLE ')+fmtT(S.tick)+(CFG.stage?'  STAGE '+CFG.stage:'')+(S.ai&&S.ai.lessons.length?'  AI learned '+S.ai.lessons.length:'');")
t=e.t
i=t.index("  {const ids=[0,1,2,4,5,6];if(CFG.ring)ids.splice(3,0,3);const kk=ids.join();const h=$('shbtns');")
j=t.index("  setT('lAt','AT '+sP.sh.at)")
e.t=t[:i]+"""  {const ids=[];for(let t=0;t<NSH;t++)if(shapeOkS(me,t))ids.push(t);const lab=t=>t<7?SHN[t]:shName(me,t);const kk=ids.join()+'|'+ids.map(lab).join();const h=$('shbtns');
   if(h.dataset.k!==kk){h.dataset.k=kk;h.innerHTML='';for(const t of ids){const b=document.createElement('button');b.className='shb';b.id='shb'+t;const s1=document.createElement('span');s1.textContent=lab(t);const s2=document.createElement('span');s2.className='cdt';s2.textContent='-';const bar=document.createElement('i');b.appendChild(s1);b.appendChild(s2);b.appendChild(bar);b.addEventListener('click',()=>{if(S.phase!=='battle'){S.msg='Shapes are used in battle';return;}if(!useShape(ME,selP,t))S.msg=shapeLeft(ME,t)>0?lab(t)+' recharging':'Cannot form here';});h.appendChild(b);}}
   for(const t of ids){const b=$('shb'+t),left=S.phase==='battle'?shapeLeft(ME,t):0,tot=cdTicks(t),busy=!!sP.arm&&S.phase==='battle',txt=S.phase!=='battle'?'-':left>0?(left/60).toFixed(1)+'s':busy?'wait':'READY';
    const sp=b.children[1];if(sp.textContent!==txt)sp.textContent=txt;const w=S.phase!=='battle'?0:Math.round((1-left/tot)*100)+'%';if(b.children[2].style.width!==w)b.children[2].style.width=w;const cd=left>0||S.phase!=='battle';if(b.classList.contains('cd')!==cd)b.classList.toggle('cd',cd);}}
"""+e.t[j:]
t=e.t
i=t.index("  if(S.over){const a=me.stats,b=foe.stats;")
j=t.index("  const sl=[['sSp','speed']")
e.t=t[:i]+"""  if(S.over){setT('rTitle',st);const rk=S.tick+':'+revPane+':'+(S.aiReview?1:0);if(hudCache.rk!==rk){hudCache.rk=rk;renderResult();}
    setD('btnRev',S.aiReview?'block':'none');setT('btnRev',revPane?'STATS':'AI REVIEW');}else{hudCache.rk=null;revPane=!!S.aiReview;}
"""+e.t[j:]
e.ed("function wallsLeft(sd){","""let revPane=false;
// RESULT SCREEN: full stats table (you / foe) and, when the AI played, its match review (the AI's tactical memory is already wiped by then)
function resultLines(){const me=S.sides[0],foe=S.sides[1],a=me.stats,b=foe.stats,pct=s=>s.released?Math.round(100*(s.kills+s.circleDmg)/s.released):0,L=[];
  L.push(['Time',fmtT(S.tick)+'   pool you '+Math.max(0,me.pool)+' / foe '+Math.max(0,foe.pool)]);
  L.push(['Particles destroyed','you '+a.kills+' / foe '+b.kills]);
  L.push(['Interceptions','you '+a.intercepts+' / foe '+b.intercepts]);
  L.push(['Deployment efficiency','you '+pct(a)+'% / foe '+pct(b)+'  ('+a.released+' sent)']);
  L.push(['Circle hits','you '+a.circleDmg+' / foe '+b.circleDmg+'  (burned '+b.burned+' of foe pool)']);
  L.push(['Barrier damage','dealt '+a.wallDmg+' / '+b.wallDmg+', taken '+a.wallTaken+' / '+b.wallTaken+', walls broken '+a.wallsBroken+' / '+b.wallsBroken+', gate passes '+a.gatePass]);
  const f=[];for(let t=0;t<NSH;t++)if(a.shapeMade[t]>0)f.push([t,a.shapeMade[t],(a.shapeKill[t]+1)/(a.shapeLoss[t]+1)]);f.sort((x,y)=>y[2]-x[2]);
  L.push(['Formation performance',f.length?f.slice(0,3).map(q=>shName(me,q[0])+' x'+q[1]+' '+q[2].toFixed(2)+' k/l').join(', '):'none used']);
  L.push(['Formation health','broke '+a.formBreaks+', reformed '+a.formReforms]);
  L.push(['Lives used','you '+a.livesUsed+' ('+a.lostForGood+' gone) / foe '+b.livesUsed+' ('+b.lostForGood+')']);
  L.push(['Branch redraws',a.brRedraws+' (meter lost '+Math.round(me.brWaste)+')']);return L;}
function renderResult(){const h=$('rBody');h.innerHTML='';h.scrollTop=0;
  const add=(lab,txt)=>{const p=document.createElement('p');if(lab){const b=document.createElement('b');b.textContent=lab+' ';p.appendChild(b);}p.appendChild(document.createTextNode(txt));h.appendChild(p);};
  if(revPane&&S.aiReview){add('AI REVIEW','');for(const l of S.aiReview.lines)add('',l);}else for(const r of resultLines())add(r[0],r[1]);}
function wallsLeft(sd){""")
# ---------------- input
e.ed("else if(S.tool==='wall'){const st=wallBegin(ME,q.x,q.y);if(st)ptr={mode:'wall',st:st,px:q.x,py:q.y};else{ptr=null;S.msg=wallUsed(sd)+CFG.wsp>CFG.wallMax?'No wall meter left':'Walls: your half only';}}","else if(S.tool==='wall'||S.tool==='gate'){const st=wallBegin(ME,q.x,q.y,S.tool==='gate');if(st)ptr={mode:'wall',st:st,px:q.x,py:q.y};else{ptr=null;S.msg=wallUsed(sd)+CFG.wsp>CFG.wallMax?'No wall meter left':'Walls: your half only';}}")
e.ed("for(const t of['circle','main','branch','wall','erase'])$('t'+t[0].toUpperCase()+t.slice(1)).addEventListener('click',()=>{S.tool=t;S.msg='';});","for(const t of['circle','main','branch','wall','gate','erase'])$('t'+t[0].toUpperCase()+t.slice(1)).addEventListener('click',()=>{S.tool=t;S.msg='';});\n$('tLane').addEventListener('click',()=>{const sd=S.sides[ME],P=sd.paths[selP]||sd.paths[0];for(let k=1;k<=5;k++){const c=((P.lane|0)+k)%5;if(laneOk(c)){setLane(ME,P.id,c);break;}}});\n$('btnRev').addEventListener('click',()=>{revPane=!revPane;});")
# prefs & forms boot
e.ed("const prefs={wins:0,losses:0};","const prefs={wins:0,losses:0,stage:0};")
e.ed("function loadPrefs(){try{const v=JSON.parse(localStorage.getItem(KEY)||'null');","function loadPrefs(){try{const v=JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(KEY3)||'null');")
e.ed("prefs.losses=fin(+v.losses)?clamp(Math.floor(+v.losses),0,1e6):0;}}catch(e){}}","prefs.losses=fin(+v.losses)?clamp(Math.floor(+v.losses),0,1e6):0;prefs.stage=fin(+v.stage)?clamp(Math.floor(+v.stage),0,4):0;}}catch(e){}}")
e.ed("cap:s.cap,sdens:s.sdens,compact:s.compact,wins:prefs.wins,losses:prefs.losses}));","cap:s.cap,sdens:s.sdens,compact:s.compact,wins:prefs.wins,losses:prefs.losses,stage:prefs.stage}));")
e.ed("function loadCustom(){try{const v=JSON.parse(localStorage.getItem(KEYC)||'null');","function loadCustom(){try{const v=JSON.parse(localStorage.getItem(KEYC)||localStorage.getItem(KEYC3)||'null');")
e.ed("loadPrefs();loadCustom();","loadPrefs();loadCustom();loadForms();syncForms();")
# menu, stages, editor
e.ed("$('mResume').addEventListener('click',()=>{showView('app');});","""const STG=[['1 FUNDAMENTALS','Path, density, pace, flow, pool and lives. EASY AI.'],['2 TACTICAL','+ walls, branches (erase and redraw), LINE / ARROW / WEDGE abilities, wide and narrow lanes. NORMAL AI.'],['3 ADVANCED','+ every formation, gates, tapered and arrow lanes, your own formations, angle ricochet. HARD AI.'],['4 STRATEGIC','+ full hybrid ricochet, AI custom formations and its match review. BRUTAL AI.']];
function startStage(n){n=clamp(Math.floor(n),0,4);startWith(n?{stage:n,aiLevel:n}:{});}
function buildStages(){const L=$('stlist');L.innerHTML='';
  STG.forEach((s,i)=>{const n=i+1,open=!!CUS.stageAll||n===1||prefs.stage>=n-1,b=document.createElement('button');b.className='stg'+(open?'':' lock');b.id='st'+n;const t=document.createElement('b'),d=document.createElement('small');t.textContent='STAGE '+s[0]+(prefs.stage>=n?'  (cleared)':open?'':'  (locked: win stage '+(n-1)+')');d.textContent=s[1];b.appendChild(t);b.appendChild(d);b.addEventListener('click',()=>{if(open)startStage(n);});L.appendChild(b);});
  const f=document.createElement('button');f.className='stg';f.id='st0';const t=document.createElement('b'),d=document.createElement('small');t.textContent='FREE PLAY';d.textContent='Every mechanic, NORMAL AI. Same as QUICK MATCH.';f.appendChild(t);f.appendChild(d);f.addEventListener('click',()=>startStage(0));L.appendChild(f);}
$('mStages').addEventListener('click',()=>{buildStages();showView('stages');});$('stBack').addEventListener('click',()=>showView('menu'));
// FORMATION EDITOR (grid FCOLS x FROWS, top = front). Saves to PRESETS (localStorage) -> shape abilities
const ED={cells:new Uint8Array(FCOLS*FROWS),mirror:true,sel:-1,paint:-1,cs:20},edc=$('edc'),ectx=edc.getContext('2d');
function edList(){const L=[];for(let y=0;y<FROWS;y++)for(let x=0;x<FCOLS;x++)if(ED.cells[y*FCOLS+x])L.push([x,y]);return L;}
function edMsg(t){$('edmsg').textContent=t;}
function edDraw(){const cs=ED.cs,w=cs*FCOLS,h=cs*FROWS;if(edc.width!==w||edc.height!==h)return;ectx.setTransform(1,0,0,1,0,0);ectx.fillStyle='#0b0d1c';ectx.fillRect(0,0,w,h);
  ectx.fillStyle='#4a52a8';ectx.fillRect(0,0,w,3);
  for(let y=0;y<FROWS;y++)for(let x=0;x<FCOLS;x++){const cx=Math.floor(x*cs+cs/2),cy=Math.floor(y*cs+cs/2);
    if(ED.cells[y*FCOLS+x]){ectx.fillStyle='#12b5d6';const o=Math.max(1,Math.floor(cs/6)),d=Math.max(2,Math.floor(cs/4));ectx.fillRect(cx-o-d,cy-o-d,d,d);ectx.fillRect(cx+o,cy-o-d,d,d);ectx.fillRect(cx-o-d,cy+o,d,d);ectx.fillRect(cx+o,cy+o,d,d);}
    else{ectx.fillStyle='#2c3270';ectx.fillRect(cx-1,cy-1,2,2);}}}
function edLayout(){const wr=$('edwrap'),w=wr.clientWidth,h=wr.clientHeight;if(!w||!h)return;const cs=Math.max(8,Math.floor(Math.min(w/FCOLS,h/FROWS)));ED.cs=cs;edc.width=cs*FCOLS;edc.height=cs*FROWS;edc.style.width=edc.width+'px';edc.style.height=edc.height+'px';edc.style.left=Math.floor((w-edc.width)/2)+'px';edc.style.top=Math.floor((h-edc.height)/2)+'px';edDraw();}
function edCellAt(e){const r=edc.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)/(r.width/FCOLS)),y=Math.floor((e.clientY-r.top)/(r.height/FROWS));return(x>=0&&x<FCOLS&&y>=0&&y<FROWS)?[x,y]:null;}
function edSet(x,y,v){ED.cells[y*FCOLS+x]=v;if(ED.mirror)ED.cells[y*FCOLS+(FCOLS-1-x)]=v;}
function edChips(){const L=$('edlist');L.innerHTML='';PRESETS.forEach((f,i)=>{const b=document.createElement('button');b.id='pc'+i;b.className=i===ED.sel?'on':'';b.textContent=f.name;b.addEventListener('click',()=>{ED.cells.fill(0);for(const c of f.cells)ED.cells[c[1]*FCOLS+c[0]]=1;ED.sel=i;edChips();edDraw();edMsg('Loaded '+f.name+' ('+f.cells.length+' dots).');});L.appendChild(b);});}
function edSave(){const cells=edList();if(cells.length<3){edMsg('Place at least 3 dots first.');return -1;}
  if(ED.sel>=0&&PRESETS[ED.sel]){const c=cleanForm({name:PRESETS[ED.sel].name,cells:cells});if(c){PRESETS[ED.sel]=c;saveForms();syncForms();edChips();edMsg('Updated '+c.name+'.');return ED.sel;}}
  const i=addPreset('CUSTOM '+(PRESETS.length+1),cells);if(i<0){edMsg(PRESETS.length>=MAXCUS?'All '+MAXCUS+' slots used: load one and DELETE it.':'Could not save.');return -1;}
  ED.sel=i;edChips();edMsg('Saved as '+PRESETS[i].name+'. Find it in the SHAPE tab.');return i;}
edc.addEventListener('pointerdown',e=>{e.preventDefault();const c=edCellAt(e);if(!c)return;try{edc.setPointerCapture(e.pointerId);}catch(_){}ED.paint=ED.cells[c[1]*FCOLS+c[0]]?0:1;edSet(c[0],c[1],ED.paint);edDraw();edMsg(edList().length+' dots');});
edc.addEventListener('pointermove',e=>{if(ED.paint<0)return;const c=edCellAt(e);if(c){edSet(c[0],c[1],ED.paint);edDraw();}});
const edUp=()=>{if(ED.paint>=0){ED.paint=-1;edMsg(edList().length+' dots');}};edc.addEventListener('pointerup',edUp);edc.addEventListener('pointercancel',edUp);
$('edClear').addEventListener('click',()=>{ED.cells.fill(0);ED.sel=-1;edChips();edDraw();edMsg('Cleared. SAVE makes a new formation.');});
$('edMirror').addEventListener('click',()=>{ED.mirror=!ED.mirror;$('edMirror').textContent=ED.mirror?'MIRROR ON':'MIRROR OFF';});
$('edSave').addEventListener('click',edSave);
$('edDel').addEventListener('click',()=>{if(ED.sel>=0&&delPreset(ED.sel)){ED.cells.fill(0);ED.sel=-1;edChips();edDraw();edMsg('Deleted.');}else edMsg('Load a saved formation first.');});
$('mForms').addEventListener('click',()=>{showView('editor');edChips();edMsg(edList().length+' dots');requestAnimationFrame(edLayout);});$('edBack').addEventListener('click',()=>showView('menu'));
window.addEventListener('resize',()=>{if(view==='editor')edLayout();});
$('mResume').addEventListener('click',()=>{showView('app');});""")
e.ed("$('mQuick').addEventListener('click',()=>startWith({}));","$('mQuick').addEventListener('click',()=>startWith({aiLevel:2}));")
e.save()
