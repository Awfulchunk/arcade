import sys
F='/workspace/game/build-pixelwar041/index.html'
class E:
    def __init__(s): s.t=open(F,encoding='utf8').read(); s.n=0
    def ed(s,old,new,cnt=1):
        c=s.t.count(old)
        if c!=cnt: print('PATCH FAIL (found %d, want %d):'%(c,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
        s.t=s.t.replace(old,new); s.n+=1
    def save(s): open(F,'w',encoding='utf8').write(s.t); print('ok',s.n,'edits')
