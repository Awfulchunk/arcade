import sys; sys.path.insert(0,'/workspace/game/build-pixelwar041/patch')
from lib import E
e=E()
e.ed("const prefs={wins:0,losses:0,stage:0};","const prefs={wins:0,losses:0,stage:0,diff:3};")
e.ed("prefs.stage=fin(+v.stage)?clamp(Math.floor(+v.stage),0,4):0;}}","prefs.stage=fin(+v.stage)?clamp(Math.floor(+v.stage),0,4):0;prefs.diff=fin(+v.diff)?clamp(Math.floor(+v.diff),1,4):3;}}")
e.ed("wins:prefs.wins,losses:prefs.losses,stage:prefs.stage}));","wins:prefs.wins,losses:prefs.losses,stage:prefs.stage,diff:prefs.diff}));")
e.ed("function startStage(n){n=clamp(Math.floor(n),0,4);startWith(n?{stage:n,aiLevel:n}:{});}","function startStage(n){n=clamp(Math.floor(n),0,4);startWith(n?{stage:n,aiLevel:n}:{aiLevel:prefs.diff});}")
e.ed("$('mQuick').addEventListener('click',()=>startWith({aiLevel:2}));","$('mQuick').addEventListener('click',()=>startWith({aiLevel:prefs.diff}));\n$('mDiff').addEventListener('click',()=>{prefs.diff=prefs.diff>=4?1:prefs.diff+1;setT('mDiff','DIFFICULTY: '+DIFFN[prefs.diff]);hudCache.mDiff=null;savePrefs();});")
e.ed('<button id="mQuick">QUICK MATCH</button>','<button id="mQuick">QUICK MATCH</button><button id="mDiff">DIFFICULTY: HARD</button>')
e.ed("d.textContent='Every mechanic, NORMAL AI. Same as QUICK MATCH.';","d.textContent='Every mechanic, AI at your DIFFICULTY setting. Same as QUICK MATCH.';")
e.ed("function showView(v){view=v;","function showView(v){view=v;if(v==='menu')setT('mDiff','DIFFICULTY: '+DIFFN[prefs.diff]);")
# help
t=e.t;i=t.index("const HELP=[");j=t.index("function hud(){")
e.t=t[:i]+"""const HELP=['Destroy the enemy circle. Your pixels hurt it on contact; they never shoot or fight, they only collide.',
 'POOL = HP: your circle holds a pool of pixels (10,000). Every enemy pixel that reaches it burns 20 pixels out of the pool (500 hits to lose). Pool at 0 = you lose.',
 'LIVES: each pixel has 20 lives. A collision death costs one life and the pixel goes back to the circle to come out again. After 20 deaths it is gone for good.',
 'PREP: place your circle, draw one PATH (it locks at START), spend the WALL meter on barriers, and draw BRANCHES only from the path. A path is a route; the LANE is the area the pixels occupy around it.',
 'LANE SHAPES: the LANE button gives a path (or branch) a hitbox geometry: NORMAL, WIDE, NARROW, TAPERED (wide to narrow) or ARROW (narrow shaft, flared head). It shows as a faint yellow (purple for branches) area. Narrow lanes pack the pixels tighter.',
 'You choose how the stream looks: DENSITY (wide and loose vs tight and packed), FLOW (how fast pixels leave the circle) and PACE (how fast they travel). The most pixels out at once is limited by your pool and a performance cap.',
 'SHAPES are abilities with a cooldown (shown on each button). A shape forms inside the lane by borrowing pixels from the stream, so the pixels behind it are thinner. It never makes the lane wider. FORM AT slides where it forms. ARROW and WEDGE have a fuller leading edge.',
 'FORMATIONS are not rigid. Impacts stretch, compress and scatter them, a badly hit one breaks apart, and a surviving one REFORMS toward its preferred arrangement. In a tapered lane a formation compresses with it.',
 'FORMATION EDITOR (menu): place dots on a grid, top = front, and SAVE up to 6 formations on this device. Each one becomes a shape button in the SHAPE tab with the same cooldown and lane rules. The AI designs its own formations the same way.',
 'BRANCHES can be erased and redrawn during the battle (ERASE, then BRANCH; start on the end of a branch to continue it). The main path stays locked. All branches share one meter; erasing mid-match loses a share of it (Custom: Branch meter lost), so redrawing is never free.',
 'WALLS block both sides. Your own pixels stop at your walls and do no damage. Enemy pixels wear down only the exact spot they hit, so a hole opens where they keep hitting. A GATE is a wall piece (dashed) that your own pixels pass through and enemies cannot.',
 'RICOCHET (FULL HYBRID, the default): the chance a pixel bounces off instead of taking damage and the chance it pushes the enemy away depend on the IMPACT ANGLE (glancing bounces more, head-on hits harder), the CLOSING SPEED (fast hits hit harder and push farther) and PACKING (tightly packed pixels survive and push more). Custom Game can switch to the older rules.',
 'DIFFICULTY (Easy, Normal, Hard, Brutal) changes only how well the AI plans, adapts and times its formations. Its pool, lives, burn, cooldowns and meters are exactly yours.',
 'STAGES unlock mechanics step by step: 1 Fundamentals, 2 Tactical, 3 Advanced, 4 Strategic. Quick Match and Custom Game have everything. After a match the result screen shows your stats and the AI review; the AI then wipes its tactical memory. CUSTOM GAME exposes every rule.'];
"""+e.t[j:]
# CMDS
e.ed("{name:'setTool',args:[{name:'i',min:0,max:4}]}","{name:'setTool',args:[{name:'i',min:0,max:5}]}")
e.ed(" {name:'eraseAt',args:[{name:'x',min:0,max:360},{name:'y',min:0,max:500}]},"," {name:'gate',args:[{name:'x1',min:0,max:360},{name:'y1',min:260,max:500},{name:'x2',min:0,max:360},{name:'y2',min:260,max:500}]},{name:'setLane',args:[{name:'path',min:0,max:5},{name:'v',min:0,max:4}]},\n {name:'eraseAt',args:[{name:'x',min:0,max:360},{name:'y',min:0,max:500}]},")
e.ed("const TOOLS=['circle','main','branch','wall','erase'];","const TOOLS=['circle','main','branch','wall','erase','gate'];")
e.ed("case'setTool':{const i=Math.floor(num(+args[0]));S.tool=TOOLS[clamp(i,0,4)];break;}","case'setTool':{const i=Math.floor(num(+args[0]));S.tool=TOOLS[clamp(i,0,5)];break;}\n  case'gate':{const st=wallBegin(0,num(+args[0]),num(+args[1]),true);if(!st)return 0;const n=wallExtend(0,st,num(+args[2]),num(+args[3]));wallEnd(0,st);return n;}\n  case'setLane':return setLane(0,Math.floor(num(+args[0])),num(+args[1]));")
e.ed("shapes:sd.paths.map(P=>P?P.sh.t:-1)})),pixels:pix};},","shapes:sd.paths.map(P=>P?P.sh.t:-1),lanes:sd.paths.map(P=>P?P.lane:-1),forms:sd.forms.length,gatePass:sd.stats.gatePass})),stage:CFG.stage|0,pixels:pix};},")
e.ed("branchBegin,branchExtend,branchEnd,removeBranch,setSetting,setShape,","branchBegin,branchExtend,branchEnd,removeBranch,setSetting,setShape,setLane,laneF,laneOk,LANES,formErr,shock,disband,brLeft,brTotal,brCap,feat,shapeOkS,shName,get PRESETS(){return PRESETS;},set PRESETS(v){PRESETS=v;},addPreset,delPreset,cleanForm,loadForms,saveForms,syncForms,aiDesignForm,buildReview,resultLines,renderResult,startStage,STG,DIFFN,ED,edList,edSet,edSave,edChips,edLayout,formPts,lanePoly,pgc,KEYF,KEY,KEYC,")
e.ed(" C:{W,H,CAPMAX,PSP,CONTACT,STUN,MAXP,MAXSQ,DEFCFG,SHAPES},"," C:{W,H,CAPMAX,PSP,CONTACT,STUN,MAXP,MAXSQ,DEFCFG,SHAPES,NSH,MAXCUS,FCOLS,FROWS},")
e.save()
