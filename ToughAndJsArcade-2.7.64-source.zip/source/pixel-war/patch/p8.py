import sys
sys.path.insert(0,'/workspace/game/build-pixelwar041/patch')
from lib import E
e=E();L=e.t.split('\n')
def find(prefix,start=0):
    for k in range(start,len(L)):
        if L[k].startswith(prefix): return k
    print('NO LINE',prefix); sys.exit(1)
a=find("// FORMATION EDITOR (grid");b=find("$('edClear').addEventListener")
L[a:b]="""// SHAPE OUTLINE EDITOR: draw ONE closed outline with a finger (top edge = FRONT). The outline IS the shape's yellow hitbox: its pixels wander freely inside it. Saves to PRESETS (localStorage) -> shape abilities
const EDW=15,EDH=12,ED={pts:[],poly:null,sel:-1,drawing:false,cs:20},edc=$('edc'),ectx=edc.getContext('2d');
function edMsg(t){$('edmsg').textContent=t;}
function edSimplify(pts){let th=0.04,q=pts.slice(0,1);for(let g=0;g<14;g++){q=[pts[0]];for(let k=1;k<pts.length;k++){const l=q[q.length-1];if(Math.hypot(pts[k][0]-l[0],pts[k][1]-l[1])>=th)q.push(pts[k]);}if(q.length<=POLYMAX)break;th*=1.3;}return q;}
function edPoly(){const q=edSimplify(ED.pts);const f=q.length>=3?cleanForm({name:'X',poly:q}):null;return f?f.poly:null;}
function edDraw(){const cs=ED.cs,w=cs*EDW,h=cs*EDH;if(edc.width!==w||edc.height!==h)return;ectx.setTransform(1,0,0,1,0,0);ectx.fillStyle='#fff';ectx.fillRect(0,0,w,h);
  ectx.fillStyle='#e8ebf5';ectx.fillRect(0,0,w,3);ectx.strokeStyle='#161616';ectx.lineWidth=1;ectx.setLineDash([4,4]);ectx.beginPath();ectx.moveTo(w/2,0);ectx.lineTo(w/2,h);ectx.stroke();ectx.setLineDash([]);
  const poly=ED.poly;
  if(poly){ectx.beginPath();poly.forEach((p,k)=>{k?ectx.lineTo(p[0]*w,p[1]*h):ectx.moveTo(p[0]*w,p[1]*h);});ectx.closePath();ectx.fillStyle='rgba(255,205,60,0.45)';ectx.fill();ectx.strokeStyle='rgba(214,160,20,0.9)';ectx.lineWidth=2;ectx.stroke();
    const rr=mul(7);ectx.fillStyle='#1c2fd6';let n=0;for(let g=0;g<900&&n<90;g++){const x=rr(),y=rr();if(!inPoly(poly,x,y))continue;if(rr()>Math.exp(-(x-0.5)*(x-0.5)/0.05))continue;n++;ectx.fillRect(Math.floor(x*w)-1,Math.floor(y*h)-1,2,2);}}
  else if(ED.pts.length>1){ectx.beginPath();ED.pts.forEach((p,k)=>{k?ectx.lineTo(p[0]*w,p[1]*h):ectx.moveTo(p[0]*w,p[1]*h);});ectx.strokeStyle='rgba(214,160,20,0.9)';ectx.lineWidth=2;ectx.stroke();}}
function edLayout(){const wr=$('edwrap'),w=wr.clientWidth,h=wr.clientHeight;if(!w||!h)return;const cs=Math.max(8,Math.floor(Math.min(w/EDW,h/EDH)));ED.cs=cs;edc.width=cs*EDW;edc.height=cs*EDH;edc.style.width=edc.width+'px';edc.style.height=edc.height+'px';edc.style.left=Math.floor((w-edc.width)/2)+'px';edc.style.top=Math.floor((h-edc.height)/2)+'px';edDraw();}
function edAt(e){const r=edc.getBoundingClientRect();return[clamp((e.clientX-r.left)/r.width,0,1),clamp((e.clientY-r.top)/r.height,0,1)];}
function edChips(){const L=$('edlist');L.innerHTML='';PRESETS.forEach((f,i)=>{const b=document.createElement('button');b.id='pc'+i;b.className=i===ED.sel?'on':'';b.textContent=f.name;b.addEventListener('click',()=>{ED.poly=f.poly.map(c=>[c[0],c[1]]);ED.pts=ED.poly.map(c=>[c[0],c[1]]);ED.sel=i;edChips();edDraw();edMsg('Loaded '+f.name+' ('+f.poly.length+' points). Draw again to replace it.');});L.appendChild(b);});}
function edSave(){const poly=ED.poly;if(!poly){edMsg('Draw one closed outline first.');return -1;}
  if(ED.sel>=0&&PRESETS[ED.sel]){const c=cleanForm({name:PRESETS[ED.sel].name,poly:poly});if(c){PRESETS[ED.sel]=c;saveForms();syncForms();edChips();edMsg('Updated '+c.name+'.');return ED.sel;}}
  const i=addPreset('CUSTOM '+(PRESETS.length+1),poly);if(i<0){edMsg(PRESETS.length>=MAXCUS?'All '+MAXCUS+' slots used: load one and DELETE it.':'Could not save.');return -1;}
  ED.sel=i;edChips();edMsg('Saved as '+PRESETS[i].name+'. Find it in the SHAPE tab.');return i;}
edc.addEventListener('pointerdown',e=>{e.preventDefault();try{edc.setPointerCapture(e.pointerId);}catch(_){}ED.drawing=true;ED.pts=[edAt(e)];ED.poly=null;edDraw();edMsg('Drawing... lift to close the outline.');});
edc.addEventListener('pointermove',e=>{if(!ED.drawing)return;const p=edAt(e),l=ED.pts[ED.pts.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])>0.008){ED.pts.push(p);edDraw();}});
const edUp=()=>{if(!ED.drawing)return;ED.drawing=false;ED.poly=edPoly();if(ED.poly)edMsg('Outline closed ('+ED.poly.length+' points). SAVE it, or draw again.');else edMsg('Too small or flat: draw a bigger closed outline.');edDraw();};edc.addEventListener('pointerup',edUp);edc.addEventListener('pointercancel',edUp);""".split('\n')
e.t='\n'.join(L)
e.ed("$('edClear').addEventListener('click',()=>{ED.cells.fill(0);ED.sel=-1;edChips();edDraw();edMsg('Cleared. SAVE makes a new formation.');});\n$('edMirror').addEventListener('click',()=>{ED.mirror=!ED.mirror;$('edMirror').textContent=ED.mirror?'MIRROR ON':'MIRROR OFF';});\n",
"$('edClear').addEventListener('click',()=>{ED.pts=[];ED.poly=null;ED.sel=-1;edChips();edDraw();edMsg('Cleared. Draw an outline, then SAVE makes a new shape.');});\n")
e.ed("if(ED.sel>=0&&delPreset(ED.sel)){ED.cells.fill(0);ED.sel=-1;edChips();edDraw();edMsg('Deleted.');}else edMsg('Load a saved formation first.');","if(ED.sel>=0&&delPreset(ED.sel)){ED.pts=[];ED.poly=null;ED.sel=-1;edChips();edDraw();edMsg('Deleted.');}else edMsg('Load a saved shape first.');")
e.ed("$('mForms').addEventListener('click',()=>{showView('editor');edChips();edMsg(edList().length+' dots');requestAnimationFrame(edLayout);});","$('mForms').addEventListener('click',()=>{showView('editor');edChips();edMsg(ED.poly?'Outline ready.':'Draw one closed outline.');requestAnimationFrame(edLayout);});")
# html
e.ed('<button id="mForms">FORMATION EDITOR</button>','<button id="mForms">SHAPE EDITOR</button>')
e.ed('<h1>FORMATION EDITOR</h1><p class="sub">Tap or drag dots onto the grid; the top edge is the FRONT. Saved formations are shape abilities in the SHAPE tab (the AI designs its own).</p>','<h1>SHAPE EDITOR</h1><p class="sub">Draw ONE closed outline with your finger; the top edge is the FRONT. The outline is the shape\'s yellow hitbox: its pixels wander freely inside it. Saved shapes are abilities in the SHAPE tab (the AI designs its own).</p>')
e.ed('<button id="edMirror">MIRROR ON</button>','')
e.ed("edList,edSet,edSave,edChips,edLayout,","edPoly,edSave,edChips,edLayout,edDraw,edSimplify,")
# comments
e.ed("// custom formation cells (FCOLS x FROWS grid, row 0 = front) -> points (u front-first, v lateral); cached on the formation\n","") if False else None
open('/workspace/game/build-pixelwar041/index.html','w',encoding='utf8').write(e.t)
