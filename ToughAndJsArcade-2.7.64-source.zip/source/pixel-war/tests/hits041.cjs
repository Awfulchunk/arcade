// 0.4.1 hits -> out/hits041/*.png (360x800 @2 = 720x1600 device px; zoom crops @3). Menus, outline editor, lane widths, areas, knock-out, recall, walls, gates, redraw, result.
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar041/out/hits041/';fs.mkdirSync(OUT,{recursive:true});for(const f of fs.readdirSync(OUT))if(f.endsWith('.png'))fs.unlinkSync(OUT+f);
const HELP=`window.__H={mk(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};},
 game(seed,cfg){const P=__pw;P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed,false);P.setRnd(this.mk(seed));return P;},
 main(P,pts){for(const k of pts||[[180,420],[184,350],[190,280],[196,210],[196,140]])P.pathExtend(0,k[0],k[1]);},
 straight(P){for(const y of[400,340,280,220,160,100])P.pathExtend(0,180,y);},
 quiet(P){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);f.acc=0;},
 box(P){let n=0,a=1e9,b=-1e9,c=1e9,d=-1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]>=4){n++;a=Math.min(a,P.px[i]);b=Math.max(b,P.px[i]);c=Math.min(c,P.py[i]);d=Math.max(d,P.py[i]);}return n?{n,x:(a+b)/2,y:(c+d)/2,w:b-a,h:d-c}:null;}};`;
(async()=>{const b=await launch();let pg;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const fresh=async(w,h)=>{pg=await open(b,w||360,h||800,2);await pg.evaluate(HELP);};
 const snap=async(name,clip)=>{await sleep(160);const o={path:OUT+name+'.png'};if(clip)o.clip=clip;await pg.screenshot(o);};
 const L=()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const zoom=async(name,cx,cy,w,h)=>{const l=await L();await snap(name,{x:l.x+(cx-w/2)*l.s,y:l.y+(cy-h/2)*l.s,width:w*l.s,height:h*l.s,scale:3});};
 const show=(seed,cfg,fn)=>pg.evaluate(([seed,cfg,fn])=>{const P=__H.game(seed,JSON.parse(cfg));eval(fn);__pw.S.paused=true;__pw.draw();},[seed,JSON.stringify(cfg),fn]);
 const adv=(n)=>pg.evaluate(n=>{const P=__pw;for(let i=0;i<n;i++)P.tick();P.S.paused=true;P.draw();},n);
 // 01 menu, 02 stages, 03 custom, 04 help
 await fresh();await pg.evaluate(()=>__pw.showView('menu'));await snap('01-menu');
 await pg.click('#mStages');await sleep(200);await snap('02-stages');await pg.click('#stBack');await sleep(150);
 await pg.click('#mCustom');await sleep(250);await snap('03-custom-game-top');await pg.evaluate(()=>{document.getElementById('clist').scrollTop=99999;});await snap('03b-custom-game-bottom');await pg.evaluate(()=>__pw.showView('menu'));
 await pg.evaluate(()=>__pw.showView('help'));await snap('04-help');await pg.evaluate(()=>{const e=document.querySelector('#help .body, #help div');});
 // 05 OUTLINE EDITOR: draw with real mouse, save, load chip
 await pg.evaluate(()=>{localStorage.removeItem('pixelwar.v41.forms');__pw.PRESETS=[];__pw.showView('menu');});await pg.click('#mForms');await sleep(300);
 const er=await pg.evaluate(()=>{const r=document.getElementById('edc').getBoundingClientRect();return{x:r.left,y:r.top,w:r.width,h:r.height};});
 const E=(u,v)=>({x:er.x+er.w*u,y:er.y+er.h*v});
 await snap('05a-editor-empty');
 const hook=[[0.5,0.04],[0.64,0.16],[0.8,0.3],[0.9,0.5],[0.84,0.7],[0.66,0.84],[0.5,0.78],[0.4,0.9],[0.28,0.78],[0.2,0.55],[0.26,0.32],[0.38,0.16],[0.5,0.04]];
 await pg.mouse.move(E(...hook[0]).x,E(...hook[0]).y);await pg.mouse.down();for(let k=1;k<hook.length;k++){await pg.mouse.move(E(...hook[k]).x,E(...hook[k]).y,{steps:4});}await pg.mouse.up();await sleep(150);await snap('05b-editor-outline-drawn');
 await pg.click('#edSave');await sleep(200);await snap('05c-editor-saved');
 // 06 LANES side by side like the sketch: WIDE (loose stipple), ARROW (thin -> bubble), NARROW (hugging, packed). One image per lane, stitched by contact step.
 for(const [i,nm] of [[1,'a-wide'],[4,'b-arrow'],[2,'c-narrow']]){await fresh();await show(5,{capDef:4000},"P.placeCircle(0,180,440);__H.straight(P);P.setLane(0,0,"+i+");P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.sides[0].set.release=8;P.S.paused=false;for(let k=0;k<330;k++)P.tick();P.S.paused=true;P.draw();");await zoom('06'+nm+'-lane-battle',180,250,150,300);await pg.close();}
 // 07 ARROW ability: forming (t=45), formed (t=120), thinning behind it (t=200), later
 for(const [k,ticks] of [['a-forming',70],['b-formed',120],['c-moving',200]]){await fresh();await show(3,{capDef:4000},"P.placeCircle(0,180,440);__H.straight(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.sides[0].set.release=8;for(let k=0;k<60;k++)P.tick();P.useShape(0,0,1);for(let k=0;k<"+ticks+";k++)P.tick();");await snap('07'+k+'-arrow-ability');if(k==='b-formed'||k==='c-moving'){const bx=await pg.evaluate(()=>__H.box(__pw));if(bx)await zoom('07'+k+'-zoom',bx.x,bx.y,90,110);}await pg.close();}
 // 07d ARROW ability in a THIN lane: bubble up to 3x the thin lane, borrowed from the stream behind
 await fresh();await show(3,{capDef:4000},"P.placeCircle(0,180,440);__H.straight(P);P.setLane(0,0,2);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.sides[0].set.release=8;for(let k=0;k<60;k++)P.tick();P.useShape(0,0,1);for(let k=0;k<140;k++)P.tick();");{const bx=await pg.evaluate(()=>__H.box(__pw));if(bx)await zoom('07d-arrow-in-thin-lane-zoom',bx.x,bx.y+20,90,150);}await pg.close();
 // 08 each shape area (zoom)
 const SN=['line','arrow','wedge','ring','diamond','double','spiral'];
 for(const t of[0,2,3,4,5,6]){await fresh();await show(3,{ring:1},"P.placeCircle(0,180,440);__H.straight(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,"+t+");for(let k=0;k<170;k++)P.tick();");const bx=await pg.evaluate(()=>__H.box(__pw));if(bx)await zoom('08-shape-'+SN[t],bx.x,bx.y,80,80);await pg.close();}
 // 08g custom (drawn) outline as ability
 await fresh();await show(3,{},"P.PRESETS=[];P.addPreset('HOOK',[[0.5,0.04],[0.8,0.3],[0.9,0.5],[0.84,0.7],[0.5,0.78],[0.4,0.9],[0.2,0.55],[0.26,0.32]]);P.placeCircle(0,180,440);__H.straight(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,7);for(let k=0;k<170;k++)P.tick();");{const bx=await pg.evaluate(()=>__H.box(__pw));if(bx)await zoom('08-shape-custom-outline',bx.x,bx.y,80,80);}await pg.close();
 // 09 COLLISION KNOCKS PIXELS OUT: before / impact / after (dots outside the soft edge, then regroup)
 await fresh();await show(4,{capDef:4000},"P.placeCircle(0,180,440);__H.straight(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,2);for(let i=0;i<150;i++)P.tick();window.__q=P.S.sides[0].sq.find(x=>x);");
 let bx=await pg.evaluate(()=>__H.box(__pw));await zoom('09a-before-impact',bx.x,bx.y,90,90);
 await pg.evaluate(()=>{const P=__pw,sd=P.S.sides[0],q=window.__q,B=P.POOL;let cx=0,cy=0,n=0;for(let m=0;m<q.n;m++){const i=q.slot[m];if(i>=0){cx+=P.px[i];cy+=P.py[i];n++;}}cx/=n;cy/=n;P.S.sides[1].paths[0].p=[cx,cy-30,cx,cy-26];let k=0;for(let m=0;m<q.n&&k<120;m++){const i=q.slot[m];if(i>=0&&m%2===0){P.px[B+k]=P.px[i]+1.2;P.py[B+k]=P.py[i];P.pvx[B+k]=0;P.pvy[B+k]=-30;P.pspm[B+k]=1;P.php[B+k]=2;P.pst[B+k]=3;P.pcd[B+k]=0;P.pwc[B+k]=0;P.pstun[B+k]=0;P.pgc[B+k]=0;k++;}}P.S.sides[1].active+=k;P.S.paused=false;for(let s=0;s<14;s++){P.movePixels();P.collide();P.S.tick++;}P.S.paused=true;P.draw();window.__ko=sd.stats.knocked;});
 bx=await pg.evaluate(()=>__H.box(__pw));await zoom('09b-impact-knocked-out',bx.x,bx.y,110,110);
 const koN=await pg.evaluate(()=>{const P=__pw;let c=0;for(let i=0;i<P.POOL;i++)if(P.pst[i]===5)c++;return c;});console.log('knocked out at impact frame:',koN);
 await pg.evaluate(()=>{const P=__pw;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);P.S.sides[1].active=0;P.S.paused=false;for(let i=0;i<70;i++)P.tick();P.S.paused=true;P.draw();});
 bx=await pg.evaluate(()=>__H.box(__pw));await zoom('09c-regrouped',bx.x,bx.y,90,90);await pg.close();
 // 10 RECALL: pixels shoved past the leash go home (before / after)
 await fresh();await show(3,{},"P.placeCircle(0,180,440);__H.straight(P);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.useShape(0,0,0);for(let i=0;i<150;i++)P.tick();const q=P.S.sides[0].sq.find(x=>x),ms=[];for(let m=0;m<q.n;m++)if(q.slot[m]>=0)ms.push(q.slot[m]);const lash=P.CFG.leash;ms.slice(0,40).forEach((i,k)=>{const tx=-q.ty,ty=q.tx,d=q.def.rad+(k<20?lash*0.55:lash*1.15)+((k%5)*2);const s=k%2?1:-1;P.px[i]=q.cx+tx*d*s+q.tx*(P.plu[i]);P.py[i]=q.cy+ty*d*s+q.ty*(P.plu[i]);P.pvx[i]=0;P.pvy[i]=0;P.pcnt[i]=0;});window.__rc=P.S.sides[0].stats.koRecall;P.S.paused=true;P.draw();");
 bx=await pg.evaluate(()=>__H.box(__pw));await zoom('10a-shoved-past-leash',180,bx.y,230,170);
 await pg.evaluate(()=>{const P=__pw;P.S.paused=false;for(let i=0;i<3;i++)P.tick();P.S.paused=true;P.draw();});
 await zoom('10b-recalled-or-returning',180,bx.y,230,170);console.log('recalls:',await pg.evaluate(()=>__pw.S.sides[0].stats.koRecall-window.__rc));await pg.close();
 // 11 WALLS: 1000 HP per section (500 per cell), 5 damage per hit: an enemy stream wearing a hole into one spot
 await fresh();await show(6,{},"P.placeCircle(0,180,456);P.S.sides[1].human=true;let st=P.wallBegin(0,100,400);P.wallExtend(0,st,260,400);P.wallEnd(0,st);P.startBattle();__H.quiet(P);P.S.sides[1].paths[0].p=[180,340,180,344];const B=P.POOL;for(let n=0;n<4600;n++){const i=B+(n%40);P.px[i]=176+((n*7)%11)*1.0;P.py[i]=396;P.pvx[i]=0;P.pvy[i]=40;P.pspm[i]=1;P.php[i]=2;P.pst[i]=3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;P.pgc[i]=0;P.S.sides[1].active=40;P.movePixels();P.collide();}window.__w=st.segs.map(s=>s.hp+(s.alive?'':'x')).join(',');");
 console.log('wall cell HP after the hammering:',await pg.evaluate(()=>window.__w));
 await snap('11-walls-worn');await zoom('11b-walls-zoom',180,400,170,50);await pg.close();
 // 12 prep: gates + walls + branch with lanes
 await fresh();await show(6,{},"P.placeCircle(0,180,440);__H.main(P);let st=P.wallBegin(0,60,400);P.wallExtend(0,st,110,388);P.wallExtend(0,st,140,386);P.wallEnd(0,st);st=P.wallBegin(0,150,300,true);P.wallExtend(0,st,230,300);P.wallEnd(0,st);st=P.wallBegin(0,240,380);P.wallExtend(0,st,290,392);P.wallExtend(0,st,330,404);P.wallEnd(0,st);const p=P.S.sides[0].paths[0].p;const B=P.branchBegin(0,p[24],p[25]);for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]-q*16,p[25]-q*12);P.branchEnd(0,B);P.setLane(0,0,3);P.setLane(0,B.id,2);");await snap('12-prep-walls-gates-branch-lanes');await pg.close();
 // 13 gate
 await fresh();await show(7,{capDef:3000},"P.placeCircle(0,180,440);__H.main(P);let st=P.wallBegin(0,150,330,true);P.wallExtend(0,st,215,330);P.wallEnd(0,st);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.paused=false;for(let i=0;i<260;i++)P.tick();P.S.paused=true;P.draw();");await snap('13-gate-own-stream-passes');await zoom('13b-gate-zoom',185,330,90,60);await pg.close();
 // 14 mid-battle branch erase + redraw (free)
 await fresh();await show(8,{capDef:3000},"P.placeCircle(0,180,440);__H.main(P);const p=P.S.sides[0].paths[0].p;let B=P.branchBegin(0,p[24],p[25]);for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]-q*16,p[25]-q*12);P.branchEnd(0,B);P.S.sides[1].human=true;P.startBattle();__H.quiet(P);P.S.paused=false;for(let i=0;i<200;i++)P.tick();P.eraseAt(0,p[24]-48,p[25]-36);B=P.branchBegin(0,p[24],p[25]);if(B){for(let q=1;q<=6;q++)P.branchExtend(0,B,p[24]+q*16,p[25]-q*12);P.branchEnd(0,B);}for(let i=0;i<120;i++)P.tick();window.__w=P.S.sides[0].brWaste;");await snap('14-branch-erased-redrawn-free');console.log('branch meter lost:',await pg.evaluate(()=>window.__w));await pg.close();
 // 15 dense battle with AI, arrow lane
 await fresh();await show(11,{capDef:4000,aiLevel:4},"P.placeCircle(0,180,440);__H.main(P);P.setLane(0,0,3);P.aiPlan(1);P.S.sides[1].human=false;P.startBattle();P.useShape(0,0,1);for(let i=0;i<420;i++){P.tick();if(i%120===60)P.useShape(0,0,4);}");await snap('15-battle-brutal-ai-tapered-lane');await pg.close();
 // 16/17 result + review
 for(const [w,h,tag] of [[360,800,'360'],[320,568,'320']]){await fresh(w,h);await pg.evaluate(()=>{const P=__H.game(12,{capDef:3000,aiLevel:3});P.placeCircle(0,180,440);__H.main(P);P.aiPlan(1);P.S.sides[1].human=false;P.startBattle();for(let i=0;i<6000&&!P.S.over;i++)P.tick();window.__ended=P.S.over;});await sleep(300);await snap('16-result-review-'+tag);await pg.click('#btnRev');await sleep(250);await snap('17-result-stats-'+tag);await pg.close();}
 console.log('done');await b.close();})();
