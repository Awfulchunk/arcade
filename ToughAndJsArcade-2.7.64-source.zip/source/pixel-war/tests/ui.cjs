// Visual + controls tests at 360x800@2, 320x568@2, 720x1600@1 (and A03s-class 720x1600@2 rendering size check)
const {launch,open}=require('./lib.cjs');
const fs=require('fs');const OUT='/workspace/game/build-pixelwar041/out/shots/';fs.mkdirSync(OUT,{recursive:true});
const R=[];const ok=(n,c,i)=>{R.push([c?'PASS':'FAIL',n,c?'':String(i)]);};
const SIZES=[[360,800,2,'360x800'],[320,568,2,'320x568'],[720,1600,1,'720x1600']];
async function domChecks(pg,tag){
 return pg.evaluate(()=>{const out={over:[],small:[],clip:[],offs:[]};
  const els=[...document.querySelectorAll('#top>*,#panel *,#stage,canvas')].filter(e=>{const r=e.getBoundingClientRect(),cs=getComputedStyle(e);return r.width>0&&r.height>0&&cs.display!=='none'&&cs.visibility!=='hidden';});
  const leaf=els.filter(e=>(!e.querySelector('*')||e.matches('button,input,.bar,canvas,#stage,#rBody'))&&(!e.closest('#rBody')||e.id==='rBody'));
  const vis=leaf.filter(e=>!e.closest('.bar')||e.classList.contains('bar')); // bar children are inside bars
  for(let i=0;i<vis.length;i++)for(let j=i+1;j<vis.length;j++){const a=vis[i],b=vis[j];if(a.contains(b)||b.contains(a))continue;const A=a.getBoundingClientRect(),B=b.getBoundingClientRect();
   const ox=Math.min(A.right,B.right)-Math.max(A.left,B.left),oy=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);if(ox>0.5&&oy>0.5)out.over.push((a.id||a.tagName)+' x '+(b.id||b.tagName));}
  for(const e of document.querySelectorAll('button,input'))if(e.offsetParent!==null){const r=e.getBoundingClientRect();if(r.height<43.5||r.width<43.5)out.small.push(e.id+':'+Math.round(r.width)+'x'+Math.round(r.height));if(r.right>innerWidth+0.5||r.bottom>innerHeight+0.5||r.left<-0.5)out.offs.push(e.id);}
  for(const e of document.querySelectorAll('#status,.lab,button,#info,#result p,#result h2'))if(e.offsetParent!==null&&(e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+1))out.clip.push(e.id||e.className||e.tagName);
  const c=document.getElementById('c'),r=c.getBoundingClientRect();out.canvas={cw:c.width,ch:c.height,w:r.width,h:r.height,dpr:devicePixelRatio,smooth:c.getContext('2d').imageSmoothingEnabled};
  const st=document.getElementById('stage').getBoundingClientRect();out.stage=[st.width,st.height];out.scale=__pw.L.LS;
  return out;});}
(async()=>{const b=await launch();
 for(const [w,h,d,tag] of SIZES){const pg=await open(b,w,h,d,{mobile:true});
  await pg.evaluate(()=>__tt.setSeed(5));
  let r=await domChecks(pg,tag);
  ok(tag+' prep: no overlapping UI elements',r.over.length===0,r.over);ok(tag+' prep: all tap targets >=44px',r.small.length===0,r.small);ok(tag+' prep: no clipped text',r.clip.length===0,r.clip);ok(tag+' prep: nothing off-screen',r.offs.length===0,r.offs);
  ok(tag+' canvas is DPR-native ('+r.canvas.cw+'x'+r.canvas.ch+' for '+Math.round(r.canvas.w)+'x'+Math.round(r.canvas.h)+' @'+r.canvas.dpr+')',Math.abs(r.canvas.cw-Math.round(r.canvas.w*r.canvas.dpr))<=1&&Math.abs(r.canvas.ch-Math.round(r.canvas.h*r.canvas.dpr))<=1);
  ok(tag+' imageSmoothing off',r.canvas.smooth===false);
  console.log(tag,'field scale',r.scale.toFixed(2),'stage',r.stage.map(Math.round));
  for(const tb of['S','F','D']){await pg.evaluate(t=>document.getElementById('tab'+t).click(),tb);const rr=await domChecks(pg,tag);ok(tag+' prep tab '+tb+': no overlap/small/clip',rr.over.length+rr.small.length+rr.clip.length===0,JSON.stringify(rr.over.concat(rr.small,rr.clip)));}
  for(const v of['menu','custom','help']){await pg.evaluate(v=>__pw.showView(v),v);await new Promise(r=>setTimeout(r,60));
   const vr=await pg.evaluate(v=>{const root=document.getElementById(v),R=root.getBoundingClientRect(),out={over:[],small:[],clip:[],off:[]};const els=[...root.querySelectorAll('button,input,h1,.sub,.cl,.cgrp,.hlp p,.cv')].filter(e=>{const r=e.getBoundingClientRect();if(!(r.width>0&&r.height>0&&r.bottom>R.top&&r.top<R.bottom))return false;const sc=e.closest('.hlp');if(sc&&e!==sc){const q=sc.getBoundingClientRect();if(r.bottom>q.bottom+0.5||r.top<q.top-0.5)return false;}return true;});
    for(let i=0;i<els.length;i++)for(let j=i+1;j<els.length;j++){const a=els[i],b=els[j];if(a.contains(b)||b.contains(a))continue;const A=a.getBoundingClientRect(),B=b.getBoundingClientRect();const ox=Math.min(A.right,B.right)-Math.max(A.left,B.left),oy=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);if(ox>0.5&&oy>0.5)out.over.push((a.id||a.className||a.tagName)+' x '+(b.id||b.className||b.tagName));}
    for(const e of els){const r=e.getBoundingClientRect();if(/BUTTON|INPUT/.test(e.tagName)&&(r.height<43.5||r.width<43.5)&&r.top>=R.top&&r.bottom<=R.bottom)out.small.push((e.id||e.tagName)+':'+Math.round(r.width)+'x'+Math.round(r.height));
     if(/BUTTON|H1|CV/.test(e.tagName)||e.classList.contains('cl')||e.classList.contains('cv')){if(e.scrollWidth>e.clientWidth+1)out.clip.push(e.id||e.textContent.slice(0,20));}
     if(r.right>window.innerWidth+1||r.left<-1)out.off.push(e.id||e.textContent.slice(0,16));}
    return out;},v);
   ok(tag+' '+v+' view: no overlaps/small targets/clipped/off-screen',vr.over.length+vr.small.length+vr.clip.length+vr.off.length===0,JSON.stringify(vr));}
  await pg.evaluate(()=>__pw.showView('app'));await new Promise(r=>setTimeout(r,60));
  await pg.screenshot({path:OUT+tag+'-prep.png'});
  await pg.evaluate(()=>{__tt.step(1);__tt.step(400);});
  r=await domChecks(pg,tag);ok(tag+' battle: no overlaps/small/clip/offscreen',r.over.length+r.small.length+r.clip.length+r.offs.length===0,JSON.stringify(r));
  await pg.screenshot({path:OUT+tag+'-battle.png'});
  {const fit=await pg.evaluate(()=>{const o=[];for(const [id,t] of [['lCa','OUT 10000'],['tY','YOU 10000'],['tF','FOE 10000'],['lSp','PACE 10'],['lDe','DENSITY 10'],['lRe','FLOW 10']]){const e=document.getElementById(id);if(!e||e.offsetParent===null)continue;const old=e.textContent;e.textContent=t;if(e.scrollWidth>e.clientWidth+1)o.push(id+':'+e.scrollWidth+'>'+e.clientWidth);e.textContent=old;}return o;});ok(tag+' worst-case HUD text (10000 / 10) fits its label',fit.length===0,fit);}
  await pg.evaluate(()=>{let t=0;while(!__pw.S.over&&t<12000){__tt.step(30);t+=30;}});await new Promise(r=>setTimeout(r,200));
  r=await domChecks(pg,tag);ok(tag+' result view: no overlaps/small/clip/offscreen',r.over.length+r.small.length+r.clip.length+r.offs.length===0,JSON.stringify(r));
  await pg.screenshot({path:OUT+tag+'-result.png'});
  // pixel-mask: circles don't overlap anything solid; pixel colours crisp (only expected palette + AA of arcs/lines)
  const pm=await pg.evaluate(()=>{const s=__tt.getSprites().filter(x=>x.noOverlap);let o=0;for(let i=0;i<s.length;i++)for(let j=i+1;j<s.length;j++){const a=s[i],b=s[j];if(Math.min(a.x+a.w,b.x+b.w)>Math.max(a.x,b.x)&&Math.min(a.y+a.h,b.y+b.h)>Math.max(a.y,b.y))o++;}return o;});
  ok(tag+' solid sprites (circles) never overlap',pm===0);
  ok(tag+' 0 JS errors',pg._errs.length===0,pg._errs);
  // crispness: sample a pixel row through a pixel dot; dots must be solid rectangles (no gradient): count distinct colours near a known pixel
  await pg.close();}
 // controls with real touch input at 360x800
 {const pg=await open(b,360,800,2,{mobile:true});
  const L=async()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
  async function tdrag(pts){const l=await L();const q=pts.map(p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s}));const t=await pg.touchscreen.touchStart(q[0].x,q[0].y);for(const p of q.slice(1))await t.move(p.x,p.y);await t.end();}
  const st=()=>pg.evaluate(()=>{const s=__pw.S.sides[0];return{cx:s.circle.x,cy:s.circle.y,pu:__pw.pathUsed(s),wu:__pw.wallUsed(s),strokes:s.strokes.length,ph:__pw.S.phase,tool:__pw.S.tool,paused:__pw.S.paused,hudP:document.getElementById('tP').textContent};});
  await pg.evaluate(()=>__tt.setSeed(31));
  await pg.tap('#tCircle');await tdrag([[100,455],[200,462]]);let s=await st();ok('touch: CIRCLE tool places circle on bottom strip (x~200)',Math.abs(s.cx-200)<3&&s.cy>=440,[s.cx,s.cy]);
  await pg.tap('#tMain');await pg.tap('#tMain');await tdrag([[50,300],[60,290]]);s=await st();ok('touch: PATH starting away from circle is refused',s.pu===0,s.pu);
  await tdrag([[200,462],[200,380],[150,300],[160,200],[250,120]]);s=await st();ok('touch: PATH drawn from circle (used '+Math.round(s.pu)+')',s.pu>200&&s.pu<=520&&s.hudP.indexOf('PATH')===0,s.pu);
  const pu1=s.pu;await tdrag([[250,120],[330,60],[340,300],[10,300],[10,40],[300,20]]);s=await st();ok('touch: path meter caps at 520',s.pu<=520&&s.pu>pu1,s.pu);
  await pg.tap('#tWall');await pg.tap('#tWall');await tdrag([[20,300],[340,300]]);s=await st();ok('touch: WALL stroke limited by wall meter (<=220), cannot span screen',s.wu>100&&s.wu<=220,s.wu);
  await tdrag([[20,360],[340,360]]);await tdrag([[20,420],[340,420]]);s=await st();ok('touch: more strokes still capped at 220',s.wu<=220,s.wu);
  await tdrag([[20,200],[300,200]]);const w2=(await st()).wu;ok('touch: wall in enemy half refused',w2===s.wu,[w2,s.wu]);
  await pg.tap('#tErase');await pg.tap('#tErase');await tdrag([[100,300],[100,300]]);await tdrag([[100,360],[100,360]]);s=await st();ok('touch: ERASE removes wall strokes and frees meter',s.wu<=130,s.wu);
  const pe=await pg.evaluate(()=>{const p=__pw.S.sides[0].paths[0].p;return[p[200],p[201]];});await tdrag([[pe[0],pe[1]],[pe[0],pe[1]]]);s=await st();ok('touch: ERASE on path trims it',s.pu<pu1+300&&s.pu<(520),s.pu);
  await pg.tap('#btnPause');s=await st();ok('PAUSE toggles',s.paused===true);await pg.tap('#btnPause');
  await pg.tap('#tStart');await new Promise(r=>setTimeout(r,1500));s=await st();const t1=await pg.evaluate(()=>__pw.S.tick);ok('START locks and battle runs in real time (tick '+t1+')',s.ph==='battle'&&t1>30,[s.ph,t1]);
  await pg.tap('#btnPause');await new Promise(r=>setTimeout(r,300));const a=await pg.evaluate(()=>__pw.S.tick);await new Promise(r=>setTimeout(r,500));const c2=await pg.evaluate(()=>__pw.S.tick);ok('PAUSE freezes sim',a===c2,[a,c2]);await pg.tap('#btnPause');
  await pg.evaluate(()=>{const e=document.getElementById('sSp');e.value=10;e.dispatchEvent(new Event('input',{bubbles:true}));const f=document.getElementById('sDe');f.value=1;f.dispatchEvent(new Event('input',{bubbles:true}));});
  ok('sliders drive settings',await pg.evaluate(()=>__pw.S.sides[0].set.speed===10&&__pw.S.sides[0].set.density===1));
  const ek=await pg.evaluate(()=>{const g=__pw.S.sides[0];const q=[g.paths[0].p.length];return q[0];});
  await pg.tap('#btnRestart');s=await st();ok('NEW restarts to prep and keeps slider settings',s.ph==='prep'&&await pg.evaluate(()=>__pw.S.sides[0].set.speed===10),s.ph);
  ok('touch tests: 0 JS errors',pg._errs.length===0,pg._errs);await pg.close();}
 await b.close();
 let f=0;for(const r of R){console.log(r.join(' '));if(r[0]==='FAIL')f++;}console.log('UI '+(R.length-f)+' pass / '+f+' fail');process.exit(f?1:0);})();
