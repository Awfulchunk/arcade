// 0.3 tests: pool/lives/burn, shape cooldowns, lane containment, thinning, density ricochet, arrow vs dense/loose, wall cells, ring removal
const {launch,open}=require('./lib.cjs');
const code=function(){
const P=window.__pw,R=[];const ok=(name,cond,info)=>R.push({name,pass:!!cond,info:info===undefined?'':String(info)});
const lcg=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
const POOL=P.POOL;
function fresh(seed,cfg){P.CFG=Object.assign({},P.C.DEFCFG,{ricoMode:0},cfg||{});P.newGame(seed||1,false);P.setRnd(lcg(seed||1));}
function mainPath(side,pts){const q=pts||[[180,400],[184,330],[190,260],[196,190],[196,130]];for(const k of q)P.pathExtend(side||0,k[0],k[1]);}
function quietFoe(){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;f.acc=0;for(let i=POOL;i<2*POOL;i++)if(P.pst[i])P.recall(i);}
function run(n){for(let i=0;i<n;i++)P.tick();}
function battle(seed,cfg,quiet){fresh(seed,cfg);P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();if(quiet!==false)quietFoe();return P.S.sides[0];}
const count=(side,f)=>{let c=0;for(let i=side*POOL;i<side*POOL+POOL;i++)if(P.pst[i]&&(!f||f(i)))c++;return c;};
const hit=(sd,v)=>{sd.pool=v;sd.circle.hp=v;};
const sset=(sd,s)=>{const q=new Set();return q;};
// ================= 1 POOL
fresh(1);{const a=P.S.sides[0],b=P.S.sides[1];
 ok('each circle starts with a 10,000-pixel pool; HP = pool',a.pool===10000&&b.pool===10000&&a.circle.hp===10000&&P.qN[0]===10000&&P.qN[1]===10000);
 let all20=true;for(let i=0;i<2*POOL;i++)if(P.plife[i]!==20)all20=false;ok('every pixel starts with 20 lives (Custom: lives)',all20);}
{const sd=battle(2,{capDef:10000},true);sd.set.cap=10000;sd.set.release=10;let n=0;for(let i=0;i<20000;i++)if(P.release(0))n++;
 ok('pool: 10,000 pixels can be on the field at once (cap raised in Custom) and no more',n===10000&&sd.active===10000&&P.qN[0]===0&&!P.release(0),[n,sd.active,P.qN[0]]);
 for(let k=0;k<30000;k++){let i=-1;for(let q=k%POOL;q<POOL;q++)if(P.pst[q]){i=q;break;}if(i<0){for(let q=0;q<POOL;q++)if(P.pst[q]){i=q;break;}}P.recall(i);if(!P.release(0))break;}
 ok('pool recycling: 30,000 recall+release cycles at 10k, pool never runs out',sd.active===10000&&P.qN[0]===0&&sd.pool===10000,[sd.active,P.qN[0],sd.pool]);
 for(let i=0;i<POOL;i++)if(P.pst[i])P.recall(i);ok('after recalling all, 10,000 ready again',P.qN[0]===10000&&sd.active===0);}
{const sd=battle(3,{poolSize:10000},true);const a0=sd.active;sd.set.cap=4000;let n=0;for(let i=0;i<9000;i++)if(P.release(0))n++;
 ok('default on-screen cap is the performance cap (4000) even with a 10,000 pool',n===4000&&P.CFG.capDef===4000&&P.qN[0]===6000,[n,P.CFG.capDef]);
 fresh(3,{capDef:3000});P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();ok('old 3000 cap is a Custom Game value (capDef 3000 applies)',P.S.sides[0].set.cap===3000);}
// ================= 2 LIVES
{fresh(4,{poolSize:50,lives:3});const sd=P.S.sides[0];P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();quietFoe();
 const kill=()=>{if(!P.release(0))return false;let i=-1;for(let q=0;q<POOL;q++)if(P.pst[q]){i=q;break;}P.loseLife(i);return true;};
 for(let n=0;n<50;n++)kill();let ev=true;for(let i=0;i<50;i++)if(P.plife[i]!==2)ev=false;
 ok('life countdown: 50 collision deaths take one life from 50 different pixels (FIFO wear), pool intact ('+sd.pool+')',ev&&sd.pool===50&&P.qN[0]===50&&sd.stats.livesUsed===50);
 for(let n=0;n<100;n++)kill();
 ok('permanent removal: after 3 lives every pixel is gone, pool 0, HP mirror 0, nothing left to release',sd.pool===0&&sd.circle.hp===0&&P.qN[0]===0&&!P.release(0)&&sd.stats.lostForGood===50,[sd.pool,P.qN[0],sd.stats.lostForGood]);}
{const sd=battle(5,{},true);let i=-1;P.release(0);for(let q=0;q<POOL;q++)if(P.pst[q]){i=q;break;}P.plife[i]=1;const before=sd.pool;P.loseLife(i);
 ok('the 20th death removes that pixel for good: pool -1, never returns to the ready ring',P.plife[i]===0&&sd.pool===before-1&&sd.circle.hp===before-1&&sd.stats.lostForGood===1&&P.qN[0]===POOL-1+(0));}
{const sd=battle(6,{},true);let a=-1,b=-1;for(let q=0;q<POOL;q++){}
 const A=0,B=POOL;P.release(0);P.release(1);for(let q=0;q<POOL;q++)if(P.pst[q]){a=q;break;}for(let q=POOL;q<2*POOL;q++)if(P.pst[q]){b=q;break;}
 P.px[a]=100;P.py[a]=200;P.pvx[a]=50;P.pvy[a]=0;P.pst[a]=3;P.php[a]=1;P.pcd[a]=0;P.px[b]=102;P.py[b]=200;P.pvx[b]=-50;P.pvy[b]=0;P.pst[b]=3;P.php[b]=2;P.pcd[b]=0;
 const l0=P.plife[a],pool0=sd.pool;P.setRnd(()=>0.5);P.collide();
 ok('a pixel killed in a collision uses ONE life and goes back to its circle (pool unchanged)',P.plife[a]===l0-1&&sd.pool===pool0&&P.pst[a]===0&&sd.stats.livesUsed===1,[P.plife[a],l0]);}
// ================= 3 BURN
{const sd=battle(7,{},true),foe=P.S.sides[1];const pool0=sd.pool,q0=P.qN[0];
 P.release(1);let b=-1;for(let q=POOL;q<2*POOL;q++)if(P.pst[q]){b=q;break;}
 for(let n=0;n<5;n++){P.px[b]=sd.circle.x;P.py[b]=sd.circle.y;P.pst[b]=3;P.pvx[b]=0;P.pvy[b]=0;P.pwc[b]=0;P.collide();if(!P.pst[b])P.release(1),b=(()=>{for(let q=POOL;q<2*POOL;q++)if(P.pst[q])return q;return -1;})();}
 ok('each enemy pixel reaching my circle burns 20 pixels out of my pool (5 hits -> -100; 500 hits = 10,000)',sd.pool===pool0-100&&sd.circle.hp===pool0-100&&sd.stats.burned===100&&foe.stats.circleDmg===5&&P.qN[0]===q0-100,[sd.pool,P.qN[0]]);
 ok('burned pixels come out of the READY ring first',P.qN[0]===q0-100);}
{const sd=battle(8,{poolSize:1000,capDef:1000},true);sd.set.cap=1000;for(let i=0;i<1000;i++)P.release(0);const pool0=sd.pool;
 ok('all pixels out on the field: pool is 1000, ready 0',sd.active===1000&&P.qN[0]===0);
 P.burnPool(sd,60);ok('burn with nobody ready becomes debt, pool drops at once ('+sd.pool+')',sd.pool===pool0-60&&sd.debt===60&&sd.circle.hp===pool0-60);
 let i=0,done=0;while(done<60){if(P.pst[i]){P.recall(i);done++;}i++;}
 ok('debt is paid by the next 60 pixels that return: they are removed for good, invariant ready+out-debt = pool',sd.debt===0&&P.qN[0]===0&&sd.active===940&&sd.pool===940,[sd.debt,P.qN[0],sd.active,sd.pool]);}
{let bad=0,dup=0;fresh(9,{burn:2});P.aiPlan(0);P.startBattle();for(let t=0;t<2500&&!P.S.over;t++){P.tick();if(t%50===0)for(let s=0;s<2;s++){const sd=P.S.sides[s];if(P.qN[s]+sd.active-sd.debt!==sd.pool)bad++;if(sd.circle.hp!==sd.pool)bad++;
   const seen=new Set();for(let k=0;k<P.qN[s];k++){const i=P.qBufAt?0:0;}}}
 ok('invariant over a real match: ready + out - debt = pool and HP = pool (50-tick samples)',bad===0,bad);}
// ================= 4 SHAPE COOLDOWNS
{const sd=battle(10);const t0=P.S.tick;run(5);
 ok('shape fires in battle',P.useShape(0,0,1)===true);
 ok('same shape refused while on cooldown',P.useShape(0,0,1)===false&&P.shapeLeft(0,1)>0);
 const cd=P.cdTicks(1);ok('cooldown length = shapeCD x multiplier ('+cd+' ticks)',cd===Math.round(P.CFG.shapeCD*60*1));
 ok('a different shape has its OWN cooldown (but one fire per path at a time while it forms)',P.useShape(0,0,2)===false&&P.useShape(0,0,4)===false);
 run(60*P.CFG.armSec+5);ok('after the formation finishes/expires the path can fire another shape',P.useShape(0,0,2)===true);
 P.S.tick=t0+5+cd-1;ok('1 tick before the cooldown ends: still refused',P.shapeLeft(0,1)===1);P.S.tick++;ok('cooldown over: ready',P.shapeLeft(0,1)===0);}
{fresh(11);P.placeCircle(0,180,456);mainPath(0);ok('shapes cannot be fired in prep',P.useShape(0,0,1)===false);P.startBattle();ok('RING is not available by default',P.useShape(0,0,3)===false);
 fresh(11,{ring:1});P.placeCircle(0,180,456);mainPath(0);P.startBattle();ok('RING works only when Custom Game turns it on',P.useShape(0,0,3)===true);}
{let viol=0,fires=0,rings=0,sideFires=[0,0],both=0;
 for(const seed of[41,42,43]){fresh(seed,{burn:1,aiLevel:3});P.aiPlan(0);P.startBattle();const last=[new Array(7).fill(-1),new Array(7).fill(-1)],used=[new Array(7).fill(0),new Array(7).fill(0)];
  for(let t=0;t<2400&&!P.S.over;t++){P.tick();for(let s=0;s<2;s++){const sd=P.S.sides[s];for(let k=0;k<7;k++)if(sd.shUsed[k]!==used[s][k]){used[s][k]=sd.shUsed[k];fires++;sideFires[s]++;if(k===3)rings++;if(last[s][k]>=0&&P.S.tick-last[s][k]<P.cdTicks(k))viol++;last[s][k]=P.S.tick;}}}}
 ok('AI obeys the same cooldowns: '+fires+' shape fires in 3 matches, 0 inside a cooldown, no RING',fires>=6&&viol===0&&rings===0,[fires,viol,rings]);
 ok('both the planner (player side, auto) and the AI use shapes',sideFires[1]>=3,sideFires);}
// ================= 5 AREA CONTAINMENT (0.4.1: a shape is a free-wander hitbox AREA; members wander inside it, none are slots)
{let worst=1,bad=[],rows=[];
 for(const den of[3,7,10]){for(const t of[0,1,2,4,5,6]){const sd=battle(20+t,{},true);sd.set.density=den;sd.set.speed=5;sd.set.release=9;run(60);const hw=P.laneHW(sd.set);
   P.useShape(0,0,t);let tot=0,inside=0;
   for(let k=0;k<230;k++){P.tick();const q=sd.sq.find(x=>x&&x.t===t);if(q&&!q.open&&k>110&&k%6===0){for(let m=0;m<q.n;m++){const i=q.slot[m];if(i<0)continue;tot++;if(P.areaSd(q,i)<=P.CFG.koMargin)inside++;}}}
   const q=sd.sq.find(x=>x&&x.t===t);const fr=tot?inside/tot:0;if(fr<worst)worst=fr;rows.push(den+'/'+t+':'+fr.toFixed(2));if(tot<200||fr<0.9)bad.push(den+'/'+t+' '+fr.toFixed(2)+' n='+tot);}}
 ok('every shape (LINE ARROW WEDGE DIAMOND DOUBLE SPIRAL) keeps >=90% of its pixels inside its area (+knock margin) at density 3, 7, 10, worst '+worst.toFixed(2),bad.length===0,bad.join(' ')+' | '+rows.join(' '));}
{let bad=[];for(const den of[1,4,7,10])for(const t of[0,1,2,4,5,6]){fresh(1);const set={speed:5,density:den,release:9,sdens:7,compact:6},hw=P.laneHW(set),D=P.areaDef(t,hw,1,null);
  if(D.rad>1.2*hw+1e-6)bad.push(den+'/'+t+' rad '+D.rad.toFixed(1)+' > 1.2hw '+(1.2*hw).toFixed(1));if(D.Lu>48+1e-6||D.Lu>P.CFG.shapeLen*hw+1e-3&&!D.disc)bad.push(den+'/'+t+' Lu '+D.Lu.toFixed(1));}
 ok('area half-width <= 1.2 x lane half-width (= 3x the thin lane 0.4) for all shapes and 4 densities, and never longer than 48u: shapes borrow, they never grow the lane',bad.length===0,bad.join(' '));
 fresh(1);const hw7=P.laneHW({speed:5,density:7}),D7=P.areaDef(1,hw7,1,null);ok('shapes are modest: ARROW area at the default lane is '+D7.Lu.toFixed(0)+'u long x '+(2*D7.rad).toFixed(0)+'u wide (lane '+(2*hw7).toFixed(0)+'u)',D7.Lu<=P.CFG.shapeLen*hw7+1e-3&&D7.Lu<48&&2*D7.rad<=2.4*hw7+1e-6);}
// ================= 6 THINNING BEHIND THE SHAPE
{const win=(fire,seed,t)=>{const sd=battle(seed,{});sd.set.release=9;sd.set.speed=5;run(150);const F=P.fPos(sd.paths[0]);if(fire)P.useShape(0,0,t);if(fire){let g=0;while(g++<200){run(1);const q=sd.sq.find(x=>x);if(q&&!q.open)break;}}else run(70);run(12);
   let n=0,sq=0;for(let i=0;i<POOL;i++){if(P.pst[i]===2&&P.pps[i]>=F+2&&P.pps[i]<=F+50)n++;if(P.pst[i]===4)sq++;}return{n,sq};};
 let a=0,b=0,sqn=0;for(const seed of[51,52,53]){const w1=win(true,seed,1),w0=win(false,seed,1);a+=w1.n;b+=w0.n;sqn+=w1.sq;}
 ok('stream behind a forming shape is thinned: '+a+' vs '+b+' stream pixels in the 50u after the form point (borrowed '+Math.round(sqn/3)+' per shape)',a<b*0.85&&sqn/3>100,[a,b,sqn]);}
{const sd=battle(54,{sqPull:100});sd.paths[0].sh.pull=100;sd.paths[0].sh.at=15;run(150);P.useShape(0,0,1);run(120);const q=sd.sq.find(x=>x);
 ok('the shape BORROWS pixels from the stream: squad size = sqN ('+(q&&q.n)+'), no pixels created',!!q&&q.n===P.CFG.sqN&&sd.active<=sd.stats.released-sd.stats.recalled-sd.stats.kills+1);}
// ================= 7 DENSITY-SCALED RICOCHET
{const trial=(packed,loose,N)=>{let sI=0,sJ=0,bI=0,bJ=0,pk=0;const seed=7;P.CFG=Object.assign({},P.C.DEFCFG,{ricoMode:0});P.newGame(7,false);P.setRnd(lcg(77));P.placeCircle(0,180,456);P.placeCircle(1,180,44);P.S.sides[0].human=P.S.sides[1].human=true;P.startBattle();
  for(let i=0;i<2*POOL;i++)if(P.pst[i])P.recall(i);
  for(let n=0;n<N;n++){for(let i=0;i<2*POOL;i++)if(P.pst[i]){P.pst[i]=0;}P.S.sides[0].active=0;P.S.sides[1].active=0;
   const put=(i,x,y,vx,vy)=>{P.px[i]=x;P.py[i]=y;P.pvx[i]=vx;P.pvy[i]=vy;P.php[i]=2;P.pst[i]=3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;P.S.sides[i<POOL?0:1].active++;};
   put(0,100,200,50,0);put(POOL,102,200,-50,0);
   for(let k=1;k<=packed;k++){put(k,96+(k%5)*1.5,196+((k/5)|0)%6*1.4,0.01,0);P.pcd[k]=255;}        // own side behind i (x<=97 > 4.5u from the enemy pixel)
   for(let k=1;k<=loose;k++){put(POOL+k,103+(k%5)*1.0,196+((k/5)|0)%6*1.4,0.01,0);P.pcd[POOL+k]=255;}
   P.collide();pk=P.rhoAt(0,100,200);
   if(P.php[0]===2)sI++;if(P.php[POOL]===2)sJ++;if(P.pvx[0]<0)bI++;if(P.pvx[POOL]>0)bJ++;}
  return{sI:sI/N,sJ:sJ/N,bI:bI/N,bJ:bJ/N,rhoI:P.rhoAt(0,100,200),rhoJ:P.rhoAt(1,102,200)};};
 const eq=trial(0,0,3000),pk=trial(24,0,3000),lo=trial(0,24,3000);
 const f=(ri,rj)=>{const dr=(ri-rj)/P.CFG.rhoRef,pm=0.2,pr=0.35,c=(v,a,b)=>Math.min(b,Math.max(a,v));return{svI:c(pm*(1+P.CFG.kSurv*dr),0,P.CFG.survMax),svJ:c(pm*(1-P.CFG.kSurv*dr),0,P.CFG.survMax),psJ:c(pr*(1+P.CFG.kPush*dr),0,P.CFG.pushMax),psI:c(pr*(1-P.CFG.kPush*dr),0,P.CFG.pushMax)};};
 const fe=f(eq.rhoI,eq.rhoJ),fp=f(pk.rhoI,pk.rhoJ);
 ok('density ricochet: equal density = baseline survive '+eq.sI.toFixed(2)+'/'+eq.sJ.toFixed(2)+' (rho '+eq.rhoI+' vs '+eq.rhoJ+')',Math.abs(eq.sI-0.2)<0.04&&Math.abs(eq.sJ-0.2)<0.04);
 ok('PACKED (rho '+pk.rhoI+') vs loose (rho '+pk.rhoJ+'): the packed pixel survives '+pk.sI.toFixed(2)+' vs baseline '+eq.sI.toFixed(2)+' and the loose one '+pk.sJ.toFixed(2),pk.sI>eq.sI*2&&pk.sJ<eq.sJ*0.5&&pk.sI>pk.sJ+0.3,JSON.stringify(pk));
 const dfP=1-(1-pk.sJ)*(1-0)*0;ok('deflect % of the ENEMY pixel hitting the packed one: '+(100*pk.bJ).toFixed(0)+'% vs baseline '+(100*eq.bJ).toFixed(0)+'% (packed pushes enemies away); the packed pixel itself bounces '+(100*pk.bI).toFixed(0)+'%',pk.bJ>eq.bJ+0.2&&pk.bI<pk.bJ,[eq.bJ,pk.bJ,pk.bI]);
 ok('measured rates match the formula (survive packed '+pk.sI.toFixed(2)+' ~ '+fp.svI.toFixed(2)+', push '+pk.bJ.toFixed(2)+' ~ '+(1-(1-fp.psJ)*(1-fp.svJ)).toFixed(2)+')',Math.abs(pk.sI-fp.svI)<0.05&&Math.abs(pk.bJ-(1-(1-fp.psJ)*(1-fp.svJ)))<0.05);
 ok('reversed (loose pixel hits a packed enemy cluster): the loose side survives less ('+lo.sI.toFixed(2)+') and is bounced more ('+lo.bI.toFixed(2)+')',lo.sI<eq.sI*0.5&&lo.bI>eq.bI+0.2,JSON.stringify(lo));}
// ================= 8 ARROW vs DENSE LINE vs LOOSE PATH
{const scen=(seed,en,shape)=>{P.CFG=Object.assign({},P.C.DEFCFG,{ricoMode:0});P.newGame(seed,false);P.setRnd(lcg(seed));P.placeCircle(0,180,456);for(const q of[[180,400],[180,300],[180,200],[180,140]])P.pathExtend(0,q[0],q[1]);
   P.placeCircle(1,300,50);for(const q of[[300,150],[300,250],[240,250],[180,250],[120,250],[60,250]])P.pathExtend(1,q[0],q[1]);
   const m=P.S.sides[0],E=P.S.sides[1];m.set.release=5;m.set.density=7;m.set.speed=5;m.set.cap=10000;E.set.release=en.rel;E.set.density=en.den;E.set.speed=en.spd;E.set.cap=10000;m.human=E.human=true;P.startBattle();m.pool=E.pool=1e9;m.circle.hp=E.circle.hp=1e9;
   let fired=false;const ids=new Set();for(let t=0;t<900;t++){if(t===200)fired=P.useShape(0,0,shape);P.tick();if(fired&&t>200)for(let i=0;i<POOL;i++)if(P.pst[i]===4&&P.psh[i]===shape)ids.add(i);}
   let cross=0;for(const i of ids)if(P.py[i]<235)cross++;return cross/Math.max(1,ids.size);};
 const avg=(en,sh)=>[61,62,63].map(s=>scen(s,en,sh)).reduce((a,b)=>a+b,0)/3;
 const dense=avg({rel:10,den:10,spd:5},1),mid=avg({rel:6,den:7,spd:5},1),loose=avg({rel:2,den:2,spd:8},1),denseW=avg({rel:10,den:10,spd:3},2);
 ok('ARROW vs a DENSE straight enemy path stalls: only '+(100*dense).toFixed(0)+'% of its pixels get past the crossing (WEDGE '+(100*denseW).toFixed(0)+'%)',dense<0.15&&denseW<0.2,[dense,denseW]);
 ok('ARROW vs a LOOSE enemy path breaks through: '+(100*loose).toFixed(0)+'% get past',loose>0.8,loose);
 ok('a medium enemy path gives a partial result ('+(100*mid).toFixed(0)+'%): the arrow is not a free win and not useless',mid>dense+0.25&&mid<loose-0.1,[dense,mid,loose]);}
// ================= 9 WALL CELLS / BOTH SIDES / CLEARANCE
{const w=()=>{fresh(70);P.placeCircle(0,60,456);const st=P.wallBegin(0,130,330);P.wallExtend(0,st,230,330);P.wallEnd(0,st);P.placeCircle(1,300,40);P.S.sides[1].human=true;P.startBattle();for(let i=0;i<2*POOL;i++)if(P.pst[i])P.recall(i);return P.S.sides[0];};
 const sd=w();const CH=P.cellHP();const c=sd.segs[10],mx=(c.x1+c.x2)/2,my=c.y1;
 const put=(i,x,y,vx,vy)=>{P.px[i]=x;P.py[i]=y;P.pvx[i]=vx;P.pvy[i]=vy;P.php[i]=2;P.pst[i]=3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;P.pox[i]=x;P.poy[i]=y-1.6;P.S.sides[i<POOL?0:1].active++;};
 const hpAll=()=>sd.segs.map(g=>g.hp);const before=hpAll();
 put(0,mx,my-2.4,0,60);P.collide();ok('own pixel: stopped by its own wall (bounces) and the wall takes NO damage',JSON.stringify(hpAll())===JSON.stringify(before)&&P.pvy[0]<0,P.pvy[0]);
 P.pst[0]=0;put(POOL,mx,my-2.4,0,60);P.collide();const after=hpAll();let changed=[];for(let k=0;k<after.length;k++)if(after[k]!==before[k])changed.push(k);
 ok('enemy pixel damages ONLY the cell it hits (cell 10), no other cell changes',changed.length===1&&changed[0]===10&&after[10]===before[10]-P.CFG.wallDmg,changed.join());
 for(let n=0;n<Math.ceil(CH/P.CFG.wallDmg)+3;n++){P.pst[POOL]=0;P.pcd[POOL]=0;put(POOL,mx,my-2.4,0,60);P.collide();}
 const dead=sd.segs.map((g,k)=>g.alive?-1:k).filter(k=>k>=0);ok('repeated hits on one spot kill exactly that cell (hole starts at the impact spot): dead '+dead.join(','),dead.length===1&&dead[0]===10);
 for(let n=0;n<Math.ceil(CH/P.CFG.wallDmg)+3;n++){P.pst[POOL]=0;P.pcd[POOL]=0;put(POOL,(sd.segs[11].x1+sd.segs[11].x2)/2,my-2.4,0,60);P.collide();}
 const hx=c.x2;P.pst[POOL]=0;P.S.sides[1].active--;put(POOL,hx,my-2.4,0,60);P.collide();ok('after the adjacent cell dies too the hole lets pixels through right there',P.pvy[POOL]===60,P.pvy[POOL]);
 P.pst[POOL]=0;put(0,hx,my-2.4,0,60);P.collide();ok('own pixels use the same hole',P.pvy[0]===60);}
{fresh(71);P.placeCircle(0,180,456);mainPath(0,[[180,400],[180,300],[180,200]]);const nb=P.wallBegin(0,180,330);ok('a wall cannot start on your own path (clearance = lane half-width + 4)',nb===null);
 const st=P.wallBegin(0,60,330);P.wallExtend(0,st,330,330);P.wallEnd(0,st);let minx=1e9,maxx=-1e9;for(let k=0;k<st.pts.length;k+=2){if(st.pts[k]<180)maxx=Math.max(maxx,st.pts[k]);else minx=Math.min(minx,st.pts[k]);}
 const clr=P.clrOf(P.S.sides[0]);ok('a wall stops short of your own path on both sides, leaving a gap of at least '+(2*clr).toFixed(0)+'u (left end x='+maxx.toFixed(0)+', right end x='+(minx<1e8?minx.toFixed(0):'none')+')',maxx<=180-clr+0.5&&(minx>1e8||minx>=180+clr-0.5));
 fresh(72);P.placeCircle(0,180,456);const w2=P.wallBegin(0,100,330);P.wallExtend(0,w2,260,330);P.wallEnd(0,w2);const n=P.pathExtend(0,180,150);const p=P.S.sides[0].paths[0].p;let cross=false;for(let k=0;k<p.length;k+=2)if(Math.abs(p[k+1]-330)<3&&p[k]>100&&p[k]<260)cross=true;
 ok('the main path routes around your own wall: drawing straight through it stops at the clearance line (does not cross)',!cross&&P.pathUsed(P.S.sides[0])<330);}
{let released=0,blocked=0;for(const seed of[81,82]){fresh(seed,{burn:1});P.placeCircle(0,180,456);mainPath(0);const st=P.wallBegin(0,60,330);P.wallExtend(0,st,330,330);P.wallEnd(0,st);P.S.sides[1].human=true;P.startBattle();quietFoe();run(900);released+=P.S.sides[0].stats.released;blocked+=P.S.sides[0].stats.ownBlocked||0;}
 ok('own stream through the gap in its own wall is not blocked ('+blocked+' wall bounces for '+released+' pixels sent)',blocked<released*0.02,[blocked,released]);}
// ================= 10 CUSTOM
{const rows=P.CUSTOM.map(r=>r[0]);ok('Custom Game exposes pool, lives, burn, performance cap, cooldown, ring, density-ricochet constants, wall cell size',['poolSize','lives','burn','capDef','shapeCD','ring','rhoRef','kSurv','kPush','survMax','pushMax','wcell','shapeLane','shapeLen','sqN','sqPull','armSec'].every(k=>rows.includes(k)),['poolSize','lives','burn','capDef','shapeCD','ring','rhoRef','kSurv','kPush','survMax','pushMax','wcell','shapeLane','shapeLen','sqN','sqPull','armSec'].filter(k=>!rows.includes(k)));
 P.startWith({burn:5,lives:2,poolSize:2000});ok('Custom burn/lives/pool apply',P.S.sides[0].pool===2000&&P.plife[0]===2&&P.CFG.burn===5);}
return R;};
(async()=>{const b=await launch();const pg=await open(b,360,800,1);
 const R=await pg.evaluate('('+code.toString()+')()');let p=0,f=0;for(const r of R){if(r.pass)p++;else f++;console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'  ['+r.info+']'));}
 console.log('errors',pg._errs);console.log('MECH3 '+p+' pass / '+f+' fail');await b.close();process.exit(f||pg._errs.length?1:0);})();
