// MECH4: fuzz + soak of the 0.4 features (lane shapes, gates, branch erase/redraw + meter, custom formations, AI designs, stages, ricochet modes).
// Invariants: finite positions/hp, counts match live pixels, area members point at pixels that point back, wander spots finite, branch meter in range, <=6 forms, no exceptions.
const {launch,open}=require('./lib.cjs');
const code=function(){
const P=window.__pw,R=[],POOL=P.POOL;
const ok=(name,cond,info)=>R.push({name,pass:!!cond,info:info===undefined?'':String(info)});
const lcg=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
function inv(tag){const S=P.S;const bad=[];
  for(let sd=0;sd<2;sd++){const s=S.sides[sd];let live=0;for(let i=sd*POOL;i<sd*POOL+POOL;i++){if(!P.pst[i])continue;live++;if(!isFinite(P.px[i])||!isFinite(P.py[i])||!isFinite(P.pvx[i])||!isFinite(P.pvy[i])){bad.push(tag+' nonfinite pixel');break;}if(P.px[i]<-40||P.px[i]>400||P.py[i]<-40||P.py[i]>500){bad.push(tag+' pixel far outside field '+P.px[i].toFixed(0)+','+P.py[i].toFixed(0));break;}}
    if(live!==s.active)bad.push(tag+' side'+sd+' active '+s.active+' != live '+live);
    if(!isFinite(s.circle.hp)||s.circle.hp<0)bad.push(tag+' hp '+s.circle.hp);
    if(s.forms.length>P.C.MAXCUS)bad.push(tag+' forms '+s.forms.length);
    if(P.brTotal(s)>P.brCap()+1e-3||!isFinite(P.brTotal(s)))bad.push(tag+' branch meter total '+P.brTotal(s)+' cap '+P.brCap());
    for(const q of s.sq){if(!q)continue;if(!(q.coh>=0&&q.coh<=1.0001))bad.push(tag+' coh '+q.coh);let l=0;for(let m=0;m<q.n;m++){const i=q.slot[m];if(i<0)continue;l++;if(!P.pst[i]||P.psq[i]!==q.id||P.pst[i]<4)bad.push(tag+' member->pixel mismatch');if(!isFinite(P.plu[i]+P.plv[i]))bad.push(tag+' wander spot not finite');}if(l!==q.live)bad.push(tag+' squad live '+q.live+' != '+l);}}
  return bad;}
const allBad=[];let fired=0,gates=0,erased=0,redrawn=0,forms=0,matches=0;
for(let seed=1;seed<=14;seed++){
  const rnd=lcg(seed*131);
  P.CFG=Object.assign({},P.C.DEFCFG,{capDef:[1500,3000,4000][seed%3],aiLevel:(seed%4)+1,ricoMode:seed%4,lives:[3,20,255][seed%3],burn:[20,200,1][seed%3],pace:1,laneDef:seed%5});
  P.newGame(seed,false);P.setRnd(rnd);P.placeCircle(0,60+rnd()*240,400+rnd()*55);
  for(let k=1;k<=8;k++)P.pathExtend(0,60+rnd()*240,456-k*40-rnd()*10);
  P.setLane(0,0,(rnd()*5)|0);
  for(let k=0;k<3;k++){const gate=rnd()<0.5,x=60+rnd()*200,y=270+rnd()*120;const st=P.wallBegin(0,x,y,gate);if(st){P.wallExtend(0,st,x+60+rnd()*40,y+(rnd()-.5)*40);P.wallEnd(0,st);if(gate)gates++;}}
  for(let k=0;k<2;k++){const p0=P.S.sides[0].paths[0].p,j=2*((rnd()*(p0.length/2-2))|0)+2;const B=P.branchBegin(0,p0[j],p0[j+1]);if(B){for(let q=1;q<=6;q++)P.branchExtend(0,B,p0[j]+(rnd()-.5)*160,p0[j+1]-q*14);P.branchEnd(0,B);}}
  if(seed%2){const poly=[];const nv=3+((rnd()*8)|0);for(let k=0;k<nv;k++)poly.push([rnd(),rnd()]);if(P.addPreset('FZ'+seed,poly)>=0)forms++;}
  P.S.sides[1].human=false;P.startBattle();
  for(let t=0;t<1800&&!P.S.over;t++){
    P.tick();
    if(t%97===0){const ids=[0,1,2,3,4,5,6,7,8,9,10,11,12];const sh=ids[(rnd()*ids.length)|0];const sd=P.S.sides[0];if(P.useShape(0,(rnd()*sd.paths.length)|0,sh))fired++;}
    if(t%211===0){const sd=P.S.sides[0];if(P.eraseAt(0,60+rnd()*240,150+rnd()*300))erased++;}
    if(t%263===0){const sd=P.S.sides[0],p0=sd.paths[0].p,j=2*((rnd()*(p0.length/2-2))|0)+2;const B=P.branchBegin(0,p0[j],p0[j+1]);if(B){for(let q=1;q<=5;q++)P.branchExtend(0,B,p0[j]+(rnd()-.5)*140,p0[j+1]-q*16);P.branchEnd(0,B);redrawn++;}}
    if(t%300===0){P.setLane(0,0,(rnd()*5)|0);}
    if(t%50===0){const b=inv('seed'+seed+'@'+t);if(b.length){allBad.push(b[0]);break;}}
  }
  matches++;const b=inv('seed'+seed+' end');if(b.length)allBad.push(b[0]);
}
ok('FUZZ x14 seeds: lanes, gates, branch erase/redraw, custom outlines, abilities, AI levels 1-4, ricochet modes 0-3: no invariant broke ('+matches+' matches, '+fired+' abilities, '+gates+' gates, '+erased+' erases, '+redrawn+' redraws, '+forms+' presets)',allBad.length===0,allBad.slice(0,3).join(' | '));
// stage gating
{const res=[];for(let st=1;st<=4;st++){P.CFG=Object.assign({},P.C.DEFCFG,{stage:st});P.newGame(3,false);const sd=P.S.sides[0];res.push([st,P.canWall(sd)?1:0,P.canBr(sd)?1:0,P.laneOk(2)?1:0,P.laneOk(3)?1:0,P.feat('rico3')?1:0,P.feat('forms')?1:0].join(''));}
 ok('STAGE gating table (walls,branch,laneAB,laneCD,rico3,forms) per stage = '+res.join(' '),res.join(' ')==='1000000 2111000 3111101 4111111',res.join(' '));}
// presets hardening
{P.CFG=Object.assign({},P.C.DEFCFG);P.newGame(1,false);P.PRESETS=[];let n=0;for(let k=0;k<20;k++)if(P.addPreset('P'+k,[[0.1,0],[0.9,0],[0.9,1],[0.1,1]])>=0)n++;ok('PRESETS capped at '+P.C.MAXCUS+' (tried 20, kept '+n+')',n===P.C.MAXCUS&&P.PRESETS.length===P.C.MAXCUS);
 ok('PRESETS reject junk (NaN, flat, too few points, strings)',P.addPreset('x',[[NaN,1],[1e9,-4]])<0&&P.addPreset('y','zzz')<0&&P.addPreset('z',[[1,1]])<0&&P.addPreset('w',[[0,0],[0.5,0.5],[1,1]])<0&&P.addPreset('v',[[0,0],[0.01,0],[0.01,0.01]])<0);P.PRESETS=[];}
// AI wipes memory
{P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:4,capDef:1500});P.newGame(9,false);P.setRnd(lcg(9));P.placeCircle(0,180,456);P.S.sides[1].human=false;P.startBattle();for(let t=0;t<600;t++)P.tick();P.endMatch(0);ok('AI memory wiped after the match, review kept (ai='+P.S.ai+', forms '+P.S.sides[1].forms.length+', review lines '+(P.S.aiReview?P.S.aiReview.lines.length:0)+')',!P.S.ai&&P.S.sides[1].forms.length===0&&P.S.aiReview&&P.S.aiReview.lines.length>=4);}
return R;};
(async()=>{const b=await launch();const pg=await open(b,360,800,2);const R=await pg.evaluate('('+code.toString()+')()');let p=0,f=0;for(const r of R){if(r.pass)p++;else f++;console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'  ['+r.info+']'));}
 console.log('errors',JSON.stringify(pg._errs));console.log('MECH4 '+p+' pass / '+f+' fail');await b.close();process.exit(f||pg._errs.length?1:0);})();
