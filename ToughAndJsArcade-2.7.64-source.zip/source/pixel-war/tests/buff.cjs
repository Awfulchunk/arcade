// Break + stress tests
const {launch,open,FILE}=require('./lib.cjs');
const R=[];const ok=(n,c,i)=>R.push([c?'PASS':'FAIL',n,c?'':String(i)]);
let seed=12345;const rr=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const inv=pg=>pg.evaluate(()=>{const S=__pw.S;let bad=0;window.__why=window.__why||{};const w=k=>{bad++;__why[k]=(__why[k]||0)+1;};for(let sd=0;sd<2;sd++){let c=0;for(let i=sd*__pw.C.CAPMAX;i<sd*__pw.C.CAPMAX+__pw.C.CAPMAX;i++)if(__pw.pst[i]){c++;if(!isFinite(__pw.px[i]+__pw.py[i]+__pw.pvx[i]+__pw.pvy[i]))w('nan');if(__pw.php[i]<1||__pw.php[i]>Math.max(2,__pw.CFG.pixHP))w('php');}if(c!==S.sides[sd].active||c>__pw.C.CAPMAX)w('cnt'+c+'/'+S.sides[sd].active);
 const s=S.sides[sd];if(__pw.pathUsed(s)>__pw.CFG.pathMax+1e-6||__pw.wallUsed(s)>__pw.CFG.wallMax+1e-6)w('meter');}return bad;});
(async()=>{const b=await launch();
 // 1 monkey with real input
 {const pg=await open(b,360,800,2,{mobile:true});const ids=['#tCircle','#tMain','#tBranch','#tWall','#tErase','#tStart','#btnPause','#btnRestart','#btnAgain','#tabS','#tabF','#tabD','#shb0','#shb1','#shb2','#shb4','#shb5','#shb6','#shb1','#shb5','#chips button','#btnMenu','#mResume','#mQuick','#mCustom','#cBack','#cPlay','#mHelp','#hBack'];let bad=0,N=1200;
  for(let i=0;i<N;i++){const k=rr();try{
   if(k<0.35){const x=rr()*360,y=60+rr()*500;await pg.mouse.move(x,y);await pg.mouse.down();for(let j=0;j<3;j++)await pg.mouse.move(rr()*360,60+rr()*500);await pg.mouse.up();}
   else if(k<0.6){const id=ids[(rr()*ids.length)|0];const el=await pg.$(id);if(el){const v=await el.isVisible?.();try{await el.click({delay:0});}catch(e){}}}
   else if(k<0.7){await pg.evaluate(r=>{const ids=['sSp','sDe','sRe','sCa','sSh','sPu','sAt','sSD','sCo'];const e=document.getElementById(ids[(r*9)|0]);e.value=Math.floor(Math.random()*e.max);e.dispatchEvent(new Event('input',{bubbles:true}));},rr());}
   else if(k<0.8)await pg.evaluate(()=>__tt.step(30));
   else if(k<0.85)await pg.setViewport({width:200+((rr()*600)|0),height:300+((rr()*1300)|0),deviceScaleFactor:1+((rr()*2)|0),isMobile:true,hasTouch:true});
   else if(k<0.9)await pg.keyboard.press(rr()<.5?'Escape':'Backspace');
   else if(k<0.95)await pg.evaluate(()=>__tt.step(200));
   else await pg.evaluate(()=>{__tt.flood(300)});
  }catch(e){bad++;}
  if(i%100===0)bad+=await inv(pg);}
  bad+=await inv(pg);ok('monkey: '+N+' random real taps/drags/sliders/resizes/keys: invariants hold (finite, hp, counts, meters)',bad===0,bad+JSON.stringify(await pg.evaluate(()=>__why)));ok('monkey: 0 JS errors',pg._errs.length===0,pg._errs.slice(0,3));await pg.close();}
 // 2 multitouch, cancel
 {const pg=await open(b,360,800,2,{mobile:true});await pg.tap('#tMain');await pg.tap('#tMain');
  const L=await pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
  const c=await pg.evaluate(()=>__pw.S.sides[0].circle);
  const t1=await pg.touchscreen.touchStart(L.x+c.x*L.s,L.y+c.y*L.s);const t2=await pg.touchscreen.touchStart(L.x+50,L.y+100);
  await t1.move(L.x+c.x*L.s,L.y+300);await t2.move(L.x+300,L.y+100);await t1.end();await t2.end();
  ok('multi-touch: no errors, meters sane',(await inv(pg))===0&&pg._errs.length===0,pg._errs);
  // touch cancel mid-stroke
  await pg.evaluate(()=>{const c=document.getElementById('c');c.dispatchEvent(new PointerEvent('pointercancel',{pointerId:99}));});await pg.close();}
 // 3 storage: blocked / corrupt / quota
 for(const [name,script] of [['storage throws SecurityError',"Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});"],
   ['v41 forms: not JSON',"localStorage.setItem('pixelwar.v41.forms','{{{x');"],
   ['v41 forms: junk outlines',"localStorage.setItem('pixelwar.v41.forms',JSON.stringify([{name:'a',poly:[[NaN,1],[1e99,-5],['a',null]]},{name:'b',poly:[[0,0],[1,1]]},null,7,{poly:'zzz'},{name:'y'.repeat(9999),poly:Array(5000).fill([0.5,0.5])},{name:'t',poly:[[0,0],[1e-6,0],[0,1e-6]]},{name:'x',poly:[[0,0],[1,1],[1,0],[0,1]]},{name:'ok',poly:[[0.1,0],[0.9,0],[0.8,1],[0.2,1]]}].concat(Array(40).fill({name:'m',poly:[[0,0],[1,0],[1,1]]}))));"],
   ['v41 forms: huge array',"localStorage.setItem('pixelwar.v41.forms',JSON.stringify(Array(5000).fill({name:'q',poly:[[0.1,0],[0.9,0],[0.5,1]]})));"],
   ['v41 custom: absurd values',"localStorage.setItem('pixelwar.v41.custom',JSON.stringify({segHP:-1e99,wallDmg:1e99,koMargin:-9,knockK:1e99,brWaste:NaN,shapeLane:1e99,tint:'x'}));"],
   ['v4 prefs corrupt: stage/diff absurd',"localStorage.setItem('pixelwar.v4',JSON.stringify({stage:1e99,diff:-9,speed:NaN}));"],
   ['v4 forms: not JSON',"localStorage.setItem('pixelwar.v4.forms','{{{x');"],['v4 forms: junk cells',"localStorage.setItem('pixelwar.v4.forms',JSON.stringify([{name:'x',cells:[[1e99,-5],['a',null],[3,3]]},null,7,{cells:'zzz'},{name:'y'.repeat(9999),cells:Array(5000).fill([2,2])}].concat(Array(40).fill({name:'m',cells:[[3,3],[4,4],[5,5],[6,6],[7,7],[8,8],[9,9],[10,10]]}))));"],['v4 forms: huge array',"localStorage.setItem('pixelwar.v4.forms',JSON.stringify(Array(5000).fill({name:'q',cells:[[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7],[8,8]]})));"],['v4 custom: absurd rules',"localStorage.setItem('pixelwar.v4.custom',JSON.stringify({laneDef:99,brWaste:-1e9,arrowFront:1e99,reformSec:0,shockK:-5,breakLive:1e9,kSpeed:NaN,stage:77,aiLevel:42,ricoMode:9}));"],
   ['corrupt save: not JSON',"localStorage.setItem('pixelwar.v3','{{{not json');"],['corrupt save: array',"localStorage.setItem('pixelwar.v3','[1,2,3]');"],
   ['corrupt save: absurd values',"localStorage.setItem('pixelwar.v3',JSON.stringify({speed:1e99,density:-5,release:'x',cap:null,wins:{},losses:NaN}));"],
   ['corrupt save: huge strings',"localStorage.setItem('pixelwar.v3',JSON.stringify({speed:'9'.repeat(100000)}));"],
   ['corrupt custom: not JSON',"localStorage.setItem('pixelwar.v3.custom','{{{x');"],['corrupt custom: absurd values',"localStorage.setItem('pixelwar.v3.custom',JSON.stringify({poolSize:-1e99,burn:1e99,lives:-5,capDef:1e99,wcell:0,borrowSec:-3,shapeCD:NaN,rhoRef:0,kSurv:1e99,wallMax:1e99,maxBr:NaN,capMax:'x',sqN:Infinity,matchSec:0,prepSec:-9}));"],['corrupt custom: array',"localStorage.setItem('pixelwar.v3.custom','[1,2]');"],
   ['quota exceeded on write',"Storage.prototype.setItem=function(){throw new DOMException('quota','QuotaExceededError');};"]]){
  const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
  await pg.evaluateOnNewDocument(script);await pg.goto(FILE);await new Promise(r=>setTimeout(r,600));
  await pg.evaluate(()=>{__tt.step(1);__tt.step(300);__pw.startWith({});__tt.step(300);});const set=await pg.evaluate(()=>__pw.S.sides[0].set);
  ok(name+': boots + plays, settings in range',errs.length===0&&set.speed>=1&&set.speed<=10&&set.density>=1&&set.density<=10&&set.release>=1&&set.release<=10&&set.cap>=250&&set.cap<=10000,[errs,JSON.stringify(set)]);await pg.close();}
 // 3b absurd custom values are clamped into the schema and a match still runs
 {const pg=await b.newPage();await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
  await pg.evaluateOnNewDocument("localStorage.setItem('pixelwar.v3.custom',JSON.stringify({poolSize:-1e99,burn:1e99,lives:-5,capDef:1e99,wcell:0,borrowSec:-3,shapeCD:NaN,rhoRef:0,kSurv:1e99,wallMax:1e99,maxBr:99999,capMax:1e9,sqN:1e12,matchSec:0,prepSec:-9,wallHP:0}));");await pg.goto(FILE);await new Promise(r=>setTimeout(r,500));
  const r=await pg.evaluate(()=>{__pw.startWith(Object.assign({},__pw.CUS));__tt.step(1);__tt.step(2000);const C=__pw.CFG;return{hp:C.poolSize,bn:C.burn,lv:C.lives,cd:C.capDef,wc:C.wcell,bs:C.borrowSec,scd:C.shapeCD,rr:C.rhoRef,ks:C.kSurv,wm:C.wallMax,mb:C.maxBr,cm:C.capMax,sq:C.sqN,ms:C.matchSec,ps:C.prepSec,tick:__pw.S.tick,ent:__tt.getState().entityCount};});
  ok('absurd custom values are clamped (hp>0, wall<=sane, maxBr<=cap, pool/burn/lives/capDef/wcell/borrow/cooldown/rho sane, entities<=20000)',errs.length===0&&r.hp>=1&&r.hp<=10000&&r.bn>=1&&r.bn<=200&&r.lv>=1&&r.lv<=255&&r.cd<=10000&&r.cd>=250&&r.wc>=1&&r.bs>0&&r.scd>=1&&r.rr>=1&&isFinite(r.ks)&&r.wm<=5000&&r.mb<=8&&r.ent<=20000&&r.ms>=5,JSON.stringify(r)+errs);await pg.close();}
 // 3c STRESS: extreme-but-valid rules, player vs AI, shapes fired every cooldown, invariants every 200 ticks
 for(const [nm,cfg] of [['pool 1000 / burn 200 / 1 life / cap 10000 / cooldown 1s',{poolSize:1000,burn:200,lives:1,capDef:10000,shapeCD:1}],['pool 10000 / burn 1 / 255 lives / cap 10000 / cooldown 1s',{poolSize:10000,burn:1,lives:255,capDef:10000,shapeCD:1}],['old 3000 cap in Custom',{capDef:3000}]]){
  const pg=await open(b,360,800,2,{mobile:true});const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
  const r=await pg.evaluate(c=>{const P=__pw;__tt.setSeed(9);P.startWith(c);P.placeCircle(0,180,456);for(const k of[[180,400],[184,330],[190,260],[196,190],[196,130]])P.pathExtend(0,k[0],k[1]);P.startBattle();let bad=0,peak=0,shapes=0;
   for(let k=0;k<3000;k++){__tt.step(1);if(k%20===0){for(let t=0;t<7;t++)if(P.useShape(0,0,t))shapes++;}if(k%200===0){for(let sd=0;sd<2;sd++){const s=P.S.sides[sd];if(!(s.pool>=0&&s.pool<=P.CFG.poolSize&&isFinite(s.circle.hp)))bad++;peak=Math.max(peak,s.active);}}if(P.S.over)break;}
   return{bad,peak,shapes,over:P.S.over,tick:P.S.tick,cap:P.S.sides[0].set.cap};},cfg);
  ok('stress '+nm+': no errors, pool sane, peak active '+r.peak+', '+r.shapes+' shapes fired, ended '+r.over+' @'+r.tick,errs.length===0&&r.bad===0&&r.peak<=10000&&(cfg.capDef!==3000||r.peak<=3000)&&r.shapes>0,JSON.stringify(r)+errs);await pg.close();}
 // 4 extremes via hook
 {const pg=await open(b,360,800,2,{mobile:true});const r=await pg.evaluate(()=>{const o=[];const T=__tt;const bad=[NaN,Infinity,-Infinity,1e9,-1e9,null,undefined,{},'x'];
  for(const c of T.listCommands()){for(const v of bad){try{T.runCommand(c.name,(c.args||[]).map(()=>v));}catch(e){}}}
  T.step(1e9>>0&&600);return[T.getState().entityCount,__pw.S.phase];});
  ok('extreme command args (NaN/Inf/1e9/null/{}) never corrupt',(await inv(pg))===0,r);
  const f=await pg.evaluate(()=>{__tt.setSeed(3);__tt.step(1);const a=__tt.flood(Infinity),b=__tt.flood(1e9),c=__tt.flood(-5),d=__tt.flood(NaN);__tt.step(120);const s=__tt.getState();return[a,b,c,d,s.entityCount,s.caps.maxEntities];});
  ok('flood(Infinity/1e9/-5/NaN) respects caps (<=20000 entities)',f[4]<=20000&&f[4]<=f[5],f);
  ok('extremes: 0 JS errors',pg._errs.length===0,pg._errs);await pg.close();}
 // 5 restart spam / long soak with heap
 {const pg=await open(b,360,800,2,{mobile:true});const cdp=await pg.createCDPSession();
  const heap=async()=>{await cdp.send('HeapProfiler.collectGarbage');return (await pg.metrics()).JSHeapUsedSize/1048576;};
  const h0=await heap();
  await pg.evaluate(()=>{for(let g=0;g<300;g++){__tt.setSeed(g+1);__tt.step(1);__tt.step(200);document.getElementById('btnRestart').click();}});
  const h1=await heap();
  await pg.evaluate(()=>{__tt.setSeed(9);__tt.step(1);__pw.S.sides[0].circle.hp=1e9;__pw.S.sides[1].circle.hp=1e9;__pw.S.tick=0;for(let i=0;i<60;i++)__tt.step(300);});
  const h2=await heap();
  ok('300 restarts + 18000-tick soak: heap '+h0.toFixed(1)+' -> '+h1.toFixed(1)+' -> '+h2.toFixed(1)+' MB (no leak, <+3MB)',h2-h0<3,[h0,h1,h2]);
  ok('soak: invariants ok',(await inv(pg))===0&&pg._errs.length===0,pg._errs);await pg.close();}
 // 6 visibility + resize mid battle
 {const pg=await open(b,360,800,2,{mobile:true});await pg.evaluate(()=>{__tt.setSeed(5);__tt.step(1);});await pg.tap('#btnPause');await pg.tap('#btnPause');
  const t0=await pg.evaluate(()=>__pw.S.tick);await new Promise(r=>setTimeout(r,800));const t1=await pg.evaluate(()=>__pw.S.tick);
  const cdp=await pg.createCDPSession();await cdp.send('Emulation.setFocusEmulationEnabled',{enabled:false}).catch(()=>{});
  await pg.setViewport({width:800,height:360,deviceScaleFactor:2,isMobile:true,hasTouch:true});await new Promise(r=>setTimeout(r,300));
  const sz=await pg.evaluate(()=>({w:document.getElementById('c').width,h:document.getElementById('c').height,iw:innerWidth,ih:innerHeight,st:[document.getElementById('stage').clientWidth,document.getElementById('stage').clientHeight]}));
  await pg.screenshot({path:'/workspace/game/build-pixelwar041/out/shots/landscape-800x360.png'});
  await pg.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});
  ok('real-time battle advances ('+(t1-t0)+' ticks in 0.8 s)',t1-t0>20&&t1-t0<80,t1-t0);
  ok('rotate to landscape: canvas re-fits stage '+JSON.stringify(sz),Math.abs(sz.w-sz.st[0]*2)<=2&&Math.abs(sz.h-sz.st[1]*2)<=2,JSON.stringify(sz));
  ok('rotate: 0 errors + invariants',(await inv(pg))===0&&pg._errs.length===0,pg._errs);await pg.close();}
 await b.close();
 let f=0;for(const r of R){console.log(r.join(' '));if(r[0]==='FAIL')f++;}console.log('BUFF '+(R.length-f)+' pass / '+f+' fail');process.exit(f?1:0);})();
