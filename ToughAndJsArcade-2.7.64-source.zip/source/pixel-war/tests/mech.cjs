// Mechanics hard tests (collision math, ricochet, leash, recycle, walls, circles, meters/gaps, AI limits, determinism)
const {launch,open}=require('./lib.cjs');
const code=function(){
const P=window.__pw,R=[];const C=Object.assign({},P.C,{POOLV:10000,BURN:20,CIRCLE_DMG:1,SEG_HP:1000,WALL_DMG:5,PATH_MAX:520,WALL_MAX:220});
const ok=(name,cond,info)=>R.push({name,pass:!!cond,info:info===undefined?'':String(info)});
const seq=a=>{let i=0;return()=>a[Math.min(i++,a.length-1)];};
function fresh(seed){P.CFG.ricoMode=0;P.newGame(seed||1,false);P.setRnd(()=>0.5);}
function battle(seed){fresh(seed);P.startBattle();P.S.sides[0].set.cap=30;P.S.sides[1].set.cap=30;for(let i=0;i<2*C.CAPMAX;i++)if(P.pst[i])P.recall(i);P.S.sides[0].acc=0;P.S.sides[1].acc=0;}
function put(i,x,y,vx,vy,st){P.px[i]=x;P.py[i]=y;P.pvx[i]=vx;P.pvy[i]=vy;P.php[i]=2;P.pst[i]=st||3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;const side=i<C.CAPMAX?0:1;P.S.sides[side].active++;P.px[i]=x;P.py[i]=y;}
const setPool=(sd,v)=>{sd.pool=v;sd.circle.hp=v;};
function clear(){for(let i=0;i<2*C.CAPMAX;i++)if(P.pst[i])P.recall(i);}
const A=0,B=C.CAPMAX;
// ---- 1 collision damage
battle(1);put(A,100,200,50,0);put(B,102,200,-50,0);P.setRnd(seq([0.5,0.5,0.9,0.9]));P.collide();
ok('contact: both lose 1 HP (no miss, no ricochet)',P.php[A]===1&&P.php[B]===1,[P.php[A],P.php[B]]);
ok('contact: cooldown set, 2nd collide same tick no extra dmg',(P.collide(),P.php[A]===1&&P.php[B]===1));
P.pcd[A]=0;P.pcd[B]=0;P.setRnd(seq([0.5,0.5,0.9,0.9]));const k0=P.S.sides[0].stats.kills,a0=P.S.sides[0].active;P.collide();
ok('contact: second hit kills both -> recycled (pst=0) and active counts drop',P.pst[A]===0&&P.pst[B]===0&&P.S.sides[0].active===a0-1,[P.pst[A],P.pst[B],P.S.sides[0].active]);
ok('kills credited to opposite sides',P.S.sides[0].stats.kills===k0+1&&P.S.sides[1].stats.kills>=1);
// ---- 2 miss (deflect instead of damage)
battle(1);put(A,100,200,50,0);put(B,102,200,-50,0);P.setRnd(seq([0.1,0.1,0.5,0.5]));P.collide();
ok('miss: deflect INSTEAD of damage (hp stays 2)',P.php[A]===2&&P.php[B]===2);
ok('miss: head-on velocities reversed (A now moves -x, B +x)',P.pvx[A]<0&&P.pvx[B]>0,[P.pvx[A],P.pvx[B]]);
ok('miss: stun set (steering recovery delay)',P.pstun[A]>0&&P.pstun[B]>0);
// ---- 3 ricochet alongside hit
battle(1);put(A,100,200,50,0);put(B,102,200,-50,0);P.setRnd(seq([0.5,0.5,0.1,0.1,0.5,0.5]));P.collide();
ok('hit+ricochet: damaged AND deflected',P.php[A]===1&&P.php[B]===1&&P.pvx[A]<0&&P.pvx[B]>0);
// angle-based: reflection about contact normal; oblique approach
battle(1);put(A,100,200,50,50);put(B,102,200,0,0);P.setRnd(seq([0.1,0.1,0.5,0.5]));P.collide();
{const sp=Math.hypot(P.pvx[A],P.pvy[A]);ok('ricochet preserves speed',Math.abs(sp-70.71)<0.5,sp);ok('oblique reflect: A leaves in -x half-plane',P.pvx[A]<0.01,P.pvx[A]);}
// equal density: frequencies PER PIXEL (survive and push-away are independent rolls per pixel now)
{let survA=0,survB=0,dA=0,dB=0,hitA=0,hitB=0,ricoA=0,ricoB=0,N=6000;
 battle(2);const m=(a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;})(99);P.setRnd(m);
 for(let n=0;n<N;n++){clear();put(A,100,200,50,0);put(B,102,200,-50,0);P.collide();
  if(P.php[A]===2)survA++;else{hitA++;if(P.pst[A]&&P.pvx[A]<0)ricoA++;}
  if(P.php[B]===2)survB++;else{hitB++;if(P.pst[B]&&P.pvx[B]>0)ricoB++;}
  if(P.php[A]!==P.php[B])dA++;}
 ok('equal density: survive (miss) chance ~20% per pixel ('+(survA/N).toFixed(3)+'/'+(survB/N).toFixed(3)+')',Math.abs(survA/N-0.2)<0.03&&Math.abs(survB/N-0.2)<0.03);
 ok('equal density: ricochet-with-hit ~35% per pixel ('+(ricoA/hitA).toFixed(3)+'/'+(ricoB/hitB).toFixed(3)+')',Math.abs(ricoA/hitA-0.35)<0.04&&Math.abs(ricoB/hitB-0.35)<0.04);
 ok('equal density: the exchange is symmetric on average (|dmgA-dmgB| small), but rolls are independent per pixel',Math.abs(hitA-hitB)<N*0.05&&dA>N*0.1,[hitA,hitB,dA]);}
// ---- 4 friendly pass-through
battle(1);put(A,100,200,50,0);put(A+1,100.5,200,-50,0);P.collide();
ok('friendly pixels: no damage, no deflect',P.php[A]===2&&P.php[A+1]===2&&P.pvx[A]===50&&P.pvx[A+1]===-50);
// ---- 5 leash
battle(3);{const sd=P.S.sides[0];sd.paths[0].p=[100,450,100,446,100,442,100,438,100,434,100,430,100,426,100,422,100,418,100,414,100,410];
 put(A,100+80,430,0,0,2);P.pps[A]=20;P.movePixels();ok('leash: FOLLOW pixel >72 off path recalled',P.pst[A]===0);
 put(A,100+70,430,0,0,2);P.pps[A]=20;P.movePixels();ok('leash: FOLLOW pixel 70 off still active',P.pst[A]!==0);clear();
 put(A,100,410-60,0,-60,3);P.movePixels();ok('end drift: 60 past end still active',P.pst[A]===3);clear();
 put(A,100,410-80,0,-60,3);P.movePixels();ok('end drift: 80 past end recalled (leash from path end)',P.pst[A]===0);}
// ---- 6 recycle: slot reused, counts invariant
battle(4);{const sd=P.S.sides[0];sd.set.cap=30;let n=0;for(let i=0;i<30;i++)if(P.release(0))n++;const ex=P.release(0);
 ok('cap respected on release (30 max)',n===30&&!ex&&sd.active===30,[n,ex,sd.active]);
 P.recall(3);ok('recall frees a slot immediately',sd.active===29&&P.release(0)&&sd.active===30);
 let c=0;for(let i=0;i<C.CAPMAX;i++)if(P.pst[i])c++;ok('active counter equals live slots',c===sd.active,[c,sd.active]);}
// ---- 7 wall segment damage / deflect / break
function wallTest(){fresh(5);const sd=P.S.sides[0];P.placeCircle(0,60,456);const st=P.wallBegin(0,150,380);P.wallExtend(0,st,230,380);P.wallEnd(0,st);P.pathExtend(0,60,380);
 const foeSd=P.S.sides[1];P.placeCircle(1,300,40);P.S.phase='prep';return{sd,foeSd};}
{const {sd}=wallTest();P.startBattle();P.S.sides[0].set.cap=30;P.S.sides[1].set.cap=30;clear();
 const CH=P.cellHP();ok('walls: cut into small cells (4u), each cell its own '+CH+' HP',sd.segs.length>=18&&sd.segs.every(s=>s.hp===CH&&Math.hypot(s.x2-s.x1,s.y2-s.y1)<=4.01),sd.segs.length);
 const seg=sd.segs[5],mx=(seg.x1+seg.x2)/2,my=seg.y1;
 // enemy pixel from above (smaller y) moving down into wall
 put(B,mx,my-2.4,0,60,3);P.setRnd(seq([0.5,0.5,0.5,0.5]));P.pox[B]=mx;P.poy[B]=my-4;P.collide();
 ok('enemy hit = WALL_DMG to that cell only',seg.hp===CH-C.WALL_DMG&&sd.segs[4].hp===CH&&sd.segs[6].hp===CH,seg.hp);
 ok('pixel deflected back toward where it came from (up)',P.pvy[B]<0,P.pvy[B]);
 ok('pixel pushed out on its origin side',P.py[B]<my,P.py[B]);
 put(A,mx,my-2.4,0,60,3);P.pox[A]=mx;P.poy[A]=my-4;const h=seg.hp;P.collide();
 ok('OWN pixel is blocked by own wall (bounces back) and does NO damage',seg.hp===h&&P.pvy[A]<0&&P.pwc[A]>0,[seg.hp,h,P.pvy[A]]);clear();
 // hit from below too
 put(B,mx+0.2,my+2.4,0,-60,3);P.pox[B]=mx;P.poy[B]=my+4;P.collide();ok('hit from other side deflects to that side',P.pvy[B]>0&&seg.hp===CH-2*C.WALL_DMG,[P.pvy[B],seg.hp]);
 // random approach angles: deflected heading points back toward origin
 let bad=0;P.setRnd((a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;})(7));
 for(let n=0;n<300;n++){clear();const ang=-Math.PI/2+(n/300-0.5)*2.2+Math.PI;const ox=mx+Math.cos(ang)*5,oy=my+Math.sin(ang)*5;
  put(B,ox,oy,0,0,3);const v=60,tx=mx-ox,ty=my-oy,d=Math.hypot(tx,ty);P.pvx[B]=tx/d*v;P.pvy[B]=ty/d*v;P.px[B]=mx+Math.cos(ang)*2.6;P.py[B]=my+Math.sin(ang)*2.6;P.pox[B]=ox;P.poy[B]=oy;P.collide();
  if(P.pwc[B]===0)continue;const dot=P.pvx[B]*Math.cos(ang)+P.pvy[B]*Math.sin(ang);if(!(P.pvy[B]>0))bad++;void dot;}
 ok('300 angled hits (+-63deg off normal): always sent back to the origin side of the wall',bad===0,bad);
 // break after exactly CH hits (reset every cell first: the angled hits above may have chipped neighbours)
 clear();for(const g of sd.segs){g.hp=CH;g.alive=true;}P.buildWallGrid();let hits=0;P.setRnd(()=>0.5);
 while(seg.alive&&hits<4000){clear();put(B,mx,my-2.4,0,60,3);P.pox[B]=mx;P.poy[B]=my-4;P.collide();hits++;}
 ok('cell HP / WALL_DMG = broken after exactly '+CH/C.WALL_DMG+' hits',hits===CH/C.WALL_DMG&&!seg.alive&&seg.hp===0,hits);
 ok('only that cell disappears; neighbours remain full HP',sd.segs[4].alive&&sd.segs[6].alive&&sd.segs[4].hp===CH&&sd.segs[6].hp===CH&&P.wallsLeft(sd)===sd.segs.length-1);
 // a single dead cell is NOT yet a hole (pixels are wider than 4u); two adjacent dead cells are
 clear();put(B,mx,my-2.4,0,60,3);P.pox[B]=mx;P.poy[B]=my-4;P.collide();ok('one dead cell: pixel is still stopped by the neighbours',P.pvy[B]<0,P.pvy[B]);
 sd.segs[6].hp=0;sd.segs[6].alive=false;P.buildWallGrid();const gx=seg.x2;clear();put(B,gx,my-2.4,0,60,3);P.pox[B]=gx;P.poy[B]=my-4;P.collide();
 ok('two adjacent dead cells open a hole: enemy pixel passes through',P.pvy[B]===60,P.pvy[B]);}
// ---- 8 circle = pool burn + win
battle(6);{const me=P.S.sides[0],foe=P.S.sides[1];const BR=P.CFG.burn*C.CIRCLE_DMG;put(B,me.circle.x,me.circle.y,0,0,3);P.collide();
 ok('enemy pixel reaching my circle burns '+BR+' pixels from my pool and is recycled',me.pool===C.POOLV-BR&&me.circle.hp===me.pool&&P.pst[B]===0&&me.stats.burned===BR,[me.pool,me.circle.hp]);
 put(A,foe.circle.x+5,foe.circle.y,0,0,3);P.collide();ok('player pixel burns the enemy pool',foe.pool===C.POOLV-BR);
 put(A,me.circle.x+3,me.circle.y,0,0,3);P.collide();ok('own circle untouched by own pixels',me.pool===C.POOLV-BR);clear();
 setPool(foe,BR);me.paths[0].p=[foe.circle.x,foe.circle.y];put(A,foe.circle.x,foe.circle.y,0,0,3);P.tick();ok('pool hits 0 => win (phase over, winner 0)',P.S.over&&P.S.winner===0&&P.S.phase==='over'&&foe.pool===0);
 battle(6);setPool(P.S.sides[0],BR);P.S.sides[1].paths[0].p=[P.S.sides[0].circle.x,P.S.sides[0].circle.y];put(B,P.S.sides[0].circle.x,P.S.sides[0].circle.y,0,0,3);P.tick();ok('own pool 0 => lose',P.S.over&&P.S.winner===1);
 battle(6);setPool(P.S.sides[1],300);setPool(P.S.sides[0],500);P.S.tick=60*P.CFG.matchSec-1;P.tick();ok('timeout: larger pool wins (500 vs 300)',P.S.over&&P.S.winner===0);}
// ---- 9 meters & gaps
fresh(7);{const sd=P.S.sides[0];P.pathExtend(0,180,20);P.pathExtend(0,10,10);P.pathExtend(0,350,490);P.pathExtend(0,5,5);
 ok('path meter caps total (<=520)',P.pathUsed(sd)<=520+1e-6&&P.pathUsed(sd)>=516,P.pathUsed(sd));
 ok('main-path meter is larger than the defense meter (Jay: path meter is more)',C.PATH_MAX>C.WALL_MAX);
 // walls: try covering whole width
 let made=0;for(let r=0;r<12;r++){const st=P.wallBegin(0,8,300+r*12);if(!st)continue;P.wallExtend(0,st,352,300+r*12);P.wallEnd(0,st);made++;}
 ok('wall meter caps total (<=220)',P.wallUsed(sd)<=220+1e-6&&P.wallUsed(sd)>=208,P.wallUsed(sd));
 const iv=[];for(const s of sd.strokes)for(let k=0;k+3<s.pts.length;k+=2){iv.push([Math.min(s.pts[k],s.pts[k+2]),Math.max(s.pts[k],s.pts[k+2])]);}
 iv.sort((a,b)=>a[0]-b[0]);let cov=0,cur=-1e9,ce=-1e9;for(const v of iv){if(v[0]>ce){cov+=Math.max(0,ce-cur);cur=v[0];ce=v[1];}else ce=Math.max(ce,v[1]);}cov+=Math.max(0,ce-cur);
 ok('gaps guaranteed: x-projection of all walls covers <= 220 of 360 (gap >= 140)',cov<=221&&360-cov>=139,cov);
 ok('wall in enemy half rejected',P.wallBegin(0,100,100)===null);
 ok('wall on own circle rejected',P.wallBegin(0,P.S.sides[0].circle.x,P.S.sides[0].circle.y)===null);
 ok('non-finite inputs rejected',P.pathExtend(0,NaN,1)===0&&P.wallBegin(0,Infinity,300)===null&&!P.placeCircle(0,NaN,NaN));
 P.startBattle();const used=P.pathUsed(sd);P.pathExtend(0,200,300);ok('after START the player path/walls are locked',P.pathUsed(sd)===used&&P.wallBegin(0,100,400)===null&&!P.eraseAt(0,sd.paths[0].p[8],sd.paths[0].p[9]));}
// erase refund
fresh(8);{const sd=P.S.sides[0];P.pathExtend(0,200,300);const u=P.pathUsed(sd);P.eraseAt(0,sd.paths[0].p[40],sd.paths[0].p[41]);ok('erase path trims and frees meter',P.pathUsed(sd)<u,[u,P.pathUsed(sd)]);
 const st=P.wallBegin(0,100,300);P.wallExtend(0,st,200,300);P.wallEnd(0,st);const w=P.wallUsed(sd);P.eraseAt(0,150,300);ok('erase wall stroke frees meter',w>0&&P.wallUsed(sd)===0,[w,P.wallUsed(sd)]);
 P.placeCircle(0,200,460);ok('circle clamped to bottom strip',P.S.sides[0].circle.y>=440&&P.S.sides[0].circle.y<=472);P.placeCircle(0,-500,50);ok('circle x/y clamped (x>=28, y in strip)',P.S.sides[0].circle.x>=28&&P.S.sides[0].circle.y>=440);
 P.pathExtend(0,P.S.sides[0].circle.x,300);P.placeCircle(0,100,456);ok('moving the circle restarts the path (starts from circle)',P.pathUsed(sd)===0&&sd.paths[0].p[0]===100);}
// ---- 10 AI obeys same limits, 300 seeds
{let bad=[];for(let s=1;s<=300;s++){P.newGame(s,false);P.startBattle();for(const sd of P.S.sides){const p=sd.paths[0].p,n=p.length/2;
  const z=sd.id===0?(y=>y>=250&&y<=494):(y=>y<=250&&y>=6);
  if(P.pathUsed(sd)>520+1e-6)bad.push('path'+s);if(P.wallUsed(sd)>220+1e-6)bad.push('wall'+s);if(sd.strokes.length>12)bad.push('strokes'+s);
  if(Math.hypot(p[0]-sd.circle.x,p[1]-sd.circle.y)>0.01)bad.push('start'+s);
  for(let k=0;k<p.length;k+=2)if(!(p[k]>=4&&p[k]<=356&&p[k+1]>=4&&p[k+1]<=496)){bad.push('bounds'+s);break;}
  for(const st of sd.strokes)for(let k=0;k<st.pts.length;k+=2)if(st.pts[k]<6||st.pts[k]>354||!z(st.pts[k+1])||Math.hypot(st.pts[k]-sd.circle.x,st.pts[k+1]-sd.circle.y)<=30)bad.push('wallzone'+s);
  for(let k=1;k<n;k++){const d=Math.hypot(p[k*2]-p[k*2-2],p[k*2+1]-p[k*2-1]);if(Math.abs(d-4)>1e-3){bad.push('spacing'+s);break;}}
  const set=sd.set;if(set.speed<1||set.speed>10||set.cap>C.CAPMAX)bad.push('set'+s);
  if(sd.id===1&&P.pathUsed(sd)<250)bad.push('aiShort'+s);}}
 ok('AI: 300 seeds, same meters/zones/spacing/limits as player, no extras',bad.length===0,bad.slice(0,5).join(','));}
// AI cannot see player plan: AI plan independent of player path/walls
{P.newGame(11,false);P.pathExtend(0,200,100);const w=P.wallBegin(0,100,300);P.wallExtend(0,w,200,300);P.startBattle();const a=JSON.stringify(P.S.sides[1].paths[0].p);
 P.newGame(11,false);P.startBattle();const b=JSON.stringify(P.S.sides[1].paths[0].p);ok('AI plan does not depend on player path/walls (only circle pos)',a===b);}
// ---- 11 lane following (side1 suppressed)
battle(12);{const sd=P.S.sides[0];sd.set.cap=C.CAPMAX;sd.set.release=10;P.pathExtend(0,0,0); // none (locked) -> use planner path
 P.newGame(12,false);P.setRnd(()=>0.5);const mrnd=(a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;})(3);P.setRnd(mrnd);
 P.placeCircle(0,180,456);P.pathExtend(0,170,380);P.pathExtend(0,180,300);P.startBattle();const s0=P.S.sides[0];s0.set.cap=C.CAPMAX;s0.set.release=8;
 const hwA=P.laneHW(s0.set);let tot=0,inl=0,maxd=0;
 for(let t=0;t<900;t++){P.tick();for(let i=C.CAPMAX;i<2*C.CAPMAX;i++)if(P.pst[i])P.recall(i);
  if(t>300&&t%10===0){const p=s0.paths[0].p;for(let i=0;i<C.CAPMAX;i++)if(P.pst[i]===2){let bd=1e9;for(let k=0;k<p.length;k+=2){const d=Math.hypot(P.px[i]-p[k],P.py[i]-p[k+1]);if(d<bd)bd=d;}tot++;if(bd<=hwA*1.35+3)inl++;if(bd>maxd)maxd=bd;}}}
 ok('following pixels stay inside the lane ('+(100*inl/tot).toFixed(1)+'% within 1.35x half-width, max '+maxd.toFixed(1)+')',inl/tot>0.95&&maxd<72,tot);
 // end behaviour: pixels past the end, never beyond leash+step
 const p=s0.paths[0].p,ex=p[p.length-2],ey=p[p.length-1];let far=0,cnt=0;const dists=[];
 for(let t=0;t<600;t++){P.tick();for(let i=C.CAPMAX;i<2*C.CAPMAX;i++)if(P.pst[i])P.recall(i);for(let i=0;i<C.CAPMAX;i++)if(P.pst[i]===3){const d=Math.hypot(P.px[i]-ex,P.py[i]-ey);if(d>far)far=d;dists.push(d);cnt++;}}
 ok('path end: pixels go straight on past the end ('+cnt+' samples) and stay within leash '+far.toFixed(1)+'<=74',cnt>50&&far<=74,far);
 // spread grows with time since end: compare lateral spread near vs far
 let nearL=[],farL=[];const tx=ex-p[p.length-6],ty=ey-p[p.length-5],tl=Math.hypot(tx,ty)||1;
 for(let i=0;i<C.CAPMAX;i++)if(P.pst[i]===3){const dx=P.px[i]-ex,dy=P.py[i]-ey,along=(dx*tx+dy*ty)/tl,lat=(-dx*ty+dy*tx)/tl;if(along>5&&along<25)nearL.push(Math.abs(lat));else if(along>=40)farL.push(Math.abs(lat));}
 const avg=a=>a.reduce((x,y)=>x+y,0)/(a.length||1);
 ok('drift: lateral spread grows with distance past the end ('+avg(nearL).toFixed(1)+' -> '+avg(farL).toFixed(1)+')',nearL.length>3&&farL.length>3?avg(farL)>avg(nearL):true,[nearL.length,farL.length]);}
// ---- 12 slider mappings
{const lo={speed:1,density:5,release:5,cap:C.CAPMAX},hi={speed:10,density:5,release:5,cap:C.CAPMAX};
 ok('SPEED slow = wider lane; fast = thinner',P.laneHW(lo)>P.laneHW(hi));ok('speed does not change release rate (independent)',P.rateOf(lo)===P.rateOf(hi));
 ok('DENSITY high = tighter lane',P.laneHW({speed:5,density:10})<P.laneHW({speed:5,density:1}));
 ok('RELEASE rate monotonic',P.rateOf({release:10})>P.rateOf({release:1}));
 ok('max speed per tick < wall half-thickness+pixel (no tunnelling)',P.speedOf({speed:10})*1.12/60<3.0,P.speedOf({speed:10})*1.12/60);
 ok('max closing speed per tick < 2*CONTACT (no pixel tunnelling)',2*P.speedOf({speed:10})*1.12/60<2*3.5,2*P.speedOf({speed:10})*1.12/60);}
// ---- 13 long run invariants incl. both AI, counts
{P.newGame(21,false);P.setRnd(P.S&&(a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;})(21));P.aiPlan(0);P.startBattle();let bad=0,maxA=[0,0],cc=0;
 for(let t=0;t<7000&&!P.S.over;t++){P.tick();for(let sd=0;sd<2;sd++){let c=0;for(let i=sd*C.CAPMAX;i<sd*C.CAPMAX+C.CAPMAX;i++)if(P.pst[i]){c++;if(!isFinite(P.px[i]+P.py[i]+P.pvx[i]+P.pvy[i]))bad++;if(P.php[i]<1||P.php[i]>2)bad++;}
  if(c!==P.S.sides[sd].active)bad++;maxA[sd]=Math.max(maxA[sd],c);}cc++;}
 ok('7000-tick AI vs planner: counts/hp/finite invariants hold, cap<=CAPMAX ('+maxA+')',bad===0&&maxA[0]<=C.CAPMAX&&maxA[1]<=C.CAPMAX,[bad,cc]);
 ok('match resolved or running legally',P.S.phase==='over'||P.S.phase==='battle');}
// ---- 14 stress at the max cap
{P.newGame(33,false);P.aiPlan(0);P.startBattle();const sd0=P.S.sides[0],sd1=P.S.sides[1];sd0.set.cap=C.CAPMAX;sd1.set.cap=C.CAPMAX;sd0.set.release=10;sd1.set.release=10;setPool(sd0,1e9);setPool(sd1,1e9);
 let bad=0,pk=[0,0],t0=performance.now(),uniq=true;
 for(let t=0;t<2400;t++){P.tick();if(t%100===99){for(let sd=0;sd<2;sd++){let c=0;for(let i=sd*C.CAPMAX;i<sd*C.CAPMAX+C.CAPMAX;i++)if(P.pst[i]){c++;if(!isFinite(P.px[i]+P.py[i]+P.pvx[i]+P.pvy[i])||P.php[i]<1||P.php[i]>2)bad++;}
   if(c!==P.S.sides[sd].active||c>C.CAPMAX)bad++;pk[sd]=Math.max(pk[sd],c);}}}
 const ms=(performance.now()-t0)/2400;
 ok('STRESS: 2400 ticks at cap '+C.CAPMAX+'/side, release 10: counts/hp/finite hold, peak '+pk,bad===0&&pk[0]>=0.5*C.CAPMAX&&pk[1]>=0.5*C.CAPMAX,[bad,pk]);
 ok('STRESS: sim tick average '+ms.toFixed(2)+' ms (desktop, unthrottled, 10k-pool cap) < 12 ms',ms<12,ms);
 ok('STRESS: both sides took damage (collisions happen at cap)',sd0.stats.kills+sd1.stats.kills>100,[sd0.stats.kills,sd1.stats.kills]);}
// ---- 15 pool integrity
{P.newGame(34,false);P.aiPlan(0);P.startBattle();const sd=P.S.sides[0];sd.set.cap=C.CAPMAX;let n=0;while(P.release(0)&&n<C.CAPMAX+50)n++;let live=0;for(let i=0;i<C.CAPMAX;i++)if(P.pst[i])live++;
 ok('pool: releasing until refused yields exactly CAPMAX unique live pixels',n===C.CAPMAX&&live===C.CAPMAX&&sd.active===C.CAPMAX,[n,live,sd.active]);
 for(let i=0;i<C.CAPMAX;i+=2)P.recall(i);let n2=0;while(P.release(0)&&n2<C.CAPMAX)n2++;let live2=0;for(let i=0;i<C.CAPMAX;i++)if(P.pst[i])live2++;
 ok('pool: recycled slots are reused, no duplicates/leaks',n2===C.CAPMAX/2&&live2===C.CAPMAX&&sd.active===C.CAPMAX,[n2,live2]);}
return R;};
(async()=>{const b=await launch();const pg=await open(b,360,800,2);
 const R=await pg.evaluate('('+code.toString()+')()');let p=0,f=0;for(const r of R){if(r.pass)p++;else f++;console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'  ['+r.info+']'));}
 console.log('errors',pg._errs);console.log('MECH '+p+' pass / '+f+' fail');await b.close();process.exit(f||pg._errs.length?1:0);})();
