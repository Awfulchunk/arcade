
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar041/out/hits/collisions/';fs.mkdirSync(OUT,{recursive:true});
for(const f of fs.readdirSync(OUT))if(f.endsWith('.png'))fs.unlinkSync(OUT+f);
const HELP=`
window.__H={mk(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};},
 game(seed,cfg){const P=__pw;P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed,false);P.setRnd(this.mk(seed));return P;},
 main(P,pts){for(const k of pts||[[180,400],[184,330],[190,260],[196,190],[196,130]])P.pathExtend(0,k[0],k[1]);},
 quiet(P){const f=P.S.sides[1];f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];f.circle.x=60;f.circle.y=44;for(let i=P.POOL;i<2*P.POOL;i++)if(P.pst[i])P.recall(i);},
 squad(P){let n=0,sx=0,sy=0,mnx=1e9,mxx=-1e9,mny=1e9,mxy=-1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){n++;sx+=P.px[i];sy+=P.py[i];mnx=Math.min(mnx,P.px[i]);mxx=Math.max(mxx,P.px[i]);mny=Math.min(mny,P.py[i]);mxy=Math.max(mxy,P.py[i]);}return n?{n,x:sx/n,y:sy/n,w:mxx-mnx,h:mxy-mny}:null;},
 shot(P){P.S.paused=true;P.draw();}};`;
const SH={0:'line',1:'arrow',2:'wedge',4:'diamond',5:'double',6:'spiral'};
(async()=>{const b=await launch();let pg;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const L=async()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 const fresh=async dpr=>{pg=await open(b,360,800,dpr||2,{mobile:true});await pg.evaluate(HELP);};
 const snap=async(name,clip)=>{await sleep(150);const o={path:OUT+name+'.png'};if(clip)o.clip=clip;await pg.screenshot(o);};
 const zoom=async(name,cx,cy,w,h)=>{const l=await L();await pg.evaluate(()=>{document.getElementById('tabF').click();__H.shot(__pw);});await snap(name,{x:l.x+(cx-w/2)*l.s,y:l.y+(cy-h/2)*l.s,width:w*l.s,height:h*l.s});};
 const log=[];
 // ---------- A density matchups: head-on on the same line, same flow & pace, only DENSITY differs
 const duel=async(name,dm,de)=>{
  const sc=async dpr=>{await fresh(dpr);return pg.evaluate((dm,de)=>{const P=__H.game(4);P.placeCircle(0,180,456);P.pathExtend(0,180,400);P.pathExtend(0,180,300);P.pathExtend(0,180,200);P.pathExtend(0,180,150);
   P.placeCircle(1,180,44);const E=P.S.sides[1],m=P.S.sides[0];for(const q of[[180,100],[180,200],[180,300],[180,350]])P.pathExtend(1,q[0],q[1]);
   m.set.density=dm;E.set.density=de;m.set.release=6;E.set.release=6;m.set.speed=5;E.set.speed=5;m.human=true;E.human=true;P.startBattle();
   for(let t=0;t<330;t++)P.tick();const st=a=>({kills:a.stats.kills,defl:a.stats.defl,surv:a.stats.surv,pushed:a.stats.pushed,rico:a.stats.ricochets});
   __H.shot(P);return{mine:st(m),foe:st(E),act:[m.active,E.active],hw:[P.laneHW(m.set),P.laneHW(E.set)]};},dm,de);};
  let r=await sc(2);await snap(name);log.push(name+' '+JSON.stringify(r));console.log(name,JSON.stringify(r));await pg.close();
  await sc(4);await zoom(name+'-zoom',180,250,150,110);await pg.close();};
 await duel('A1-packed-BLUE-d10-vs-loose-RED-d2',10,2);
 await duel('A2-loose-BLUE-d2-vs-packed-RED-d10',2,10);
 await duel('A3-equal-d6-vs-d6',6,6);
 await duel('A4-dense-d10-vs-dense-d10-stalemate',10,10);
 // ---------- B each shape fired into a mid-density enemy line (zoom at the crossing), stats
 for(const t of [0,1,2,4,5,6]){const name='B'+(t===0?0:t===1?1:t===2?2:t===4?3:t===5?4:5)+'-'+SH[t]+'-vs-enemy-path';
  const sc=async dpr=>{await fresh(dpr);return pg.evaluate(t=>{const P=__H.game(2);P.placeCircle(0,180,456);__H.main(P,[[180,400],[180,300],[180,200],[180,140]]);P.placeCircle(1,300,50);const E=P.S.sides[1],m=P.S.sides[0];for(const q of[[300,150],[300,250],[240,250],[180,250],[120,250],[60,250]])P.pathExtend(1,q[0],q[1]);
   m.set.release=5;m.set.density=7;m.set.speed=5;E.set.release=7;E.set.density=8;E.set.speed=4;m.human=true;E.human=true;P.startBattle();
   for(let k=0;k<200;k++)P.tick();P.useShape(0,0,t);let t0=-1;for(let k=0;k<800;k++){P.tick();let ny=1e9;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4&&P.py[i]<ny)ny=P.py[i];if(t0<0&&ny<262)t0=k;if(t0>=0&&k===t0+50)break;}
   let alive=0,beyond=0;for(let i=0;i<P.POOL;i++)if(P.pst[i]===4){alive++;if(P.py[i]<240)beyond++;}__H.shot(P);return{alive,beyondLine:beyond,defl:m.stats.defl,kills:[m.stats.kills,E.stats.kills]};},t);};
  let r=await sc(4);await zoom(name,180,250,130,100);console.log(name,JSON.stringify(r));log.push(name+' '+JSON.stringify(r));await pg.close();}
 // ---------- C branch collisions: my branch crosses the enemy's branch and main path
 {const sc=async dpr=>{await fresh(dpr);return pg.evaluate(()=>{const P=__H.game(5,{maxBr:3,brMax:300});P.placeCircle(0,100,456);for(const q of[[100,400],[100,300],[100,160]])P.pathExtend(0,q[0],q[1]);
   const pos=(side,y)=>{const p=P.S.sides[side].paths[0].p;let bi=0,bd=1e9;for(let k=0;k<p.length;k+=2){const d=Math.abs(p[k+1]-y);if(d<bd){bd=d;bi=k;}}return[p[bi],p[bi+1]];};
   let a=pos(0,370);const B0=P.branchBegin(0,a[0],a[1]);for(const q of[[130,350],[170,310],[220,260],[262,218]])P.branchExtend(0,B0,q[0],q[1]);P.branchEnd(0,B0);
   P.placeCircle(1,260,44);for(const q of[[260,100],[260,200],[260,340]])P.pathExtend(1,q[0],q[1]);
   a=pos(1,300);const B1=P.branchBegin(1,a[0],a[1]);for(const q of[[225,265],[190,230],[140,180],[100,140]])P.branchExtend(1,B1,q[0],q[1]);P.branchEnd(1,B1);
   const m=P.S.sides[0],E=P.S.sides[1];m.set.release=6;E.set.release=6;m.set.density=6;E.set.density=6;m.human=true;E.human=true;P.startBattle();
   for(let k=0;k<420;k++)P.tick();__H.shot(P);const st=a=>({kills:a.stats.kills,defl:a.stats.defl,surv:a.stats.surv});return{br:[B0&&B0.id,B1&&B1.id],mine:st(m),foe:st(E),pool:[m.pool,E.pool]};});};
  let r=await sc(2);await snap('C1-branch-vs-branch-vs-main');console.log('C1',JSON.stringify(r));log.push('C1 '+JSON.stringify(r));await pg.close();
  await sc(4);await zoom('C1-branch-crossing-zoom',220,260,150,110);await pg.close();}
 // ---------- D two cut-short main paths: pixels drift off the path ends and clash freely (like the sketches)
 {const sc=async(dpr,frame)=>{await fresh(dpr);return pg.evaluate(frame=>{const P=__H.game(7);P.placeCircle(0,100,456);for(const q of[[112,400],[130,350],[150,300]])P.pathExtend(0,q[0],q[1]);
   P.placeCircle(1,260,44);for(const q of[[248,100],[230,150],[210,200]])P.pathExtend(1,q[0],q[1]);
   const m=P.S.sides[0],E=P.S.sides[1];m.set.release=6;E.set.release=6;m.set.density=6;E.set.density=6;m.human=true;E.human=true;P.startBattle();
   let t=0,first=-1;for(;t<frame.stop;t++){P.tick();if(first<0&&m.stats.kills+E.stats.kills>0)first=t;}
   let drift=[0,0];for(let i=0;i<2*P.POOL;i++)if(P.pst[i]===3)drift[i<P.POOL?0:1]++;__H.shot(P);return{first,drift,kills:[m.stats.kills,E.stats.kills],defl:m.stats.defl,pool:[m.pool,E.pool]};},frame);};
  for(const [nm,stop] of [['D1-cut-short-paths-first-contact',175],['D2-cut-short-paths-clashing',300],['D3-cut-short-paths-steady-clash',600]]){
   let r=await sc(2,{stop});await snap(nm);console.log(nm,JSON.stringify(r));log.push(nm+' '+JSON.stringify(r));await pg.close();}
  await sc(4,{stop:300});await zoom('D2-clash-zoom',180,250,160,120);await pg.close();}
 fs.writeFileSync(OUT+'stats.txt',log.join('\n')+'\n');
 await b.close();})();
