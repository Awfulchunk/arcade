// 0.2 touch/UI flows: branch drawing, shape tab, chips, live edits in battle, menu/custom/help, prep timer
const {launch,open}=require('./lib.cjs');
const R=[];const ok=(n,c,i)=>{R.push([c?'PASS':'FAIL',n,c?'':String(i)]);};
(async()=>{try{await main();}catch(e){for(const r of R)console.log(r.join(' '));console.log('CRASH',e.stack.split('\n').slice(0,4).join(' | '));process.exit(2);}})();
async function main(){const b=await launch();
 for(const [w,h,d] of [[360,800,2],[320,568,2]]){
 const pg=await open(b,w,h,d,{mobile:true});const tag=w+'x'+h+' ';
 const L=async()=>pg.evaluate(()=>{const r=document.getElementById('c').getBoundingClientRect(),l=__pw.L;return{x:r.left+l.LX,y:r.top+l.LY,s:l.LS};});
 async function tdrag(pts){const l=await L();const q=pts.map(p=>({x:l.x+p[0]*l.s,y:l.y+p[1]*l.s}));const t=await pg.touchscreen.touchStart(q[0].x,q[0].y);for(const p of q.slice(1))await t.move(p.x,p.y);await t.end();}
 const ev=(f,a)=>pg.evaluate(f,a);const tp=async sel=>{await new Promise(r=>setTimeout(r,160));try{await pg.tap(sel);}catch(e){await new Promise(r=>setTimeout(r,400));await pg.tap(sel);}};
 await ev(()=>__tt.setSeed(41));
 const c=await ev(()=>({x:__pw.S.sides[0].circle.x,y:__pw.S.sides[0].circle.y}));
 await tp('#tMain');await tp('#tMain');await tdrag([[c.x,c.y],[c.x+4,c.y-80],[c.x+20,c.y-170],[c.x+10,c.y-260],[c.x-20,c.y-340]]);
 let pu=await ev(()=>__pw.pathUsed(__pw.S.sides[0]));ok(tag+'main path drawn by touch ('+Math.round(pu)+')',pu>250,pu);
 const pm=await ev(()=>{const p=__pw.S.sides[0].paths[0].p;return[p[60],p[61],p[80],p[81]];});
 await tp('#tBranch');await tp('#tBranch');await tdrag([[pm[0],pm[1]],[pm[0]+40,pm[1]-20],[pm[0]+90,pm[1]-60],[pm[0]+120,pm[1]-110]]);
 let br=await ev(()=>({n:__pw.brCount(__pw.S.sides[0]),sel:__pw.selP,lab:document.getElementById('tP').textContent,used:__pw.S.sides[0].paths[1]?__pw.brUsed(__pw.S.sides[0].paths[1]):0}));
 ok(tag+'BRANCH tool draws from the main path; meter label switches to the branch ('+br.lab+')',br.n===1&&br.sel===1&&/^BR1/.test(br.lab)&&br.used>40&&br.used<=140,JSON.stringify(br));
 await tdrag([[30,300],[60,250],[90,230]]);ok(tag+'BRANCH started away from the path is refused',await ev(()=>__pw.brCount(__pw.S.sides[0]))===1);
 await tp('#tabS');
 const chips=await ev(()=>[...document.querySelectorAll('#chips button')].map(e=>e.textContent));ok(tag+'SHAPE tab lists MAIN + BR1 chips ('+chips+')',chips.join()==='MAIN,BR1',chips);
 const sb=await ev(()=>[...document.querySelectorAll('#shbtns button')].map(e=>e.id+':'+e.children[0].textContent));ok(tag+'SHAPE tab shows 6 ability buttons, no RING ('+sb.join(' ')+')',sb.join()==='shb0:LINE,shb1:ARROW,shb2:WEDGE,shb4:DIAM,shb5:DOUBLE,shb6:SPIRAL',sb);
 await tp('#shb1');ok(tag+'shape buttons do nothing in prep (message only)',await ev(()=>__pw.S.sides[0].shReady.every(x=>x===0)&&__pw.S.sides[0].sq.every(x=>!x)));
 await ev(()=>{const set=(id,v)=>{const e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));};set('sAt',40);});
 await tp('#chips button:nth-child(2)');await ev(()=>{const e=document.getElementById('sSh');e.value=65;e.dispatchEvent(new Event('input',{bubbles:true}));});
 const v=await ev(()=>({at:__pw.S.sides[0].paths[1].sh.at,sh:__pw.S.sides[0].paths[1].share}));ok(tag+'FORM AT / SHARE sliders drive the selected path',v.at===40&&v.sh===65,JSON.stringify(v));
 await tp('#tabF');await ev(()=>{const set=(id,v)=>{const e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));};set('sSD',9);set('sCo',3);});
 ok(tag+'FLOW tab: shape density + compactness sliders drive settings',await ev(()=>__pw.S.sides[0].set.sdens===9&&__pw.S.sides[0].set.compact===3));
 await tp('#tabD');await tp('#tStart');await new Promise(r=>setTimeout(r,1200));
 const bs=await ev(()=>({ph:__pw.S.phase,tab:document.getElementById('pF').style.display,circle:document.getElementById('tCircle').style.display,branch:document.getElementById('tBranch').style.display,start:document.getElementById('tStart').style.display}));
 ok(tag+'START: battle runs, FLOW tab opens, circle/path tools hidden, live branch/wall tools stay',bs.ph==='battle'&&bs.tab==='block'&&bs.circle==='none'&&bs.start==='none'&&bs.branch==='block',JSON.stringify(bs));
 await tp('#tabS');await tp('#chips button:first-child');await tp('#shb1');await new Promise(r=>setTimeout(r,300));
 const cu=await ev(()=>({cd:document.getElementById('shb1').classList.contains('cd'),txt:document.getElementById('shb1').children[1].textContent,w:document.getElementById('shb1').children[2].style.width,other:document.getElementById('shb2').children[1].textContent,left:__pw.shapeLeft(0,1),armed:!!__pw.S.sides[0].paths[0].arm||__pw.S.sides[0].sq.some(x=>x)}));
 ok(tag+'tapping ARROW in battle fires it: its button shows a cooldown ('+cu.txt+'), the others stay READY ('+cu.other+')',cu.cd&&/s$/.test(cu.txt)&&(cu.other==='READY'||cu.other==='wait')&&cu.left>0&&cu.armed,JSON.stringify(cu));
 const l0=await ev(()=>__pw.shapeLeft(0,1));await tp('#shb1');const l1=await ev(()=>({l:__pw.shapeLeft(0,1),m:__pw.S.msg}));ok(tag+'tapping a recharging shape does not refire it (cooldown kept counting down '+l0+' -> '+l1.l+', msg: '+l1.m+')',l1.l<=l0&&/recharging/.test(l1.m));
 ok(tag+'OUT readout and pool-as-HP in HUD ('+await ev(()=>document.getElementById('lCa').textContent+' | '+document.getElementById('tY').textContent)+')',await ev(()=>/^OUT \d+/.test(document.getElementById('lCa').textContent)&&/^YOU \d+/.test(document.getElementById('tY').textContent)));
 ok(tag+'FLOW tab labels: PACE / DENSITY / FLOW',await ev(()=>['lSp','lDe','lRe'].map(i=>document.getElementById(i).textContent.split(' ')[0]).join()==='PACE,DENSITY,FLOW'));
 await tp('#tabD');await tp('#tBranch');await tp('#tBranch');const pm2=await ev(()=>{const p=__pw.S.sides[0].paths[0].p;return[p[40],p[41]];});await tdrag([[pm2[0],pm2[1]],[pm2[0]-50,pm2[1]-30],[pm2[0]-90,pm2[1]-70]]);
 ok(tag+'live: a second branch can be drawn during battle',await ev(()=>__pw.brCount(__pw.S.sides[0]))===2);
 await tp('#tWall');await tp('#tWall');await tdrag([[40,380],[110,380]]);ok(tag+'live: a wall can be built during battle and is collidable',await ev(()=>__pw.S.sides[0].segs.length)>0);
 // menu
 await tp('#btnMenu');if(await ev(()=>__pw.view)==='app')await tp('#btnMenu');let vw=await ev(()=>({v:__pw.view,paused:__pw.S.paused,app:document.getElementById('app').style.display,menu:document.getElementById('menu').style.display}));ok(tag+'MENU opens, game pauses',vw.v==='menu'&&vw.paused&&vw.app==='none'&&vw.menu==='flex',JSON.stringify(vw));
 await tp('#mResume');const tk=await ev(()=>__pw.S.tick);await tp('#btnPause');await new Promise(r=>setTimeout(r,200));ok(tag+'RESUME returns to the match',await ev(()=>__pw.view)==='app');
 await tp('#btnMenu');await tp('#mHelp');ok(tag+'HELP view (short text)',await ev(()=>__pw.view==='help'&&document.querySelectorAll('#hbody p').length<=14));await tp('#hBack');
 await tp('#mCustom');const rows=await ev(()=>document.querySelectorAll('#clist .crow').length);ok(tag+'CUSTOM GAME lists every rule ('+rows+' rows)',rows>=30,rows);
 await ev(()=>{const r=[...document.querySelectorAll('#clist .crow')].find(x=>/Redraw branches/.test(x.textContent));r.querySelector('button').click();});
 await ev(()=>{const r=[...document.querySelectorAll('#clist .crow')].find(x=>/^Pool = circle HP/.test(x.textContent));const e=r.querySelector('input');e.value=3000;e.dispatchEvent(new Event('input',{bubbles:true}));});
 await tp('#cPlay');const cf=await ev(()=>({hp:__pw.S.sides[0].circle.hp,liveBr:__pw.CFG.liveBr,ph:__pw.S.phase,v:__pw.view}));ok(tag+'CUSTOM PLAY starts a prep with the edited rules',cf.hp===3000&&cf.liveBr===0&&cf.ph==='prep'&&cf.v==='app',JSON.stringify(cf));
 await pg.reload();await new Promise(r=>setTimeout(r,600));const saved=await ev(()=>JSON.parse(localStorage.getItem('pixelwar.v41.custom')||'{}'));ok(tag+'custom rules persist across reloads',saved.poolSize===3000&&saved.liveBr===0,JSON.stringify(saved).slice(0,80));
 await tp('#btnMenu');await tp('#mQuick');ok(tag+'QUICK MATCH uses the default rules (custom untouched)',await ev(()=>__pw.CFG.poolSize===10000&&__pw.CFG.liveBr===1));
 await tp('#btnMenu');await tp('#mCustom');await tp('#cReset');ok(tag+'RESET restores defaults',await ev(()=>__pw.CUS.poolSize===10000&&__pw.CUS.liveBr===1));await tp('#cBack');await tp('#mResume');
 await ev(()=>__pw.startWith({prepSec:1}));await new Promise(r=>setTimeout(r,2000));ok(tag+'prep timer starts the battle by itself',await ev(()=>__pw.S.phase)==='battle');
 ok(tag+'0 JS errors',pg._errs.length===0,pg._errs);await pg.close();}
 await b.close();let f=0;for(const r of R){console.log(r.join(' '));if(r[0]==='FAIL')f++;}console.log('UI2 '+(R.length-f)+' pass / '+f+' fail');process.exit(f?1:0);}
