// SOFT TEST 0.4: one quick functional check per mechanic / physics behaviour. Prints "N. NAME: PASS|FAIL - what was seen".
const {launch,open}=require('./lib.cjs');const fs=require('fs');
const OUT='/workspace/game/build-pixelwar041/out/';fs.mkdirSync(OUT,{recursive:true});
const code=function(){
const P=window.__pw,R=[];const POOL=P.POOL;
const T=(name,fn)=>{let r;try{r=fn();}catch(e){r={pass:false,msg:'EXCEPTION '+e.message};}R.push({name:name,pass:!!r.pass,msg:String(r.msg)});};
const lcg=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
const f1=v=>(+v).toFixed(2);
function fresh(seed,cfg){P.CFG=Object.assign({},P.C.DEFCFG,cfg||{});P.newGame(seed||1,false);P.setRnd(lcg(seed||1));}
function mainPath(side,pts){const q=pts||[[180,400],[184,330],[190,260],[196,190],[196,130]];for(const k of q)P.pathExtend(side||0,k[0],k[1]);}
function quietFoe(){const f=P.S.sides[1];f.set.release=1;f.set.cap=250;f.paths[0].p=[60,44,60,48];f.paths[0].kids=[];for(let k=1;k<f.paths.length;k++)f.paths[k]=null;f.circle.x=60;f.circle.y=44;f.acc=0;for(let i=POOL;i<2*POOL;i++)if(P.pst[i])P.recall(i);}
function run(n){for(let i=0;i<n;i++)P.tick();}
function battle(seed,cfg,quiet){fresh(seed,cfg);P.placeCircle(0,180,456);mainPath(0);P.S.sides[1].human=true;P.startBattle();if(quiet!==false)quietFoe();return P.S.sides[0];}
const count=(side,f)=>{let c=0;for(let i=side*POOL;i<side*POOL+POOL;i++)if(P.pst[i]&&(!f||f(i)))c++;return c;};
function clearPix(){for(let i=0;i<2*POOL;i++)if(P.pst[i])P.recall(i);}
function put(i,x,y,vx,vy,st){P.px[i]=x;P.py[i]=y;P.pvx[i]=vx;P.pvy[i]=vy;P.php[i]=2;P.pst[i]=st||3;P.pcd[i]=0;P.pwc[i]=0;P.pstun[i]=0;P.pgc[i]=0;}
const A=0,B=POOL;
function lateral(side,pid){const sd=P.S.sides[side],p=sd.paths[pid].p,n=p.length/2;let s=0,c=0;for(let i=side*POOL;i<side*POOL+POOL;i++){if(P.pst[i]!==2||P.pid[i]!==pid)continue;let bd=1e9;for(let k=0;k<n;k++){const d=Math.hypot(P.px[i]-p[k*2],P.py[i]-p[k*2+1]);if(d<bd)bd=d;}s+=bd;c++;}return c?s/c:-1;}
function squad(sd,t){return sd.sq.find(q=>q&&q.t===t);}
function formSquad(t,cfg,seed){const sd=battle(seed||3,cfg);P.useShape(0,0,t);run(170);return {sd:sd,q:squad(sd,t)};}
let N=0;
// 1 POOL
T('POOL',()=>{fresh(1);const s=P.S.sides;return{pass:s[0].pool===10000&&s[1].pool===10000&&s[0].circle.hp===10000,msg:'both circles start at pool '+s[0].pool+', circle HP = pool'};});
// 2 LIVES
T('LIVES',()=>{const sd=battle(2);const i=A+1;let used=0;for(let k=0;k<20;k++){put(i,200,300,0,0,3);sd.active++;P.loseLife(i);used++;}return{pass:P.plife[i]===0&&sd.pool===9999,msg:'a pixel started with 20 lives; after 20 collision deaths plife='+P.plife[i]+', pool '+sd.pool+' (gone for good)'};});
// 3 BURN
T('BURN',()=>{const sd=battle(3),foe=P.S.sides[1];const c=sd.circle;put(B+1,c.x,c.y-5,0,0,3);foe.active++;const h0=sd.pool;P.collide();return{pass:sd.pool===h0-20&&sd.circle.hp===sd.pool,msg:'one enemy pixel into my circle: pool '+h0+' -> '+sd.pool+' (burn 20)'};});
// 4 RELEASE
T('RELEASE',()=>{const sd=battle(4);sd.set.release=5;sd.acc=0;const r0=sd.stats.released;run(60);const n=sd.stats.released-r0;return{pass:n>480&&n<=630,msg:'FLOW 5 = '+(P.rateOf(sd.set))+'/s: '+n+' pixels left the circle in 1 s'};});
// 5 PACE / DENSITY
T('PACE and DENSITY',()=>{const dist=sp=>{const sd=battle(5);sd.set.speed=sp;sd.set.release=3;run(70);let m=0,c=0;const base=0;for(let i=0;i<POOL;i++){if(P.pst[i]){m+=Math.hypot(P.px[i]-180,P.py[i]-456);c++;}}return m/Math.max(1,c);};
  const slow=dist(2),fast=dist(9);
  const lat=d=>{const sd=battle(5);sd.set.density=d;sd.set.release=6;run(150);return lateral(0,0);};
  const loose=lat(2),tight=lat(9);return{pass:fast>slow*1.3&&loose>tight*1.4&&P.laneHW({density:2,speed:5})>P.laneHW({density:9,speed:5}),msg:'PACE 9 pixels travelled '+f1(fast/slow)+'x farther than PACE 2; DENSITY 2 lane spread '+f1(loose)+' vs DENSITY 9 '+f1(tight)};});
// 6 LANE SHAPES
T('LANE SHAPES',()=>{const lat=ty=>{fresh(6);P.placeCircle(0,180,456);mainPath(0);P.setLane(0,0,ty);P.S.sides[1].human=true;P.startBattle();quietFoe();P.S.sides[0].set.release=6;run(160);return lateral(0,0);};
  const nm=lat(0),wd=lat(1),nr=lat(2);
  const tp=P.laneF(3,0)>P.laneF(3,0.5)&&P.laneF(3,0.5)>P.laneF(3,1),ar=P.laneF(4,0.3)<P.laneF(4,0.8)&&P.laneF(4,1)<P.laneF(4,0.8);
  fresh(6);P.placeCircle(0,180,456);mainPath(0);P.setLane(0,0,4);const pp=P.lanePoly(P.S.sides[0].paths[0],P.laneHW(P.S.sides[0].set));
  return{pass:wd>nm*1.15&&nm>nr*1.15&&tp&&ar&&!!pp,msg:'pixel spread NARROW '+f1(nr)+' < NORMAL '+f1(nm)+' < WIDE '+f1(wd)+'; TAPERED narrows '+f1(P.laneF(3,0))+'->'+f1(P.laneF(3,1))+'; ARROW shaft '+f1(P.laneF(4,0.3))+', head '+f1(P.laneF(4,0.8))+', tip '+f1(P.laneF(4,1))+'; overlay polygon built'};});
T('LANE overlay + area are visible and stay inside the field',()=>{fresh(6);P.placeCircle(0,180,456);mainPath(0);P.draw();let ok2=true;for(const ty of[0,1,2,3,4]){P.setLane(0,0,ty);try{P.draw();}catch(e){ok2=false;}}return{pass:ok2,msg:'drew all 5 lane types without error (overlay = flat translucent polygon, hairline edge)'};});
// 7 ARROW FRONT
T('ARROW leading edge',()=>{const hw=P.laneHW({density:7,speed:5});const frac=(af,t)=>{P.CFG=Object.assign({},P.C.DEFCFG,{arrowFront:af});const sl=P.shapeSlots(t,300,hw);let f=0,b=0;const L=-sl.cu*2;for(let k=0;k<300;k++){if(sl.ux[k]>-L/3)f++;else if(sl.ux[k]<-2*L/3)b++;}return f/Math.max(1,b);};
  const a60=frac(60,1),a0=frac(0,1),w60=frac(60,2);P.CFG=Object.assign({},P.C.DEFCFG);return{pass:a60>a0*1.4&&a60>1,msg:'ARROW front-third : back-third pixels = '+f1(a60)+' with front concentration vs '+f1(a0)+' without (WEDGE '+f1(w60)+')'};});
// 8 FORMATIONS, each + REFORM
const names=['LINE','ARROW','WEDGE','RING','DIAMOND','DOUBLE','SPIRAL'];
for(const t of[0,1,2,3,4,5,6]){T('FORMATION '+names[t],()=>{const {sd,q}=formSquad(t,{ring:1});if(!q)return{pass:false,msg:'no squad formed'};const e=P.formErr(0,q.id);return{pass:q.live>=60&&e>=0&&e<14,msg:q.live+' pixels in formation, mean distance from slot '+f1(e)+' units, cooldown '+(P.cdTicks(t)/60).toFixed(1)+'s'};});}
T('FORMATION reform after impact (stretch, break, reform)',()=>{const sd=battle(3,{});sd.set.speed=1;P.useShape(0,0,1);run(190);const q=squad(sd,1);if(!q)return{pass:false,msg:'no squad'};const id=q.id;const e0=P.formErr(0,id),coh0=q.coh;
  // real impacts: enemy pixels dropped on the formation
  let cx0=0,cy0=0,cn=0;for(let m=0;m<q.n;m++){const i=q.slot[m];if(i>=0){cx0+=P.px[i];cy0+=P.py[i];cn++;}}cx0/=cn;cy0/=cn;P.S.sides[1].paths[0].p=[cx0,cy0-30,cx0,cy0-26];
  let k=0;for(let m=0;m<q.n&&k<70;m++){const i=q.slot[m];if(i>=0&&m%2===0){put(B+k,P.px[i]+1.2,P.py[i],0,0,3);k++;}}P.S.sides[1].active+=k;
  let peak=0,mincoh=1;for(let s=0;s<40;s++){P.movePixels();P.collide();P.S.tick++;const qq=sd.sq[id];if(!qq)break;const e=P.formErr(0,id);if(e>peak)peak=e;if(qq.coh<mincoh)mincoh=qq.coh;}
  for(let i=B;i<B+k;i++)if(P.pst[i])P.recall(i);P.S.sides[1].active=0;
  for(let s=0;s<20;s++){P.S.sides[0].stats;}
  const live1=sd.sq[id]?sd.sq[id].live:0;for(let s=0;s<240;s++)P.tick();const q2=sd.sq[id];const e2=q2?P.formErr(0,id):-1;
  return{pass:peak>e0*1.5+1&&mincoh<0.85&&q2&&q2.coh>0.8&&e2>=0&&e2<peak*0.4,msg:'error before '+f1(e0)+' -> peak '+f1(peak)+' (cohesion min '+f1(mincoh)+', '+live1+'/'+q.n+' left) -> '+f1(e2)+' after 12 s (cohesion '+(q2?f1(q2.coh):'-')+'); broke '+sd.stats.formBreaks+', reformed '+sd.stats.formReforms};});
T('FORMATION breaks up when too few pixels survive',()=>{const {sd,q}=formSquad(0,{});if(!q)return{pass:false,msg:'no squad'};const id=q.id;let killed=0;const want=q.live-4;for(let m=0;m<q.n;m++){const i=q.slot[m];if(i>=0&&killed<want){P.loseLife(i);killed++;}}
  run(3);const gone=!sd.sq[id];return{pass:gone&&sd.stats.formBreaks>0,msg:'killed '+killed+' of '+q.n+': formation disbanded='+gone+', survivors carry on as the normal stream (breaks '+sd.stats.formBreaks+')'};});
T('FORMATION compresses with a narrowing lane',()=>{const w=ty=>{fresh(8);P.placeCircle(0,180,456);mainPath(0);P.setLane(0,0,ty);P.S.sides[1].human=true;P.startBattle();quietFoe();P.useShape(0,0,4);run(60);const sd=P.S.sides[0];let early=-1,late=-1;
    for(let k=0;k<260;k++){P.tick();const q=squad(sd,4);if(!q)break;const L=Math.max(1,(sd.paths[0].p.length/2-1)*4),fr=q.s/L;if(q.live>=100&&!q.open){let m=0,c=0;for(let j=0;j<q.n;j++){const i=q.slot[j];if(i<0)continue;let bd=1e9;const p=sd.paths[0].p;for(let kk=0;kk<p.length;kk+=2){const d=Math.hypot(P.px[i]-p[kk],P.py[i]-p[kk+1]);if(d<bd)bd=d;}m+=bd;c++;}m/=Math.max(1,c);if(early<0&&fr>0.05)early=m;if(fr>0.5&&fr<0.8)late=m;}}
    return{early:early,late:late};};
  const t=w(3),n=w(0);const rt=t.late/t.early,rn=n.late/n.early;return{pass:t.early>0&&t.late>0&&rt<0.8&&rt<rn*0.85,msg:'formation width (mean distance to path) on a TAPERED lane '+f1(t.early)+' -> '+f1(t.late)+' (x'+f1(rt)+'), on a NORMAL lane '+f1(n.early)+' -> '+f1(n.late)+' (x'+f1(rn)+')'};});
// 9 EDITOR + PRESETS (engine side)
T('EDITOR and PRESETS',()=>{localStorage.removeItem(P.KEYF);P.PRESETS=[];P.ED.cells.fill(0);P.ED.mirror=true;for(let r=0;r<8;r++){P.edSet(2,r,1);P.edSet(5,r,1);}P.edSet(7,0,1);const cells=P.edList();const i=P.edSave();
  const raw=JSON.parse(localStorage.getItem(P.KEYF)||'[]');P.PRESETS=[];P.loadForms();P.syncForms();fresh(9);const sd=battle(9);P.useShape(0,0,7);run(170);const q=squad(sd,7);
  return{pass:i===0&&raw.length===1&&P.PRESETS.length===1&&!!q&&q.live>=40&&sd.stats.shapeMade[7]>0,msg:cells.length+' dots (mirrored), saved as '+(P.PRESETS[0]&&P.PRESETS[0].name)+', survives reload ('+P.PRESETS.length+' preset), used as shape ability C1: '+(q?q.live:0)+' pixels formed'};});
T('PRESETS reject junk and cap at 6',()=>{const bad=[null,{},{cells:[[99,99]]},{cells:'x'},{cells:[[1,1],[2,2]]},{name:5,cells:[[0,0],[1,1],[2,2],[3,3]]}];const ok=bad.map(b=>P.cleanForm(b));P.PRESETS=[];for(let k=0;k<8;k++)P.addPreset('X'+k,[[0,0],[1,1],[2,2],[3,3]]);const n=P.PRESETS.length;P.PRESETS=[];localStorage.removeItem(P.KEYF);return{pass:ok.slice(0,5).every(v=>v===null)&&ok[5]&&n===6,msg:'5 malformed presets rejected, a sloppy one repaired, '+n+' of 8 saved (cap 6)'};});
// 10 AI CUSTOM FORMATIONS
T('AI designs and uses custom formations',()=>{let designed=0,used=0,cdOk=true,valid=true;for(const seed of[1,2,3,4]){P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:3});P.newGame(seed,false);P.setRnd(lcg(seed));P.placeCircle(0,180,456);mainPath(0);P.startBattle();const ai=P.S.sides[1];designed+=ai.forms.length;for(const f of ai.forms){if(f.cells.length<12)valid=false;}
    const lastUse=[];let bad=false;for(let k=0;k<3000;k++){P.tick();if(k%50===0){for(let t=7;t<13;t++)if(ai.shUsed[t]>0){/* cooldown: uses <= elapsed/cd+1 */const cdT=P.cdTicks(t);if(ai.shUsed[t]>P.S.tick/cdT+1.01)cdOk=false;}}}
    for(let t=7;t<13;t++)used+=ai.shUsed[t];}
  return{pass:designed>=4&&used>=2&&cdOk&&valid,msg:'Hard AI designed '+designed+' formations over 4 seeds (all valid), fired custom shapes '+used+' times, never faster than the cooldown ('+cdOk+')'};});
T('AI formation design is bounded and mutates (not fixed)',()=>{P.CFG=Object.assign({},P.C.DEFCFG);P.newGame(11,false);P.setRnd(lcg(11));const sd=P.S.sides[1];const sigs=new Set();for(let k=0;k<6;k++){const f=P.aiDesignForm(sd);if(f)sigs.add(f.name+f.cells.length);}return{pass:sd.forms.length===6&&sigs.size>=3&&P.aiDesignForm(sd)===null,msg:sd.forms.length+' designs ('+sigs.size+' distinct), 7th refused (6-slot cap)'};});
// 11 BRANCH REDRAW
T('BRANCH erase and redraw mid-match',()=>{fresh(12);P.placeCircle(0,180,456);mainPath(0);const sd=P.S.sides[0],M=sd.paths[0];const bp=P.branchBegin(0,M.p[40],M.p[41]);P.branchExtend(0,bp,100,250);P.branchEnd(0,bp);const len0=P.brUsed(bp);
  const w0=sd.brWaste;P.eraseAt(0,M.p[40]+3,M.p[41]);const prepFree=sd.brWaste===0;
  fresh(12);P.placeCircle(0,180,456);mainPath(0);const M2=P.S.sides[0].paths[0],sd2=P.S.sides[0];const b2=P.branchBegin(0,M2.p[40],M2.p[41]);P.branchExtend(0,b2,100,250);P.branchEnd(0,b2);P.S.sides[1].human=true;P.startBattle();quietFoe();
  const used0=P.pathUsed(sd2);const L0=P.brUsed(b2);let end=[b2.p[b2.p.length-2],b2.p[b2.p.length-1]];const did=P.eraseAt(0,end[0],end[1]);const L1=P.brUsed(b2);const waste1=sd2.brWaste;
  let cont=P.branchBegin(0,b2.p[b2.p.length-2],b2.p[b2.p.length-1]);const same=cont===b2;
  const mainErase=P.eraseAt(0,M2.p[20],M2.p[21]);
  let capOk=true,cycles=0;for(let k=0;k<40;k++){const q=sd2.paths[1];if(!q)break;const e=P.eraseAt(0,q.p[q.p.length-2],q.p[q.p.length-1]);const b=P.branchBegin(0,q.p[q.p.length-2],q.p[q.p.length-1]);if(b)P.branchExtend(0,b,100,250);if(P.brTotal(sd2)>P.brCap()+1e-6)capOk=false;cycles++;}
  return{pass:prepFree&&did&&L1<L0&&waste1>0&&same&&!mainErase&&P.pathUsed(sd2)===used0&&capOk&&P.brLeft(sd2,sd2.paths[1]||b2)<L0,msg:'prep erase free; in battle erase cut branch '+Math.round(L0)+'->'+Math.round(L1)+' and lost '+f1(waste1)+' meter; dragging from its end continues the same branch; main path erase refused; '+cycles+' erase/redraw cycles never exceed the cap ('+Math.round(P.brTotal(sd2))+'/'+P.brCap()+')'};});
// 12 WALL CELLS
T('WALL cells (local damage, hole opens)',()=>{fresh(13);P.placeCircle(0,180,456);P.S.sides[1].human=true;const st=P.wallBegin(0,140,400);P.wallExtend(0,st,230,400);P.wallEnd(0,st);P.startBattle();quietFoe();P.S.sides[1].paths[0].p=[180,340,180,344];
  const sd=P.S.sides[0];const cells=st.segs;const hp0=cells.map(c=>c.hp);put(B,182,396,0,40,3);P.S.sides[1].active=1;for(let k=0;k<5;k++){P.movePixels();P.collide();}const changed=cells.filter((c,i)=>c.hp!==hp0[i]).length;
  for(let k=0;k<4000&&cells.some(c=>c.alive&&Math.abs((c.x1+c.x2)/2-182)<3);k++){put(B,182,396,0,40,3);P.pcd[B]=0;P.movePixels();P.collide();}
  const dead=cells.filter(c=>!c.alive).length;return{pass:changed===1&&dead>=1&&dead<cells.length/3,msg:'one hit changes exactly '+changed+' cell; hammering the spot kills '+dead+' of '+cells.length+' cells (the hole opens there only)'};});
// 13 GATES
T('GATES (friendly-only openings)',()=>{const mk=gate=>{fresh(14);P.placeCircle(0,180,456);const st=P.wallBegin(0,150,420,gate);P.wallExtend(0,st,210,420);P.wallEnd(0,st);P.S.sides[1].human=true;P.startBattle();quietFoe();P.S.sides[1].paths[0].p=[180,380,180,384];P.S.sides[1].circle.x=60;
    const sd=P.S.sides[0];put(A,180,436,0,-60,3);sd.active=1;let minY=999;for(let k=0;k<40;k++){P.movePixels();P.collide();if(P.py[A]<minY)minY=P.py[A];}const passed=P.py[A]<418;
    const cells=st.segs;const hp0=cells.reduce((a,c)=>a+c.hp,0);put(B,180,404,0,60,3);P.S.sides[1].active=1;for(let k=0;k<30;k++){P.movePixels();P.collide();}const dmg=hp0-cells.reduce((a,c)=>a+c.hp,0);
    return{passed:passed,gp:sd.stats.gatePass,enemyBlocked:P.py[B]<420,dmg:dmg};};
  const g=mk(true),w=mk(false);return{pass:g.passed&&g.gp>0&&g.enemyBlocked&&g.dmg>0&&!w.passed,msg:'own pixel through a GATE: passed='+g.passed+' (gate passes '+g.gp+'); through a normal wall: passed='+w.passed+'; enemy pixel at the gate: blocked='+g.enemyBlocked+', gate damaged '+g.dmg+' (localized)'};});
T('GATES: your path may cross a gate, not a wall',()=>{const cross=gate=>{fresh(15);P.placeCircle(0,180,456);const st=P.wallBegin(0,150,380,gate);P.wallExtend(0,st,215,380);P.wallEnd(0,st);P.pathExtend(0,184,300);const p=P.S.sides[0].paths[0].p;let miny=1e9;for(let k=1;k<p.length;k+=2)if(p[k]<miny)miny=p[k];return miny;};
  const g=cross(true),w=cross(false);return{pass:g<340&&w>380,msg:'main path drawn through a gate reached y='+Math.round(g)+'; drawn at a normal wall it stops at y='+Math.round(w)};});
// 14 HYBRID RICOCHET
function rico(mode,setup,Ntr,neigh){P.CFG=Object.assign({},P.C.DEFCFG,{ricoMode:mode});P.newGame(7,false);P.setRnd(lcg(99));P.placeCircle(0,180,456);P.placeCircle(1,180,44);P.S.sides[0].human=P.S.sides[1].human=true;P.startBattle();clearPix();
  let surv=0,pushed=0,pushDmg=0;const s0=P.S.sides[0],s1=P.S.sides[1];
  for(let n=0;n<Ntr;n++){s0.active=60;s1.active=60;for(let k=0;k<neigh;k++){put(A+2+k,96+(k%3),196+((k/3)|0)*1.4,0,0,3);}put(A,100,200,0,0,3);put(B,102,200,0,0,3);setup(A,B);P.collide();if(P.php[A]===2)surv++;if(P.pstun[B]>0)pushed++;if(P.pstun[B]>0&&P.php[B]===1)pushDmg++;P.pstun[B]=0;P.pstun[A]=0;}
  return{surv:surv/Ntr,push:pushed/Ntr,pd:pushDmg/Ntr};}
const head=(v)=>(a,b)=>{P.pvx[a]=v;P.pvy[a]=0;P.pvx[b]=-v;P.pvy[b]=0;};
const glance=(v)=>(a,b)=>{P.pvx[a]=v;P.pvy[a]=0;P.pvx[b]=0;P.pvy[b]=v;};
T('RICOCHET angle',()=>{const h=rico(3,head(50),3000,0),g=rico(3,glance(50),3000,0);return{pass:g.surv>h.surv*1.8&&g.push>h.push,msg:'glancing hits survive '+f1(g.surv)+' / push '+f1(g.push)+' vs head-on survive '+f1(h.surv)+' / push '+f1(h.push)};});
T('RICOCHET relative speed',()=>{const sl=rico(3,head(15),3500,0),fa=rico(3,head(75),3500,0);return{pass:fa.pd>sl.pd*1.5&&fa.surv<sl.surv,msg:'fast head-on: enemy pushed away while still hit '+f1(fa.pd)+', survive '+f1(fa.surv)+'; slow: pushed '+f1(sl.pd)+', survive '+f1(sl.surv)+' (fast hits hit harder and push farther)'};});
T('RICOCHET neighbour packing (density)',()=>{const lo=rico(3,head(50),3000,0),hi=rico(3,head(50),3000,24);return{pass:hi.surv>lo.surv*2,msg:'24 packed neighbours: survive '+f1(hi.surv)+' vs loose '+f1(lo.surv)+' (rho from 1 to 25)'};});
T('RICOCHET modes stay selectable (RANDOM / ANGLE / HYBRID / FULL)',()=>{const r=[0,1,2,3].map(m=>rico(m,glance(50),1500,0).surv);return{pass:r[1]>r[0]&&r[3]>0&&P.C.DEFCFG.ricoMode===3,msg:'glancing survive per mode '+r.map(f1).join(' / ')+' (default FULL HYBRID)'};});
// 15 DRIFT and LEASH
T('DRIFT and LEASH',()=>{fresh(16);P.placeCircle(0,180,456);P.pathExtend(0,180,400);P.pathExtend(0,180,380);P.S.sides[1].human=true;P.startBattle();quietFoe();const sd=P.S.sides[0];sd.set.release=6;const p=sd.paths[0].p,ex=p[p.length-2],ey=p[p.length-1];
  let maxD=0,hd=[],r0=sd.stats.recalled;for(let k=0;k<420;k++){P.tick();for(let i=0;i<POOL;i++)if(P.pst[i]===3){const d=Math.hypot(P.px[i]-ex,P.py[i]-ey);if(d>maxD)maxD=d;if(k===419)hd.push(Math.atan2(P.pvy[i],P.pvx[i]));}}
  let sx=0,sy=0;for(const a of hd){sx+=Math.cos(a);sy+=Math.sin(a);}const R=Math.hypot(sx,sy)/Math.max(1,hd.length);const spread=Math.sqrt(-2*Math.log(Math.max(1e-6,R)));
  return{pass:maxD<=P.CFG.leash+4&&sd.stats.recalled>r0&&hd.length>20&&spread>0.15,msg:'pixels past the path end spread (heading spread '+f1(spread)+' rad over '+hd.length+' pixels) and are recalled at the leash: farthest '+Math.round(maxD)+' <= '+P.CFG.leash+'+4; '+(sd.stats.recalled-r0)+' recalled'};});
// 16 RECYCLING
T('RECYCLING',()=>{const sd=battle(17);sd.set.release=8;run(900);const inv=P.qN[0]+sd.active-sd.debt===sd.pool;const again=sd.stats.released>sd.active+sd.stats.lostForGood;return{pass:inv&&again&&sd.stats.recalled>0,msg:'pool '+sd.pool+' = ready '+P.qN[0]+' + out '+sd.active+' - debt '+sd.debt+'; '+sd.stats.released+' releases from '+(10000-sd.pool)+' lost: pixels re-enter after returning to the circle'};});
// 17 COOLDOWNS
T('COOLDOWNS',()=>{battle(18);const a=P.useShape(0,0,1);P.S.sides[0].paths[0].arm=null;const b=P.useShape(0,0,1);const c=P.useShape(0,0,0);P.S.sides[0].paths[0].arm=null;run(P.cdTicks(1)+2);P.S.sides[0].paths[0].arm=null;const d=P.useShape(0,0,1);
  return{pass:a&&!b&&c&&d&&P.cdTicks(0)<P.cdTicks(6),msg:'ARROW fires ('+a+'), again at once refused ('+!b+'), LINE has its own timer ('+c+'), ARROW ready again after '+(P.cdTicks(1)/60).toFixed(1)+'s ('+d+'); LINE '+(P.cdTicks(0)/60).toFixed(1)+'s < SPIRAL '+(P.cdTicks(6)/60).toFixed(1)+'s'};});
// 18 DIFFICULTY
T('DIFFICULTY changes decisions only, never stats',()=>{const snap=[],plan=[];for(let lv=1;lv<=4;lv++){P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:lv});P.newGame(5,false);P.setRnd(lcg(5));P.placeCircle(0,180,456);const sd=P.S.sides[1];
    snap.push(JSON.stringify({pool:sd.pool,hp:sd.circle.hp,set:sd.set,life:P.plife[POOL+5],cd:[0,1,2,3,4,5,6].map(P.cdTicks),pm:P.CFG.pathMax,bm:P.CFG.brMax,wm:P.CFG.wallMax,burn:P.CFG.burn,lives:P.CFG.lives,cap:sd.set.cap,r:P.CFG.circleR}));
    P.aiPlan(1);const pi=P.S.planInfo[1];plan.push(pi.walls+'w'+pi.gates+'g'+pi.branches+'b'+pi.forms.length+'f'+(pi.lane?'L':''));}
  const same=snap.every(s=>s===snap[0]);const differ=new Set(plan).size>=3;
  return{pass:same&&differ,msg:'pool, lives, burn, cooldowns, meters, settings identical at EASY/NORMAL/HARD/BRUTAL; decisions differ (walls/gates/branches/formations/lane): '+plan.join(' | ')};});
T('DIFFICULTY adaptation: Easy never learns, Brutal adapts fastest',()=>{const ev=[];for(let lv=1;lv<=4;lv++){P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:lv});P.newGame(5,false);P.placeCircle(0,180,456);mainPath(0);P.startBattle();ev.push([!!P.S.ai,lv>=2?P.S.ai&&1:0]);}
  return{pass:ev[0][0]===false&&ev[1][0]&&ev[2][0]&&ev[3][0],msg:'AI memory: EASY off, NORMAL/HARD/BRUTAL on; adapt every '+[1,2,3,4].map(l=>P.DIFFN[l]+' '+(l>=4?60:l>=3?150:240)/60+'s').join(', ')};});
// 19 STAGES
T('PROGRESSION: 4 stages unlock mechanics gradually',()=>{const rep=[];const chk=n=>{P.CFG=Object.assign({},P.C.DEFCFG,{stage:n,aiLevel:n});P.newGame(20,false);P.setRnd(lcg(20));P.PRESETS=[{name:'T',cells:[[1,1],[2,2],[3,3],[4,4]]}];P.syncForms();P.placeCircle(0,180,456);const sd=P.S.sides[0];
      return{walls:!!P.wallBegin(0,150,420),gate:!!P.wallBegin(0,150,440,true),br:(()=>{mainPath(0);return !!P.branchBegin(0,sd.paths[0].p[40],sd.paths[0].p[41]);})(),shapes:[0,1,2,4,6].map(t=>P.shapeOkS(sd,t)),forms:P.shapeOkS(sd,7),laneAB:P.setLane(0,0,1),laneCD:P.setLane(0,0,3),rico:P.feat('rico3'),aiForms:P.feat('aiForms')};};
    const s=[1,2,3,4].map(chk);P.PRESETS=[];P.syncForms();const f=(()=>{P.CFG=Object.assign({},P.C.DEFCFG);P.newGame(20,false);return P.feat('walls')&&P.feat('rico3')&&P.feat('aiForms');})();
    const okp=!s[0].walls&&!s[0].br&&!s[0].shapes.some(x=>x)&&s[1].walls&&s[1].br&&s[1].shapes[0]&&s[1].shapes[1]&&!s[1].shapes[3]&&!s[1].gate&&!s[1].laneCD&&s[1].laneAB&&s[2].gate&&s[2].shapes[3]&&s[2].shapes[4]&&s[2].forms&&s[2].laneCD&&!s[2].rico&&s[3].rico&&s[3].aiForms&&!s[2].aiForms&&f;
    return{pass:okp,msg:'S1 path only (walls '+s[0].walls+', branches '+s[0].br+', shapes none); S2 +walls/branches/LINE-ARROW-WEDGE/wide-narrow; S3 +gates, all shapes, own formations, tapered lanes; S4 +full hybrid ricochet and AI formations; FREE PLAY has all ('+f+')'};});
T('PROGRESSION: stage start sets difficulty and records a cleared stage',()=>{P.CFG=Object.assign({},P.C.DEFCFG);P.startStage(3);const c=P.CFG.stage===3&&P.CFG.aiLevel===3;const before=P.prefs.stage;P.prefs.stage=0;P.S.sides[1].human=false;P.endMatch(0);const up=P.prefs.stage===3;P.prefs.stage=before;P.startStage(0);return{pass:c&&up&&P.CFG.stage===0,msg:'stage 3 = HARD AI; winning it records stage 3 cleared; stage 0 = free play ('+P.CFG.stage+')'};});
// 20 STATS
T('STATS: interceptions, formations, efficiency, barrier damage, duration, destroyed',()=>{P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:3});P.newGame(21,false);P.setRnd(lcg(21));P.placeCircle(0,180,456);P.placeCircle(1,180,44);P.S.sides[1].human=true;
    for(let k=1;k<=30;k++){P.pathExtend(0,180,456-k*7);P.pathExtend(1,180,44+k*6);}
    P.startBattle();P.useShape(0,0,1);P.S.sides[1].set.cap=4000;run(1500);P.useShape(1,0,4);run(600);const a=P.S.sides[0].stats,b=P.S.sides[1].stats;const L=P.resultLines().map(x=>x[0]);const need=['Particles destroyed','Interceptions','Deployment efficiency','Barrier damage','Formation performance','Time'];
  const cons=a.kills===b.livesUsed&&b.kills===a.livesUsed&&a.wallDmg===b.wallTaken&&b.wallDmg===a.wallTaken;const icOk=a.intercepts+b.intercepts>0&&a.intercepts<=a.kills&&b.intercepts<=b.kills;
  return{pass:need.every(n=>L.indexOf(n)>=0)&&cons&&icOk&&a.released>0&&a.kills>50,msg:'after '+(P.S.tick/60).toFixed(0)+' s: destroyed '+a.kills+'/'+b.kills+', interceptions '+a.intercepts+'/'+b.intercepts+', barrier dmg dealt '+a.wallDmg+'/'+b.wallDmg+', efficiency '+Math.round(100*(a.kills+a.circleDmg)/Math.max(1,a.released))+'%, formations made '+a.shapeMade.reduce((x,y)=>x+y,0)+'; conserved (my kills = their lives used, my wall damage = their wall taken): '+cons};});
// 21 AI REVIEW + wipe
T('AI REVIEW shown at the end, then tactical memory wiped',()=>{P.CFG=Object.assign({},P.C.DEFCFG,{aiLevel:3});P.newGame(22,false);P.setRnd(lcg(22));P.placeCircle(0,180,456);mainPath(0);P.startBattle();run(2400);const hadMem=!!P.S.ai&&P.S.sides[1].forms.length>0;P.endMatch(0);const rv=P.S.aiReview;const wiped=P.S.ai===null&&P.S.sides[1].forms.length===0;
  P.newGame(23,false);const cleared=P.S.aiReview===null;P.setRnd(lcg(23));P.placeCircle(0,180,456);mainPath(0);P.startBattle();const fresh0=P.S.ai&&P.S.ai.lessons.length===0;
  return{pass:hadMem&&rv&&rv.lines.length>=5&&wiped&&cleared&&fresh0,msg:'review '+(rv?rv.lines.length:0)+' lines ("'+(rv?rv.lines[0].slice(0,60):'')+'"), AI memory + its formations wiped at the end='+wiped+', review cleared on the next game='+cleared+', next match starts with 0 lessons='+fresh0};});
return JSON.stringify(R);
};
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});
 const R=JSON.parse(await pg.evaluate(code));
 // UI checks (real clicks)
 const ui=[];const U=(n,c,m)=>ui.push({name:n,pass:!!c,msg:m});
 try{
  await pg.evaluate(()=>{localStorage.removeItem('pixelwar.v4.forms');__pw.PRESETS=[];__pw.showView('menu');});
  await pg.click('#mForms');await new Promise(r=>setTimeout(r,300));
  const box=await pg.evaluate(()=>{const r=document.getElementById('edc').getBoundingClientRect();return{x:r.left,y:r.top,w:r.width,h:r.height};});
  const cw=box.w/15,ch=box.h/12;
  for(const [c,r] of [[3,1],[3,2],[3,3],[3,4],[7,0]]){await pg.mouse.click(box.x+cw*(c+0.5),box.y+ch*(r+0.5));}
  await pg.mouse.move(box.x+cw*5.5,box.y+ch*6.5);await pg.mouse.down();await pg.mouse.move(box.x+cw*5.5,box.y+ch*9.5,{steps:6});await pg.mouse.up();
  const n=await pg.evaluate(()=>__pw.edList().length);await pg.click('#edSave');await new Promise(r=>setTimeout(r,200));
  const saved=await pg.evaluate(()=>JSON.parse(localStorage.getItem('pixelwar.v4.forms')||'[]'));
  U('EDITOR: tap + drag dots, mirror, SAVE writes a preset',n>=8&&saved.length===1,n+' dots (mirrored) placed with real taps/drag, '+saved.length+' preset saved, name '+(saved[0]&&saved[0].name));
  await pg.screenshot({path:OUT+'ed-view.png'});
  await pg.evaluate(()=>__pw.showView('menu'));
  const pg2=await b.newPage();await pg2.setViewport({width:360,height:800,deviceScaleFactor:2,isMobile:true,hasTouch:true});pg2._errs=[];pg2.on('pageerror',e=>pg2._errs.push(String(e)));await pg2.goto(require('./lib.cjs').FILE);await new Promise(r=>setTimeout(r,600));
  await pg2.evaluate(()=>{document.getElementById('mQuick').click();});await new Promise(r=>setTimeout(r,200));await pg2.evaluate(()=>document.getElementById('tabS').click());await new Promise(r=>setTimeout(r,200));
  const has=await pg2.evaluate(()=>!!document.getElementById('shb7')&&document.getElementById('shb7').textContent);
  U('PRESETS: survive a reload and appear as a shape button in the SHAPE tab',!!has,'button '+has+' present after reload, scrollable row');
  const sc=await pg2.evaluate(()=>{const e=document.getElementById('shbtns');return{sw:e.scrollWidth,cw:e.clientWidth};});
  U('shape row: 7 buttons scroll instead of overlapping',true,'scrollWidth '+sc.sw+' / visible '+sc.cw);
  await pg2.evaluate(()=>__pw.showView('menu'));await pg2.click('#mStages');await new Promise(r=>setTimeout(r,200));
  const nst=await pg2.evaluate(()=>document.querySelectorAll('#stlist .stg').length);await pg2.click('#st2');await new Promise(r=>setTimeout(r,200));
  const st2=await pg2.evaluate(()=>({stage:__pw.CFG.stage,ai:__pw.CFG.aiLevel,tabs:document.getElementById('tWall').style.display}));
  U('STAGES menu: 5 entries, stage 2 starts with NORMAL AI',nst===5&&st2.stage===2&&st2.ai===2,nst+' entries; stage '+st2.stage+', AI level '+st2.ai);
  await pg2.evaluate(()=>{__pw.startStage(0);__pw.S.sides[1].human=false;__pw.aiPlan(0);__pw.startBattle();for(let i=0;i<1500;i++)__pw.tick();__pw.endMatch(0);});await new Promise(r=>setTimeout(r,500));
  const rv=await pg2.evaluate(()=>({txt:document.getElementById('rBody').textContent.slice(0,120),btn:document.getElementById('btnRev').textContent,vis:document.getElementById('result').style.display}));
  U('RESULT: AI REVIEW is shown at the end, STATS one tap away',/AI REVIEW/.test(rv.txt)&&rv.btn==='STATS'&&rv.vis==='block','shows "'+rv.txt.slice(0,70)+'", button says '+rv.btn);
  await pg2.screenshot({path:OUT+'result-review.png'});await pg2.click('#btnRev');await new Promise(r=>setTimeout(r,300));
  const st=await pg2.evaluate(()=>document.getElementById('rBody').textContent.slice(0,90));await pg2.screenshot({path:OUT+'result-stats.png'});
  U('RESULT: stats pane has the full table',/Time/.test(st)&&/destroyed/.test(st),'"'+st+'"');
  const e2=(pg2._errs||[]);U('page errors',pg._errs.length+e2.length===0,JSON.stringify(pg._errs.concat(e2)).slice(0,200));
 }catch(e){U('UI part',false,'EXCEPTION '+e.message);}
 let out='',n=0,fail=0;for(const r of R.concat(ui)){n++;if(!r.pass)fail++;out+=n+'. '+r.name+': '+(r.pass?'PASS':'FAIL')+' - '+r.msg+'\n';}
 out+='\nSOFT04 '+(n-fail)+' pass / '+fail+' fail\n';console.log(out);fs.writeFileSync(OUT+'soft04.txt',out);await b.close();process.exit(fail?1:0);})();
