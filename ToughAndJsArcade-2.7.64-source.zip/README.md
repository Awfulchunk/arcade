# Tough & J's Arcade 2.7.64 (versionCode 102) — source (GPL-3.0)

2.7.64 is cumulative over 2.7.62 (Papa Potato 0.4.1 stays as is; 0.3/0.2/0.1 stay playable as v03/v02/v01):
- NEW: Pixel War as its own arcade card. Slot pixelwar:latest = Pixel War 0.4.1 (default), slot pixelwar:v03 = Pixel War 0.3 kept as an older version. Source: source/pixel-war/ (both game htmls, tests, assembler, arcade regression, verify script, README).
- Unchanged from 2.7.62: Papa Potato 0.4.1, Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms: source/latch-ui, latch-manual, latch-build, funmotion-0.2.5, swarm-1.6.14, needle-ui, engine, android-app, old-webview, papa-potato.
- Version note: 2.7.63 (code 101, Pixel War 0.3 only) was staged but never published; 2.7.64 / code 102 supersedes it.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
