# Pixel War 0.4.2 source (Tough & J's Arcade 2.7.65) — GPL-3.0
- game/pixel-war-0.4.2.html: the whole game is this one file (no build step). Plain-words HUD, prep with attack path + defense line, live branches in the match (own colour/meter, per-path sliders), slow flow, leash fade, sparkle + ricochet effects, free SANDBOX, shapes hidden (code kept under CUSTOM GAME). Save keys `pixelwar.v42*`. Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.1.html: kept as `pixelwar:v041`; game/pixel-war-0.3.html: `pixelwar:v03`.
- arcade-2.7.65/: assemble-2765.mjs (replaces the latest slot, adds v041, asserts everything else byte-identical) and verify-2765.cjs (checks the signed APK against 2.7.64).
- tests/ (mech, mech2-4, buff, ui, ui2, soft042, perf, hits042, contact), patch/ lint, MISSING.md (audit of every requested item), PROGRESS.md.
- No signing keys and no Latch code are included.
