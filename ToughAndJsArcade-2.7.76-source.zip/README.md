# Tough & J's Arcade 2.7.76 (versionCode 114) — source (GPL-3.0)

2.7.76 is cumulative over 2.7.75 (everything else unchanged):
- Pixel War 0.4.15 is now `pixelwar:latest` (default): big pixels clearly win straight fights in real play (packing counts flow, quarter-point HP/damage, steeper size tables, size edge and shove, 0.9x count cost). 0.4.14 is kept as `pixelwar:v0414`. Source: source/pixel-war/arcade-2.7.76/ (game files, diff, AI-RULES.md, FEATURES-0415.md, tests). Ship scripts: source/arcade-2.7.76/.

From 2.7.75:
- Swarm 1.6.16 is now `swarm:latest` (default). 1.6.15 is kept as `swarm:v1615`; v1614, v1613 and older unchanged. Source: source/swarm-1.6.16/ (patch tools + diff from 1.6.15). Ship scripts: source/arcade-2.7.75/.
- From 2.7.74: Pixel War 0.4.14 latest (v0412, v0413 kept), Papa Potato 0.4.11 latest (v0410 kept). Sources: source/pixel-war/arcade-2.7.74/, source/papa-potato/0.4.11/.
- Unchanged otherwise: Latch 2.1, FunMotion 0.2.5, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
