// Arcade 2.7.75 = published 2.7.74 bundle + swarm:latest 1.6.16 (new v1615=1.6.15). Everything else byte-identical.
import fs from "node:fs"; import crypto from "node:crypto"; import vm from "node:vm";
import { legacyParts, joinParts, legacyHtml } from "/workspace/game/build-latch/fix/legacy-html.mjs";
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const assert = (c, m) => { if (!c) throw new Error("ASSERT " + m); };
const B = "/workspace/game/build-ship2775", BASE = B + "/out/base-2774.html", OUT = process.argv[2] || B + "/out/index.html";
const src = fs.readFileSync(BASE, "utf8");
assert(sha(src) === "68e63a59ef81c446d4c1284ee331d246feda492acc0d74121c8393e262737314", "2.7.74 base hash");
const rd = (f) => fs.readFileSync(`${B}/out/${f}`, "utf8");
const JOBS = [
 { card: "swarm", newKey: "v1615", html: rd("swarm-v1.6.16.html"), hsha: "8b595400d74feb4e152855655e1c669b7c1cf7c1437471a8d449dd6755ff9e6a", oldSha: "6b2846db7988bfee90dc96366345ae61a8d2c0013c9eb4f24421ceafc140f41b",
   oldName: "v1.6.15 – Prior", name: "v1.6.16 – Latest",
   desc: "Every zombie keeps its own body parts, gore and blood: nothing vanishes or gets recycled to cover a newer death. Parts stay until the round-end gore feed sucks them in. Ammo matters: every gun (BASIC too) has limited ammo, misses, overkill, spraying and early box-mag reloads all burn real rounds, and when everything is dry you are OUT until you buy AMMO (price climbs each buy) or an AMMO RACK refills you. Accurate hits earn rounds back at wave clear. HIT % and WASTED on the HUD, a wasted-shots breakdown after each wave and on game over. 7 guns, 7 defenses, 7 abilities, turret AI panel and audio retained.",
   order: null, orderEnd: "v1613,v1614,latest" },
];
for (const j of JOBS) { assert(sha(j.html) === j.hsha, "staged html sha " + j.card); for (const x of j.extra || []) assert(sha(x.html) === x.hsha, "extra sha " + x.key); }
function slots(t) { const r = {}; const re = /^"([^"\n]+)":\[/gm; let m; while ((m = re.exec(t))) { const a = m.index + m[0].length - 1; const b = t.indexOf('].join("")', a) + '].join("")'.length; r[m[1]] = [a, b, t.slice(a, b)]; } return r; }
const GS = (t) => { const i = t.indexOf("const GAME_SRC="), j = t.indexOf("// END_PACKED_GAME_SRC"); return vm.runInNewContext(t.slice(i, j) + "\nGAME_SRC;"); };
const ex = (h) => JSON.stringify([h]).replace(/<\//g, "<\\/") + ".join(\"\")";
const before = slots(src); const NB = Object.keys(before).length; assert(NB === 180, "180 slots before, got " + NB);
const G0 = GS(src);
for (const j of JOBS) { j.KL = j.card + ":latest"; j.KN = j.card + ":" + j.newKey; assert(before[j.KL] && !before[j.KN], "slot state " + j.card); j.old = G0[j.KL];
  assert(sha(j.old) === j.oldSha, "live latest = previous version " + j.card); for (const x of j.extra || []) { x.K = j.card + ":" + x.key; assert(!before[x.K], "extra slot free " + x.K); } }
let out = src; for (const j of [...JOBS].sort((a, b) => before[b.KL][0] - before[a.KL][0])) out = out.slice(0, before[j.KL][0]) + ex(j.html) + out.slice(before[j.KL][1]);
const endM = "\n};})(); // END_PACKED_GAME_SRC"; const ei = out.indexOf(endM); assert(ei > 0, "end marker");
out = out.slice(0, ei) + JOBS.map((j) => ',\n"' + j.KN + '":' + ex(j.old) + (j.extra || []).map((x) => ',\n"' + x.K + '":' + ex(x.html)).join("")).join("") + out.slice(ei);
const gA = out.indexOf("const GAMES="), gE = out.indexOf("\n", gA); const gLine = out.slice(gA, gE);
const gJson = gLine.slice(12).replace(/;\s*$/, ""); const GAMES = JSON.parse(gJson); assert(JSON.stringify(GAMES) === gJson, "GAMES roundtrip");
for (const j of JOBS) { const g = GAMES.find((x) => x.id === j.card); const ids = g.versions.map((v) => v.id);
  if (j.order) assert(ids.join() === j.order, "card versions before " + j.card + " " + ids); if (j.orderEnd) assert(ids.join().endsWith(j.orderEnd), "card end " + j.card + " " + ids);
  assert(ids[ids.length - 1] === "latest" && !ids.includes(j.newKey), "latest last " + j.card);
  const L = g.versions[g.versions.length - 1]; const kept = { ...L, id: j.newKey, name: j.oldName, def: false }; const lat = { ...L, name: j.name, desc: j.desc, def: true };
  const extras = (j.extra || []).map((x) => ({ ...L, id: x.key, name: x.name, desc: x.desc, def: false }));
  g.versions = [...g.versions.slice(0, -1), kept, ...extras, lat]; }
out = out.slice(0, gA) + "const GAMES=" + JSON.stringify(GAMES) + (gLine.slice(12).match(/;\s*$/) || [""])[0] + out.slice(gE);
const lA = out.indexOf("\nconst GAME_LEGACY="), lE = out.indexOf("\n", lA + 1); const lJson = out.slice(lA + 1, lE).slice("const GAME_LEGACY=".length).replace(/;$/, ""); const LEG = JSON.parse(lJson);
assert(JSON.stringify(LEG).replace(/<\//g, "<\\/") === lJson, "GAME_LEGACY roundtrip");
const LEG2 = { ...LEG };
const lp = (h, tag) => { const r = {}, p = legacyParts(h, r); assert(r.jsFail.length === 0, "legacy js fail " + tag + " " + JSON.stringify(r.jsFail).slice(0, 300)); assert(joinParts(p, h) === legacyHtml(h, {}), "parts mismatch " + tag); return p; };
for (const j of JOBS) { const pn = lp(j.html, "new " + j.card); const ro = {}, po = legacyParts(j.old, ro); assert(ro.jsFail.length === 0, "legacy js fail old " + j.card);
  assert(JSON.stringify(LEG[j.KL]) === JSON.stringify(po), "old legacy latest == old parts " + j.card);
  LEG2[j.KL] = pn; LEG2[j.KN] = po; for (const x of j.extra || []) LEG2[x.K] = lp(x.html, "extra " + x.K); }
out = out.slice(0, lA + 1) + "const GAME_LEGACY=" + JSON.stringify(LEG2).replace(/<\//g, "<\\/") + ";" + out.slice(lE);
const after = slots(out); const added = JOBS.flatMap((j) => [j.KN, ...(j.extra || []).map((x) => x.K)]); assert(Object.keys(after).length === NB + added.length, "slots after " + Object.keys(after).length);
const changed = JOBS.map((j) => j.KL);
for (const k of Object.keys(before)) if (!changed.includes(k)) assert(after[k][2] === before[k][2], "slot text changed " + k);
assert(JSON.stringify(Object.keys(after).filter((k) => !before[k]).sort()) === JSON.stringify([...added].sort()), "only new slots");
const G1 = GS(out); for (const j of JOBS) { assert(G1[j.KL] === j.html && G1[j.KN] === j.old, "payloads " + j.card); for (const x of j.extra || []) assert(G1[x.K] === x.html, "extra payload " + x.K); }
for (const k of Object.keys(G0)) if (!changed.includes(k)) assert(G0[k] === G1[k], "payload changed " + k);
for (const k of Object.keys(LEG)) if (!changed.includes(k)) assert(JSON.stringify(LEG[k]) === JSON.stringify(LEG2[k]), "legacy changed " + k);
const strip = (t) => { const a1 = t.indexOf("const GAMES="), a2 = t.indexOf("\n", a1); const b1 = t.indexOf("\nconst GAME_LEGACY="), b2 = t.indexOf("\n", b1 + 1); let s = t.slice(0, a1) + t.slice(a2, b1) + t.slice(b2); const c1 = s.indexOf("const GAME_SRC="), c2 = s.indexOf("// END_PACKED_GAME_SRC"); return s.slice(0, c1) + s.slice(c2); };
assert(strip(out) === strip(src), "shell text changed outside GAMES / GAME_SRC / GAME_LEGACY");
const base = (() => { const a = src.indexOf("const GAMES="), e = src.indexOf("\n", a); return JSON.parse(src.slice(a + 12, e).replace(/;\s*$/, "")); })();
const cards = JOBS.map((j) => j.card);
assert(JSON.stringify(GAMES.filter((g) => !cards.includes(g.id))) === JSON.stringify(base.filter((g) => !cards.includes(g.id))), "other cards changed");
assert(JSON.stringify(GAMES.map((g) => g.id)) === JSON.stringify(base.map((g) => g.id)), "card order");
for (const j of JOBS) { const a = GAMES.find((g) => g.id === j.card), b = base.find((g) => g.id === j.card); const { versions: va, ...ra } = a, { versions: vb, ...rb } = b; assert(JSON.stringify(ra) === JSON.stringify(rb), "card fields " + j.card);
  const n = 2 + (j.extra || []).length; assert(JSON.stringify(va.slice(0, -n)) === JSON.stringify(vb.slice(0, -1)), "older versions untouched " + j.card); }
fs.writeFileSync(OUT, out);
fs.writeFileSync(B + "/out/index.assemble.json", JSON.stringify({ base: sha(src), out: sha(out), bytes: Buffer.byteLength(out), slotsBefore: NB, slotsAfter: Object.keys(after).length, added, latest: Object.fromEntries(JOBS.map((j) => [j.KL, j.hsha])) }, null, 1));
console.log("ASSEMBLE OK", sha(out), Object.keys(after).length, "slots; added", added.join(", "));
