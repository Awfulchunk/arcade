// 0.4.15 tuning: set size tables in the page, run realistic scenarios. TAB={HP:[..],DMG:[..],CNT:[..]}
const {launch,open}=require('./lib.cjs');const {scen,SCN}=require('./scen0415.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,800));
 const tab=process.env.TAB?JSON.parse(process.env.TAB):null;
 if(tab)await pg.evaluate(t=>{const g=window.__pw;for(const k of Object.keys(t)){if(k==='SV')continue;const a=g['SZ_'+k];for(let q=0;q<10;q++)a[q]=t[k][q];}if(t.CNT){for(let q=0;q<10;q++)g.SZ_MASS[q]=+(1/t.CNT[q]).toFixed(3);}g.rebuildSZ();if(t.SV!=null)g.ZL.SV=t.SV;},tab);
 console.log('TITLE',await pg.evaluate(()=>document.title),'HP',await pg.evaluate(()=>JSON.stringify(window.__pw.SZ_HP)));
 const pairs=JSON.parse(process.env.PAIRS||'[[9,6],[10,1],[8,5],[6,5]]'),only=(process.env.ONLY||'headon w6|half|angled 30|guard').split('|'),seeds=JSON.parse(process.env.SEEDS||'[5,9]');
 for(const [bg,sm] of pairs)for(const [nm,A,B] of SCN(bg,sm)){if(!only.some(o=>nm.includes(o)))continue;const r=await scen(pg,nm,A,B,+(process.env.T||1800),seeds);console.log('SCEN',JSON.stringify(r));}
 if(pg._errs.length)console.log('ERRS',pg._errs.slice(0,5));await b.close();})();
