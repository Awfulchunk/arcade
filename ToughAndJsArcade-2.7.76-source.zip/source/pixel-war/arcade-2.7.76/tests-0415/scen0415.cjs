// Pixel War 0.4.15 (Jay t1212): realistic size scenarios, not only perfect head-on duels. Two human sides (duel mode), size A vs size B,
// sides swapped + seeds. Scenarios: head-on, wide/max flow, angled meet (one lane bowed), crossing lanes, half overlap, big wide vs small thin.
// Reports kill share of A, how far A pushed the fight (front, + = toward B's circle), circle pool burned by each, KOs.
const {launch,open}=require('./lib.cjs');
const SC=function(a){const g=window.__pw;g.clearAiMem();const _r=Math.random;let u=a.seed/4294967296;Math.random=()=>u;g.startWith({duel:1});Math.random=_r;
  const S=g.S;S.sides[1].human=true;const A=S.sides[0].circle,C=S.sides[1].circle;
  const mk=(sd,P0,P1,bow,off)=>{const dx=P1.x-P0.x,dy=P1.y-P0.y,L=Math.hypot(dx,dy),nx=-dy/L,ny=dx/L;for(let i=1;i<=160;i++){const t=i/160,b=4*t*(1-t)*bow,o=off*Math.min(1,t*3);g.pathExtend(sd,P0.x+dx*t+nx*(b+o),P0.y+dy*t+ny*(b+o));}};
  const sa=a.sw?a.B:a.A,sb=a.sw?a.A:a.B;mk(0,A,C,sa.bow||0,sa.off||0);mk(1,C,A,sb.bow||0,sb.off||0);
  for(const sd of [0,1]){const o=sd?sb:sa;const y=sd?C.y+70:A.y-70;const w=g.wallBegin(sd,10,y);if(w){g.wallExtend(sd,w,60,y);g.wallEnd(sd,w);}g.setSetting(sd,'width',o.w);g.setSetting(sd,'speed',o.sp||6);g.setSetting(sd,'release',o.f);g.setSetting(sd,'size',o.s);}
  g.tryStart();S.phase==='prep'&&g.startBattle();S.paused=false;const H=g.C.H;
  let frontSum=0,frontN=0;
  for(let i=0;i<a.t&&!S.over;i++){g.tick();if(i%30===29){const st=window.__tt.getState();let ys=[],yb=[];for(const p of st.pixels){if(p.s===0)ys.push(p.y);else yb.push(p.y);}
    // front = the deepest 10% of side 0 pixels toward side 1's circle vs side 1's deepest: midpoint of the two stream tips
    ys.sort((x,y)=>x-y);yb.sort((x,y)=>y-x);if(ys.length>10&&yb.length>10){const dir=Math.sign(C.y-A.y);const t0=dir<0?ys[Math.floor(ys.length*0.1)]:ys[ys.length-1-Math.floor(ys.length*0.1)];frontSum+=t0;frontN++;}}}
  const mid=(A.y+C.y)/2,dir=Math.sign(C.y-A.y),f0=frontN?(frontSum/frontN-mid)*dir:0;
  return {k:[S.sides[0].stats.kills,S.sides[1].stats.kills],burn:[10000-Math.round(S.sides[1].pool),10000-Math.round(S.sides[0].pool)],out:[S.sides[0].active,S.sides[1].active],tip0:f0,over:S.over,winner:S.winner,tick:S.tick};};
async function scen(pg,name,A,B,t,seeds){let kA=0,kB=0,bA=0,bB=0,tipA=0,tipB=0,ko=[0,0],n=0,oA=0,oB=0;
  for(const seed of seeds)for(const sw of [0,1]){const r=await pg.evaluate(SC,{seed,A,B,sw,t});const a=sw?1:0,b=1-a;kA+=r.k[a];kB+=r.k[b];bA+=r.burn[a];bB+=r.burn[b];oA+=r.out[a];oB+=r.out[b];
    if(sw)tipB+=r.tip0;else tipA+=r.tip0;n++;if(r.over){if(r.winner===a)ko[0]++;else if(r.winner===b)ko[1]++;}}
  return {name,A:A.s,B:B.s,killShareA:+(100*kA/Math.max(1,kA+kB)).toFixed(1),kills:[kA,kB],burnByA:bA,burnByB:bB,outAvg:[Math.round(oA/n),Math.round(oB/n)],tipA:+(tipA/(n/2)).toFixed(1),tipB:+(tipB/(n/2)).toFixed(1),ko};}
const SCN=(big,small)=>[
 ['headon w6 f600',{s:big,w:6,f:600},{s:small,w:6,f:600}],
 ['headon w10 f1000',{s:big,w:10,f:1000},{s:small,w:10,f:1000}],
 ['angled 30deg',{s:big,w:7,f:700},{s:small,w:7,f:700,bow:70}],
 ['angled other',{s:big,w:7,f:700,bow:70},{s:small,w:7,f:700}],
 ['crossing',{s:big,w:7,f:700,bow:90},{s:small,w:7,f:700,bow:90}],
 ['half overlap',{s:big,w:8,f:600,off:8},{s:small,w:8,f:600,off:8}],
 ['big wide vs small thin',{s:big,w:10,f:700},{s:small,w:4,f:700}],
 ['small wide vs big thin',{s:big,w:4,f:700},{s:small,w:10,f:700}],
 ['vs Pixie coverage guard (w+1,f+80)',{s:big,w:9,f:600},{s:Math.max(small,5),w:10,f:680}],
 ['max flow vs guard',{s:big,w:10,f:1000},{s:Math.max(small,5),w:10,f:1000}],
];
module.exports={scen,SCN,SC};
if(require.main===module)(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,800));
  console.log('TITLE',await pg.evaluate(()=>document.title));
  const t=+(process.env.T||1800),seeds=JSON.parse(process.env.SEEDS||'[5,9]'),pairs=JSON.parse(process.env.PAIRS||'[[10,1],[9,3],[8,4]]'),only=process.env.ONLY;
  for(const [bg,sm] of pairs)for(const [nm,A,B] of SCN(bg,sm)){if(only&&!nm.includes(only))continue;const r=await scen(pg,nm,A,B,t,seeds);console.log('SCEN',JSON.stringify(r));}
  if(pg._errs.length)console.log('ERRS',pg._errs.slice(0,5));await b.close();})();
