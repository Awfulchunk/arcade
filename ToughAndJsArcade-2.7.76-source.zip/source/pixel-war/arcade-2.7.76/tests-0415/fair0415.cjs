// Pixel War 0.4.15 fair runs: the same openings as 0.4.10-0.4.13 (dummy 11, fair 17/11/23, left-wrap variant 19), memory cleared each run, played to the real end.
// Bar: Pixie wins all four fair/variant runs, 0 mid-match walls, 0 JS errors, 0 book errors. Extra (not the bar): the same fair-17 opening with a small-swarm player,
// a big-pixel player and a wide player, to see the book's size / width entries act; plus the book switched OFF on the bar runs for comparison.
const {launch,open}=require('./lib.cjs');const {runFight,SPECS}=require('./fairlib0414.cjs');
const which=process.argv[2]||'all';
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 const t=await pg.evaluate(()=>document.title);if(t!=='PIXEL WAR 0.4.15'){console.error('LOAD_FAIL',t);process.exit(1);}
 const bad=[],rows=[];
 const run=async(sp,tag)=>{const r=await runFight(pg,sp,18000);const win=r.winner===1?'AI':r.winner===0?'player':'draw';
  const g=[];const book={};let reads=0,berr=0;for(const tr of r.trace){for(const x of tr.br)if(x.job==='guard')g.push(x.id+':w'+x.w+':z'+x.z);if(tr.book)Object.assign(book,tr.book);reads=Math.max(reads,tr.bookReads||0);berr=Math.max(berr,tr.bookErr||0);}
  console.log('RUN',tag,JSON.stringify({name:sp.name,winner:win,sec:+(r.tick/60).toFixed(1),aiHits:r.aiHits,pHits:r.pHits,aiHp:r.aiHp,pHp:r.pHp,guards:[...new Set(g)],detour:r.detour&&r.detour.ok,offense:r.offense&&r.offense.ok,walls:r.wallsUnchanged,aiNoWallTry:r.aiNeverTried,bookReads:reads,bookFired:book,bookErr:berr}));
  return Object.assign(r,{berr});};
 if(which==='all'||which==='bar'){await pg.evaluate(()=>{window.__pw.AIR.book=1;});
  for(const sp of SPECS){const r=await run(sp,'BOOK');rows.push(r);
   if(!r.started||!r.locked)bad.push(sp.name+': start/lock');if(!r.wallsUnchanged||!r.aiNeverTried)bad.push(sp.name+': mid-match wall');if(r.berr)bad.push(sp.name+': book errors');
   if(sp.kind!=='dummy'&&!(r.detour&&r.detour.ok&&r.offense&&r.offense.ok))bad.push(sp.name+': player detour/offense missing');
   if(r.winner!==1)bad.push(sp.name+': AI did not win');}}
 if(which==='all'||which==='extra'){await pg.evaluate(()=>{window.__pw.AIR.book=1;});
  for(const sp of [{kind:'fair',seed:17,name:'fair-17-swarm-size2',ps:2,os:1.5,ds:2},{kind:'fair',seed:17,name:'fair-17-big-size9',ps:9,os:9.5,ds:9},{kind:'fair',seed:23,name:'fair-23-wide9',pw:9,ow:9},{kind:'variant',seed:19,name:'variant-19-big',ps:8.5,os:9}]){const r=await run(sp,'EXTRA');if(r.berr)bad.push(sp.name+': book errors');if(!r.wallsUnchanged||!r.aiNeverTried)bad.push(sp.name+': mid-match wall');}}
 if(which==='all'||which==='off'){await pg.evaluate(()=>{window.__pw.AIR.book=0;});for(const sp of SPECS)await run(sp,'BOOK-OFF');await pg.evaluate(()=>{window.__pw.AIR.book=1;});}
 if(pg._errs.length)bad.push('JS errors '+JSON.stringify(pg._errs.slice(0,3)));
 const fair=rows.filter(r=>r.kind!=='dummy');console.log('BAR',JSON.stringify({fairRuns:fair.length,aiWins:fair.filter(r=>r.winner===1).length}));
 await b.close();if(bad.length){console.error('TEST_FAIL',bad);process.exit(1);}console.log('TEST_OK');})().catch(e=>{console.error(e);process.exit(1);});
