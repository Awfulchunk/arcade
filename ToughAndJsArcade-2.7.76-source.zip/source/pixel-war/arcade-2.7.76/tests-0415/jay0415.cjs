// Pixel War 0.4.15: Jay-like matches vs Pixie (player main/detour/offense big, size 8-10, some wide), memory carried between matches like on his phone.
// Reads the per-size kill matrix (stats.kz[killerSize*11+victimSize]) to see who wins the FIGHTS between Jay's big pixels and Pixie's pixels, by Pixie's size.
const {launch,open}=require('./lib.cjs');const {runFight}=require('./fairlib0414.cjs');
(async()=>{const b=await launch();const pg=await open(b,360,800,2,{mobile:true});await new Promise(r=>setTimeout(r,1200));
 console.log('TITLE',await pg.evaluate(()=>document.title));await pg.evaluate(()=>{window.__pw.clearAiMem();});
 const specs=[{kind:'fair',seed:17,name:'jay17-big9',ps:9,os:9,ds:9,keepMem:1},{kind:'fair',seed:11,name:'jay11-big10-wide9',ps:10,os:10,ds:10,pw:9,ow:9,keepMem:1},
  {kind:'fair',seed:23,name:'jay23-big8',ps:8,os:8,ds:8,keepMem:1},{kind:'variant',seed:19,name:'jay19-big9-wide8',ps:9,os:9,ds:9,pw:8,ow:8,keepMem:1},{kind:'fair',seed:17,name:'jay17-big10-again',ps:10,os:10,ds:10,keepMem:1}];
 const tot={pk:0,ak:0,pkS:0,akS:0};
 for(const sp of specs){const r=await runFight(pg,sp,Number(process.env.MAXT||18000));
  const m=await pg.evaluate(()=>{const S=window.__pw.S;return {p:Array.from(S.sides[0].stats.kz),a:Array.from(S.sides[1].stats.kz)};});
  // player kills of AI pixels where the player's pixel was 7+ ; AI kills of player 7+ pixels. Split by AI size: small (<=6) vs big (7+)
  let pkSm=0,pkBg=0,akSm=0,akBg=0;for(let k=0;k<11;k++)for(let v=0;v<11;v++){const pk=m.p[k*11+v],ak=m.a[k*11+v];if(k>=7){if(v<=6)pkSm+=pk;else pkBg+=pk;}if(v>=7){if(k<=6)akSm+=ak;else akBg+=ak;}}
  tot.pk+=pkSm;tot.ak+=akSm;
  console.log('JAY',JSON.stringify({name:sp.name,winner:r.winner===1?'Pixie':r.winner===0?'Jay':'draw',sec:+(r.tick/60).toFixed(1),jayHp:r.pHp,pixieHp:r.aiHp,
   bigVsPixieSmall:{jayKills:pkSm,pixieKills:akSm,jayShare:+(100*pkSm/Math.max(1,pkSm+akSm)).toFixed(1)},bigVsPixieBig:{jayKills:pkBg,pixieKills:akBg},
   pixieSizesKilling:m.a.reduce((o,x,ix)=>{if(x&&(ix%11)>=7){const k=(ix/11|0);o[k]=(o[k]||0)+x;}return o;},{})}));}
 console.log('TOTAL big-vs-small-in-real-play jayShare',(100*tot.pk/Math.max(1,tot.pk+tot.ak)).toFixed(1),tot);
 if(pg._errs.length)console.log('ERRS',pg._errs.slice(0,5));await b.close();})();
