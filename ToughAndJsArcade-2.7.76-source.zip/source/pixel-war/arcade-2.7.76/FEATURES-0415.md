# Pixel War 0.4.15 — big pixels clearly win straight fights in real play (Jay t1212)

Build: `/workspace/game/build-pixelwar0415/index.html`, SHA256 `5bd075a7b105a0bf3d42b84c88a79b2e6d865152ba6930473c2cd4ecd6f2a07f`. Copied from 0.4.14 (d9a90032…ba73). Shipped in Arcade 2.7.76 as `pixelwar:latest`; 0.4.14 kept as `pixelwar:v0414`.

## Root cause
Lab head-on duels only ever tested 10 v 1 and 9 v 3. In real games Jay's big stream (8–10) meets Pixie's guards and mains at size 6–9. Measured with a per-size kill matrix in Jay-like matches vs Pixie: Jay's big pixels won only **50.4%** of their fights against Pixie's smaller (≤6) pixels, and 9 v 6 head-on in the lab was only 56%. Two causes:
1. **Packing counted pixels, not flow.** The survive / push rolls use local packing (`rhoAt`, kSurv 0.9, kPush 0.8). Big pixels come out at 0.8x per flow, so a big stream always read as "looser" and lost those rolls to an equal-flow small stream.
2. **HP and damage were rolled in whole points** (then x4), so the size tables collapsed: size 5 through 9 all killed in the same 2 hits most of the time, and only the extreme pairs showed any edge.

## Fix (physics only; Pixie's AI code untouched, only her book's numbers updated)
- Packing counts mass (`ZL.MASS`, = flow), not pixel count.
- HP and damage roll in quarter points (`HPQ` 4), so every 0.1 of size matters.
- Steeper tables: HP 1.7…2.75, damage 0.85…1.4 (size 5 still HP 2, damage 1).
- Size edge: the bigger pixel of a contact gets +5% chance to shrug off the hit per whole size step of difference (`ZL.SV`).
- Size shove: the bigger pixel bounces the smaller one more often and knocks it back harder (ricochet stays random and short).
- Lighter count cost: 0.9x pixels per flow at size 10, 1.1x at size 1 (was 0.8x / 1.2x). Circle/wall damage per pixel is still 1/count, so the same flow does the same total damage.
- Edge inset, slider fractions and old density were checked: not the cause, unchanged.
- Pixie's book (`size_swarm`, `objective`) and AI-RULES.md updated with the new numbers. Saves `pixelwar.v415*`, falling back to v414 and older; DELETE clears v415 and v414 memory too.

## Numbers (tests/scen0415.cjs: two human sides, seeds 5 & 9, sides swapped, 30 s; kill share for the BIG side)
| scenario | 9 v 6 before → after | 10 v 6 before → after | 10 v 1 before → after | 9 v 3 before → after |
|---|---|---|---|---|
| head-on w6 f600 | 56.4 → 70.6 | 57.9 → 72.7 | 70.3 → 90.1 | 64.2 → 79.0 |
| head-on w10 f1000 | 55.9 → 70.7 | 58.8 → 73.3 | 70.3 → 90.3 | 64.9 → 78.8 |
| angled 30° | 61.7 → 78.8 | 67.8 → 80.9 | 82.6 → 94.8 | 75.7 → 85.1 |
| half overlap | 57.8 → 69.0 | 59.0 → 71.9 | 70.6 → 90.0 | 64.5 → 79.1 |
| big wide vs small thin | 55.9 → 67.8 | 58.1 → 69.7 | 68.6 → 87.1 | 62.9 → 75.1 |
| small wide vs big thin | 57.7 → 71.8 | 59.5 → 74.6 | 71.7 → 91.1 | 65.5 → 80.5 |
| vs Pixie coverage guard | 55.8 → 69.0 | 57.7 → 71.9 | (10 v 5) → 74.4 | (9 v 5) → 71.3 |
Front push (head-on w6, 9 v 6): big's tip went from −20.5 to +9.6 (past the middle), small's from −32.3 to −61.3 (pushed back toward its own circle).
Tuning (tests/tune0415.cjs, head-on): 8 v 5 70.8%, 10 v 8 69.5%, 6 v 5 61.8%.

Real play (tests/jay0415.cjs, Jay-like big player vs Pixie, memory carried, 5 matches): Jay's big pixels vs Pixie's ≤6 pixels **50.4% → 71.8%** of the fights. Pixie still won 4 of 5 of those matches (she counters big with big and by flanking).

Fair runs (tests/fair0415.cjs bar, memory cleared): Pixie won dummy 11, fair 17, 11, 23 and variant 19; 0 mid-match walls, 0 book errors, 0 JS errors.

Testing was one quick pass (t1212): syntax check, the scenarios above, fair runs. No full suites, no physical-phone test.
