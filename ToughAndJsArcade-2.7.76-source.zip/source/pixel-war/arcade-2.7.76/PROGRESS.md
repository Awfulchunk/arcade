# Pixel War 0.4.15 — progress
**SHIPPED in Arcade 2.7.76 (Jay t1212: quick fix then ship).** See FEATURES-0415.md. Final SHA256 5bd075a7b105a0bf3d42b84c88a79b2e6d865152ba6930473c2cd4ecd6f2a07f.
Logs: tests/out-before-scen.txt (0.4.14), tests/out-after-scen.txt, tests/out-after-jay.txt, tests/out-after-fair.txt.
