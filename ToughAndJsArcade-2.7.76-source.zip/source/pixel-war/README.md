# Pixel War source (Tough & J's Arcade 2.7.76) — GPL-3.0

Current ship: Pixel War 0.4.15 is `pixelwar:latest` (see arcade-2.7.76/). 0.4.14 is kept as `pixelwar:v0414` (arcade-2.7.74/ and arcade-2.7.76/pixel-war-0.4.14.html).

# Pixel War source (Tough & J's Arcade 2.7.73) — GPL-3.0

Current ship: Pixel War 0.4.12 is `pixelwar:latest` (see arcade-2.7.73/: the game file, AI-RULES.md, patch tools and tests). 0.4.10 is kept as `pixelwar:v0410` (arcade-2.7.72/). 0.4.9 is `pixelwar:v049` (arcade-2.7.71/). Older slots stay as previously shipped. 0.4.11 was never shipped on its own; its changes are inside 0.4.12.

# Pixel War 0.4.7 source (Tough & J's Arcade 2.7.70) — GPL-3.0
- game/pixel-war-0.4.7.html: the whole game is this one file (no build step). The AI always plays at full smart (the difficulty picker is hidden). Branch streams fill their full lane width. Past the end of a path or a branch, pixels keep going in that last direction as one loose, wide group, then fade. Save keys `pixelwar.v47*` (prefs/forms/custom/AI memory fall back from v46/v45/v44/v43). Shipped as `pixelwar:latest` (default).
- game/pixel-war-0.4.6.html: kept as `pixelwar:v046`; 0.4.5 as `v045`; 0.4.4 as `v044`; 0.4.3 as `v043`; 0.4.2 as `v042`; 0.4.1 as `v041`; 0.3 as `v03`.
- arcade-2.7.70/: assemble-2770.mjs and verify-2770.cjs (checks the signed APK against 2.7.69).
- tests/ were not re-run for 0.4.7. No signing keys and no Latch code are included.
