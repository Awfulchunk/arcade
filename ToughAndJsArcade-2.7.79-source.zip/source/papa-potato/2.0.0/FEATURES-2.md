# Papa Potato 2.0.0: what was built
A full rework of Papa Potato 0.4.11, built as one single-file HTML5 canvas game (release/papa-potato-2.0.0.html).
Your 0.4.11 stays playable as its own Arcade slot with its own save. 2.0.0 is a fresh start under a new save key, papaPotato2.save.v1.

## Locked answers (Jay), all built
- **View:** Project Zomboid-style corner isometric. Walls, floor tiles, depth-sorted objects, shadows, and a moving light sheen on cloth and wood.
  - The camera follows Papa. You can pan, pinch or wheel to zoom.
  - The KITCHEN and WASH buttons jump to a room. ◎ toggles follow.
- **One continuous map (26x24 tiles):**
  - Kitchen: x 0..13, y 0..23.
  - Wash room: x 15..25, y 0..15.
  - They share a wall with a metal door at (14,3-4).
  - Papa walks through the door with the camera following. He carries potatoes between the rooms by hand, in the sack, or on belts.
- **Belts:** 1x1 tiles, placed one at a time. The ghost auto-advances to the next tile.
  - Tap a placed belt to rotate it. Items really ride the belts, and belts feed machines.
  - Belts are walkable at 0.85 speed.
- **Machines:** hopper (2x2), auto peeler (3x2), washer drum (3x2) and generator (2x2). All are huge.
  - Each has an input side and an output side, shown with arrows.
  - They need power: a generator gives 12 load (+8 per BIG GENERATOR level) in radius 7 (+1.5 per level). Loads are belt 1, hopper 2, peeler 3, washer 3.
  - Machines can jam. Papa walks over and fixes the jam: on his own with FIX JAMS on, or when you tap FIX or the jammed machine.
- **Papa v2:** 1.45x bigger, with better proportions, shading, and walk, peel, sweep, scrub, sleep and puke animations.
  - When he is behind a machine or wall, a see-through Papa outline still shows him.
- **Wash room:**
  - Peeled potatoes come out dirty. Clean ones sell for more.
  - He scrubs them at the tub, or you scrub them by tapping or swiping a dirty potato (brush).
  - They also get cleaner soaking in the pool or riding the canal.
  - Kept from 0.4.11: the X-ray scanner pass-through, the pool, the canal, and the ship hole on the wash-room wall.
  - Outlets are cap 5, range 4.5.

## Fault list t1213, each item fixed
| Fault | Fix |
|---|---|
| Every item is a physical object with a looped animation | Every one of the 49 shop items is drawn on the map with its own loop. Tested 2x with a pixel-mask animation diff per item. |
| Placement free and correct; nothing stuck, locked, hidden or unreachable | Free placement with a green/red ghost. The ghost spawns at the nearest valid spot with the camera centered on it. It has TURN, MOVE and STORE, and a PLACED tab that lists every placed thing. EDIT x-ray fades tall objects, walls and the door. Front walls are low curbs and the shared wall is low. Reachability is checked with BFS for every item, 2x. |
| Entry room longer and 2x wider | Kitchen is 14x24 tiles (0.4.11 kitchen 7 wide). |
| Papa and potatoes bigger, machines huge | Papa is 1.45x, potatoes are bigger, and machines are 2x2 or 3x2 with tall bodies. |
| The puke is HUGE | It is a lobed puddle of radius 2.0 tiles, with chunks, bubbles and stink lines. Papa always mops it first. |
| Sack glitch; Papa never sleeps with the sack | Before a nap he sets the sack on the floor tile beside the bed, picked so it is never hidden behind the headboard. He never lies down holding it, and he picks it up again on waking. Tested 2x. |
| Redraw the peeled potato | New peeled potato: pale flesh, facets, eyes cut out. Dirty ones show grime spots until scrubbed. |
| Broom and dustpan only move in his hands | They are drawn only in his hands (or on the equip slot), never floating, and are swept with his arm animation. |
| Port the radio/My Music | Ported the radio sheet (stations plus My Music) and the RADIO object with antenna, dial and notes. |
| Port the decor effects | Every decor item keeps its 0.4.11 effect. Each effect is probe-tested 2x. |
| Port the mood meter | The MOOD bar is in the HUD, and decor, rugs, radio, TV and the cat move it. |
| Port the table sink | KITCHEN SINK, with a dripping tap and a splash ring. WASH BEFORE PEEL uses it. |
| Port the shop key door | The ROOM KEY in the shop unlocks the metal door. Wash-room boxes say "Needs the ROOM KEY" until then. |
| Port the cat | CAT BED + CAT. The cat wanders, sleeps in the bed and boosts mood. |

## Extras (not in the brief)
- **Puke mechanic:** EAT while full makes him puke a huge puddle, and he mops it.
- **Power and generators:** power rings in EDIT, an over-capacity warning, and NO POWER state on machine cards.
- **Jams:** the FIX order blinks when anything is jammed. The SERVICE KIT upgrade cuts jams.
- **WASHER DRUM machine:** cleans peeled potatoes on the belt line.
  - SEND PEELED TO has three choices: tub, belt or CARRY to the 5c spot.
- **Machines stack:** you can place more than one of each, and every extra one costs 1.5x.
- **Starter objects:** the bed, cooler and table can be moved but not stored.
- **See-through Papa** behind objects.
- **EDIT x-ray view and PLACED tab.**
- **Paged command boxes:** ▲/▼ page buttons, sized to the screen, so the panel never hides anything behind a scroll. The sliders are 44px tap targets.
- **Moving sheen** on rugs and wood.
- **Small animated details:** a fly, a moth, a dial needle, a standby LED and more.

## Cut, and why
- **Side table and table-top slots:** the fruit bowl, cookbook and aquarium are now floor stands. A table-top slot can't be placed freely or reached on the iso map without hiding things, which breaks the "nothing hidden or unreachable" rule.
- **Stool:** he eats standing at the cooler, so a stool had no purpose and was just another thing to block a path.
- **POTATOES IN PLAY slider:** the raw pile is unlimited in 2.0, so the slider had nothing to control.
- **AUTO-WASH:** replaced by the WASHER DRUM machine plus the SEND PEELED TO choices.

## Tests (desktop headless Chrome; no physical phone test was done)
- **Items:** every one of the 49 shop items, 2x (seeds 101 and 202). Checks: level lock, buy and price, place, reachability, looped animation, effect probe, and move/turn/store/re-place.
- **Mechanics:** 28 mechanics, 2x.
- **Full game by touch:** play.cjs, 33 touch checks, 2x (seeds 31 and 62).
- **tough-tools:** `tt.js test --all`, covering mech, visual, stress and buff.
- **A03s perf:** 360x800@2, CDP CPU throttle 6x and 4x, on a factory scene and a full-decor scene.
