/* ===== Papa Potato 2.0.0 — UI, input, camera, save, tests ===== */
(function(){
"use strict";
var S=PP2,Dr=PPDraw;
function $(id){return document.getElementById(id);}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c];});}
var cv=$("cv"),ctx=cv.getContext("2d"),play=$("play"),app=$("app");
var seed0=(Date.now()%100000)+1;
var sim=new S.Sim(seed0);
var view={w:360,h:400,z:0.72,cx:6.5,cy:13.5,t:0,dpr:1,edit:false,ghost:null,sel:0,showPower:false};
var follow=true,paused=false,last=0,acc=0,frameN=0,fpsT=0,fpsN=0,fps=60;
var ZMIN=0.38,ZMAX=1.7;
/* ---------- storage (boots even when storage throws) ---------- */
function store(){try{return window.localStorage;}catch(e){return null;}}
function saveGame(){try{var ls=store();if(ls)ls.setItem(S.SAVE_KEY,sim.saveStr());}catch(e){}}
function loadGame(){try{var ls=store();if(!ls)return false;var v=ls.getItem(S.SAVE_KEY);if(!v)return false;return sim.load(v);}catch(e){return false;}}
/* ---------- canvas size ---------- */
/* adaptive render scale: full device sharpness while the phone keeps up; on a slow phone it steps the canvas
   resolution down in 0.25 steps (never below 1x) instead of dropping frames, and climbs back when there is headroom */
var RS={max:2,cur:2,acc:0,n:0,t:0,good:0,ban:{},lastDown:-99,clock:0};
function rsSet(v){v=Math.max(1,Math.min(RS.max,Math.round(v*4)/4));if(v===RS.cur)return;RS.cur=v;resize();}
function rsTick(dt){RS.clock+=dt;if(RS.clock<3||document.hidden)return;RS.acc+=dt;RS.n++;RS.t+=dt;if(RS.t<2)return;
  var avg=RS.acc/RS.n;RS.acc=0;RS.n=0;RS.t=0;
  if(avg>1/52&&RS.cur>1){if(RS.clock-RS.up<10)RS.ban[RS.cur]=1;RS.lastDown=RS.clock;RS.good=0;rsSet(RS.cur-0.25);return;}
  if(avg<1/57){RS.good+=2;var nx=RS.cur+0.25;if(RS.cur<RS.max&&RS.good>=6&&!RS.ban[nx]&&RS.clock-RS.lastDown>20){RS.good=0;RS.up=RS.clock;rsSet(nx);}}else RS.good=0;}
RS.up=-99;
function resize(){var w=Math.max(50,play.clientWidth),h=Math.max(50,play.clientHeight);RS.max=Math.min(2,window.devicePixelRatio||1);
  /* a new screen size / rotation / dpr costs differently: start again at full sharpness and re-measure */
  var sig=w+"x"+h+"@"+RS.max;if(sig!==RS.sig){RS.sig=sig;RS.cur=RS.max;RS.clock=0;RS.ban={};RS.acc=0;RS.n=0;RS.t=0;RS.good=0;RS.lastDown=-99;RS.up=-99;}if(RS.cur>RS.max)RS.cur=RS.max;var d=RS.cur;
  view.w=w;view.h=h;view.dpr=d;cv.width=Math.round(w*d);cv.height=Math.round(h*d);draw();}
window.addEventListener("resize",function(){resize();cmdLay();});window.addEventListener("orientationchange",function(){setTimeout(resize,120);});
/* ---------- camera ---------- */
function clampCam(){view.cx=Math.max(0,Math.min(S.W,view.cx));view.cy=Math.max(0,Math.min(S.H,view.cy));}
function camStep(dt){if(!follow)return;var p=sim.s.papa,tx=p.x,ty=p.y,k=1-Math.pow(0.02,dt);view.cx+=(tx-view.cx)*k;view.cy+=(ty-view.cy)*k;}
function panBy(dx,dy){var Z=view.z,dX=-dx/(32*Z),dY=-dy/(16*Z);view.cx+=(dX+dY)/2;view.cy+=(dY-dX)/2;clampCam();}
function setZoom(z,px,py){var a=px!=null?Dr.toWorld(px,py):null;view.z=Math.max(ZMIN,Math.min(ZMAX,z));
  if(a){Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);var b=Dr.toWorld(px,py);view.cx+=a.x-b.x;view.cy+=a.y-b.y;clampCam();}draw();}
function setFollow(on){follow=!!on;$("zFol").className=follow?"on":"";}
/* ---------- drawing ---------- */
function draw(){ctx.setTransform(view.dpr,0,0,view.dpr,0,0);/* the renderer paints the whole canvas (ground fill first) */
  try{Dr.render(ctx,sim,view);}catch(e){if(!draw.err){draw.err=1;console.error(e);}}}
/* ---------- sim events -> particles, sounds of the world ---------- */
function pumpEvents(){var ev=sim.events;if(!ev.length)return;for(var i=0;i<ev.length;i++){Dr.emit(ev[i]);}sim.events=[];}
/* ---------- main loop: fixed 1/60 steps, dt clamp ---------- */
function frame(ts){requestAnimationFrame(frame);
  if(!last)last=ts;var dt=Math.min(0.1,Math.max(0,(ts-last)/1000));last=ts;
  fpsN++;fpsT+=dt;if(fpsT>=1){fps=fpsN/fpsT;fpsN=0;fpsT=0;}
  if(paused)return;if(!(window.__tt&&window.__tt.manual))rsTick(dt);
  if(!(window.__tt&&window.__tt.manual)){acc+=dt;var n=0;while(acc>=S.DT&&n<6){sim.step(S.DT);acc-=S.DT;n++;}if(n>=6)acc=0;}
  view.t+=dt;camStep(dt);pumpEvents();Dr.stepParts(dt);
  if(view.edit&&view.ghost)refreshGhost();
  draw();frameN++;
  if(frameN%6===0)updateHud();
  if(frameN%30===0){refreshPanel();radioSync();}
  if(frameN%300===0)saveGame();}
/* ---------- HUD ---------- */
var TASKTXT={idle:"waiting for work",doze:"dozing on the floor (out of energy)",grab:"grabbing raw potatoes",trayTake:"taking potatoes off the tray",washRaw:"rinsing raw potatoes at the sink",peel:"peeling",drop:"dropping off peeled potatoes",toTub:"loading the scrub tub",scrub:"scrubbing potatoes",tubTake:"taking clean ones out of the tub",toss:"tossing clean ones into the canal",eat:"eating",puke:"PUKING! (he ate too much)",nap:"napping",watch:"watching TV",rinse:"rinsing his hands",water:"watering the plant",tune:"tuning the radio",fix:"clearing a jam",sweep:"sweeping peels",mop:"mopping up the puke",pickSack:"picking his sack back up"};
function taskLine(){var p=sim.s.papa,t=p.task;if(!t)return p.lazy?"Papa is AUTO-LAZY (tired)":"Papa is waiting for work";var s=TASKTXT[t.type]||t.type;
  if(t.stage==="walk")s="walking: "+s;if(p.hold.length)s+=" · holding "+p.hold.length;return "Papa: "+s;}
var hudCache={};
function setTxt(id,v){if(hudCache[id]!==v){hudCache[id]=v;$(id).textContent=v;}}
function setBar(id,v,low){var k=id+"b";v=Math.max(0,Math.min(100,v));var r=Math.round(v);if(hudCache[k]===r)return;hudCache[k]=r;var b=$(id);b.firstChild.style.transform="scaleX("+(v/100)+")";b.className=b.className.replace(/ low/,"")+(v<low?" low":"");}
var lastMsg="",toastT=0;
function updateHud(){var s=sim.s,p=s.papa;
  setTxt("hCoins",s.coins+"c");setTxt("hFood","FOOD "+s.food+"/"+sim.cooCap());setTxt("hPeels","PEELS "+s.peels.length);$("hPeels").className=s.peels.length>45?"messy":"";
  setTxt("hLv","LV "+s.level);var m=sim.shiftMin(),hh=Math.floor(m/60),mm=Math.floor(m%60);setTxt("hClock",((hh+11)%12+1)+":"+(mm<10?"0":"")+mm+(hh<12?" AM":" PM"));
  var mood=Math.round(p.mood);setTxt("pH",Math.round(p.hunger)+"");setTxt("pE",Math.round(p.energy)+"");setTxt("pM",mood+"");setTxt("pD",Math.round(p.hands)+"");
  setBar("bH",p.hunger,25);setBar("bE",p.energy,25);setBar("bM",mood,30);setBar("bD",p.hands,25);
  setTxt("hState",taskLine());
  if(s.msg!==lastMsg){lastMsg=s.msg;toast(s.msg);}
  if(toastT&&view.t>toastT){toastT=0;$("toast").className="off";}
  var jam=sim.jammed().length>0,ob=document.querySelectorAll(".ob");for(var i=0;i<ob.length;i++){var o=ob[i].getAttribute("data-o"),cls="ob"+((p.order===o||(o==="work"&&!p.order))?" on":"")+(o==="fix"&&jam?" alert":"");if(ob[i].className!==cls)ob[i].className=cls;}}
function toast(m){if(!m)return;var t=$("toast");t.textContent=m;t.className="";toastT=view.t+4.5;}
/* ---------- command boxes ---------- */
function fmtV(c,v){switch(c.fmt){case "pace":return S.PACE[v]||v;case "pct":return v<=0&&c.min===0?"OFF":v+"%";case "num":return v<=0?"OFF":String(v);case "style":return (S.STYLE[v]||{}).n||v;
  case "deliver":return S.DELIVER[v]||v;case "onoff":return v?"ON":"OFF";case "speed":return S.SPEED_NAME[v]||v;}return String(v);}
function needOk(n){if(!n)return true;if(n==="roomKey")return sim.key();if(n==="machine")return sim.s.objs.some(function(o){return S.isMach(o.id);});if(n==="belt")return sim.placed("belt");return sim.placed(n);}
function needTxt(n){if(n==="roomKey")return "Needs the ROOM KEY (SHOP)";if(n==="machine")return "Place a machine first";if(n==="belt")return "Place a belt first";var it=S.itemDef(n);return "Place the "+(it?it.name:n)+" first";}
var panelSig="";
function buildCmds(){var h="";S.COMMANDS.forEach(function(c,i){var ok=needOk(c.need),v=sim.s.box[c.id];
  h+='<div class="cb'+(ok?"":" lock")+'" data-c="'+c.id+'"><button class="pm" type="button" data-d="1" data-c="'+c.id+'">+</button><div class="mid"><div class="nm"><span>'+esc(c.name)+'</span><b id="cv_'+c.id+'">'+esc(fmtV(c,v))+'</b></div>'+
    (ok?'<input type="range" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'" value="'+v+'" data-c="'+c.id+'" id="cr_'+c.id+'">':'<div class="why">'+esc(needTxt(c.need))+'</div>')+'</div><button class="pm" type="button" data-d="-1" data-c="'+c.id+'">&minus;</button></div>';});
  $("cmds").innerHTML='<div id="cmdList">'+h+'</div><div id="cmdPg"><button type="button" id="pgUp" aria-label="previous boxes">&#9650;</button><span id="pgN"></span><button type="button" id="pgDn" aria-label="more boxes">&#9660;</button></div>';cmdLay();}
/* command boxes are paged (no scrolling panel): as many boxes per page as fit */
var cmdPage=0,cmdPer=3;
function cmdLay(){var pn=$("panel"),L=$("cmdList");if(!L)return;var bx=L.querySelector(".cb"),bh=bx?bx.offsetHeight+2:62;if(bh<40)bh=62;var avail=pn.clientHeight-6;
  cmdPer=Math.max(1,Math.floor((avail+2)/bh));var n=S.COMMANDS.length,pages=Math.max(1,Math.ceil(n/cmdPer));if(cmdPage>=pages)cmdPage=pages-1;if(cmdPage<0)cmdPage=0;
  var cbs=L.querySelectorAll(".cb");for(var i=0;i<cbs.length;i++){var on=Math.floor(i/cmdPer)===cmdPage;cbs[i].style.display=on?"grid":"none";}
  $("pgN").textContent=(cmdPage+1)+"/"+pages;$("pgUp").disabled=cmdPage<=0;$("pgDn").disabled=cmdPage>=pages-1;$("cmdPg").style.visibility=pages>1?"visible":"hidden";}
function showCmd(id){var i=-1;S.COMMANDS.forEach(function(c,k){if(c.id===id)i=k;});if(i<0)return;cmdPage=Math.floor(i/cmdPer);cmdLay();}
function lockSig(){return S.COMMANDS.map(function(c){return needOk(c.need)?1:0;}).join("");}
function refreshPanel(){var sig=lockSig();if(sig!==panelSig){panelSig=sig;buildCmds();return;}
  S.COMMANDS.forEach(function(c){var v=sim.s.box[c.id],e=$("cv_"+c.id);if(e){var t=fmtV(c,v);if(e.textContent!==t)e.textContent=t;}var r=$("cr_"+c.id);if(r&&document.activeElement!==r&&+r.value!==v)r.value=v;});}
$("cmds").addEventListener("click",function(e){var pg=e.target.closest?e.target.closest("#pgUp,#pgDn"):null;if(pg){cmdPage+=pg.id==="pgUp"?-1:1;cmdLay();return;}var b=e.target.closest?e.target.closest("button[data-c]"):null;if(!b)return;var id=b.getAttribute("data-c"),c=S.BOX[id];if(!c||!needOk(c.need)){toast(c?needTxt(c.need):"");return;}
  sim.setBox(id,sim.s.box[id]+c.step*(+b.getAttribute("data-d")));refreshPanel();radioSync();saveGame();});
$("cmds").addEventListener("input",function(e){var r=e.target;if(r.tagName!=="INPUT")return;var id=r.getAttribute("data-c");sim.setBox(id,+r.value);var c=S.BOX[id],el=$("cv_"+id);if(el)el.textContent=fmtV(c,sim.s.box[id]);radioSync();});
$("cmds").addEventListener("change",function(){saveGame();});
$("orders").addEventListener("click",function(e){var b=e.target.closest?e.target.closest("button[data-o]"):null;if(!b)return;var o=b.getAttribute("data-o");
  if(o==="fix"){var j=sim.jammed();if(!j.length){toast("Nothing is jammed.");return;}sim.sendFix(j[0].u);toast("Papa is on his way to clear the jam.");}
  else{sim.order(o);toast({eat:"EAT: he heads for the cooler.",nap:"NAP: he sets the sack down and goes to bed.",clean:"CLEAN: he sweeps up (puke first).",work:"WORK: back to his job."}[o]);}
  setFollow(true);updateHud();});
/* ---------- the info card (tap a thing) ---------- */
var cardFor=null;
function showCard(title,text,btns,tag){cardFor=tag||null;$("cardT").textContent=title;$("cardX2").innerHTML=text;var h="";(btns||[]).forEach(function(b){h+='<button type="button" data-k="'+b[0]+'">'+b[1]+'</button>';});$("cardB").innerHTML=h;$("cardB").style.display=btns&&btns.length?"grid":"none";$("card").className="show";}
function hideCard(){cardFor=null;$("card").className="";}
$("cardX").addEventListener("click",hideCard);
function machState(o){if(o.jam)return "JAMMED";if(!sim.powered(o))return "NO POWER";if(!o.on)return "OFF";if(sim.s.box.mspeed<=0)return "MACHINE SPEED OFF";return "RUNNING";}
function objCard(o){var it=S.itemDef(o.id)||{name:o.id,fx:""},b=[];var t=esc(it.fx||"");
  if(S.isMach(o.id)){t='<b style="color:'+(o.jam?"#ff7a6a":"#7dff9a")+'">'+machState(o)+'</b> · faces '+S.DNAME[o.r]+' (arrow = output)<br>'+t;b.push(["mtog",o.on?"TURN OFF":"TURN ON"]);if(o.jam)b.push(["mfix","FIX JAM"]);}
  if(o.id==="generator"){if(!sim.power)sim.calcPower();var src=sim.power.src.filter(function(s){return s.u===o.u;})[0];if(src)t='<b style="color:#9fd0ff">LOAD '+src.used+' / '+src.cap+'</b> · ring '+src.range.toFixed(1)+' tiles<br>'+t;}
  if(o.id==="belt"){t='Heading <b>'+S.DNAME[o.r]+'</b>'+(sim.powered(o)?'':' · <b style="color:#ff9a6a">NO POWER</b>')+'<br>'+t;b.push(["rot","TURN"]);}
  b.push(["move","MOVE"]);if(!o.st)b.push(["store","STORE"]);
  showCard(it.name,t,b,o.u);}
function papaCard(){var p=sim.s.papa;showCard("PAPA","Hunger "+Math.round(p.hunger)+" · Energy "+Math.round(p.energy)+" · Mood "+Math.round(p.mood)+" · Hands "+Math.round(p.hands)+"<br>"+esc(taskLine())+(sim.s.equip.carrySack?"<br>Sack: "+(p.sack.on?"on his back":"on the floor"):""),[["o:eat","EAT"],["o:nap","NAP"],["o:work","WORK"]],"papa");}
$("cardB").addEventListener("click",function(e){var b=e.target.closest?e.target.closest("button[data-k]"):null;if(!b)return;var k=b.getAttribute("data-k"),o=sim.obj(cardFor),r;
  if(k.indexOf("o:")===0){sim.order(k.slice(2));hideCard();return;}
  if(!o){hideCard();return;}
  if(k==="mtog"){sim.machToggle(o.u);objCard(o);}
  else if(k==="mfix"){sim.sendFix(o.u);toast("Papa is going to clear the jam.");hideCard();setFollow(true);}
  else if(k==="rot"){r=sim.rotate(o.u);if(!r.ok)toast(r.why);objCard(o);}
  else if(k==="move"){hideCard();enterEdit();startMove(o);}
  else if(k==="store"){r=sim.store(o.u);toast(r.ok?"Stored in INV.":r.why);hideCard();saveGame();}});
/* ---------- pointer input on the map ---------- */
var ptrs={},gest=null,lastBrush=null;
function rel(e){var r=cv.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
function dirtyNear(px,py){var best=null,bd=30*view.z+12;sim.s.pots.forEach(function(q){if(q.k!==1||q.d<=0.15)return;if(q.m!=="pool"&&q.m!=="canal"&&q.m!=="tub")return;var h=q.m==="tub"?0.8:0.05,a=Dr.project(q.x,q.y,h),d=Math.hypot(a[0]-px,a[1]-py);if(d<bd){bd=d;best=q;}});return best;}
function brushAt(px,py,str){var q=dirtyNear(px,py);if(!q)return 0;return sim.brush(q.x,q.y,str);}
cv.addEventListener("pointerdown",function(e){var p=rel(e);ptrs[e.pointerId]={x:p[0],y:p[1]};try{cv.setPointerCapture(e.pointerId);}catch(x){}
  var ids=Object.keys(ptrs);
  if(ids.length===2){var a=ptrs[ids[0]],b=ptrs[ids[1]];gest={mode:"pinch",d0:Math.hypot(a.x-b.x,a.y-b.y)||1,z0:view.z};return;}
  Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);
  var mode="tap";
  if(view.edit&&view.ghost){var w=Dr.toWorld(p[0],p[1]),f=S.fp({id:view.ghost.id,x:view.ghost.x,y:view.ghost.y,r:view.ghost.r});if(w.x>=f.x-0.6&&w.x<=f.x+f.w+0.6&&w.y>=f.y-0.6&&w.y<=f.y+f.h+0.6)mode="ghost";}
  else if(!view.edit&&dirtyNear(p[0],p[1]))mode="brush";
  gest={mode:mode,x0:p[0],y0:p[1],lx:p[0],ly:p[1],moved:0,t0:view.t};if(mode==="brush"){lastBrush=[p[0],p[1]];}
  e.preventDefault();});
cv.addEventListener("pointermove",function(e){if(!ptrs[e.pointerId]||!gest)return;var p=rel(e);ptrs[e.pointerId]={x:p[0],y:p[1]};
  if(gest.mode==="pinch"){var ids=Object.keys(ptrs);if(ids.length<2)return;var a=ptrs[ids[0]],b=ptrs[ids[1]];setZoom(gest.z0*Math.hypot(a.x-b.x,a.y-b.y)/gest.d0,(a.x+b.x)/2,(a.y+b.y)/2);return;}
  var dx=p[0]-gest.lx,dy=p[1]-gest.ly;gest.moved+=Math.abs(dx)+Math.abs(dy);gest.lx=p[0];gest.ly=p[1];
  if(gest.mode==="ghost"){moveGhostTo(p[0],p[1]);return;}
  if(gest.mode==="brush"){if(Math.hypot(p[0]-lastBrush[0],p[1]-lastBrush[1])>14){lastBrush=[p[0],p[1]];brushAt(p[0],p[1],0.2);}return;}
  if(gest.moved>8){gest.mode="pan";setFollow(false);panBy(dx,dy);}});
function endPtr(e){if(!ptrs[e.pointerId])return;delete ptrs[e.pointerId];if(!gest)return;
  if(gest.mode==="pinch"){if(!Object.keys(ptrs).length)gest=null;return;}
  if(gest.moved<=8&&(gest.mode==="tap"||gest.mode==="brush"||gest.mode==="ghost"))tapAt(gest.x0,gest.y0,gest.mode);
  if(gest.mode==="ghost")refreshEdit();gest=null;}
cv.addEventListener("pointerup",endPtr);cv.addEventListener("pointercancel",function(e){delete ptrs[e.pointerId];gest=null;});
cv.addEventListener("wheel",function(e){var p=rel(e);setZoom(view.z*(e.deltaY<0?1.12:1/1.12),p[0],p[1]);e.preventDefault();},{passive:false});
function tapAt(px,py,mode){Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);var w=Dr.toWorld(px,py);
  if(view.edit){if(view.ghost){moveGhostTo(px,py);refreshEdit();return;}var o=Dr.pick(sim,px,py);if(o){if(o.id==="belt"&&view.sel===o.u){var r=sim.rotate(o.u);toast("Belt heading "+S.DNAME[o.r]+".");}view.sel=o.u;}else view.sel=0;refreshEdit();return;}
  if(mode==="brush"){var n=brushAt(px,py,0.25);if(n){toast("Scrub scrub! Keep brushing to get them clean (5c at the ship hole).");return;}}
  var pp=sim.s.papa,pa=Dr.project(pp.x,pp.y,0.7);if(Math.hypot(pa[0]-px,pa[1]-py)<30*view.z+10){papaCard();return;}
  var ob=Dr.pick(sim,px,py);
  if(ob){if(ob.id==="belt"){var rr=sim.rotate(ob.u);if(rr.ok){toast("Belt now heading "+S.DNAME[ob.r]+".");saveGame();}if(cardFor===ob.u)objCard(ob);return;}objCard(ob);return;}
  var tx=Math.floor(w.x),ty=Math.floor(w.y);
  if(S.inRect(tx,ty,S.FIX.pile)){showCard("RAW POTATO PILE","Endless raw potatoes. Papa grabs them here, or a POTATO HOPPER touching the pile sucks them up.",[],null);return;}
  if(S.inRect(tx,ty,S.FIX.chute)){showCard("SHIPPING CHUTE","Drop peeled potatoes in (Papa, or a belt heading NORTH into it). Pays by dirt: dirty 2c, a bit clean 3c, clean 4c.",[],null);return;}
  if(S.inRect(tx,ty,S.FIX.scanK)||S.inRect(tx,ty,S.FIX.scanW)){showCard("X-RAY SCANNER","The pass-through in the wall. Peeled potatoes go in on the kitchen side (Papa, or a belt heading EAST into it) and slide out into the wash pool."+(sim.key()?"":" Needs the ROOM KEY."),[],null);return;}
  if(S.isWater(tx,ty)){showCard(S.isPool(tx,ty)?"WASH POOL":"CANAL","Peeled potatoes soak clean slowly while the current carries them to the ship hole. Brush them with your finger to clean them faster: clean ones pay 5c.",[],null);return;}
  hideCard();}
$("zIn").addEventListener("click",function(){setZoom(view.z*1.2,view.w/2,view.h/2);});
$("zOut").addEventListener("click",function(){setZoom(view.z/1.2,view.w/2,view.h/2);});
$("zFol").addEventListener("click",function(){setFollow(!follow);});
$("goK").addEventListener("click",function(){setFollow(false);view.cx=7;view.cy=12;draw();});
$("goW").addEventListener("click",function(){setFollow(false);view.cx=20;view.cy=8;draw();});
/* ---------- EDIT: place / move / turn / store, every item placed freely by the real rules ---------- */
var editTab="mach",lastBeltR=0,ghostKey="";
var TABS=[["mach","MACHINE"],["floor","FLOOR"],["rug","RUGS"],["wall","WALL"],["placed","PLACED"]];
function tabOf(it){if(it.cat==="belt"||it.cat==="mach")return "mach";return it.cat;}
function enterEdit(){if(view.edit)return;view.edit=true;view.showPower=true;app.className="editing";hideCard();refreshEdit();navMark();}
function exitEdit(){view.edit=false;view.showPower=false;view.ghost=null;view.sel=0;app.className="";navMark();saveGame();}
function startGhost(id){Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);var w=Dr.toWorld(view.w/2,view.h/2),it=S.itemDef(id),r=id==="belt"?lastBeltR:0,f=S.fp({id:id,x:0,y:0,r:r});
  var gx=Math.round(w.x-f.w/2),gy=Math.round(w.y-f.h/2);
  /* start it on the nearest free spot so it is ready to place */
  if(it.cat!=="wall"){var found=null;for(var d=0;d<9&&!found;d++)for(var yy=gy-d;yy<=gy+d&&!found;yy++)for(var xx=gx-d;xx<=gx+d&&!found;xx++){if(Math.max(Math.abs(xx-gx),Math.abs(yy-gy))!==d)continue;if(sim.canPlace(id,xx,yy,r).ok)found=[xx,yy];}if(found){gx=found[0];gy=found[1];}}
  view.ghost={id:id,x:gx,y:gy,r:r,ok:false,why:"",moveU:0};view.sel=0;ghostKey="";refreshGhost();refreshEdit();
  var gf=S.fp({id:id,x:gx,y:gy,r:r});if(it.cat!=="wall"){setFollow(false);view.cx=gf.x+gf.w/2;view.cy=gf.y+gf.h/2;}}
function startMove(o){var g={id:o.id,x:o.x,y:o.y,r:o.r,ok:true,why:"",moveU:o.u};if(o.wall){g.x=o.wall==="N"?o.x:1;g.y=o.wall==="N"?1:o.y;}view.ghost=g;view.sel=o.u;ghostKey="";refreshGhost();refreshEdit();}
function moveGhostTo(px,py){var g=view.ghost;if(!g)return;Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);var w=Dr.toWorld(px,py),f=S.fp({id:g.id,x:0,y:0,r:g.r});
  g.x=Math.max(-2,Math.min(S.W,Math.round(w.x-f.w/2)));g.y=Math.max(-2,Math.min(S.H,Math.round(w.y-f.h/2)));refreshGhost();}
function refreshGhost(){var g=view.ghost;if(!g)return;var k=g.id+","+g.x+","+g.y+","+g.r+","+g.moveU+","+sim.s.objs.length;if(k===ghostKey)return;ghostKey=k;var it=S.itemDef(g.id);
  if(it.cat==="wall"){var o=g.moveU?sim.obj(g.moveU):null,keep=o?o.wall:null;if(o)o.wall="X";var w=sim.wallSpot(g.id,g.x+0.5,g.y+0.5);if(o)o.wall=keep;g.ok=!!w;g.why=w?"":"No free wall spot for it in this room";}
  else{var c=sim.canPlace(g.id,g.x,g.y,g.r,g.moveU||undefined);g.ok=!!c.ok;g.why=c.ok?"":(c.why||"Can't go here");}
  var n=$("enote");if(n)n.innerHTML=ghostNote();}
function ghostNote(){var g=view.ghost;if(!g){var o=sim.obj(view.sel);return o?esc((S.itemDef(o.id)||{}).name||o.id)+' selected. TURN, MOVE or STORE it.':'Pick an item below, or tap a placed thing to select it. Tap a selected belt again to turn it.';}
  var it=S.itemDef(g.id);return esc(it.name)+(g.moveU?" (moving)":"")+": "+(g.ok?'<b style="color:#7dff9a">fits here, tap PLACE</b>':'<b style="color:#ff7a6a">'+esc(g.why)+'</b>')+". Drag it or tap where it goes.";}
function refreshEdit(){if(!view.edit)return;var h='<div class="tabs">',inv=sim.s.inv;
  TABS.forEach(function(t){h+='<button type="button" data-tab="'+t[0]+'" class="'+(editTab===t[0]?"on":"")+'">'+t[1]+'</button>';});h+='</div><div class="enote" id="enote">'+ghostNote()+'</div><div class="eact">';
  var g=view.ghost,sel=sim.obj(view.sel);
  if(g){h+='<button type="button" data-e="rot">TURN</button><button type="button" data-e="place"'+(g.ok?"":" disabled")+'>PLACE</button><button type="button" data-e="cancel">CANCEL</button>';}
  else{h+='<button type="button" data-e="srot"'+(sel&&!sel.wall?"":" disabled")+'>TURN</button><button type="button" data-e="move"'+(sel?"":" disabled")+'>MOVE</button><button type="button" data-e="store"'+(sel&&!sel.st?"":" disabled")+'>STORE</button>';}
  h+='<button type="button" data-e="done">DONE</button></div><div class="tray" style="margin-top:4px">';var any=0;
  if(editTab==="placed"){sim.s.objs.forEach(function(o){var it=S.itemDef(o.id);any=1;h+='<button type="button" class="ti'+(view.sel===o.u?" on":"")+'" data-sel="'+o.u+'">'+esc(it.name)+'<small>'+(o.wall?"wall":"at "+o.x+","+o.y)+'</small></button>';});}
  else S.ITEMS.forEach(function(it){if(tabOf(it)!==editTab||(inv[it.id]|0)<=0)return;any=1;h+='<button type="button" class="ti'+(g&&!g.moveU&&g.id===it.id?" on":"")+'" data-it="'+it.id+'">'+esc(it.name)+'<small>x'+inv[it.id]+' in INV</small></button>';});
  h+='</div>';if(!any)h+='<div class="enote">Nothing here in your INV. Buy items in the SHOP.</div>';
  $("edit").innerHTML=h;}
$("edit").addEventListener("click",function(e){var b=e.target.closest?e.target.closest("button"):null;if(!b||b.disabled)return;var r;
  if(b.hasAttribute("data-tab")){editTab=b.getAttribute("data-tab");refreshEdit();return;}
  if(b.hasAttribute("data-it")){startGhost(b.getAttribute("data-it"));return;}
  if(b.hasAttribute("data-sel")){var o=sim.obj(+b.getAttribute("data-sel"));if(o){view.ghost=null;view.sel=o.u;setFollow(false);var f=S.fp(o);view.cx=o.wall?(o.wall==="N"?o.x+1:2):f.x+f.w/2;view.cy=o.wall?(o.wall==="N"?2:o.y+1):f.y+f.h/2;}refreshEdit();return;}
  var k=b.getAttribute("data-e"),g=view.ghost,sel=sim.obj(view.sel);
  if(k==="done"){exitEdit();return;}
  if(k==="cancel"){view.ghost=null;refreshEdit();return;}
  if(k==="rot"&&g){if(S.itemDef(g.id).cat==="wall"){toast("Wall items hang flat on the wall.");return;}g.r=(g.r+1)%4;if(g.id==="belt")lastBeltR=g.r;refreshGhost();refreshEdit();return;}
  if(k==="place"&&g){if(g.moveU)r=sim.move(g.moveU,g.x,g.y,g.r);else r=sim.place(g.id,g.x,g.y,g.r);
    if(!r.ok){toast(r.why||"Can't go here");return;}
    if(!g.moveU&&g.id==="belt"&&(sim.s.inv.belt|0)>0){var d=S.DIRS[g.r];g.x+=d[0];g.y+=d[1];ghostKey="";refreshGhost();toast("Belt placed. The next one is ready ahead of it.");}
    else{view.sel=g.moveU||(r.o?r.o.u:0);view.ghost=null;toast(g.moveU?"Moved.":"Placed.");}
    saveGame();refreshEdit();return;}
  if(k==="srot"&&sel){r=sim.rotate(sel.u);if(!r.ok)toast(r.why);refreshEdit();saveGame();return;}
  if(k==="move"&&sel){startMove(sel);return;}
  if(k==="store"&&sel){r=sim.store(sel.u);toast(r.ok?"Stored in INV.":r.why);if(r.ok)view.sel=0;refreshEdit();saveGame();return;}});
/* ---------- sheets: SHOP / INV / HELP / RADIO ---------- */
var sheet=null;
function openSheet(k){sheet=k;$("ovl").className="show";$("sheetT").textContent={shop:"SHOP",inv:"INVENTORY",help:"HELP",radio:"RADIO"}[k];buildSheet();$("sheetBody").scrollTop=0;navMark();}
function closeSheet(){sheet=null;$("ovl").className="";navMark();saveGame();}
$("sheetX").addEventListener("click",closeSheet);
function navMark(){var b=document.querySelectorAll(".nb");for(var i=0;i<b.length;i++){var n=b[i].getAttribute("data-n");b[i].className="nb"+((n===sheet)||(n==="edit"&&view.edit)?" on":"");}}
$("nav").addEventListener("click",function(e){var b=e.target.closest?e.target.closest("button[data-n]"):null;if(!b)return;var n=b.getAttribute("data-n");
  if(n==="edit"){if(sheet)closeSheet();if(view.edit)exitEdit();else enterEdit();return;}if(sheet===n){closeSheet();return;}openSheet(n);});
function buildSheet(){var h=sheet==="shop"?buildShop():sheet==="inv"?buildInv():sheet==="help"?buildHelp():buildRadio();$("sheetBody").innerHTML=h;}
function btn(act,label,cls){return '<button class="go'+(cls?" "+cls:"")+'" type="button" data-act="'+act+'">'+label+'</button>';}
function row(nm,fx,btns){return '<div class="row"><div class="tx"><div class="nm">'+nm+'</div>'+(fx?'<div class="fx">'+fx+'</div>':'')+'</div>'+(btns?'<div class="btns">'+btns+'</div>':'')+'</div>';}
var SECS=[["key","KEY + TOOLS"],["mach","MACHINES + BELTS (LV 2+)"],["floor","FLOOR ITEMS"],["rug","CARPETS"],["wall","WALL ITEMS"],["basin","WASH POOL TOYS"],["theme","LOOKS"]];
function buildShop(){var s=sim.s,h="",lp=sim.levelPrice(),c=s.coins;
  h+='<div class="sec">LEVEL '+s.level+' · '+c+'c</div>';
  if(lp){var nxt=S.ITEMS.filter(function(it){return it.lv===s.level+1;}).map(function(it){return it.name;}).join(", ");h+=row("LEVEL "+(s.level+1)+" <b>"+lp+"c</b>","Unlocks: "+esc(nxt),btn("lv",c>=lp?"BUY":"NEED<br>"+lp+"c",c>=lp?"":"poor"));}
  else h+=row("MAX LEVEL","Every item is unlocked.","");
  var fp=sim.foodPrice();h+='<div class="sec">FOOD</div>'+row("FOOD CAN <b>"+fp+"c</b>","Cooler "+s.food+"/"+sim.cooCap()+". 1 can = +55 hunger. Don't feed him over 60% hunger: he pukes.",btn("food:1","BUY 1",c>=fp?"":"poor")+btn("food:5","BUY 5",c>=fp?"":"poor"));
  SECS.forEach(function(sc){var list=S.ITEMS.filter(function(it){return (sc[0]==="mach"?(it.cat==="mach"||it.cat==="belt"):sc[0]==="key"?(it.cat==="key"||it.cat==="tool"):it.cat===sc[0]);});if(!list.length)return;h+='<div class="sec">'+sc[1]+'</div>';
    list.forEach(function(it){var pr=sim.itemPrice(it.id),own=s.owned[it.id]|0,lock=it.lv>s.level,b;
      if(lock)b=btn("x","LV "+it.lv,"lock");else if(!it.stack&&own)b=btn("x","OWNED","done");
      else if(it.cat==="belt")b=btn("item:"+it.id+":1","BUY 1<br>"+pr+"c",c>=pr?"":"poor")+btn("item:"+it.id+":10","BUY 10<br>"+pr*10+"c",c>=pr*10?"":"poor");
      else b=btn("item:"+it.id+":1","BUY<br>"+pr+"c",c>=pr?"":"poor");
      h+=row(esc(it.name)+(it.stack&&own?" <b>x"+own+"</b>":"")+(lock?"":" <b>"+pr+"c</b>"),esc(it.fx),b);});});
  h+='<div class="sec">UPGRADES</div>';
  S.UPS.forEach(function(u){var l=sim.up(u.id),pr=u.prices[l],lock=(u.lv||1)>s.level,b;b=l>=u.max?btn("x","MAX","done"):lock?btn("x","LV "+u.lv,"lock"):btn("up:"+u.id,"BUY<br>"+pr+"c",c>=pr?"":"poor");
    h+=row(esc(u.name)+" <b>"+l+"/"+u.max+"</b>",esc(u.fx),b);});
  return h;}
function buildInv(){var s=sim.s,h="";
  h+='<div class="sec">ON PAPA</div>';var tools=S.ITEMS.filter(function(it){return it.cat==="tool";}),any=0;
  tools.forEach(function(it){if(!(s.owned[it.id]|0))return;any=1;var on=s.equip[it.id];h+=row(esc(it.name)+" <b>"+(on?"ON":"OFF")+"</b>",esc(it.fx),btn("eq:"+it.id,on?"TAKE<br>OFF":"PUT<br>ON",on?"done":""));});
  if(!any)h+=row("NO TOOLS YET","Buy the CARRY SACK, BETTER PEELER and BROOM + DUSTPAN in the SHOP.","");
  h+='<div class="sec">TO PLACE</div>';any=0;
  S.ITEMS.forEach(function(it){var n=s.inv[it.id]|0;if(n<=0)return;any=1;h+=row(esc(it.name)+" <b>x"+n+"</b>",esc(it.fx),btn("pl:"+it.id,"PLACE",""));});
  if(!any)h+=row("NOTHING WAITING","Everything you own is placed. Store things from EDIT to get them back here.","");
  h+='<div class="sec">WASH POOL TOYS</div>';any=0;
  S.ITEMS.forEach(function(it){if(it.cat!=="basin"||!(s.owned[it.id]|0))return;any=1;var on=s.basin[it.id];h+=row(esc(it.name)+" <b>"+(on?"IN":"OUT")+"</b>",esc(it.fx),btn("bs:"+it.id,on?"TAKE<br>OUT":"PUT<br>IN",on?"done":""));});
  if(!any)h+=row("NONE YET","The duck, toy boat and bubble maker (SHOP, LV 3+).","");
  if((s.owned.wallpaper|0)||(s.owned.floorTiles|0)){h+='<div class="sec">LOOKS</div>';
    if(s.owned.wallpaper|0)h+=row("WALLS <b>"+S.THEMES.wall[s.decor.wall]+"</b>","",S.THEMES.wall.map(function(n,i){return btn("th:wall:"+i,n.split(" ")[0],s.decor.wall===i?"done":"");}).join(""));
    if(s.owned.floorTiles|0)h+=row("FLOOR <b>"+S.THEMES.floor[s.decor.floor]+"</b>","",S.THEMES.floor.map(function(n,i){return btn("th:floor:"+i,n.split(" ")[0],s.decor.floor===i?"done":"");}).join(""));}
  var st=s.stats;h+='<div class="sec">RECORD</div>'+row("SHIPPED <b>"+s.shipped+"</b> · CLEAN <b>"+s.shippedClean+"</b> · EARNED <b>"+s.earned+"c</b>","Peeled by Papa "+st.peeled+" · by machines "+st.machPeeled+" · scrubbed "+st.scrubbed+" · washer drum "+st.drumWashed+" · you brushed "+st.brushed+" · jams "+st.jams+" (fixed "+st.fixed+") · pukes "+st.pukes+" · door trips "+st.doorTrips,"");
  h+=row("NEW GAME","Wipes this Papa Potato 2 save and starts over.",btn("reset","RESET","poor"));
  return h;}
function buildHelp(){var h='<div class="help">';
  h+='<div class="sec">HOW IT WORKS</div><p><b>Papa works on his own.</b> He grabs raw potatoes from the pile, peels them at the peel table and drops them in the chute. You set how he works with the <b>COMMAND BOXES</b> (+ and &minus;, or slide). The big buttons <b>EAT NAP CLEAN FIX WORK</b> are one-time orders.</p>';
  h+='<p><b>Money:</b> raw 1c · peeled dirty 2c · half clean 3c · clean 4c in the chute · <b>clean through the wash-room ship hole 5c</b>. Peeled potatoes come out dirty.</p>';
  h+='<p><b>The map:</b> one kitchen and one wash room. The camera follows Papa (&#9678;). Drag to look around, pinch or + / &minus; to zoom, KITCHEN / WASH jump the view. Papa walks through the metal door with whatever he carries (it needs the <b>ROOM KEY</b>).</p>';
  h+='<div class="sec">WASH ROOM</div><p>Three ways to clean peeled potatoes: <b>SEND PEELED TO SCANNER</b> drops them through the X-ray in the wall into the pool, where they soak a little while the canal carries them to the ship hole. <b>CARRY</b> makes Papa walk them through the door to the scrub tub and scrub them himself. And <b>you can scrub</b>: tap or swipe dirty potatoes in the pool, canal or tub to brush them clean.</p>';
  h+='<div class="sec">BELTS + MACHINES (LV 2+)</div><p>Belts are single tiles: place them one by one in EDIT (the next tile is ready ahead after each), tap a belt to turn it. Potatoes ride the belts for real into whatever is ahead: the peel table tray, a machine\'s back, the chute (heading NORTH), the X-ray (heading EAST), the scrub tub or the water.</p>';
  h+='<p><b>POTATO HOPPER</b> touching the raw pile pumps raw potatoes out of its spout. <b>AUTO PEELER</b>: raw in the back, peeled out the front (arrow). <b>WASHER DRUM</b>: dirty peeled in, clean out. Machines and belts need <b>power</b>: the wall outlet powers 5 load nearby, a <b>GENERATOR</b> powers 12 in its blue ring. Belt 1, hopper 2, peeler 3, washer 3. Machines sometimes <b>JAM</b> (red light, smoke): FIX JAMS sends Papa, or press FIX.</p>';
  h+='<div class="sec">PAPA</div><p>Watch his bars: hunger, energy, mood, clean hands. Feed him when hunger is low, not when he is full: <b>eating over 60% hunger makes him puke</b> (a huge mess he has to mop). He sets his sack down before a nap and picks it up after. The broom and dustpan ride on his back and only move in his hands.</p>';
  h+='<div class="sec">COMMANDS</div>';S.COMMANDS.forEach(function(c){h+='<p><b>'+esc(c.name)+'</b> '+esc(c.what)+' '+esc(c.effect)+'</p>';});
  h+='<div class="sec">ITEMS</div>';S.ITEMS.forEach(function(it){h+='<p><b>'+esc(it.name)+'</b> (LV '+it.lv+') '+esc(it.fx)+'</p>';});
  h+='<div class="sec">UPGRADES</div>';S.UPS.forEach(function(u){h+='<p><b>'+esc(u.name)+'</b> '+esc(u.fx)+'</p>';});
  h+='<p style="color:#7f93ad">Papa Potato 2.0.0 · Tough &amp; J\'s Arcade · save: this phone only.</p></div>';return h;}
/* ---------- radio (ported from 0.4.11) ---------- */
var radioNote="";
function radioWant(){var s=sim.s,d=s.decor,p=s.papa,dist=99,rd=sim.objsOf("radio")[0];if(rd&&p.where!=="w"){var f=S.fp(rd);dist=Math.hypot(p.x-f.x-0.5,p.y-f.y-0.5)*0.6*1.6;}
  return {on:s.box.radio>0,placed:!!rd,st:d.radioSt|0,vol:d.radioVol==null?6:d.radioVol|0,near:d.radioNear?1:0,dist:dist,papaWash:p.where==="w",viewWash:view.cx>14.5&&view.cy<16};}
function radioSync(){try{if(window.PPRadio)PPRadio.update(radioWant());}catch(e){}}
function radioWake(){try{if(window.PPRadio){PPRadio.update(radioWant());PPRadio.wake();}}catch(e){}}
function radioPickInput(){var inp=$("musicPick");if(inp)return inp;inp=document.createElement("input");inp.type="file";inp.id="musicPick";inp.accept="audio/*";inp.multiple=true;inp.setAttribute("data-tt-allow-offscreen","");
  inp.style.cssText="position:absolute;left:-9999px;top:0;width:1px;height:1px;opacity:0";
  inp.addEventListener("change",function(){var r={added:0,first:-1};try{r=PPRadio.addFiles(inp.files);}catch(e){}try{inp.value="";}catch(e2){}
    if(r.added>0){sim.s.decor.radioSt=2;sim.setBox("radio",1);radioWake();PPRadio.playSong(r.first);}radioNote=r.added>0?("Added "+r.added+" song"+(r.added>1?"s":"")+"."):"No music picked.";if(sheet==="radio")buildSheet();});
  document.body.appendChild(inp);return inp;}
function radioAct(c){var d=sim.s.decor;radioWake();
  if(c==="power")sim.setBox("radio",sim.s.box.radio>0?0:1);
  else if(c.indexOf("st:")===0){d.radioSt=Math.max(0,Math.min(2,+c.slice(3)|0));if(sim.s.box.radio<=0)sim.setBox("radio",1);if(d.radioSt===2&&!PPRadio.hasGoodSong())radioNote="Pick songs first (ADD SONGS). Playing POTATO FM until then.";}
  else if(c==="pick"){radioNote="";try{radioPickInput().click();}catch(e){radioNote="This phone did not open a file picker.";}}
  else if(c.indexOf("song:")===0){d.radioSt=2;if(sim.s.box.radio<=0)sim.setBox("radio",1);radioWake();PPRadio.playSong(+c.slice(5)|0);}
  else if(c==="next"||c==="prev"){d.radioSt=2;if(sim.s.box.radio<=0)sim.setBox("radio",1);radioWake();if(c==="next")PPRadio.next();else PPRadio.prev();}
  else if(c==="vol+")d.radioVol=Math.min(10,(d.radioVol|0)+1);else if(c==="vol-")d.radioVol=Math.max(0,(d.radioVol|0)-1);
  else if(c==="near")d.radioNear=d.radioNear?0:1;else if(c==="clear"){PPRadio.clearSongs();if(d.radioSt===2)d.radioSt=0;radioNote="Song list cleared.";}
  radioSync();buildSheet();refreshPanel();}
function buildRadio(){var s=sim.s,d=s.decor,on=s.box.radio>0,st=d.radioSt|0,h="",i,R={songs:[],cur:-1,supported:false};try{if(window.PPRadio)R=PPRadio.state();}catch(e){}
  var songs=R.songs||[],good=false;try{good=window.PPRadio&&PPRadio.hasGoodSong();}catch(e){}var placed=sim.placed("radio");
  h+='<div class="sec">POWER</div>'+row("RADIO <b>"+(on?"ON":"OFF")+"</b>","Music ON: energy drains 20% slower and he works 5% faster.",btn("radio:power",on?"TURN<br>OFF":"TURN<br>ON",on?"done":""));
  if(!placed)h+=row("NOT PLACED","Buy the RADIO (LV 3) and place it from EDIT to hear it and get the bonus.","");
  if(!R.supported)h+=row("NO SOUND","This phone has no WebAudio. The bonus still works.","");
  h+='<div class="sec">STATION</div>';var names=[["POTATO FM","Lo-fi beats, made live by the game."],["SPUD JAZZ","Slow jazz, made live by the game."],["MY MUSIC","Your own songs from this phone."]];
  for(i=0;i<3;i++){var sel=st===i;h+=row(names[i][0]+(sel?" <b>"+(on?"ON AIR":"TUNED")+"</b>":""),names[i][1]+(i===2&&!good?" Pick songs below first.":""),btn("radio:st:"+i,sel?"TUNED":"TUNE",sel?"done":(i<2||good?"":"poor")));}
  h+='<div class="sec">MY MUSIC</div>'+row("ADD SONGS <b>"+songs.length+"</b>","Pick music files on your phone. They play out of the little radio. Nothing leaves the phone. The list lasts until you close the game.",btn("radio:pick","ADD<br>SONGS",""));
  for(i=0;i<songs.length;i++){var now=st===2&&R.cur===i&&R.playing==="song";h+=row((i+1)+". "+esc(songs[i].name)+(now?" <b>PLAYING</b>":"")+(songs[i].bad?" <b>WON'T PLAY</b>":""),"",btn("radio:song:"+i,now?"&#9654;":"PLAY",now?"done":(songs[i].bad?"poor":"")));}
  if(songs.length)h+=row("CONTROLS","",btn("radio:prev","&lt;&lt;","")+btn("radio:power",on?"||":"&#9654;",on?"done":"")+btn("radio:next","&gt;&gt;","")+btn("radio:clear","CLEAR","poor"));
  h+='<div class="sec">SOUND</div>'+row("VOLUME <b>"+(d.radioVol|0)+" / 10</b>","",btn("radio:vol-","&minus;","")+btn("radio:vol+","+",""));
  h+=row("LOUDER NEAR PAPA <b>"+(d.radioNear?"ON":"OFF")+"</b>","Louder when he is near the radio, muffled from the wash room.",btn("radio:near",d.radioNear?"ON":"OFF",d.radioNear?"done":""));
  var line=!on?"Off.":(!placed?"On, but the radio is not placed.":(st===2&&good?("Playing: "+(R.songName||"your songs")):("Playing: "+(st===1?"SPUD JAZZ":"POTATO FM"))));
  h+=row("NOW",esc(line)+(radioNote?"<br>"+esc(radioNote):""),"");return h;}
$("sheetBody").addEventListener("click",function(e){var b=e.target.closest?e.target.closest("button[data-act]"):null;if(!b)return;var a=b.getAttribute("data-act"),r=null,p=a.split(":");
  if(a==="x")return;
  if(p[0]==="radio"){radioAct(a.slice(6));return;}
  if(a==="lv")r=sim.buyLevel();
  else if(p[0]==="food")r=sim.buyFood(+p[1]);
  else if(p[0]==="up")r=sim.buyUp(p[1]);
  else if(p[0]==="item"){r=sim.buyItem(p[1],+p[2]);var it=S.ITEMI[p[1]];if(r.ok&&["floor","rug","belt","mach","wall"].indexOf(it.cat)>=0){closeSheet();enterEdit();editTab=tabOf(it);startGhost(it.id);toast("Bought! Drag it where you want it and tap PLACE.");saveGame();return;}}
  else if(p[0]==="eq"){sim.equip(p[1],!sim.s.equip[p[1]]);}
  else if(p[0]==="bs"){if(!sim.setBasin(p[1],!sim.s.basin[p[1]]))toast("The pool is behind the locked door: buy the ROOM KEY.");}
  else if(p[0]==="th"){sim.setTheme(p[1],+p[2]);}
  else if(p[0]==="pl"){var it2=S.ITEMI[p[1]];closeSheet();enterEdit();editTab=tabOf(it2);startGhost(p[1]);return;}
  else if(a==="reset"){if(b.getAttribute("data-sure")!=="1"){b.setAttribute("data-sure","1");b.innerHTML="SURE?";return;}sim.reset(seed0);try{var ls=store();if(ls)ls.removeItem(S.SAVE_KEY);}catch(x){}closeSheet();panelSig="";refreshPanel();toast("New game started.");return;}
  if(r&&!r.ok)toast(r.why);else if(r&&r.ok)toast("Bought!");
  var st=$("sheetBody").scrollTop;buildSheet();$("sheetBody").scrollTop=st;updateHud();refreshPanel();saveGame();});
/* ---------- lifecycle ---------- */
document.addEventListener("visibilitychange",function(){if(document.hidden){paused=true;saveGame();}else{paused=false;last=0;acc=0;}try{if(window.PPRadio)PPRadio.onHidden(document.hidden);}catch(e){}});
window.addEventListener("pagehide",saveGame);
["pointerup","touchend","click"].forEach(function(t){document.addEventListener(t,function(){try{if(window.PPRadio&&sim.s.box.radio>0&&sim.placed("radio")){PPRadio.update(radioWant());PPRadio.kick();}}catch(e){}},{passive:true});});
/* ---------- test hooks (window.__tt contract) ---------- */
function ni(v,a,b){v=+v;if(!isFinite(v))throw new Error("bad arg");v=Math.round(v);if(v<a||v>b)throw new Error("arg out of range");return v;}
function stateObj(){var s=sim.s,p=s.papa,modes={};s.pots.forEach(function(q){modes[q.m]=(modes[q.m]|0)+1;});
  return {tick:s.tick,over:false,paused:paused,entityCount:s.pots.length+s.peels.length+s.puke.length,caps:{maxEntities:S.POT_CAP+S.PEEL_CAP+6},
    coins:s.coins,level:s.level,food:s.food,shipped:s.shipped,shippedClean:s.shippedClean,earned:s.earned,
    papa:{x:Math.round(p.x*1000)/1000,y:Math.round(p.y*1000)/1000,hunger:Math.round(p.hunger*100)/100,energy:Math.round(p.energy*100)/100,mood:Math.round(p.mood),hands:Math.round(p.hands*100)/100,hold:p.hold.length,task:p.task?p.task.type:"none",stage:p.task?p.task.stage:"",where:p.where,sack:p.sack.on?1:0},
    objs:s.objs.map(function(o){return {id:o.id,x:o.x,y:o.y,r:o.r,jam:o.jam?1:0,on:o.on==null?1:o.on};}),pots:modes,potCount:s.pots.length,peels:s.peels.length,puke:s.puke.length,box:s.box,stats:s.stats,inv:s.inv,owned:s.owned,ups:s.ups};}
var CMDS=[
  {name:"order",args:[{name:"i",min:0,max:4}],run:function(a){sim.order(["eat","nap","clean","fix","work"][ni(a[0],0,4)]);}},
  {name:"setBox",args:[{name:"i",min:0,max:S.COMMANDS.length-1},{name:"v",min:0,max:100}],run:function(a){var c=S.COMMANDS[ni(a[0],0,S.COMMANDS.length-1)];sim.setBox(c.id,ni(a[1],-1e6,1e6));}},
  {name:"buyFood",args:[{name:"n",min:1,max:5}],run:function(a){sim.buyFood(ni(a[0],1,20));}},
  {name:"buyLevel",run:function(){sim.buyLevel();}},
  {name:"buyItem",args:[{name:"i",min:0,max:S.ITEMS.length-1},{name:"q",min:1,max:10}],run:function(a){sim.buyItem(S.ITEMS[ni(a[0],0,S.ITEMS.length-1)].id,ni(a[1]==null?1:a[1],1,20));}},
  {name:"buyUp",args:[{name:"i",min:0,max:S.UPS.length-1}],run:function(a){sim.buyUp(S.UPS[ni(a[0],0,S.UPS.length-1)].id);}},
  {name:"place",args:[{name:"i",min:0,max:S.ITEMS.length-1},{name:"x",min:0,max:S.W-1},{name:"y",min:0,max:S.H-1},{name:"r",min:0,max:3}],run:function(a){sim.place(S.ITEMS[ni(a[0],0,S.ITEMS.length-1)].id,ni(a[1],-50,50),ni(a[2],-50,50),ni(a[3],0,3));}},
  {name:"move",args:[{name:"k",min:0,max:30},{name:"x",min:0,max:S.W-1},{name:"y",min:0,max:S.H-1},{name:"r",min:0,max:3}],run:function(a){var o=sim.s.objs[ni(a[0],0,999)];if(o)sim.move(o.u,ni(a[1],-50,50),ni(a[2],-50,50),ni(a[3],0,3));}},
  {name:"rotate",args:[{name:"k",min:0,max:30}],run:function(a){var o=sim.s.objs[ni(a[0],0,999)];if(o)sim.rotate(o.u);}},
  {name:"store",args:[{name:"k",min:0,max:30}],run:function(a){var o=sim.s.objs[ni(a[0],0,999)];if(o)sim.store(o.u);}},
  {name:"machToggle",args:[{name:"k",min:0,max:30}],run:function(a){var o=sim.s.objs[ni(a[0],0,999)];if(o)sim.machToggle(o.u);}},
  {name:"sendFix",args:[{name:"k",min:0,max:30}],run:function(a){var o=sim.s.objs[ni(a[0],0,999)];if(o)sim.sendFix(o.u);}},
  {name:"brush",args:[{name:"x",min:15,max:25},{name:"y",min:0,max:15}],run:function(a){var x=+a[0],y=+a[1];if(!isFinite(x)||!isFinite(y))throw new Error("bad arg");sim.brush(x,y,0.2);}},
  {name:"equip",args:[{name:"i",min:0,max:2},{name:"on",min:0,max:1}],run:function(a){sim.equip(["betterPeeler","carrySack","broomDustpan"][ni(a[0],0,2)],ni(a[1],0,1)===1);}},
  {name:"basin",args:[{name:"i",min:0,max:2},{name:"on",min:0,max:1}],run:function(a){sim.setBasin(["duck","toyBoat","bubbles"][ni(a[0],0,2)],ni(a[1],0,1)===1);}},
  {name:"theme",args:[{name:"w",min:0,max:1},{name:"v",min:0,max:3}],run:function(a){sim.setTheme(ni(a[0],0,1)?"floor":"wall",ni(a[1],0,3));}}
];
function flood(n){n=Math.max(0,Math.min(2000,Math.round(+n)||0));var made=0;for(var i=0;i<n;i++){var q=sim.newPot(1,"pool");if(!q)break;sim.toWater(q,17.5+(i%3)*0.8,12.5+((i/3)|0)%4*0.8);made++;}return made;}
window.__tt={version:1,manual:false,
  getState:stateObj,
  step:function(n){n=Math.max(0,Math.min(100000,Math.round(+n)||0));for(var i=0;i<n;i++)sim.step(S.DT);sim.events=[];draw();},
  setSeed:function(s){sim.reset((Math.round(+s)>>>0)||1);sim.events=[];Dr.parts.length=0;view.cx=sim.s.papa.x;view.cy=sim.s.papa.y;draw();},
  listCommands:function(){return CMDS.map(function(c){return c.args?{name:c.name,args:c.args}:{name:c.name};});},
  runCommand:function(name,args){var c=null;for(var i=0;i<CMDS.length;i++)if(CMDS[i].name===name)c=CMDS[i];if(!c)throw new Error("no such command");c.run(Array.isArray(args)?args:[]);draw();return true;},
  flood:flood,render:function(){draw();}};
/* richer API for the scripted tests */
window.PP2T={RS:RS,showCmd:showCmd,cmdLay:cmdLay,sim:function(){return sim;},S:S,view:view,draw:draw,fps:function(){return fps;},setCam:function(x,y,z){setFollow(false);view.cx=x;view.cy=y;if(z)view.z=z;draw();},follow:setFollow,
  enterEdit:enterEdit,exitEdit:exitEdit,startGhost:startGhost,startMove:startMove,ghost:function(){return view.ghost;},moveGhost:function(x,y){var g=view.ghost;if(g){g.x=x;g.y=y;refreshGhost();refreshEdit();}},
  openSheet:openSheet,closeSheet:closeSheet,refresh:function(){updateHud();refreshPanel();if(view.edit)refreshEdit();},project:function(x,y,h){Dr.setView(ctx,view.w,view.h,view.z,view.cx,view.cy,view.t);var a=Dr.project(x,y,h||0);var r=cv.getBoundingClientRect();return [a[0]+r.left,a[1]+r.top];},
  save:saveGame,parts:function(){return Dr.parts.length;},editTab:function(t){editTab=t;refreshEdit();}};
/* ---------- boot ---------- */
var loaded=loadGame();if(!loaded){view.cx=sim.s.papa.x;view.cy=sim.s.papa.y;}else{view.cx=sim.s.papa.x;view.cy=sim.s.papa.y;sim.say("Welcome back. Papa kept your kitchen just as you left it.");}
resize();buildCmds();panelSig=lockSig();setTimeout(cmdLay,0);updateHud();navMark();
$("boot").className="off";
requestAnimationFrame(frame);
window.__PP_READY=true;
})();
