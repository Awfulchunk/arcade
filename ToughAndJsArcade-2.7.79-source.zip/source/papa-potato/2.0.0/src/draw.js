/* ===== Papa Potato 2.0.0 — iso renderer (Project Zomboid-style corner view: back walls up, front walls cut low).
   Everything here is drawn live with canvas paths: every item is a physical object with its own looped animation. ===== */
var PPDraw=(function(){
"use strict";
var D={},S=PP2,FIX=S.FIX,W=S.W,H=S.H;
var NOGROUND=false,ctx=null,Z=1,CW=360,CH=400,CX=0,CY=0,T=0,ZP=50,WALLH=2.4,LOWH=0.55;
var cam={x:7,y:12};
function setView(c,cw,ch,z,cx,cy,t){ctx=c;CW=cw;CH=ch;Z=z;cam.x=cx;cam.y=cy;T=t;CX=(cx-cy);CY=(cx+cy);}
function sx(x,y){return CW/2+((x-y)-CX)*32*Z;}
function sy(x,y,h){return CH/2+((x+y)-CY)*16*Z-(h||0)*ZP*Z;}
function P(x,y,h){return [sx(x,y),sy(x,y,h)];}
function toWorld(px,py){var X=(px-CW/2)/(32*Z)+CX,Y=(py-CH/2)/(16*Z)+CY;return {x:(X+Y)/2,y:(Y-X)/2};}
function hex(c){if(c[0]!=="#")return [128,128,128];var n=parseInt(c.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
var shadeCache={};
function shade(c,f){var k=c+f;var v=shadeCache[k];if(v)return v;var r=hex(c),o;if(f<=1)o=[r[0]*f,r[1]*f,r[2]*f];else{var g=f-1;o=[r[0]+(255-r[0])*g,r[1]+(255-r[1])*g,r[2]+(255-r[2])*g];}
  v="rgb("+(o[0]|0)+","+(o[1]|0)+","+(o[2]|0)+")";shadeCache[k]=v;return v;}
function poly(pts,fill,stroke,lw){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(var i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=(lw||1)*Math.max(0.6,Z);ctx.stroke();}}
var OUT="rgba(20,14,10,0.55)";
/* a shaded box: x,y min corner (tiles), w along x, d along y, z0 base (m), h height (m) */
function box(x,y,w,d,z0,h,c,o){o=o||{};var t=z0+h;
  var A=P(x,y,t),B=P(x+w,y,t),C2=P(x+w,y+d,t),Dd=P(x,y+d,t),Bb=P(x+w,y,z0),Cb=P(x+w,y+d,z0),Db=P(x,y+d,z0);
  var st=o.stroke===false?null:(o.stroke||OUT);
  poly([Dd,C2,Cb,Db],o.left||shade(c,0.78),null);poly([C2,B,Bb,Cb],o.right||shade(c,0.62),null);poly([A,B,C2,Dd],o.top||c,null);
  /* one outline pass for all three faces (same lines as stroking each face, a third of the draw calls) */
  if(st){ctx.beginPath();ctx.moveTo(Db[0],Db[1]);ctx.lineTo(Cb[0],Cb[1]);ctx.lineTo(Bb[0],Bb[1]);ctx.lineTo(B[0],B[1]);ctx.lineTo(A[0],A[1]);ctx.lineTo(Dd[0],Dd[1]);ctx.closePath();
    ctx.moveTo(Dd[0],Dd[1]);ctx.lineTo(C2[0],C2[1]);ctx.lineTo(B[0],B[1]);ctx.moveTo(C2[0],C2[1]);ctx.lineTo(Cb[0],Cb[1]);ctx.strokeStyle=st;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();}}
function topQuad(x,y,w,d,h,c,st){poly([P(x,y,h),P(x+w,y,h),P(x+w,y+d,h),P(x,y+d,h)],c,st);}
function ell(x,y,h,rx,ry,c,st){var p=P(x,y,h);ctx.beginPath();ctx.ellipse(p[0],p[1],Math.max(0.5,rx*Z),Math.max(0.5,ry*Z),0,0,6.2832);if(c){ctx.fillStyle=c;ctx.fill();}if(st){ctx.strokeStyle=st;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();}}
/* iso circle on the floor plane: r in tiles */
function isoCirc(x,y,h,r,c,st,lw){var p=P(x,y,h);ctx.beginPath();ctx.ellipse(p[0],p[1],r*45.25*Z,r*22.6*Z,0,0,6.2832);if(c){ctx.fillStyle=c;ctx.fill();}if(st){ctx.strokeStyle=st;ctx.lineWidth=(lw||1)*Math.max(0.6,Z);ctx.stroke();}}
function cyl(x,y,r,z0,h,c,top){var a=P(x,y,z0),b=P(x,y,z0+h),rx=r*45.25*Z,ry=r*22.6*Z;
  ctx.beginPath();ctx.ellipse(a[0],a[1],rx,ry,0,0,Math.PI);ctx.lineTo(b[0]-rx,b[1]);ctx.ellipse(b[0],b[1],rx,ry,0,Math.PI,0,true);ctx.closePath();
  var g=ctx.createLinearGradient(a[0]-rx,0,a[0]+rx,0);g.addColorStop(0,shade(c,0.85));g.addColorStop(0.4,shade(c,1.08));g.addColorStop(1,shade(c,0.55));ctx.fillStyle=g;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();
  ctx.beginPath();ctx.ellipse(b[0],b[1],rx,ry,0,0,6.2832);ctx.fillStyle=top||shade(c,1.1);ctx.fill();ctx.stroke();}
function shadow(x,y,r,a){isoCirc(x,y,0,r,"rgba(0,0,0,"+(a||0.22)+")");}
function line(a,b,c,w){ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.strokeStyle=c;ctx.lineWidth=(w||1)*Math.max(0.5,Z);ctx.stroke();}
function txt(s,x,y,size,c,al){ctx.font="bold "+Math.max(7,Math.round(size*Z))+"px monospace";ctx.textAlign=al||"center";ctx.textBaseline="middle";ctx.fillStyle=c;ctx.fillText(s,x,y);}
/* faces of a wall plane (for wall items): N wall = plane y=0 (u along x), W wall = plane x=0 (u along y) */
function wallPt(wall,u,h,off){off=off||0.02;return wall==="N"?P(u,off,h):P(off,u,h);}
function wallQuad(wall,u0,u1,h0,h1,c,st){poly([wallPt(wall,u0,h0),wallPt(wall,u1,h0),wallPt(wall,u1,h1),wallPt(wall,u0,h1)],c,st);}
/* ---------- potatoes: raw = brown skin with eyes; peeled = smooth cream with soft knife facets, dirt shows as smudges ---------- */
function potato(x,y,h,p,rot,sc){var a=P(x,y,h),r=(sc||1)*6.2*Z,ry=r*0.72;ctx.save();ctx.translate(a[0],a[1]-ry*0.6);ctx.rotate(rot||0);
  if(p.k===0){ctx.beginPath();ctx.ellipse(0,0,r,ry,0,0,6.2832);var g=ctx.createRadialGradient(-r*0.35,-ry*0.4,r*0.1,0,0,r*1.1);g.addColorStop(0,"#c99a63");g.addColorStop(0.55,"#9a6a3a");g.addColorStop(1,"#5e3d1f");ctx.fillStyle=g;ctx.fill();ctx.strokeStyle="rgba(40,22,10,0.7)";ctx.lineWidth=Math.max(0.5,Z*0.8);ctx.stroke();
    ctx.fillStyle="#4a2e16";ctx.fillRect(-r*0.4,-ry*0.1,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(r*0.25,ry*0.2,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(r*0.05,-ry*0.45,Math.max(1,Z),Math.max(1,Z));}
  else{ctx.beginPath();ctx.ellipse(0,0,r*0.94,ry*0.94,0,0,6.2832);var g2=ctx.createRadialGradient(-r*0.3,-ry*0.45,r*0.05,0,0,r);g2.addColorStop(0,"#fff6cf");g2.addColorStop(0.5,"#f2d98a");g2.addColorStop(1,"#d3ad55");ctx.fillStyle=g2;ctx.fill();ctx.strokeStyle="rgba(120,84,30,0.65)";ctx.lineWidth=Math.max(0.5,Z*0.7);ctx.stroke();
    ctx.strokeStyle="rgba(190,150,70,0.55)";ctx.beginPath();ctx.moveTo(-r*0.5,-ry*0.2);ctx.lineTo(-r*0.1,ry*0.35);ctx.moveTo(r*0.15,-ry*0.55);ctx.lineTo(r*0.45,ry*0.1);ctx.stroke();
    if(p.d>0.02){ctx.globalAlpha=Math.min(0.85,p.d*0.9);ctx.fillStyle="#6b4a2a";ctx.beginPath();ctx.ellipse(-r*0.25,ry*0.15,r*0.4,ry*0.32,0.4,0,6.2832);ctx.fill();ctx.beginPath();ctx.ellipse(r*0.38,-ry*0.15,r*0.22,ry*0.25,0,0,6.2832);ctx.fill();
      ctx.fillStyle="#3f2a16";ctx.fillRect(r*0.05,ry*0.3,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(-r*0.6,-ry*0.3,Math.max(1,Z),Math.max(1,Z));ctx.globalAlpha=1;}
    else{var tw=(Math.sin(T*5+p.u)*0.5+0.5);ctx.fillStyle="rgba(255,255,255,"+(0.5+0.5*tw)+")";ctx.fillRect(-r*0.45,-ry*0.55,Math.max(1,1.5*Z),Math.max(1,1.5*Z));}
    ctx.fillStyle="rgba(255,255,255,0.55)";ctx.beginPath();ctx.ellipse(-r*0.35,-ry*0.4,r*0.22,ry*0.16,-0.4,0,6.2832);ctx.fill();}
  ctx.restore();}
D.potato=potato;
/* ---------- particles (render only) ---------- */
var parts=[],NOPART=false;function part(o){if(NOPART)return;if(parts.length>420)parts.shift();parts.push(o);}
function emit(ev){var i;switch(ev.e){
  case "coin":part({k:"txt",x:ev.x,y:ev.y,h:1.6,t:0,life:1.6,s:"+"+ev.v+"c",c:ev.v>=5?"#7dff9a":"#ffd34d"});for(i=0;i<6;i++)part({k:"spark",x:ev.x,y:ev.y,h:1.2,vx:(Math.random()-0.5)*1.5,vy:(Math.random()-0.5)*1.5,vh:1+Math.random()*1.5,t:0,life:0.6,c:"#ffd34d"});break;
  case "peeled":for(i=0;i<5;i++)part({k:"peel",x:ev.x,y:ev.y,h:1.0,vx:(Math.random()-0.5)*1.6,vy:(Math.random()-0.2)*1.6,vh:1.5+Math.random(),t:0,life:0.8,r:Math.random()*6});break;
  case "splash":for(i=0;i<9;i++)part({k:"drop",x:ev.x,y:ev.y,h:0.5,vx:(Math.random()-0.5)*1.4,vy:(Math.random()-0.5)*1.4,vh:1.5+Math.random()*1.5,t:0,life:0.7});break;
  case "foam":for(i=0;i<4;i++)part({k:"foam",x:ev.x+(Math.random()-0.5)*0.4,y:ev.y+(Math.random()-0.5)*0.4,h:0.6,vh:0.4+Math.random()*0.4,t:0,life:1.1,r:2+Math.random()*3});break;
  case "puke":for(i=0;i<26;i++)part({k:"chunk",x:ev.x,y:ev.y,h:0.6,vx:(Math.random()-0.5)*3,vy:(Math.random()-0.5)*3,vh:1+Math.random()*2.2,t:0,life:0.9});break;
  case "fixed":for(i=0;i<10;i++)part({k:"spark",x:ev.x,y:ev.y,h:1.2,vx:(Math.random()-0.5)*2,vy:(Math.random()-0.5)*2,vh:1+Math.random()*2,t:0,life:0.5,c:"#ffe27a"});part({k:"txt",x:ev.x,y:ev.y,h:2.4,t:0,life:1.4,s:"FIXED",c:"#8fe3ff"});break;
  case "eat":part({k:"txt",x:0,y:0,h:0,t:0,life:0.01,s:"",c:"#fff"});break;
}}
function stepParts(dt){for(var i=parts.length-1;i>=0;i--){var p=parts[i];p.t+=dt;if(p.t>=p.life){parts.splice(i,1);continue;}if(p.vx!=null){p.x+=p.vx*dt;p.y+=(p.vy||0)*dt;}if(p.vh!=null){p.h+=p.vh*dt;if(p.k!=="foam")p.vh-=6*dt;if(p.h<0){p.h=0;p.vh=0;p.vx*=0.3;p.vy*=0.3;}}}}
function drawParts(){for(var i=0;i<parts.length;i++){var p=parts[i],a=P(p.x,p.y,p.h),f=1-p.t/p.life;
  if(p.k==="txt"){txt(p.s,a[0],a[1]-p.t*24*Z,11,p.c);continue;}
  ctx.globalAlpha=Math.max(0,Math.min(1,f*1.5));
  if(p.k==="spark"){ctx.fillStyle=p.c;ctx.fillRect(a[0]-Z,a[1]-Z,2*Z,2*Z);}
  else if(p.k==="peel"){ctx.strokeStyle="#c58c47";ctx.lineWidth=Math.max(1,1.6*Z);ctx.beginPath();ctx.arc(a[0],a[1],2.5*Z,p.r+p.t*9,p.r+p.t*9+2.4);ctx.stroke();}
  else if(p.k==="drop"){ctx.fillStyle="#9fd8ff";ctx.fillRect(a[0]-Z,a[1]-Z,2*Z,2.5*Z);}
  else if(p.k==="foam"){ctx.beginPath();ctx.arc(a[0],a[1],p.r*Z,0,6.2832);ctx.fillStyle="rgba(255,255,255,0.75)";ctx.fill();ctx.strokeStyle="rgba(160,210,255,0.8)";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();}
  else if(p.k==="chunk"){ctx.fillStyle=i%3?"#b7c64a":"#d9b84a";ctx.fillRect(a[0]-1.5*Z,a[1]-1.5*Z,3.2*Z,3*Z);}
  else if(p.k==="smoke"){ctx.beginPath();ctx.arc(a[0],a[1],(3+p.t*6)*Z,0,6.2832);ctx.fillStyle="rgba(90,90,90,"+(0.45*f)+")";ctx.fill();}
  else if(p.k==="note"){txt(p.s,a[0]+Math.sin(p.t*5)*4*Z,a[1],10,"#ffd6f5");}
  else if(p.k==="z"){txt("z",a[0]+Math.sin(p.t*3)*4*Z,a[1],8+p.t*5,"#cfe8ff");}
  ctx.globalAlpha=1;}}
D.emit=emit;D.stepParts=stepParts;D.parts=parts;
/* ---------- floor, walls, water ---------- */
var FLOORS=[["#e6dabd","#d6c7a3"],["#efefea","#2e2e33"],["#cf7f55","#bb6b43"],["#b98a55","#a87a47"]];
var WALLS=[["#eadfc4","#8a6748"],["#c5e6d3","#7aa58d"],["#f2cfcf","#b97c7c"],["#41557a","#26344f"]];
function visTiles(){var a=toWorld(0,0),b=toWorld(CW,0),c=toWorld(0,CH+140*Z),d=toWorld(CW,CH+140*Z);
  return {x0:Math.max(0,Math.floor(Math.min(a.x,c.x))-1),x1:Math.min(W,Math.ceil(Math.max(b.x,d.x))+1),y0:Math.max(0,Math.floor(Math.min(a.y,b.y))-1),y1:Math.min(H,Math.ceil(Math.max(c.y,d.y))+1)};}
function tilePath(x,y){var a=P(x,y,0),b=P(x+1,y,0),c=P(x+1,y+1,0),d=P(x,y+1,0);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);ctx.closePath();}
function drawFloor(sim,V){var s=sim.s,th=s.decor.floor|0,F=FLOORS[th]||FLOORS[0],x,y,i;
  /* ground outside the rooms */
  if(!NOGROUND){ctx.fillStyle="#1d1a18";ctx.fillRect(0,0,CW,CH);}
  var pass=[[],[],[],[]];
  for(y=V.y0;y<V.y1;y++)for(x=V.x0;x<V.x1;x++){var r=S.roomOf(x,y);if(r==="k"){if(S.fixedBlock(x,y)&&!S.inRect(x,y,FIX.pile))continue;pass[(x+y)&1].push([x,y]);}else if(r==="w"){if(S.isWater(x,y))continue;pass[2+((x+y)&1)].push([x,y]);}else if(r==="door")pass[2].push([x,y]);}
  var cols=[F[0],th===3?F[0]:F[1],"#bcccd2","#aabdc4"];
  for(i=0;i<4;i++){ctx.beginPath();pass[i].forEach(function(t){tilePath(t[0],t[1]);});ctx.fillStyle=cols[i];ctx.fill();}
  ctx.strokeStyle="rgba(60,45,30,0.18)";ctx.lineWidth=Math.max(0.5,0.7*Z);ctx.beginPath();
  for(x=Math.max(0,V.x0);x<=Math.min(26,V.x1);x++){var y0=0,y1=x<=14?24:16;if(x===15)y1=24;var a=P(x,Math.max(y0,V.y0),0),b=P(x,Math.min(y1,V.y1),0);if(x>14&&x<=26){a=P(x,Math.max(0,V.y0),0);b=P(x,Math.min(16,V.y1),0);}ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}
  for(y=Math.max(0,V.y0);y<=Math.min(24,V.y1);y++){var xe=y<=16?26:14,c=P(0,y,0),d=P(xe,y,0);ctx.moveTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);}
  ctx.stroke();
  if(th===3){ctx.strokeStyle="rgba(70,45,20,0.25)";ctx.beginPath();for(y=0;y<24;y++)for(x=0;x<14;x+=2){if(y<V.y0||y>V.y1)continue;var e=P(x+((y&1)?1:0),y,0),f=P(x+((y&1)?1:0),y+1,0);ctx.moveTo(e[0],e[1]);ctx.lineTo(f[0],f[1]);}ctx.stroke();}
  /* soft ambient-occlusion along the back walls */
  var g0=P(0,0,0),g1=P(26,0,0),g2=P(26,0.7,0),g3=P(0,0.7,0);poly([g0,g1,g2,g3],"rgba(0,0,0,0.10)");poly([P(0,0,0),P(0.7,0,0),P(0.7,24,0),P(0,24,0)],"rgba(0,0,0,0.10)");
}
function drawBackWalls(sim){var s=sim.s,th=s.decor.wall|0,Wc=WALLS[th]||WALLS[0],i;
  /* kitchen north wall (x 0..15) + west wall (y 0..24) */
  wallQuad("N",0,15,0,WALLH,Wc[0],OUT);wallQuad("W",0,24,0,WALLH,shade(Wc[0],0.86),OUT);
  wallQuad("N",0,15,0,0.9,Wc[1],null);wallQuad("W",0,24,0,0.9,shade(Wc[1],0.86),null);
  if(th===1){for(i=0;i<15;i+=0.5)wallQuad("N",i,i+0.25,0.9,WALLH,shade(Wc[0],0.93),null);for(i=0;i<24;i+=0.5)wallQuad("W",i,i+0.25,0.9,WALLH,shade(Wc[0],0.8),null);}
  if(th===2){ctx.strokeStyle="rgba(150,90,90,0.4)";for(i=1;i<15;i++)line(wallPt("N",i,0.9),wallPt("N",i,WALLH),"rgba(150,90,90,0.35)");for(i=1;i<24;i++)line(wallPt("W",i,0.9),wallPt("W",i,WALLH),"rgba(150,90,90,0.35)");for(var hh=1.2;hh<WALLH;hh+=0.3){line(wallPt("N",0,hh),wallPt("N",15,hh),"rgba(150,90,90,0.3)");line(wallPt("W",0,hh),wallPt("W",24,hh),"rgba(150,90,90,0.3)");}}
  if(th===3){for(i=0.5;i<15;i+=2)wallQuad("N",i,i+1.4,1.1,2.1,shade(Wc[0],1.12),"rgba(0,0,0,0.25)");for(i=0.5;i<24;i+=2)wallQuad("W",i,i+1.4,1.1,2.1,shade(Wc[0],1.0),"rgba(0,0,0,0.25)");}
  line(wallPt("N",0,0.9),wallPt("N",15,0.9),"rgba(255,255,255,0.35)",1.5);line(wallPt("W",0,0.9),wallPt("W",24,0.9),"rgba(255,255,255,0.3)",1.5);
  /* top trim */
  poly([P(0,0,WALLH),P(15,0,WALLH),P(15,-0.15,WALLH),P(-0.15,-0.15,WALLH),P(-0.15,24,WALLH),P(0,24,WALLH)],"#5b4636",OUT);
  /* wash room north wall: white tiles */
  wallQuad("N",15,26,0,WALLH,"#dfe9ec",OUT);for(i=15.5;i<26;i+=0.5)line(wallPt("N",i,0),wallPt("N",i,WALLH),"rgba(90,120,130,0.25)");for(var h2=0.3;h2<WALLH;h2+=0.3)line(wallPt("N",15,h2),wallPt("N",26,h2),"rgba(90,120,130,0.25)");
  poly([P(15,0,WALLH),P(26,0,WALLH),P(26.15,-0.15,WALLH),P(15,-0.15,WALLH)],"#6d7f86",OUT);
  /* the ship hole at the canal end */
  wallQuad("N",25.05,25.95,0,1.0,"#0d1418","#000");
  txt("SHIP",sx(25.5,0),sy(25.5,0,1.25),8,"#ffe9a8");
  /* the free wall outlet */
  var oy=FIX.outlet.y;wallQuad("W",oy+0.25,oy+0.75,0.35,0.75,"#f4f1e8","#555");
  var hp=wallPt("W",oy+0.4,0.5,0.04),hq=wallPt("W",oy+0.6,0.5,0.04);ctx.fillStyle="#333";ctx.fillRect(hp[0]-Z,hp[1]-2*Z,1.5*Z,3*Z);ctx.fillRect(hq[0]-Z,hq[1]-2*Z,1.5*Z,3*Z);
}
/* the only moving bits of the back walls (drawn live over the cached layer) */
function drawWallAnim(){var dr=(T*2)%1;line(wallPt("N",25.3,0.05,0.05),wallPt("N",25.3,0.05+dr*0.2,0.05),"#9fd8ff",1.5);
  var oy=FIX.outlet.y,lp=wallPt("W",oy+0.5,0.68,0.05);ctx.fillStyle=(Math.floor(T*2)%2)?"#7dff9a":"#2f7a43";ctx.fillRect(lp[0]-Z,lp[1]-Z,2*Z,2*Z);}
/* static layer cache: floor + back walls never move, so they are drawn once per zoom/theme into an offscreen canvas and blitted 1:1 (no scaling) */
var BG={c:null,key:"",pend:"",pendN:0,ox:0,oy:0};
function bgLayer(sim,V){var s=sim.s,dpr=D.dpr||1,key=Z.toFixed(4)+"|"+dpr+"|"+(s.decor.floor|0)+"|"+(s.decor.wall|0);
  var pad=8,cwv=2*(27*32*Z+pad),chv=2*(WALLH*ZP*Z+18*Z+pad),wpx=Math.ceil(cwv*dpr),hpx=Math.ceil((chv/2+51*16*Z+pad)*dpr);
  var ok=wpx<=4096&&hpx<=4096&&wpx*hpx<=9e6&&typeof document!=="undefined";
  if(ok&&BG.key!==key){if(BG.pend===key)BG.pendN++;else{BG.pend=key;BG.pendN=0;}
    if(BG.pendN>=2){/* zoom has settled: rebuild */
      var c=BG.c||document.createElement("canvas");if(c.width!==wpx)c.width=wpx;if(c.height!==hpx)c.height=hpx;var g=c.getContext("2d");g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,wpx,hpx);g.setTransform(dpr,0,0,dpr,0,0);
      var sv=[ctx,CW,CH,CX,CY,cam.x,cam.y];ctx=g;CW=cwv;CH=chv;CX=0;CY=0;NOGROUND=true;
      drawFloor(sim,{x0:0,x1:W,y0:0,y1:H});drawBackWalls(sim);
      NOGROUND=false;ctx=sv[0];CW=sv[1];CH=sv[2];CX=sv[3];CY=sv[4];cam.x=sv[5];cam.y=sv[6];BG.c=c;BG.key=key;}}
  if(ok&&BG.key===key){ctx.fillStyle="#1d1a18";ctx.fillRect(0,0,CW,CH);
    /* world origin in the cache vs on screen, in device pixels, rounded so the blit stays 1:1 */
    var dx=Math.round((sx(0,0)-cwv/2)*dpr),dy=Math.round((sy(0,0,0)-chv/2)*dpr);
    ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(BG.c,dx,dy);ctx.restore();return true;}
  drawFloor(sim,V);drawBackWalls(sim);return false;}
function drawWater(sim,V){var i,x,y;
  /* pool: stone rim + animated water */
  var pl=FIX.pool;poly([P(pl.x-0.1,pl.y-0.1,0.25),P(pl.x+pl.w+0.1,pl.y-0.1,0.25),P(pl.x+pl.w+0.1,pl.y+pl.h+0.1,0.25),P(pl.x-0.1,pl.y+pl.h+0.1,0.25)],"#7b8a8f",OUT);
  poly([P(pl.x,pl.y,0.05),P(pl.x+pl.w,pl.y,0.05),P(pl.x+pl.w,pl.y+pl.h,0.05),P(pl.x,pl.y+pl.h,0.05)],"#2f7fa8",null);
  /* canal */
  ctx.beginPath();S.CANAL_TILES.forEach(function(t){var a=P(t[0],t[1],0.05),b=P(t[0]+1,t[1],0.05),c=P(t[0]+1,t[1]+1,0.05),d=P(t[0],t[1]+1,0.05);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);ctx.closePath();});ctx.fillStyle="#2b78a0";ctx.fill();
  /* canal stone lips */
  box(19.9,15.0,0.1,1,0,0.25,"#7b8a8f");box(20,14.9,5.0,0.1,0,0.25,"#7b8a8f");box(24.9,0,0.1,14.9,0,0.25,"#7b8a8f");
  /* ripples */
  ctx.strokeStyle="rgba(200,235,255,0.35)";ctx.lineWidth=Math.max(0.5,Z);
  for(i=0;i<6;i++){var ph=(T*0.5+i/6)%1;isoCirc(pl.x+0.8+(i%3)*0.8,pl.y+0.8+((i/3)|0)*2,0.06,0.15+ph*0.35,null,"rgba(200,235,255,"+(0.35*(1-ph))+")");}
  var flow=([0.55,1.0,1.7][sim.up("channel")]||0.55);
  for(i=0;i<22;i++){var c=((T*flow+i)%S.CANAL_LEN+S.CANAL_LEN)%S.CANAL_LEN,p=sim.canalPos(c),o=(i%3-1)*0.25;
    var a=c<=5.5?P(p.x-0.2,p.y+o,0.06):P(p.x+o,p.y+0.2,0.06),b=c<=5.5?P(p.x+0.2,p.y+o,0.06):P(p.x+o,p.y-0.2,0.06);line(a,b,"rgba(210,240,255,0.45)",1);}
  /* the scanner pour into the pool */
  var sp=P(17.05,14.9,0.75),sq=P(17.3,14.9,0.06);ctx.strokeStyle="rgba(180,225,255,0.7)";ctx.lineWidth=Math.max(1,3*Z);ctx.beginPath();ctx.moveTo(sp[0],sp[1]);ctx.quadraticCurveTo(sp[0]+3*Z,(sp[1]+sq[1])/2,sq[0],sq[1]);ctx.stroke();
  isoCirc(17.35,14.95,0.06,0.25+0.05*Math.sin(T*8),null,"rgba(255,255,255,0.5)");
}
/* low cut-away walls: the shared wall (x=14), the front walls. Returns drawables for depth sorting. */
function lowWalls(sim,list){var key=sim.key(),y;
  for(y=0;y<24;y++){if(y===3||y===4)continue;(function(y){list.push({d:14.5+y+0.5,wx:14.5,wy:y+0.5,f:function(){box(14.2,y,0.6,1,0,0.3,"#6f6a64",{top:"#8c867e"});}});})(y);}
  /* door frame + sliding metal door */
  list.push({d:14.5+5.2,f:function(){if(D.editView)ctx.globalAlpha=0.45;var p=sim.s.papa,near=Math.hypot(p.x-14.5,p.y-4)<2.2,open=key&&near;
    sim._door=sim._door==null?0:sim._door;sim._door+=((open?1:0)-sim._door)*0.18;var o=sim._door;
    box(14.15,2.85,0.7,0.15,0,1.25,"#5a5f66");box(14.15,5.0,0.7,0.15,0,1.25,"#5a5f66");
    box(14.3,3+o*1.9,0.4,2-o*1.9>0.05?2-o*1.9:0.05,0,1.1,key?"#8d99a6":"#7c6f6a",{top:key?"#aab6c2":"#968983"});
    var lp=P(14.5,2.9,1.35);ctx.beginPath();ctx.arc(lp[0],lp[1],2.4*Z,0,6.2832);ctx.fillStyle=key?(open?"#7dff9a":"#3bd16a"):((Math.floor(T*2)%2)?"#ff5a4d":"#8a2a24");ctx.fill();
    if(!key){var lk=P(14.5,4.0,0.6);ctx.fillStyle="#e0b84a";ctx.fillRect(lk[0]-3*Z,lk[1]-2*Z,6*Z,5*Z);ctx.strokeStyle="#e0b84a";ctx.lineWidth=Math.max(1,1.2*Z);ctx.beginPath();ctx.arc(lk[0],lk[1]-2*Z,2.2*Z,Math.PI,0);ctx.stroke();txt("KEY",lk[0],lk[1]-9*Z,7,"#ffe9a8");}ctx.globalAlpha=1;}});
  /* kitchen south wall, wash south + east walls (front, low) */
  /* front walls are only a curb so they never hide the canal, the pool or Papa */
  list.push({d:100,f:function(){var F=0.16;box(0,24,14.8,0.2,0,F,"#6f6a64",{top:"#8c867e"});box(14.8,16,11.4,0.2,0,F,"#6f6a64",{top:"#8c867e"});box(26,0,0.2,16.2,0,F,"#6f6a64",{top:"#8c867e"});}});
}
D.toWorld=toWorld;D.P=P;D.cam=cam;
/* ---------- fixed things ---------- */
var pileCache={z:0,c:null,ox:0,oy:0};
function pileSeedPts(){var pts=[],i,seed=7;function r(){seed=(seed*16807)%2147483647;return seed/2147483647;}
  var pl=FIX.pile;for(i=0;i<170;i++){var u=r(),v=r(),x=pl.x+0.2+u*(pl.w-0.4),y=pl.y+0.2+v*(pl.h-0.4),cx=(u-0.5)*2,cy=(v-0.5)*2,dd=Math.max(0,1-(cx*cx*0.8+cy*cy*0.9));pts.push({x:x,y:y,h:0.05+dd*0.95*r(),rot:r()*3,k:0,u:i,d:1});}
  pts.sort(function(a,b){return (a.x+a.y+a.h*0.2)-(b.x+b.y+b.h*0.2);});return pts;}
var PILE_PTS=null;
function drawPile(sim){var pl=FIX.pile;if(!PILE_PTS)PILE_PTS=pileSeedPts();
  /* wooden crate edge + burlap base */
  shadow(pl.x+pl.w/2,pl.y+pl.h/2,2.6,0.25);
  poly([P(pl.x,pl.y,0.02),P(pl.x+pl.w,pl.y,0.02),P(pl.x+pl.w,pl.y+pl.h,0.02),P(pl.x,pl.y+pl.h,0.02)],"#8b6a43",OUT);
  /* the mound is cached at this zoom */
  var dp=D.dpr||1,key=Z.toFixed(3)+"/"+dp;if(pileCache.z!==key||!pileCache.c){var c=document.createElement("canvas"),wpx=Math.ceil((pl.w+pl.h)*32*Z+40),hpx=Math.ceil((pl.w+pl.h)*16*Z+90*Z+40);c.width=Math.ceil(wpx*dp);c.height=Math.ceil(hpx*dp);
    var save=ctx,sCW=CW,sCH=CH,sCX=CX,sCY=CY;var cc=c.getContext("2d");cc.scale(dp,dp);ctx=cc;
    var top=[(pl.x-pl.y-pl.h)*32*Z,(pl.x+pl.y)*16*Z-80*Z];CX=0;CY=0;CW=0;CH=0;ctx.translate(-top[0]+20,-top[1]+20);
    PILE_PTS.forEach(function(q){potato(q.x,q.y,q.h,q,q.rot,1.05);});
    ctx=save;CW=sCW;CH=sCH;CX=sCX;CY=sCY;pileCache={z:key,c:c,ox:top[0]-20,oy:top[1]-20,w:wpx,h:hpx};}
  var o=P(0,0,0);ctx.drawImage(pileCache.c,o[0]+pileCache.ox,o[1]+pileCache.oy,pileCache.w,pileCache.h);
  /* looped: one potato rolls off the top every few seconds */
  var ph=(T/3.2)%1,rx=pl.x+2.5+ph*1.6,ry=pl.y+1.4+ph*1.9,rh=Math.max(0.02,1.0-ph*1.2);potato(rx,ry,rh,{k:0,u:1,d:1},T*6,1.05);
  var sg=P(pl.x+pl.w/2,pl.y+pl.h,0.1);txt("RAW PILE ∞",sg[0],sg[1]+6*Z,8,"#ffe9a8");
}
function drawChute(sim){var x=6,y=0;box(x,y,2,0.7,0,1.9,"#7d8a94");
  poly([P(x+0.25,y+0.7,0.55),P(x+1.75,y+0.7,0.55),P(x+1.75,y+0.7,1.35),P(x+0.25,y+0.7,1.35)],"#111a20","#000");
  for(var i=0;i<6;i++)poly([P(x+i/3,y+0.7,1.9),P(x+i/3+0.16,y+0.7,1.9),P(x+i/3+0.16,y+0.7,1.7),P(x+i/3,y+0.7,1.7)],i%2?"#222":"#f2c230");
  /* lip / funnel */
  poly([P(x+0.1,y+0.7,0.55),P(x+1.9,y+0.7,0.55),P(x+1.9,y+1.0,0.45),P(x+0.1,y+1.0,0.45)],"#9aa8b2",OUT);
  var fl=Math.sin(T*3)*0.08;poly([P(x+0.3,y+0.71,1.35),P(x+1.7,y+0.71,1.35),P(x+1.7,y+0.71+fl,1.0),P(x+0.3,y+0.71+fl,1.0)],"rgba(60,70,80,0.85)");
  var lp=P(x+1.85,y+0.7,1.6);ctx.beginPath();ctx.arc(lp[0],lp[1],2.2*Z,0,6.28);ctx.fillStyle=(Math.floor(T*1.5)%2)?"#7dff9a":"#2c6a3c";ctx.fill();
  var sg=P(x+1,y+0.7,2.15);txt("SHIP 2-4c",sg[0],sg[1],8,"#ffe9a8");}
function scanner(x,y,side,sim){box(x,y,2,2,0,1.9,"#5e6f7e");box(x+0.1,y+0.1,1.8,1.8,1.9,0.12,"#4b5966");
  /* screen on the south face with an x-ray potato */
  var s0=P(x+0.3,y+2,0.85),s1=P(x+1.7,y+2,0.85),s2=P(x+1.7,y+2,1.65),s3=P(x+0.3,y+2,1.65);poly([s0,s1,s2,s3],"#0d2a1c","#000");
  var sc=(T*0.7)%1,bx=P(x+0.3+sc*1.4,y+2,0.85),bt=P(x+0.3+sc*1.4,y+2,1.65);line(bx,bt,"rgba(120,255,170,0.8)",1.5);
  var mid=P(x+1,y+2,1.25);ctx.strokeStyle="rgba(140,255,190,0.85)";ctx.lineWidth=Math.max(0.7,Z);ctx.beginPath();ctx.ellipse(mid[0],mid[1],9*Z,6*Z,0,0,6.28);ctx.stroke();ctx.beginPath();ctx.ellipse(mid[0]-2*Z,mid[1],3*Z,2*Z,0,0,6.28);ctx.stroke();
  txt("X-RAY",P(x+1,y+2,1.78)[0],P(x+1,y+2,1.78)[1],7,"#bfffd6");
  if(side==="k"){/* input slot on the west face with rubber flaps */var a=P(x,y+0.6,0.45),b=P(x,y+1.4,0.45),c=P(x,y+1.4,0.95),d=P(x,y+0.6,0.95);poly([a,b,c,d],"#10161a","#000");
    for(var i=0;i<4;i++){var u=y+0.65+i*0.2,sw=Math.sin(T*6+i)*0.03;line(P(x-sw,u,0.95),P(x-sw,u+0.15,0.5),"#2d3338",2);}
    var key=sim.key();var lp=P(x+0.1,y+0.2,1.7);ctx.beginPath();ctx.arc(lp[0],lp[1],2.2*Z,0,6.28);ctx.fillStyle=key?"#7dff9a":"#ff5a4d";ctx.fill();}
  else{/* spout on the east face into the pool */box(x+2,y+0.7,0.2,0.6,0.7,0.12,"#7a8a96");}}
/* ---------- machines ---------- */
function lamp(x,y,h,state){var p=P(x,y,h),c=state==="jam"?((Math.floor(T*4)%2)?"#ff3b30":"#5a1410"):state==="run"?"#55ff7a":state==="nopow"?((Math.floor(T*2)%2)?"#ffcc33":"#5a4a10"):"#555";ctx.beginPath();ctx.arc(p[0],p[1],2.8*Z,0,6.28);ctx.fillStyle=c;ctx.fill();ctx.strokeStyle="#111";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();
  if(state==="jam"||state==="run"){ctx.globalAlpha=0.25;ctx.beginPath();ctx.arc(p[0],p[1],6*Z,0,6.28);ctx.fill();ctx.globalAlpha=1;}}
function mState(sim,o){if(o.jam)return "jam";if(!o.pw)return "nopow";if(!o.on||sim.s.box.mspeed<=0)return "off";return o.run?"run":"idle";}
function arrowFloor(x,y,dir,c){var d=S.DIRS[dir],cx=x+0.5,cy=y+0.5,a=P(cx-d[0]*0.3,cy-d[1]*0.3,0.03),b=P(cx+d[0]*0.3,cy+d[1]*0.3,0.03),n=[-d[1],d[0]];
  var l=P(cx+d[0]*0.05+n[0]*0.2,cy+d[1]*0.05+n[1]*0.2,0.03),r=P(cx+d[0]*0.05-n[0]*0.2,cy+d[1]*0.05-n[1]*0.2,0.03);line(a,b,c,2.2);line(b,l,c,2.2);line(b,r,c,2.2);}
function spout(sim,o,col){var f=sim.frontOut(o),d=S.DIRS[o.r],ff=S.fp(o),cx=f[0]+0.5-d[0]*0.5,cy=f[1]+0.5-d[1]*0.5;
  var w=Math.abs(d[0])?0.3:0.6,dd=Math.abs(d[0])?0.6:0.3;box(cx-w/2+(d[0]>0?0:d[0]<0?-0.3:0)+(d[0]?0:0),cy-dd/2+(d[1]>0?0:d[1]<0?-0.3:0),w,dd,0.35,0.2,col||"#9aa7b0");}
function drawHopper(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*40)*0.012:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.3);
  /* legs + base */
  box(x+0.15,y+0.15,0.2,0.2,0,0.8,"#555c63");box(x+f.w-0.35,y+0.15,0.2,0.2,0,0.8,"#555c63");box(x+0.15,y+f.h-0.35,0.2,0.2,0,0.8,"#555c63");box(x+f.w-0.35,y+f.h-0.35,0.2,0.2,0,0.8,"#555c63");
  box(x+0.25,y+0.25,f.w-0.5,f.h-0.5,0.8,0.5,"#6f8aa0");
  /* funnel: wider at the top */
  var t0=1.3,t1=2.5,a=[P(x+0.25,y+0.25,t0),P(x+f.w-0.25,y+0.25,t0),P(x+f.w-0.25,y+f.h-0.25,t0),P(x+0.25,y+f.h-0.25,t0)],b=[P(x-0.05,y-0.05,t1),P(x+f.w+0.05,y-0.05,t1),P(x+f.w+0.05,y+f.h+0.05,t1),P(x-0.05,y+f.h+0.05,t1)];
  poly([a[3],a[2],b[2],b[3]],"#7f9bb2",OUT);poly([a[2],a[1],b[1],b[2]],"#60798d",OUT);poly(b,"#283844",OUT);
  /* potatoes swirling in the funnel */
  var n=Math.min(6,(o.fed|0)%7+(sim.touchesPile(o)?4:o.q.length));for(var i=0;i<n;i++){var an=T*(st==="run"?3:0.3)+i*1.05;potato(x+f.w/2+Math.cos(an)*0.45,y+f.h/2+Math.sin(an)*0.45,t1-0.15,{k:0,u:i,d:1},an,0.95);}
  /* suction hose to the pile */
  if(sim.touchesPile(o)){var pl=FIX.pile,hx=Math.max(pl.x+0.3,Math.min(pl.x+pl.w-0.3,x+f.w/2)),hy=Math.max(pl.y+0.3,Math.min(pl.y+pl.h-0.3,y+f.h/2));var h0=P(x+f.w/2,y+f.h/2,t1),h1=P(hx,hy,0.6),wob=Math.sin(T*5)*3*Z;
    ctx.strokeStyle="#33302c";ctx.lineWidth=Math.max(2,5*Z);ctx.beginPath();ctx.moveTo(h0[0],h0[1]);ctx.quadraticCurveTo((h0[0]+h1[0])/2+wob,Math.min(h0[1],h1[1])-30*Z,h1[0],h1[1]);ctx.stroke();ctx.strokeStyle="#6b655d";ctx.lineWidth=Math.max(1,2*Z);ctx.stroke();}
  spout(sim,o);lamp(x+f.w,y+f.h*0.3,1.15,st);
  var lb=P(x+f.w/2,y+f.h,1.05);txt("HOPPER",lb[0],lb[1],7,"#e8f4ff");}
function drawPeeler(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*35)*0.01:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.8);
  box(x,y,f.w,f.h,0,0.25,"#3d4349");box(x+0.1,y+0.1,f.w-0.2,f.h-0.2,0.25,1.55,"#c9a227");box(x+0.2,y+0.2,f.w-0.4,f.h-0.4,1.8,0.35,"#8f7419");
  /* stripes */
  for(var i=0;i<6;i++){var u=x+0.1+i*(f.w-0.2)/6;poly([P(u,y+f.h-0.1,0.25),P(u+(f.w-0.2)/12,y+f.h-0.1,0.25),P(u+(f.w-0.2)/12,y+f.h-0.1,0.45),P(u,y+f.h-0.1,0.45)],i%2?"#222":"#f0d34a");}
  /* round drum window on the south face, a potato spinning in it */
  var wc=P(x+f.w/2,y+f.h-0.08,1.05);ctx.beginPath();ctx.ellipse(wc[0],wc[1],15*Z,13*Z,0,0,6.28);ctx.fillStyle="#1b2228";ctx.fill();ctx.strokeStyle="#ddd";ctx.lineWidth=Math.max(1,2.5*Z);ctx.stroke();
  if(o.q.length){ctx.save();ctx.beginPath();ctx.ellipse(wc[0],wc[1],13*Z,11*Z,0,0,6.28);ctx.clip();var ang=st==="run"?T*14:0;ctx.translate(wc[0],wc[1]);ctx.rotate(ang);
    ctx.beginPath();ctx.ellipse(0,0,8*Z,5.5*Z,0,0,6.28);ctx.fillStyle=o.t>1.5?"#f2d98a":"#9a6a3a";ctx.fill();ctx.restore();
    if(st==="run"){for(var k=0;k<3;k++){var a2=T*9+k*2.1;ctx.strokeStyle="#c58c47";ctx.lineWidth=Math.max(1,1.4*Z);ctx.beginPath();ctx.arc(wc[0]+Math.cos(a2)*9*Z,wc[1]+Math.sin(a2)*7*Z,2*Z,a2,a2+2);ctx.stroke();}}}
  /* blades on top + exhaust */
  var ex=P(x+0.5,y+0.5,2.15);box(x+0.4,y+0.4,0.2,0.2,2.15,0.45,"#555");if(st==="run"&&Math.random()<0.08)part({k:"smoke",x:x+0.5,y:y+0.5,h:2.6,vh:0.6,t:0,life:1.2});
  if(st==="jam"&&Math.random()<0.2)part({k:"smoke",x:x+f.w/2+(Math.random()-0.5),y:y+f.h/2,h:2.0,vh:0.8,t:0,life:1.5});
  spout(sim,o,"#d8c06a");lamp(x+f.w-0.15,y+f.h-0.1,1.85,st);
  var lb=P(x+f.w/2,y+f.h,0.62);txt(st==="jam"?"JAMMED!":"AUTO PEELER",lb[0],lb[1],7,st==="jam"?"#ff8a80":"#222");}
function drawWasher(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*30)*0.01:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.8);
  box(x,y,f.w,f.h,0,0.2,"#3d4349");box(x+0.1,y+0.1,f.w-0.2,f.h-0.2,0.2,1.45,"#e9eef2");box(x+0.15,y+0.15,f.w-0.3,0.5,1.65,0.25,"#3aa0d8");
  var wc=P(x+f.w/2,y+f.h-0.08,0.95);ctx.beginPath();ctx.ellipse(wc[0],wc[1],16*Z,14*Z,0,0,6.28);ctx.fillStyle="#cfd8de";ctx.fill();ctx.strokeStyle="#7d8a94";ctx.lineWidth=Math.max(1,3*Z);ctx.stroke();
  ctx.save();ctx.beginPath();ctx.ellipse(wc[0],wc[1],13*Z,11*Z,0,0,6.28);ctx.clip();ctx.fillStyle="#123";ctx.fillRect(wc[0]-14*Z,wc[1]-12*Z,28*Z,24*Z);
  var sl=st==="run"?Math.sin(T*5)*4*Z:0;ctx.fillStyle="#3b9fd6";ctx.beginPath();ctx.moveTo(wc[0]-14*Z,wc[1]+sl);ctx.quadraticCurveTo(wc[0],wc[1]-sl*1.5,wc[0]+14*Z,wc[1]-sl);ctx.lineTo(wc[0]+14*Z,wc[1]+12*Z);ctx.lineTo(wc[0]-14*Z,wc[1]+12*Z);ctx.fill();
  for(var i=0;i<o.q.length;i++){var a=(st==="run"?T*6:0)+i*3;ctx.fillStyle="#f2d98a";ctx.beginPath();ctx.ellipse(wc[0]+Math.cos(a)*6*Z,wc[1]+Math.sin(a)*5*Z,5*Z,3.5*Z,a,0,6.28);ctx.fill();}
  for(var k=0;k<4;k++){var bb=(T*0.8+k/4)%1;ctx.fillStyle="rgba(255,255,255,0.7)";ctx.beginPath();ctx.arc(wc[0]+(k-1.5)*5*Z,wc[1]+8*Z-bb*18*Z,1.5*Z,0,6.28);ctx.fill();}ctx.restore();
  if(st==="jam"&&Math.random()<0.2)part({k:"foam",x:x+f.w/2+(Math.random()-0.5),y:y+f.h,h:1.4,vh:0.5,t:0,life:1.2,r:3});
  spout(sim,o,"#b9c6cf");lamp(x+f.w-0.15,y+f.h-0.1,1.75,st);var lb=P(x+f.w/2,y+f.h,0.45);txt(st==="jam"?"CLOGGED!":"WASHER",lb[0],lb[1],7,st==="jam"?"#ff8a80":"#234");}
function drawGenerator(sim,o){var f=S.fp(o),x=f.x+Math.sin(T*50)*0.006,y=f.y;shadow(x+1,y+1,1.3);
  box(x+0.1,y+0.1,1.8,1.8,0,0.15,"#2e3135");box(x+0.2,y+0.2,1.6,1.6,0.15,0.8,"#e3b928");box(x+0.45,y+0.45,1.1,1.0,0.95,0.35,"#4a4f55");
  /* flywheel on the east face */
  var wc=P(x+1.9,y+1.0,0.6);ctx.beginPath();ctx.ellipse(wc[0],wc[1],8*Z,11*Z,0,0,6.28);ctx.fillStyle="#333";ctx.fill();ctx.strokeStyle="#999";ctx.lineWidth=Math.max(1,1.5*Z);ctx.stroke();
  for(var i=0;i<4;i++){var a=T*12+i*1.57;line(wc,[wc[0]+Math.cos(a)*6*Z,wc[1]+Math.sin(a)*9*Z],"#bbb",1.3);}
  box(x+1.4,y+0.4,0.18,0.18,1.3,0.6,"#555");if(Math.random()<0.1)part({k:"smoke",x:x+1.5,y:y+0.5,h:2.0,vh:0.7,t:0,life:1.1});
  var pw=sim.power&&sim.power.src.filter(function(s){return s.u===o.u;})[0];var lb=P(x+1,y+2,0.62);txt("GEN "+(pw?pw.used+"/"+pw.cap:""),lb[0],lb[1],7,"#222");}
function drawBelt(sim,o,V){var x=o.x,y=o.y,d=S.DIRS[o.r],run=o.pw&&sim.s.box.belts>0;
  box(x+0.04,y+0.04,0.92,0.92,0,0.18,"#4d555c",{stroke:"rgba(0,0,0,0.5)"});
  poly([P(x+0.12,y+0.12,0.185),P(x+0.88,y+0.12,0.185),P(x+0.88,y+0.88,0.185),P(x+0.12,y+0.88,0.185)],"#24292d");
  var sp=(S.SPEEDV[sim.s.box.belts]||0)*1.3,off=run?(T*sp)%0.25:0,n=[-d[1],d[0]];
  for(var k=0;k<4;k++){var u=-0.5+k*0.25+off;if(u>0.5)u-=1;var c=[x+0.5+d[0]*u,y+0.5+d[1]*u];line(P(c[0]+n[0]*0.36,c[1]+n[1]*0.36,0.19),P(c[0]-n[0]*0.36,c[1]-n[1]*0.36,0.19),"#5a646c",1.4);}
  arrowFloor(x,y,o.r,run?"rgba(255,214,80,0.9)":"rgba(255,140,80,0.7)");
  if(!o.pw){var p=P(x+0.5,y+0.5,0.5);if(Math.floor(T*2)%2)txt("⚡",p[0],p[1],10,"#ffcc33");}}
D.drawBelt=drawBelt;
/* ---------- starters ---------- */
function drawTable(sim,o){var f=S.fp(o),x=f.x,y=f.y,h=0.9;shadow(x+f.w/2,y+f.h/2,1.6);
  [[0.1,0.1],[f.w-0.25,0.1],[0.1,f.h-0.25],[f.w-0.25,f.h-0.25]].forEach(function(l){box(x+l[0],y+l[1],0.15,0.15,0,h-0.12,"#6b4a2b");});
  box(x+0.15,y+0.15,f.w-0.3,f.h-0.3,0.3,0.06,"#7b5733");
  box(x,y,f.w,f.h,h-0.12,0.12,"#b07a45",{top:"#c98f55"});
  ctx.strokeStyle="rgba(110,70,30,0.35)";for(var i=1;i<5;i++){var u=i/5;if(f.w>=f.h)line(P(x,y+u*f.h,h),P(x+f.w,y+u*f.h,h),"rgba(110,70,30,0.3)");else line(P(x+u*f.w,y,h),P(x+u*f.w,y+f.h,h),"rgba(110,70,30,0.3)");}
  /* cutting board + knife */
  var bx=x+f.w*0.35,by=y+f.h*0.35;topQuad(bx-0.35,by-0.25,0.7,0.5,h+0.03,"#e2c48e","rgba(80,50,20,0.5)");line(P(bx+0.45,by-0.2,h+0.04),P(bx+0.45,by+0.25,h+0.04),"#d0d6dc",2);line(P(bx+0.45,by+0.25,h+0.04),P(bx+0.45,by+0.42,h+0.04),"#3a2a1a",3);
  /* built-in sink (t1206) with a dripping tap */
  var sk=sim.sinkTile(o),p=sim.s.papa,rin=p.task&&p.task.type==="rinse"&&p.task.stage==="act";
  poly([P(sk[0]+0.15,sk[1]+0.15,h+0.01),P(sk[0]+0.85,sk[1]+0.15,h+0.01),P(sk[0]+0.85,sk[1]+0.85,h+0.01),P(sk[0]+0.15,sk[1]+0.85,h+0.01)],"#9fb1bb",OUT);
  poly([P(sk[0]+0.25,sk[1]+0.25,h-0.08),P(sk[0]+0.75,sk[1]+0.25,h-0.08),P(sk[0]+0.75,sk[1]+0.75,h-0.08),P(sk[0]+0.25,sk[1]+0.75,h-0.08)],"#5f7480");
  box(sk[0]+0.45,sk[1]+0.12,0.08,0.08,h,0.35,"#c9d2d8");var tp=P(sk[0]+0.49,sk[1]+0.3,h+0.33);line(P(sk[0]+0.49,sk[1]+0.16,h+0.35),tp,"#c9d2d8",2);
  var dph=rin?1:(T*1.3)%1;if(rin){line(tp,P(sk[0]+0.49,sk[1]+0.3,h-0.05),"rgba(160,220,255,0.9)",2.5);}else{var dp=P(sk[0]+0.49,sk[1]+0.3,h+0.3-dph*0.35);ctx.fillStyle="#9fd8ff";ctx.fillRect(dp[0]-Z,dp[1],2*Z,2.5*Z);}
  /* tray potatoes */
  o.tray.forEach(function(u){var q=sim.pot(u);if(q)potato(q.x,q.y,h+0.05,q,0.3);});}
function drawCooler(sim,o,small){var f=S.fp(o),x=f.x+0.1,y=f.y+0.1,w=f.w-0.2,d=f.h-0.2,hh=small?0.6:0.95;shadow(x+w/2,y+d/2,0.55);
  box(x,y,w,d,0,hh,"#f2f4f6");box(x-0.02,y-0.02,w+0.04,d+0.04,hh,0.12,"#2f7fd0");box(x+w*0.3,y+d-0.02,w*0.4,0.06,hh-0.25,0.08,"#9aa");
  var on=sim.s.food>0;var lp=P(x+w,y+d*0.5,hh-0.2);ctx.fillStyle=on?((Math.floor(T*1.2)%3)?"#7dff9a":"#2c6a3c"):((Math.floor(T*1.2)%2)?"#ff7a5a":"#552a20");ctx.beginPath();ctx.arc(lp[0],lp[1],2.6*Z,0,6.28);ctx.fill();
  if(true){var fr=(T*0.6)%1;ctx.globalAlpha=0.4*(1-fr);ell(x+w/2,y+d/2,hh+0.2+fr*0.4,6+fr*6,3+fr*3,"#e8f6ff");ctx.globalAlpha=1;}
  var lb=P(x+w/2,y+d,0.25);txt(small?"+2":sim.s.food+"/"+sim.cooCap(),lb[0],lb[1],7,"#234");}
function drawBed(sim,o,cot){var f=S.fp(o),x=f.x,y=f.y,p=sim.s.papa,sl=p.task&&p.task.type==="nap"&&p.task.lying&&p.task.target===o;shadow(x+f.w/2,y+f.h/2,1.5);
  if(cot){box(x+0.05,y+0.05,f.w-0.1,f.h-0.1,0.25,0.12,"#556b3a");[[0.05,0.05],[f.w-0.15,0.05],[0.05,f.h-0.15],[f.w-0.15,f.h-0.15]].forEach(function(l){box(x+l[0],y+l[1],0.1,0.1,0,0.25,"#333");});
    topQuad(x+0.15,y+0.15,f.w-0.3,0.5,0.4,"#e9e4d4",OUT);sheen(x+0.1,y+0.7,f.w-0.2,f.h-0.8,0.38,0.2,0.25);var tg=P(x+f.w,y+f.h*0.5,0.3),sw=Math.sin(T*2.2)*5*Z;line(tg,[tg[0]+sw,tg[1]+9*Z],"#888",1);ctx.fillStyle="#f3e2a0";ctx.fillRect(tg[0]+sw-5*Z,tg[1]+9*Z,10*Z,7*Z);}
  else{box(x,y,f.w,f.h,0,0.35,"#7a5232");box(x,y,f.w,0.18,0,0.95,"#6a4528");box(x+0.08,y+0.2,f.w-0.16,f.h-0.28,0.35,0.22,"#f3efe4");
    box(x+0.25,y+0.3,f.w-0.5,0.55,0.57,0.12,"#ffffff");
    var br=sl?Math.sin(T*2)*0.03:0;box(x+0.08,y+1.0,f.w-0.16,f.h-1.08,0.57,0.06+br,"#3a6fb0",{top:"#4a80c4"});for(var i=0;i<3;i++)line(P(x+0.1,y+1.3+i*0.5,0.64+br),P(x+f.w-0.1,y+1.3+i*0.5,0.64+br),"rgba(255,255,255,0.35)",1.2);}
  if(sl&&Math.random()<0.04)part({k:"z",x:x+f.w/2,y:y+0.6,h:1.2,vh:0.5,t:0,life:2});}
function drawTub(sim,o){var f=S.fp(o),x=f.x,y=f.y,h=0.75;shadow(x+f.w/2,y+f.h/2,1.1);
  [[0.1,0.1],[f.w-0.2,0.1],[0.1,f.h-0.2],[f.w-0.2,f.h-0.2]].forEach(function(l){box(x+l[0],y+l[1],0.1,0.1,0,h-0.3,"#555");});
  box(x+0.05,y+0.05,f.w-0.1,f.h-0.1,h-0.3,0.42,"#a9b9c2",{top:"#c2d0d8"});
  poly([P(x+0.15,y+0.15,h+0.08),P(x+f.w-0.15,y+0.15,h+0.08),P(x+f.w-0.15,y+f.h-0.15,h+0.08),P(x+0.15,y+f.h-0.15,h+0.08)],"#7fc7e8");
  for(var i=0;i<5;i++){var ph=(T*0.7+i/5)%1;ctx.globalAlpha=1-ph;ell(x+0.3+i*(f.w-0.6)/4,y+f.h/2,h+0.1+ph*0.3,2.5,2.5,"#ffffff","rgba(150,200,240,0.8)");ctx.globalAlpha=1;}
  o.q.forEach(function(u){var q=sim.pot(u);if(q)potato(q.x,q.y,h+0.05+Math.sin(T*3+q.u)*0.02,q,Math.sin(T+q.u)*0.3);});
  /* scrub brush resting on the rim (Papa picks it up to scrub) */
  var p=sim.s.papa;if(!(p.task&&p.task.type==="scrub"&&p.task.stage==="act")){box(x+f.w-0.35,y+0.1,0.25,0.1,h+0.12,0.06,"#b5462f");}
  var lb=P(x+f.w/2,y+f.h,0.3);txt("SCRUB TUB",lb[0],lb[1],7,"#123");}
/* ---------- decor (each a physical object with a looped animation) ---------- */
/* a soft light band sliding across a surface: the looped animation for rugs, mats and shelves */
function sheen(x,y,w,d,h,a,sp){var u=((T*(sp||0.3))%1.5)-0.25;ctx.save();ctx.beginPath();var q=[P(x,y,h),P(x+w,y,h),P(x+w,y+d,h),P(x,y+d,h)];ctx.moveTo(q[0][0],q[0][1]);for(var i=1;i<4;i++)ctx.lineTo(q[i][0],q[i][1]);ctx.closePath();ctx.clip();
  var long=w>=d,a0=long?P(x+u*w,y-0.5,h):P(x-0.5,y+u*d,h),a1=long?P(x+u*w+0.3,y+d+0.5,h):P(x+w+0.5,y+u*d+0.3,h);ctx.strokeStyle="rgba(255,250,225,"+(a||0.28)+")";ctx.lineWidth=Math.max(4,16*Z);ctx.beginPath();ctx.moveTo(a0[0],a0[1]);ctx.lineTo(a1[0],a1[1]);ctx.stroke();ctx.restore();}
function drawRug(o){var f=S.fp(o),x=f.x,y=f.y,id=o.id,w=f.w,d=f.h,h=0.015,sh=Math.sin(T*1.5)*0.5+0.5;
  if(id==="roundRug"){isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.05,"#b86a3c","rgba(60,30,10,0.5)");isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.3,"#e0a35a");isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.55,"#8a4a2a");isoCirc(x+w/2,y+d/2,h,0.18,"rgba(255,230,170,"+(0.3+0.3*sh)+")");sheen(x+0.2,y+0.2,w-0.4,d-0.4,h+0.004,0.22,0.35);return;}
  var c=id==="kitchenMat"?["#7f9a6a","#efe6cf"]:id==="runner"?["#7a2f3a","#e2b45a"]:["#3d5a8a","#d9c08a"];
  topQuad(x+0.06,y+0.06,w-0.12,d-0.12,h,c[1],"rgba(40,20,10,0.5)");topQuad(x+0.16,y+0.16,w-0.32,d-0.32,h+0.002,c[0]);
  if(id==="kitchenMat"){for(var i=1;i<6;i++)line(P(x+0.16+i*(w-0.32)/6,y+0.16,h+0.003),P(x+0.16+i*(w-0.32)/6,y+d-0.16,h+0.003),"rgba(255,255,255,0.25)");}
  if(id==="runner"){for(var k=0;k<3;k++){var cy=y+0.5+k*(d-1)/2;poly([P(x+w/2,cy-0.25,h+0.004),P(x+w-0.25,cy,h+0.004),P(x+w/2,cy+0.25,h+0.004),P(x+0.25,cy,h+0.004)],c[1]);}}
  if(id==="rug"){topQuad(x+0.45,y+0.45,w-0.9,d-0.9,h+0.003,"#c75b4a");}
  sheen(x+0.1,y+0.1,w-0.2,d-0.2,h+0.005,0.25,0.3);
  /* tassels flutter */
  for(var t=0;t<4;t++){var fx=x+0.2+t*(w-0.4)/3;line(P(fx,y+d-0.06,h),P(fx+Math.sin(T*3+t)*0.03,y+d+0.08,h),c[1],1.2);}}
function drawFloorDecor(sim,o){var f=S.fp(o),x=f.x,y=f.y,id=o.id,cx=x+f.w/2,cy=y+f.h/2,s=sim.s;
  switch(id){
  case "sink":{shadow(cx,cy,0.5);box(x+0.1,y+0.1,0.8,0.8,0,0.85,"#e7ecef");topQuad(x+0.2,y+0.2,0.6,0.6,0.86,"#9fb1bb",OUT);topQuad(x+0.28,y+0.28,0.44,0.44,0.8,"#5f7480");
    box(x+0.46,y+0.12,0.08,0.08,0.85,0.35,"#c9d2d8");var p=s.papa,act=p.task&&p.task.type==="washRaw"&&p.task.stage==="act";var tp=P(x+0.5,y+0.32,1.18);line(P(x+0.5,y+0.16,1.2),tp,"#c9d2d8",2);
    if(act)line(tp,P(x+0.5,y+0.32,0.82),"rgba(160,220,255,0.9)",3);else{var dph=(T*1.1)%1,dp=P(x+0.5,y+0.32,1.15-dph*0.33);ctx.fillStyle="#9fd8ff";ctx.beginPath();ctx.ellipse(dp[0],dp[1],2*Z,3*Z,0,0,6.28);ctx.fill();if(dph>0.7)isoCirc(x+0.5,y+0.45,0.81,0.05+(dph-0.7)*0.6,null,"rgba(200,235,255,"+(1-(dph-0.7)/0.3)+")",1.5);}break;}
  case "smallCooler":drawCooler(sim,o,true);break;
  case "basicCot":drawBed(sim,o,true);break;
  case "compost":{shadow(cx,cy,0.45);cyl(cx,cy,0.34,0,0.75,"#3f6b3a");var lid=Math.max(0,Math.sin(T*1.2))*0.06;ell(cx,cy,0.78+lid,15,7.5,"#2d4f29","rgba(0,0,0,0.4)");
    if(Math.random()<0.03)part({k:"smoke",x:cx,y:cy,h:0.9,vh:0.3,t:0,life:1.5});break;}
  case "fruitBowl":{shadow(cx,cy,0.35);cyl(cx,cy,0.12,0,0.75,"#7a5232");cyl(cx,cy,0.3,0.75,0.1,"#d9d2c4");
    [["#d33",0],["#f5c518",1],["#6c3",2],["#e83",3]].forEach(function(fr){var a=fr[1]*1.6+Math.sin(T*1.3)*0.05,p=P(cx+Math.cos(a)*0.14,cy+Math.sin(a)*0.14,0.92);ctx.beginPath();ctx.arc(p[0],p[1],3.4*Z,0,6.28);ctx.fillStyle=fr[0];ctx.fill();});var fa=T*4,fl=P(cx+Math.cos(fa)*0.35,cy+Math.sin(fa*1.3)*0.3,1.15+Math.sin(T*7)*0.08);ctx.fillStyle="#222";ctx.beginPath();ctx.arc(fl[0],fl[1],2*Z,0,6.28);ctx.fill();ctx.fillStyle="rgba(220,230,255,0.8)";ctx.beginPath();ctx.ellipse(fl[0]-2*Z,fl[1]-2*Z,2.5*Z,1.4*Z,(Math.floor(T*20)%2)?0.6:-0.6,0,6.28);ctx.fill();ctx.beginPath();ctx.ellipse(fl[0]+2*Z,fl[1]-2*Z,2.5*Z,1.4*Z,(Math.floor(T*20)%2)?-0.6:0.6,0,6.28);ctx.fill();break;}
  case "plant":{shadow(cx,cy,0.4);cyl(cx,cy,0.25,0,0.4,"#b5562f");var dry=s.plant.dry>60,sw=Math.sin(T*1.6)*(dry?0.02:0.06);
    for(var i=0;i<7;i++){var a=i*0.9,len=dry?0.25:0.45,b0=P(cx,cy,0.4),b1=P(cx+Math.cos(a)*0.3+sw,cy+Math.sin(a)*0.3,0.4+len+(dry?-0.1:0.15));ctx.strokeStyle=dry?"#8a8a3a":"#3f9a3f";ctx.lineWidth=Math.max(2,4*Z);ctx.beginPath();ctx.moveTo(b0[0],b0[1]);ctx.quadraticCurveTo(b0[0]+sw*40*Z,b1[1]-8*Z,b1[0],b1[1]);ctx.stroke();}break;}
  case "lamp":{shadow(cx,cy,0.35);var on=s.box.lamp>0;if(on){ctx.globalAlpha=0.18+0.04*Math.sin(T*3);isoCirc(cx,cy,0.01,1.6,"#ffe6a0");ctx.globalAlpha=1;}
    cyl(cx,cy,0.18,0,0.06,"#333");box(cx-0.03,cy-0.03,0.06,0.06,0.06,1.4,"#444");cyl(cx,cy,0.26,1.35,0.3,on?"#ffe8a8":"#d8cfae");var ch=P(cx+0.15,cy+0.15,1.35),cs=Math.sin(T*2.5)*4*Z;line(ch,[ch[0]+cs,ch[1]+12*Z],"#c9a227",1.2);ctx.fillStyle="#c9a227";ctx.beginPath();ctx.arc(ch[0]+cs,ch[1]+12*Z,2*Z,0,6.28);ctx.fill();
    var ma=T*3.1,mp=P(cx+Math.cos(ma)*0.4,cy+Math.sin(ma)*0.4,1.75+Math.sin(T*5)*0.1);ctx.fillStyle=on?"#f4e9c8":"#9a9080";ctx.beginPath();ctx.ellipse(mp[0]-2*Z,mp[1],2.6*Z,1.6*Z,0.5,0,6.28);ctx.ellipse(mp[0]+2*Z,mp[1],2.6*Z,1.6*Z,-0.5,0,6.28);ctx.fill();break;}
  case "shelf":{shadow(cx,cy,0.7);for(var sh=0;sh<3;sh++)box(x+0.05,y+0.2,f.w-0.1,f.h-0.4,0.3+sh*0.5,0.06,"#8a6438");box(x+0.05,y+0.2,0.08,f.h-0.4,0,1.4,"#6b4a2b");box(x+f.w-0.13,y+0.2,0.08,f.h-0.4,0,1.4,"#6b4a2b");
    var n=Math.min(8,s.food);for(var c=0;c<n;c++){var u=x+0.25+(c%4)*(f.w-0.5)/3.5,lv=(c/4)|0;cyl(f.w>=f.h?u:cx,f.w>=f.h?cy:y+0.25+(c%4)*(f.h-0.5)/3.5,0.07,0.36+lv*0.5,0.2,["#d33","#36c","#da3"][c%3]);}
    sheen(x+0.05,y+0.2,f.w-0.1,f.h-0.4,1.36,0.35,0.3);var tg2=P(x+f.w*0.5,y+f.h-0.2,1.3),sw2=Math.sin(T*1.8)*4*Z;line(tg2,[tg2[0]+sw2,tg2[1]+10*Z],"#777",1);ctx.fillStyle="#fff3c0";ctx.fillRect(tg2[0]+sw2-6*Z,tg2[1]+10*Z,12*Z,7*Z);break;}
  case "sackPile":{shadow(cx,cy,0.8);for(var k=0;k<3;k++){var sx2=f.w>=f.h?x+0.45+k*0.55:cx,sy2=f.w>=f.h?cy:y+0.45+k*0.55,br=Math.sin(T*1.1+k)*0.02;cyl(sx2,sy2,0.28,0,0.5+br,"#b08a57");ell(sx2,sy2,0.55+br,8,4,"#8c6a3d");}break;}
  case "cookbook":{shadow(cx,cy,0.3);box(cx-0.05,cy-0.05,0.1,0.1,0,0.9,"#5a3a22");var pg=(T*0.4)%1;box(x+0.2,y+0.25,0.6,0.5,0.9,0.05,"#7a2f2a");
    topQuad(x+0.25,y+0.3,0.25,0.4,0.96,"#f6f0dd","#999");topQuad(x+0.5,y+0.3,0.25,0.4,0.96,"#f6f0dd","#999");var pp=P(x+0.5-0.25*Math.cos(pg*Math.PI),y+0.5,0.96+0.15*Math.sin(pg*Math.PI));line(P(x+0.5,y+0.5,0.96),pp,"#fff",2);break;}
  case "mopBucket":{shadow(cx,cy,0.4);cyl(cx,cy,0.27,0,0.45,"#e0c020");ell(cx,cy,0.45,12,6,"#6fb3d9");box(cx+0.05,cy-0.05,0.05,0.05,0.4,1.1,"#9a7a50");var sw=Math.sin(T*2)*0.04;cyl(cx+0.08+sw,cy,0.12,0.4,0.15,"#ddd");break;}
  case "radio":{shadow(cx,cy,0.4);box(x+0.3,y+0.3,0.4,0.4,0,0.55,"#6b4a2b");box(x+0.15,y+0.3,0.7,0.4,0.55,0.4,"#c0392b",{top:"#d9534f"});
    var on=s.box.radio>0;topQuad(x+0.25,y+0.35,0.3,0.3,0.96,"#2a2a2a");var dp=P(x+0.7,y+0.7,0.75);ctx.beginPath();ctx.arc(dp[0],dp[1],3*Z,0,6.28);ctx.fillStyle=on?"#ffe27a":"#777";ctx.fill();
    var an=P(x+0.75,y+0.35,0.95),at=P(x+0.95+Math.sin(T*2)*0.12,y+0.2,1.5+Math.sin(T*2)*0.05);line(an,at,"#bbb",1.6);ctx.fillStyle="#e33";ctx.beginPath();ctx.arc(at[0],at[1],2*Z,0,6.28);ctx.fill();
    var dl=P(x+0.6,y+0.7,0.88),nd=Math.sin(T*0.8)*6*Z;ctx.fillStyle="#f6e7b0";ctx.fillRect(dl[0]-8*Z,dl[1]-3*Z,16*Z,6*Z);line([dl[0]+nd,dl[1]-3*Z],[dl[0]+nd,dl[1]+3*Z],"#c00",1.5);
    if(on){var lv=window.PPRadio?Math.min(1,PPRadio.level()*6):0.5;var bp=P(x+0.4,y+0.7,0.75);ctx.beginPath();ctx.arc(bp[0],bp[1],(4+lv*2.5)*Z,0,6.28);ctx.fillStyle="#3a3a3a";ctx.fill();if(Math.random()<0.04)part({k:"note",x:cx,y:cy,h:1.2,vh:0.5,t:0,life:1.8,s:Math.random()<0.5?"♪":"♫"});}break;}
  case "fan":{shadow(cx,cy,0.35);cyl(cx,cy,0.2,0,0.06,"#444");box(cx-0.03,cy-0.03,0.06,0.06,0.06,0.9,"#555");var hc=P(cx,cy,1.15);ctx.beginPath();ctx.ellipse(hc[0],hc[1],11*Z,11*Z,0,0,6.28);ctx.fillStyle="rgba(200,220,230,0.25)";ctx.fill();ctx.strokeStyle="#888";ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();
    for(var b=0;b<3;b++){var a=T*18+b*2.09;ctx.beginPath();ctx.ellipse(hc[0]+Math.cos(a)*5*Z,hc[1]+Math.sin(a)*5*Z,5*Z,2.5*Z,a,0,6.28);ctx.fillStyle="#9fb1bb";ctx.fill();}break;}
  case "bookshelf":{shadow(cx,cy,0.7);box(x+0.05,y+0.25,f.w-0.1,f.h-0.5,0,1.8,"#6b4a2b");for(var r=0;r<3;r++){for(var bk=0;bk<6;bk++){var u=(f.w>=f.h?x:y)+0.15+bk*((f.w>=f.h?f.w:f.h)-0.3)/6,hh=0.25+((bk*7+r*3)%4)*0.04;
      if(f.w>=f.h)poly([P(u,y+f.h-0.25,0.15+r*0.55),P(u+0.13,y+f.h-0.25,0.15+r*0.55),P(u+0.13,y+f.h-0.25,0.15+r*0.55+hh),P(u,y+f.h-0.25,0.15+r*0.55+hh)],["#c0392b","#2e86c1","#27ae60","#f1c40f","#8e44ad","#e67e22"][(bk+r)%6]);
      else poly([P(x+f.w-0.25,u,0.15+r*0.55),P(x+f.w-0.25,u+0.13,0.15+r*0.55),P(x+f.w-0.25,u+0.13,0.15+r*0.55+hh),P(x+f.w-0.25,u,0.15+r*0.55+hh)],["#c0392b","#2e86c1","#27ae60","#f1c40f","#8e44ad","#e67e22"][(bk+r)%6]);}}
    var wig=Math.sin(T*1.5)*0.12;box(x+0.3,y+0.35+(f.w>=f.h?0:wig),0.1+(f.w>=f.h?0:0),0.1,1.8,0.25,"#c33");var bm=P(x+f.w*0.6,y+f.h-0.25,1.25),bs=Math.sin(T*2)*4*Z;line(bm,[bm[0]+bs,bm[1]+16*Z],"#e33",2.5);sheen(x+0.05,y+0.25,f.w-0.1,f.h-0.5,1.8,0.3,0.3);break;}
  case "catBed":{shadow(cx,cy,0.45);cyl(cx,cy,0.38,0,0.18,"#8e5aa8");var bre=Math.sin(T*1.6)*1.5;ell(cx,cy,0.18,15+bre,7.5+bre*0.5,"#f0d8f8");var yr=Math.sin(T*0.9)*0.25,yp=P(cx+0.45+yr,cy+0.3,0.08);ctx.fillStyle="#e04a6a";ctx.beginPath();ctx.arc(yp[0],yp[1],4*Z,0,6.28);ctx.fill();ctx.strokeStyle="#a02a4a";ctx.lineWidth=Math.max(0.6,Z);ctx.beginPath();ctx.arc(yp[0],yp[1],2.5*Z,T*3+yr*8,T*3+yr*8+3);ctx.stroke();break;}
  case "tvArmchair":{var p=s.papa,w=f.w>=f.h;shadow(cx,cy,1.3);
    /* TV on a stand at the back, armchair in front facing it */
    var tx=w?x+0.3:x+0.3,ty=y+0.15;box(tx,ty,f.w-0.6,0.4,0,0.5,"#5a3a22");box(tx+0.1,ty+0.05,f.w-0.8,0.3,0.5,0.75,"#222");
    var on=s.box.tv>0,sc=[P(tx+0.15,ty+0.36,0.58),P(tx+f.w-0.75,ty+0.36,0.58),P(tx+f.w-0.75,ty+0.36,1.18),P(tx+0.15,ty+0.36,1.18)];
    poly(sc,on?["#3b7dd8","#d84b3b","#3bd86a","#d8c03b"][Math.floor(T*1.5)%4]:"#111");if(!on){var rf=(T*0.25)%1.4-0.2,r0=P(tx+0.15+rf*(f.w-0.9),ty+0.36,0.58),r1=P(tx+0.15+rf*(f.w-0.9)+0.25,ty+0.36,1.18);ctx.save();ctx.beginPath();ctx.moveTo(sc[0][0],sc[0][1]);for(var si=1;si<4;si++)ctx.lineTo(sc[si][0],sc[si][1]);ctx.closePath();ctx.clip();line(r0,r1,"rgba(255,255,255,0.18)",10*Z);ctx.restore();var led=P(tx+f.w-0.85,ty+0.37,0.62);ctx.fillStyle=(Math.floor(T*1.5)%2)?"#ff3b30":"#4a1410";ctx.beginPath();ctx.arc(led[0],led[1],2.2*Z,0,6.28);ctx.fill();}if(on){ctx.globalAlpha=0.25;for(var k=0;k<5;k++)line(P(tx+0.15,ty+0.36,0.62+k*0.12+((T*2)%0.12)),P(tx+f.w-0.75,ty+0.36,0.62+k*0.12+((T*2)%0.12)),"#fff");ctx.globalAlpha=1;}
    var ax=x+0.35,ay=y+f.h-0.95;box(ax,ay,f.w-0.7,0.8,0,0.45,"#8b3a3a");box(ax,ay+0.6,f.w-0.7,0.2,0.45,0.55,"#7a3030");box(ax,ay,0.15,0.8,0.45,0.2,"#7a3030");box(ax+f.w-0.85,ay,0.15,0.8,0.45,0.2,"#7a3030");break;}
  case "aquarium":{shadow(cx,cy,0.45);box(x+0.15,y+0.25,0.7,0.5,0,0.7,"#4a3a2a");box(x+0.12,y+0.22,0.76,0.56,0.7,0.5,"rgba(120,200,255,0.55)",{top:"rgba(160,220,255,0.5)",left:"rgba(80,170,230,0.6)",right:"rgba(60,140,200,0.6)"});
    for(var fsh=0;fsh<3;fsh++){var a=T*(0.8+fsh*0.3)+fsh*2,fp2=P(x+0.5+Math.cos(a)*0.25,y+0.78,0.85+fsh*0.12);ctx.fillStyle=["#ff8c1a","#ffd31a","#ff4d6a"][fsh];ctx.beginPath();ctx.ellipse(fp2[0],fp2[1],3*Z,1.8*Z,0,0,6.28);ctx.fill();}
    var bb=(T*0.9)%1,bp=P(x+0.3,y+0.78,0.75+bb*0.4);ctx.fillStyle="rgba(255,255,255,0.8)";ctx.beginPath();ctx.arc(bp[0],bp[1],1.3*Z,0,6.28);ctx.fill();break;}
  case "statue":{shadow(cx,cy,0.4);box(x+0.2,y+0.2,0.6,0.6,0,0.45,"#888");var gl=0.5+0.5*Math.sin(T*2);drawPapaBody(P(cx,cy,0.45),0.62,{gold:1,face:1,dir:1,tt:T,still:1});
    ctx.globalAlpha=0.3*gl;var gp=P(cx,cy,1.0);ctx.beginPath();ctx.arc(gp[0],gp[1],14*Z,0,6.28);ctx.fillStyle="#ffe27a";ctx.fill();ctx.globalAlpha=1;break;}
  default:{box(x+0.2,y+0.2,f.w-0.4,f.h-0.4,0,0.5,"#999");}
  }}
function drawWallItem(sim,o){var w=o.wall,u=w==="N"?o.x:o.y,id=o.id,it=S.itemDef(id),n=it.w||1,s=sim.s,mid=u+n/2;
  function Q(a,b,h0,h1,c,st){wallQuad(w,u+a,u+b,h0,h1,c,st||OUT);}
  switch(id){
  case "clock":{var c=wallPt(w,mid,1.75,0.03);ctx.beginPath();ctx.ellipse(c[0],c[1],10*Z,11*Z,0,0,6.28);ctx.fillStyle="#fffbea";ctx.fill();ctx.strokeStyle="#5a3a22";ctx.lineWidth=Math.max(1,2*Z);ctx.stroke();
    var m=sim.shiftMin(),ha=(m/720)*6.283-1.57,ma=((m%60)/60)*6.283-1.57,sa=(T%60)/60*6.283-1.57;line(c,[c[0]+Math.cos(ha)*5*Z,c[1]+Math.sin(ha)*5*Z],"#222",1.6);line(c,[c[0]+Math.cos(ma)*7.5*Z,c[1]+Math.sin(ma)*7.5*Z],"#222",1);line(c,[c[0]+Math.cos(sa)*8*Z,c[1]+Math.sin(sa)*8*Z],"#c33",0.6);break;}
  case "coatHook":{Q(0.2,0.8,1.75,1.85,"#6b4a2b");var sw=Math.sin(T*1.4)*0.05;poly([wallPt(w,mid-0.15,1.75,0.05),wallPt(w,mid+0.15,1.75,0.05),wallPt(w,mid+0.22+sw,1.05,0.08),wallPt(w,mid-0.22+sw,1.05,0.08)],"#e8e2d0",OUT);
    poly([wallPt(w,mid-0.12+sw*0.6,1.45,0.07),wallPt(w,mid+0.12+sw*0.6,1.45,0.07),wallPt(w,mid+0.12+sw*0.8,1.25,0.08),wallPt(w,mid-0.12+sw*0.8,1.25,0.08)],"#c0392b");break;}
  case "calendar":{Q(0.2,0.8,1.2,1.9,"#fffdf5");Q(0.2,0.8,1.75,1.9,"#c0392b");var fl=(T/5)%1;if(fl<0.15){var k=fl/0.15;poly([wallPt(w,u+0.2,1.75,0.04),wallPt(w,u+0.8,1.75,0.04),wallPt(w,u+0.8,1.75-0.55*(1-k),0.04+k*0.25),wallPt(w,u+0.2,1.75-0.55*(1-k),0.04+k*0.25)],"#f4efe2",OUT);}
    var dp=wallPt(w,mid,1.45,0.03);txt(""+(1+Math.floor((s.t*2+480)/1440)%31),dp[0],dp[1],9,"#333");break;}
  case "spiceRack":{Q(0.1,0.9,1.3,1.36,"#7a5232");Q(0.1,0.9,1.6,1.66,"#7a5232");for(var j=0;j<4;j++){var jp=wallPt(w,u+0.2+j*0.2,1.36,0.08),bob=(Math.floor(T*0.5+j)%4===0)?Math.sin(T*10)*1.2*Z:0;ctx.fillStyle=["#c0392b","#e67e22","#27ae60","#f1c40f"][j];ctx.fillRect(jp[0]-2*Z,jp[1]-8*Z+bob,4*Z,8*Z);ctx.fillStyle="#eee";ctx.fillRect(jp[0]-2*Z,jp[1]-9.5*Z+bob,4*Z,2*Z);}break;}
  case "window":{var m2=sim.shiftMin(),day=m2>=360&&m2<1200,sky=day?(m2<480||m2>1080?"#f2a65a":"#8fd0ff"):"#1b2340";Q(0.15,n-0.15,1.0,2.1,"#f3efe4");Q(0.25,n-0.25,1.08,2.02,sky);
    if(!day){for(var st=0;st<5;st++){var sp=wallPt(w,u+0.4+st*0.3,1.4+(st%2)*0.4,0.03);ctx.fillStyle="#fff";ctx.fillRect(sp[0],sp[1],Z,Z);}}else{var cl=wallPt(w,u+0.4+((T*0.03)%1)*(n-0.8),1.8,0.03);ctx.fillStyle="#fff";ctx.beginPath();ctx.ellipse(cl[0],cl[1],6*Z,2.5*Z,0,0,6.28);ctx.fill();}
    line(wallPt(w,mid,1.08,0.03),wallPt(w,mid,2.02,0.03),"#f3efe4",2);var cw=Math.sin(T*1.1)*0.04;Q(0.1,0.4+cw,1.0,2.15,"#d65a5a",null);Q(n-0.4-cw,n-0.1,1.0,2.15,"#d65a5a",null);break;}
  case "poster":{var fl2=Math.sin(T*2.2)*0.04;Q(0.15,0.85,1.1,2.0,"#f5e6b8");var pc=wallPt(w,mid,1.6,0.03);drawPapaBody([pc[0],pc[1]+10*Z],0.45,{face:1,dir:1,tt:T,still:1,flat:1});txt("PAPA",pc[0],wallPt(w,mid,1.17,0.03)[1],7,"#a33");
    poly([wallPt(w,u+0.85,2.0,0.03),wallPt(w,u+0.85,1.82,0.03),wallPt(w,u+0.7,2.0,0.06+fl2)],"#e0cf9c");break;}
  case "potsPans":{Q(0.1,n-0.1,1.95,2.0,"#555");for(var pn=0;pn<3;pn++){var sw2=Math.sin(T*1.3+pn)*0.05,pu=u+0.35+pn*(n-0.7)/2,hp=wallPt(w,pu,1.95,0.05),pp=wallPt(w,pu+sw2,1.55-pn*0.05,0.08);line(hp,pp,"#444",1);ctx.beginPath();ctx.ellipse(pp[0],pp[1]+5*Z,(6-pn)*Z,(5-pn*0.6)*Z,0,0,6.28);ctx.fillStyle=pn===1?"#b87333":"#3a3a3a";ctx.fill();ctx.strokeStyle="#111";ctx.stroke();}break;}
  case "photos":{for(var ph=0;ph<3;ph++){var a0=0.12+ph*0.27,h0=1.3+(ph%2)*0.3;Q(a0,a0+0.24,h0,h0+0.3,"#7a5232");Q(a0+0.03,a0+0.21,h0+0.03,h0+0.27,"#f2d98a",null);var fp3=wallPt(w,u+a0+0.12,h0+0.14,0.03);ctx.fillStyle="#9a6a3a";ctx.beginPath();ctx.ellipse(fp3[0],fp3[1]+Math.sin(T*2+ph)*0.5*Z,2.5*Z,3*Z,0,0,6.28);ctx.fill();}break;}
  case "towelRack":{Q(0.1,0.9,1.5,1.55,"#bbb");var sw3=Math.sin(T*1.2)*0.03;poly([wallPt(w,u+0.2,1.52,0.05),wallPt(w,u+0.8,1.52,0.05),wallPt(w,u+0.8+sw3,1.0,0.07),wallPt(w,u+0.2+sw3,1.0,0.07)],"#5dade2",OUT);for(var sl=0;sl<3;sl++)line(wallPt(w,u+0.2+sw3*0.5,1.15+sl*0.1,0.07),wallPt(w,u+0.8+sw3*0.5,1.15+sl*0.1,0.07),"rgba(255,255,255,0.6)");break;}
  case "soap":{Q(0.3,0.7,1.1,1.55,"#f2f2f2");Q(0.35,0.65,1.2,1.45,"#e88cc8",null);var dd=(T*0.7)%1;var dp2=wallPt(w,mid,1.08-dd*0.4,0.06);ctx.fillStyle="rgba(232,140,200,"+(1-dd)+")";ctx.beginPath();ctx.ellipse(dp2[0],dp2[1],2.4*Z,3.2*Z,0,0,6.28);ctx.fill();
    for(var sb=0;sb<3;sb++){var bph=(T*0.45+sb/3)%1,bp3=wallPt(w,mid+(sb-1)*0.25+Math.sin(T*2+sb)*0.08,1.6+bph*0.7,0.12);ctx.strokeStyle="rgba(255,200,240,"+(1-bph)+")";ctx.lineWidth=Math.max(0.8,1.2*Z);ctx.beginPath();ctx.arc(bp3[0],bp3[1],(2+bph*3)*Z,0,6.28);ctx.stroke();}break;}
  case "stringLights":{for(var lb=0;lb<9;lb++){var lu=u+0.1+lb*(n-0.2)/8,lh=2.15-Math.sin(lb/8*Math.PI)*0.18,lp2=wallPt(w,lu,lh,0.04),on=((Math.floor(T*3)+lb)%3)!==0;if(lb){var pv=wallPt(w,u+0.1+(lb-1)*(n-0.2)/8,2.15-Math.sin((lb-1)/8*Math.PI)*0.18,0.04);line(pv,lp2,"#333",0.8);}
      ctx.beginPath();ctx.arc(lp2[0],lp2[1]+2*Z,2.2*Z,0,6.28);ctx.fillStyle=on?["#ff6b6b","#ffd93d","#6bcBff","#7dff9a"][lb%4]:"#555";ctx.fill();}break;}
  case "neonSign":{var flick=(Math.floor(T*7)%23)!==0&&Math.sin(T*1.7)>-0.85;Q(0.08,0.92,1.45,1.95,"#1a1a24");var np=wallPt(w,mid,1.7,0.03);txt("OPEN",np[0],np[1],9,flick?"#ff4fd8":"#552244");if(flick){ctx.globalAlpha=0.1+0.12*(0.5+0.5*Math.sin(T*4));ctx.beginPath();ctx.arc(np[0],np[1],(18+5*Math.sin(T*4))*Z,0,6.28);ctx.fillStyle="#ff4fd8";ctx.fill();ctx.globalAlpha=1;}break;}
  case "trophyShelf":{Q(0.1,n-0.1,1.4,1.47,"#6b4a2b");var cups=sim.cups();for(var cu=0;cu<3;cu++){var tp=wallPt(w,u+0.4+cu*(n-0.8)/2,1.47,0.08),got=cu<cups,gl=got?0.5+0.5*Math.sin(T*2+cu):0;ctx.fillStyle=got?"rgb("+(220+30*gl|0)+","+(180+40*gl|0)+",40)":"#555";ctx.fillRect(tp[0]-3*Z,tp[1]-9*Z,6*Z,6*Z);ctx.fillRect(tp[0]-1*Z,tp[1]-3*Z,2*Z,3*Z);}break;}
  default:Q(0.2,n-0.2,1.2,1.8,"#999");
  }}
function drawBasin(sim){var b=sim.s.basin;if(b.duck){var a=T*0.4,dx=18.5+Math.cos(a)*0.7,dy=13.8+Math.sin(a)*1.0,bob=Math.sin(T*3)*0.02;ell(dx,dy,0.1+bob,6,4,"#ffd31a","#a80");ell(dx+0.12,dy-0.05,0.25+bob,3.5,3.5,"#ffd31a","#a80");var bk=P(dx+0.2,dy-0.05,0.24+bob);ctx.fillStyle="#f80";ctx.fillRect(bk[0],bk[1]-Z,3*Z,2*Z);}
  if(b.toyBoat){var c=(T*0.9)%S.CANAL_LEN,p=sim.canalPos(c),bb=Math.sin(T*4)*0.02;var hp=P(p.x,p.y,0.08+bb);ctx.fillStyle="#c0392b";ctx.beginPath();ctx.moveTo(hp[0]-8*Z,hp[1]);ctx.lineTo(hp[0]+8*Z,hp[1]);ctx.lineTo(hp[0]+5*Z,hp[1]+4*Z);ctx.lineTo(hp[0]-5*Z,hp[1]+4*Z);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.moveTo(hp[0],hp[1]-14*Z);ctx.lineTo(hp[0]+6*Z,hp[1]-2*Z);ctx.lineTo(hp[0],hp[1]-2*Z);ctx.fill();line([hp[0],hp[1]-14*Z],[hp[0],hp[1]],"#5a3a22",1);}
  if(b.bubbles){box(19.4,12.3,0.4,0.3,0,0.2,"#7f8c8d");for(var i=0;i<8;i++){var ph=(T*0.6+i/8)%1;ctx.globalAlpha=1-ph;ell(18+((i*37)%10)/5,12.6+((i*53)%10)/3.3,0.1+ph*0.6,2+ph*2,2+ph*2,"rgba(255,255,255,0.6)","rgba(150,210,255,0.9)");ctx.globalAlpha=1;}}}
/* ---------- PAPA v2: same potato guy, better proportions, shading, smoother animation ---------- */
function blob(cx,cy,rx,ry){ctx.beginPath();ctx.moveTo(cx,cy-ry);ctx.bezierCurveTo(cx+rx*0.62,cy-ry*1.02,cx+rx*1.04,cy-ry*0.42,cx+rx*0.98,cy+ry*0.12);ctx.bezierCurveTo(cx+rx*0.92,cy+ry*0.78,cx+rx*0.42,cy+ry*1.0,cx-rx*0.05,cy+ry*0.98);
  ctx.bezierCurveTo(cx-rx*0.6,cy+ry*0.96,cx-rx*1.02,cy+ry*0.6,cx-rx*0.98,cy+ry*0.02);ctx.bezierCurveTo(cx-rx*0.94,cy-ry*0.55,cx-rx*0.55,cy-ry*0.98,cx,cy-ry);ctx.closePath();}
function limb(a,b,c,w){ctx.strokeStyle=c;ctx.lineCap="round";ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();ctx.lineCap="butt";}
/* pt = feet on screen; sc = size; o = pose info. Returns {hl,hr,body} in screen px so tools can be drawn in his hands */
var PS=1.45;/* Papa v2 scale: about 1.5 m tall next to a 0.9 m table */
function drawPapaBody(pt,sc,o){var k=Z*sc*PS,fx=pt[0],fy=pt[1],m=o.mir?-1:1,ph=o.walk||0,mv=o.moving?1:0,t=o.tt||T;
  var bob=mv?Math.abs(Math.sin(ph*9))*1.6*k:Math.sin(t*2.2)*0.5*k,lean=(o.lean||0)*k,sitd=o.sit?7*k:0;
  var skin=o.gold?["#fff3b0","#e2b93b","#8a6a12"]:["#e9c48e","#b98348","#6e4522"];
  var bx=fx+lean*m,by=fy-27*k-bob+sitd;
  if(!o.flat){ctx.fillStyle="rgba(0,0,0,0.22)";ctx.beginPath();ctx.ellipse(fx,fy,14*k,5*k,0,0,6.28);ctx.fill();}
  /* legs */
  var lc=o.gold?"#c9a227":"#7a4d28",sw=mv?Math.sin(ph*9):0;
  if(o.sit){limb([bx-5*k,fy-6*k],[bx-5*k+9*k*m,fy-2*k],lc,5*k);limb([bx+5*k,fy-6*k],[bx+5*k+9*k*m,fy-1*k],lc,5*k);}
  else{limb([bx-5*k,fy-12*k],[fx-5*k+sw*3*k*m,fy-Math.max(0,sw)*3*k],lc,5.5*k);limb([bx+5*k,fy-12*k],[fx+5*k-sw*3*k*m,fy-Math.max(0,-sw)*3*k],lc,5.5*k);
    ctx.fillStyle=o.gold?"#a8861a":"#3b2414";ctx.beginPath();ctx.ellipse(fx-5*k+sw*3*k*m+1.5*k*m,fy-Math.max(0,sw)*3*k,4*k,2.2*k,0,0,6.28);ctx.fill();ctx.beginPath();ctx.ellipse(fx+5*k-sw*3*k*m+1.5*k*m,fy-Math.max(0,-sw)*3*k,4*k,2.2*k,0,0,6.28);ctx.fill();}
  var sh={l:[bx-12*k,by-4*k],r:[bx+12*k,by-4*k]};
  var hands=o.hands?o.hands(bx,by,k,m):{l:[bx-15*k-sw*2*k,by+9*k],r:[bx+15*k+sw*2*k,by+9*k]};
  if(o.back)o.back(bx,by,k,m);
  /* far arm behind */
  var farL=(m>0);var armC=o.gold?"#c9a227":"#8a5a30";
  if(farL)limb(sh.l,hands.l,armC,4*k);else limb(sh.r,hands.r,armC,4*k);
  /* body */
  blob(bx,by,15*k,20*k);var g=ctx.createRadialGradient(bx-6*k*m,by-9*k,2*k,bx,by,24*k);g.addColorStop(0,skin[0]);g.addColorStop(0.55,skin[1]);g.addColorStop(1,skin[2]);ctx.fillStyle=g;ctx.fill();ctx.strokeStyle="rgba(50,28,12,0.8)";ctx.lineWidth=Math.max(0.8,1.1*k);ctx.stroke();
  /* skin spots */
  ctx.fillStyle="rgba(90,55,25,0.55)";[[-8,6],[7,10],[9,-6],[-3,14]].forEach(function(s2){ctx.beginPath();ctx.ellipse(bx+s2[0]*k*m,by+s2[1]*k,1.6*k,1.1*k,0,0,6.28);ctx.fill();});
  if(o.apron){ctx.fillStyle="rgba(240,236,224,0.95)";ctx.beginPath();ctx.moveTo(bx-9*k,by+1*k);ctx.lineTo(bx+9*k,by+1*k);ctx.lineTo(bx+10*k,by+16*k);ctx.quadraticCurveTo(bx,by+20*k,bx-10*k,by+16*k);ctx.closePath();ctx.fill();ctx.strokeStyle="rgba(120,110,90,0.6)";ctx.lineWidth=Math.max(0.5,0.7*k);ctx.stroke();}
  if(o.face){var ex=bx+3*k*m,ey=by-7*k,cl=o.eyesClosed||((t%3.7)<0.12);
    [[-5,0],[5,0]].forEach(function(e){var X=ex+e[0]*k,Y=ey;if(cl){limb([X-2.5*k,Y],[X+2.5*k,Y],"#2a1a0e",1.2*k);}else{ctx.fillStyle="#fff";ctx.beginPath();ctx.ellipse(X,Y,3*k,3.6*k,0,0,6.28);ctx.fill();ctx.strokeStyle="rgba(40,20,10,0.6)";ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();ctx.fillStyle="#1d120a";ctx.beginPath();ctx.arc(X+1*k*m,Y+0.6*k,1.6*k,0,6.28);ctx.fill();ctx.fillStyle="#fff";ctx.fillRect(X+1.2*k*m,Y-0.6*k,0.9*k,0.9*k);}
      limb([X-2.8*k,Y-5.4*k+(o.lazy?1.2*k:0)],[X+2.8*k,Y-5.6*k],"#4a2c14",1.3*k);});
    ctx.fillStyle="rgba(255,120,110,0.35)";ctx.beginPath();ctx.ellipse(ex-8*k,ey+5*k,2.6*k,1.6*k,0,0,6.28);ctx.fill();ctx.beginPath();ctx.ellipse(ex+8*k,ey+5*k,2.6*k,1.6*k,0,0,6.28);ctx.fill();
    ctx.fillStyle=skin[1];ctx.beginPath();ctx.ellipse(ex+0.5*k*m,ey+3.5*k,2.4*k,1.8*k,0,0,6.28);ctx.fill();
    /* moustache */
    ctx.fillStyle=o.gold?"#8a6a12":"#3b2414";ctx.beginPath();ctx.moveTo(ex,ey+5.4*k);ctx.quadraticCurveTo(ex-4*k,ey+4.2*k,ex-6.5*k,ey+6.8*k);ctx.quadraticCurveTo(ex-3*k,ey+7.4*k,ex,ey+6.4*k);ctx.quadraticCurveTo(ex+3*k,ey+7.4*k,ex+6.5*k,ey+6.8*k);ctx.quadraticCurveTo(ex+4*k,ey+4.2*k,ex,ey+5.4*k);ctx.fill();
    if(o.mouth==="open"){ctx.fillStyle="#4a1a10";ctx.beginPath();ctx.ellipse(ex,ey+9.5*k,2.6*k,2.2*k,0,0,6.28);ctx.fill();}else{ctx.strokeStyle="#4a1a10";ctx.lineWidth=Math.max(0.6,0.9*k);ctx.beginPath();ctx.arc(ex,ey+7.6*k,2.4*k,0.3,2.8);ctx.stroke();}}
  /* near arm in front */
  if(farL)limb(sh.r,hands.r,armC,4*k);else limb(sh.l,hands.l,armC,4*k);
  ctx.fillStyle=o.gold?"#e2b93b":"#c58e55";[hands.l,hands.r].forEach(function(h){ctx.beginPath();ctx.arc(h[0],h[1],2.8*k,0,6.28);ctx.fill();ctx.strokeStyle="rgba(50,28,12,0.7)";ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();});
  if(o.front)o.front(bx,by,k,m,hands);
  return {hl:hands.l,hr:hands.r,bx:bx,by:by,k:k};}
D.drawPapaBody=drawPapaBody;
function sackDraw(cx,cy,k,n){ctx.fillStyle="#b08a57";ctx.beginPath();ctx.ellipse(cx,cy,9*k,11*k,0,0,6.28);ctx.fill();ctx.strokeStyle="#6b5230";ctx.lineWidth=Math.max(0.6,k);ctx.stroke();
  ctx.fillStyle="#8c6a3d";ctx.fillRect(cx-4*k,cy-12*k,8*k,3*k);for(var i=0;i<Math.min(4,n);i++){ctx.fillStyle="rgba(110,80,40,0.6)";ctx.beginPath();ctx.ellipse(cx+(i%2?3:-3)*k,cy+(i<2?-2:5)*k,3*k,2.6*k,0,0,6.28);ctx.fill();}
  ctx.strokeStyle="rgba(90,65,35,0.5)";for(var j=0;j<3;j++){ctx.beginPath();ctx.moveTo(cx-8*k,cy-6*k+j*6*k);ctx.lineTo(cx+8*k,cy-5*k+j*6*k);ctx.stroke();}}
function broomOnBack(bx,by,k,m){limb([bx-10*k*m,by+12*k],[bx+12*k*m,by-26*k],"#9a6a3a",2.4*k);ctx.fillStyle="#d8b24a";ctx.beginPath();ctx.moveTo(bx+10*k*m,by-24*k);ctx.lineTo(bx+18*k*m,by-34*k);ctx.lineTo(bx+20*k*m,by-30*k);ctx.lineTo(bx+13*k*m,by-21*k);ctx.closePath();ctx.fill();
  ctx.fillStyle="#2f6f9a";ctx.fillRect(bx-13*k*m-3*k,by+5*k,7*k,6*k);}
function drawPapa(sim){var s=sim.s,p=s.papa,t=p.task,act=t&&t.stage==="act",ty=t?t.type:"idle";
  if(act&&(ty==="nap"&&t.lying||ty==="watch"&&t.sit))return;   /* the bed / armchair draws him */
  var pt=P(p.x,p.y,0),scx=p.fx-p.fy,scy=(p.fx+p.fy),mir=scx<-0.01,front=scy>=-0.01||ty==="doze"||ty==="puke";
  var held=p.hold.map(function(u){return sim.pot(u);}).filter(Boolean),sackOn=s.equip.carrySack&&p.sack.on,broom=s.equip.broomDustpan;
  var o={face:front,mir:mir,walk:p.walkT,moving:p.moving,tt:T,lazy:p.lazy,apron:sim.placed("coatHook")};
  var tt=act?t.t:0;
  /* things on his back */
  o.back=function(bx,by,k,m){if(front){if(sackOn)sackDraw(bx-12*k*m,by-2*k,k,held.length);if(broom&&!(act&&(ty==="sweep"||ty==="mop")))broomOnBack(bx,by,k,m);}};
  var frontExtra=function(bx,by,k,m,h){if(!front){if(sackOn)sackDraw(bx+2*k*m,by-1*k,k,held.length);if(broom&&!(act&&(ty==="sweep"||ty==="mop")))broomOnBack(bx,by,k,-m);}};
  if(act&&ty==="peel"){o.hands=function(bx,by,k,m){var a=Math.sin(T*10)*3*k;return {l:[bx-6*k*m+0*a,by+6*k],r:[bx+8*k*m+a*m,by+3*k+a*0.4]};};
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);var cur=sim.pot(t.cur);if(cur){var tp=[h.l[0]+3*k*m,h.l[1]-2*k];ctx.save();ctx.translate(tp[0],tp[1]);ctx.rotate(T*2);ctx.beginPath();ctx.ellipse(0,0,6*k,4.4*k,0,0,6.28);var pr=t.prog||0;ctx.fillStyle=pr>0.5?"#f2d98a":"#9a6a3a";ctx.fill();ctx.strokeStyle="rgba(60,30,10,0.6)";ctx.lineWidth=Math.max(0.5,0.7*k);ctx.stroke();ctx.restore();}
      if(s.equip.betterPeeler){limb(h.r,[h.r[0]+5*k*m,h.r[1]-5*k],"#d0d6dc",2.2*k);limb(h.r,[h.r[0]-1*k*m,h.r[1]+3*k],"#2f6f9a",3*k);ctx.fillStyle="#fff";if(Math.floor(T*4)%2)ctx.fillRect(h.r[0]+4*k*m,h.r[1]-6*k,1.5*k,1.5*k);}
      else{limb(h.r,[h.r[0]+6*k*m,h.r[1]-3*k],"#c9d2d8",1.6*k);limb(h.r,[h.r[0]-2*k*m,h.r[1]+1*k],"#3a2a1a",2.6*k);}
      if(Math.random()<0.25)part({k:"peel",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.4,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.4,h:0.9,vx:(Math.random()-0.5)*1.2,vy:(Math.random()-0.5)*1.2,vh:1+Math.random(),t:0,life:0.6,r:Math.random()*6});};}
  else if(act&&(ty==="sweep"||ty==="mop")){var swp=Math.sin(T*(ty==="mop"?5:8));o.hands=function(bx,by,k,m){return {l:[bx+4*k*m,by+2*k],r:[bx+9*k*m,by+8*k]};};o.lean=4;
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);if(broom){var head=[pt[0]+(14+swp*7)*k*m,pt[1]+2*k];limb(h.l,head,"#9a6a3a",2.4*k);ctx.save();ctx.translate(head[0],head[1]);ctx.rotate(swp*0.3);ctx.fillStyle=ty==="mop"?"#e8e4d8":"#d8b24a";ctx.fillRect(-7*k,-2*k,14*k,5*k);ctx.strokeStyle="#7a5a20";ctx.lineWidth=Math.max(0.5,0.7*k);ctx.strokeRect(-7*k,-2*k,14*k,5*k);ctx.restore();
      ctx.fillStyle="#2f6f9a";ctx.beginPath();ctx.moveTo(h.r[0],h.r[1]);ctx.lineTo(h.r[0]+8*k*m,h.r[1]+9*k);ctx.lineTo(h.r[0]+1*k*m,h.r[1]+11*k);ctx.closePath();ctx.fill();}
      else{ctx.fillStyle=ty==="mop"?"#e8e4d8":"#c58c47";ctx.beginPath();ctx.arc(h.r[0]+swp*3*k,h.r[1]+4*k,2.5*k,0,6.28);ctx.fill();}
      if(Math.random()<0.15)part({k:ty==="mop"?"foam":"peel",x:p.x+(Math.random()-0.5)*0.6,y:p.y+0.4,h:0.1,vh:0.5,t:0,life:0.6,r:2+Math.random()*2,vx:0,vy:0});};}
  else if(act&&ty==="scrub"){o.hands=function(bx,by,k,m){var a=T*12;return {l:[bx+(6+Math.cos(a)*3)*k*m,by+8*k+Math.sin(a)*2*k],r:[bx+(10+Math.cos(a+1)*3)*k*m,by+7*k+Math.sin(a+1)*2*k]};};o.lean=3;
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);ctx.fillStyle="#b5462f";ctx.fillRect(h.r[0]-4*k,h.r[1]-1.5*k,8*k,3*k);ctx.fillStyle="#f0e0a0";ctx.fillRect(h.r[0]-4*k,h.r[1]+1.5*k,8*k,1.5*k);};}
  else if(act&&ty==="fix"){o.hands=function(bx,by,k,m){var a=Math.sin(T*14);return {l:[bx+8*k*m,by+6*k],r:[bx+12*k*m,by-2*k+a*6*k]};};
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);var a=Math.sin(T*14);limb(h.r,[h.r[0]+8*k*m,h.r[1]+3*k+a*2*k],"#9aa3ab",2.6*k);ctx.strokeStyle="#9aa3ab";ctx.lineWidth=2*k;ctx.beginPath();ctx.arc(h.r[0]+9*k*m,h.r[1]+3*k+a*2*k,2.5*k,0,5);ctx.stroke();
      if(Math.random()<0.2)part({k:"spark",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.5,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.5,h:1.0,vx:(Math.random()-0.5)*2,vy:(Math.random()-0.5)*2,vh:1.5,t:0,life:0.4,c:"#ffe27a"});};}
  else if(act&&ty==="eat"){o.mouth=(Math.floor(T*6)%2)?"open":"";o.hands=function(bx,by,k,m){return {l:[bx-12*k,by+8*k],r:[bx+5*k*m,by-2*k+Math.sin(T*6)*1.5*k]};};
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);ctx.fillStyle="#d33";ctx.fillRect(h.r[0]-3*k,h.r[1]-1*k,6*k,7*k);ctx.fillStyle="#ddd";ctx.fillRect(h.r[0]-3*k,h.r[1]-2*k,6*k,1.5*k);};}
  else if(act&&ty==="puke"){var pk=Math.min(1,tt/0.5);o.lean=7*pk;o.mouth="open";o.eyesClosed=true;o.hands=function(bx,by,k,m){return {l:[bx-10*k,by+14*k],r:[bx+10*k,by+14*k]};};
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);if(tt>0.3&&tt<2.2){var ex=bx+3*k*m,ey=by+2.5*k,D=S.DIRS[p.dir],tgt=P(p.x+D[0]*1.3,p.y+D[1]*1.3,0),wob=Math.sin(T*30)*2*k;
      ctx.strokeStyle="rgba(170,190,60,0.95)";ctx.lineWidth=Math.max(3,9*k);ctx.lineCap="round";ctx.beginPath();ctx.moveTo(ex,ey);ctx.quadraticCurveTo((ex+tgt[0])/2+wob,ey-6*k,tgt[0],tgt[1]);ctx.stroke();ctx.strokeStyle="rgba(220,200,80,0.9)";ctx.lineWidth=Math.max(1.5,4*k);ctx.stroke();ctx.lineCap="butt";
      if(Math.random()<0.6)part({k:"chunk",x:p.x+D[0]*1.3,y:p.y+D[1]*1.3,h:0.1,vx:(Math.random()-0.5)*2.5,vy:(Math.random()-0.5)*2.5,vh:1+Math.random()*1.5,t:0,life:0.6});}};}
  else if(act&&ty==="doze"){o.sit=true;o.eyesClosed=true;o.hands=function(bx,by,k,m){return {l:[bx-12*k,by+14*k],r:[bx+12*k,by+14*k]};};if(Math.random()<0.03)part({k:"z",x:p.x,y:p.y,h:1.2,vh:0.5,t:0,life:2});}
  else if(act&&(ty==="water")){o.hands=function(bx,by,k,m){return {l:[bx+8*k*m,by+2*k],r:[bx+12*k*m,by+4*k]};};o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);ctx.fillStyle="#4a8fd0";ctx.fillRect(h.r[0]-3*k,h.r[1]-3*k,8*k,7*k);limb([h.r[0]+5*k*m,h.r[1]],[h.r[0]+12*k*m,h.r[1]+4*k],"#4a8fd0",2*k);if(Math.random()<0.4)part({k:"drop",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.6,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.6,h:0.8,vx:0,vy:0,vh:-0.5,t:0,life:0.4});};}
  else if(act&&(ty==="rinse"||ty==="washRaw")){o.hands=function(bx,by,k,m){var a=Math.sin(T*12)*2*k;return {l:[bx+6*k*m+a,by+6*k],r:[bx+11*k*m-a,by+6*k]};};if(Math.random()<0.3)part({k:"drop",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.5,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.5,h:0.9,vx:(Math.random()-0.5),vy:(Math.random()-0.5),vh:1,t:0,life:0.4});}
  else if(act&&ty==="tune"){o.hands=function(bx,by,k,m){return {l:[bx-14*k,by+9*k],r:[bx+12*k*m,by+5*k+Math.sin(T*8)*k]};};}
  if(!o.hands&&held.length&&!sackOn){o.hands=function(bx,by,k,m){return {l:[bx-5*k+3*k*m,by+4*k],r:[bx+5*k+3*k*m,by+4*k]};};
    o.front=function(bx,by,k,m,h){frontExtra(bx,by,k,m,h);var q=held[0],c=P(p.x,p.y,0);ctx.save();var hp=[(h.l[0]+h.r[0])/2,(h.l[1]+h.r[1])/2-3*k];
      /* draw the held potato at his hands (screen space) */
      ctx.translate(hp[0],hp[1]);ctx.beginPath();ctx.ellipse(0,0,6.5*k,4.8*k,0.2,0,6.28);if(q.k===0){ctx.fillStyle="#9a6a3a";}else{ctx.fillStyle=q.d>0.55?"#cdb46a":q.d>0.15?"#e6cf80":"#f7e39a";}ctx.fill();ctx.strokeStyle="rgba(60,30,10,0.6)";ctx.lineWidth=Math.max(0.5,0.7*k);ctx.stroke();
      if(q.k===1&&q.d>0.15){ctx.fillStyle="rgba(107,74,42,"+(q.d*0.8)+")";ctx.beginPath();ctx.ellipse(-2*k,1*k,3*k,2*k,0.4,0,6.28);ctx.fill();}ctx.restore();};}
  if(!o.front)o.front=frontExtra;
  /* back-facing: draw back items after so they are in front */
  drawPapaBody(pt,1,o);
  if(p.lazy&&Math.random()<0.02)part({k:"txt",x:p.x,y:p.y,h:1.6,t:0,life:1.2,s:"…",c:"#ddd"});}
function drawPapaLying(sim,bed){var p=sim.s.papa,f=S.fp(bed),c=P(f.x+f.w/2,f.y+0.75,0.6),k=Z*PS;ctx.save();ctx.translate(c[0],c[1]);ctx.rotate(-0.45);
  blob(0,0,13*k,11*k);var g=ctx.createRadialGradient(-4*k,-4*k,1,0,0,16*k);g.addColorStop(0,"#e9c48e");g.addColorStop(0.6,"#b98348");g.addColorStop(1,"#6e4522");ctx.fillStyle=g;ctx.fill();ctx.strokeStyle="rgba(50,28,12,0.8)";ctx.lineWidth=Math.max(0.8,k);ctx.stroke();
  limb([-5*k,-3*k],[-1*k,-3*k],"#2a1a0e",1.2*k);limb([3*k,-3*k],[7*k,-3*k],"#2a1a0e",1.2*k);ctx.fillStyle="#3b2414";ctx.fillRect(-2*k,1*k,8*k,2*k);ctx.restore();
  var br=Math.sin(T*2)*0.03;box(f.x+0.08,f.y+1.0,f.w-0.16,f.h-1.08,0.57,0.12+br,"#3a6fb0",{top:"#4a80c4"});}
function drawPapaSitting(sim,tv){var p=sim.s.papa,pt=P(p.x,p.y,0.45);drawPapaBody(pt,1,{face:false,mir:false,tt:T,sit:true,eyesClosed:false});}
function drawSackFloor(sim){var p=sim.s.papa;if(!sim.s.equip.carrySack||p.sack.on)return;var c=P(p.sack.x,p.sack.y,0);shadow(p.sack.x,p.sack.y,0.3);sackDraw(c[0],c[1]-10*Z,Z,p.hold.length);
  var tw=Math.sin(T*2)*0.5+0.5;txt("SACK",c[0],c[1]-26*Z,7,"rgba(255,233,168,"+(0.5+0.5*tw)+")");}
function drawCat(sim){if(!sim.placed("catBed"))return;var c=sim.s.cat,pt=P(c.x,c.y,0),k=Z,m=(c.fx-c.fy)<0?-1:1,walk=c.st==="walk",nap=c.st==="nap";
  ctx.fillStyle="rgba(0,0,0,0.2)";ctx.beginPath();ctx.ellipse(pt[0],pt[1],8*k,3*k,0,0,6.28);ctx.fill();
  var by=pt[1]-(nap?4:7)*k-(walk?Math.abs(Math.sin(T*10))*1.2*k:0);var col="#e08a3a";
  if(!nap){var lg=walk?Math.sin(T*10)*2*k:0;limb([pt[0]-4*k,by+2*k],[pt[0]-4*k+lg,pt[1]],col,2*k);limb([pt[0]+4*k,by+2*k],[pt[0]+4*k-lg,pt[1]],col,2*k);}
  ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(pt[0],by,8*k,nap?4*k:4.5*k,0,0,6.28);ctx.fill();
  var tail=Math.sin(T*3)*3*k;limb([pt[0]-7*k*m,by],[pt[0]-12*k*m,by-6*k+tail],col,2*k);
  var hx=pt[0]+7*k*m,hy=by-(nap?1:4)*k;ctx.beginPath();ctx.arc(hx,hy,4*k,0,6.28);ctx.fill();ctx.beginPath();ctx.moveTo(hx-3*k,hy-2*k);ctx.lineTo(hx-2*k,hy-6*k);ctx.lineTo(hx,hy-3*k);ctx.moveTo(hx+3*k,hy-2*k);ctx.lineTo(hx+2*k,hy-6*k);ctx.lineTo(hx,hy-3*k);ctx.fill();
  ctx.fillStyle="#222";if(nap){limb([hx-2.5*k,hy],[hx-0.5*k,hy],"#222",0.8*k);limb([hx+0.5*k,hy],[hx+2.5*k,hy],"#222",0.8*k);if(Math.random()<0.02)part({k:"z",x:c.x,y:c.y,h:0.5,vh:0.3,t:0,life:1.6});}else{ctx.fillRect(hx-2*k,hy-1*k,1.2*k,1.2*k);ctx.fillRect(hx+1*k,hy-1*k,1.2*k,1.2*k);}}
/* ---------- floor mess: peels + HUGE puke ---------- */
function drawPeels(sim,V){var a=sim.s.peels,cols=["#c58c47","#a8743a","#d9a35f"],k,i,q,p;if(!a.length)return;ctx.lineCap="round";
  /* batched: one stroke per peel colour + one for the highlights (was 2 strokes per peel) */
  var vis=[];for(i=0;i<a.length;i++){q=a[i];if(q.x<V.x0-1||q.x>V.x1+1||q.y<V.y0-1||q.y>V.y1+1)continue;vis.push([q,P(q.x,q.y,0.01)]);}
  ctx.lineWidth=Math.max(1,2*Z);for(k=0;k<3;k++){ctx.beginPath();var any=false;for(i=0;i<vis.length;i++){q=vis[i][0];if(q.c!==k)continue;p=vis[i][1];any=true;ctx.moveTo(p[0]+Math.cos(q.a)*3*Z,p[1]+Math.sin(q.a)*3*Z);ctx.arc(p[0],p[1],3*Z,q.a,q.a+2.6);}if(any){ctx.strokeStyle=cols[k];ctx.stroke();}}
  ctx.strokeStyle="rgba(255,240,190,0.5)";ctx.lineWidth=Math.max(0.5,0.8*Z);ctx.beginPath();for(i=0;i<vis.length;i++){q=vis[i][0];p=vis[i][1];ctx.moveTo(p[0]+Math.cos(q.a+0.4)*2.4*Z,p[1]+Math.sin(q.a+0.4)*2.4*Z);ctx.arc(p[0],p[1],2.4*Z,q.a+0.4,q.a+2.0);}ctx.stroke();ctx.lineCap="butt";}
function drawPuke(sim){sim.s.puke.forEach(function(q){var r=q.r*Math.max(0.25,q.a),c=P(q.x,q.y,0.012),n=14,i,sd=q.seed;
  function rr(i){var v=Math.sin(sd*12.9898+i*78.233)*43758.5453;return v-Math.floor(v);}
  ctx.beginPath();for(i=0;i<=n;i++){var a=i/n*6.2832,rad=r*(0.72+0.38*rr(i%n))+0.04*Math.sin(T*2+i),px=c[0]+Math.cos(a)*rad*45*Z,py=c[1]+Math.sin(a)*rad*22.5*Z;if(!i)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.closePath();
  var g=ctx.createRadialGradient(c[0]-8*Z,c[1]-4*Z,2,c[0],c[1],r*45*Z);g.addColorStop(0,"#d9d36a");g.addColorStop(0.6,"#a9b23f");g.addColorStop(1,"#7d8a2a");ctx.fillStyle=g;ctx.globalAlpha=0.6+0.4*q.a;ctx.fill();ctx.strokeStyle="rgba(70,80,20,0.7)";ctx.lineWidth=Math.max(1,1.5*Z);ctx.stroke();
  /* splatter drops around */
  for(i=0;i<9;i++){var a2=rr(i+20)*6.28,d2=r*(1.05+rr(i+40)*0.5);ctx.fillStyle="#a9b23f";ctx.beginPath();ctx.ellipse(c[0]+Math.cos(a2)*d2*45*Z,c[1]+Math.sin(a2)*d2*22.5*Z,(2+rr(i+60)*3)*Z,(1+rr(i+60)*1.5)*Z,0,0,6.28);ctx.fill();}
  /* chunks */
  for(i=0;i<16;i++){var a3=rr(i+80)*6.28,d3=r*rr(i+100)*0.8;ctx.fillStyle=i%3?"#e0b84a":"#8a6a2a";ctx.fillRect(c[0]+Math.cos(a3)*d3*45*Z,c[1]+Math.sin(a3)*d3*22.5*Z,(2+rr(i+120)*2.5)*Z,(1.5+rr(i+140)*2)*Z);}
  /* gloss + popping bubbles + stink lines */
  ctx.fillStyle="rgba(255,255,220,0.35)";ctx.beginPath();ctx.ellipse(c[0]-r*12*Z,c[1]-r*6*Z,r*12*Z,r*4*Z,-0.2,0,6.28);ctx.fill();
  for(i=0;i<4;i++){var ph=(T*0.8+i*0.25)%1,bp=[c[0]+(rr(i+160)-0.5)*r*60*Z,c[1]+(rr(i+180)-0.5)*r*25*Z];ctx.strokeStyle="rgba(240,240,170,"+(1-ph)+")";ctx.lineWidth=Math.max(0.5,0.8*Z);ctx.beginPath();ctx.arc(bp[0],bp[1],(1+ph*3.5)*Z,0,6.28);ctx.stroke();}
  for(i=0;i<3;i++){var sp=(T*0.5+i/3)%1,sx2=c[0]+(i-1)*r*18*Z,sy2=c[1]-sp*40*Z;ctx.strokeStyle="rgba(170,200,90,"+(0.6*(1-sp))+")";ctx.lineWidth=Math.max(1,1.5*Z);ctx.beginPath();ctx.moveTo(sx2,sy2);ctx.quadraticCurveTo(sx2+6*Z,sy2-6*Z,sx2,sy2-12*Z);ctx.stroke();}
  ctx.globalAlpha=1;});}
/* ---------- the whole scene ---------- */
function objDepth(o){var f=S.fp(o);return f.x+f.w/2+f.y+f.h/2;}
function render(c,sim,view){
  var dpr=view.dpr||1;setView(c,view.w,view.h,view.z,view.cx,view.cy,view.t);D.dpr=dpr;D.editView=!!view.edit;
  var s=sim.s,V=visTiles(),list=[];
  var PF=D.prof?[performance.now()]:null,pm=function(){if(PF){if(D.prof.flush)ctx.getImageData(0,0,1,1);PF.push(performance.now());}};
  bgLayer(sim,V);pm();drawWallAnim();pm();
  s.objs.forEach(function(o){if(o.wall)drawWallItem(sim,o);});pm();
  drawWater(sim,V);pm();
  s.objs.forEach(function(o){var cat=(S.itemDef(o.id)||{}).cat;if(cat==="rug")drawRug(o);});
  if(view.edit||view.showPower)drawPowerRings(sim,view);
  s.objs.forEach(function(o){if(o.id==="belt")drawBelt(sim,o,V);});
  drawPeels(sim,V);drawPuke(sim);pm();
  /* depth-sorted things */
  list.push({d:3.5+21-0.5,f:function(){drawPile(sim);}});
  list.push({d:7+0.6,f:function(){drawChute(sim);}});
  list.push({d:13+15,f:function(){if(view.edit)ctx.globalAlpha=0.45;scanner(12,14,"k",sim);ctx.globalAlpha=1;}});
  list.push({d:16+15,f:function(){if(view.edit)ctx.globalAlpha=0.45;scanner(15,14,"w",sim);ctx.globalAlpha=1;}});
  lowWalls(sim,list);
  var p=s.papa,pt=p.task;
  s.objs.forEach(function(o){if(o.wall||o.id==="belt")return;var cat=(S.itemDef(o.id)||{}).cat;if(cat==="rug")return;
    var fp0=S.fp(o);list.push({d:objDepth(o),o:o,wx:fp0?fp0.x+fp0.w/2:o.x+0.5,wy:fp0?fp0.y+fp0.h/2:o.y+0.5,wr:fp0?Math.max(fp0.w,fp0.h):2,f:function(){var see=view.edit&&heightOf(o.id)>0.8&&view.sel!==o.u;if(see)ctx.globalAlpha=0.45;
      switch(o.id){case "table":drawTable(sim,o);break;case "cooler":drawCooler(sim,o,false);break;case "bed":drawBed(sim,o,false);if(pt&&pt.type==="nap"&&pt.lying&&pt.target===o)drawPapaLying(sim,o);break;
      case "basicCot":drawBed(sim,o,true);if(pt&&pt.type==="nap"&&pt.lying&&pt.target===o)drawPapaLying(sim,o);break;
      case "tub":drawTub(sim,o);break;case "hopper":drawHopper(sim,o);break;case "autoPeeler":drawPeeler(sim,o);break;case "washer":drawWasher(sim,o);break;case "generator":drawGenerator(sim,o);break;
      case "tvArmchair":drawFloorDecor(sim,o);if(pt&&pt.type==="watch"&&pt.sit&&pt.target===o)drawPapaSitting(sim,o);break;
      default:drawFloorDecor(sim,o);}
      ctx.globalAlpha=1;if(view.sel===o.u)selBox(o);}});});
  s.pots.forEach(function(q){if(q.m==="belt"||q.m==="pool"||q.m==="canal"||q.m==="scan")list.push({d:q.x+q.y+0.05,wx:q.x,wy:q.y,f:function(){
    if(q.m==="scan"){if(q.t<0.5)potato(12.0+q.t*1.5,15,0.55,q,0);return;}
    var h=q.m==="belt"?0.2:0.05+Math.sin(T*3+q.u)*0.02;if(q.m!=="belt"){ell(q.x,q.y,0.04,7,3,"rgba(255,255,255,0.25)");}potato(q.x,q.y,h,q,q.m==="belt"?0:Math.sin(T+q.u)*0.4);}});});
  list.push({d:p.x+p.y+0.01,f:function(){drawPapa(sim);}});
  if(s.equip.carrySack&&!p.sack.on)list.push({d:p.sack.x+p.sack.y,f:function(){drawSackFloor(sim);}});
  if(sim.placed("catBed"))list.push({d:s.cat.x+s.cat.y+0.02,f:function(){drawCat(sim);}});
  list.sort(function(a,b){return a.d-b.d;});
  pm();var cm=60*Z+40;list=list.filter(function(e){if(e.wx==null)return true;var r=(e.wr||1)*36*Z+cm,X=sx(e.wx,e.wy),Y=sy(e.wx,e.wy,0);return X>-r&&X<CW+r&&Y>-r-150*Z&&Y<CH+r;});
  if(PF&&D.prof.each){for(var i=0;i<list.length;i++){var t0=performance.now();list[i].f();if(D.prof.flush)ctx.getImageData(0,0,1,1);var k=list[i].o?list[i].o.id:(list[i].f.toString().slice(12,40));D.prof.each[k]=(D.prof.each[k]||0)+performance.now()-t0;}}else for(var i=0;i<list.length;i++)list[i].f();pm();
  drawBasin(sim);
  /* see-through Papa: when a huge machine hides him you still see where he is */
  var pd=p.x+p.y,psx=sx(p.x,p.y),psy=sy(p.x,p.y,0),hid=list.some(function(e){if(e.d<=pd+0.01||e.wx==null)return false;
    var hh=e.o?heightOf(e.o.id):1.3;if(hh<0.5)return false;var X=sx(e.wx,e.wy),Y=sy(e.wx,e.wy,0),r=(e.wr||1)*40*Z+30*Z;return Math.abs(X-psx)<r&&psy<Y+20*Z&&psy>Y-(hh*ZP+60)*Z;});
  var pt2=p.task;if(hid&&!(pt2&&pt2.stage==="act"&&((pt2.type==="nap"&&pt2.lying)||(pt2.type==="watch"&&pt2.sit)))){NOPART=true;ctx.globalAlpha=0.3;drawPapa(sim);ctx.globalAlpha=1;NOPART=false;}
  drawParts();
  if(view.edit)drawEditOverlay(sim,view);
  if(view.marks)view.marks.forEach(function(m){var a=P(m.x,m.y,m.h||0);ctx.strokeStyle=m.c||"#fff";ctx.lineWidth=2;ctx.beginPath();ctx.arc(a[0],a[1],m.r||10,0,6.28);ctx.stroke();});
  pm();if(PF){var a=D.prof.acc||(D.prof.acc=[]);for(var j=1;j<PF.length;j++)a[j-1]=(a[j-1]||0)+PF[j]-PF[j-1];D.prof.n=(D.prof.n||0)+1;}
}
function selBox(o){var f=S.fp(o);ctx.setLineDash([4,3]);poly([P(f.x,f.y,0.02),P(f.x+f.w,f.y,0.02),P(f.x+f.w,f.y+f.h,0.02),P(f.x,f.y+f.h,0.02)],null,"#ffe27a",2);ctx.setLineDash([]);}
function drawPowerRings(sim,view){if(!sim.power)sim.calcPower();sim.power.src.forEach(function(s){isoCirc(s.x,s.y,0.02,s.range,"rgba(80,170,255,0.07)","rgba(110,190,255,0.55)",1.5);var a=P(s.x,s.y,0.05);txt((s.id==="outlet"?"OUTLET ":"GEN ")+s.used+"/"+s.cap,a[0],a[1]+10*Z,8,"#9fd0ff");});}
function drawEditOverlay(sim,view){var s=sim.s;
  /* arrows on every machine so the flow is clear */
  s.objs.forEach(function(o){if(S.isMach(o.id)||o.id==="tub"){var f=sim.frontOut(o);arrowFloor(f[0],f[1],o.r,"rgba(120,255,160,0.95)");}});
  var g=view.ghost;if(!g)return;var it=S.itemDef(g.id);if(!it)return;
  if(it.cat==="wall"){var w=sim.wallSpot(g.id,g.x+0.5,g.y+0.5);if(w){var n=it.w||1,u=w.wall==="N"?w.x:w.y;wallQuad(w.wall,u,u+n,0.9,2.2,g.ok?"rgba(120,255,160,0.35)":"rgba(255,90,80,0.4)","#fff");}return;}
  var f=S.fp({id:g.id,x:g.x,y:g.y,r:g.r});poly([P(f.x,f.y,0.03),P(f.x+f.w,f.y,0.03),P(f.x+f.w,f.y+f.h,0.03),P(f.x,f.y+f.h,0.03)],g.ok?"rgba(120,255,160,0.35)":"rgba(255,90,80,0.4)",g.ok?"#7dff9a":"#ff6b5e",2);
  if(g.id==="belt"||S.isMach(g.id)){var fo=g.id==="belt"?[g.x+S.DIRS[g.r][0],g.y+S.DIRS[g.r][1]]:sim.frontOut({id:g.id,x:g.x,y:g.y,r:g.r});if(g.id==="belt")arrowFloor(g.x,g.y,g.r,"#ffe27a");else arrowFloor(fo[0],fo[1],g.r,"#ffe27a");}
  if(g.id==="generator"){isoCirc(f.x+1,f.y+1,0.02,7+1.5*sim.up("gen"),null,"rgba(110,190,255,0.8)",1.5);}
  ctx.globalAlpha=0.55;var tmp={u:-1,id:g.id,x:g.x,y:g.y,r:g.r,on:1,q:[],tray:[],pw:1,t:0};try{if(g.id==="belt")drawBelt(sim,tmp,null);else if(S.isMach(g.id)||g.id==="generator"){({hopper:drawHopper,autoPeeler:drawPeeler,washer:drawWasher,generator:drawGenerator})[g.id](sim,tmp);}else if(it.cat==="rug")drawRug(tmp);else if(g.id==="table")drawTable(sim,tmp);else if(g.id==="bed")drawBed(sim,tmp,false);else if(g.id==="tub")drawTub(sim,tmp);else if(g.id==="cooler")drawCooler(sim,tmp,false);else drawFloorDecor(sim,tmp);}catch(e){}ctx.globalAlpha=1;}
/* screen bounding boxes for picking */
function heightOf(id){return {hopper:2.5,autoPeeler:2.2,washer:1.9,generator:1.4,table:1.0,cooler:1.1,bed:1.0,tub:0.9,belt:0.25,lamp:1.7,bookshelf:1.9,fan:1.3,tvArmchair:1.4,shelf:1.5,plant:1.0,statue:1.5,basicCot:0.5}[id]||0.9;}
function pick(sim,px,py){var best=null,bd=-1e9;sim.s.objs.forEach(function(o){var it=S.itemDef(o.id);if(!it)return;
  if(o.wall){var n=it.w||1,u=o.wall==="N"?o.x:o.y,a=wallPt(o.wall,u,0.9),b=wallPt(o.wall,u+n,2.2),x0=Math.min(a[0],b[0]),x1=Math.max(a[0],b[0]),y0=Math.min(a[1],b[1]),y1=Math.max(a[1],b[1]);if(px>=x0-4&&px<=x1+4&&py>=y0-4&&py<=y1+4){var d=-5+(o.wall==="N"?o.x:o.y)*0.01;if(d>bd){bd=d;best=o;}}return;}
  var f=S.fp(o),h=it.cat==="rug"?0.02:heightOf(o.id),pts=[P(f.x,f.y,0),P(f.x+f.w,f.y,0),P(f.x+f.w,f.y+f.h,0),P(f.x,f.y+f.h,0),P(f.x,f.y,h),P(f.x+f.w,f.y,h),P(f.x+f.w,f.y+f.h,h),P(f.x,f.y+f.h,h)];
  var x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;pts.forEach(function(q){x0=Math.min(x0,q[0]);x1=Math.max(x1,q[0]);y0=Math.min(y0,q[1]);y1=Math.max(y1,q[1]);});
  if(px>=x0&&px<=x1&&py>=y0&&py<=y1){/* inside the hexagon outline? */var w=toWorld(px,py);var inFoot=w.x>=f.x-0.1&&w.x<=f.x+f.w+0.1&&w.y>=f.y-0.1&&w.y<=f.y+f.h+0.1;var d=objDepth(o)+(inFoot?50:0)-(it.cat==="rug"?100:0);if(d>bd){bd=d;best=o;}}});
  return best;}
D.render=render;D.pick=pick;D.toWorld=function(px,py){return toWorld(px,py);};D.project=function(x,y,h){return P(x,y,h);};D.heightOf=heightOf;D.setView=setView;
return D;
})();
