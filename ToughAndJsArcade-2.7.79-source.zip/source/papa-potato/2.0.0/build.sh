#!/bin/bash
# Papa Potato 2.0.0 build: one self-contained HTML file.
set -e
cd "$(dirname "$0")"
mkdir -p release
OUT=release/papa-potato-2.0.0.html
{
  cat src/head.html
  echo '<script>'
  cat src/sim.js
  cat src/radio.js
  cat src/draw.js
  cat src/ui/game.js
  echo '</script>'
  echo '</body></html>'
} > "$OUT"
# syntax check of the whole script + WebView 83 guard (no ?. ?? roundRect)
node -e '
const fs=require("fs");const h=fs.readFileSync(process.argv[1],"utf8");const js=h.split("<script>")[1].split("</script>")[0];
new Function(js);
const bad=[/\?\.[a-zA-Z_$\[(]/,/\?\?/,/roundRect/];bad.forEach(r=>{const m=js.match(r);if(m){console.error("WebView83 guard hit: "+r+" near "+js.substr(Math.max(0,m.index-60),120));process.exit(1);}});
console.log("ok",h.length,"bytes");' "$OUT"
sha256sum "$OUT"
