/* injected into the page: builds test states through the real sim API only */
window.SC={
 rich:function(){var s=PP2T.sim(),S=s.s;S.coins=99999;S.level=5;S.food=6;["roomKey","carrySack","broomDustpan","betterPeeler"].forEach(function(i){s.buyItem(i);});return s;},
 factory:function(){var s=SC.rich(),out=[],L=function(r,m){if(!r.ok)out.push(m+":"+r.why);return r;};
  s.buyItem("belt",20);s.buyItem("belt",20);s.buyItem("hopper");s.buyItem("autoPeeler");s.buyItem("washer");s.buyItem("generator");s.buyItem("generator");s.buyUp("gen");s.buyUp("gen");
  L(s.place("hopper",6,20,3),"hopper");for(var y=19;y>=15;y--)L(s.place("belt",6,y,3),"b6"+y);
  L(s.place("autoPeeler",6,12,3),"ap");L(s.place("belt",6,11,0),"b611");L(s.place("belt",7,11,0),"b711");L(s.place("belt",8,11,3),"b811");L(s.place("belt",8,10,3),"b810");
  L(s.place("washer",8,7,3),"washer");for(var y2=6;y2>=2;y2--)L(s.place("belt",8,y2,3),"b8"+y2);L(s.place("belt",8,1,2),"b81");L(s.place("belt",7,1,3),"b71");
  L(s.place("generator",10,13,0),"gen1");L(s.place("generator",10,2,0),"gen2");return out;},
 decor:function(){var s=SC.rich(),out=[];s.S=PP2T.S;PP2T.S.ITEMS.forEach(function(it){if(["floor","rug","wall","basin","theme"].indexOf(it.cat)>=0)s.buyItem(it.id);});return out;}
};
SC.auto=function(id,ox,oy,r){var s=PP2T.sim(),it=PP2T.S.itemDef(id);if(it.cat==="wall")return s.place(id,ox||0,oy||0,0);
  var best=null;for(var d=0;d<30&&!best;d++)for(var y=oy-d;y<=oy+d&&!best;y++)for(var x=ox-d;x<=ox+d&&!best;x++){if(Math.max(Math.abs(x-ox),Math.abs(y-oy))!==d)continue;if(s.canPlace(id,x,y,r||0).ok)best=[x,y];}
  if(!best)return {ok:false,why:"nowhere"};return s.place(id,best[0],best[1],r||0);};
SC.decorAll=function(){var s=SC.rich(),out=[],S=PP2T.S;S.ITEMS.forEach(function(it){if(["floor","rug","wall","basin","theme"].indexOf(it.cat)>=0)s.buyItem(it.id);});
  var spots={sink:[3,9],smallCooler:[12,7],basicCot:[12,18],kitchenMat:[5,11],compost:[1,15],fruitBowl:[11,9],plant:[1,3],lamp:[3,6],runner:[8,14],shelf:[9,1],sackPile:[1,17],cookbook:[9,9],mopBucket:[16,2],radio:[11,11],rug:[2,12],fan:[12,2],bookshelf:[2,1],catBed:[4,16],tvArmchair:[8,20],roundRug:[21,8],aquarium:[12,12],statue:[22,4]};
  var wx={clock:[2,0],coatHook:[3,0],calendar:[4,0],spiceRack:[5,0],window:[9,0],poster:[0,4],potsPans:[0,6],photos:[0,10],stringLights:[0,12],neonSign:[0,15],trophyShelf:[0,18],towelRack:[17,0],soap:[19,0]};
  S.ITEMS.forEach(function(it){var n=s.s.inv[it.id]|0;if(!n)return;var r;if(it.cat==="wall"){var w=wx[it.id]||[1,0];r=s.place(it.id,w[0]+0.5,w[1]+0.5,0);}else{var sp=spots[it.id]||[6,6];r=SC.auto(it.id,sp[0],sp[1],0);}if(!r.ok)out.push(it.id+":"+r.why);});
  ["duck","toyBoat","bubbles"].forEach(function(b){s.setBasin(b,true);});s.setTheme("wall",1);s.setTheme("floor",3);
  ["tv","lamp","radio"].forEach(function(c){s.setBox(c,1);});return out;};
