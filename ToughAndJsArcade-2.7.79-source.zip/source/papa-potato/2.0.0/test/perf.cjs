// A03s perf: 360x800@2, CDP CPU throttle 6x and 4x, factory + full-decor scenes, real rAF loop. Desktop Chrome emulation, NOT a phone.
const L=require("./lib.cjs");const fs=require("fs");
(async()=>{const b=await L.browser();const out=[];
for(const mode of ["adaptive","fixed2x"])for(const scene of ["factory","decorAll"])for(const rate of [6,4]){const {p,errs}=await L.open(b,[360,800],{dpr:2});
 await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});
 await p.evaluate((sc,m)=>{SC[sc]();PP2T.setCam(7,12,0.72);if(m==="fixed2x")PP2T.RS.clock=-1e9;},scene,mode);
 const c=await L.cdp(p);await c.send("Emulation.setCPUThrottlingRate",{rate});await L.sleep(9000);
 const r=await p.evaluate(()=>new Promise(res=>{const d=[];let last=performance.now();const t0=last;function f(t){d.push(t-last);last=t;if(t-t0<10000)requestAnimationFrame(f);else{d.sort((a,b)=>a-b);const avg=d.reduce((a,b)=>a+b,0)/d.length;res({frames:d.length,fps:+(1000/avg).toFixed(1),p50:+d[d.length>>1].toFixed(1),p95:+d[Math.floor(d.length*.95)].toFixed(1),max:+d[d.length-1].toFixed(1),objs:PP2T.sim().s.objs.length,renderScale:PP2T.RS.cur,devicePixelRatio:devicePixelRatio,pots:(PP2T.sim().s.pots||[]).length});}}requestAnimationFrame(f);}));
 await c.send("Emulation.setCPUThrottlingRate",{rate:1});r.mode=mode;r.scene=scene;r.throttle=rate+"x";r.errs=errs.length;out.push(r);console.log(JSON.stringify(r));await p.close();}
fs.writeFileSync(__dirname+"/perf-results.json",JSON.stringify({viewport:"360x800@2 (A03s), desktop Chrome + CDP CPU throttle",runs:out},null,1));await b.close();})();
