const L=require("./lib.cjs");const fs=require("fs");
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:2});
await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});
const shots=JSON.parse(fs.existsSync(process.argv[2])?fs.readFileSync(process.argv[2],"utf8"):process.argv[2]||"[]");
await p.evaluate(()=>{__tt.manual=true;__tt.setSeed(5);});
for(const s of shots){ if(s.js) console.log("js:",JSON.stringify(await p.evaluate(s.js))); if(s.step) await p.evaluate(n=>__tt.step(n),s.step);
  if(s.cam) await p.evaluate(c=>PP2T.setCam(c[0],c[1],c[2]),s.cam);
  await L.sleep(s.wait||150); if(s.shot){await p.screenshot({path:"shots/"+s.shot+".png"});console.log("shot",s.shot);} if(s.log) console.log(JSON.stringify(await p.evaluate(s.log)));}
console.log("errs",errs);await b.close();})();
