const L=require("./lib.cjs");
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:2});
await L.sleep(1500);await p.screenshot({path:"shots/smoke-start.png"});
const st=await p.evaluate(()=>__tt.getState());console.log(JSON.stringify(st.papa),st.coins,st.potCount);
await p.evaluate(()=>{__tt.manual=true;__tt.step(60*60);__tt.manual=false;});await L.sleep(400);
await p.screenshot({path:"shots/smoke-60s.png"});
const st2=await p.evaluate(()=>__tt.getState());console.log(JSON.stringify(st2.papa),st2.coins,st2.shipped,st2.peels);
console.log("errs",errs);await b.close();})();
