const PP2=require("./simq.cjs");
function run(name,setup,secs,check){const s=new PP2.Sim(7);const S=s.s;S.coins=99999;S.level=5;setup(s,S);for(let i=0;i<60*secs;i++)s.step(1/60);console.log(name,JSON.stringify(check(s,S)));}
run("scanner",(s,S)=>{s.buyItem("roomKey");s.setBox("deliver",1);},120,(s,S)=>({sh:S.shipped,clean:S.shippedClean,coins:S.coins-99960,pots:S.pots.map(p=>p.m+":"+p.d.toFixed(2)).join(" ")}));
run("carry",(s,S)=>{s.buyItem("roomKey");s.buyItem("carrySack");s.setBox("deliver",2);},150,(s,S)=>({sh:S.shipped,clean:S.shippedClean,trips:S.stats.doorTrips,scrubbed:S.stats.scrubbed,task:S.papa.task&&S.papa.task.type,where:S.papa.where,pots:S.pots.map(p=>p.m+":"+p.d.toFixed(2)).join(" ")}));
run("puke",(s,S)=>{s.setBox("eat",70);S.food=5;S.papa.hunger=68;},20,(s,S)=>({pukes:S.stats.pukes,puke:S.puke.length,h:S.papa.hunger|0}));
run("mop",(s,S)=>{s.setBox("clean",50);s.buyItem("broomDustpan");S.papa.hunger=65;S.food=2;s.order("eat");},40,(s,S)=>({pukes:S.stats.pukes,puke:S.puke.length,task:S.papa.task&&S.papa.task.type,msg:S.msg}));
run("napSack",(s,S)=>{s.buyItem("carrySack");s.setBox("nap",40);S.papa.energy=42;},30,(s,S)=>({sackOn:S.papa.sack.on,sack:[S.papa.sack.x,S.papa.sack.y],downs:S.stats.sackDowns,task:S.papa.task&&S.papa.task.type,lying:!!(S.papa.task&&S.papa.task.lying),e:S.papa.energy|0}));
run("napSack2",(s,S)=>{s.buyItem("carrySack");s.setBox("nap",40);S.papa.energy=42;},60,(s,S)=>({sackOn:S.papa.sack.on,downs:S.stats.sackDowns,task:S.papa.task&&S.papa.task.type,e:S.papa.energy|0,hold:S.papa.hold.length}));
run("sweep",(s,S)=>{s.setBox("clean",10);s.setBox("style",2);},120,(s,S)=>({peels:S.peels.length,swept:S.swept}));
run("jamfix",(s,S)=>{s.buyItem("hopper");s.buyItem("generator");s.buyItem("belt",4);s.place("hopper",6,20,3);s.place("generator",8,20,0);s.place("belt",6,19,3);s.place("belt",6,18,0);s.place("belt",7,18,0);s.objsOf("hopper")[0].jam=1;},20,(s,S)=>({fixed:S.stats.fixed,jam:s.objsOf("hopper")[0].jam,fed:s.objsOf("hopper")[0].fed}));
run("brush",(s,S)=>{s.buyItem("roomKey");const p=s.newPot(1,"pool");p.x=18;p.y=13;p.d=1;for(let i=0;i<5;i++)s.brush(p.x,p.y,0.2);},1,(s,S)=>({brushed:S.stats.brushed,d:S.pots.map(p=>p.d)}));
run("washer",(s,S)=>{s.buyItem("roomKey");s.buyItem("washer");s.buyItem("generator");s.buyItem("belt",6);
  console.log(JSON.stringify(s.place("washer",9,1,0)),JSON.stringify(s.place("generator",9,4,0)));for(let i=0;i<3;i++){const p=s.newPot(1,"belt");p.o=s.place("belt",8-0,1+0,0).o?0:0;}
},1,(s,S)=>({}));
