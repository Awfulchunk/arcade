const vm=require("vm"),fs=require("fs");const ctx={Math,JSON,console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+"/../src/sim.js","utf8")+";this.PP2=PP2;",ctx);
module.exports=ctx.PP2;
