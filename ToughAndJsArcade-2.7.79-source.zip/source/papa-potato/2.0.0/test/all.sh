#!/bin/bash
# final evidence run on release/papa-potato-2.0.0.html
cd /workspace/game/build-potato2/v2/test
EV=/workspace/game/requests/finished-ship/papa-potato-2-test/test-evidence
echo "start $(date)"
timeout 2400 node hard.cjs > $EV/hard.log 2>&1; cp hard-results.json $EV/; echo "hard done $(tail -1 $EV/hard.log)"
timeout 600 node play.cjs > $EV/play.log 2>&1; cp play-results.json $EV/; echo "play done $(tail -1 $EV/play.log)"
timeout 600 node perf.cjs > $EV/perf.log 2>&1; cp perf-results.json $EV/; echo "perf done"
SHOTS=/workspace/game/requests/finished-ship/papa-potato-2-test/screenshots timeout 600 node shots.cjs > $EV/shots.log 2>&1; echo "shots done $(tail -1 $EV/shots.log)"
cd .. && timeout 1200 node /workspace/game/tough-tools/tt.js test release/papa-potato-2.0.0.html --all > $EV/tt.log 2>&1; echo "tt done $(grep '^TEST' $EV/tt.log)"
rm -rf $EV/tt && cp -r /workspace/game/tough-tools/out/papa-potato-2.0.0 $EV/tt
echo "end $(date)"
