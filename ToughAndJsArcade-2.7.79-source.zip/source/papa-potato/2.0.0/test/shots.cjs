const L=require("./lib.cjs");const fs=require("fs");
const OUT=process.env.SHOTS||__dirname+"/shots";fs.mkdirSync(OUT,{recursive:true});
async function fresh(b,seed){const {p,errs}=await L.open(b,[360,800],{dpr:2});await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});await p.evaluate(s=>{__tt.manual=true;__tt.setSeed(s);},seed||5);return {p,errs};}
async function until(p,cond,max){for(let i=0;i<max;i++){if(await p.evaluate(cond))return i;await p.evaluate(()=>__tt.step(10));}return -1;}
async function shot(p,name,cam,wait){if(cam)await p.evaluate(c=>PP2T.setCam(c[0],c[1],c[2]),cam);await p.evaluate(()=>{var t=document.getElementById("toast");t.className="off";});
  await p.evaluate(()=>{__tt.manual=false;});await L.sleep(wait||700);await p.evaluate(()=>{__tt.manual=true;});await p.screenshot({path:OUT+"/"+name+".png"});console.log("shot",name);}
(async()=>{const b=await L.browser();const E=[];
 // 1 kitchen + 2 wash room iso views (decorated)
 let {p,errs}=await fresh(b,5);await p.evaluate(()=>SC.decorAll());await p.evaluate(()=>{PP2T.sim().setBox("deliver",1);});await p.evaluate(()=>__tt.step(3000));
 await shot(p,"01-kitchen-iso",[6.5,11,0.42]);await shot(p,"02-wash-room-iso",[20.5,7.5,0.48]);E.push(...errs);await p.close();
 // 3 conveyors + machines working
 ({p,errs}=await fresh(b,7));await p.evaluate(()=>SC.factory());await p.evaluate(()=>__tt.step(2400));await p.evaluate(()=>{PP2T.sim().s.objs.forEach(o=>{o.jam=0;});});
 await shot(p,"03-belts-machines",[7.5,13,0.62],900);
 // 4 a jam (FIX JAMS off so it stays jammed)
 await p.evaluate(()=>{var s=PP2T.sim();s.setBox("fix",0);var ap=s.objsOf("autoPeeler")[0];ap.jam=1;s.say("JAM! The auto peeler is stuck.");});await p.evaluate(()=>__tt.step(120));
 await shot(p,"04-jam",[7,13,0.9],900);
 await p.evaluate(()=>{var s=PP2T.sim();s.sendFix(s.objsOf("autoPeeler")[0].u);});const fx=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="fix"&&t.stage==="act";},300);
 await shot(p,"05-papa-fixing-jam",[7,13,1.0],500);console.log("fix reached",fx);E.push(...errs);await p.close();
 // 6 carrying through the door
 ({p,errs}=await fresh(b,9));await p.evaluate(()=>{var s=SC.rich();s.setBox("deliver",2);s.setBox("scrub",1);});
 const dr=await until(p,()=>{var q=PP2T.sim().s.papa;return q.hold.length>=2&&q.x>13.7&&q.x<15.3&&q.y>2.6&&q.y<5.4;},2000);console.log("door at",dr);
 await shot(p,"06-papa-carries-through-door",[14.5,4.5,1.15],250);
 const sc=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="scrub"&&t.stage==="act";},2000);console.log("scrub at",sc);
 await shot(p,"07-papa-scrubbing-tub",[19.5,5,1.25],500);
 // 8 the player scrubbing in the pool (real touch swipes)
 await p.evaluate(()=>{__tt.flood(8);PP2T.setCam(18.5,13.5,1.2);});
 await p.evaluate(()=>{__tt.manual=false;});
 for(let i=0;i<12;i++){const a=await p.evaluate(()=>{var o=null;PP2T.sim().s.pots.forEach(q=>{if(!o&&q.k===1&&q.d>0.15&&(q.m==="pool"||q.m==="canal"))o=PP2T.project(q.x,q.y,0.05);});return o;});if(!a)break;await L.touchDrag(p,a[0]-20,a[1]-4,a[0]+20,a[1]+4,5);}
 const br=await p.evaluate(()=>PP2T.sim().s.stats.brushed);console.log("brushed",br);
 await p.screenshot({path:OUT+"/08-player-scrubbing-pool.png"});console.log("shot 08");E.push(...errs);await p.close();
 // 9 the huge puke
 ({p,errs}=await fresh(b,11));await p.evaluate(()=>{var s=SC.rich();s.s.papa.hunger=92;s.s.food=4;s.order("eat");});
 const pk=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="puke"&&t.t>0.9;},1500);console.log("puke at",pk);
 await p.evaluate(()=>{var q=PP2T.sim().s.papa;PP2T.setCam(q.x,q.y,1.1);});await p.screenshot({path:OUT+"/09-huge-puke.png"});
 await p.evaluate(()=>__tt.step(200));await shot(p,"10-puke-puddle",null,400);E.push(...errs);await p.close();
 // 11 nap: sack set down beside the bed
 ({p,errs}=await fresh(b,13));await p.evaluate(()=>{var s=SC.rich();s.order("nap");});
 const np=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="nap"&&t.lying;},1500);console.log("nap at",np);
 await shot(p,"11-nap-sack-beside-bed",[11,19,1.1],600);E.push(...errs);
 // 12 edit mode ghost
 await p.evaluate(()=>{var s=PP2T.sim();s.buyItem("belt",10);s.buyItem("generator");PP2T.enterEdit();PP2T.editTab("mach");PP2T.startGhost("generator");PP2T.moveGhost(7,14);PP2T.setCam(7,14,0.8);});
 await shot(p,"12-edit-place-generator",null,300);
 await p.evaluate(()=>{PP2T.moveGhost(2,20);PP2T.setCam(4,18,0.8);});await shot(p,"13-edit-blocked",null,300);E.push(...errs);await p.close();
 console.log("ERRORS",JSON.stringify(E));await b.close();})();
