/* Full-game scripted hard test with REAL touch input (CDP touch events) on 360x800@2. Run twice (2 seeds). */
const L=require("./lib.cjs");const fs=require("fs");
const OUT=process.env.PLAY_OUT||__dirname+"/play-results.json";
async function stepT(p,sec){await p.evaluate(n=>{__tt.manual=true;__tt.step(n);__tt.manual=false;PP2T.refresh();},Math.round(sec*60));await L.sleep(60);}
async function tapSel(p,sel){await p.evaluate(s=>{const e=document.querySelector(s);const cb=e&&e.closest(".cb");if(cb&&cb.style.display==="none")PP2T.showCmd(cb.getAttribute("data-c"));if(e&&e.closest("#sheetBody"))e.scrollIntoView({block:"center"});},sel);await L.sleep(60);await L.touchTap(p,sel);await L.sleep(80);}
async function tapActText(p,act){const r=await p.evaluate(a=>{const b=document.querySelector('#sheetBody [data-act="'+a+'"]');if(!b)return null;b.scrollIntoView({block:"center"});const q=b.getBoundingClientRect();return {x:q.left+q.width/2,y:q.top+q.height/2};},act);if(!r)throw new Error("no act "+act);await L.sleep(60);await L.touchTapXY(p,r.x,r.y);await L.sleep(80);}
async function world(p,x,y,h){return p.evaluate((x,y,h)=>PP2T.project(x,y,h),x,y,h||0);}
(async()=>{const b=await L.browser();const all=[];
for(const seed of [31,62]){const R=[];const ok=(n,v,d)=>{R.push({n,pass:!!v,d:String(d||"")});console.log((v?"PASS ":"FAIL ")+"["+seed+"] "+n+" "+(d||""));};
 const {p,errs}=await L.open(b,[360,800],{dpr:2});
 await p.evaluate(s=>{__tt.setSeed(s);},seed);
 // 1 boot health
 ok("boots with HUD + command boxes",await p.evaluate(()=>document.querySelectorAll(".cb").length===PP2.COMMANDS.length&&!!document.getElementById("hCoins").textContent));
 // 2 command box + / - by touch
 const pace0=await p.evaluate(()=>PP2T.sim().s.box.pace);await tapSel(p,'.cb[data-c="pace"] .pm[data-d="1"]');const pace1=await p.evaluate(()=>PP2T.sim().s.box.pace);
 await tapSel(p,'.cb[data-c="pace"] .pm[data-d="-1"]');ok("WORK PACE + and - by touch",pace1===pace0+1&&await p.evaluate(()=>PP2T.sim().s.box.pace)===pace0,pace0+"->"+pace1);
 // 3 play a while: Papa earns
 await stepT(p,150);const c1=await p.evaluate(()=>PP2T.sim().s.coins);ok("Papa earns on his own",c1>=6,"coins "+c1);
 // 4 shop by touch: food
 await p.evaluate(()=>{PP2T.sim().s.coins+=400;});await tapSel(p,'.nb[data-n="shop"]');ok("SHOP opens",await p.evaluate(()=>document.getElementById("ovl").className==="show"));
 const f0=await p.evaluate(()=>PP2T.sim().s.food);await tapActText(p,"food:1");ok("buy food by touch",await p.evaluate(()=>PP2T.sim().s.food)===f0+1);
 await tapActText(p,"item:roomKey:1");ok("buy ROOM KEY by touch",await p.evaluate(()=>PP2T.sim().key()));
 await tapActText(p,"item:carrySack:1");await tapActText(p,"item:broomDustpan:1");ok("buy sack + broom",await p.evaluate(()=>PP2T.sim().s.equip.carrySack&&PP2T.sim().s.equip.broomDustpan));
 await tapSel(p,"#sheetX");ok("SHOP closes",await p.evaluate(()=>document.getElementById("ovl").className===""));
 // 5 SEND PEELED TO = CARRY by touch, camera follows him through the door
 await tapSel(p,'.cb[data-c="deliver"] .pm[data-d="1"]');await tapSel(p,'.cb[data-c="deliver"] .pm[data-d="1"]');ok("deliver set to CARRY by touch",await p.evaluate(()=>PP2T.sim().s.box.deliver===2));
 await p.evaluate(()=>PP2T.follow(true));let inWash=false;for(let i=0;i<60&&!inWash;i++){await stepT(p,2);await L.sleep(120);inWash=await p.evaluate(()=>PP2T.sim().s.papa.x>15&&PP2T.view.cx>14.6);}
 ok("Papa carries potatoes through the door and the camera follows",inWash,await p.evaluate(()=>"papa "+PP2T.sim().s.papa.x.toFixed(1)+","+PP2T.sim().s.papa.y.toFixed(1)+" cam "+PP2T.view.cx.toFixed(1)));
 // 6 player scrub by real swipe on the tub / pool
 await p.evaluate(()=>{__tt.flood(4);PP2T.setCam(18.5,13.6,1.2);});await L.sleep(100);let br0=await p.evaluate(()=>PP2T.sim().s.stats.brushed);
 for(let i=0;i<14;i++){const a=await p.evaluate(()=>{var o=null;PP2T.sim().s.pots.forEach(q=>{if(!o&&q.k===1&&q.d>0.15&&(q.m==="pool"||q.m==="canal"))o=PP2T.project(q.x,q.y,0.05);});return o;});if(!a)break;await L.touchDrag(p,a[0]-22,a[1]-4,a[0]+22,a[1]+4,6);}
 ok("you scrub potatoes clean with your finger (swipe)",await p.evaluate(()=>PP2T.sim().s.stats.brushed)>br0,"brushed "+await p.evaluate(()=>PP2T.sim().s.stats.brushed));
 // 7 level up to 5 by touch, buy belts + machines, EDIT place by touch
 await p.evaluate(()=>{PP2T.sim().s.coins+=5000;});await tapSel(p,'.nb[data-n="shop"]');for(let i=0;i<4;i++)await tapActText(p,"lv");ok("level up 4x by touch",await p.evaluate(()=>PP2T.sim().s.level===5));
 await p.evaluate(()=>PP2T.setCam(9,15,0.8));await tapActText(p,"item:generator:1");ok("buying a machine jumps into EDIT with it ready",await p.evaluate(()=>PP2T.view.edit&&PP2T.ghost()&&PP2T.ghost().id==="generator"));
 // drag the ghost to tile (9,15) with a real touch drag
 await L.sleep(100);const g=await p.evaluate(()=>{var q=PP2T.ghost();return [PP2T.project(q.x+1,q.y+1,0),q.x,q.y];});const tgt=await world(p,10,16);
 await L.touchDrag(p,g[0][0],g[0][1],tgt[0],tgt[1],10);const gg=await p.evaluate(()=>PP2T.ghost());ok("drag the ghost with a finger",gg&&(gg.x!==g[1]||gg.y!==g[2]),"ghost "+(gg&&gg.x)+","+(gg&&gg.y)+" ok="+(gg&&gg.ok));
 await tapSel(p,'#edit [data-e="place"]');ok("PLACE by touch",await p.evaluate(()=>PP2T.sim().placed("generator")));
 // belts: buy 10, place a line with auto-advance
 await tapSel(p,'.nb[data-n="shop"]');await tapActText(p,"item:belt:10");await p.evaluate(()=>{PP2T.moveGhost(9,13);});const r0=await p.evaluate(()=>PP2T.ghost().r);
 for(let i=0;i<4;i++){await tapSel(p,'#edit [data-e="place"]');}ok("4 belt tiles placed one at a time (auto-advance)",await p.evaluate(()=>PP2T.sim().objsOf("belt").length)===4,await p.evaluate(()=>PP2T.sim().objsOf("belt").map(o=>o.x+","+o.y).join(" ")));
 await tapSel(p,'#edit [data-e="cancel"]');await tapSel(p,'#edit [data-e="done"]');ok("leave EDIT",await p.evaluate(()=>!PP2T.view.edit));
 // tap a belt on the map to turn it
 const bl=await p.evaluate(()=>{var o=PP2T.sim().objsOf("belt")[0];PP2T.setCam(o.x+0.5,o.y+0.5,1.0);return {u:o.u,r:o.r};});await L.sleep(120);const bp=await world(p,(await p.evaluate(u=>PP2T.sim().obj(u).x,bl.u))+0.5,(await p.evaluate(u=>PP2T.sim().obj(u).y,bl.u))+0.5,0.18);
 await L.touchTapXY(p,bp[0],bp[1]);ok("tap a belt on the map to turn it",await p.evaluate(u=>PP2T.sim().obj(u).r,bl.u)===(bl.r+1)%4);
 // machine card: jam a hopper, FIX button blinks, tap FIX
 await p.evaluate(()=>{var s=PP2T.sim();s.buyItem("hopper");var r=s.place("hopper",6,20,3);s.setBox("fix",0);s.objsOf("hopper")[0].jam=1;});await stepT(p,0.5);
 ok("FIX button turns red on a jam",await p.evaluate(()=>document.querySelector('.ob[data-o="fix"]').className.indexOf("alert")>=0));
 await tapSel(p,'.ob[data-o="fix"]');const ft=await p.evaluate(()=>{var t=PP2T.sim().s.papa.task;return t?t.type+"/"+t.stage:"none";});let fixed=false;for(let i=0;i<20&&!fixed;i++){await stepT(p,1);fixed=await p.evaluate(()=>!PP2T.sim().objsOf("hopper")[0].jam);}ok("FIX by touch sends Papa to clear it",fixed,"task after tap "+ft+"; "+await p.evaluate(()=>{var s=PP2T.sim(),h=s.objsOf("hopper")[0],t=s.s.papa.task;return "hopper@"+h.x+","+h.y+" jam "+h.jam+" papa "+s.s.papa.x.toFixed(1)+","+s.s.papa.y.toFixed(1)+" "+(t?t.type+"/"+t.stage:"");}));
 // tap the hopper -> card -> TURN OFF
 const hp=await p.evaluate(()=>{var o=PP2T.sim().objsOf("hopper")[0];PP2T.setCam(7,21,1.0);return 1;});await L.sleep(120);const hpp=await world(p,7,21,1.6);await L.touchTapXY(p,hpp[0],hpp[1]);
 ok("tap a machine opens its card",await p.evaluate(()=>document.getElementById("card").className==="show"),await p.evaluate(()=>document.getElementById("cardT").textContent));
 const hasT=await p.evaluate(()=>!!document.querySelector('#cardB [data-k="mtog"]'));if(hasT){await tapSel(p,'#cardB [data-k="mtog"]');}ok("card TURN OFF works",hasT&&await p.evaluate(()=>PP2T.sim().objsOf("hopper")[0].on===0));await tapSel(p,"#cardX");
 // orders: EAT (puke if full), NAP
 await p.evaluate(()=>{var s=PP2T.sim();s.s.food=5;s.s.papa.hunger=90;});await tapSel(p,'.ob[data-o="eat"]');await stepT(p,20);ok("EAT while full = HUGE puke, then he mops it",await p.evaluate(()=>PP2T.sim().s.stats.pukes>=1));
 await tapSel(p,'.ob[data-o="nap"]');let lying=false;for(let i=0;i<20&&!lying;i++){await stepT(p,1);lying=await p.evaluate(()=>{var t=PP2T.sim().s.papa.task;return !!(t&&t.type==="nap"&&t.lying);});}
 ok("NAP by touch: he sleeps, sack on the floor",lying&&await p.evaluate(()=>!PP2T.sim().s.papa.sack.on));
 await tapSel(p,'.ob[data-o="work"]');await stepT(p,3);ok("WORK wakes him",await p.evaluate(()=>{var t=PP2T.sim().s.papa.task;return !(t&&t.type==="nap");}));
 // INV: unequip/equip sack by touch
 await tapSel(p,'.nb[data-n="inv"]');await tapActText(p,"eq:carrySack");const e1=await p.evaluate(()=>PP2T.sim().s.equip.carrySack);await tapActText(p,"eq:carrySack");ok("INV take off / put on the sack",!e1&&await p.evaluate(()=>PP2T.sim().s.equip.carrySack));
 await tapSel(p,"#sheetX");
 // RADIO sheet: buy radio, place via INV PLACE, turn on by touch
 await p.evaluate(()=>{PP2T.sim().buyItem("radio");});await tapSel(p,'.nb[data-n="inv"]');await tapActText(p,"pl:radio");await p.evaluate(()=>PP2T.moveGhost(3,4));await tapSel(p,'#edit [data-e="place"]');await tapSel(p,'#edit [data-e="done"]');
 await tapSel(p,'.nb[data-n="radio"]');await tapActText(p,"radio:power");await tapActText(p,"radio:st:1");ok("RADIO placed from INV, turned on, station SPUD JAZZ by touch",await p.evaluate(()=>PP2T.sim().placed("radio")&&PP2T.sim().s.box.radio===1&&PP2T.sim().s.decor.radioSt===1));
 await tapSel(p,"#sheetX");
 // HELP opens + scrolls
 await tapSel(p,'.nb[data-n="help"]');const hs=await p.evaluate(()=>{var b=document.getElementById("sheetBody");b.scrollTop=99999;return b.scrollTop>500;});ok("HELP lists every command + item (long, scrolls)",hs);await tapSel(p,"#sheetX");
 // zoom buttons, room jump
 const z0=await p.evaluate(()=>PP2T.view.z);await tapSel(p,"#zIn");const z1=await p.evaluate(()=>PP2T.view.z);await tapSel(p,"#goW");ok("zoom + and WASH jump",z1>z0&&await p.evaluate(()=>PP2T.view.cx>18),z0.toFixed(2)+"->"+z1.toFixed(2));
 // pinch zoom with two touch points
 const cdp=await L.cdp(p);const z2=await p.evaluate(()=>PP2T.view.z);await cdp.send("Input.dispatchTouchEvent",{type:"touchStart",touchPoints:[{x:150,y:300,id:1},{x:210,y:300,id:2}]});for(let i=1;i<=6;i++){await cdp.send("Input.dispatchTouchEvent",{type:"touchMove",touchPoints:[{x:150-i*10,y:300,id:1},{x:210+i*10,y:300,id:2}]});await L.sleep(15);}await cdp.send("Input.dispatchTouchEvent",{type:"touchEnd",touchPoints:[]});await L.sleep(100);
 ok("pinch zoom",await p.evaluate(()=>PP2T.view.z)>z2);
 // save + reload keeps everything
 const before=await p.evaluate(()=>({o:PP2T.sim().s.objs.length,lv:PP2T.sim().s.level,key:PP2T.sim().key()}));await p.evaluate(()=>PP2T.save());await p.reload();await p.waitForFunction(()=>window.__PP_READY===true);await L.sleep(300);
 const after=await p.evaluate(()=>({o:PP2T.sim().s.objs.length,lv:PP2T.sim().s.level,key:PP2T.sim().key()}));ok("save + reload keeps the kitchen",JSON.stringify(before)===JSON.stringify(after),JSON.stringify(after));
 // storage throwing: boots anyway
 const p2=await b.newPage();await p2.evaluateOnNewDocument(()=>{Object.defineProperty(window,"localStorage",{get(){throw new DOMException("no","SecurityError");}});});const e2=[];p2.on("pageerror",e=>e2.push(e.message));
 await p2.goto(L.GAME);await p2.waitForFunction(()=>window.__PP_READY===true,{timeout:8000}).catch(()=>{});ok("boots with storage throwing SecurityError",await p2.evaluate(()=>window.__PP_READY===true)&&!e2.length);await p2.close();
 ok("no page errors",!errs.length,JSON.stringify(errs));all.push({seed,R});await p.close();}
const pass=all.reduce((a,x)=>a+x.R.filter(r=>r.pass).length,0),fail=all.reduce((a,x)=>a+x.R.filter(r=>!r.pass).length,0);console.log("TOTAL",pass,"pass",fail,"fail");fs.writeFileSync(OUT,JSON.stringify({pass,fail,all},null,1));await b.close();})();
