const L=require("./lib.cjs");const fs=require("fs");
const FILTER=process.argv[2]||"";const OUTJ=process.env.HARD_OUT||__dirname+"/hard-results.json";
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:1});
for(const f of ["scenes.js","hardtests.js","hardmech.js"])if(fs.existsSync(__dirname+"/"+f))await p.addScriptTag({content:fs.readFileSync(__dirname+"/"+f,"utf8")});
await p.evaluate(()=>{__tt.manual=true;});
const names=await p.evaluate(f=>HT.H.order.filter(n=>n.indexOf(f)>=0),FILTER);const res=[];let pass=0,fail=0;
for(const n of names){for(const seed of [101,202]){const r=await p.evaluate((n,s)=>HT.H.runOne(n,s),n,seed);res.push({test:n,seed,pass:r.pass,d:r.d});if(r.pass)pass++;else fail++;console.log((r.pass?"PASS ":"FAIL ")+n+" seed "+seed+" :: "+r.d);}}
console.log("TOTAL",pass,"pass",fail,"fail","page errors",JSON.stringify(errs));fs.writeFileSync(OUTJ,JSON.stringify({pass,fail,errs,res},null,1));await b.close();})();
