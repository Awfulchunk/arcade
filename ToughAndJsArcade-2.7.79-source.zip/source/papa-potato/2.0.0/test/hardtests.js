/* Papa Potato 2 hard tests: run inside the real game page. Every test runs with 2 seeds. */
window.HT=(function(){var S=PP2T.S,H={};
H.fresh=function(seed){__tt.setSeed(seed);return PP2T.sim();};
H.rich=function(seed){var s=H.fresh(seed);s.s.coins=99999;s.s.level=5;s.s.food=6;return s;};
H.run=function(s,sec,cond){var n=Math.round(sec*60);for(var i=0;i<n;i++){s.step(1/60);if(cond&&cond(s))return i+1;}s.events=[];return cond?-1:n;};
H.reachAll=function(s){var bad=[];[["pile","pile"],["chute","chute"]].concat(s.s.objs.filter(function(o){return !o.wall&&o.id!=="belt"&&(S.itemDef(o.id)||{}).cat!=="rug"&&(s.key()||S.roomOf(o.x,o.y)!=="w");}).map(function(o){return [o.id+"@"+o.x+","+o.y,o];})).forEach(function(t){var sp=s.spotsFor(t[1]);if(!sp.length||!s.route(sp))bad.push(t[0]);});
  if(s.key()){var c=s.spotsFor("canal");if(!c.length||!s.route(c))bad.push("canal");}return bad;};
H.canvas=null;
H.render=function(s,cx,cy,z,t,ed){if(!H.canvas){H.canvas=document.createElement("canvas");H.canvas.width=360;H.canvas.height=400;}var c=H.canvas.getContext("2d");c.setTransform(1,0,0,1,0,0);c.fillStyle="#000";c.fillRect(0,0,360,400);
  PPDraw.render(c,s,{w:360,h:400,z:z||1,cx:cx,cy:cy,t:t,dpr:1,edit:!!ed,ghost:null,sel:0,showPower:false});return c;};
/* pixels inside a box change between two times = a looped animation */
H.animates=function(s,o){var it=S.itemDef(o.id),cx,cy,f;if(o.wall){var n=it.w||1;cx=o.wall==="N"?o.x+n/2:0.3;cy=o.wall==="N"?0.3:o.y+n/2;}else{f=S.fp(o);cx=f.x+f.w/2;cy=f.y+f.h/2;}
  var p=s.s.papa,ox=p.x,oy=p.y,far=[[3,3],[12,22],[22,9],[24,2]].sort(function(A,B){return Math.hypot(B[0]-cx,B[1]-cy)-Math.hypot(A[0]-cx,A[1]-cy);})[0];p.x=far[0]+0.5;p.y=far[1]+0.5;
  var cat=s.s.cat,cx0=cat.x,cy0=cat.y;cat.x=far[0]+0.5;cat.y=far[1]+0.5;
  function img(t){PPDraw.parts.length=0;return H.render(s,cx,cy,1,t,H.ed).getImageData(70,20,220,300).data.slice();}
  function dif(a,b,i){return Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>24;}
  var t0=s.s.t,B0=img(10.0),i0=s.s.objs.indexOf(o);s.s.objs.splice(i0,1);s.dirtyGrid=true;var A0=img(10.0);s.s.objs.splice(i0,0,o);s.dirtyGrid=true;
  var best=0;[10.37,10.9,11.6,12.3].forEach(function(t,k){s.s.t=t0+(k+1)*20;var Bt=img(t),d=0;for(var i=0;i<B0.length;i+=4)if(dif(A0,B0,i)&&dif(B0,Bt,i))d++;if(d>best)best=d;});
  s.s.t=t0;p.x=ox;p.y=oy;cat.x=cx0;cat.y=cy0;PPDraw.parts.length=0;return best;};
H.T={};H.order=[];function T(name,fn){H.T[name]=fn;H.order.push(name);}
H.runOne=function(name,seed){var r;try{PPDraw.parts.length=0;r=H.T[name](seed);}catch(e){r={pass:false,d:"THREW "+e.message+" "+(e.stack||"").split("\n")[1]};}return r;};
return {H:H,T:T,S:S};})();
(function(){var T=HT.T,H=HT.H,S=HT.S;
/* effect probes for items whose effect is a pure function we can read */
var FX={
  smallCooler:function(s,on){return s.cooCap();},shelf:function(s){return s.cooCap();},potsPans:function(s){return -s.foodPrice();},bookshelf:function(s){var l=s.s.level;s.s.level=2;var v=-s.levelPrice();s.s.level=l;return v;},
  statue:function(s){s.s.papa.mood=50;return s.workMul();},trophyShelf:function(s){s.s.papa.mood=50;return s.workMul();},fan:function(s){for(var i=0;i<90;i++)s.addPeel(3+(i%5)*0.5,12+((i/5)|0)%5*0.5);return -s.messSlow();},
  lamp:function(s){s.setBox("lamp",1);return -s.peelTime();},radio:function(s){s.setBox("radio",1);s.s.papa.mood=50;return s.workMul();},
  clock:function(s){return s.moodCalc();},calendar:function(s){return s.moodCalc();},plant:function(s){return s.moodCalc();},poster:function(s){return s.moodCalc();},window:function(s){return s.moodCalc();},
  coatHook:function(s){return s.moodCalc();},spiceRack:function(s){return s.moodCalc();},compost:function(s){return s.moodCalc();},fruitBowl:function(s){return s.moodCalc();},runner:function(s){return s.moodCalc();}
};
var ORIG={k:[[4,5],[9,15]],w:[[18,6],[22,10]],any:[[3,13],[20,9]]};
function spot(s,id,seedIdx){var it=S.itemDef(id),o=ORIG[it.room||"any"][seedIdx%2];for(var d=0;d<30;d++)for(var y=o[1]-d;y<=o[1]+d;y++)for(var x=o[0]-d;x<=o[0]+d;x++){if(Math.max(Math.abs(x-o[0]),Math.abs(y-o[1]))!==d)continue;if(s.canPlace(id,x,y,0).ok)return [x,y];}return null;}
S.ITEMS.forEach(function(it){
  T("item:"+it.id,function(seed){var s=H.rich(seed),out=[],ok=true,si=seed%2;function chk(c,m){if(!c){ok=false;out.push("FAIL "+m);}}
    /* locked below its level (if above 1) */
    if(it.lv>1){s.s.level=it.lv-1;var lr=s.buyItem(it.id);chk(!lr.ok&&/LV/.test(lr.why),"not locked below LV "+it.lv);s.s.level=5;}
    if(it.room==="w")s.buyItem("roomKey");var before=null;if(FX[it.id])before=FX[it.id](s);
    var c0=s.s.coins,pr=s.itemPrice(it.id),r=s.buyItem(it.id,1);chk(r.ok,"buy "+(r.why||""));chk(s.s.coins===c0-pr,"price "+pr);
    if(it.cat==="key"){chk(s.walkable(14,3)&&s.walkable(14,4),"door walkable");var rt=s.route(s.spotsFor(s.objsOf("tub")[0]));chk(!!rt,"route to wash room");return {pass:ok,d:out.join("; ")||"door open, wash room reachable"};}
    if(it.cat==="tool"){chk(s.s.equip[it.id]===true,"equipped");s.equip(it.id,false);chk(s.s.equip[it.id]===false,"unequip");s.equip(it.id,true);H.render(s,s.s.papa.x,s.s.papa.y,1,3);return {pass:ok,d:out.join("; ")||"equip/unequip ok, drawn"};}
    if(it.cat==="basin"){chk(s.s.basin[it.id]===false,"no key yet");s.buyItem("roomKey");chk(s.setBasin(it.id,true)&&s.s.basin[it.id],"in pool");var fake={id:"x",x:17,y:12,wall:"N"};H.render(s,18.5,13.5,1,2);return {pass:ok,d:out.join("; ")||"basin toggles"};}
    if(it.cat==="theme"){var k=it.id==="wallpaper"?"wall":"floor";chk(s.setTheme(k,2)&&s.s.decor[k]===2,"theme set");H.render(s,6,8,0.6,2);chk(s.setTheme(k,0),"theme back");return {pass:ok,d:out.join("; ")||"theme ok"};}
    /* placeables */
    var o=null;if(it.cat==="wall"){var w0=si?[0.5,10.5]:[3.5,0.5];if(it.room==="w")w0=si?[22.5,0.5]:[16.5,0.5];r=s.place(it.id,w0[0],w0[1],0);chk(r.ok,"wall place "+(r.why||""));o=r.o;}
    else{var sp=spot(s,it.id,si);chk(!!sp,"found a free spot");if(!sp)return {pass:false,d:out.join("; ")};r=s.place(it.id,sp[0],sp[1],0);chk(r.ok,"place "+(r.why||""));o=r.o;}
    if(!o)return {pass:false,d:out.join("; ")};
    chk(H.reachAll(s).length===0,"everything still reachable "+H.reachAll(s).join(","));
    H.run(s,0.3);if(it.cat==="belt"||it.cat==="mach"){o.pw=1;if(o.on!=null)o.run=1;}H.ed=false;var an=H.animates(s,o),anv="";if(an<=30){H.ed=true;an=H.animates(s,o);anv=" (seen in EDIT x-ray view: hidden behind something tall in normal view)";H.ed=false;}chk(an>30,"looped animation (changed px "+an+")");
    if(FX[it.id]){var after=FX[it.id](s);chk(after>before,"effect "+before+" -> "+after);}
    /* move, turn, store, re-place */
    if(it.cat==="wall"){var mv=s.move(o.u,o.wall==="N"?12.5:0.5,o.wall==="N"?0.5:20.5);if(it.room==="w")mv=s.move(o.u,24.5,0.5);chk(mv.ok,"wall move "+(mv.why||""));}
    else{var sp2=spot(s,it.id,si+1);if(sp2){var mv2=s.move(o.u,sp2[0],sp2[1],o.r);chk(mv2.ok,"move "+(mv2.why||""));}var rr=s.rotate(o.u);chk(rr.ok||/room to turn/.test(rr.why),"turn "+(rr.why||""));}
    var st=s.store(o.u);chk(st.ok&&(s.s.inv[it.id]|0)===1,"store");var re=it.cat==="wall"?s.place(it.id,1.5,0.5,0):s.place(it.id,(spot(s,it.id,si)||[0,0])[0],(spot(s,it.id,si)||[0,0])[1],0);chk(re.ok,"re-place "+(re.why||""));
    chk(H.reachAll(s).length===0,"reachable after edits");H.run(s,3);
    return {pass:ok,d:out.join("; ")||("placed, animates ("+an+"px"+anv+"), moved, turned, stored, re-placed"+(FX[it.id]?", effect ok":""))};});
});
})();
