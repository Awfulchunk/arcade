# Papa Potato 2.0.0 — progress (resume file)
Brief: full rework of 0.4.11 -> 2.0.0, test (items 2x, mechanics 2x, full touch game 2x, tough-tools, A03s perf 6x/4x),
stage in /workspace/game/requests/finished-ship/papa-potato-2-test/, then ship Arcade 2.7.77 (Papa 2.0.0 + Pixel War 0.5.0, keep 0.4.11/0.4.15 slots),
versionCode 115, same signer, apksigner v1/v2/v3, publish to Awfulchunk/arcade Pages. Never print keys; Latch REPLACE-WITH-UNLOCK-CODE; do NOT touch PR 2.

## Layout
- src/: sim.js, draw.js, radio.js (copied from 0.4.11), head.html, ui/game.js. build.sh -> release/papa-potato-2.0.0.html (NOT "out/": box wipes out/).
- test/: lib.cjs (puppeteer), scenes.js, hardtests.js (49 items x2), hardmech.js (28 mechanics x2), hard.cjs runner, play.cjs (full touch game x2), shots.cjs (screens).

## Status (2026-11-25 21:05 PT)
- [x] sim.js, draw.js, head.html, game.js, build.sh — builds, no page errors
- [x] items 2x: 98/98 pass (looped animation pixel check, place/move/turn/store, effects, reachability)
- [x] mechanics 2x: 56/56 pass
- [~] play.cjs: 64/66 — "FIX by touch" failing, debugging
- [ ] tough-tools tt.js --all
- [ ] perf A03s 360x800@2, 6x + 4x throttle
- [ ] FEATURES-2.md + staging
- [ ] ship 2.7.77

- 21:06 play.cjs 66/66 PASS (seeds 31,62). Next: tough-tools --all, perf, hard rerun, shots, stage, ship.
- 21:27 tt.js visual fixed (paged command boxes, 44px sliders, HUD narrow). Perf: bg layer cache, culling, batched box outlines/peels, adaptive render scale (2x->1x steps). 6x ~57-60fps adaptive. Running test/all.sh (hard, play, perf, shots, tt --all) -> staging test-evidence.
- 21:43 adaptive scale resets on resize (tt buff resize-rotate fixed). Final html 80791950... Rerunning test/all.sh. Ship prep done in /workspace/game/build-ship2777 (assemble/verify/headless scripts, package-2.7.77 manifest 115/2.7.77, src-work). Next: stage html, assemble, build APK, verify, source zip, publish.
- 21:54 RESUME: site clean, origin/main 83299e6 (no partial push). all.sh: hard 154/0, play 66/0, perf, shots ok; tt --all running. Staged html 80791950 + FEATURES-2.md.
- 22:01 all.sh FINAL on 80791950: hard 154/0, play 66/0, perf ok, 13 shots, tt --all 66 pass 0 fail 5 warn. Next: assemble 2.7.77.
- 22:04 perf rerun clean; staging SHA256SUMS written; assembled release/index.html.
- 22:06 APK built (release/ToughAndJsArcade-2.7.77.apk), headless ALL OK, verify run.
