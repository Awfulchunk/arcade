# Papa Potato 2.0.2 — progress (resume file)
Base: live 2.0.1 (src/, release/papa-potato-2.0.1.html, arcade 2.7.78). Backup: src-2.0.1-backup/.
Fixes: 1 wall shipping (kitchen intake -> wash outlet -> pool pile, remove X-RAYs + old SHIP) 2 no pre-placed machines (fresh+migrated)
3 pile = 0.4.11 exact 4 calendar still, flips on day change; audit anims 5 radio-station want 6 short-trip min work (<50%) 7 broom parked unless sweeping.
Test: tt --all 1x + one scripted every-feature run A03s. Stage finished-ship/papa-potato-2.0.2-test/. DO NOT SHIP.
## Log
- 07:06 backup src-2.0.1-backup made
- 07:14 sim.js patched (wall SHIPPING machine scanK x13 / scanW, chute removed, pile FIX {0,20,14,4} potTotal 852, broom fetch/park tasks, calendar calFlipT, stDisco station want, migration old saves: pile+772, deliver 1->0, starters off pile). build.sh -> 2.0.2. NEXT: away.js min work, radio.js station 3, game.js UI, draw.js (machine, pile 0.4.11 port, broom, anims)
- 07:15 away.js (MIN_WORK 0.15, >=1c for >=60s trips, station wants), radio.js DISCO SPUD st3, game.js (machine card, help, radio rows) done. NEXT draw.js
- draw.js patched (ship machine, 0.4.11 pile, broom park, anim audit)
- hardtests: animation classes (always/state/trigger/still), station item test; items 56/56 x2 seeds pass
- hardmech updated + 8 new 202: tests pass
- stage202.cjs screenshots, pile side-by-side, broom toast text, pile label hidden, pile card count
- NOTE: release/papa-potato-2.0.1.html had been overwritten at 07:14 by an early 2.0.2 build (before build.sh output was renamed). Restored from finished-ship/papa-potato-2.0.1-test (sha e94457c8…, matches its .sha256). Bad copy kept at work202/overwritten-2.0.1-name-by-early-202-build.html
- perf: pile shadow/bay/chute/front now in the pile cache (one drawImage per frame); broom label hidden. build 569786e3
- 07:56 resumed after interrupt; final evidence run (all202.sh) on build 569786e3 in progress: hard 103/0, play 66/0, savecompat pass
- 08:06 final evidence done on build 569786e3: hard 103/0, play 66/0, savecompat pass, tt 66 pass 0 fail 5 warn (same 5 warns as 2.0.1), perf vs 2.0.1 baseline recorded. Staged to finished-ship/papa-potato-2.0.2-test with FEATURES-202.md, screenshots, SHA256SUMS. NOT shipped. Known gap: Papa partly hidden behind the machine (ghost outline) while dropping.
- 08:20 t1240 started: Papa ghost fix, chute to other (west) side, pay 2c at drop + ~4c after wash, warmer pile, rounder chute
- pay: toScanner pays DROP_PAY 2c (+coin popup via drop), prepaid pots pay potValue-1 at the hole (clean 4c), save pend/poolPre handle prepaid; away route 6/4; texts updated
- 08:24 draw: Papa d>=29.2 near machine + no ghost; chute mirrored west, round ribbed pipe (ring polys); warmer pile palette+LVF; drop spots [13,16] first
- 08:40 tests: 202:pay + 202:Papa-in-front added (old build fails it 87/88%); stage202 06b drop +2c and 09b hole +4c shots via real event pump
- 08:45 t1240 full run: hard 105/0, play 66/0, savecompat PASS, tt 66 pass 0 fail 5 warn (same warns), perf factory6x 45.5 vs 51.9; stage re-run with 05c; composite 18 rebuilt; staged html+sha+FEATURES
- 08:46 t1242 started: A Papa floor spot south + machine unwalkable + depth; B canal outlet; C flow tap/FLOW btn, AUTO CLEANER + SORTER over canal, DRYER/BUBBLER to Custom Game
- 09:05 t1242 code: sim (drop spot shipFront 13,16 only + kept clear, SHIP_C drain, flowOff, canal machines CANALM cleaner/sorter/dryer/bubbler, custom), ui (FLOW nav+gate tap, custom game in HELP, shop), draw (drain, gate, canal machines, sink anim, Papa plain depth)
- 09:20 t1242 tests added (11 canal/drop tests) all pass; item tests 60/60
- 09:40 t1242 visual fixes (no ghost by canal machines, cleaner label on roof, wantB hidden in shots, drain cam); FEATURES t1242 section; starting HARD TEST 2X (t1243)
- 09:25 hard pass (pre-fix) found 2 issues: item test order for custom items (test bug), Papa ghosted by canal potatoes (draw bug: pot/yoyo entries now nh). Fixed; rerunning 2 full passes on final build
- 09:38 pass1 (final build) DONE: hard 119/0, play 76/0, savecompat PASS, stage ERRORS [], tt 66/0/5warn; pass2 (SEEDS=202) hard 119/0 play 76/0 savecompat PASS then interrupted at perf; resuming pass2 from perf (note: 09:40 line above was mis-stamped, really ~09:07)
- 10:15 found pass2 original run had NOT died (two pass2 runners overlapped from perf on); killed both; re-running pass2 perf/stage/poses/pile/tt once, sequentially
- 10:12 HARD TEST 2X done on build ad4fdd78: pass1 hard 119/0 play 76/0 savecompat PASS stage ERRORS[] tt 66/0/5w; pass2 (SEEDS=202) hard 119/0 play 76/0 savecompat PASS stage ERRORS[] tt 65/0/6w (+1 soak-degrade timing warn). Screenshots reviewed both passes. Staged html+sha+FEATURES+PROGRESS+screenshots(pass2), comp 18 rebuilt, SHA256SUMS verified. NOT shipped, PR 2 untouched.
- 10:45 t1244 (Jay angry: in front of the box + fix label): drop spot -> 13,18 (lane 13,16..18 kept clear), toss arc into intake, low dividing-wall segments can't ghost Papa (nh), FLOW label white bold on dark plate + red/green dot (map + menu button); new hard test bbox Papa vs SHIPPING machine at 8 zooms (min gap 9px at z0.38); ghost flag check. Ship request (t1245) noted: NOT published: no owner approval id for it in my relay, staging only
- 10:57 t1244 pass attempt found: play NAP-by-touch fail both seeds = real bug (order lost when he went to pick up his sack; showed up because the new drop spot changed timing). Fixed in decide() + new hard test. Restarting HARD TEST 2X on build d79d4fdc
- 11:33 HARD TEST 2X on build d79d4fdc DONE: pass1 hard 121/0 play 76/0 savecompat PASS stage ERRORS[] tt 66/0/5w; pass2 (SEEDS=202) hard 121/0 play 76/0 savecompat PASS stage ERRORS[] tt 66/0/5w. Pass2 perf factory 6x fixed1x 20.6fps is an outlier (arcade assemble ran at the same time). Screenshots reviewed. Next: stage, then ship 2.7.79 (Jay pt1245u)
- 11:34 2.7.79: assembled bundle 1834155b (187 slots, +papa-potato:v201), headless launch 14/14 0 errors, APK built + verify run
