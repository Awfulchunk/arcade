/* ===== Papa Potato 2.0.2 — iso renderer (Project Zomboid-style corner view: back walls up, front walls cut low).
   Everything here is drawn live with canvas paths. 2.0.2: decor stays still unless something real moves it (see the animation audit in FEATURES-202.md). ===== */
var PPDraw=(function(){
"use strict";
var D={},S=PP2,FIX=S.FIX,W=S.W,H=S.H;
var NOGROUND=false,ctx=null,Z=1,CW=360,CH=400,CX=0,CY=0,T=0,ZP=50,WALLH=2.4,LOWH=0.55;
var cam={x:7,y:12};
function setView(c,cw,ch,z,cx,cy,t){ctx=c;CW=cw;CH=ch;Z=z;cam.x=cx;cam.y=cy;T=t;CX=(cx-cy);CY=(cx+cy);}
function sx(x,y){return CW/2+((x-y)-CX)*32*Z;}
function sy(x,y,h){return CH/2+((x+y)-CY)*16*Z-(h||0)*ZP*Z;}
function P(x,y,h){return [sx(x,y),sy(x,y,h)];}
function toWorld(px,py){var X=(px-CW/2)/(32*Z)+CX,Y=(py-CH/2)/(16*Z)+CY;return {x:(X+Y)/2,y:(Y-X)/2};}
function hex(c){if(c[0]!=="#")return [128,128,128];var n=parseInt(c.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
var shadeCache={};
function shade(c,f){var k=c+f;var v=shadeCache[k];if(v)return v;var r=hex(c),o;if(f<=1)o=[r[0]*f,r[1]*f,r[2]*f];else{var g=f-1;o=[r[0]+(255-r[0])*g,r[1]+(255-r[1])*g,r[2]+(255-r[2])*g];}
  v="rgb("+(o[0]|0)+","+(o[1]|0)+","+(o[2]|0)+")";shadeCache[k]=v;return v;}
function poly(pts,fill,stroke,lw){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(var i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=(lw||1)*Math.max(0.6,Z);ctx.stroke();}}
var OUT="rgba(20,14,10,0.55)";
/* a shaded box: x,y min corner (tiles), w along x, d along y, z0 base (m), h height (m) */
function box(x,y,w,d,z0,h,c,o){o=o||{};var t=z0+h;
  var A=P(x,y,t),B=P(x+w,y,t),C2=P(x+w,y+d,t),Dd=P(x,y+d,t),Bb=P(x+w,y,z0),Cb=P(x+w,y+d,z0),Db=P(x,y+d,z0);
  var st=o.stroke===false?null:(o.stroke||OUT);
  poly([Dd,C2,Cb,Db],o.left||shade(c,0.78),null);poly([C2,B,Bb,Cb],o.right||shade(c,0.62),null);poly([A,B,C2,Dd],o.top||c,null);
  /* one outline pass for all three faces (same lines as stroking each face, a third of the draw calls) */
  if(st){ctx.beginPath();ctx.moveTo(Db[0],Db[1]);ctx.lineTo(Cb[0],Cb[1]);ctx.lineTo(Bb[0],Bb[1]);ctx.lineTo(B[0],B[1]);ctx.lineTo(A[0],A[1]);ctx.lineTo(Dd[0],Dd[1]);ctx.closePath();
    ctx.moveTo(Dd[0],Dd[1]);ctx.lineTo(C2[0],C2[1]);ctx.lineTo(B[0],B[1]);ctx.moveTo(C2[0],C2[1]);ctx.lineTo(Cb[0],Cb[1]);ctx.strokeStyle=st;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();}}
function topQuad(x,y,w,d,h,c,st){poly([P(x,y,h),P(x+w,y,h),P(x+w,y+d,h),P(x,y+d,h)],c,st);}
function ell(x,y,h,rx,ry,c,st){var p=P(x,y,h);ctx.beginPath();ctx.ellipse(p[0],p[1],Math.max(0.5,rx*Z),Math.max(0.5,ry*Z),0,0,6.2832);if(c){ctx.fillStyle=c;ctx.fill();}if(st){ctx.strokeStyle=st;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();}}
/* iso circle on the floor plane: r in tiles */
function isoCirc(x,y,h,r,c,st,lw){var p=P(x,y,h);ctx.beginPath();ctx.ellipse(p[0],p[1],r*45.25*Z,r*22.6*Z,0,0,6.2832);if(c){ctx.fillStyle=c;ctx.fill();}if(st){ctx.strokeStyle=st;ctx.lineWidth=(lw||1)*Math.max(0.6,Z);ctx.stroke();}}
function cyl(x,y,r,z0,h,c,top){var a=P(x,y,z0),b=P(x,y,z0+h),rx=r*45.25*Z,ry=r*22.6*Z;
  ctx.beginPath();ctx.ellipse(a[0],a[1],rx,ry,0,0,Math.PI);ctx.lineTo(b[0]-rx,b[1]);ctx.ellipse(b[0],b[1],rx,ry,0,Math.PI,0,true);ctx.closePath();
  var g=ctx.createLinearGradient(a[0]-rx,0,a[0]+rx,0);g.addColorStop(0,shade(c,0.85));g.addColorStop(0.4,shade(c,1.08));g.addColorStop(1,shade(c,0.55));ctx.fillStyle=g;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();
  ctx.beginPath();ctx.ellipse(b[0],b[1],rx,ry,0,0,6.2832);ctx.fillStyle=top||shade(c,1.1);ctx.fill();ctx.stroke();}
function shadow(x,y,r,a){isoCirc(x,y,0,r,"rgba(0,0,0,"+(a||0.22)+")");}
function line(a,b,c,w){ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.strokeStyle=c;ctx.lineWidth=(w||1)*Math.max(0.5,Z);ctx.stroke();}
function txt(s,x,y,size,c,al){ctx.font="bold "+Math.max(7,Math.round(size*Z))+"px monospace";ctx.textAlign=al||"center";ctx.textBaseline="middle";ctx.fillStyle=c;ctx.fillText(s,x,y);}
/* faces of a wall plane (for wall items): N wall = plane y=0 (u along x), W wall = plane x=0 (u along y) */
function wallPt(wall,u,h,off){off=off||0.02;return wall==="N"?P(u,off,h):P(off,u,h);}
function wallQuad(wall,u0,u1,h0,h1,c,st){poly([wallPt(wall,u0,h0),wallPt(wall,u1,h0),wallPt(wall,u1,h1),wallPt(wall,u0,h1)],c,st);}
/* ---------- potatoes: raw = brown skin with eyes; peeled = smooth cream with soft knife facets, dirt shows as smudges ---------- */
function potato(x,y,h,p,rot,sc){var a=P(x,y,h),r=(sc||1)*6.2*Z,ry=r*0.72;ctx.save();ctx.translate(a[0],a[1]-ry*0.6);ctx.rotate(rot||0);
  if(p.k===0){ctx.beginPath();ctx.ellipse(0,0,r,ry,0,0,6.2832);var g=ctx.createRadialGradient(-r*0.35,-ry*0.4,r*0.1,0,0,r*1.1);g.addColorStop(0,"#c99a63");g.addColorStop(0.55,"#9a6a3a");g.addColorStop(1,"#5e3d1f");ctx.fillStyle=g;ctx.fill();ctx.strokeStyle="rgba(40,22,10,0.7)";ctx.lineWidth=Math.max(0.5,Z*0.8);ctx.stroke();
    ctx.fillStyle="#4a2e16";ctx.fillRect(-r*0.4,-ry*0.1,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(r*0.25,ry*0.2,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(r*0.05,-ry*0.45,Math.max(1,Z),Math.max(1,Z));}
  else{ctx.beginPath();ctx.ellipse(0,0,r*0.94,ry*0.94,0,0,6.2832);var g2=ctx.createRadialGradient(-r*0.3,-ry*0.45,r*0.05,0,0,r);g2.addColorStop(0,"#fff6cf");g2.addColorStop(0.5,"#f2d98a");g2.addColorStop(1,"#d3ad55");ctx.fillStyle=g2;ctx.fill();ctx.strokeStyle="rgba(120,84,30,0.65)";ctx.lineWidth=Math.max(0.5,Z*0.7);ctx.stroke();
    ctx.strokeStyle="rgba(190,150,70,0.55)";ctx.beginPath();ctx.moveTo(-r*0.5,-ry*0.2);ctx.lineTo(-r*0.1,ry*0.35);ctx.moveTo(r*0.15,-ry*0.55);ctx.lineTo(r*0.45,ry*0.1);ctx.stroke();
    if(p.d>0.02){ctx.globalAlpha=Math.min(0.85,p.d*0.9);ctx.fillStyle="#6b4a2a";ctx.beginPath();ctx.ellipse(-r*0.25,ry*0.15,r*0.4,ry*0.32,0.4,0,6.2832);ctx.fill();ctx.beginPath();ctx.ellipse(r*0.38,-ry*0.15,r*0.22,ry*0.25,0,0,6.2832);ctx.fill();
      ctx.fillStyle="#3f2a16";ctx.fillRect(r*0.05,ry*0.3,Math.max(1,Z),Math.max(1,Z));ctx.fillRect(-r*0.6,-ry*0.3,Math.max(1,Z),Math.max(1,Z));ctx.globalAlpha=1;}
    else{var tw=(Math.sin(T*5+p.u)*0.5+0.5);ctx.fillStyle="rgba(255,255,255,"+(0.5+0.5*tw)+")";ctx.fillRect(-r*0.45,-ry*0.55,Math.max(1,1.5*Z),Math.max(1,1.5*Z));}
    ctx.fillStyle="rgba(255,255,255,0.55)";ctx.beginPath();ctx.ellipse(-r*0.35,-ry*0.4,r*0.22,ry*0.16,-0.4,0,6.2832);ctx.fill();}
  ctx.restore();}
D.potato=potato;
/* 2.0.2 animation rules (t1236 "calendar shouldn't be constantly playing"): decor stays still unless something real moves it.
   brush(o,x,y): 0..1, eases up while Papa walks within 1.8 tiles of (x,y) and settles back to 0 (render-side only). */
/* render-side memory per object (never saved): RSO.get(o) -> {sw, used} */
var RSO=typeof WeakMap!=="undefined"?new WeakMap():null;function rso(o){if(!RSO)return {};var r=RSO.get(o);if(!r){r={sw:0,used:null};RSO.set(o,r);}return r;}
D.rso=rso;
function brush(o,x,y){var p=D.sim?D.sim.s.papa:null,tg=0,r=rso(o);if(p&&p.moving&&Math.hypot(p.x-x,p.y-y)<1.8)tg=1;var v=r.sw||0;v+=(tg-v)*(tg?0.12:0.05);if(v<0.004)v=0;r.sw=v;return v;}
function usedRecently(o,act){var r=rso(o);if(act)r.used=T;return r.used!=null&&T-r.used>=0&&T-r.used<4;}
function fanOn(sim){return sim.placed("fan");}
function papaDoing(sim,type){var t=sim.s.papa.task;return !!(t&&t.type===type&&t.stage==="act");}
/* ---------- particles (render only) ---------- */
var parts=[],NOPART=false;function part(o){if(NOPART)return;if(parts.length>420)parts.shift();parts.push(o);}
function emit(ev){var i;switch(ev.e){
  case "coin":part({k:"txt",x:ev.x,y:ev.y,h:1.6,t:0,life:1.6,s:"+"+ev.v+"c",c:(ev.tot||ev.v)>=5?"#7dff9a":"#ffd34d"});for(i=0;i<6;i++)part({k:"spark",x:ev.x,y:ev.y,h:1.2,vx:(Math.random()-0.5)*1.5,vy:(Math.random()-0.5)*1.5,vh:1+Math.random()*1.5,t:0,life:0.6,c:"#ffd34d"});break;
  case "peeled":for(i=0;i<5;i++)part({k:"peel",x:ev.x,y:ev.y,h:1.0,vx:(Math.random()-0.5)*1.6,vy:(Math.random()-0.2)*1.6,vh:1.5+Math.random(),t:0,life:0.8,r:Math.random()*6});break;
  case "splash":for(i=0;i<9;i++)part({k:"drop",x:ev.x,y:ev.y,h:0.5,vx:(Math.random()-0.5)*1.4,vy:(Math.random()-0.5)*1.4,vh:1.5+Math.random()*1.5,t:0,life:0.7});break;
  case "foam":for(i=0;i<4;i++)part({k:"foam",x:ev.x+(Math.random()-0.5)*0.4,y:ev.y+(Math.random()-0.5)*0.4,h:0.6,vh:0.4+Math.random()*0.4,t:0,life:1.1,r:2+Math.random()*3});break;
  case "fixed":for(i=0;i<10;i++)part({k:"spark",x:ev.x,y:ev.y,h:1.2,vx:(Math.random()-0.5)*2,vy:(Math.random()-0.5)*2,vh:1+Math.random()*2,t:0,life:0.5,c:"#ffe27a"});part({k:"txt",x:ev.x,y:ev.y,h:2.4,t:0,life:1.4,s:"FIXED",c:"#8fe3ff"});break;
  case "sortBack":part({k:"txt",x:ev.x,y:ev.y,h:1.3,t:0,life:1.2,s:"DIRTY \u21a9 POOL",c:"#ffb080"});break;
  case "eat":part({k:"txt",x:0,y:0,h:0,t:0,life:0.01,s:"",c:"#fff"});break;
}}
function stepParts(dt){for(var i=parts.length-1;i>=0;i--){var p=parts[i];p.t+=dt;if(p.t>=p.life){parts.splice(i,1);continue;}if(p.vx!=null){p.x+=p.vx*dt;p.y+=(p.vy||0)*dt;}if(p.vh!=null){p.h+=p.vh*dt;if(p.k!=="foam")p.vh-=6*dt;if(p.h<0){p.h=0;p.vh=0;p.vx*=0.3;p.vy*=0.3;}}}}
function drawParts(){for(var i=0;i<parts.length;i++){var p=parts[i],a=P(p.x,p.y,p.h),f=1-p.t/p.life;
  if(p.k==="txt"){txt(p.s,a[0],a[1]-p.t*24*Z,11,p.c);continue;}
  ctx.globalAlpha=Math.max(0,Math.min(1,f*1.5));
  if(p.k==="spark"){ctx.fillStyle=p.c;ctx.fillRect(a[0]-Z,a[1]-Z,2*Z,2*Z);}
  else if(p.k==="peel"){ctx.strokeStyle="#c58c47";ctx.lineWidth=Math.max(1,1.6*Z);ctx.beginPath();ctx.arc(a[0],a[1],2.5*Z,p.r+p.t*9,p.r+p.t*9+2.4);ctx.stroke();}
  else if(p.k==="drop"){ctx.fillStyle="#9fd8ff";ctx.fillRect(a[0]-Z,a[1]-Z,2*Z,2.5*Z);}
  else if(p.k==="foam"){ctx.beginPath();ctx.arc(a[0],a[1],p.r*Z,0,6.2832);ctx.fillStyle="rgba(255,255,255,0.75)";ctx.fill();ctx.strokeStyle="rgba(160,210,255,0.8)";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();}
  else if(p.k==="smoke"){ctx.beginPath();ctx.arc(a[0],a[1],(3+p.t*6)*Z,0,6.2832);ctx.fillStyle="rgba(90,90,90,"+(0.45*f)+")";ctx.fill();}
  else if(p.k==="note"){txt(p.s,a[0]+Math.sin(p.t*5)*4*Z,a[1],10,"#ffd6f5");}
  else if(p.k==="z"){txt("z",a[0]+Math.sin(p.t*3)*4*Z,a[1],8+p.t*5,"#cfe8ff");}
  ctx.globalAlpha=1;}}
D.emit=emit;D.stepParts=stepParts;D.parts=parts;
/* ---------- floor, walls, water ---------- */
var FLOORS=[["#e6dabd","#d6c7a3"],["#efefea","#2e2e33"],["#cf7f55","#bb6b43"],["#b98a55","#a87a47"]];
var WALLS=[["#eadfc4","#8a6748"],["#c5e6d3","#7aa58d"],["#f2cfcf","#b97c7c"],["#41557a","#26344f"]];
function visTiles(){var a=toWorld(0,0),b=toWorld(CW,0),c=toWorld(0,CH+140*Z),d=toWorld(CW,CH+140*Z);
  return {x0:Math.max(0,Math.floor(Math.min(a.x,c.x))-1),x1:Math.min(W,Math.ceil(Math.max(b.x,d.x))+1),y0:Math.max(0,Math.floor(Math.min(a.y,b.y))-1),y1:Math.min(H,Math.ceil(Math.max(c.y,d.y))+1)};}
function tilePath(x,y){var a=P(x,y,0),b=P(x+1,y,0),c=P(x+1,y+1,0),d=P(x,y+1,0);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);ctx.closePath();}
function drawFloor(sim,V){var s=sim.s,th=s.decor.floor|0,F=FLOORS[th]||FLOORS[0],x,y,i;
  /* ground outside the rooms */
  if(!NOGROUND){ctx.fillStyle="#1d1a18";ctx.fillRect(0,0,CW,CH);}
  var pass=[[],[],[],[]];
  for(y=V.y0;y<V.y1;y++)for(x=V.x0;x<V.x1;x++){var r=S.roomOf(x,y);if(r==="k"){if(S.fixedBlock(x,y)&&!S.inRect(x,y,FIX.pile))continue;pass[(x+y)&1].push([x,y]);}else if(r==="w"){if(S.isWater(x,y))continue;pass[2+((x+y)&1)].push([x,y]);}else if(r==="door")pass[2].push([x,y]);}
  var cols=[F[0],th===3?F[0]:F[1],"#bcccd2","#aabdc4"];
  for(i=0;i<4;i++){ctx.beginPath();pass[i].forEach(function(t){tilePath(t[0],t[1]);});ctx.fillStyle=cols[i];ctx.fill();}
  ctx.strokeStyle="rgba(60,45,30,0.18)";ctx.lineWidth=Math.max(0.5,0.7*Z);ctx.beginPath();
  for(x=Math.max(0,V.x0);x<=Math.min(26,V.x1);x++){var y0=0,y1=x<=14?24:16;if(x===15)y1=24;var a=P(x,Math.max(y0,V.y0),0),b=P(x,Math.min(y1,V.y1),0);if(x>14&&x<=26){a=P(x,Math.max(0,V.y0),0);b=P(x,Math.min(16,V.y1),0);}ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}
  for(y=Math.max(0,V.y0);y<=Math.min(24,V.y1);y++){var xe=y<=16?26:14,c=P(0,y,0),d=P(xe,y,0);ctx.moveTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);}
  ctx.stroke();
  if(th===3){ctx.strokeStyle="rgba(70,45,20,0.25)";ctx.beginPath();for(y=0;y<24;y++)for(x=0;x<14;x+=2){if(y<V.y0||y>V.y1)continue;var e=P(x+((y&1)?1:0),y,0),f=P(x+((y&1)?1:0),y+1,0);ctx.moveTo(e[0],e[1]);ctx.lineTo(f[0],f[1]);}ctx.stroke();}
  /* soft ambient-occlusion along the back walls */
  var g0=P(0,0,0),g1=P(26,0,0),g2=P(26,0.7,0),g3=P(0,0.7,0);poly([g0,g1,g2,g3],"rgba(0,0,0,0.10)");poly([P(0,0,0),P(0.7,0,0),P(0.7,24,0),P(0,24,0)],"rgba(0,0,0,0.10)");
}
function drawBackWalls(sim){var s=sim.s,th=s.decor.wall|0,Wc=WALLS[th]||WALLS[0],i;
  /* kitchen north wall (x 0..15) + west wall (y 0..24) */
  wallQuad("N",0,15,0,WALLH,Wc[0],OUT);wallQuad("W",0,24,0,WALLH,shade(Wc[0],0.86),OUT);
  wallQuad("N",0,15,0,0.9,Wc[1],null);wallQuad("W",0,24,0,0.9,shade(Wc[1],0.86),null);
  if(th===1){for(i=0;i<15;i+=0.5)wallQuad("N",i,i+0.25,0.9,WALLH,shade(Wc[0],0.93),null);for(i=0;i<24;i+=0.5)wallQuad("W",i,i+0.25,0.9,WALLH,shade(Wc[0],0.8),null);}
  if(th===2){ctx.strokeStyle="rgba(150,90,90,0.4)";for(i=1;i<15;i++)line(wallPt("N",i,0.9),wallPt("N",i,WALLH),"rgba(150,90,90,0.35)");for(i=1;i<24;i++)line(wallPt("W",i,0.9),wallPt("W",i,WALLH),"rgba(150,90,90,0.35)");for(var hh=1.2;hh<WALLH;hh+=0.3){line(wallPt("N",0,hh),wallPt("N",15,hh),"rgba(150,90,90,0.3)");line(wallPt("W",0,hh),wallPt("W",24,hh),"rgba(150,90,90,0.3)");}}
  if(th===3){for(i=0.5;i<15;i+=2)wallQuad("N",i,i+1.4,1.1,2.1,shade(Wc[0],1.12),"rgba(0,0,0,0.25)");for(i=0.5;i<24;i+=2)wallQuad("W",i,i+1.4,1.1,2.1,shade(Wc[0],1.0),"rgba(0,0,0,0.25)");}
  line(wallPt("N",0,0.9),wallPt("N",15,0.9),"rgba(255,255,255,0.35)",1.5);line(wallPt("W",0,0.9),wallPt("W",24,0.9),"rgba(255,255,255,0.3)",1.5);
  /* top trim */
  poly([P(0,0,WALLH),P(15,0,WALLH),P(15,-0.15,WALLH),P(-0.15,-0.15,WALLH),P(-0.15,24,WALLH),P(0,24,WALLH)],"#5b4636",OUT);
  /* wash room north wall: white tiles */
  wallQuad("N",15,26,0,WALLH,"#dfe9ec",OUT);for(i=15.5;i<26;i+=0.5)line(wallPt("N",i,0),wallPt("N",i,WALLH),"rgba(90,120,130,0.25)");for(var h2=0.3;h2<WALLH;h2+=0.3)line(wallPt("N",15,h2),wallPt("N",26,h2),"rgba(90,120,130,0.25)");
  poly([P(15,0,WALLH),P(26,0,WALLH),P(26.15,-0.15,WALLH),P(15,-0.15,WALLH)],"#6d7f86",OUT);
  /* the ship hole at the canal end */
  /* 2.0.2 t1242: the old dark doorway in the wall at the canal end is hidden (the canal now ends in a floor drain, drawDrain) */
  if(D.wallHole){wallQuad("N",25.05,25.95,0,1.0,"#0d1418","#000");txt("SHIP",sx(25.5,0),sy(25.5,0,1.25),8,"#ffe9a8");}
  /* the free wall outlet */
  var oy=FIX.outlet.y;wallQuad("W",oy+0.25,oy+0.75,0.35,0.75,"#f4f1e8","#555");
  var hp=wallPt("W",oy+0.4,0.5,0.04),hq=wallPt("W",oy+0.6,0.5,0.04);ctx.fillStyle="#333";ctx.fillRect(hp[0]-Z,hp[1]-2*Z,1.5*Z,3*Z);ctx.fillRect(hq[0]-Z,hq[1]-2*Z,1.5*Z,3*Z);
}
/* the only moving bits of the back walls (drawn live over the cached layer) */
function drawWallAnim(){var dr=(T*2)%1;if(D.wallHole)line(wallPt("N",25.3,0.05,0.05),wallPt("N",25.3,0.05+dr*0.2,0.05),"#9fd8ff",1.5);
  var oy=FIX.outlet.y,lp=wallPt("W",oy+0.5,0.68,0.05);ctx.fillStyle="#5fd47e";ctx.fillRect(lp[0]-Z,lp[1]-Z,2*Z,2*Z);}   /* 2.0.2: steady LED, no blinking */
/* static layer cache: floor + back walls never move, so they are drawn once per zoom/theme into an offscreen canvas and blitted 1:1 (no scaling) */
var BG={c:null,key:"",pend:"",pendN:0,ox:0,oy:0};
function bgLayer(sim,V){var s=sim.s,dpr=D.dpr||1,key=Z.toFixed(4)+"|"+dpr+"|"+(s.decor.floor|0)+"|"+(s.decor.wall|0);
  var pad=8,cwv=2*(27*32*Z+pad),chv=2*(WALLH*ZP*Z+18*Z+pad),wpx=Math.ceil(cwv*dpr),hpx=Math.ceil((chv/2+51*16*Z+pad)*dpr);
  var ok=wpx<=4096&&hpx<=4096&&wpx*hpx<=9e6&&typeof document!=="undefined";
  if(ok&&BG.key!==key){if(BG.pend===key)BG.pendN++;else{BG.pend=key;BG.pendN=0;}
    if(BG.pendN>=2){/* zoom has settled: rebuild */
      var c=BG.c||document.createElement("canvas");if(c.width!==wpx)c.width=wpx;if(c.height!==hpx)c.height=hpx;var g=c.getContext("2d");g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,wpx,hpx);g.setTransform(dpr,0,0,dpr,0,0);
      var sv=[ctx,CW,CH,CX,CY,cam.x,cam.y];ctx=g;CW=cwv;CH=chv;CX=0;CY=0;NOGROUND=true;
      drawFloor(sim,{x0:0,x1:W,y0:0,y1:H});drawBackWalls(sim);
      NOGROUND=false;ctx=sv[0];CW=sv[1];CH=sv[2];CX=sv[3];CY=sv[4];cam.x=sv[5];cam.y=sv[6];BG.c=c;BG.key=key;}}
  if(ok&&BG.key===key){ctx.fillStyle="#1d1a18";ctx.fillRect(0,0,CW,CH);
    /* world origin in the cache vs on screen, in device pixels, rounded so the blit stays 1:1 */
    var dx=Math.round((sx(0,0)-cwv/2)*dpr),dy=Math.round((sy(0,0,0)-chv/2)*dpr);
    ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(BG.c,dx,dy);ctx.restore();return true;}
  drawFloor(sim,V);drawBackWalls(sim);return false;}
/* the pool and canal are cut INTO the floor: stone coping flush with the tiles (h=0), inner walls on the far sides, water a little lower.
   Nothing overhangs a neighbouring tile. */
var WL=-0.1,COPE=0.1;
function wet(x,y){return S.isWater(x,y);}
function drawWater(sim,V){var i,x,y,tiles=[],pl=FIX.pool;
  for(x=pl.x;x<pl.x+pl.w;x++)for(y=pl.y;y<pl.y+pl.h;y++)tiles.push([x,y]);S.CANAL_TILES.forEach(function(t){tiles.push([t[0],t[1]]);});
  var inner=tiles.map(function(t){var x=t[0],y=t[1];return [x+(wet(x-1,y)?0:COPE),y+(wet(x,y-1)?0:COPE),x+1-(wet(x+1,y)?0:COPE),y+1-(wet(x,y+1)?0:COPE),x,y];});
  /* far inner walls (north + west faces of the pit) */
  inner.forEach(function(r){var x=r[4],y=r[5];
    if(!wet(x,y-1))poly([P(r[0],r[1],0),P(r[2],r[1],0),P(r[2],r[1],WL),P(r[0],r[1],WL)],"#56646a");
    if(!wet(x-1,y))poly([P(r[0],r[1],0),P(r[0],r[3],0),P(r[0],r[3],WL),P(r[0],r[1],WL)],"#46535a");});
  /* water surface: one path, one fill */
  ctx.beginPath();inner.forEach(function(r){var a=P(r[0],r[1],WL),b=P(r[2],r[1],WL),c=P(r[2],r[3],WL),d=P(r[0],r[3],WL);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(d[0],d[1]);ctx.closePath();});
  var g0=P(pl.x,pl.y,WL),g1=P(pl.x+pl.w,pl.y+pl.h,WL),wg=ctx.createLinearGradient(g0[0],g0[1],g1[0],g1[1]);wg.addColorStop(0,"#3b8fba");wg.addColorStop(1,"#256d94");ctx.fillStyle=wg;ctx.fill();
  /* a soft dark band where the water meets the far walls */
  inner.forEach(function(r){var x=r[4],y=r[5];if(!wet(x,y-1))poly([P(r[0],r[1],WL),P(r[2],r[1],WL),P(r[2],r[1]+0.12,WL),P(r[0],r[1]+0.12,WL)],"rgba(10,40,60,0.28)");
    if(!wet(x-1,y))poly([P(r[0],r[1],WL),P(r[0]+0.12,r[1],WL),P(r[0]+0.12,r[3],WL),P(r[0],r[3],WL)],"rgba(10,40,60,0.22)");});
  /* stone coping, flush with the floor, only on dry sides (plus the little corner squares of inside corners) */
  ctx.beginPath();function q(a,b,c,d){var A=P(a,b,0),B=P(c,b,0),C=P(c,d,0),Dd=P(a,d,0);ctx.moveTo(A[0],A[1]);ctx.lineTo(B[0],B[1]);ctx.lineTo(C[0],C[1]);ctx.lineTo(Dd[0],Dd[1]);ctx.closePath();}
  tiles.forEach(function(t){var x=t[0],y=t[1];if(!wet(x,y-1))q(x,y,x+1,y+COPE);if(!wet(x,y+1))q(x,y+1-COPE,x+1,y+1);if(!wet(x-1,y))q(x,y,x+COPE,y+1);if(!wet(x+1,y))q(x+1-COPE,y,x+1,y+1);
    [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(function(d){if(wet(x+d[0],y)&&wet(x,y+d[1])&&!wet(x+d[0],y+d[1])){var cx=d[0]<0?x:x+1-COPE,cy=d[1]<0?y:y+1-COPE;q(cx,cy,cx+COPE,cy+COPE);}});});
  ctx.fillStyle="#8d9a9e";ctx.fill();ctx.strokeStyle="rgba(40,50,55,0.35)";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();
  /* ripples + current */
  for(i=0;i<6;i++){var ph=(T*0.5+i/6)%1;isoCirc(pl.x+0.8+(i%3)*0.8,pl.y+0.8+((i/3)|0)*2,WL+0.01,0.15+ph*0.35,null,"rgba(200,235,255,"+(0.35*(1-ph))+")");}
  var flow=sim.s.flowOff?0:([0.55,1.0,1.7][sim.up("channel")]||0.55),RL=S.SHIP_C-0.45;
  for(i=0;i<22;i++){var c=((T*flow+i*RL/22)%RL+RL)%RL,p=sim.canalPos(c),o=(i%3-1)*0.22;
    var a=c<=5.5?P(p.x-0.2,p.y+o,WL+0.01):P(p.x+o,p.y+0.2,WL+0.01),b=c<=5.5?P(p.x+0.2,p.y+o,WL+0.01):P(p.x+o,p.y-0.2,WL+0.01);line(a,b,"rgba(210,240,255,0.45)",1);}
  drawDrain(sim);
  /* 2.0.2: the SHIPPING machine's spout only splashes when a potato actually drops in (no constant stream) */
  var sk=sim.s.t-(sim.s.landT==null?-99:sim.s.landT);if(sk>=0&&sk<0.6){var f2=sk/0.6;isoCirc(17.6,14.9,WL+0.01,0.12+f2*0.4,null,"rgba(255,255,255,"+(0.7*(1-f2))+")",1.5);}
}
/* the basin heap (0.4.11 look): peeled potatoes the SHIPPING machine spits out pile up in a mound under its spout and wait for Papa */
function drawHeap(sim){var pots=sim.s.pots.filter(function(q){return q.m==="pool";});if(!pots.length)return;var n=pots.length,HP=S.HEAP;
  var sh=0.55+0.35*Math.min(1,n/48);ctx.globalAlpha=0.34+0.16*Math.min(1,n/40);isoCirc(HP.x+0.05,HP.y+0.08,WL+0.005,0.9*sh+0.25,"#061018");ctx.globalAlpha=0.22;isoCirc(HP.x+0.1,HP.y+0.12,WL+0.005,0.55*sh+0.15,"#040c12");ctx.globalAlpha=1;
  pots.slice().sort(function(a,b){var ha=a.hl||0,hb=b.hl||0;return (a.x+a.y+ha*3)-(b.x+b.y+hb*3);}).forEach(function(q){var lift=q.hl||0,base=lift<0.04,bob=base?Math.sin(T*2.3+q.u)*0.012:0;
    if(base){ctx.globalAlpha=0.35;ell(q.x,q.y,WL+0.005,7,3,"rgba(255,255,255,0.5)");ctx.globalAlpha=1;}potato(q.x,q.y,WL+0.02+lift+bob,q,((q.u*37)%10)/10-0.5);});
  /* light surface film around the base */
  ctx.globalAlpha=0.14;isoCirc(HP.x,HP.y,WL+0.01,0.95,"#165a7c");ctx.globalAlpha=1;}
/* low cut-away walls: the shared wall (x=14), the front walls. Returns drawables for depth sorting. */
function lowWalls(sim,list){var key=sim.key(),y;
  for(y=0;y<24;y++){if(y===3||y===4||y===14||y===15)continue;(function(y){list.push({d:14.5+y+0.5,nh:1,wx:14.5,wy:y+0.5,f:function(){box(14.2,y,0.6,1,0,0.3,"#6f6a64",{top:"#8c867e"});}});})(y);}
  /* door frame + sliding metal door */
  list.push({d:14.5+5.2,f:function(){if(D.editView)ctx.globalAlpha=0.45;var p=sim.s.papa,near=Math.hypot(p.x-14.5,p.y-4)<2.2,open=key&&near;
    sim._door=sim._door==null?0:sim._door;sim._door+=((open?1:0)-sim._door)*0.18;var o=sim._door;
    box(14.15,2.85,0.7,0.15,0,1.25,"#5a5f66");box(14.15,5.0,0.7,0.15,0,1.25,"#5a5f66");
    box(14.3,3+o*1.9,0.4,2-o*1.9>0.05?2-o*1.9:0.05,0,1.1,key?"#8d99a6":"#7c6f6a",{top:key?"#aab6c2":"#968983"});
    var lp=P(14.5,2.9,1.35);ctx.beginPath();ctx.arc(lp[0],lp[1],2.4*Z,0,6.2832);ctx.fillStyle=key?(open?"#7dff9a":"#3bd16a"):"#e0483c";ctx.fill();
    if(!key){var lk=P(14.5,4.0,0.6);ctx.fillStyle="#e0b84a";ctx.fillRect(lk[0]-3*Z,lk[1]-2*Z,6*Z,5*Z);ctx.strokeStyle="#e0b84a";ctx.lineWidth=Math.max(1,1.2*Z);ctx.beginPath();ctx.arc(lk[0],lk[1]-2*Z,2.2*Z,Math.PI,0);ctx.stroke();txt("KEY",lk[0],lk[1]-9*Z,7,"#ffe9a8");}ctx.globalAlpha=1;}});
  /* kitchen south wall, wash south + east walls (front, low) */
  /* front walls are only a curb so they never hide the canal, the pool or Papa */
  list.push({d:100,f:function(){var F=0.16;box(0,24,14.8,0.2,0,F,"#6f6a64",{top:"#8c867e"});box(14.8,16,11.4,0.2,0,F,"#6f6a64",{top:"#8c867e"});box(26,0,0.2,16.2,0,F,"#6f6a64",{top:"#8c867e"});}});
}
D.toWorld=toWorld;D.P=P;D.cam=cam;
/* ---------- fixed things ---------- */
/* 2.0.2: the raw pile is the 0.4.11 pile, copied exactly (Jay t1236: same spot, size and look).
   0.4.11 kitchen: 108 x 280 units, walls 7 thick; pile cx 54, base 258, rx 45, rz 14 against the bottom wall; tiers of 100*sc^2 (sc = 1-0.095t),
   R2 low-discrepancy spread, jitter, LIFT 1.1 a tier (capped at 9), sprite sizes 2.9/3.3/3.7, light ramp by tier (LVF), soft shadow under tier 0,
   drawn tier by tier, then by depth. Here the interior (x 7..101) maps onto kitchen x 0..14 and the bottom wall (y 273) onto y 24, one scale for both axes.
   The return chute is the 0.4.11 one too: a pipe out of the right wall at the back of the pile, mouth at x 86 -> 11.8. (2.0.1 pile code kept below, hidden.) */
var U2T=14/94,PX_U=3.6,LIFT_H=0.15,LVF=[0.72,0.84,0.96,1.08,1.18,1.28],P11=null,SPR11=null,pileCache={key:"",c:null};
function u2x(xu){return (xu-7)*U2T;}function u2y(zu){return 24-(273-zu)*U2T;}
function srng11(n){var v=(n*1664525+1013904223)>>>0;return (v%10000)/10000;}
function pile11(){if(P11)return P11;var cx=54,base=258,rx0=45,rz0=14,idx=0,out=[],PILEMAX=800;
  for(var t=0;idx<PILEMAX;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(100*sc*sc):90;
    for(var j=0;j<cap;j++,idx++){var r=Math.sqrt(((j+0.5)*0.7548776662)%1),th=(((j+0.5)*0.5698402910)%1)*6.28318+t*1.3;
      var xu=cx+rx0*sc*r*Math.cos(th)+(srng11(idx*5+2)-0.5)*3,zu=base+rz0*sc*r*Math.sin(th)+(srng11(idx*3+7)-0.5)*2.2;
      out.push({x:u2x(xu),y:u2y(zu),h:Math.min(t,9)*LIFT_H,t:t,vi:idx%3,fl:(idx*7)%2,i:idx});}}
  var ord=out.map(function(p,i){return i;});ord.sort(function(a,b){var A=out[a],B=out[b];return A.t!==B.t?A.t-B.t:(A.x+A.y)-(B.x+B.y);});
  P11={pos:out,ord:ord,n:out.length};return P11;}
function shadeHex11(h,f){var n=parseInt(h.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function c(v){v=Math.round(v*f);return Math.max(0,Math.min(255,v));}return "rgb("+c(r)+","+c(g)+","+c(b)+")";}
/* the 0.4.11 potato() sprite (disc with outline, highlight, eyes), at the iso pixel scale */
function potato11(g,x,y,sz,flip,pal){var out=pal[0],dk=pal[1],md=pal[2],hi=pal[3],hw=Math.max(1.2,sz),hh=Math.max(0.9,sz*0.72),fx=flip?1:-1,k=Math.max(0.6,Z);
  function ov(cx,cy,rw,rh,c){g.fillStyle=c;g.beginPath();g.ellipse(cx,cy,Math.max(0.35,rw),Math.max(0.35,rh),0,0,6.283185);g.fill();}
  ov(x+0.7*k,y+0.7*k,hw+0.3*k,hh+0.2*k,"rgba(0,0,0,0.22)");ov(x,y,hw+0.7*k,hh+0.7*k,"#1a1410");ov(x,y,hw,hh,md);
  ov(x+fx*hw*0.16,y-hh*0.18,hw*0.62,hh*0.5,hi);ov(x+fx*hw*0.28,y-hh*0.32,hw*0.28,hh*0.22,hi);
  ov(x+fx*hw*0.12,y+hh*0.05,Math.max(0.5,hw*0.12),Math.max(0.5,hh*0.12),dk);ov(x-fx*hw*0.28,y+hh*0.18,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),out);
  if(sz>3)ov(x+fx*hw*0.35,y-hh*0.08,Math.max(0.45,hw*0.1),Math.max(0.45,hh*0.1),"#6a4020");}
function sprites11(){var dp=D.dpr||1,key=Z.toFixed(3)+"/"+dp;if(SPR11&&SPR11.key===key)return SPR11;SPR11={key:key,s:{}};var sizes=[2.9,3.3,3.7],base=D.pileWarm===false?["#4a2810","#6a4020","#8a5a28","#c48a48"]:["#5a3010","#8a5222","#b8782e","#e8aa5c"];   /* 2.0.2 t1240: warmer, closer to 0.4.11's orange-gold (old browner set kept behind D.pileWarm=false) */
  for(var vi=0;vi<3;vi++){var sp=Math.max(3,sizes[vi]*PX_U*Z),hw=sp,hh=sp*0.72,w=Math.ceil(2*hw+6*Z+4),h=Math.ceil(2*hh+7*Z+4);
    for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++)for(var sh=0;sh<2;sh++){var f=LVF[lv],pal=[shadeHex11(base[0],f*0.9),shadeHex11(base[1],f),shadeHex11(base[2],f),shadeHex11(base[3],f)];
      var c=document.createElement("canvas");c.width=Math.ceil(w*dp);c.height=Math.ceil(h*dp);var g=c.getContext("2d");g.scale(dp,dp);var X=w/2,Y=h/2;
      if(sh){g.fillStyle="rgba(0,0,0,0.20)";g.beginPath();g.ellipse(X+Z,Y+Z,hw+Z,hh,0,0,6.283);g.fill();}
      potato11(g,X,Y,sp,!!fl,pal);c.cw=w;c.ch=h;c.ax=X;c.ay=Y+hh*0.55;SPR11.s[vi+"/"+lv+"/"+fl+"/"+sh]=c;}}
  return SPR11;}
function spr11(q){var lv=Math.min(4,2+Math.floor(q.t/3));return sprites11().s[q.vi+"/"+lv+"/"+q.fl+"/"+(q.t===0?1:0)];}
function floorEll(cx,cy,rx,ry,c){ctx.beginPath();for(var i=0;i<=24;i++){var a=i/24*6.2832,p=P(cx+Math.cos(a)*rx,cy+Math.sin(a)*ry,0.004);if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}ctx.closePath();ctx.fillStyle=c;ctx.fill();}
/* 0.4.11 shallow wooden bay against the bottom wall: a thin strip with side rails and corner posts (potatoes draw on top) */
function drawPileBay(){var x0=u2x(54-45-2),x1=u2x(54+45+2),y0=u2y(258+14-3),y1=24;
  poly([P(x0,y0,0.004),P(x1,y0,0.004),P(x1,y1,0.004),P(x0,y1,0.004)],"rgba(40,30,16,0.16)");
  box(x0,y0,0.24,y1-y0,0,0.1,"#4a3018",{top:"#8a6a40"});box(x1-0.24,y0,0.24,y1-y0,0,0.1,"#3a200c",{top:"#5a3a18"});}
function drawPileFront(){var x0=u2x(54-45-2),x1=u2x(54+45+2),y1=24,t=2.2*U2T;
  box(x0,y1-t,x1-x0,t,0,0.12,"#3a200c",{top:"#8a6a40"});box(x0-0.06,y1-0.48,0.33,0.48,0,0.2,"#3a200c",{top:"#8a6a40"});box(x1-0.27,y1-0.48,0.33,0.48,0,0.2,"#3a200c",{top:"#8a6a40"});}
function drawPileShadow(){floorEll(u2x(54),u2y(259),(45+4)*U2T,(14+2)*U2T,"rgba(40,30,16,0.22)");floorEll(u2x(54),u2y(260),(45-4)*U2T,(14-2)*U2T,"rgba(30,22,10,0.16)");}
/* 2.0.1/early-2.0.2 return chute on the east wall, kept hidden (Jay t1240: the chute goes back on the other side of the pile) */
var RET201={mx:u2x(86),y:u2y(244),w:9*U2T,h0:0.3};
function drawReturnChuteEast(sim){var x0=RET201.mx,x1=14,yc=RET201.y,hw=RET201.w/2,h0=RET201.h0,hh=0.5;
  box(x1-0.1,yc-hw-0.14,0.1,RET201.w+0.28,h0-0.12,hh+0.24,"#4a5250",{top:"#8a9490",left:"#5a6461"});
  box(x0,yc-hw,x1-0.1-x0,RET201.w,h0,hh,"#8e9b96",{top:"#c4d0ca",left:"#9aa7a2",right:"#5d6865"});}
/* 2.0.2 return chute (Jay t1240): mirrored to the OTHER (west) side of the pile like 0.4.11 had it on the opposite end;
   a round ribbed steel pipe out of the west wall with a flared mouth facing east toward the heap, green arrows pointing out */
var RET={mx:14-u2x(86),y:u2y(244),w:9*U2T,h0:0.3,r:0.27};
function drawReturnChute(sim){var x0=0,x1=RET.mx,yc=RET.y,r=RET.r,hc=RET.h0+r,T=2*r*53*Z,k=Math.max(0.6,Z);
  var a=P(x0+0.06,yc,hc),b=P(x1,yc,hc),dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L;
  function ring(xq,rr,fill,st,lw,dx2,half){ctx.beginPath();for(var i=0;i<=20;i++){var t=half?-0.79+i/20*3.1416:i/20*6.2832,pp=P(xq,yc+Math.cos(t)*rr,hc+Math.sin(t)*rr);pp[0]+=dx2||0;if(i)ctx.lineTo(pp[0],pp[1]);else ctx.moveTo(pp[0],pp[1]);}if(!half)ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(st){ctx.lineWidth=lw||k;ctx.strokeStyle=st;ctx.stroke();}}
  function seg(off,w,c){ctx.beginPath();ctx.moveTo(a[0],a[1]+off);ctx.lineTo(b[0],b[1]+off);ctx.lineWidth=w;ctx.strokeStyle=c;ctx.stroke();}
  ctx.save();ctx.lineCap="butt";
  var s0=P(x0,yc+0.15,0.004),s1=P(x1+0.1,yc+0.15,0.004);ctx.beginPath();ctx.moveTo(s0[0],s0[1]);ctx.lineTo(s1[0],s1[1]);ctx.lineWidth=T*0.7;ctx.strokeStyle="rgba(30,22,10,0.22)";ctx.stroke();
  ring(x0+0.04,r*1.45,"#4a5250",OUT);
  seg(0,T+2*k,OUT);seg(0,T,"#8e9b96");seg(T*0.28,T*0.42,"#6a7672");seg(-T*0.24,T*0.3,"#c8d4ce");seg(-T*0.3,T*0.1,"#eef5f1");
  for(var q=0.28;q<0.9;q+=0.22)ring(x0+(x1-x0)*q,r*1.04,null,"#55605d",Math.max(1,1.8*Z),0,true);
  for(var n=0;n<2;n++){var ax=x0+(x1-x0)*(0.38+n*0.24),hz=hc+r*0.95,p1=P(ax+0.16,yc,hz);line(P(ax-0.14,yc,hz),p1,"#2fd36a",2);line(p1,P(ax+0.02,yc-0.1,hz),"#2fd36a",2);line(p1,P(ax+0.02,yc+0.1,hz),"#2fd36a",2);}
  ring(x1,r*1.3,"#9aa7a2",OUT);ring(x1+0.01,r*0.92,"#0e1418",null,0,ux*0.6*k);
  ctx.restore();}
/* the chute's light: green while potatoes are coming back (drawn every frame over the cached layer) */
function retLed(sim){var lit=sim.s.ret.length>0,lp=P(0.45,RET.y+RET.r*0.9,RET.h0+RET.r*1.7);ctx.fillStyle=lit?"#40ff70":"#1d5a2c";ctx.fillRect(lp[0]-1.2*Z,lp[1]-1.2*Z,2.5*Z,2.5*Z);}
function drawPile(sim){var s=sim.s,L=pile11(),n=Math.max(0,Math.min(s.pile,L.n)),pos=L.pos;
  /* one cached layer: shadow, bay, return chute, the heap and the front rail. Redrawn only when the count (or zoom) changes, so a frame is one drawImage */
  var dp=D.dpr||1,o0=P(0,0,0),key=n+"/"+Z.toFixed(3)+"/"+dp;
  if(pileCache.key!==key){var X0=sx(0,24)-o0[0]-24*Z,X1=sx(14,19)-o0[0]+24*Z,Y0=sy(0,19,1.2)-o0[1]-24*Z,Y1=sy(14,24,0)-o0[1]+24*Z,w=Math.ceil(X1-X0),h=Math.ceil(Y1-Y0);
    var c=pileCache.c||document.createElement("canvas");var cw=Math.ceil(w*dp),ch=Math.ceil(h*dp);if(c.width!==cw)c.width=cw;if(c.height!==ch)c.height=ch;var g=c.getContext("2d");g.setTransform(dp,0,0,dp,0,0);g.clearRect(0,0,w,h);
    var keepCtx=ctx,cw0=CW,ch0=CH;ctx=g;CW=cw0-2*(o0[0]+X0);CH=ch0-2*(o0[1]+Y0);
    try{drawPileShadow();drawPileBay();drawReturnChute(sim,true);
      for(var q=0;q<L.ord.length;q++){var i=L.ord[q];if(i>=n)continue;var pp=pos[i],sp=spr11(pp),a=P(pp.x,pp.y,pp.h);g.drawImage(sp,a[0]-sp.ax,a[1]-sp.ay,sp.cw,sp.ch);}
      drawPileFront();}finally{ctx=keepCtx;CW=cw0;CH=ch0;}
    pileCache={key:key,c:c,ox:X0,oy:Y0,w:w,h:h};D.pileRenders=(D.pileRenders||0)+1;}
  ctx.drawImage(pileCache.c,o0[0]+pileCache.ox,o0[1]+pileCache.oy,pileCache.w,pileCache.h);
  retLed(sim);
  /* potatoes coming back out of the return chute: out of the mouth, tumble, bounce, roll onto their slot */
  for(var k=0;k<s.ret.length;k++){var Lt=s.ret[k],ph=1-(Lt-s.t)/0.7;if(ph<0||ph>1)continue;var q2=pos[Math.min(pos.length-1,n+k)],e=ph<0.7?ph/0.7:1,bx=RET.mx+0.1+(q2.x-RET.mx-0.1)*e,by=RET.y+(q2.y-RET.y)*e;
    var hgt=ph<0.7?(RET.h0+RET.r)+(q2.h-RET.h0-RET.r)*e+Math.sin(e*Math.PI)*0.3:q2.h+Math.abs(Math.sin((ph-0.7)/0.3*Math.PI))*0.08*(1-ph);var sp2=spr11(q2),a2=P(bx,by,hgt);
    ctx.save();ctx.translate(a2[0],a2[1]-sp2.ay+sp2.ch/2);ctx.rotate(ph*7);ctx.drawImage(sp2,-sp2.cw/2,-sp2.ch/2,sp2.cw,sp2.ch);ctx.restore();}
  /* 0.4.11 had no label on the pile; kept hidden (tap the pile for its count) */
  if(D.pileLabel){var sg=P(u2x(54),24,0.1);txt("RAW PILE "+n,sg[0],sg[1]+26*Z,8,"#ffe9a8");}
}
D.pile11=pile11;D.U2T=U2T;
/* ---- 2.0.1 pile (hidden, not deleted) ---- */
/* the raw pile, 0.4.11 look: stacked tiers in a shallow wooden bay. Slot order is an R2 low-discrepancy spread, so even a small pile
   lies wide along the floor and it rises as it fills. Lit by tier on a fixed ramp; only the bottom tier casts a soft shadow.
   Rendered to a cached layer that only redraws when the count changes. Returns come down a pipe in the west wall and roll onto their slot. */
var LVF201=[0.60,0.74,0.90,1.08,1.25,1.42],PILE_POS=null,PSPR=null,pileCache201={key:"",c:null};
function pileSlots201(){if(PILE_POS)return PILE_POS;var pl=FIX.pile,cx=pl.x+pl.w/2+0.05,cy=pl.y+pl.h/2+0.1,rx=pl.w/2-0.5,ry=pl.h/2-0.5,out=[],idx=0,t,j;
  function sr(n){var x=Math.sin(n*12.9898)*43758.5453;return x-Math.floor(x);}
  for(t=0;idx<S.C.potTotal+8;t++){var sc=t<10?1-0.095*t:0.55,cap=t<10?Math.round(24*sc*sc):8;
    for(j=0;j<cap;j++,idx++){var r=Math.sqrt(((j+0.5)*0.7548776662)%1),th=(((j+0.5)*0.5698402910)%1)*6.28318+t*1.3;
      out.push({x:cx+rx*sc*r*Math.cos(th)+(sr(idx*5+2)-0.5)*0.12,y:cy+ry*sc*r*Math.sin(th)+(sr(idx*3+7)-0.5)*0.1,h:0.05+Math.min(t,9)*0.11,t:t,vi:idx%3,fl:(idx*7)%2});}}
  PILE_POS=out;return out;}
function rawPal201(f){return [shade("#4a2810",f*0.9),shade("#6a4020",f),shade("#8a5a28",f),shade("#c48a48",f)];}
function pileSprites201(){var dp=D.dpr||1,key=Z.toFixed(3)+"/"+dp;if(PSPR&&PSPR.key===key)return PSPR;PSPR={key:key,s:{}};
  [1.12,1.22,1.32].forEach(function(sz,vi){for(var lv=0;lv<6;lv++)for(var fl=0;fl<2;fl++)for(var sh=0;sh<2;sh++){var r=6.0*Z*sz,ry=r*0.72,w=Math.ceil(r*2+6),h=Math.ceil(ry*2+7),c=document.createElement("canvas");c.width=Math.ceil(w*dp);c.height=Math.ceil(h*dp);
    var g=c.getContext("2d");g.scale(dp,dp);var pal=rawPal201(LVF201[lv]),X=w/2,Y=h/2-1;
    if(sh){g.fillStyle="rgba(0,0,0,0.22)";g.beginPath();g.ellipse(X+1,Y+ry*0.55,r*1.02,ry*0.7,0,0,6.283);g.fill();}
    g.save();g.translate(X,Y);g.rotate(fl?0.35:-0.25);g.beginPath();g.ellipse(0,0,r,ry,0,0,6.283);g.fillStyle=pal[0];g.fill();
    g.beginPath();g.ellipse(-r*0.04,-ry*0.06,r*0.9,ry*0.84,0,0,6.283);g.fillStyle=pal[1];g.fill();
    g.beginPath();g.ellipse(-r*0.16,-ry*0.2,r*0.62,ry*0.56,0,0,6.283);g.fillStyle=pal[2];g.fill();
    g.beginPath();g.ellipse(-r*0.36,-ry*0.38,r*0.24,ry*0.18,-0.3,0,6.283);g.fillStyle=pal[3];g.fill();
    g.fillStyle=pal[0];var e=Math.max(1,Z*1.1);g.fillRect(r*0.28,ry*0.12,e,e);g.fillRect(-r*0.1,ry*0.34,e,e);g.fillRect(r*0.02,-ry*0.4,e,e);g.restore();
    c.cw=w;c.ch=h;c.ax=X;c.ay=Y+ry*0.6;PSPR.s[vi+"/"+lv+"/"+fl+"/"+sh]=c;}});return PSPR;}
function pileSpr201(q){var lv=Math.min(4,2+Math.floor(q.t/3));return pileSprites201().s[q.vi+"/"+lv+"/"+q.fl+"/"+(q.t===0?1:0)];}
function drawPileBay201(){var pl=FIX.pile,x0=pl.x,y0=pl.y,x1=pl.x+pl.w,y1=pl.y+pl.h,b=0.12,hh=0.12;
  poly([P(x0,y0,0.005),P(x1,y0,0.005),P(x1,y1,0.005),P(x0,y1,0.005)],"rgba(40,30,16,0.16)");
  box(x0,y0,pl.w,b,0,hh,"#4a3018",{top:"#8a6a40"});box(x0,y0+b,b,pl.h-b,0,hh,"#4a3018",{top:"#8a6a40"});}
function drawPileFront201(){var pl=FIX.pile,x0=pl.x,y0=pl.y,x1=pl.x+pl.w,y1=pl.y+pl.h,b=0.12,hh=0.12;
  box(x1-b,y0+b,b,pl.h-b,0,hh,"#3a200c",{top:"#8a6a40"});box(x0+b,y1-b,pl.w-2*b,b,0,hh,"#3a200c",{top:"#8a6a40"});
  [[x0,y0],[x1-0.2,y0],[x0,y1-0.2],[x1-0.2,y1-0.2]].forEach(function(c){box(c[0],c[1],0.2,0.2,0,0.22,"#3a200c",{top:"#8a6a40"});});}
function drawPile201(sim){var pl=FIX.pile,s=sim.s,n=Math.max(0,Math.min(s.pile,S.C.potTotal)),pos=pileSlots201();
  ctx.fillStyle="rgba(40,30,16,0.22)";isoCirc(pl.x+pl.w/2,pl.y+pl.h/2+0.1,0.01,1.9,"rgba(40,30,16,0.22)");
  drawPileBay201();
  /* return pipe in the west wall */
  box(0,20.55,0.5,0.9,0.5,0.5,"#7d8a94",{top:"#9aa8b2"});var mo=[P(0.5,20.65,0.58),P(0.5,21.35,0.58),P(0.5,21.35,0.92),P(0.5,20.65,0.92)];poly(mo,"#121a20","#000");
  /* the heap layer: redrawn only when the count (or zoom) changes */
  var dp=D.dpr||1,o0=P(0,0,0),key=n+"/"+Z.toFixed(3)+"/"+dp;
  if(pileCache201.key!==key){var w=Math.ceil((pl.w+pl.h)*32*Z+60),h=Math.ceil((pl.w+pl.h)*16*Z+70*Z+60),c=pileCache201.c||document.createElement("canvas");c.width=Math.ceil(w*dp);c.height=Math.ceil(h*dp);
    var g=c.getContext("2d");g.setTransform(dp,0,0,dp,0,0);g.clearRect(0,0,w,h);var ox=sx(pl.x,pl.y+pl.h)-o0[0]-30,oy=sy(pl.x,pl.y,0)-o0[1]-70*Z-30;
    var ord=[];for(var i=0;i<n;i++)ord.push(i);ord.sort(function(a,b){var A=pos[a],B=pos[b];return A.t!==B.t?A.t-B.t:(A.x+A.y)-(B.x+B.y);});
    ord.forEach(function(i){var q=pos[i],sp=pileSpr201(q),a=P(q.x,q.y,q.h);g.drawImage(sp,a[0]-o0[0]-ox-sp.ax,a[1]-o0[1]-oy-sp.ay,sp.cw,sp.ch);});
    pileCache201={key:key,c:c,ox:ox,oy:oy,w:w,h:h};}
  ctx.drawImage(pileCache201.c,o0[0]+pileCache201.ox,o0[1]+pileCache201.oy,pileCache201.w,pileCache201.h);
  /* potatoes coming back down the pipe: out of the mouth, arc, bounce, roll onto their slot */
  for(var k=0;k<s.ret.length;k++){var L=s.ret[k],ph=1-(L-s.t)/0.7;if(ph<0||ph>1)continue;var q2=pos[Math.min(pos.length-1,n+k)],e=ph<0.7?ph/0.7:1,bx=0.55+(q2.x-0.55)*e,by=21+(q2.y-21)*e;
    var hgt=ph<0.7?0.75+(q2.h-0.75)*e+Math.sin(e*Math.PI)*0.35:q2.h+Math.abs(Math.sin((ph-0.7)/0.3*Math.PI))*0.08*(1-ph);var sp2=pileSpr201(q2),a2=P(bx,by,hgt);
    ctx.save();ctx.translate(a2[0],a2[1]-sp2.ay+sp2.ch/2);ctx.rotate(ph*7);ctx.drawImage(sp2,-sp2.cw/2,-sp2.ch/2,sp2.cw,sp2.ch);ctx.restore();}
  drawPileFront201();
  var sg=P(pl.x+pl.w/2,pl.y+pl.h,0.1);txt("RAW PILE "+n,sg[0],sg[1]+6*Z,8,"#ffe9a8");
}
function drawChute(sim){var x=6,y=0;box(x,y,2,0.7,0,1.9,"#7d8a94");
  poly([P(x+0.25,y+0.7,0.55),P(x+1.75,y+0.7,0.55),P(x+1.75,y+0.7,1.35),P(x+0.25,y+0.7,1.35)],"#111a20","#000");
  for(var i=0;i<6;i++)poly([P(x+i/3,y+0.7,1.9),P(x+i/3+0.16,y+0.7,1.9),P(x+i/3+0.16,y+0.7,1.7),P(x+i/3,y+0.7,1.7)],i%2?"#222":"#f2c230");
  /* lip / funnel */
  poly([P(x+0.1,y+0.7,0.55),P(x+1.9,y+0.7,0.55),P(x+1.9,y+1.0,0.45),P(x+0.1,y+1.0,0.45)],"#9aa8b2",OUT);
  var fl=Math.sin(T*3)*0.08;poly([P(x+0.3,y+0.71,1.35),P(x+1.7,y+0.71,1.35),P(x+1.7,y+0.71+fl,1.0),P(x+0.3,y+0.71+fl,1.0)],"rgba(60,70,80,0.85)");
  var lp=P(x+1.85,y+0.7,1.6);ctx.beginPath();ctx.arc(lp[0],lp[1],2.2*Z,0,6.28);ctx.fillStyle=(Math.floor(T*1.5)%2)?"#7dff9a":"#2c6a3c";ctx.fill();
  var sg=P(x+1,y+0.7,2.15);txt("SHIP 2-4c",sg[0],sg[1],8,"#ffe9a8");}
function scanner(x,y,side,sim){box(x,y,2,2,0,1.9,"#5e6f7e");box(x+0.1,y+0.1,1.8,1.8,1.9,0.12,"#4b5966");
  /* screen on the south face with an x-ray potato */
  var s0=P(x+0.3,y+2,0.85),s1=P(x+1.7,y+2,0.85),s2=P(x+1.7,y+2,1.65),s3=P(x+0.3,y+2,1.65);poly([s0,s1,s2,s3],"#0d2a1c","#000");
  var sc=(T*0.7)%1,bx=P(x+0.3+sc*1.4,y+2,0.85),bt=P(x+0.3+sc*1.4,y+2,1.65);line(bx,bt,"rgba(120,255,170,0.8)",1.5);
  var mid=P(x+1,y+2,1.25);ctx.strokeStyle="rgba(140,255,190,0.85)";ctx.lineWidth=Math.max(0.7,Z);ctx.beginPath();ctx.ellipse(mid[0],mid[1],9*Z,6*Z,0,0,6.28);ctx.stroke();ctx.beginPath();ctx.ellipse(mid[0]-2*Z,mid[1],3*Z,2*Z,0,0,6.28);ctx.stroke();
  txt("X-RAY",P(x+1,y+2,1.78)[0],P(x+1,y+2,1.78)[1],7,"#bfffd6");
  if(side==="k"){/* input slot on the west face with rubber flaps */var a=P(x,y+0.6,0.45),b=P(x,y+1.4,0.45),c=P(x,y+1.4,0.95),d=P(x,y+0.6,0.95);poly([a,b,c,d],"#10161a","#000");
    for(var i=0;i<4;i++){var u=y+0.65+i*0.2,sw=Math.sin(T*6+i)*0.03;line(P(x-sw,u,0.95),P(x-sw,u+0.15,0.5),"#2d3338",2);}
    var key=sim.key();var lp=P(x+0.1,y+0.2,1.7);ctx.beginPath();ctx.arc(lp[0],lp[1],2.2*Z,0,6.28);ctx.fillStyle=key?"#7dff9a":"#ff5a4d";ctx.fill();}
  else{/* spout on the east face into the pool */box(x+2,y+0.7,0.2,0.6,0.7,0.12,"#7a8a96");}}
/* 2.0.2: ONE shipping machine built into the dividing wall (Jay t1237/t1238). Kitchen side: intake slot where Papa drops peeled potatoes.
   Wall section: a housing through the wall. Wash side: outlet with a spout that spits them into the pool, where they pile up and wait.
   It only moves when a potato goes through (flaps, light); otherwise it stands still. */
function shipBusy(sim){return sim.s.t-(sim.s.shipT==null?-99:sim.s.shipT);}
function drawShipK(sim){var key=sim.key(),bz=shipBusy(sim),act=bz>=0&&bz<0.6,x=13.05,y=14.08,STEEL="#6d7c88";
  shadow(13.5,15,0.9);
  /* housing through the wall (over the low wall line) */
  box(13.9,14.3,1.2,1.4,0.2,0.8,"#56636e",{top:"#7f8d98"});for(var r=0;r<3;r++)line(P(14.05+r*0.45,15.7,0.25),P(14.05+r*0.45,15.7,0.95),"rgba(20,26,30,0.45)",1);
  box(x,y,0.95,1.84,0,1.15,STEEL,{top:"#90a0ab"});
  /* yellow + black band and the sign */
  for(var i=0;i<4;i++)poly([P(x+i*0.2375,y+1.84,1.15),P(x+i*0.2375+0.2375,y+1.84,1.15),P(x+i*0.2375+0.2375,y+1.84,1.0),P(x+i*0.2375,y+1.84,1.0)],i%2?"#222":"#f2c230");
  var sg=P(x+0.47,y+1.84,0.7);txt("SHIPPING",sg[0],sg[1],7,"#ffe9a8");
  /* intake: a hopper mouth on top of the kitchen side (Papa drops potatoes in from his side); rubber flaps only swing while one goes in */
  box(x+0.05,y+0.3,0.55,1.24,1.15,0.14,"#9aa8b2",{top:"#b9c6ce"});topQuad(x+0.12,y+0.38,0.41,1.08,1.295,"#10161a","#000");
  for(var f=0;f<4;f++){var u=y+0.46+f*0.25,sw=act?Math.sin(bz*30+f)*0.06*(1-bz/0.6):0;line(P(x+0.14,u+sw,1.3),P(x+0.51,u+sw,1.3),"#3a4248",2);}
  /* flow arrow pointing east through the wall */
  var ar=P(x+0.2,y+1.84,0.42),ab=P(x+0.8,y+1.84,0.42);line(ar,ab,"#ffe9a8",1.6);line(ab,P(x+0.66,y+1.84,0.52),"#ffe9a8",1.6);line(ab,P(x+0.66,y+1.84,0.32),"#ffe9a8",1.6);
  /* status light: green = to the pool, amber = ships them dirty right here (no key / SHIP DIRTY); white blink as one goes through */
  var to=key&&sim.s.box.deliver!==1;var lp=P(x+0.93,y+1.84,1.07);ctx.beginPath();ctx.arc(lp[0],lp[1],2.4*Z,0,6.28);ctx.fillStyle=act&&Math.floor(bz*10)%2===0?"#ffffff":(to?"#5fe080":"#ffb02e");ctx.fill();
  if(act&&!to&&bz<0.05)part({k:"spark",x:13.4,y:15,h:1.2,vx:-0.6,vy:0,vh:1.2,t:0,life:0.4,c:"#ffd34d"});}
function drawShipW(sim){var bz=shipBusy(sim),act=bz>=0&&bz<0.6,x=15.02,y=14.08,STEEL="#6d7c88";
  shadow(16,15,0.9);box(x,y,1.66,1.84,0,1.05,STEEL,{top:"#90a0ab"});
  for(var i=0;i<6;i++)poly([P(x+1.66,y+i*0.307,1.05),P(x+1.66,y+i*0.307+0.307,1.05),P(x+1.66,y+i*0.307+0.307,0.92),P(x+1.66,y+i*0.307,0.92)],i%2?"#222":"#f2c230");
  var sg=P(x+0.83,y+1.84,0.78);txt("SHIP",sg[0],sg[1],7,"#ffe9a8");var sg2=P(x+0.83,y+1.84,0.55);txt("TO POOL",sg2[0],sg2[1],6,"#bfe6ff");
  /* spout: a sloped steel chute from the east face over the pool coping */
  var sp=[P(16.68,14.62,0.78),P(16.68,15.32,0.78),P(17.45,15.22,0.42),P(17.45,14.72,0.42)];poly(sp,"#8d9aa4",OUT);
  poly([P(16.68,14.7,0.79),P(16.68,15.24,0.79),P(17.4,15.16,0.44),P(17.4,14.78,0.44)],"#55626c");
  /* mouth on the east face */poly([P(16.68,14.62,0.78),P(16.68,15.32,0.78),P(16.68,15.32,0.98),P(16.68,14.62,0.98)],"#10161a","#000");
  var lp=P(x+1.5,y+0.15,0.98);ctx.beginPath();ctx.arc(lp[0],lp[1],2.2*Z,0,6.28);ctx.fillStyle=act?"#ffffff":"#5fe080";ctx.fill();}
D.shipBusy=shipBusy;
/* ---------- machines ---------- */
function lamp(x,y,h,state){var p=P(x,y,h),c=state==="jam"?((Math.floor(T*4)%2)?"#ff3b30":"#5a1410"):state==="run"?"#55ff7a":state==="nopow"?((Math.floor(T*2)%2)?"#ffcc33":"#5a4a10"):"#555";ctx.beginPath();ctx.arc(p[0],p[1],2.8*Z,0,6.28);ctx.fillStyle=c;ctx.fill();ctx.strokeStyle="#111";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();
  if(state==="jam"||state==="run"){ctx.globalAlpha=0.25;ctx.beginPath();ctx.arc(p[0],p[1],6*Z,0,6.28);ctx.fill();ctx.globalAlpha=1;}}
function mState(sim,o){if(o.jam)return "jam";if(!o.pw)return "nopow";if(!o.on||sim.s.box.mspeed<=0)return "off";return o.run?"run":"idle";}
function arrowFloor(x,y,dir,c){var d=S.DIRS[dir],cx=x+0.5,cy=y+0.5,a=P(cx-d[0]*0.3,cy-d[1]*0.3,0.03),b=P(cx+d[0]*0.3,cy+d[1]*0.3,0.03),n=[-d[1],d[0]];
  var l=P(cx+d[0]*0.05+n[0]*0.2,cy+d[1]*0.05+n[1]*0.2,0.03),r=P(cx+d[0]*0.05-n[0]*0.2,cy+d[1]*0.05-n[1]*0.2,0.03);line(a,b,c,2.2);line(b,l,c,2.2);line(b,r,c,2.2);}
function spout(sim,o,col){var f=sim.frontOut(o),d=S.DIRS[o.r],ff=S.fp(o),cx=f[0]+0.5-d[0]*0.5,cy=f[1]+0.5-d[1]*0.5;
  var w=Math.abs(d[0])?0.3:0.6,dd=Math.abs(d[0])?0.6:0.3;box(cx-w/2+(d[0]>0?0:d[0]<0?-0.3:0)+(d[0]?0:0),cy-dd/2+(d[1]>0?0:d[1]<0?-0.3:0),w,dd,0.35,0.2,col||"#9aa7b0");}
function drawHopper(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*40)*0.012:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.3);
  /* legs + base */
  box(x+0.15,y+0.15,0.2,0.2,0,0.8,"#555c63");box(x+f.w-0.35,y+0.15,0.2,0.2,0,0.8,"#555c63");box(x+0.15,y+f.h-0.35,0.2,0.2,0,0.8,"#555c63");box(x+f.w-0.35,y+f.h-0.35,0.2,0.2,0,0.8,"#555c63");
  box(x+0.25,y+0.25,f.w-0.5,f.h-0.5,0.8,0.5,"#6f8aa0");
  /* funnel: wider at the top */
  var t0=1.3,t1=2.5,a=[P(x+0.25,y+0.25,t0),P(x+f.w-0.25,y+0.25,t0),P(x+f.w-0.25,y+f.h-0.25,t0),P(x+0.25,y+f.h-0.25,t0)],b=[P(x-0.05,y-0.05,t1),P(x+f.w+0.05,y-0.05,t1),P(x+f.w+0.05,y+f.h+0.05,t1),P(x-0.05,y+f.h+0.05,t1)];
  poly([a[3],a[2],b[2],b[3]],"#7f9bb2",OUT);poly([a[2],a[1],b[1],b[2]],"#60798d",OUT);poly(b,"#283844",OUT);
  /* potatoes swirling in the funnel */
  var n=Math.min(6,(o.fed|0)%7+(sim.touchesPile(o)?4:o.q.length));for(var i=0;i<n;i++){var an=(st==="run"?T*3:0)+i*1.05;potato(x+f.w/2+Math.cos(an)*0.45,y+f.h/2+Math.sin(an)*0.45,t1-0.15,{k:0,u:i,d:1},an,0.95);}
  /* suction hose to the pile */
  if(sim.touchesPile(o)){var pl=FIX.pile,hx=Math.max(pl.x+0.3,Math.min(pl.x+pl.w-0.3,x+f.w/2)),hy=Math.max(pl.y+0.3,Math.min(pl.y+pl.h-0.3,y+f.h/2));var h0=P(x+f.w/2,y+f.h/2,t1),h1=P(hx,hy,0.6),wob=Math.sin(T*5)*3*Z;
    ctx.strokeStyle="#33302c";ctx.lineWidth=Math.max(2,5*Z);ctx.beginPath();ctx.moveTo(h0[0],h0[1]);ctx.quadraticCurveTo((h0[0]+h1[0])/2+wob,Math.min(h0[1],h1[1])-30*Z,h1[0],h1[1]);ctx.stroke();ctx.strokeStyle="#6b655d";ctx.lineWidth=Math.max(1,2*Z);ctx.stroke();}
  spout(sim,o);lamp(x+f.w,y+f.h*0.3,1.15,st);
  var lb=P(x+f.w/2,y+f.h,1.05);txt("HOPPER",lb[0],lb[1],7,"#e8f4ff");}
function drawPeeler(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*35)*0.01:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.8);
  box(x,y,f.w,f.h,0,0.25,"#3d4349");box(x+0.1,y+0.1,f.w-0.2,f.h-0.2,0.25,1.55,"#c9a227");box(x+0.2,y+0.2,f.w-0.4,f.h-0.4,1.8,0.35,"#8f7419");
  /* stripes */
  for(var i=0;i<6;i++){var u=x+0.1+i*(f.w-0.2)/6;poly([P(u,y+f.h-0.1,0.25),P(u+(f.w-0.2)/12,y+f.h-0.1,0.25),P(u+(f.w-0.2)/12,y+f.h-0.1,0.45),P(u,y+f.h-0.1,0.45)],i%2?"#222":"#f0d34a");}
  /* round drum window on the south face, a potato spinning in it */
  var wc=P(x+f.w/2,y+f.h-0.08,1.05);ctx.beginPath();ctx.ellipse(wc[0],wc[1],15*Z,13*Z,0,0,6.28);ctx.fillStyle="#1b2228";ctx.fill();ctx.strokeStyle="#ddd";ctx.lineWidth=Math.max(1,2.5*Z);ctx.stroke();
  if(o.q.length){ctx.save();ctx.beginPath();ctx.ellipse(wc[0],wc[1],13*Z,11*Z,0,0,6.28);ctx.clip();var ang=st==="run"?T*14:0;ctx.translate(wc[0],wc[1]);ctx.rotate(ang);
    ctx.beginPath();ctx.ellipse(0,0,8*Z,5.5*Z,0,0,6.28);ctx.fillStyle=o.t>1.5?"#f2d98a":"#9a6a3a";ctx.fill();ctx.restore();
    if(st==="run"){for(var k=0;k<3;k++){var a2=T*9+k*2.1;ctx.strokeStyle="#c58c47";ctx.lineWidth=Math.max(1,1.4*Z);ctx.beginPath();ctx.arc(wc[0]+Math.cos(a2)*9*Z,wc[1]+Math.sin(a2)*7*Z,2*Z,a2,a2+2);ctx.stroke();}}}
  /* blades on top + exhaust */
  var ex=P(x+0.5,y+0.5,2.15);box(x+0.4,y+0.4,0.2,0.2,2.15,0.45,"#555");if(st==="run"&&Math.random()<0.08)part({k:"smoke",x:x+0.5,y:y+0.5,h:2.6,vh:0.6,t:0,life:1.2});
  if(st==="jam"&&Math.random()<0.2)part({k:"smoke",x:x+f.w/2+(Math.random()-0.5),y:y+f.h/2,h:2.0,vh:0.8,t:0,life:1.5});
  spout(sim,o,"#d8c06a");lamp(x+f.w-0.15,y+f.h-0.1,1.85,st);
  var lb=P(x+f.w/2,y+f.h,0.62);txt(st==="jam"?"JAMMED!":"AUTO PEELER",lb[0],lb[1],7,st==="jam"?"#ff8a80":"#222");}
function drawWasher(sim,o){var f=S.fp(o),st=mState(sim,o),j=st==="run"?Math.sin(T*30)*0.01:0,x=f.x+j,y=f.y;shadow(x+f.w/2,y+f.h/2,1.8);
  box(x,y,f.w,f.h,0,0.2,"#3d4349");box(x+0.1,y+0.1,f.w-0.2,f.h-0.2,0.2,1.45,"#e9eef2");box(x+0.15,y+0.15,f.w-0.3,0.5,1.65,0.25,"#3aa0d8");
  var wc=P(x+f.w/2,y+f.h-0.08,0.95);ctx.beginPath();ctx.ellipse(wc[0],wc[1],16*Z,14*Z,0,0,6.28);ctx.fillStyle="#cfd8de";ctx.fill();ctx.strokeStyle="#7d8a94";ctx.lineWidth=Math.max(1,3*Z);ctx.stroke();
  ctx.save();ctx.beginPath();ctx.ellipse(wc[0],wc[1],13*Z,11*Z,0,0,6.28);ctx.clip();ctx.fillStyle="#123";ctx.fillRect(wc[0]-14*Z,wc[1]-12*Z,28*Z,24*Z);
  var sl=st==="run"?Math.sin(T*5)*4*Z:0;ctx.fillStyle="#3b9fd6";ctx.beginPath();ctx.moveTo(wc[0]-14*Z,wc[1]+sl);ctx.quadraticCurveTo(wc[0],wc[1]-sl*1.5,wc[0]+14*Z,wc[1]-sl);ctx.lineTo(wc[0]+14*Z,wc[1]+12*Z);ctx.lineTo(wc[0]-14*Z,wc[1]+12*Z);ctx.fill();
  for(var i=0;i<o.q.length;i++){var a=(st==="run"?T*6:0)+i*3;ctx.fillStyle="#f2d98a";ctx.beginPath();ctx.ellipse(wc[0]+Math.cos(a)*6*Z,wc[1]+Math.sin(a)*5*Z,5*Z,3.5*Z,a,0,6.28);ctx.fill();}
  if(st==="run")for(var k=0;k<4;k++){var bb=(T*0.8+k/4)%1;ctx.fillStyle="rgba(255,255,255,0.7)";ctx.beginPath();ctx.arc(wc[0]+(k-1.5)*5*Z,wc[1]+8*Z-bb*18*Z,1.5*Z,0,6.28);ctx.fill();}ctx.restore();
  if(st==="jam"&&Math.random()<0.2)part({k:"foam",x:x+f.w/2+(Math.random()-0.5),y:y+f.h,h:1.4,vh:0.5,t:0,life:1.2,r:3});
  spout(sim,o,"#b9c6cf");lamp(x+f.w-0.15,y+f.h-0.1,1.75,st);var lb=P(x+f.w/2,y+f.h,0.45);txt(st==="jam"?"CLOGGED!":"WASHER",lb[0],lb[1],7,st==="jam"?"#ff8a80":"#234");}
function drawGenerator(sim,o){var f=S.fp(o),x=f.x+Math.sin(T*50)*0.006,y=f.y;shadow(x+1,y+1,1.3);
  box(x+0.1,y+0.1,1.8,1.8,0,0.15,"#2e3135");box(x+0.2,y+0.2,1.6,1.6,0.15,0.8,"#e3b928");box(x+0.45,y+0.45,1.1,1.0,0.95,0.35,"#4a4f55");
  /* flywheel on the east face */
  var wc=P(x+1.9,y+1.0,0.6);ctx.beginPath();ctx.ellipse(wc[0],wc[1],8*Z,11*Z,0,0,6.28);ctx.fillStyle="#333";ctx.fill();ctx.strokeStyle="#999";ctx.lineWidth=Math.max(1,1.5*Z);ctx.stroke();
  for(var i=0;i<4;i++){var a=T*12+i*1.57;line(wc,[wc[0]+Math.cos(a)*6*Z,wc[1]+Math.sin(a)*9*Z],"#bbb",1.3);}
  box(x+1.4,y+0.4,0.18,0.18,1.3,0.6,"#555");if(Math.random()<0.1)part({k:"smoke",x:x+1.5,y:y+0.5,h:2.0,vh:0.7,t:0,life:1.1});
  var pw=sim.power&&sim.power.src.filter(function(s){return s.u===o.u;})[0];var lb=P(x+1,y+2,0.62);txt("GEN "+(pw?pw.used+"/"+pw.cap:""),lb[0],lb[1],7,"#222");}
function drawBelt(sim,o,V){var x=o.x,y=o.y,d=S.DIRS[o.r],run=o.pw&&sim.s.box.belts>0;
  box(x+0.04,y+0.04,0.92,0.92,0,0.18,"#4d555c",{stroke:"rgba(0,0,0,0.5)"});
  poly([P(x+0.12,y+0.12,0.185),P(x+0.88,y+0.12,0.185),P(x+0.88,y+0.88,0.185),P(x+0.12,y+0.88,0.185)],"#24292d");
  var sp=(S.SPEEDV[sim.s.box.belts]||0)*1.3,off=run?(T*sp)%0.25:0,n=[-d[1],d[0]];
  for(var k=0;k<4;k++){var u=-0.5+k*0.25+off;if(u>0.5)u-=1;var c=[x+0.5+d[0]*u,y+0.5+d[1]*u];line(P(c[0]+n[0]*0.36,c[1]+n[1]*0.36,0.19),P(c[0]-n[0]*0.36,c[1]-n[1]*0.36,0.19),"#5a646c",1.4);}
  arrowFloor(x,y,o.r,run?"rgba(255,214,80,0.9)":"rgba(255,140,80,0.7)");
  if(!o.pw){var p=P(x+0.5,y+0.5,0.5);if(Math.floor(T*2)%2)txt("⚡",p[0],p[1],10,"#ffcc33");}}
D.drawBelt=drawBelt;
/* ---------- starters ---------- */
function drawTable(sim,o){var f=S.fp(o),x=f.x,y=f.y,h=0.9;shadow(x+f.w/2,y+f.h/2,1.6);
  [[0.1,0.1],[f.w-0.25,0.1],[0.1,f.h-0.25],[f.w-0.25,f.h-0.25]].forEach(function(l){box(x+l[0],y+l[1],0.15,0.15,0,h-0.12,"#6b4a2b");});
  box(x+0.15,y+0.15,f.w-0.3,f.h-0.3,0.3,0.06,"#7b5733");
  box(x,y,f.w,f.h,h-0.12,0.12,"#b07a45",{top:"#c98f55"});
  ctx.strokeStyle="rgba(110,70,30,0.35)";for(var i=1;i<5;i++){var u=i/5;if(f.w>=f.h)line(P(x,y+u*f.h,h),P(x+f.w,y+u*f.h,h),"rgba(110,70,30,0.3)");else line(P(x+u*f.w,y,h),P(x+u*f.w,y+f.h,h),"rgba(110,70,30,0.3)");}
  /* built-in sink (t1206) with a dripping tap */
  var sk=sim.sinkTile(o),p=sim.s.papa,rin=p.task&&p.task.type==="rinse"&&p.task.stage==="act";
  poly([P(sk[0]+0.15,sk[1]+0.15,h+0.01),P(sk[0]+0.85,sk[1]+0.15,h+0.01),P(sk[0]+0.85,sk[1]+0.85,h+0.01),P(sk[0]+0.15,sk[1]+0.85,h+0.01)],"#9fb1bb",OUT);
  poly([P(sk[0]+0.25,sk[1]+0.25,h-0.08),P(sk[0]+0.75,sk[1]+0.25,h-0.08),P(sk[0]+0.75,sk[1]+0.75,h-0.08),P(sk[0]+0.25,sk[1]+0.75,h-0.08)],"#5f7480");
  box(sk[0]+0.45,sk[1]+0.12,0.08,0.08,h,0.35,"#c9d2d8");var tp=P(sk[0]+0.49,sk[1]+0.3,h+0.33);line(P(sk[0]+0.49,sk[1]+0.16,h+0.35),tp,"#c9d2d8",2);
  var dph=rin?1:(T*1.3)%1;var rec=usedRecently(o,rin);if(rin){line(tp,P(sk[0]+0.49,sk[1]+0.3,h-0.05),"rgba(160,220,255,0.9)",2.5);}else if(rec){var dp=P(sk[0]+0.49,sk[1]+0.3,h+0.3-dph*0.35);ctx.fillStyle="#9fd8ff";ctx.fillRect(dp[0]-Z,dp[1],2*Z,2.5*Z);}
  /* tray potatoes */
  o.tray.forEach(function(u){var q=sim.pot(u);if(q)potato(q.x,q.y,h+0.05,q,0.3);});}
function drawCooler(sim,o,small){var f=S.fp(o),x=f.x+0.1,y=f.y+0.1,w=f.w-0.2,d=f.h-0.2,hh=small?0.6:0.95;shadow(x+w/2,y+d/2,0.55);
  box(x,y,w,d,0,hh,"#f2f4f6");box(x-0.02,y-0.02,w+0.04,d+0.04,hh,0.12,"#2f7fd0");box(x+w*0.3,y+d-0.02,w*0.4,0.06,hh-0.25,0.08,"#9aa");
  var on=sim.s.food>0;var lp=P(x+w,y+d*0.5,hh-0.2);ctx.fillStyle=on?"#6fe08c":"#d0503a";ctx.beginPath();ctx.arc(lp[0],lp[1],2.6*Z,0,6.28);ctx.fill();
  if(on){var fr=(T*0.6)%1;ctx.globalAlpha=0.4*(1-fr);ell(x+w/2,y+d/2,hh+0.2+fr*0.4,6+fr*6,3+fr*3,"#e8f6ff");ctx.globalAlpha=1;}
  var lb=P(x+w/2,y+d,0.25);txt(small?"+2":sim.s.food+"/"+sim.cooCap(),lb[0],lb[1],7,"#234");}
function drawBed(sim,o,cot){var f=S.fp(o),x=f.x,y=f.y,p=sim.s.papa,sl=p.task&&p.task.type==="nap"&&p.task.lying&&p.task.target===o;shadow(x+f.w/2,y+f.h/2,1.5);
  if(cot){box(x+0.05,y+0.05,f.w-0.1,f.h-0.1,0.25,0.12,"#556b3a");[[0.05,0.05],[f.w-0.15,0.05],[0.05,f.h-0.15],[f.w-0.15,f.h-0.15]].forEach(function(l){box(x+l[0],y+l[1],0.1,0.1,0,0.25,"#333");});
    topQuad(x+0.15,y+0.15,f.w-0.3,0.5,0.4,"#e9e4d4",OUT);sheen(x+0.1,y+0.7,f.w-0.2,f.h-0.8,0.38,0.2,0.25);var tg=P(x+f.w,y+f.h*0.5,0.3),sw=0;line(tg,[tg[0]+sw,tg[1]+9*Z],"#888",1);ctx.fillStyle="#f3e2a0";ctx.fillRect(tg[0]+sw-5*Z,tg[1]+9*Z,10*Z,7*Z);}
  else{box(x,y,f.w,f.h,0,0.35,"#7a5232");box(x,y,f.w,0.18,0,0.95,"#6a4528");box(x+0.08,y+0.2,f.w-0.16,f.h-0.28,0.35,0.22,"#f3efe4");
    box(x+0.25,y+0.3,f.w-0.5,0.55,0.57,0.12,"#ffffff");
    var br=sl?Math.sin(T*2)*0.03:0;box(x+0.08,y+1.0,f.w-0.16,f.h-1.08,0.57,0.06+br,"#3a6fb0",{top:"#4a80c4"});for(var i=0;i<3;i++)line(P(x+0.1,y+1.3+i*0.5,0.64+br),P(x+f.w-0.1,y+1.3+i*0.5,0.64+br),"rgba(255,255,255,0.35)",1.2);}
  if(sl&&Math.random()<0.04)part({k:"z",x:x+f.w/2,y:y+0.6,h:1.2,vh:0.5,t:0,life:2});}
function drawTub(sim,o){var f=S.fp(o),x=f.x,y=f.y,h=0.75;shadow(x+f.w/2,y+f.h/2,1.1);
  [[0.1,0.1],[f.w-0.2,0.1],[0.1,f.h-0.2],[f.w-0.2,f.h-0.2]].forEach(function(l){box(x+l[0],y+l[1],0.1,0.1,0,h-0.3,"#555");});
  box(x+0.05,y+0.05,f.w-0.1,f.h-0.1,h-0.3,0.42,"#a9b9c2",{top:"#c2d0d8"});
  poly([P(x+0.15,y+0.15,h+0.08),P(x+f.w-0.15,y+0.15,h+0.08),P(x+f.w-0.15,y+f.h-0.15,h+0.08),P(x+0.15,y+f.h-0.15,h+0.08)],"#7fc7e8");
  if(o.q.length||papaDoing(sim,"scrub"))for(var i=0;i<5;i++){var ph=(T*0.7+i/5)%1;ctx.globalAlpha=1-ph;ell(x+0.3+i*(f.w-0.6)/4,y+f.h/2,h+0.1+ph*0.3,2.5,2.5,"#ffffff","rgba(150,200,240,0.8)");ctx.globalAlpha=1;}
  o.q.forEach(function(u){var q=sim.pot(u);if(q)potato(q.x,q.y,h+0.05+Math.sin(T*3+q.u)*0.02,q,Math.sin(T+q.u)*0.3);});
  /* scrub brush resting on the rim (Papa picks it up to scrub) */
  var p=sim.s.papa;if(!(p.task&&p.task.type==="scrub"&&p.task.stage==="act")){box(x+f.w-0.35,y+0.1,0.25,0.1,h+0.12,0.06,"#b5462f");}
  var lb=P(x+f.w/2,y+f.h,0.3);txt("SCRUB TUB",lb[0],lb[1],7,"#123");}
/* ---------- decor (each a physical object with a looped animation) ---------- */
/* a soft light band sliding across a surface: the looped animation for rugs, mats and shelves */
function sheen(x,y,w,d,h,a,sp){var u=0.3;ctx.save();ctx.beginPath();var q=[P(x,y,h),P(x+w,y,h),P(x+w,y+d,h),P(x,y+d,h)];ctx.moveTo(q[0][0],q[0][1]);for(var i=1;i<4;i++)ctx.lineTo(q[i][0],q[i][1]);ctx.closePath();ctx.clip();
  var long=w>=d,a0=long?P(x+u*w,y-0.5,h):P(x-0.5,y+u*d,h),a1=long?P(x+u*w+0.3,y+d+0.5,h):P(x+w+0.5,y+u*d+0.3,h);ctx.strokeStyle="rgba(255,250,225,"+(a||0.28)+")";ctx.lineWidth=Math.max(4,16*Z);ctx.beginPath();ctx.moveTo(a0[0],a0[1]);ctx.lineTo(a1[0],a1[1]);ctx.stroke();ctx.restore();}
function drawRug(o){var f=S.fp(o),x=f.x,y=f.y,id=o.id,w=f.w,d=f.h,h=0.015,sh=0.5;
  if(id==="roundRug"){isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.05,"#b86a3c","rgba(60,30,10,0.5)");isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.3,"#e0a35a");isoCirc(x+w/2,y+d/2,h,Math.min(w,d)/2-0.55,"#8a4a2a");isoCirc(x+w/2,y+d/2,h,0.18,"rgba(255,230,170,"+(0.3+0.3*sh)+")");sheen(x+0.2,y+0.2,w-0.4,d-0.4,h+0.004,0.22,0.35);return;}
  var c=id==="kitchenMat"?["#7f9a6a","#efe6cf"]:id==="runner"?["#7a2f3a","#e2b45a"]:["#3d5a8a","#d9c08a"];
  topQuad(x+0.06,y+0.06,w-0.12,d-0.12,h,c[1],"rgba(40,20,10,0.5)");topQuad(x+0.16,y+0.16,w-0.32,d-0.32,h+0.002,c[0]);
  if(id==="kitchenMat"){for(var i=1;i<6;i++)line(P(x+0.16+i*(w-0.32)/6,y+0.16,h+0.003),P(x+0.16+i*(w-0.32)/6,y+d-0.16,h+0.003),"rgba(255,255,255,0.25)");}
  if(id==="runner"){for(var k=0;k<3;k++){var cy=y+0.5+k*(d-1)/2;poly([P(x+w/2,cy-0.25,h+0.004),P(x+w-0.25,cy,h+0.004),P(x+w/2,cy+0.25,h+0.004),P(x+0.25,cy,h+0.004)],c[1]);}}
  if(id==="rug"){topQuad(x+0.45,y+0.45,w-0.9,d-0.9,h+0.003,"#c75b4a");}
  sheen(x+0.1,y+0.1,w-0.2,d-0.2,h+0.005,0.25,0.3);
  /* tassels flutter */
  for(var t=0;t<4;t++){var fx=x+0.2+t*(w-0.4)/3;line(P(fx,y+d-0.06,h),P(fx,y+d+0.08,h),c[1],1.2);}}
function drawFloorDecor(sim,o){var f=S.fp(o),x=f.x,y=f.y,id=o.id,cx=x+f.w/2,cy=y+f.h/2,s=sim.s;
  switch(id){
  case "sink":{shadow(cx,cy,0.5);box(x+0.1,y+0.1,0.8,0.8,0,0.85,"#e7ecef");topQuad(x+0.2,y+0.2,0.6,0.6,0.86,"#9fb1bb",OUT);topQuad(x+0.28,y+0.28,0.44,0.44,0.8,"#5f7480");
    box(x+0.46,y+0.12,0.08,0.08,0.85,0.35,"#c9d2d8");var p=s.papa,act=p.task&&p.task.type==="washRaw"&&p.task.stage==="act";var tp=P(x+0.5,y+0.32,1.18);line(P(x+0.5,y+0.16,1.2),tp,"#c9d2d8",2);
    var rec=usedRecently(o,act);if(act)line(tp,P(x+0.5,y+0.32,0.82),"rgba(160,220,255,0.9)",3);else if(rec){var dph=(T*1.1)%1,dp=P(x+0.5,y+0.32,1.15-dph*0.33);ctx.fillStyle="#9fd8ff";ctx.beginPath();ctx.ellipse(dp[0],dp[1],2*Z,3*Z,0,0,6.28);ctx.fill();if(dph>0.7)isoCirc(x+0.5,y+0.45,0.81,0.05+(dph-0.7)*0.6,null,"rgba(200,235,255,"+(1-(dph-0.7)/0.3)+")",1.5);}break;}
  case "smallCooler":drawCooler(sim,o,true);break;
  case "basicCot":drawBed(sim,o,true);break;
  case "compost":{shadow(cx,cy,0.45);cyl(cx,cy,0.34,0,0.75,"#3f6b3a");var swp=papaDoing(sim,"sweep"),lid=swp?Math.max(0,Math.sin(T*1.2))*0.06:0;ell(cx,cy,0.78+lid,15,7.5,"#2d4f29","rgba(0,0,0,0.4)");
    if(swp&&Math.random()<0.03)part({k:"smoke",x:cx,y:cy,h:0.9,vh:0.3,t:0,life:1.5});break;}
  case "fruitBowl":{shadow(cx,cy,0.35);cyl(cx,cy,0.12,0,0.75,"#7a5232");cyl(cx,cy,0.3,0.75,0.1,"#d9d2c4");
    [["#d33",0],["#f5c518",1],["#6c3",2],["#e83",3]].forEach(function(fr){var a=fr[1]*1.6,p=P(cx+Math.cos(a)*0.14,cy+Math.sin(a)*0.14,0.92);ctx.beginPath();ctx.arc(p[0],p[1],3.4*Z,0,6.28);ctx.fillStyle=fr[0];ctx.fill();});if(false){var fa=T*4,fl=P(cx+Math.cos(fa)*0.35,cy+Math.sin(fa*1.3)*0.3,1.15+Math.sin(T*7)*0.08);ctx.fillStyle="#222";ctx.beginPath();ctx.arc(fl[0],fl[1],2*Z,0,6.28);ctx.fill();ctx.fillStyle="rgba(220,230,255,0.8)";ctx.beginPath();ctx.ellipse(fl[0]-2*Z,fl[1]-2*Z,2.5*Z,1.4*Z,(Math.floor(T*20)%2)?0.6:-0.6,0,6.28);ctx.fill();ctx.beginPath();ctx.ellipse(fl[0]+2*Z,fl[1]-2*Z,2.5*Z,1.4*Z,(Math.floor(T*20)%2)?-0.6:0.6,0,6.28);ctx.fill();}break;}
  case "plant":{shadow(cx,cy,0.4);cyl(cx,cy,0.25,0,0.4,"#b5562f");var dry=s.plant.dry>60,sw=fanOn(sim)?Math.sin(T*1.6)*(dry?0.02:0.06):0;
    for(var i=0;i<7;i++){var a=i*0.9,len=dry?0.25:0.45,b0=P(cx,cy,0.4),b1=P(cx+Math.cos(a)*0.3+sw,cy+Math.sin(a)*0.3,0.4+len+(dry?-0.1:0.15));ctx.strokeStyle=dry?"#8a8a3a":"#3f9a3f";ctx.lineWidth=Math.max(2,4*Z);ctx.beginPath();ctx.moveTo(b0[0],b0[1]);ctx.quadraticCurveTo(b0[0]+sw*40*Z,b1[1]-8*Z,b1[0],b1[1]);ctx.stroke();}break;}
  case "lamp":{shadow(cx,cy,0.35);var on=s.box.lamp>0;if(on){ctx.globalAlpha=0.2;isoCirc(cx,cy,0.01,1.6,"#ffe6a0");ctx.globalAlpha=1;}
    cyl(cx,cy,0.18,0,0.06,"#333");box(cx-0.03,cy-0.03,0.06,0.06,0.06,1.4,"#444");cyl(cx,cy,0.26,1.35,0.3,on?"#ffe8a8":"#d8cfae");var ch=P(cx+0.15,cy+0.15,1.35),cs=0;line(ch,[ch[0]+cs,ch[1]+12*Z],"#c9a227",1.2);ctx.fillStyle="#c9a227";ctx.beginPath();ctx.arc(ch[0]+cs,ch[1]+12*Z,2*Z,0,6.28);ctx.fill();
    if(!on)break;var ma=T*3.1,mp=P(cx+Math.cos(ma)*0.4,cy+Math.sin(ma)*0.4,1.75+Math.sin(T*5)*0.1);ctx.fillStyle=on?"#f4e9c8":"#9a9080";ctx.beginPath();ctx.ellipse(mp[0]-2*Z,mp[1],2.6*Z,1.6*Z,0.5,0,6.28);ctx.ellipse(mp[0]+2*Z,mp[1],2.6*Z,1.6*Z,-0.5,0,6.28);ctx.fill();break;}
  case "shelf":{shadow(cx,cy,0.7);for(var sh=0;sh<3;sh++)box(x+0.05,y+0.2,f.w-0.1,f.h-0.4,0.3+sh*0.5,0.06,"#8a6438");box(x+0.05,y+0.2,0.08,f.h-0.4,0,1.4,"#6b4a2b");box(x+f.w-0.13,y+0.2,0.08,f.h-0.4,0,1.4,"#6b4a2b");
    var n=Math.min(8,s.food);for(var c=0;c<n;c++){var u=x+0.25+(c%4)*(f.w-0.5)/3.5,lv=(c/4)|0;cyl(f.w>=f.h?u:cx,f.w>=f.h?cy:y+0.25+(c%4)*(f.h-0.5)/3.5,0.07,0.36+lv*0.5,0.2,["#d33","#36c","#da3"][c%3]);}
    sheen(x+0.05,y+0.2,f.w-0.1,f.h-0.4,1.36,0.35,0.3);var tg2=P(x+f.w*0.5,y+f.h-0.2,1.3),sw2=0;line(tg2,[tg2[0]+sw2,tg2[1]+10*Z],"#777",1);ctx.fillStyle="#fff3c0";ctx.fillRect(tg2[0]+sw2-6*Z,tg2[1]+10*Z,12*Z,7*Z);break;}
  case "sackPile":{shadow(cx,cy,0.8);for(var k=0;k<3;k++){var sx2=f.w>=f.h?x+0.45+k*0.55:cx,sy2=f.w>=f.h?cy:y+0.45+k*0.55,br=0;cyl(sx2,sy2,0.28,0,0.5+br,"#b08a57");ell(sx2,sy2,0.55+br,8,4,"#8c6a3d");}break;}
  case "cookbook":{shadow(cx,cy,0.3);box(cx-0.05,cy-0.05,0.1,0.1,0,0.9,"#5a3a22");var pg=papaDoing(sim,"peel")?(T*0.4)%1:0;box(x+0.2,y+0.25,0.6,0.5,0.9,0.05,"#7a2f2a");
    topQuad(x+0.25,y+0.3,0.25,0.4,0.96,"#f6f0dd","#999");topQuad(x+0.5,y+0.3,0.25,0.4,0.96,"#f6f0dd","#999");var pp=P(x+0.5-0.25*Math.cos(pg*Math.PI),y+0.5,0.96+0.15*Math.sin(pg*Math.PI));line(P(x+0.5,y+0.5,0.96),pp,"#fff",2);break;}
  case "mopBucket":{shadow(cx,cy,0.4);cyl(cx,cy,0.27,0,0.45,"#e0c020");ell(cx,cy,0.45,12,6,"#6fb3d9");var sw=Math.sin(T*3)*0.14*brush(o,cx,cy);line(P(cx+0.075,cy-0.025,0.42),P(cx+0.075+sw,cy-0.025,1.5),OUT,4);line(P(cx+0.075,cy-0.025,0.42),P(cx+0.075+sw,cy-0.025,1.5),"#9a7a50",2.6);cyl(cx+0.08+sw*0.25,cy,0.12,0.4,0.15,"#ddd");break;}
  case "radio":{shadow(cx,cy,0.4);box(x+0.3,y+0.3,0.4,0.4,0,0.55,"#6b4a2b");box(x+0.15,y+0.3,0.7,0.4,0.55,0.4,"#c0392b",{top:"#d9534f"});
    var on=s.box.radio>0;topQuad(x+0.25,y+0.35,0.3,0.3,0.96,"#2a2a2a");var dp=P(x+0.7,y+0.7,0.75);ctx.beginPath();ctx.arc(dp[0],dp[1],3*Z,0,6.28);ctx.fillStyle=on?"#ffe27a":"#777";ctx.fill();
    var aw=on?Math.sin(T*2):0,an=P(x+0.75,y+0.35,0.95),at=P(x+0.95+aw*0.12,y+0.2,1.5+aw*0.05);line(an,at,"#bbb",1.6);ctx.fillStyle="#e33";ctx.beginPath();ctx.arc(at[0],at[1],2*Z,0,6.28);ctx.fill();
    var dl=P(x+0.6,y+0.7,0.88),nd=on?Math.sin(T*0.8)*6*Z:0;ctx.fillStyle="#f6e7b0";ctx.fillRect(dl[0]-8*Z,dl[1]-3*Z,16*Z,6*Z);line([dl[0]+nd,dl[1]-3*Z],[dl[0]+nd,dl[1]+3*Z],"#c00",1.5);
    if(on){var lv=window.PPRadio?Math.min(1,PPRadio.level()*6):0.5;var bp=P(x+0.4,y+0.7,0.75);ctx.beginPath();ctx.arc(bp[0],bp[1],(4+lv*2.5)*Z,0,6.28);ctx.fillStyle="#3a3a3a";ctx.fill();if(Math.random()<0.04)part({k:"note",x:cx,y:cy,h:1.2,vh:0.5,t:0,life:1.8,s:Math.random()<0.5?"♪":"♫"});}break;}
  case "fan":{shadow(cx,cy,0.35);cyl(cx,cy,0.2,0,0.06,"#444");box(cx-0.03,cy-0.03,0.06,0.06,0.06,0.9,"#555");var hc=P(cx,cy,1.15);ctx.beginPath();ctx.ellipse(hc[0],hc[1],11*Z,11*Z,0,0,6.28);ctx.fillStyle="rgba(200,220,230,0.25)";ctx.fill();ctx.strokeStyle="#888";ctx.lineWidth=Math.max(0.6,Z);ctx.stroke();
    for(var b=0;b<3;b++){var a=T*18+b*2.09;ctx.beginPath();ctx.ellipse(hc[0]+Math.cos(a)*5*Z,hc[1]+Math.sin(a)*5*Z,5*Z,2.5*Z,a,0,6.28);ctx.fillStyle="#9fb1bb";ctx.fill();}break;}
  case "bookshelf":{shadow(cx,cy,0.7);box(x+0.05,y+0.25,f.w-0.1,f.h-0.5,0,1.8,"#6b4a2b");for(var r=0;r<3;r++){for(var bk=0;bk<6;bk++){var u=(f.w>=f.h?x:y)+0.15+bk*((f.w>=f.h?f.w:f.h)-0.3)/6,hh=0.25+((bk*7+r*3)%4)*0.04;
      if(f.w>=f.h)poly([P(u,y+f.h-0.25,0.15+r*0.55),P(u+0.13,y+f.h-0.25,0.15+r*0.55),P(u+0.13,y+f.h-0.25,0.15+r*0.55+hh),P(u,y+f.h-0.25,0.15+r*0.55+hh)],["#c0392b","#2e86c1","#27ae60","#f1c40f","#8e44ad","#e67e22"][(bk+r)%6]);
      else poly([P(x+f.w-0.25,u,0.15+r*0.55),P(x+f.w-0.25,u+0.13,0.15+r*0.55),P(x+f.w-0.25,u+0.13,0.15+r*0.55+hh),P(x+f.w-0.25,u,0.15+r*0.55+hh)],["#c0392b","#2e86c1","#27ae60","#f1c40f","#8e44ad","#e67e22"][(bk+r)%6]);}}
    box(x+0.3,y+0.35,0.1,0.1,1.8,0.25,"#c33");var bm=P(x+f.w*0.6,y+f.h-0.25,1.25),bs=0;line(bm,[bm[0]+bs,bm[1]+16*Z],"#e33",2.5);sheen(x+0.05,y+0.25,f.w-0.1,f.h-0.5,1.8,0.3,0.3);break;}
  case "catBed":{shadow(cx,cy,0.45);cyl(cx,cy,0.38,0,0.18,"#8e5aa8");var ct=s.cat,napB=ct.st==="nap",bre=napB?Math.sin(T*1.6)*1.5:0;ell(cx,cy,0.18,15+bre,7.5+bre*0.5,"#f0d8f8");var play=ct.st==="walk"&&Math.hypot(ct.x-cx,ct.y-cy)<2,yr=play?Math.sin(T*0.9)*0.25:0,yp=P(cx+0.45+yr,cy+0.3,0.08);ctx.fillStyle="#e04a6a";ctx.beginPath();ctx.arc(yp[0],yp[1],4*Z,0,6.28);ctx.fill();ctx.strokeStyle="#a02a4a";ctx.lineWidth=Math.max(0.6,Z);ctx.beginPath();var ya=play?T*3+yr*8:0.6;ctx.arc(yp[0],yp[1],2.5*Z,ya,ya+3);ctx.stroke();break;}
  case "tvArmchair":{var p=s.papa,w=f.w>=f.h;shadow(cx,cy,1.3);
    /* TV on a stand at the back, armchair in front facing it */
    var tx=w?x+0.3:x+0.3,ty=y+0.15;box(tx,ty,f.w-0.6,0.4,0,0.5,"#5a3a22");box(tx+0.1,ty+0.05,f.w-0.8,0.3,0.5,0.75,"#222");
    var on=s.box.tv>0,sc=[P(tx+0.15,ty+0.36,0.58),P(tx+f.w-0.75,ty+0.36,0.58),P(tx+f.w-0.75,ty+0.36,1.18),P(tx+0.15,ty+0.36,1.18)];
    poly(sc,on?["#3b7dd8","#d84b3b","#3bd86a","#d8c03b"][Math.floor(T*1.5)%4]:"#111");if(!on){var rf=0.35,r0=P(tx+0.15+rf*(f.w-0.9),ty+0.36,0.58),r1=P(tx+0.15+rf*(f.w-0.9)+0.25,ty+0.36,1.18);ctx.save();ctx.beginPath();ctx.moveTo(sc[0][0],sc[0][1]);for(var si=1;si<4;si++)ctx.lineTo(sc[si][0],sc[si][1]);ctx.closePath();ctx.clip();line(r0,r1,"rgba(255,255,255,0.18)",10*Z);ctx.restore();var led=P(tx+f.w-0.85,ty+0.37,0.62);ctx.fillStyle="#c8322a";ctx.beginPath();ctx.arc(led[0],led[1],2.2*Z,0,6.28);ctx.fill();}if(on){ctx.globalAlpha=0.25;for(var k=0;k<5;k++)line(P(tx+0.15,ty+0.36,0.62+k*0.12+((T*2)%0.12)),P(tx+f.w-0.75,ty+0.36,0.62+k*0.12+((T*2)%0.12)),"#fff");ctx.globalAlpha=1;}
    var ax=x+0.35,ay=y+f.h-0.95;box(ax,ay,f.w-0.7,0.8,0,0.45,"#8b3a3a");box(ax,ay+0.6,f.w-0.7,0.2,0.45,0.55,"#7a3030");box(ax,ay,0.15,0.8,0.45,0.2,"#7a3030");box(ax+f.w-0.85,ay,0.15,0.8,0.45,0.2,"#7a3030");break;}
  case "aquarium":{shadow(cx,cy,0.45);box(x+0.15,y+0.25,0.7,0.5,0,0.7,"#4a3a2a");box(x+0.12,y+0.22,0.76,0.56,0.7,0.5,"rgba(120,200,255,0.55)",{top:"rgba(160,220,255,0.5)",left:"rgba(80,170,230,0.6)",right:"rgba(60,140,200,0.6)"});
    for(var fsh=0;fsh<3;fsh++){var a=T*(0.8+fsh*0.3)+fsh*2,fp2=P(x+0.5+Math.cos(a)*0.25,y+0.78,0.85+fsh*0.12);ctx.fillStyle=["#ff8c1a","#ffd31a","#ff4d6a"][fsh];ctx.beginPath();ctx.ellipse(fp2[0],fp2[1],3*Z,1.8*Z,0,0,6.28);ctx.fill();}
    var bb=(T*0.9)%1,bp=P(x+0.3,y+0.78,0.75+bb*0.4);ctx.fillStyle="rgba(255,255,255,0.8)";ctx.beginPath();ctx.arc(bp[0],bp[1],1.3*Z,0,6.28);ctx.fill();break;}
  case "statue":{shadow(cx,cy,0.4);box(x+0.2,y+0.2,0.6,0.6,0,0.45,"#888");var gl=0.6;drawPapaBody(P(cx,cy,0.45),0.5,{gold:1,face:1,dir:1,tt:T,still:1});
    ctx.globalAlpha=0.3*gl;var gp=P(cx,cy,1.0);ctx.beginPath();ctx.arc(gp[0],gp[1],14*Z,0,6.28);ctx.fillStyle="#ffe27a";ctx.fill();ctx.globalAlpha=1;break;}
  default:{box(x+0.2,y+0.2,f.w-0.4,f.h-0.4,0,0.5,"#999");}
  }}
function drawWallItem(sim,o){var w=o.wall,u=w==="N"?o.x:o.y,id=o.id,it=S.itemDef(id),n=it.w||1,s=sim.s,mid=u+n/2;
  function Q(a,b,h0,h1,c,st){wallQuad(w,u+a,u+b,h0,h1,c,st||OUT);}
  switch(id){
  case "clock":{var c=wallPt(w,mid,1.75,0.03);ctx.beginPath();ctx.ellipse(c[0],c[1],10*Z,11*Z,0,0,6.28);ctx.fillStyle="#fffbea";ctx.fill();ctx.strokeStyle="#5a3a22";ctx.lineWidth=Math.max(1,2*Z);ctx.stroke();
    var m=sim.shiftMin(),ha=(m/720)*6.283-1.57,ma=((m%60)/60)*6.283-1.57,sa=(T%60)/60*6.283-1.57;line(c,[c[0]+Math.cos(ha)*5*Z,c[1]+Math.sin(ha)*5*Z],"#222",1.6);line(c,[c[0]+Math.cos(ma)*7.5*Z,c[1]+Math.sin(ma)*7.5*Z],"#222",1);line(c,[c[0]+Math.cos(sa)*8*Z,c[1]+Math.sin(sa)*8*Z],"#c33",0.6);break;}
  case "coatHook":{Q(0.2,0.8,1.75,1.85,"#6b4a2b");var sw=Math.sin(T*1.4)*0.05*brush(o,w==="N"?mid:0.5,w==="N"?0.5:mid);poly([wallPt(w,mid-0.15,1.75,0.05),wallPt(w,mid+0.15,1.75,0.05),wallPt(w,mid+0.22+sw,1.05,0.08),wallPt(w,mid-0.22+sw,1.05,0.08)],"#e8e2d0",OUT);
    poly([wallPt(w,mid-0.12+sw*0.6,1.45,0.07),wallPt(w,mid+0.12+sw*0.6,1.45,0.07),wallPt(w,mid+0.12+sw*0.8,1.25,0.08),wallPt(w,mid-0.12+sw*0.8,1.25,0.08)],"#c0392b");break;}
  case "calendar":{Q(0.2,0.8,1.2,1.9,"#fffdf5");Q(0.2,0.8,1.75,1.9,"#c0392b");var fl=(s.t-(s.calFlipT==null?-99:s.calFlipT))/0.9;if(fl>=0&&fl<1){var k=fl;poly([wallPt(w,u+0.2,1.75,0.04),wallPt(w,u+0.8,1.75,0.04),wallPt(w,u+0.8,1.75-0.55*(1-k),0.04+k*0.25),wallPt(w,u+0.2,1.75-0.55*(1-k),0.04+k*0.25)],"#f4efe2",OUT);}
    var dp=wallPt(w,mid,1.45,0.03);txt(""+(1+Math.floor((s.t*2+480)/1440)%31),dp[0],dp[1],9,"#333");break;}
  case "spiceRack":{Q(0.1,0.9,1.3,1.36,"#7a5232");Q(0.1,0.9,1.6,1.66,"#7a5232");for(var j=0;j<4;j++){var jp=wallPt(w,u+0.2+j*0.2,1.36,0.08),bob=papaDoing(sim,"eat")&&(Math.floor(T*2+j)%2===0)?Math.sin(T*10)*1.2*Z:0;ctx.fillStyle=["#c0392b","#e67e22","#27ae60","#f1c40f"][j];ctx.fillRect(jp[0]-2*Z,jp[1]-8*Z+bob,4*Z,8*Z);ctx.fillStyle="#eee";ctx.fillRect(jp[0]-2*Z,jp[1]-9.5*Z+bob,4*Z,2*Z);}break;}
  case "window":{var m2=sim.shiftMin(),day=m2>=360&&m2<1200,sky=day?(m2<480||m2>1080?"#f2a65a":"#8fd0ff"):"#1b2340";Q(0.15,n-0.15,1.0,2.1,"#f3efe4");Q(0.25,n-0.25,1.08,2.02,sky);
    if(!day){for(var st=0;st<5;st++){var sp=wallPt(w,u+0.4+st*0.3,1.4+(st%2)*0.4,0.03);ctx.fillStyle="#fff";ctx.fillRect(sp[0],sp[1],Z,Z);}}else{var cl=wallPt(w,u+0.4+((T*0.03)%1)*(n-0.8),1.8,0.03);ctx.fillStyle="#fff";ctx.beginPath();ctx.ellipse(cl[0],cl[1],6*Z,2.5*Z,0,0,6.28);ctx.fill();}
    line(wallPt(w,mid,1.08,0.03),wallPt(w,mid,2.02,0.03),"#f3efe4",2);var cw=fanOn(sim)?Math.sin(T*1.1)*0.04:0;Q(0.1,0.4+cw,1.0,2.15,"#d65a5a",null);Q(n-0.4-cw,n-0.1,1.0,2.15,"#d65a5a",null);break;}
  case "poster":{var fan=fanOn(sim)?1:0,fl2=Math.sin(T*2.2)*0.04*fan;Q(0.15,0.85,1.1,2.0,"#f5e6b8");var pc=wallPt(w,mid,1.6,0.03);drawPapaBody([pc[0],pc[1]+12*Z],0.3,{face:1,dir:1,tt:T,still:1,flat:1});txt("PAPA",pc[0],wallPt(w,mid,1.17,0.03)[1],7,"#a33");
    var fl3=0.08+Math.sin(T*2.2)*0.07*fan;poly([wallPt(w,u+0.85,2.0,0.03),wallPt(w,u+0.85,1.7,0.03),wallPt(w,u+0.62,2.0,0.03+fl3)],"#e0cf9c","rgba(90,70,30,0.6)");break;}
  case "potsPans":{Q(0.1,n-0.1,1.95,2.0,"#555");var bp=brush(o,w==="N"?mid:0.5,w==="N"?0.5:mid);for(var pn=0;pn<3;pn++){var sw2=Math.sin(T*1.3+pn)*0.05*bp,pu=u+0.35+pn*(n-0.7)/2,hp=wallPt(w,pu,1.95,0.05),pp=wallPt(w,pu+sw2,1.55-pn*0.05,0.08);line(hp,pp,"#444",1);ctx.beginPath();ctx.ellipse(pp[0],pp[1]+5*Z,(6-pn)*Z,(5-pn*0.6)*Z,0,0,6.28);ctx.fillStyle=pn===1?"#b87333":"#3a3a3a";ctx.fill();ctx.strokeStyle="#111";ctx.stroke();}break;}
  case "photos":{for(var ph=0;ph<3;ph++){var a0=0.12+ph*0.27,h0=1.3+(ph%2)*0.3;Q(a0,a0+0.24,h0,h0+0.3,"#7a5232");Q(a0+0.03,a0+0.21,h0+0.03,h0+0.27,"#f2d98a",null);var fp3=wallPt(w,u+a0+0.12,h0+0.14,0.03);ctx.fillStyle="#9a6a3a";ctx.beginPath();ctx.ellipse(fp3[0],fp3[1],2.5*Z,3*Z,0,0,6.28);ctx.fill();}break;}
  case "towelRack":{Q(0.1,0.9,1.5,1.55,"#bbb");var sw3=Math.sin(T*1.2)*0.03*brush(o,w==="N"?mid:0.5,w==="N"?0.5:mid);poly([wallPt(w,u+0.2,1.52,0.05),wallPt(w,u+0.8,1.52,0.05),wallPt(w,u+0.8+sw3,1.0,0.07),wallPt(w,u+0.2+sw3,1.0,0.07)],"#5dade2",OUT);for(var sl=0;sl<3;sl++)line(wallPt(w,u+0.2+sw3*0.5,1.15+sl*0.1,0.07),wallPt(w,u+0.8+sw3*0.5,1.15+sl*0.1,0.07),"rgba(255,255,255,0.6)");break;}
  case "soap":{Q(0.3,0.7,1.1,1.55,"#f2f2f2");Q(0.35,0.65,1.2,1.45,"#e88cc8",null);if(!papaDoing(sim,"scrub"))break;var dd=(T*0.7)%1;var dp2=wallPt(w,mid,1.08-dd*0.4,0.06);ctx.fillStyle="rgba(232,140,200,"+(1-dd)+")";ctx.beginPath();ctx.ellipse(dp2[0],dp2[1],2.4*Z,3.2*Z,0,0,6.28);ctx.fill();
    for(var sb=0;sb<3;sb++){var bph=(T*0.45+sb/3)%1,bp3=wallPt(w,mid+(sb-1)*0.25+Math.sin(T*2+sb)*0.08,1.6+bph*0.7,0.12);ctx.strokeStyle="rgba(255,200,240,"+(1-bph)+")";ctx.lineWidth=Math.max(0.8,1.2*Z);ctx.beginPath();ctx.arc(bp3[0],bp3[1],(2+bph*3)*Z,0,6.28);ctx.stroke();}break;}
  case "stringLights":{for(var lb=0;lb<9;lb++){var lu=u+0.1+lb*(n-0.2)/8,lh=2.15-Math.sin(lb/8*Math.PI)*0.18,lp2=wallPt(w,lu,lh,0.04),on=((Math.floor(T*3)+lb)%3)!==0;if(lb){var pv=wallPt(w,u+0.1+(lb-1)*(n-0.2)/8,2.15-Math.sin((lb-1)/8*Math.PI)*0.18,0.04);line(pv,lp2,"#333",0.8);}
      ctx.beginPath();ctx.arc(lp2[0],lp2[1]+2*Z,2.2*Z,0,6.28);ctx.fillStyle=on?["#ff6b6b","#ffd93d","#6bcBff","#7dff9a"][lb%4]:"#555";ctx.fill();}break;}
  case "neonSign":{var flick=(Math.floor(T*7)%23)!==0&&Math.sin(T*1.7)>-0.85;Q(0.08,0.92,1.45,1.95,"#1a1a24");var np=wallPt(w,mid,1.7,0.03);txt("OPEN",np[0],np[1],9,flick?"#ff4fd8":"#552244");if(flick){ctx.globalAlpha=0.1+0.12*(0.5+0.5*Math.sin(T*4));ctx.beginPath();ctx.arc(np[0],np[1],(18+5*Math.sin(T*4))*Z,0,6.28);ctx.fillStyle="#ff4fd8";ctx.fill();ctx.globalAlpha=1;}break;}
  case "trophyShelf":{Q(0.1,n-0.1,1.4,1.47,"#6b4a2b");var cups=sim.cups();for(var cu=0;cu<3;cu++){var tp=wallPt(w,u+0.4+cu*(n-0.8)/2,1.47,0.08),got=cu<cups,gl=got?0.6:0;ctx.fillStyle=got?"rgb("+(220+30*gl|0)+","+(180+40*gl|0)+",40)":"#555";ctx.fillRect(tp[0]-3*Z,tp[1]-9*Z,6*Z,6*Z);ctx.fillRect(tp[0]-1*Z,tp[1]-3*Z,2*Z,3*Z);}break;}
  default:Q(0.2,n-0.2,1.2,1.8,"#999");
  }}
function drawBasin(sim){var b=sim.s.basin;if(b.duck){var a=T*0.4,dx=18.5+Math.cos(a)*0.7,dy=13.8+Math.sin(a)*1.0,bob=Math.sin(T*3)*0.02;ell(dx,dy,WL+0.08+bob,6,4,"#ffd31a","#a80");ell(dx+0.12,dy-0.05,WL+0.23+bob,3.5,3.5,"#ffd31a","#a80");var bk=P(dx+0.2,dy-0.05,WL+0.22+bob);ctx.fillStyle="#f80";ctx.fillRect(bk[0],bk[1]-Z,3*Z,2*Z);}
  if(b.toyBoat){var c=sim.s.flowOff?8:(T*0.9)%(S.SHIP_C-0.5),p=sim.canalPos(c),bb=Math.sin(T*4)*0.02;var hp=P(p.x,p.y,WL+0.06+bb);ctx.fillStyle="#c0392b";ctx.beginPath();ctx.moveTo(hp[0]-8*Z,hp[1]);ctx.lineTo(hp[0]+8*Z,hp[1]);ctx.lineTo(hp[0]+5*Z,hp[1]+4*Z);ctx.lineTo(hp[0]-5*Z,hp[1]+4*Z);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.moveTo(hp[0],hp[1]-14*Z);ctx.lineTo(hp[0]+6*Z,hp[1]-2*Z);ctx.lineTo(hp[0],hp[1]-2*Z);ctx.fill();line([hp[0],hp[1]-14*Z],[hp[0],hp[1]],"#5a3a22",1);}
  if(b.bubbles){box(19.4,12.3,0.4,0.3,0,0.2,"#7f8c8d");for(var i=0;i<8;i++){var ph=(T*0.6+i/8)%1;ctx.globalAlpha=1-ph;ell(18+((i*37)%10)/5,12.6+((i*53)%10)/3.3,0.1+ph*0.6,2+ph*2,2+ph*2,"rgba(255,255,255,0.6)","rgba(150,210,255,0.9)");ctx.globalAlpha=1;}}}
/* ---------- PAPA v2: same potato guy, better proportions, shading, smoother animation ---------- */
function blob(cx,cy,rx,ry){ctx.beginPath();ctx.moveTo(cx,cy-ry);ctx.bezierCurveTo(cx+rx*0.62,cy-ry*1.02,cx+rx*1.04,cy-ry*0.42,cx+rx*0.98,cy+ry*0.12);ctx.bezierCurveTo(cx+rx*0.92,cy+ry*0.78,cx+rx*0.42,cy+ry*1.0,cx-rx*0.05,cy+ry*0.98);
  ctx.bezierCurveTo(cx-rx*0.6,cy+ry*0.96,cx-rx*1.02,cy+ry*0.6,cx-rx*0.98,cy+ry*0.02);ctx.bezierCurveTo(cx-rx*0.94,cy-ry*0.55,cx-rx*0.55,cy-ry*0.98,cx,cy-ry);ctx.closePath();}
function limb(a,b,c,w){ctx.strokeStyle=c;ctx.lineCap="round";ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();ctx.lineCap="butt";}
/* ---------- Papa 2.0.1: a round retro ROBOT chef (Jay t1229 decision): warm cream + orange, screen face with moods,
   single wheel on a hover suspension, apron + chef hat (or a hat he bought), arms with mitt hands that hold every tool. ---------- */
var PS=1;
function ik(S,Hd,L1,L2,bend){var dx=Hd[0]-S[0],dy=Hd[1]-S[1],d=Math.hypot(dx,dy)||0.001,mx=L1+L2-0.01;
  if(d>mx){Hd=[S[0]+dx/d*mx,S[1]+dy/d*mx];dx=Hd[0]-S[0];dy=Hd[1]-S[1];d=mx;}
  var a=(L1*L1-L2*L2+d*d)/(2*d),h=Math.sqrt(Math.max(0,L1*L1-a*a)),px=S[0]+dx*a/d,py=S[1]+dy*a/d;
  return {e:[px-dy/d*h*bend,py+dx/d*h*bend],h:Hd};}
var PAPA_COL={body:["#fff6e6","#f1dfc0","#c7a984"],orange:["#ffad5c","#f08a3c","#b9581f"],dark:"#5a4636",wheel:["#5b5450","#3a3431","#211c1a"],apron:["#ffffff","#ece8df","#c9c2b4"],strap:"#ddd6c8",
  screen:"#211814",glow:"#ffc46b",glow2:"#ff9b3d",hat:["#ffffff","#efece6","#c9c4ba"],line:"rgba(70,48,30,0.8)",metal:"#d9cdb8"};
var PAPA_GOLD={body:["#fff3b0","#e8c24a","#a8861a"],orange:["#ffe680","#e2b93b","#a8861a"],dark:"#8a6a12",wheel:["#d9b030","#a8861a","#7a5f10"],apron:["#fff3b0","#ecc955","#b8921f"],strap:"#d9b030",
  screen:"#8a6a12",glow:"#fff6c8",glow2:"#ffe680",hat:["#fff6c8","#ecc955","#b8921f"],line:"rgba(110,80,10,0.8)",metal:"#ecc955"};
function grad(x0,x1,y,c){var g=ctx.createLinearGradient(x0,y,x1,y);g.addColorStop(0,c[0]);g.addColorStop(0.5,c[1]);g.addColorStop(1,c[2]);return g;}
function seg(a,b,c,w,out){ctx.lineCap="round";if(out){ctx.strokeStyle=out;ctx.lineWidth=w+Math.max(0.8,w*0.22);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}
  ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();ctx.lineCap="butt";}
/* rounded rectangle path, hand-built for WebView 83 */
function rrect(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();}
/* the screen face. e = happy | content | sad | focused | tired | hungry | sleep | eat | wow. (x,y) centre, w,h screen size */
function screenFace(x,y,w,h,k,e,C,t){var g=C.glow,lw=Math.max(0.8,1.3*k);ctx.save();ctx.shadowColor="rgba(255,170,60,0.0)";ctx.strokeStyle=g;ctx.fillStyle=g;ctx.lineWidth=lw;ctx.lineCap="round";
  var ex=w*0.22,ey=y-h*0.12,blink=(t%4.1)<0.12&&e!=="sleep";
  function eyes(kind){[-1,1].forEach(function(sd){var X=x+sd*ex,Y=ey;ctx.beginPath();
    if(blink||kind==="line"){ctx.moveTo(X-2.2*k,Y);ctx.lineTo(X+2.2*k,Y);ctx.stroke();}
    else if(kind==="happy"){ctx.arc(X,Y+1*k,2.3*k,3.5,5.9);ctx.stroke();}
    else if(kind==="sad"){ctx.moveTo(X-2.2*k,Y-1*k+sd*0.8*k);ctx.lineTo(X+2.2*k,Y-1*k-sd*0.8*k);ctx.stroke();ctx.beginPath();ctx.arc(X,Y+0.8*k,1.3*k,0,6.28);ctx.fill();}
    else if(kind==="focus"){ctx.fillRect(X-2.3*k,Y-0.7*k,4.6*k,1.6*k);}
    else if(kind==="tired"){ctx.moveTo(X-2.2*k,Y+0.2*k);ctx.lineTo(X+2.2*k,Y+0.2*k);ctx.stroke();ctx.beginPath();ctx.arc(X,Y+0.2*k,1.6*k,0,3.14);ctx.fill();}
    else if(kind==="wow"){ctx.arc(X,Y,2.1*k,0,6.28);ctx.stroke();ctx.beginPath();ctx.arc(X,Y,0.9*k,0,6.28);ctx.fill();}
    else{ctx.arc(X,Y,1.7*k,0,6.28);ctx.fill();}});}
  var my=y+h*0.2;
  if(e==="happy"){eyes("happy");ctx.beginPath();ctx.arc(x,my-1.6*k,3.4*k,0.35,2.8);ctx.stroke();}
  else if(e==="content"){eyes("dot");ctx.beginPath();ctx.arc(x,my-1.8*k,2.6*k,0.5,2.65);ctx.stroke();}
  else if(e==="sad"){eyes("sad");ctx.beginPath();ctx.arc(x,my+2*k,2.6*k,3.7,5.7);ctx.stroke();}
  else if(e==="focused"){eyes("focus");ctx.beginPath();ctx.moveTo(x-2*k,my);ctx.lineTo(x+2*k,my);ctx.stroke();ctx.beginPath();ctx.moveTo(x+ex+3.6*k,ey-3.2*k);ctx.lineTo(x+ex+4.6*k,ey-4.4*k);ctx.stroke();}
  else if(e==="tired"){[-1,1].forEach(function(sd){var X=x+sd*ex;ctx.beginPath();ctx.arc(X,ey-0.6*k,2.1*k,0.35,2.8);ctx.stroke();});ctx.beginPath();ctx.moveTo(x-1.6*k,my);ctx.lineTo(x+1.6*k,my);ctx.stroke();
    ctx.strokeRect(x+w*0.3,y-h*0.38,3.4*k,1.8*k);ctx.fillStyle="#ff6a4d";ctx.fillRect(x+w*0.3+0.3*k,y-h*0.38+0.3*k,0.8*k,1.2*k);}
  else if(e==="hungry"){eyes("dot");ctx.beginPath();ctx.ellipse(x,my,1.8*k,1.4*k+Math.abs(Math.sin(t*4))*0.6*k,0,0,6.28);ctx.stroke();
    /* low battery icon, blinking */
    if(Math.floor(t*2)%2){ctx.strokeRect(x+w*0.3,y-h*0.38,3.4*k,1.8*k);ctx.fillStyle=C.glow2;ctx.fillRect(x+w*0.3+0.3*k,y-h*0.38+0.3*k,0.9*k,1.2*k);}}
  else if(e==="eat"){eyes("happy");var fill=(t*0.8)%1;ctx.strokeRect(x-3.6*k,my-1.2*k,7.2*k,3*k);ctx.fillRect(x+3.6*k,my-0.4*k,0.8*k,1.4*k);ctx.fillRect(x-3.1*k,my-0.7*k,6.2*k*fill,2*k);}
  else if(e==="sleep"){eyes("line");ctx.beginPath();ctx.arc(x,my-0.8*k,1.3*k,0.3,2.84);ctx.stroke();var zt=(t*0.7)%1;ctx.globalAlpha=1-zt;ctx.font="bold "+Math.max(6,Math.round(4*k))+"px monospace";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText("z",x+w*0.3+zt*1.5*k,y-h*0.25-zt*2*k);ctx.globalAlpha=1;}
  else if(e==="wow"){eyes("wow");ctx.beginPath();ctx.arc(x,my,1.4*k,0,6.28);ctx.stroke();}
  ctx.lineCap="butt";ctx.restore();}
/* accessories Papa can own (bought by you or by himself in AUTO MODE) */
function drawHat(kind,hx,top,hw,k,C,m){if(kind==="none")return;
  if(kind==="beanie"){ctx.beginPath();ctx.ellipse(hx,top+1*k,hw*0.52,hw*0.42,0,3.14,6.28);ctx.closePath();ctx.fillStyle=grad(hx-hw/2,hx+hw/2,top,["#ff8a6a","#e0553a","#9e3322"]);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.6,0.7*k);ctx.stroke();
    rrect(hx-hw*0.55,top-0.4*k,hw*1.1,3*k,1.4*k);ctx.fillStyle="#c9432c";ctx.fill();ctx.stroke();ctx.fillStyle="#fff1e0";ctx.beginPath();ctx.arc(hx,top-hw*0.45,2.4*k,0,6.28);ctx.fill();ctx.stroke();return;}
  if(kind==="top"){rrect(hx-hw*0.62,top-0.8*k,hw*1.24,2.4*k,1*k);ctx.fillStyle="#2b2522";ctx.fill();rrect(hx-hw*0.4,top-14*k,hw*0.8,14*k,1.5*k);ctx.fillStyle=grad(hx-hw*0.4,hx+hw*0.4,top,["#4a413c","#2b2522","#151110"]);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.6,0.7*k);ctx.stroke();ctx.fillStyle="#f08a3c";ctx.fillRect(hx-hw*0.4,top-4*k,hw*0.8,2.2*k);return;}
  if(kind==="party"){ctx.beginPath();ctx.moveTo(hx-hw*0.35,top+0.5*k);ctx.lineTo(hx+hw*0.35,top+0.5*k);ctx.lineTo(hx+1*k*m,top-16*k);ctx.closePath();ctx.fillStyle=grad(hx-hw*0.35,hx+hw*0.35,top,["#9fe0ff","#4aa8e0","#2a6f9e"]);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.6,0.7*k);ctx.stroke();
    ctx.fillStyle="#ffd34d";[[-0.15,-4],[0.12,-8],[-0.05,-12]].forEach(function(d){ctx.beginPath();ctx.arc(hx+d[0]*hw,top+d[1]*k,1*k,0,6.28);ctx.fill();});ctx.fillStyle="#ff6a8a";ctx.beginPath();ctx.arc(hx+1*k*m,top-16.5*k,1.8*k,0,6.28);ctx.fill();return;}
  /* chef hat (default): band + puffy top */
  rrect(hx-hw*0.42,top-5*k,hw*0.84,5.6*k,1.2*k);ctx.fillStyle=grad(hx-hw*0.42,hx+hw*0.42,top,C.hat);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.6,0.7*k);ctx.stroke();
  ctx.fillStyle=C.hat[1];[[-0.3,-8,5.2],[0.3,-8.4,5.2],[0,-11.4,6]].forEach(function(c2){ctx.beginPath();ctx.arc(hx+c2[0]*hw,top+c2[1]*k,c2[2]*k,0,6.28);ctx.fill();ctx.stroke();});
  ctx.fillStyle=C.hat[0];[[-0.3,-8,5.2],[0.3,-8.4,5.2],[0,-11.4,6]].forEach(function(c2){ctx.beginPath();ctx.arc(hx+c2[0]*hw-0.8*k,top+c2[1]*k-0.8*k,c2[2]*k*0.72,0,6.28);ctx.fill();});
  ctx.strokeStyle=C.hat[2];ctx.lineWidth=Math.max(0.5,0.5*k);ctx.beginPath();ctx.moveTo(hx-hw*0.2,top-4.6*k);ctx.lineTo(hx-hw*0.24,top-0.6*k);ctx.moveTo(hx+hw*0.15,top-4.6*k);ctx.lineTo(hx+hw*0.17,top-0.6*k);ctx.stroke();}
/* Papa the robot: pt = floor point under his wheel. o.hands(cx,sy,k,m) -> {l: far hand, r: near (tool) hand}; sy is his working shoulder line (70k above the floor). */
function drawPapaBody(pt,sc,o){var C=o.gold?PAPA_GOLD:PAPA_COL,k=Z*sc*PS,fx=pt[0],fy=pt[1],m=o.mir?-1:1,ph=o.walk||0,mv=o.moving?1:0,t=o.tt||T,front=!!o.face,acc=o.acc||{};
  var lw=Math.max(0.6,0.75*k),OUTL=C.line,lean=(o.lean||0)*k+(mv?1.6*k:0);
  /* hover bob on the suspension; rolling adds a little wobble */
  var bob=o.still?0:Math.sin(t*3.1)*1.0*k+(mv?Math.sin(ph*12)*0.5*k:0),sink=o.sit?10*k:(o.chair?-0:0);
  var base=o.chair?fy:fy,wy=base-6*k;
  var by0=o.chair?base-2*k:base-14*k+sink,bodyH=o.chair?32*k:36*k,bcy=by0-bodyH/2-bob,cx=fx+lean*m,bw=17*k;
  var sy=base-70*k+(o.sit?10*k:0)+(o.chair?18*k:0)-bob,shY=bcy-bodyH*0.32;
  if(!o.flat){ctx.fillStyle="rgba(0,0,0,0.22)";ctx.beginPath();ctx.ellipse(fx,fy,13*k,4.6*k,0,0,6.28);ctx.fill();}
  var farS=[cx+bw*0.92*m,shY+1*k],nearS=[cx-bw*0.95*m,shY];
  var H=o.hands?o.hands(cx,sy,k,m):{l:[farS[0]+2.5*k*m+(mv?Math.sin(ph*9)*2*k*m:0),shY+21*k],r:[nearS[0]-2.5*k*m-(mv?Math.sin(ph*9)*2*k*m:0),shY+21*k]};
  if(!front){var tmp=farS;farS=nearS;nearS=tmp;}
  var armF=ik(farS,H.l,12.5*k,12.5*k,m),armN=ik(nearS,H.r,12.5*k,12.5*k,m);H={l:armF.h,r:armN.h};
  if(o.back)o.back(cx,shY,k,m);
  /* wheel + fork (hidden when he sits in the armchair) */
  if(!o.chair){var spin=(ph*14)%6.283;seg([cx-1*k*m,by0-2*k-bob],[fx,wy],C.dark,4*k,OUTL);
    ctx.beginPath();ctx.ellipse(fx,wy,6.2*k,6*k,0,0,6.28);ctx.fillStyle=grad(fx-6*k,fx+6*k,wy,C.wheel);ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw;ctx.stroke();
    ctx.beginPath();ctx.ellipse(fx,wy,2.6*k,2.5*k,0,0,6.28);ctx.fillStyle=C.orange[1];ctx.fill();ctx.stroke();
    ctx.strokeStyle="rgba(255,255,255,0.25)";ctx.lineWidth=Math.max(0.5,0.6*k);for(var s2=0;s2<3;s2++){var a2=spin+s2*2.09;ctx.beginPath();ctx.moveTo(fx+Math.cos(a2)*2.6*k,wy+Math.sin(a2)*2.5*k);ctx.lineTo(fx+Math.cos(a2)*5.4*k,wy+Math.sin(a2)*5.2*k);ctx.stroke();}}
  function arm(S2,A,isNear){var c=isNear?C.orange[1]:C.orange[2];seg(S2,A.e,c,4.4*k,OUTL);seg(A.e,A.h,c,4*k,OUTL);seg(S2,[(S2[0]+A.e[0])/2,(S2[1]+A.e[1])/2-0.6*k],isNear?C.orange[0]:C.orange[1],1.6*k);
    ctx.fillStyle=isNear?C.metal:C.body[2];ctx.beginPath();ctx.arc(A.e[0],A.e[1],2.6*k,0,6.28);ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw;ctx.stroke();
    /* mitt hand with a thumb */
    ctx.fillStyle=isNear?C.body[1]:C.body[2];ctx.beginPath();ctx.arc(A.h[0],A.h[1],3.1*k,0,6.28);ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(A.h[0]+1.9*k*m,A.h[1]-1.8*k,1.3*k,0,6.28);ctx.fill();ctx.stroke();}
  arm(farS,armF,false);
  /* body: a warm cream barrel with an orange belly band */
  rrect(cx-bw,bcy-bodyH/2,bw*2,bodyH,bw*0.98);ctx.fillStyle=grad(cx-bw,cx+bw,bcy,C.body);ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw;ctx.stroke();
  ctx.save();rrect(cx-bw,bcy-bodyH/2,bw*2,bodyH,bw*0.98);ctx.clip();ctx.fillStyle=grad(cx-bw,cx+bw,bcy,C.orange);ctx.fillRect(cx-bw,bcy+bodyH*0.12,bw*2,bodyH*0.16);
    ctx.fillStyle="rgba(255,255,255,0.35)";ctx.beginPath();ctx.ellipse(cx-bw*0.45,bcy-bodyH*0.22,bw*0.28,bodyH*0.22,-0.2,0,6.28);ctx.fill();ctx.restore();
  if(front){/* apron over the front */
    var ax=cx+2*k*m,at=bcy-bodyH*0.3,ab=bcy+bodyH*0.47;ctx.beginPath();ctx.moveTo(ax-6*k,at);ctx.lineTo(ax+6*k,at);ctx.lineTo(ax+7*k,bcy-2*k);ctx.quadraticCurveTo(ax+11*k,bcy+2*k,ax+10*k,ab);ctx.quadraticCurveTo(ax,ab+2*k,ax-10*k,ab);ctx.quadraticCurveTo(ax-11*k,bcy+2*k,ax-7*k,bcy-2*k);ctx.closePath();
    ctx.fillStyle=grad(ax-11*k,ax+11*k,bcy,C.apron);ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw;ctx.stroke();
    seg([ax-5.5*k,at],[cx-5*k,bcy-bodyH/2+1.5*k],C.strap,1.3*k);seg([ax+5.5*k,at],[cx+5*k,bcy-bodyH/2+1.5*k],C.strap,1.3*k);
    ctx.strokeStyle=C.apron[2];ctx.lineWidth=lw*0.8;ctx.strokeRect(ax-4*k,bcy+3*k,8*k,5*k);seg([ax-1*k,bcy+3*k],[ax-1*k,bcy+0.5*k],"#7a6a55",0.8*k);
    /* a little dial + two rivets above the apron */
    ctx.fillStyle=C.orange[1];ctx.beginPath();ctx.arc(cx-8*k*m,bcy-bodyH*0.3,1.4*k,0,6.28);ctx.fill();ctx.fillStyle=C.metal;ctx.beginPath();ctx.arc(cx+9*k*m,bcy-bodyH*0.3,1*k,0,6.28);ctx.fill();
    if(acc.bow){var bwy=bcy-bodyH/2+1.6*k,bwx=cx+2*k*m;ctx.fillStyle="#d8323c";ctx.beginPath();ctx.moveTo(bwx,bwy);ctx.lineTo(bwx-4.5*k,bwy-2.4*k);ctx.lineTo(bwx-4.5*k,bwy+2.4*k);ctx.closePath();ctx.moveTo(bwx,bwy);ctx.lineTo(bwx+4.5*k,bwy-2.4*k);ctx.lineTo(bwx+4.5*k,bwy+2.4*k);ctx.closePath();ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw*0.8;ctx.stroke();ctx.beginPath();ctx.arc(bwx,bwy,1.2*k,0,6.28);ctx.fill();ctx.stroke();}}
  else{/* back: vent grill + apron bow */
    ctx.strokeStyle=C.body[2];ctx.lineWidth=Math.max(0.6,0.9*k);for(var v=0;v<4;v++){ctx.beginPath();ctx.moveTo(cx-6*k,bcy-bodyH*0.28+v*2.4*k);ctx.lineTo(cx+6*k,bcy-bodyH*0.28+v*2.4*k);ctx.stroke();}
    seg([cx-bw*0.9,bcy+0.5*k],[cx+bw*0.9,bcy+0.5*k],C.strap,1.5*k);ctx.fillStyle=C.strap;ctx.beginPath();ctx.ellipse(cx-2.2*k,bcy+0.5*k,2.4*k,1.6*k,0.4,0,6.28);ctx.ellipse(cx+2.2*k,bcy+0.5*k,2.4*k,1.6*k,-0.4,0,6.28);ctx.fill();}
  /* neck + head (retro TV box with the screen face) */
  var hw=24*k,hh=19*k,hcx=cx+(front?1*k*m:0)+(o.nod?2*k*m:0),htop=bcy-bodyH/2-hh-2.6*k+(o.nod?2.5*k:0);
  ctx.fillStyle=C.dark;ctx.fillRect(cx-3*k,bcy-bodyH/2-3*k,6*k,4*k);
  rrect(hcx-hw/2,htop,hw,hh,5*k);ctx.fillStyle=grad(hcx-hw/2,hcx+hw/2,htop,C.body);ctx.fill();ctx.strokeStyle=OUTL;ctx.lineWidth=lw;ctx.stroke();
  /* side "ears" (orange knobs) */
  [-1,1].forEach(function(sd){ctx.fillStyle=sd===m?C.orange[2]:C.orange[1];ctx.beginPath();ctx.ellipse(hcx+sd*(hw/2+0.8*k),htop+hh*0.5,1.6*k,3.2*k,0,0,6.28);ctx.fill();ctx.strokeStyle=OUTL;ctx.stroke();});
  if(front){var sw2=hw-6*k,sh2=hh-6*k,scx2=hcx+1.2*k*m;rrect(scx2-sw2/2,htop+3*k,sw2,sh2,3.2*k);ctx.fillStyle=C.screen;ctx.fill();ctx.strokeStyle=C.orange[2];ctx.lineWidth=Math.max(0.8,1.1*k);ctx.stroke();
    var sg=ctx.createRadialGradient(scx2,htop+3*k+sh2/2,1,scx2,htop+3*k+sh2/2,sw2*0.6);sg.addColorStop(0,"rgba(255,180,90,0.16)");sg.addColorStop(1,"rgba(255,180,90,0)");ctx.fillStyle=sg;ctx.fill();
    screenFace(scx2,htop+3*k+sh2/2,sw2,sh2,k,o.expr||"content",C,t);
    ctx.fillStyle="rgba(255,255,255,0.12)";ctx.beginPath();ctx.moveTo(scx2-sw2/2+2*k,htop+4*k);ctx.lineTo(scx2-sw2/2+7*k,htop+4*k);ctx.lineTo(scx2-sw2/2+3*k,htop+3*k+sh2-1*k);ctx.lineTo(scx2-sw2/2+1.4*k,htop+3*k+sh2-1*k);ctx.closePath();ctx.fill();
    if(acc.glasses){var gy=htop+3*k+sh2*0.38,gx=scx2;ctx.fillStyle="rgba(20,16,14,0.92)";[-1,1].forEach(function(sd){rrect(gx+sd*sw2*0.22-3.8*k,gy-2.2*k,7.6*k,4.6*k,1.8*k);ctx.fill();});ctx.strokeStyle="#111";ctx.lineWidth=Math.max(0.8,1*k);ctx.beginPath();ctx.moveTo(gx-1.6*k,gy-0.6*k);ctx.lineTo(gx+1.6*k,gy-0.6*k);ctx.stroke();ctx.fillStyle="rgba(255,255,255,0.35)";ctx.fillRect(gx-sw2*0.22-2.6*k,gy-1.4*k,1.6*k,0.8*k);ctx.fillRect(gx+sw2*0.22-2.6*k,gy-1.4*k,1.6*k,0.8*k);}}
  else{ctx.fillStyle=C.body[2];rrect(hcx-6*k,htop+5*k,12*k,8*k,2*k);ctx.fill();ctx.fillStyle=C.orange[1];ctx.beginPath();ctx.arc(hcx,htop+9*k,1.2*k,0,6.28);ctx.fill();}
  /* antenna (tip glows with his mood) + hat */
  var ant=[hcx-6*k*m,htop+0.5*k],tip=[ant[0]-1.5*k*m,ant[1]-5.5*k];seg(ant,tip,C.dark,0.9*k);ctx.fillStyle=o.expr==="sad"||o.expr==="tired"||o.expr==="hungry"?"#ff6a4d":(o.expr==="sleep"?"#7aa0ff":"#7dff9a");ctx.beginPath();ctx.arc(tip[0],tip[1],1.3*k,0,6.28);ctx.fill();
  drawHat(acc.hat||"chef",hcx+1*k*m,htop+1.2*k,hw*0.9,k,C,m);
  arm(nearS,armN,true);
  if(o.front)o.front(cx,shY,k,m,H);
  return {hl:H.l,hr:H.r,bx:cx,by:shY,k:k};}
D.drawPapaBody=drawPapaBody;
function sackDraw(cx,cy,k,n){ctx.fillStyle="#b08a57";ctx.beginPath();ctx.ellipse(cx,cy,8*k,10*k,0,0,6.28);ctx.fill();ctx.strokeStyle="#6b5230";ctx.lineWidth=Math.max(0.6,0.8*k);ctx.stroke();
  ctx.fillStyle="#8c6a3d";ctx.fillRect(cx-3.5*k,cy-11*k,7*k,2.6*k);for(var i=0;i<Math.min(4,n);i++){ctx.fillStyle="rgba(110,80,40,0.6)";ctx.beginPath();ctx.ellipse(cx+(i%2?2.6:-2.6)*k,cy+(i<2?-2:4.5)*k,2.6*k,2.2*k,0,0,6.28);ctx.fill();}
  ctx.strokeStyle="rgba(90,65,35,0.5)";ctx.lineWidth=Math.max(0.5,0.6*k);for(var j=0;j<3;j++){ctx.beginPath();ctx.moveTo(cx-7*k,cy-5*k+j*5.5*k);ctx.lineTo(cx+7*k,cy-4.5*k+j*5.5*k);ctx.stroke();}}
/* broom (wood handle, straw head) and dustpan: in his hands only while he sweeps (and walking to and from the mess); otherwise parked on the wall */
function drawBroomParked(sim){var bx=FIX.broom.x,top=P(bx+0.38,0.04,1.25),foot=P(bx+0.22,0.3,0.06),k=Z;shadow(bx+0.45,0.3,0.25,0.18);
  /* hook on the wall */var hk=P(bx+0.38,0.02,1.3);ctx.fillStyle="#555";ctx.fillRect(hk[0]-2*k,hk[1]-1*k,4*k,2*k);
  broomAt(top,[foot[0],foot[1]-3*k],k,-0.15);
  /* dustpan leaning beside it */var dh=P(bx+0.72,0.05,0.62),dpn=P(bx+0.78,0.28,0.05);dustpanAt(dh,[dpn[0],dpn[1]-2*k],k);
  if(D.broomLabel){var lb=P(bx+0.5,0.3,0);txt("BROOM",lb[0],lb[1]+8*k,6,"rgba(255,233,168,0.75)");}}
function broomAt(top,head,k,ang){seg(top,head,"#9a6a3a",1.7*k,"rgba(60,40,20,0.7)");ctx.save();ctx.translate(head[0],head[1]);ctx.rotate(ang||0);
  ctx.fillStyle="#d8b24a";ctx.beginPath();ctx.moveTo(-2.5*k,-2*k);ctx.lineTo(2.5*k,-2*k);ctx.lineTo(5*k,3.5*k);ctx.lineTo(-5*k,3.5*k);ctx.closePath();ctx.fill();ctx.strokeStyle="#8a6a20";ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();
  ctx.fillStyle="#b23a2a";ctx.fillRect(-2.6*k,-2.4*k,5.2*k,1.3*k);for(var i=-4;i<=4;i+=2){ctx.beginPath();ctx.moveTo(i*0.9*k,0);ctx.lineTo(i*1.15*k,3.4*k);ctx.stroke();}ctx.restore();}
function dustpanAt(hand,pan,k){seg(hand,pan,"#2f6f9a",1.5*k,"rgba(20,40,60,0.7)");ctx.fillStyle="#3b86b8";ctx.beginPath();ctx.moveTo(pan[0]-5*k,pan[1]-1*k);ctx.lineTo(pan[0]+5*k,pan[1]-1*k);ctx.lineTo(pan[0]+4*k,pan[1]+2.5*k);ctx.lineTo(pan[0]-4*k,pan[1]+2.5*k);ctx.closePath();ctx.fill();ctx.strokeStyle="#1d4f72";ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();}
/* 2.0.2 t1244: Papa stands two tiles out in front of the SHIPPING machine and tosses each potato in an arc into the intake */
function drawToss(sim){var p=sim.s.papa,t=p.task;if(!t||t.type!=="drop"||t.stage!=="act"||!p.hold.length)return;var f=Math.min(1,t.t/0.45),e=f*f*(3-2*f);
  var x0=p.x,y0=p.y-0.25,h0=0.95,x1=13.55,y1=15.0,h1=1.2,x=x0+(x1-x0)*e,y=y0+(y1-y0)*e,h=h0+(h1-h0)*e+Math.sin(f*3.1416)*0.75;
  shadow(x,y,0.12,0.25);var a=P(x,y,h),r=3.4*Math.max(0.6,Z);ctx.save();ctx.translate(a[0],a[1]);ctx.rotate(f*7);ctx.fillStyle="#e2c27a";ctx.strokeStyle="#7a5a2a";ctx.lineWidth=Math.max(1,Z);
  ctx.beginPath();ctx.ellipse(0,0,r*1.3,r,0,0,6.283);ctx.fill();ctx.stroke();ctx.restore();}
function drawPapa(sim){var s=sim.s,p=s.papa,t=p.task,act=t&&t.stage==="act",ty=t?t.type:"idle";
  if(act&&(ty==="nap"&&t.lying||ty==="watch"&&t.sit))return;   /* the bed / armchair draws him */
  var pt=P(p.x,p.y,0),scx=p.fx-p.fy,scy=(p.fx+p.fy),mir=scx<-0.01,front=scy>=-0.01||ty==="doze";
  var held=p.hold.map(function(u){return sim.pot(u);}).filter(Boolean),sackOn=s.equip.carrySack&&p.sack.on,broom=s.equip.broomDustpan&&!!p.broomHeld;
  var mood=p.mood==null?60:p.mood,busy=act&&["peel","fix","scrub","sweep","rinse","washRaw","water","tune","toss","drop","grab"].indexOf(ty)>=0,ex;
  if(act&&(ty==="doze"||ty==="nap"))ex="sleep";else if(act&&ty==="eat")ex="eat";else if(p.energy<22)ex="tired";else if(p.hunger<22)ex="hungry";else if(busy)ex="focused";else if(p.wantFlash>0)ex="wow";else if(mood>65)ex="happy";else if(mood<35)ex="sad";else ex="content";
  var o={face:front,mir:mir,walk:p.walkT,moving:p.moving,tt:T,lazy:p.lazy,expr:ex,acc:s.acc||{}};
  /* the sack rides on his back: behind him when he faces us, in front of his back when he walks away */
  o.back=function(cx,sy,k,m){if(front&&sackOn)sackDraw(cx-10*k*m,sy+6*k,k,held.length);};
  var frontExtra=function(cx,sy,k,m,h){if(!front&&sackOn){sackDraw(cx+1*k*m,sy+6*k,k,held.length);}
    if(front&&sackOn){seg([cx-12*k*m,sy-2*k],[cx+8*k*m,sy+16*k],"#8c6a3d",1.4*k);}};
  if(act&&ty==="peel"){o.hands=function(cx,sy,k,m){var a=Math.sin(T*10)*2.4*k;return {l:[cx+9*k*m,sy+16*k],r:[cx+5*k*m+a*m,sy+14*k+a*0.35]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);var cur=sim.pot(t.cur);if(cur){ctx.save();ctx.translate(h.l[0]+1.5*k*m,h.l[1]-2.2*k);ctx.rotate(T*2);ctx.beginPath();ctx.ellipse(0,0,3.6*k,2.7*k,0,0,6.28);var pr=t.prog||0;ctx.fillStyle=pr>0.5?"#f2d98a":"#9a6a3a";ctx.fill();ctx.strokeStyle="rgba(60,30,10,0.6)";ctx.lineWidth=Math.max(0.5,0.5*k);ctx.stroke();ctx.restore();}
      if(s.equip.betterPeeler){seg(h.r,[h.r[0]+3.5*k*m,h.r[1]-3.5*k],"#d0d6dc",1.4*k);seg(h.r,[h.r[0]-1*k*m,h.r[1]+2.4*k],"#2f6f9a",2*k);if(Math.floor(T*4)%2){ctx.fillStyle="#fff";ctx.fillRect(h.r[0]+3*k*m,h.r[1]-4*k,1*k,1*k);}}
      else{seg(h.r,[h.r[0]+4*k*m,h.r[1]-2*k],"#c9d2d8",1.1*k);seg(h.r,[h.r[0]-1.6*k*m,h.r[1]+1*k],"#3a2a1a",1.8*k);}
      if(Math.random()<0.25)part({k:"peel",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.4,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.4,h:0.9,vx:(Math.random()-0.5)*1.2,vy:(Math.random()-0.5)*1.2,vh:1+Math.random(),t:0,life:0.6,r:Math.random()*6});};}
  else if(act&&ty==="sweep"){var swp=Math.sin(T*8);o.lean=3.5;
    /* near hand on the broom, far hand low with the dustpan */
    o.hands=function(cx,sy,k,m){return {l:[cx+13*k*m,sy+30*k],r:[cx+9*k*m+swp*1.5*k*m,sy+22*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);var ux=h.r[0],uy=h.r[1],head=[pt[0]+(19+swp*6)*k*m,pt[1]-0.5*k];var dx=head[0]-ux,dy=head[1]-uy,dl=Math.hypot(dx,dy)||1;
      if(broom){broomAt([ux-dx/dl*9*k,uy-dy/dl*9*k],head,k,swp*0.25);dustpanAt(h.l,[pt[0]+25*k*m,pt[1]+0.5*k],k);}
      if(Math.random()<0.15)part({k:"peel",x:p.x+(Math.random()-0.5)*0.6,y:p.y+0.4,h:0.1,vh:0.5,t:0,life:0.6,r:2+Math.random()*2,vx:0,vy:0});};}
  else if(act&&ty==="scrub"){o.lean=4;o.hands=function(cx,sy,k,m){var a=T*12;return {l:[cx+(12+Math.cos(a+2)*2)*k*m,sy+18*k+Math.sin(a+2)*1.2*k],r:[cx+(9+Math.cos(a)*3)*k*m,sy+17*k+Math.sin(a)*1.6*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);ctx.fillStyle="#b5462f";ctx.fillRect(h.r[0]-3.2*k,h.r[1]-0.6*k,6.4*k,2.4*k);ctx.fillStyle="#f0e0a0";ctx.fillRect(h.r[0]-3.2*k,h.r[1]+1.8*k,6.4*k,1.2*k);
      if(Math.random()<0.2)part({k:"foam",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.5,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.5,h:0.7,vh:0.4,t:0,life:0.8,r:2+Math.random()*2});};}
  else if(act&&ty==="drop"){o.hands=function(cx,sy,k,m){var f=Math.min(1,t.t/0.45);return {l:[cx+11*k*m,sy+6*k-f*3*k],r:[cx+8*k*m,sy-2*k-f*5*k]};};}
  else if(act&&ty==="fix"){o.lean=2;o.hands=function(cx,sy,k,m){var a=Math.sin(T*14);return {l:[cx+13*k*m,sy+9*k],r:[cx+10*k*m,sy+4*k+a*4*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);var a=Math.sin(T*14);seg(h.r,[h.r[0]+6*k*m,h.r[1]+2*k+a*1.5*k],"#9aa3ab",1.8*k,"#5c646b");ctx.strokeStyle="#9aa3ab";ctx.lineWidth=1.4*k;ctx.beginPath();ctx.arc(h.r[0]+7*k*m,h.r[1]+2*k+a*1.5*k,1.8*k,0,5);ctx.stroke();
      if(Math.random()<0.2)part({k:"spark",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.5,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.5,h:1.0,vx:(Math.random()-0.5)*2,vy:(Math.random()-0.5)*2,vh:1.5,t:0,life:0.4,c:"#ffe27a"});};}
  else if(act&&ty==="eat"){var up=0.5+0.5*Math.sin(T*3);o.mouth=up>0.75&&(Math.floor(T*8)%2)?"open":"";
    o.hands=function(cx,sy,k,m){return {l:[cx+6*k*m,sy+15*k],r:[cx+(4-1*up)*k*m,sy+16*k-up*15*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);ctx.fillStyle="#d33";ctx.fillRect(h.l[0]-2.4*k,h.l[1]-4*k,4.8*k,5.5*k);ctx.fillStyle="#ddd";ctx.fillRect(h.l[0]-2.4*k,h.l[1]-4.6*k,4.8*k,1.1*k);seg(h.r,[h.r[0]+1.5*k*m,h.r[1]-3*k],"#c9d2d8",0.9*k);};}
  else if(act&&ty==="doze"){o.sit=true;o.eyesClosed=true;o.nod=true;o.hands=function(cx,sy,k,m){return {l:[cx+13*k*m,sy+24*k],r:[cx+9*k*m,sy+26*k]};};if(Math.random()<0.03)part({k:"z",x:p.x,y:p.y,h:1.8,vh:0.5,t:0,life:2});}
  else if(act&&ty==="water"){o.hands=function(cx,sy,k,m){return {l:[cx+9*k*m,sy+14*k],r:[cx+11*k*m,sy+12*k]};};o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);ctx.fillStyle="#4a8fd0";ctx.fillRect(h.r[0]-2.5*k,h.r[1]-1*k,6*k,5*k);seg([h.r[0]+3.5*k*m,h.r[1]+1*k],[h.r[0]+9*k*m,h.r[1]+4*k],"#4a8fd0",1.4*k);if(Math.random()<0.4)part({k:"drop",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.6,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.6,h:0.8,vx:0,vy:0,vh:-0.5,t:0,life:0.4});};}
  else if(act&&(ty==="rinse"||ty==="washRaw")){o.lean=2;o.hands=function(cx,sy,k,m){var a=Math.sin(T*12)*1.6*k;return {l:[cx+12*k*m-a,sy+17*k],r:[cx+9*k*m+a,sy+16*k]};};if(Math.random()<0.3)part({k:"drop",x:p.x+(sim.tgtCenter(t)[0]-p.x)*0.5,y:p.y+(sim.tgtCenter(t)[1]-p.y)*0.5,h:0.9,vx:(Math.random()-0.5),vy:(Math.random()-0.5),vh:1,t:0,life:0.4});}
  else if(act&&ty==="tune"){o.hands=function(cx,sy,k,m){return {l:[cx+5*k*m,sy+26*k],r:[cx+13*k*m,sy+12*k+Math.sin(T*8)*k]};};}
  else if(act&&(ty==="getBroom"||ty==="parkBroom")){o.hands=function(cx,sy,k,m){return {l:[cx+6*k*m,sy+8*k],r:[cx+11*k*m,sy+4*k]};};}
  else if(broom){/* walking to the mess (or back to the wall): broom and dustpan carried in his hands */
    o.hands=function(cx,sy,k,m){var sw2=p.moving?Math.sin(p.walkT*9):0;return {l:[cx+11*k*m-sw2*4*k*m,sy+26*k],r:[cx-8*k*m+sw2*4*k*m,sy+25*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);broomAt([h.r[0]-1*k*m,h.r[1]-16*k],[h.r[0]+2.5*k*m,h.r[1]+19*k],k,0.1*m);dustpanAt(h.l,[h.l[0]+2*k*m,h.l[1]+6*k],k);};}
  if(!o.hands&&held.length&&!sackOn){o.hands=function(cx,sy,k,m){return {l:[cx+8*k*m,sy+18*k],r:[cx+3*k*m,sy+19*k]};};
    o.front=function(cx,sy,k,m,h){frontExtra(cx,sy,k,m,h);var hp=[(h.l[0]+h.r[0])/2,(h.l[1]+h.r[1])/2-2.4*k];
      for(var i=Math.min(held.length,3)-1;i>=0;i--){var q=held[i];ctx.save();ctx.translate(hp[0]+(i===1?-2.4:i===2?2.4:0)*k,hp[1]-(i?2.6:0)*k);ctx.beginPath();ctx.ellipse(0,0,3.8*k,2.8*k,0.2,0,6.28);
        if(q.k===0){ctx.fillStyle="#9a6a3a";}else{ctx.fillStyle=q.d>0.55?"#cdb46a":q.d>0.15?"#e6cf80":"#f7e39a";}ctx.fill();ctx.strokeStyle="rgba(60,30,10,0.6)";ctx.lineWidth=Math.max(0.5,0.5*k);ctx.stroke();
        if(q.k===1&&q.d>0.15){ctx.fillStyle="rgba(107,74,42,"+(q.d*0.8)+")";ctx.beginPath();ctx.ellipse(-1.2*k,0.6*k,1.8*k,1.2*k,0.4,0,6.28);ctx.fill();}ctx.restore();}};}
  if(!o.front)o.front=frontExtra;
  drawPapaBody(pt,1,o);
  if(p.lazy&&Math.random()<0.02)part({k:"txt",x:p.x,y:p.y,h:2.0,t:0,life:1.2,s:"…",c:"#ddd"});}
/* asleep in bed: his screen head on the pillow showing the sleep face, chef hat set beside it, body under a breathing blanket */
function drawPapaLying(sim,bed){var f=S.fp(bed),k=Z,br=Math.sin(T*2)*0.025,C=PAPA_COL,hc=P(f.x+f.w/2,f.y+0.58,0.74),acc=sim.s.acc||{};
  box(f.x+0.2,f.y+0.95,f.w-0.4,Math.min(1.9,f.h-1.1),0.6,0.14+br,"#3a6fb0",{top:"#4a80c4"});
  var hp=P(f.x+f.w*0.82,f.y+0.45,0.72);if((acc.hat||"chef")!=="none")drawHat(acc.hat||"chef",hp[0],hp[1]+4*k,13*k,0.6*k,C,1);
  ctx.save();ctx.translate(hc[0],hc[1]);ctx.rotate(0.46);var hw=24*k,hh=19*k;rrect(-hw/2,-hh/2,hw,hh,5*k);ctx.fillStyle=grad(-hw/2,hw/2,0,C.body);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.6,0.75*k);ctx.stroke();
  rrect(-hw/2+3*k,-hh/2+3*k,hw-6*k,hh-6*k,3.2*k);ctx.fillStyle=C.screen;ctx.fill();ctx.strokeStyle=C.orange[2];ctx.stroke();screenFace(0,0,hw-6*k,hh-6*k,k,"sleep",C,T);ctx.restore();
  var bm=P(f.x+f.w/2,f.y+1.75,0.74+br);ctx.save();ctx.beginPath();ctx.ellipse(bm[0],bm[1]+1.5*k,17*k,6.5*k*(1+br*2),-0.46,0,6.28);ctx.fillStyle="rgba(20,40,80,0.35)";ctx.fill();ctx.beginPath();ctx.ellipse(bm[0],bm[1]-1*k,16*k,6*k*(1+br*2),-0.46,0,6.28);var bg=ctx.createRadialGradient(bm[0]-3*k,bm[1]-4*k,1,bm[0],bm[1],16*k);bg.addColorStop(0,"#7fb0ea");bg.addColorStop(0.6,"#4f86c8");bg.addColorStop(1,"#3f75b8");ctx.fillStyle=bg;ctx.fill();ctx.strokeStyle="rgba(20,40,80,0.45)";ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();ctx.restore();
  var hd=P(f.x+f.w*0.3,f.y+1.0,0.76);ctx.fillStyle=C.body[1];ctx.beginPath();ctx.arc(hd[0],hd[1],2.8*k,0,6.28);ctx.fill();ctx.strokeStyle=C.line;ctx.lineWidth=Math.max(0.5,0.6*k);ctx.stroke();
  if(Math.random()<0.03)part({k:"z",x:f.x+f.w/2,y:f.y+0.6,h:1.4,vh:0.5,t:0,life:2});}
function drawPapaSitting(sim,tv){var p=sim.s.papa,pt=P(p.x,p.y,0.45);drawPapaBody(pt,1,{face:false,mir:false,tt:T,chair:true,expr:"happy",acc:sim.s.acc||{}});}
function drawSackFloor(sim){var p=sim.s.papa;if(!sim.s.equip.carrySack||p.sack.on)return;var c=P(p.sack.x,p.sack.y,0);shadow(p.sack.x,p.sack.y,0.3);sackDraw(c[0],c[1]-10*Z,Z,p.hold.length);
  txt("SACK",c[0],c[1]-26*Z,7,"rgba(255,233,168,0.85)");}
function drawCat(sim){if(!sim.placed("catBed"))return;var c=sim.s.cat,pt=P(c.x,c.y,0),k=Z,m=(c.fx-c.fy)<0?-1:1,walk=c.st==="walk",nap=c.st==="nap";
  ctx.fillStyle="rgba(0,0,0,0.2)";ctx.beginPath();ctx.ellipse(pt[0],pt[1],8*k,3*k,0,0,6.28);ctx.fill();
  var by=pt[1]-(nap?4:7)*k-(walk?Math.abs(Math.sin(T*10))*1.2*k:0);var col="#e08a3a";
  if(!nap){var lg=walk?Math.sin(T*10)*2*k:0;limb([pt[0]-4*k,by+2*k],[pt[0]-4*k+lg,pt[1]],col,2*k);limb([pt[0]+4*k,by+2*k],[pt[0]+4*k-lg,pt[1]],col,2*k);}
  ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(pt[0],by,8*k,nap?4*k:4.5*k,0,0,6.28);ctx.fill();
  var tail=Math.sin(T*3)*3*k;limb([pt[0]-7*k*m,by],[pt[0]-12*k*m,by-6*k+tail],col,2*k);
  var hx=pt[0]+7*k*m,hy=by-(nap?1:4)*k;ctx.beginPath();ctx.arc(hx,hy,4*k,0,6.28);ctx.fill();ctx.beginPath();ctx.moveTo(hx-3*k,hy-2*k);ctx.lineTo(hx-2*k,hy-6*k);ctx.lineTo(hx,hy-3*k);ctx.moveTo(hx+3*k,hy-2*k);ctx.lineTo(hx+2*k,hy-6*k);ctx.lineTo(hx,hy-3*k);ctx.fill();
  ctx.fillStyle="#222";if(nap){limb([hx-2.5*k,hy],[hx-0.5*k,hy],"#222",0.8*k);limb([hx+0.5*k,hy],[hx+2.5*k,hy],"#222",0.8*k);if(Math.random()<0.02)part({k:"z",x:c.x,y:c.y,h:0.5,vh:0.3,t:0,life:1.6});}else{ctx.fillRect(hx-2*k,hy-1*k,1.2*k,1.2*k);ctx.fillRect(hx+1*k,hy-1*k,1.2*k,1.2*k);}}
/* ---------- floor mess: peels ---------- */
function drawPeels(sim,V){var a=sim.s.peels,cols=["#c58c47","#a8743a","#d9a35f"],k,i,q,p;if(!a.length)return;ctx.lineCap="round";
  /* batched: one stroke per peel colour + one for the highlights (was 2 strokes per peel) */
  var vis=[];for(i=0;i<a.length;i++){q=a[i];if(q.x<V.x0-1||q.x>V.x1+1||q.y<V.y0-1||q.y>V.y1+1)continue;vis.push([q,P(q.x,q.y,0.01)]);}
  ctx.lineWidth=Math.max(1,2*Z);for(k=0;k<3;k++){ctx.beginPath();var any=false;for(i=0;i<vis.length;i++){q=vis[i][0];if(q.c!==k)continue;p=vis[i][1];any=true;ctx.moveTo(p[0]+Math.cos(q.a)*3*Z,p[1]+Math.sin(q.a)*3*Z);ctx.arc(p[0],p[1],3*Z,q.a,q.a+2.6);}if(any){ctx.strokeStyle=cols[k];ctx.stroke();}}
  ctx.strokeStyle="rgba(255,240,190,0.5)";ctx.lineWidth=Math.max(0.5,0.8*Z);ctx.beginPath();for(i=0;i<vis.length;i++){q=vis[i][0];p=vis[i][1];ctx.moveTo(p[0]+Math.cos(q.a+0.4)*2.4*Z,p[1]+Math.sin(q.a+0.4)*2.4*Z);ctx.arc(p[0],p[1],2.4*Z,q.a+0.4,q.a+2.0);}ctx.stroke();ctx.lineCap="butt";}
/* ---------- 2.0.2 t1242: canal outlet (ship drain), FLOW tap, machines that sit over the canal ---------- */
/* the canal ends in a ship drain on the floor before the back wall: a steel lip, a hazard-striped frame and a dark drain the water and potatoes pour into */
function drawDrain(sim){var x0=25.12,x1=25.88,y0=0.12,y1=0.84,h=WL+0.004,on=!sim.s.flowOff;
  poly([P(x0,y0,h),P(x1,y0,h),P(x1,y1,h),P(x0,y1,h)],"#05090c");
  /* inner walls of the drain so it reads as a hole going down */
  poly([P(x0,y0,h),P(x1,y0,h),P(x1,y0+0.16,h-0.0),P(x0,y0+0.16,h)],"#1a2a32");poly([P(x0,y0,h),P(x0+0.12,y0,h),P(x0+0.12,y1,h),P(x0,y1,h)],"#121e24");
  /* hazard frame */
  /* hazard frame: yellow/black stripes all round the drain */
  var fw=0.09,hz=h+0.012;[[x0-fw,y0-fw,x1+fw,y0],[x0-fw,y1,x1+fw,y1+fw],[x0-fw,y0,x0,y1],[x1,y0,x1+fw,y1]].forEach(function(r){poly([P(r[0],r[1],hz),P(r[2],r[1],hz),P(r[2],r[3],hz),P(r[0],r[3],hz)],"#e8c020","#111");});
  for(var k=0;k<5;k++){var xa=x0-fw+k*0.2;[[y0-fw,y0],[y1,y1+fw]].forEach(function(yy){poly([P(xa,yy[0],hz+0.001),P(xa+0.09,yy[0],hz+0.001),P(xa+0.09,yy[1],hz+0.001),P(xa,yy[1],hz+0.001)],"#1a1a1a");});}
  for(k=0;k<4;k++){var ya=y0+k*0.2;[[x0-fw,x0],[x1,x1+fw]].forEach(function(xx){poly([P(xx[0],ya,hz+0.001),P(xx[1],ya,hz+0.001),P(xx[1],ya+0.09,hz+0.001),P(xx[0],ya+0.09,hz+0.001)],"#1a1a1a");});}
  /* steel lip the water pours over */
  box(25.1,y1+0.04,0.8,0.07,WL-0.02,0.06,"#9aa7ad",{top:"#c8d2d6"});
  /* falling water: bright streaks pouring over the lip into the drain (stop when FLOW is off) */
  if(on){for(var i=0;i<7;i++){var xx=x0+0.06+i*0.1,ph=(T*1.6+i*0.37)%1,a=P(xx,y1+0.02,WL+0.03),b=P(xx,y1-0.06-ph*0.32,WL-0.02-ph*0.3);line(a,b,"rgba(190,235,255,"+(0.75*(1-ph))+")",1.6);}
    for(var j=0;j<3;j++){var q=(T*0.9+j/3)%1;isoCirc(25.5,0.46,WL+0.006,0.32*(1-q)+0.04,null,"rgba(170,220,240,"+(0.45*q)+")",1.2);}}
  /* SHIP sign on the wall right above it, arrow pointing down into the drain */
  wallQuad("N",25.12,25.88,0.55,0.98,"#1d4a2a","#0a1a10");var sg=wallPt("N",25.5,0.82,0.02);txt("SHIP",sg[0],sg[1],7,"#c8ffd0");
  var ar=wallPt("N",25.5,0.66,0.02);ctx.fillStyle="#7dff9a";ctx.beginPath();ctx.moveTo(ar[0]-4*Z,ar[1]-2*Z);ctx.lineTo(ar[0]+4*Z,ar[1]-2*Z);ctx.lineTo(ar[0],ar[1]+3*Z);ctx.closePath();ctx.fill();}
/* FLOW tap: a sluice gate across the canal with a red hand wheel; the plate drops into the water when FLOW is OFF */
function drawGate(sim){var G=FIX.gate,x=G.x+0.42,off=!!sim.s.flowOff,r=rso(G);r.sw=r.sw==null?(off?1:0):r.sw+((off?1:0)-r.sw)*0.15;var dn=r.sw;
  box(x,G.y-0.04,0.16,0.16,0,0.82,"#4a5560");box(x,G.y+0.88,0.16,0.16,0,0.82,"#4a5560");
  var z0=0.34-dn*(0.34-WL+0.06);box(x+0.03,G.y+0.12,0.1,0.76,z0,0.42,off?"#8a3a2a":"#6d7a84",{top:off?"#b0503c":"#9aa7b0"});
  box(x-0.02,G.y-0.06,0.2,1.12,0.82,0.1,"#3a434c",{top:"#5a6670"});
  var wc=P(G.x+0.5,G.y+0.5,1.08),rr=7*Z,ang=dn*Math.PI*2;ctx.save();ctx.translate(wc[0],wc[1]);ctx.beginPath();ctx.arc(0,0,rr,0,6.2832);ctx.lineWidth=Math.max(1.5,2.4*Z);ctx.strokeStyle="#d8352a";ctx.stroke();
  for(var k=0;k<3;k++){var a=ang+k*2.094;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);ctx.lineWidth=Math.max(1,1.4*Z);ctx.stroke();}ctx.fillStyle="#7a1a12";ctx.beginPath();ctx.arc(0,0,2*Z,0,6.2832);ctx.fill();ctx.restore();
  var lp=P(x+0.08,G.y,0.9);ctx.beginPath();ctx.arc(lp[0],lp[1],2.6*Z,0,6.2832);ctx.fillStyle=off?"#ff4a3a":"#55ff7a";ctx.fill();ctx.strokeStyle="#111";ctx.lineWidth=Math.max(0.5,0.6*Z);ctx.stroke();
  var lb=P(G.x+0.5,G.y+0.5,1.45),fs=Math.max(9,Math.round(9*Z)),s="FLOW "+(off?"OFF":"ON");ctx.font="bold "+fs+"px monospace";
  var tw=ctx.measureText(s).width,dr=fs*0.36,pw=tw+dr*2+fs*0.9,ph=fs*1.55,px=lb[0]-pw/2,py=lb[1]-ph/2,col=off?"#ff3b30":"#34e06a";
  ctx.fillStyle="rgba(8,12,18,0.94)";rrect(px,py,pw,ph,ph*0.3);ctx.fill();ctx.lineWidth=Math.max(1.5,1.6*Z);ctx.strokeStyle=col;ctx.stroke();
  ctx.fillStyle=col;ctx.beginPath();ctx.arc(px+fs*0.45+dr,lb[1],dr,0,6.283);ctx.fill();ctx.strokeStyle="rgba(255,255,255,0.7)";ctx.lineWidth=1;ctx.stroke();
  ctx.fillStyle="#ffffff";ctx.textAlign="left";ctx.textBaseline="middle";ctx.fillText(s,px+fs*0.45+dr*2+fs*0.3,lb[1]+0.5);}
/* machines over the canal: a back wall on the far bank, two posts and a roof on the near bank, open in the middle so you see potatoes float through */
var CM_LOOK={canalCleaner:{c:"#e9eef2",roof:"#3aa0d8",name:"CLEANER"},sorter:{c:"#f2e6c8",roof:"#e09a2a",name:"SORTER"},dryer:{c:"#efe4e0",roof:"#c8453a",name:"DRYER"},bubbler:{c:"#e2f2ee",roof:"#2ab0a0",name:"BUBBLER"}};
function cmGeo(o){var hz=o.y===15;return hz?{hz:1,bx:o.x,by:15.0,bw:1,bd:0.12,fx0:o.x,fx1:o.x+0.84,fy:15.86,fw:0.16,fd:0.14,rx:o.x-0.02,ry:14.96,rw:1.04,rd:1.06,cx:o.x+0.5,cy:15.5}
  :{hz:0,bx:25.0,by:o.y,bw:0.12,bd:1,fx0:25.86,fx1:25.86,fy0:o.y,fy1:o.y+0.84,fw:0.14,fd:0.16,rx:24.96,ry:o.y-0.02,rw:1.06,rd:1.04,cx:25.5,cy:o.y+0.5};}
function drawCanalMachBack(sim,o){var g=cmGeo(o),L=CM_LOOK[o.id]||CM_LOOK.canalCleaner,st=mState(sim,o);
  box(g.bx,g.by,g.bw,g.bd,0,0.62,L.c,{top:shade(L.c,0.9)});
  if(o.id==="canalCleaner"||o.id==="bubbler"){/* brushes / bubble bar inside, over the water */var c=P(g.cx,g.cy,0.3),sp=st==="run"?T*8:0;
    for(var k=0;k<5;k++){var a=sp+k*1.2566,dx=Math.cos(a)*9*Z,dy=Math.sin(a)*4*Z;line([c[0],c[1]],[c[0]+(g.hz?dy:dx),c[1]+(g.hz?dx*0.4:dy)],o.id==="bubbler"?"#7fe0d0":"#3a7fb0",2);}}
  if(o.id==="sorter"){var fl=P(g.cx,g.cy,0.28),sw=st==="run"?Math.sin(T*5)*0.5:0;ctx.save();ctx.translate(fl[0],fl[1]);ctx.rotate(sw);ctx.fillStyle="#c07a1a";ctx.fillRect(-8*Z,-1.5*Z,16*Z,3*Z);ctx.restore();}}
function drawCanalMachFront(sim,o){var g=cmGeo(o),L=CM_LOOK[o.id]||CM_LOOK.canalCleaner,st=mState(sim,o);
  if(g.hz){box(g.fx0,g.fy,g.fw,g.fd,0,0.62,L.c);box(g.fx1,g.fy,g.fw,g.fd,0,0.62,L.c);}else{box(g.fx0,g.fy0,g.fw,g.fd,0,0.62,L.c);box(g.fx0,g.fy1,g.fw,g.fd,0,0.62,L.c);}
  box(g.rx,g.ry,g.rw,g.rd,0.62,0.16,L.roof,{top:shade(L.roof,1.15)});
  if(o.id==="dryer"){var fc=P(g.cx,g.cy,0.79),a0=st==="run"?T*12:0;for(var k=0;k<3;k++){var a=a0+k*2.094;ctx.fillStyle="#3a3a3a";ctx.beginPath();ctx.ellipse(fc[0]+Math.cos(a)*5*Z,fc[1]+Math.sin(a)*2.5*Z,4.5*Z,1.8*Z,a,0,6.2832);ctx.fill();}}
  if(o.id==="sorter"){var sg=P(g.cx,g.cy,0.79);txt("\u21a9 POOL",sg[0],sg[1],6,"#3a2208");}
  if(st==="run"&&(o.id==="canalCleaner"||o.id==="bubbler")&&Math.random()<(o.id==="bubbler"?0.45:0.12))part({k:"foam",x:g.cx+(Math.random()-0.5)*0.6,y:g.cy+(Math.random()-0.5)*0.6,h:0.1,vh:0.4+Math.random()*0.4,t:0,life:1.0,r:1.5+Math.random()*2});
  if(st==="run"&&o.id==="dryer"&&Math.random()<0.2)part({k:"foam",x:g.cx,y:g.cy,h:0.85,vh:0.6,t:0,life:0.6,r:2});
  lamp(g.hz?g.rx+g.rw-0.1:g.rx+g.rw,g.hz?g.ry+g.rd:g.ry+g.rd-0.1,0.8,st);
  var lb=P(g.cx,g.cy,0.8);if(o.id!=="sorter"&&o.id!=="dryer"||st==="jam")txt(st==="jam"?"JAMMED!":L.name,lb[0],lb[1],7,st==="jam"?"#ff8a80":"#10283a");else{var l2=P(g.cx,g.cy,0.8);txt(L.name,l2[0],l2[1]+8*Z,6,"#3a2208");}}
function drawCanalMach(sim,o){drawCanalMachBack(sim,o);drawCanalMachFront(sim,o);}
/* ---------- the whole scene ---------- */
function objDepth(o){var f=S.fp(o);return f.x+f.w/2+f.y+f.h/2;}
function render(c,sim,view){
  D.sim=sim;var dpr=view.dpr||1;setView(c,view.w,view.h,view.z,view.cx,view.cy,view.t);D.dpr=dpr;D.editView=!!view.edit;
  var s=sim.s,V=visTiles(),list=[];
  var PF=D.prof?[performance.now()]:null,pm=function(){if(PF){if(D.prof.flush)ctx.getImageData(0,0,1,1);PF.push(performance.now());}};
  bgLayer(sim,V);pm();drawWallAnim();pm();
  s.objs.forEach(function(o){if(o.wall)drawWallItem(sim,o);});pm();
  drawWater(sim,V);pm();
  s.objs.forEach(function(o){var cat=(S.itemDef(o.id)||{}).cat;if(cat==="rug")drawRug(o);});
  if(view.edit||view.showPower)drawPowerRings(sim,view);
  s.objs.forEach(function(o){if(o.id==="belt")drawBelt(sim,o,V);});
  drawPeels(sim,V);pm();
  /* depth-sorted things */
  list.push({d:34.9,f:function(){drawPile(sim);}});
  /* 2.0.2: the old north-wall chute and the two X-RAY boxes are gone (drawChute/scanner kept in the file, not called) */
  list.push({d:13.5+15,f:function(){if(D.dbgHide&&D.dbgHide.shipK)return;if(view.edit)ctx.globalAlpha=0.45;drawShipK(sim);ctx.globalAlpha=1;}});
  list.push({d:15.85+15,f:function(){if(view.edit)ctx.globalAlpha=0.45;drawShipW(sim);ctx.globalAlpha=1;}});
  if(s.equip.broomDustpan&&!s.papa.broomHeld)list.push({d:FIX.broom.x+0.6+0.3,f:function(){drawBroomParked(sim);}});
  lowWalls(sim,list);
  var p=s.papa,pt=p.task;
  list.push({d:FIX.gate.x+FIX.gate.y+1.3,f:function(){drawGate(sim);}});
  s.objs.forEach(function(o){if(o.wall||o.id==="belt")return;var cat=(S.itemDef(o.id)||{}).cat;if(cat==="rug")return;
    if(cat==="canal"){list.push({d:o.x+o.y+0.2,o:o,f:function(){var see=view.edit&&view.sel!==o.u;if(see)ctx.globalAlpha=0.45;drawCanalMachBack(sim,o);ctx.globalAlpha=1;}});
      list.push({d:o.x+o.y+1.9,o:o,nh:1,wx:o.x+0.5,wy:o.y+0.5,wr:1,f:function(){var see=view.edit&&view.sel!==o.u;if(see)ctx.globalAlpha=0.45;drawCanalMachFront(sim,o);ctx.globalAlpha=1;if(view.sel===o.u)selBox(o);}});return;}
    var fp0=S.fp(o);list.push({d:objDepth(o),o:o,wx:fp0?fp0.x+fp0.w/2:o.x+0.5,wy:fp0?fp0.y+fp0.h/2:o.y+0.5,wr:fp0?Math.max(fp0.w,fp0.h):2,f:function(){var see=view.edit&&heightOf(o.id)>0.8&&view.sel!==o.u;if(see)ctx.globalAlpha=0.45;
      switch(o.id){case "table":drawTable(sim,o);break;case "cooler":drawCooler(sim,o,false);break;case "bed":drawBed(sim,o,false);if(pt&&pt.type==="nap"&&pt.lying&&pt.target===o)drawPapaLying(sim,o);break;
      case "basicCot":drawBed(sim,o,true);if(pt&&pt.type==="nap"&&pt.lying&&pt.target===o)drawPapaLying(sim,o);break;
      case "tub":drawTub(sim,o);break;case "hopper":drawHopper(sim,o);break;case "autoPeeler":drawPeeler(sim,o);break;case "washer":drawWasher(sim,o);break;case "generator":drawGenerator(sim,o);break;
      case "tvArmchair":drawFloorDecor(sim,o);if(pt&&pt.type==="watch"&&pt.sit&&pt.target===o)drawPapaSitting(sim,o);break;
      default:drawFloorDecor(sim,o);}
      ctx.globalAlpha=1;if(view.sel===o.u)selBox(o);}});});
  list.push({d:S.HEAP.x+S.HEAP.y,wx:S.HEAP.x,wy:S.HEAP.y,wr:2,f:function(){drawHeap(sim);}});
  s.pots.forEach(function(q){if(q.m==="belt"||q.m==="canal"||q.m==="scan")list.push({d:(q.m==="scan"&&q.t>=0.75)?32.3:(q.m==="scan"?28.0:q.x+q.y+0.05),nh:1,wx:q.x,wy:q.y,f:function(){
    if(q.m==="scan"){if(q.t<0.18){potato(12.9+q.t*0.6,15,0.6-q.t,q,0);}else if(q.t>=0.75){var ff=Math.min(1,(q.t-0.75)/0.45);var sx0=16.75,sx1=17.45,hx=ff<0.55?sx0+(sx1-sx0)*(ff/0.55):sx1+0.2*((ff-0.55)/0.45),hh=ff<0.55?0.86-(0.86-0.5)*(ff/0.55):0.5-(0.5-WL-0.02)*Math.pow((ff-0.55)/0.45,2);potato(hx,14.95,hh,q,ff*4);}return;}
    var h=q.m==="belt"?0.2:WL+0.03+Math.sin(T*3+q.u)*(sim.s.flowOff?0.006:0.015),sk=q.m==="canal"?Math.max(0,Math.min(1,(q.c-(S.SHIP_C-0.45))/0.45)):0;
    if(sk>0){h-=sk*0.3;ctx.globalAlpha=1-sk*0.7;potato(q.x,q.y,h,q,Math.sin(T+q.u)*0.4+sk*2,1-sk*0.35);ctx.globalAlpha=1;return;}
    if(q.m!=="belt"){ell(q.x,q.y,WL+0.01,7,3,"rgba(255,255,255,0.25)");}potato(q.x,q.y,h,q,q.m==="belt"?0:Math.sin(T+q.u)*0.4);}});});
  /* 2.0.2 (Jay t1240/t1242): no see-through ghost at the wall SHIPPING machine */
  var atShip=p.x>=10.8&&p.x<=14&&p.y>=13.2&&p.y<=17;
  list.push({d:p.x+p.y+0.01,f:function(){if(D.dbgHide&&D.dbgHide.papa)return;drawPapa(sim);if(!(D.dbgHide&&D.dbgHide.toss))drawToss(sim);}});   /* t1242: plain depth; his drop spot is on the floor in front of the machine */
  if(s.equip.carrySack&&!p.sack.on)list.push({d:p.sack.x+p.sack.y,f:function(){drawSackFloor(sim);}});
  if(sim.placed("catBed"))list.push({d:s.cat.x+s.cat.y+0.02,f:function(){drawCat(sim);}});
  if(sim.placed("catBed")&&s.acc&&s.acc.toy){var cb=S.fp(sim.objsOf("catBed")[0]),yx=cb.x+1.25+Math.sin(T*0.7)*0.35,yy=cb.y+0.55+Math.cos(T*0.5)*0.25;
    if(s.cat.st!=="nap"&&Math.hypot(s.cat.x-yx,s.cat.y-yy)<1.2){yx+=Math.sin(T*6)*0.08;}
    list.push({d:yx+yy,nh:1,wx:yx,wy:yy,f:function(){var a=P(yx,yy,0.07),r=4.2*Z;shadow(yx,yy,0.12,0.25);ctx.save();ctx.translate(a[0],a[1]);ctx.rotate(T*1.5);ctx.beginPath();ctx.arc(0,0,r,0,6.283);ctx.fillStyle="#d8507a";ctx.fill();ctx.strokeStyle="#8e2a4c";ctx.lineWidth=Math.max(0.6,0.8*Z);ctx.stroke();
      ctx.strokeStyle="rgba(255,200,220,0.8)";ctx.beginPath();ctx.arc(0,0,r*0.6,0.3,2.6);ctx.moveTo(-r*0.8,-r*0.2);ctx.quadraticCurveTo(0,r*0.3,r*0.8,-r*0.3);ctx.stroke();ctx.restore();
      var tl=P(yx+0.25,yy+0.2,0.01);ctx.strokeStyle="#d8507a";ctx.lineWidth=Math.max(0.6,0.8*Z);ctx.beginPath();ctx.moveTo(a[0]+r*0.6,a[1]+r*0.5);ctx.quadraticCurveTo(tl[0],a[1]+r,tl[0]+6*Z,tl[1]);ctx.stroke();}});}
  list.sort(function(a,b){return a.d-b.d;});
  pm();var cm=60*Z+40;list=list.filter(function(e){if(e.wx==null)return true;var r=(e.wr||1)*36*Z+cm,X=sx(e.wx,e.wy),Y=sy(e.wx,e.wy,0);return X>-r&&X<CW+r&&Y>-r-150*Z&&Y<CH+r;});
  if(PF&&D.prof.each){for(var i=0;i<list.length;i++){var t0=performance.now();list[i].f();if(D.prof.flush)ctx.getImageData(0,0,1,1);var k=list[i].o?list[i].o.id:(list[i].f.toString().slice(12,40));D.prof.each[k]=(D.prof.each[k]||0)+performance.now()-t0;}}else for(var i=0;i<list.length;i++)list[i].f();pm();
  drawBasin(sim);
  /* see-through Papa: when a huge machine hides him you still see where he is */
  var pd=p.x+p.y,psx=sx(p.x,p.y),psy=sy(p.x,p.y,0),hid=list.some(function(e){if(e.d<=pd+0.01||e.wx==null||e.nh)return false;
    var hh=e.o?heightOf(e.o.id):1.3;if(hh<0.5)return false;var X=sx(e.wx,e.wy),Y=sy(e.wx,e.wy,0),r=(e.wr||1)*40*Z+30*Z;return Math.abs(X-psx)<r&&psy<Y+20*Z&&psy>Y-(hh*ZP+60)*Z;});
  if(atShip)hid=false;
  if(D.dbgHide&&D.dbgHide.papa)hid=false;D.lastHid=!!hid;var pt2=p.task;if(hid&&!(pt2&&pt2.stage==="act"&&((pt2.type==="nap"&&pt2.lying)||(pt2.type==="watch"&&pt2.sit)))){NOPART=true;ctx.globalAlpha=0.3;drawPapa(sim);ctx.globalAlpha=1;NOPART=false;}
  drawParts();
  if(view.edit)drawEditOverlay(sim,view);
  if(view.marks)view.marks.forEach(function(m){var a=P(m.x,m.y,m.h||0);ctx.strokeStyle=m.c||"#fff";ctx.lineWidth=2;ctx.beginPath();ctx.arc(a[0],a[1],m.r||10,0,6.28);ctx.stroke();});
  pm();if(PF){var a=D.prof.acc||(D.prof.acc=[]);for(var j=1;j<PF.length;j++)a[j-1]=(a[j-1]||0)+PF[j]-PF[j-1];D.prof.n=(D.prof.n||0)+1;}
}
function selBox(o){var f=S.fp(o);ctx.setLineDash([4,3]);poly([P(f.x,f.y,0.02),P(f.x+f.w,f.y,0.02),P(f.x+f.w,f.y+f.h,0.02),P(f.x,f.y+f.h,0.02)],null,"#ffe27a",2);ctx.setLineDash([]);}
function drawPowerRings(sim,view){if(!sim.power)sim.calcPower();sim.power.src.forEach(function(s){isoCirc(s.x,s.y,0.02,s.range,"rgba(80,170,255,0.07)","rgba(110,190,255,0.55)",1.5);var a=P(s.x,s.y,0.05);txt((s.id==="outlet"?"OUTLET ":"GEN ")+s.used+"/"+s.cap,a[0],a[1]+10*Z,8,"#9fd0ff");});}
function drawEditOverlay(sim,view){var s=sim.s;
  /* arrows on every machine so the flow is clear */
  s.objs.forEach(function(o){if((S.isMach(o.id)&&!S.isCanalM(o.id))||o.id==="tub"){var f=sim.frontOut(o);arrowFloor(f[0],f[1],o.r,"rgba(120,255,160,0.95)");}});
  var g=view.ghost;if(!g)return;var it=S.itemDef(g.id);if(!it)return;
  if(it.cat==="wall"){var w=sim.wallSpot(g.id,g.x+0.5,g.y+0.5);if(w){var n=it.w||1,u=w.wall==="N"?w.x:w.y;wallQuad(w.wall,u,u+n,0.9,2.2,g.ok?"rgba(120,255,160,0.35)":"rgba(255,90,80,0.4)","#fff");}return;}
  var f=S.fp({id:g.id,x:g.x,y:g.y,r:g.r});poly([P(f.x,f.y,0.03),P(f.x+f.w,f.y,0.03),P(f.x+f.w,f.y+f.h,0.03),P(f.x,f.y+f.h,0.03)],g.ok?"rgba(120,255,160,0.35)":"rgba(255,90,80,0.4)",g.ok?"#7dff9a":"#ff6b5e",2);
  if(g.id==="belt"||(S.isMach(g.id)&&!S.isCanalM(g.id))){var fo=g.id==="belt"?[g.x+S.DIRS[g.r][0],g.y+S.DIRS[g.r][1]]:sim.frontOut({id:g.id,x:g.x,y:g.y,r:g.r});if(g.id==="belt")arrowFloor(g.x,g.y,g.r,"#ffe27a");else arrowFloor(fo[0],fo[1],g.r,"#ffe27a");}
  if(g.id==="generator"){isoCirc(f.x+1,f.y+1,0.02,7+1.5*sim.up("gen"),null,"rgba(110,190,255,0.8)",1.5);}
  ctx.globalAlpha=0.55;var tmp={u:-1,id:g.id,x:g.x,y:g.y,r:g.r,on:1,q:[],tray:[],pw:1,t:0};try{if(g.id==="belt")drawBelt(sim,tmp,null);else if(S.isCanalM(g.id)){if(S.isCanal(g.x,g.y))drawCanalMach(sim,tmp);}else if(S.isMach(g.id)||g.id==="generator"){({hopper:drawHopper,autoPeeler:drawPeeler,washer:drawWasher,generator:drawGenerator})[g.id](sim,tmp);}else if(it.cat==="rug")drawRug(tmp);else if(g.id==="table")drawTable(sim,tmp);else if(g.id==="bed")drawBed(sim,tmp,false);else if(g.id==="tub")drawTub(sim,tmp);else if(g.id==="cooler")drawCooler(sim,tmp,false);else drawFloorDecor(sim,tmp);}catch(e){}ctx.globalAlpha=1;}
/* screen bounding boxes for picking */
function heightOf(id){return {canalCleaner:0.8,sorter:0.8,dryer:0.8,bubbler:0.8,hopper:2.5,autoPeeler:2.2,washer:1.9,generator:1.4,table:1.0,cooler:1.1,bed:1.0,tub:0.9,belt:0.25,lamp:1.7,bookshelf:1.9,fan:1.3,tvArmchair:1.4,shelf:1.5,plant:1.0,statue:1.5,basicCot:0.5}[id]||0.9;}
function pick(sim,px,py){var best=null,bd=-1e9;sim.s.objs.forEach(function(o){var it=S.itemDef(o.id);if(!it)return;
  if(o.wall){var n=it.w||1,u=o.wall==="N"?o.x:o.y,a=wallPt(o.wall,u,0.9),b=wallPt(o.wall,u+n,2.2),x0=Math.min(a[0],b[0]),x1=Math.max(a[0],b[0]),y0=Math.min(a[1],b[1]),y1=Math.max(a[1],b[1]);if(px>=x0-4&&px<=x1+4&&py>=y0-4&&py<=y1+4){var d=-5+(o.wall==="N"?o.x:o.y)*0.01;if(d>bd){bd=d;best=o;}}return;}
  var f=S.fp(o),h=it.cat==="rug"?0.02:heightOf(o.id),pts=[P(f.x,f.y,0),P(f.x+f.w,f.y,0),P(f.x+f.w,f.y+f.h,0),P(f.x,f.y+f.h,0),P(f.x,f.y,h),P(f.x+f.w,f.y,h),P(f.x+f.w,f.y+f.h,h),P(f.x,f.y+f.h,h)];
  var x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;pts.forEach(function(q){x0=Math.min(x0,q[0]);x1=Math.max(x1,q[0]);y0=Math.min(y0,q[1]);y1=Math.max(y1,q[1]);});
  if(px>=x0&&px<=x1&&py>=y0&&py<=y1){/* inside the hexagon outline? */var w=toWorld(px,py);var inFoot=w.x>=f.x-0.1&&w.x<=f.x+f.w+0.1&&w.y>=f.y-0.1&&w.y<=f.y+f.h+0.1;var d=objDepth(o)+(inFoot?50:0)-(it.cat==="rug"?100:0);if(d>bd){bd=d;best=o;}}});
  return best;}
D.render=render;D.pick=pick;D.toWorld=function(px,py){return toWorld(px,py);};D.project=function(x,y,h){return P(x,y,h);};D.heightOf=heightOf;D.setView=setView;
return D;
})();
