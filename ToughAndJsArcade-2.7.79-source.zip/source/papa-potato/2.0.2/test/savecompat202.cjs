// shared save key papaPotato2.save.v1: 2.0.1 save -> 2.0.2 load (migration), and 2.0.2 save -> 2.0.1 load (no crash, progress kept)
const L=require("./lib.cjs");const fs=require("fs");
const V201="file:///workspace/game/build-potato2/v2/release/papa-potato-2.0.1.html",V202=process.env.PP_HTML||"file:///workspace/game/build-potato2/v2/release/papa-potato-2.0.2.html";
(async()=>{const b=await L.browser();const out=[];let ok=true;
 let {p,errs}=await L.open(b,[360,800],{url:V201});
 const before=await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=777;s.buyItem("roomKey");s.buyItem("fan");s.place("fan",3,6,0);s.buyItem("sunglasses");s.setBox("deliver",1);for(var i=0;i<1200;i++)s.step(1/60);PP2T.save();return {coins:s.s.coins,pile:s.s.pile,deliver:s.s.box.deliver,objs:s.s.objs.map(o=>o.id).sort().join(","),ver:s.s.ver};});
 const e1=errs.slice();await p.close();
 ({p,errs}=await L.open(b,[360,800],{url:V202,clear:false}));
 const r1=await p.evaluate(()=>{var s=PP2T.sim().s;return {coins:s.coins,key:!!s.owned.roomKey,pile:s.pile,deliver:s.box.deliver,objs:s.objs.map(o=>o.id).sort().join(","),glasses:s.acc.glasses,title:document.title};});
 const a=r1.coins>=before.coins&&r1.key&&r1.pile>=800&&r1.deliver===0&&r1.objs===before.objs&&r1.glasses===1&&errs.length===0;if(!a)ok=false;
 out.push({step:"2.0.1 save -> 2.0.2 load",pass:a,before,after:r1,errs:errs.slice()});
 await p.evaluate(()=>{var s=PP2T.sim();s.s.coins+=50;s.s.owned.radio=1;s.gainStation("stDisco");for(var i=0;i<600;i++)s.step(1/60);PP2T.save();});
 const mid=await p.evaluate(()=>{var s=PP2T.sim().s;return {coins:s.coins,radioSt:s.decor.radioSt,pile:s.pile};});await L.sleep(300);await p.close();
 ({p,errs}=await L.open(b,[360,800],{url:V201,clear:false}));
 const r2=await p.evaluate(()=>{var s=PP2T.sim();for(var i=0;i<600;i++)s.step(1/60);return {coins:s.s.coins,key:!!s.s.owned.roomKey,radioSt:s.s.decor.radioSt,pile:s.s.pile,objs:s.s.objs.map(o=>o.id).sort().join(","),title:document.title};});
 await L.sleep(500);const b2=r2.key&&r2.coins>=mid.coins-5&&errs.length===0;if(!b2)ok=false;
 out.push({step:"2.0.2 save -> 2.0.1 load (older build)",pass:b2,saved:mid,after:r2,errs:errs.slice(),note:"2.0.1 does not know DISCO SPUD; it falls back to its own station list"});
 console.log(JSON.stringify(out,null,1));console.log(ok?"SAVECOMPAT PASS":"SAVECOMPAT FAIL");fs.writeFileSync(__dirname+"/savecompat202-results.json",JSON.stringify({ok,out},null,1));await b.close();})();
