#!/bin/bash
# 2.0.2 "Hard test 1x" evidence run on release/papa-potato-2.0.2.html (staging only, NOT shipped)
cd /workspace/game/build-potato2/v2/test
export PP_HTML=file:///workspace/game/build-potato2/v2/release/papa-potato-2.0.2.html
ST=/workspace/game/requests/finished-ship/papa-potato-2.0.2-test
EV=$ST/test-evidence; SH=$ST/screenshots; mkdir -p $EV $SH
echo "start $(date)"
HARD_OUT=$EV/hard-results.json timeout 2400 node hard.cjs > $EV/hard.log 2>&1; echo "hard done $(tail -1 $EV/hard.log | cut -c1-200)"
timeout 600 node play.cjs > $EV/play.log 2>&1; cp play-results.json $EV/ 2>/dev/null; echo "play done $(tail -1 $EV/play.log | cut -c1-200)"
timeout 300 node savecompat202.cjs > $EV/savecompat.log 2>&1; cp savecompat202-results.json $EV/; echo "savecompat $(tail -1 $EV/savecompat.log)"
timeout 900 node perf.cjs > $EV/perf.log 2>&1; cp perf-results.json $EV/perf-results-2.0.2.json; echo "perf 2.0.2 done"
PP_HTML=file:///workspace/game/build-potato2/v2/release/papa-potato-2.0.1.html timeout 900 node perf.cjs > $EV/perf-2.0.1-baseline.log 2>&1; cp perf-results.json $EV/perf-results-2.0.1-baseline.json; echo "perf 2.0.1 baseline done"
SHOTS=$SH timeout 900 node stage202.cjs > $EV/stage-shots.log 2>&1; echo "stage shots done $(tail -1 $EV/stage-shots.log)"
SHOTS=$SH/robot timeout 600 node posesheet.cjs > $EV/posesheet.log 2>&1; echo "poses done"
SHOTS=$SH/pile-pool timeout 600 node look-pile.cjs > $EV/look-pile.log 2>&1; echo "pile done"
cd .. && timeout 1500 node /workspace/game/tough-tools/tt.js test release/papa-potato-2.0.2.html --all > $EV/tt.log 2>&1; echo "tt done $(grep '^TEST' $EV/tt.log)"
rm -rf $EV/tt && cp -r /workspace/game/tough-tools/out/papa-potato-2.0.2 $EV/tt 2>/dev/null
echo "end $(date)"
