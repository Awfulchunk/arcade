# Papa Potato 2.0.2 (TEST BUILD, NOT SHIPPED)

Built from 2.0.1 (build-potato2/v2). The Papa locks are kept: robot Papa, Project Zomboid-style iso view, one continuous map, grid belts. Cuts and frame-rate settings are unchanged.

## What changed

1. **Shipping: one machine in the wall, with two sides.**
   - Both X-RAY boxes are gone, and so is the old SHIP chute on the north wall. Their drawing code is still in the file, just never called.
   - In their place is one SHIPPING machine built into the dividing wall at tiles (13–15, 14–15).
   - Kitchen side: Papa drops each peeled potato into the hopper on top.
   - Wash side: a spout spits the potato into the pool, where potatoes pile up and wait.
   - When the pool reaches EMPTY POOL AT (default 6), Papa walks into the wash room, scoops the pile, scrubs, and puts it in the canal. Then he goes back to peeling.
   - SEND PEELED TO now offers POOL (default), SHIP DIRTY, or CARRY.
   - My call: until you have the ROOM KEY the wash room is locked, so the machine ships each potato right away and pays by dirt. That keeps the early coins coming. SHIP DIRTY does the same after the key.
   - The machine only moves while a potato passes through (flaps, white light flash, splash). The rest of the time it is still.
2. **No pre-placed machines.**
   - A fresh game starts with only the table, cooler, bed and scrub tub. The X-RAY/SHIP fixtures that looked like machines are removed.
   - A save from 2.0.1 migrates the same way: pile 80 → 852, SHIP DIRTY → POOL, coins and items kept.
   - Anything the player owned that now sits on the new pile spot moves to INV. Nothing is deleted.
3. **Pile: a copy of the 0.4.11 pile.**
   - Same spot: along the bottom kitchen wall, full width.
   - Same size: 852 potatoes, the full 0.4.11 mound.
   - Same layout and look: tiers of 100·sc², R2 spread and jitter, 1.1 lift per tier, sprite sizes 2.9/3.3/3.7, light ramp by tier, a soft shadow under the bottom tier, the wooden bay, and the ribbed return chute with green arrows (moved to the left/west end in t1240, see below).
   - Potatoes still roll back out of that chute. The 0.4.11 numbers are mapped onto the iso floor (one scale for both axes).
   - The pile and its bay are cached as one image, so each frame is a single draw.
   - Tapping the pile shows its count. The "RAW PILE" floor label is hidden because 0.4.11 had none.
4. **Calendar.** It stays still and flips one page once (0.9 s), only when the in-game day changes.
5. **Radio-station want.**
   - New station: DISCO SPUD (116 bpm, four-on-the-floor), made live by the game.
   - When Papa owns a radio, he usually wants the new station (60%), then peels until he can pay 12c, buys it, and tunes in.
   - In the RADIO menu it shows as LOCKED with a hint until he earns it. It is not sold in the shop.
   - It works in AUTO MODE too.
6. **Short trips no longer pay 0.**
   - On any trip of 1 minute or more, Papa does at least 15% steady work, at effort 0.6.
   - The pay floor is 1 coin when the trip could pay one.
   - The timeline says "Did a bit of steady work between breaks".
   - Measured efficiency stays far under the 50% ceiling (worst case at 1 min: 14.7%).
7. **Broom.** It hangs on the kitchen's north wall by the door (x 13). Papa fetches it to sweep, carries it while sweeping, and hangs it back up after. He never holds it while peeling, eating or napping.


## Fixes from Jay's notes (t1240)

1. **Papa is never ghosted behind the wall SHIPPING machine.** Near the machine he is drawn in front of it, and the see-through ghost is off there. He also prefers to stand in front of it (south side) when that spot is free. Hard test "202:Papa is drawn in front…" compares Papa's visible pixels at the machine with open floor: drop spots 102–106%, walking past 89–92%. The old build scored 87/88% and fails this test.
2. **The return chute is on the other side of the pile.** It now comes out of the west wall at the left end of the heap, with its mouth facing east toward the potatoes. Returning potatoes fly out of the new mouth. The old east-wall chute code is kept but hidden (drawReturnChuteEast).
3. **Pay: 2c at the drop, then about 4c after the wash.** With the ROOM KEY and POOL, each potato pays 2c the moment Papa drops it into the machine, with a yellow "+2c" popup at the machine. When he finishes it in the wash room (scrub, canal, ship hole) it pays the rest: clean +4c, shown as a green "+4c" popup at the hole, for 6c in all (it was 5c). A dirty one pays +1c. Saves remember which pool potatoes already paid, so nothing is paid twice. Old 2.0.1 pool potatoes were never pre-paid, so they still pay full value. With no key or SHIP DIRTY, pay is unchanged: one payment by dirt. AUTO MODE uses 6c/4c for the POOL route.
4. **Warmer pile.** Potato colours moved toward 0.4.11's orange-gold (less brown) with a flatter light ramp. The old palette is kept behind D.pileWarm=false. The chute is now a round ribbed steel pipe with a round flange and a flared round mouth, no longer a box.

## Fixes from Jay's notes (t1242)
- **Papa stands on the floor, not on the box.** The SHIPPING machine has ONE drop spot: the open kitchen floor right in front of it (tile 13,16). The machine tiles can't be walked on. Papa is drawn with normal depth, so his feet are on the floor in front of the box. That spot stays clear: you can't put furniture there (rugs and belts are OK). If an old save had something there, it goes to the inventory.
- **The canal has a real end.** The last tile is a **SHIP DRAIN**: a dark grate with a yellow/black frame, water pouring in, and a green "SHIP ▼" sign on the wall. Potatoes sink into it and are sold there (clean 5c, dirty less). The canal no longer runs into the wall.
- **FLOW ON/OFF.** A tap with a red hand wheel sits on the canal (tile 24,15). Tap it, or the new **FLOW** button in the menu (6th button). OFF: the plate drops, potatoes stop and line up behind it (the canal backs up), and once it's full Papa puts potatoes back in the pool. ON: they float on to the drain and are sold. It's saved.
- **New canal machines (shop → MACHINES, level 3, you place them yourself over a canal tile, none come pre-placed):**
  - **AUTO CLEANER** (120c, power 2): potatoes go through slowly (about 3x slower) and come out the other side, still in the canal, cleaned. Papa doesn't scrub while it works, so he's free. It pays 1c less than Papa's hand scrub (4c instead of 5c at the drain).
  - **SORTER** (90c, power 1): bad or dirty potatoes go back to the pool ("DIRTY ↩ POOL"); good clean ones go on.
  - Both need power (outlet or generator close by). With no power they let potatoes pass untouched. They can **JAM**: a jammed one blocks the canal until Papa fixes it (FIX JAMS).
  - Not allowed on: the drain, the flow tap, the corner, or a tile that already has a canal machine.
- **CUSTOM GAME (HELP → CUSTOM GAME):** the ideas that weren't picked are here, OFF by default (Jay's rule: unpicked → Custom Game):
  - **DRYER** (110c, power 2): +1c for every potato that comes out dry.
  - **BUBBLER** (150c, power 4): cleans as well as the auto cleaner but at full speed. Uses lots of power.
  - When OFF they're hidden from the shop and can't be bought or placed.
- Away mode: a working auto cleaner/bubbler counts as the "clean" route; FLOW OFF counts as the slow pool route.

## Fixes from Jay's notes (t1244)
- **Papa really stands in front of the box now.** His drop spot moved out to tile 13,18: two clear floor tiles in front of the SHIPPING machine (13,16 and 13,17 are kept clear, no furniture). He faces the box and **tosses** each potato in an arc into the intake (arm up, potato flies, lands in the slot). The whole box and its SHIPPING sign stay visible while he's there. A hard test checks that his screen box never touches the machine's screen box at every zoom (0.38 to 1.7).
- **FLOW label is easy to read.** On the map tap: white bold "FLOW ON / FLOW OFF" on a dark plate with a green or red dot and a matching border. The menu button is the same: white bold text on black, with a green (ON) or red (OFF) dot and border.

## Animation audit (every animation and what starts it)

| Item / thing | Class | Moves when |
|---|---|---|
| Clock | always | hands tick |
| Window | always | clouds drift outside; the curtains move only when a fan is placed |
| String lights | always | bulbs chase |
| Neon sign | always | flicker |
| Aquarium | always | fish swim |
| Fan | always | blades spin |
| Generator | always | engine runs (flywheel, smoke) |
| Pool / canal water, duck, toy boat, bubbles | always | water flow |
| Papa (hover bob), cat walking | always | they are characters |
| Lamp | state | lamp ON: glow and moth (the pull chain is still) |
| Radio | state | playing: antenna, dial needle, notes |
| TV + armchair | state | TV ON (off: still reflection, steady standby light) |
| Small cooler / cooler | state | stocked with food: cold mist (the LED is steady: green stocked, red empty) |
| Belts | state | powered |
| Hopper, auto peeler, washer | state | machine running. The status lamp blinks only as a warning (NO POWER / JAM) |
| Scrub tub | state | bubbles only with potatoes in it or while he scrubs |
| Calendar | trigger | in-game day changes: one page flip |
| Spice rack | trigger | Papa eating |
| Coat hook, pots & pans, towel rack, mop bucket | trigger | Papa walks past (eases in, settles back) |
| Poster corner, plant | trigger | a fan is placed (breeze) |
| Compost lid (and whiff) | trigger | Papa sweeping |
| Cookbook pages | trigger | Papa peeling |
| Soap drips | trigger | Papa scrubbing at the tub |
| Cat bed cushion / yarn | trigger | cat napping / cat walking near the bed |
| Sink drip (item and table sink) | trigger | about 4 s after it was used |
| Basic cot | trigger | Papa napping on it |
| SHIPPING machine flaps, light, pool splash | trigger | a potato passing through |
| Return chute light | trigger | potatoes rolling back to the pile |
| Photos, bookshelf, trophy shelf, statue glow, shelf tag, sack pile, fruit bowl (and its fly, hidden), rugs, sheen bands, cot tag, outlet LED, door lock light, SACK label | still | never |

Every placeable item is in exactly one class, and the hard test checks each one by pixels:
- always: it animates.
- state: still when off, animates when on.
- trigger: still with no trigger, animates on its trigger.
- still: never changes.

## Hidden, not deleted
- The old north-wall chute.
- The X-RAY scanner drawing.
- The 2.0.1 pile code (renamed with a 201 suffix).
- The pile label and the broom label.
- The fruit-bowl fly.
- `src-2.0.1-backup/` keeps the 2.0.1 source.
