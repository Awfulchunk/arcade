# Papa Potato 2.0.0 — progress (resume file)
Brief: full rework of 0.4.11 -> 2.0.0, test (items 2x, mechanics 2x, full touch game 2x, tough-tools, A03s perf 6x/4x),
stage in /workspace/game/requests/finished-ship/papa-potato-2-test/, then ship Arcade 2.7.77 (Papa 2.0.0 + Pixel War 0.5.0, keep 0.4.11/0.4.15 slots),
versionCode 115, same signer, apksigner v1/v2/v3, publish to Awfulchunk/arcade Pages. Never print keys; Latch REPLACE-WITH-UNLOCK-CODE; do NOT touch PR 2.

## Layout
- src/: sim.js, draw.js, radio.js (copied from 0.4.11), head.html, ui/game.js. build.sh -> release/papa-potato-2.0.0.html (NOT "out/": box wipes out/).
- test/: lib.cjs (puppeteer), scenes.js, hardtests.js (49 items x2), hardmech.js (28 mechanics x2), hard.cjs runner, play.cjs (full touch game x2), shots.cjs (screens).

## Status (2026-11-25 21:05 PT)
- [x] sim.js, draw.js, head.html, game.js, build.sh — builds, no page errors
- [x] items 2x: 98/98 pass (looped animation pixel check, place/move/turn/store, effects, reachability)
- [x] mechanics 2x: 56/56 pass
- [x] play.cjs: 64/66 — "FIX by touch" failing, debugging
- [x] tough-tools tt.js --all
- [x] perf A03s 360x800@2, 6x + 4x throttle
- [x] FEATURES-2.md + staging
- [x] ship 2.7.77

- 21:06 play.cjs 66/66 PASS (seeds 31,62). Next: tough-tools --all, perf, hard rerun, shots, stage, ship.
- 21:27 tt.js visual fixed (paged command boxes, 44px sliders, HUD narrow). Perf: bg layer cache, culling, batched box outlines/peels, adaptive render scale (2x->1x steps). 6x ~57-60fps adaptive. Running test/all.sh (hard, play, perf, shots, tt --all) -> staging test-evidence.
- 21:43 adaptive scale resets on resize (tt buff resize-rotate fixed). Final html 80791950... Rerunning test/all.sh. Ship prep done in /workspace/game/build-ship2777 (assemble/verify/headless scripts, package-2.7.77 manifest 115/2.7.77, src-work). Next: stage html, assemble, build APK, verify, source zip, publish.
- 21:54 RESUME: site clean, origin/main 83299e6 (no partial push). all.sh: hard 154/0, play 66/0, perf, shots ok; tt --all running. Staged html 80791950 + FEATURES-2.md.
- 22:01 all.sh FINAL on 80791950: hard 154/0, play 66/0, perf ok, 13 shots, tt --all 66 pass 0 fail 5 warn. Next: assemble 2.7.77.
- 22:04 perf rerun clean; staging SHA256SUMS written; assembled release/index.html.
- 22:06 APK built (release/ToughAndJsArcade-2.7.77.apk), headless ALL OK, verify run.
- 22:06 source zip built (no keys, pw absent, Latch placeholder present).
- 22:06 site commit made locally (not pushed yet).
- 22:07 PUSHED 83299e6..8821f18. Waiting on Pages deploy, then live SHA check.
- 22:13 DONE. Live verified (APK 6441a8b2, commit 8821f18). Deliverables in finished-ship/arcade-2.7.77-papa2-pixelwar05/ with SHIPPED.txt.

## 2.0.1 (Jay t1224-t1226): remove puke completely; Papa = older human chef dad (beard, apron, rolled sleeves), all anims redone. Test 1x + tt + perf, stage finished-ship/papa-potato-2.0.1-test/. DO NOT SHIP.
- 23:01 backup src-2.0.0-backup. Step 1: puke removal.
- 23:05 puke removed from sim.js/game.js/draw.js text+logic (mopBucket now sweeps 25% faster, hunger caps at 100). Step 2: human Papa redraw in draw.js.
- 2.0.1 ADD (Jay t1227): (a) restore the 0.4.11 potato PILE look (kitchen pile + basin heap art/behavior) adapted to iso; (b) kitchen X-ray drop machine, wash-side X-ray right next to the pool so potatoes drop into the pool (as 0.4.9/0.4.11); (c) start with NO machines placed (no pre-placed peeler/washer/generator/belts); (d) peeled potatoes in the pool gather and STAY until Papa goes to the wash room and continues (scrub, canal, ship). Don't change anything else vs 0.4.11. Add hard tests + shots: pile, drop into pool, waiting in pool, empty start room.
- 23:06 puke fully gone from src (grep 0 in sim/game/head; draw.js Papa block still has 2, replaced by the human rewrite).
- 23:08 human Papa written (work/papa-human.js spliced into draw.js), version 2.0.1. Next: screenshot check of Papa.
- 2.0.1 ADD (Jay t1229): pool basin, water surface and canal must align exactly with the iso floor tiles/walls (no overhang/offset) + proof screenshot. Character choice 'still pending' per parent: keeping human Papa (t1226) but potato code preserved in src-2.0.0-backup.
- 23:10 first look at human Papa poses OK (test/look201.cjs -> /tmp/look201). Fixing details next, then pool alignment, pile, X-ray/pool drop, empty start, pool hold.
- 23:10 CHARACTER DECIDED (Jay): Papa = ROBOT. Round retro robot, SCREEN FACE with expressions (happy, tired, hungry, focused, sleeping Zzz, mood-linked), single wheel/hover base + subtle bob, APRON + CHEF HAT, warm cream + orange, clean iso shading. Redo all anims (roll, carry, peel w/ knife in hand, scrub, sweep w/ broom+dustpan in hands, fix jam, eat/recharge, nap w/ sleep face). Drop human. Shots: 2x close-up + expressions sheet. Human version kept in work/papa-human.js (not used).
- 2.0.1 ADD (Jay t1230): AUTO MODE offline progress on resume. Elapsed real time, unlimited, ~50% live efficiency, jams/eat/sleep still happen, chunked fast-forward with caps (weeks < ~1 s on A03s), backward clock = 0, pool potatoes process if the setup allows. WHILE-YOU-WERE-GONE report (time away, coins, peeled, cleaned, shipped, naps, meals, jams). Tests: fake 1m, 1h, 8h, 3d, 30d, backward; screenshot the report.
TODO ORDER: (1) robot Papa (2) pool/canal align (3) 0.4.11 pile look (4) X-ray->pool drop verify (5) empty start, no machines (6) pool hold until Papa (7) auto/offline mode (8) tests+shots (9) stage 2.0.1-test (NO SHIP)
- 2.0.1 ADD (Jay t1231): offline = Papa mostly KICKS IT (relax, nap, eat, wander, sit, radio, pet cat if placed), only SOMETIMES works (mood/energy/hunger + randomness, bursty). 50% = CEILING. Running machines still run/jam. Report = timeline/summary ('Napped 3h, listened to radio, peeled 40, machine jammed at 2am'). Test variance across seeds.
- 2.0.1 ADD (Jay t1232): Papa WANTS (food when hungry, accessories/decor e.g. new hat, sunglasses, radio station, snack, cat toy). Want builds -> he works until he can afford it -> buys with offline coins -> kicks it. Report lists wanted/bought ('Wanted a snack, peeled 30, bought a snack, then napped'). Live 'Papa wants' bubble/readout. Add cheap cosmetic accessories (hats, glasses, bow tie).
- robot Papa body done (src/draw.js; backup work/papa-robot.bak/js), pose sheet test/posesheet.cjs, accessories hat chef|beanie|top|party, glasses, bow via s.acc; expr wow via p.wantFlash. NEXT: sim (acc state, wants, empty start, pool hold, pile 0.4.11, pool align, auto mode)
- 23:37 DONE in src: pool/canal recessed + flush coping (aligned to tiles), 0.4.11 pile (finite 80 + return pipe) + basin heap, X-ray pours into pool (falling potato drawn), empty start, pool potatoes WAIT (EMPTY POOL AT box; once he goes he empties it), wants (live bubble + GET IT; auto self-buys), cosmetic acc (party hat, beanie, bow tie, sunglasses, top hat, cat toy), src/away.js auto mode (EFF 0.5 ceiling, mach<=full clamp, pool stock excluded from eff), WYWG sheet. Tests: scen2/shots/play puke refs removed; hard.cjs 1 seed (SEEDS env); test/stage201.cjs staging shots; all.sh -> 2.0.1 staging. Puke grep src+release = 0. Running all.sh evidence. NOT SHIPPED.
