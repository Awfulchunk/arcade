// quick visual check of human Papa poses (close-ups)
const L=require("./lib.cjs");const fs=require("fs");const OUT=process.env.SHOTS||"/tmp/look201";fs.mkdirSync(OUT,{recursive:true});
async function until(p,cond,max){for(let i=0;i<max;i++){if(await p.evaluate(cond))return i;await p.evaluate(()=>__tt.step(5));}return -1;}
async function snap(p,name,z){await p.evaluate(z=>{var q=PP2T.sim().s.papa;PP2T.setCam(q.x,q.y,z);document.getElementById("toast").className="off";},z||1.6);await L.sleep(150);
  const r=await p.evaluate(()=>{var q=PP2T.sim().s.papa;var a=PP2T.project(q.x,q.y,0);var c=document.getElementById("cv").getBoundingClientRect();return [a[0]+c.left,a[1]+c.top];});
  await p.screenshot({path:OUT+"/"+name+".png",clip:{x:Math.max(0,r[0]-110),y:Math.max(0,r[1]-230),width:220,height:270}});console.log("shot",name);}
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:2});await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});
 await p.evaluate(()=>{__tt.manual=true;__tt.setSeed(3);PP2T.sim().s.equip.broomDustpan=1;});
 const w=await until(p,()=>PP2T.sim().s.papa.moving,400);await snap(p,"walk");
 await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="peel"&&t.stage==="act";},800);await snap(p,"peel");
 await p.evaluate(()=>{var s=SC.rich();});await p.evaluate(()=>{var s=PP2T.sim();for(var i=0;i<30;i++)s.s.peels.push({x:6+Math.random()*2,y:10+Math.random()*2,a:Math.random()*6,c:i%3});s.order("clean");});
 await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="sweep"&&t.stage!=="act"&&PP2T.sim().s.papa.moving;},300);await snap(p,"sweep-walk");
 await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="sweep"&&t.stage==="act";},600);await snap(p,"sweep");
 await p.evaluate(()=>{var s=PP2T.sim();s.s.papa.hunger=20;s.s.food=3;s.order("eat");});await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="eat"&&t.stage==="act";},600);await snap(p,"eat");
 await p.evaluate(()=>{PP2T.sim().order("nap");});await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="nap"&&t.lying;},900);await snap(p,"nap",1.4);
 console.log("errs",JSON.stringify(errs));await b.close();})();
