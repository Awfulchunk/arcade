// pile + pool look check
const L=require("./lib.cjs");const fs=require("fs");const OUT=process.env.SHOTS||"/tmp/lookpile";fs.mkdirSync(OUT,{recursive:true});
async function cam(p,x,y,z,name,clip){await p.evaluate((x,y,z)=>{PP2T.setCam(x,y,z);document.getElementById("toast").className="off";},x,y,z);await L.sleep(120);
  const r=await p.evaluate(()=>{var c=document.getElementById("cv").getBoundingClientRect();return [c.left,c.top,c.width,c.height];});
  await p.screenshot({path:OUT+"/"+name+".png",clip:clip||{x:r[0],y:r[1],width:r[2],height:r[3]}});console.log("shot",name);}
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:2});
 await p.evaluate(()=>{__tt.manual=true;__tt.setSeed(4);});
 await cam(p,3.5,21,1.0,"room-start-kitchen");
 await p.evaluate(()=>{PP2T.view.z=0.55;PP2T.setCam(12,12,0.55);});await L.sleep(100);await cam(p,12,12,0.55,"room-start-all");
 await cam(p,3.5,21,1.8,"pile-full");
 await p.evaluate(()=>{var s=PP2T.sim().s;s.pile=22;s.ret=[s.t+0.3,s.t+0.5,s.t+0.65];});await cam(p,3.5,21,1.8,"pile-22-returns");
 await p.evaluate(()=>{var s=PP2T.sim().s;s.pile=5;s.ret=[];});await cam(p,3.5,21,1.8,"pile-5");
 await p.evaluate(()=>{var sim=PP2T.sim(),s=sim.s;s.coins=999;sim.buyItem("roomKey");s.pile=80;for(var i=0;i<4;i++){var q=sim.newPot(1,"pool");sim.toWater(q,17.4,14.5);q.pt=i;}sim.layout();});
 await cam(p,18.5,14,1.8,"pool-4");
 await p.evaluate(()=>{var sim=PP2T.sim(),s=sim.s;for(var i=0;i<26;i++){var q=sim.newPot(1,"pool");sim.toWater(q,17.4,14.5);q.pt=10+i;q.d=Math.random();}var c=sim.newPot(1,"canal");sim.toWater(c,22,15.5);sim.layout();});
 await cam(p,19.5,14,1.4,"pool-30");
 await cam(p,21,10,0.8,"wash-all");
 console.log("errs",JSON.stringify(errs));await b.close();})();
