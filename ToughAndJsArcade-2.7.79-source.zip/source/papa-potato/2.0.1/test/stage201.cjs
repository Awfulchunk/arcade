// 2.0.1 staging screenshots (real play, not forced poses) + While-You-Were-Gone reports
const L=require("./lib.cjs");const fs=require("fs");const OUT=process.env.SHOTS||"/tmp/stage201";fs.mkdirSync(OUT,{recursive:true});
async function until(p,cond,max,st){for(let i=0;i<max;i++){if(await p.evaluate(cond))return i;await p.evaluate(s=>__tt.step(s),st||5);}return -1;}
async function hideToast(p){await p.evaluate(()=>{document.getElementById("toast").className="off";PP2T.clearParts&&0;});}
async function papaShot(p,name,z,w,h){await p.evaluate(z=>{var q=PP2T.sim().s.papa;PP2T.setCam(q.x,q.y,z);document.getElementById("toast").className="off";},z);await L.sleep(160);
  const r=await p.evaluate(()=>{var q=PP2T.sim().s.papa;var a=PP2T.project(q.x,q.y,0);var c=document.getElementById("cv").getBoundingClientRect();return [a[0]+c.left,a[1]+c.top];});
  w=w||300;h=h||360;await p.screenshot({path:OUT+"/"+name+".png",clip:{x:Math.max(0,Math.min(360-w,r[0]-w/2)),y:Math.max(0,r[1]-h*0.82),width:w,height:h}});console.log("shot",name);}
async function full(p,name,cam){if(cam)await p.evaluate(c=>PP2T.setCam(c[0],c[1],c[2]),cam);await hideToast(p);await L.sleep(250);await p.screenshot({path:OUT+"/"+name+".png"});console.log("shot",name);}
async function fresh(b,seed){const {p,errs}=await L.open(b,[360,800],{dpr:2});await p.addScriptTag({content:fs.readFileSync(__dirname+"/scenes.js","utf8")});await p.evaluate(s=>{__tt.manual=true;__tt.setSeed(s);},seed);return {p,errs};}
(async()=>{const b=await L.browser();const E=[];const log={};
 // empty starting room
 let {p,errs}=await fresh(b,3);await full(p,"01-empty-starting-room",[6.5,11.5,0.5]);
 // close-up 2x (idle at start), walking, peeling (knife in hand)
 await papaShot(p,"02-papa-closeup-2x",2.0,340,400);
 log.walk=await until(p,()=>PP2T.sim().s.papa.moving,400);await papaShot(p,"03-papa-walking",1.6);
 log.peel=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="peel"&&t.stage==="act"&&t.t>0.4;},900);await papaShot(p,"04-papa-peeling",1.7);
 // the pile (0.4.11 look)
 await full(p,"05-the-raw-pile",[3.2,20.2,1.25]);
 // sweeping with broom + dustpan
 await p.evaluate(()=>{var s=SC.rich();for(var i=0;i<30;i++)s.s.peels.push({x:6+Math.random()*2,y:10+Math.random()*2,a:Math.random()*6,c:i%3});s.order("clean");});
 log.sweep=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="sweep"&&t.stage==="act";},600);await papaShot(p,"06-papa-sweeping",1.7);
 // nap with sleep screen face
 await p.evaluate(()=>{PP2T.sim().order("nap");});log.nap=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="nap"&&t.lying;},900);await L.sleep(300);await papaShot(p,"07-papa-napping",1.5,320,300);
 E.push(...errs);await p.close();
 // carrying through the door, scrubbing at the tub
 ({p,errs}=await fresh(b,9));await p.evaluate(()=>{var s=SC.rich();s.setBox("deliver",2);s.setBox("scrub",1);});
 log.door=await until(p,()=>{var q=PP2T.sim().s.papa;return q.hold.length>=2&&q.x>13.8&&q.x<15.2&&q.y>2.6&&q.y<5.4;},2000,2);await papaShot(p,"08-papa-carries-through-door",1.4,340,380);
 log.scrub=await until(p,()=>{var t=PP2T.sim().s.papa.task;return t&&t.type==="scrub"&&t.stage==="act"&&t.t>0.3;},2000);await papaShot(p,"09-papa-scrubbing",1.7);
 E.push(...errs);await p.close();
 // scanner drop into pool, potatoes waiting in pool
 ({p,errs}=await fresh(b,5));await p.evaluate(()=>{var s=SC.rich();s.setBox("deliver",1);s.setBox("pool",30);});
 log.drop=await until(p,()=>PP2T.sim().s.pots.some(q=>q.m==="scan"&&q.t>1.0),6000,1);await p.evaluate(()=>{PP2T.setCam(16.2,14.6,1.6);document.getElementById("toast").className="off";});await p.screenshot({path:OUT+"/10-xray-drop-into-pool.png"});console.log("shot drop",log.drop);
 log.wait=await until(p,()=>PP2T.sim().poolCount()>=18,9000,10);log.poolN=await p.evaluate(()=>PP2T.sim().poolCount());await full(p,"11-potatoes-waiting-in-pool",[17.6,14.2,1.35]);
 await full(p,"12-wash-room",[19.5,9,0.55]);
 // want bubble in live play
 await p.evaluate(()=>{var s=PP2T.sim();s.s.want={id:"sunglasses",kind:"acc",name:"SUNGLASSES",price:8,t0:s.s.t};});await p.evaluate(()=>__tt.step(5));await full(p,"13-papa-wants-bubble",[8,12,0.7]);
 E.push(...errs);await p.close();
 // While-You-Were-Gone reports at faked elapsed times (fixed wall clock)
 const now=Date.UTC(2026,10,26,4,0,0);
 for(const [n,sec] of [["1m",60],["1h",3600],["8h",8*3600],["3d",3*86400],["30d",30*86400],["backward",-3600]]){
  ({p,errs}=await fresh(b,21));
  await p.evaluate(()=>{var s=SC.rich();s.place&&0;s.setBox("deliver",1);s.buyItem("radio");s.place("radio",3,5,0);s.buyItem("catBed");s.place("catBed",2,12,0);s.s.coins=40;});
  await p.evaluate(()=>__tt.step(1200));
  const r=await p.evaluate((now,sa)=>{var r=PP2T.awayAt(now,sa);var x=PP2T.sim().s.lastAway;return x?{away:x.awayTxt,coins:x.coins,earned:x.earned,spent:x.spent,peeled:x.peeled,shipped:x.shipped,naps:x.naps,meals:x.meals,jams:x.jams,eff:x.eff,bought:x.bought,wants:x.wants,backward:x.backward}:null;},now,now-sec*1000);
  log["away-"+n]=r;await L.sleep(400);await p.screenshot({path:OUT+"/14-while-you-were-gone-"+n+".png"});console.log("away",n,JSON.stringify(r).slice(0,300));
  if(n==="8h"){await p.evaluate(()=>{var e=document.getElementById("sheetBody");if(e)e.scrollTop=9999;});await L.sleep(200);await p.screenshot({path:OUT+"/14-while-you-were-gone-8h-timeline.png"});}
  E.push(...errs);await p.close();}
 fs.writeFileSync(OUT+"/stage-log.json",JSON.stringify({log,errors:E},null,1));console.log("ERRORS",JSON.stringify(E));await b.close();})();
