#!/bin/bash
# final evidence run on release/papa-potato-2.0.1.html (staging only, NOT shipped)
cd /workspace/game/build-potato2/v2/test
ST=/workspace/game/requests/finished-ship/papa-potato-2.0.1-test
EV=$ST/test-evidence; SH=$ST/screenshots; mkdir -p $EV $SH
echo "start $(date)"
HARD_OUT=$EV/hard-results.json timeout 2400 node hard.cjs > $EV/hard.log 2>&1; echo "hard done $(tail -1 $EV/hard.log)"
timeout 600 node play.cjs > $EV/play.log 2>&1; cp play-results.json $EV/; echo "play done $(tail -1 $EV/play.log)"
timeout 600 node perf.cjs > $EV/perf.log 2>&1; cp perf-results.json $EV/; echo "perf done"
SHOTS=$SH timeout 900 node stage201.cjs > $EV/stage-shots.log 2>&1; echo "stage shots done $(tail -1 $EV/stage-shots.log)"
SHOTS=$SH/robot timeout 600 node posesheet.cjs > $EV/posesheet.log 2>&1; echo "poses done"
SHOTS=$SH/pile-pool timeout 600 node look-pile.cjs > $EV/look-pile.log 2>&1; echo "pile done"
SHOTS=$SH/legacy-set timeout 600 node shots.cjs > $EV/shots.log 2>&1; echo "legacy shots done $(tail -1 $EV/shots.log)"
cd .. && timeout 1200 node /workspace/game/tough-tools/tt.js test release/papa-potato-2.0.1.html --all > $EV/tt.log 2>&1; echo "tt done $(grep '^TEST' $EV/tt.log)"
rm -rf $EV/tt && cp -r /workspace/game/tough-tools/out/papa-potato-2.0.1 $EV/tt
echo "end $(date)"
