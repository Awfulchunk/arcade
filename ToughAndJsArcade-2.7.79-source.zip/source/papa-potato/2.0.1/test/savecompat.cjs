// shared save key papaPotato2.save.v1: 2.0.0 save -> 2.0.1 load, and 2.0.1 save -> 2.0.0 load
const L=require("./lib.cjs");
const V200="file:///workspace/game/build-ship2777/src-work/source/papa-potato/2.0.0/papa-potato-2.0.0.html",V201=L.GAME;
(async()=>{const b=await L.browser();const out=[];
 let {p,errs}=await L.open(b,[360,800],{url:V200});
 await p.evaluate(()=>{var s=PP2T.sim();s.s.coins=777;s.buyItem("roomKey");PP2T.save();});
 const raw=await p.evaluate(()=>localStorage.getItem("papaPotato2.save.v1").length);await p.close();
 ({p,errs:e2}=await L.open(b,[360,800],{url:V201,clear:false}));var e2;
 const r1=await p.evaluate(()=>{var s=PP2T.sim().s;return {coins:s.coins,key:!!s.owned.roomKey,pile:s.pile,acc:s.acc,ver:document.title};});
 await p.evaluate(()=>{for(var i=0;i<600;i++)PP2T.sim().step(1/60);var s=PP2T.sim();s.buyItem("bowTie");s.s.want={id:"beanie",kind:"acc",name:"RED BEANIE",price:6,t0:1};PP2T.save();});await L.sleep(300);await p.close();
 out.push(["2.0.0 save -> 2.0.1",r1,e2]);
 ({p,errs}=await L.open(b,[360,800],{url:V200,clear:false}));
 const r2=await p.evaluate(()=>{var s=PP2T.sim().s;for(var i=0;i<600;i++)PP2T.sim().step(1/60);return {coins:s.coins,key:!!s.owned.roomKey};});await L.sleep(500);
 out.push(["2.0.1 save -> 2.0.0",r2,errs]);console.log(JSON.stringify(out,null,1));await b.close();})();
