// Robot Papa pose + expression sheet: forces each pose directly (no sim stepping), front + back
const L=require("./lib.cjs");const fs=require("fs");const OUT=process.env.SHOTS||"/tmp/poses";fs.mkdirSync(OUT,{recursive:true});
const ZM=+(process.env.ZM||2);
async function snap(p,name,setup,w,h){await p.evaluate(setup);await p.evaluate(z=>{var s=PP2T.sim().s,q=s.papa;PP2T.clearParts();PP2T.setCam(q.x-1.6/z*1.6,q.y-1.6/z*1.6,z);document.getElementById("toast").className="off";},ZM);await L.sleep(80);
  const r=await p.evaluate(()=>{var q=PP2T.sim().s.papa;var a=PP2T.project(q.x,q.y,0);return a;});
  w=w||150*ZM/1.6;h=h||200*ZM/1.6;await p.screenshot({path:OUT+"/"+name+".png",clip:{x:Math.max(0,r[0]-w/2),y:Math.max(0,r[1]-h*0.86),width:w,height:h}});return name;}
(async()=>{const b=await L.browser();const {p,errs}=await L.open(b,[360,800],{dpr:2});
 await p.evaluate(()=>{__tt.manual=true;__tt.setSeed(3);var s=PP2T.sim().s;s.equip.broomDustpan=1;var q=s.papa;q.x=5.5;q.y=11.5;q.moving=false;q.task=null;q.hold=[];q.mood=60;q.energy=80;q.hunger=80;});
 const base=`var s=PP2T.sim().s,q=s.papa;q.task=null;q.moving=false;q.hold=[];q.mood=60;q.energy=80;q.hunger=80;q.wantFlash=0;`;
 const F=`q.fx=0.5;q.fy=0.5;`,B=`q.fx=-0.5;q.fy=-0.5;`;
 const tg=`{x:6,y:13,w:1,h:1}`;
 const poses={idle:``,walk:`q.moving=true;q.walkT=0.3;`,carry:`q.hold=[s.pots&&s.pots[0]?s.pots[0].id:0].filter(function(x){return PP2T.sim().pot(x)});`,
  peel:`q.task={type:"peel",stage:"act",target:${tg}};`,sweep:`q.task={type:"sweep",stage:"act",target:${tg}};`,sweepwalk:`q.task={type:"sweep",stage:"go",target:${tg}};q.moving=true;q.walkT=0.5;`,
  scrub:`q.task={type:"scrub",stage:"act",target:${tg}};`,fix:`q.task={type:"fix",stage:"act",target:${tg}};`,eat:`q.task={type:"eat",stage:"act",target:${tg}};`,doze:`q.task={type:"doze",stage:"act"};`,
  rinse:`q.task={type:"rinse",stage:"act",target:${tg}};`,tune:`q.task={type:"tune",stage:"act",target:${tg}};`};
 const shots=[];
 for(const [n,c] of Object.entries(poses)){shots.push(await snap(p,n+"-f",new Function(base+F+c)));shots.push(await snap(p,n+"-b",new Function(base+B+c)));}
 const ex={happy:`q.mood=90;`,content:``,sad:`q.mood=20;`,focused:`q.task={type:"peel",stage:"act",target:${tg}};`,tired:`q.energy=10;`,hungry:`q.hunger=10;`,eat:`q.task={type:"eat",stage:"act",target:${tg}};`,sleep:`q.task={type:"doze",stage:"act"};`,wow:`q.wantFlash=3;`};
 for(const [n,c] of Object.entries(ex))shots.push(await snap(p,"x-"+n,new Function(base+F+c+`window.__T_OVERRIDE=1;`)));
 const acc={chef:`s.acc={hat:"chef"};`,beanie:`s.acc={hat:"beanie",glasses:1};`,top:`s.acc={hat:"top",bow:1};`,party:`s.acc={hat:"party",glasses:1,bow:1};`};
 for(const [n,c] of Object.entries(acc))shots.push(await snap(p,"a-"+n,new Function(base+F+c)));
 await p.evaluate(()=>{PP2T.sim().s.acc={hat:"chef"};});
 fs.writeFileSync(OUT+"/list.json",JSON.stringify(shots));console.log("errs",JSON.stringify(errs));await b.close();})();
