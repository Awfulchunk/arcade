/* ===== Papa Potato 2.0.1 — AUTO MODE: what Papa got up to while you were away (t1231/t1232).
   Unlimited time away, simulated in blocks (weeks resolve in a few ms). Papa mostly kicks it (naps, eats, radio, the cat,
   the armchair, wandering) and only works in bursts when his mood, energy, hunger, a WANT and a bit of luck line up.
   Output is capped at 50% of what your setup makes live (a ceiling: a lazy Papa makes less). Machines still jam and stay
   jammed until he gets up to fix them. A clock that went backwards counts as zero time. Seeded: same seed = same story. ===== */
var PPAway=(function(){
"use strict";
var S=PP2,EFF=0.5,MIN_AWAY=30;
function fmtDur(sec){sec=Math.max(0,Math.round(sec));var d=Math.floor(sec/86400),h=Math.floor(sec%86400/3600),m=Math.floor(sec%3600/60);
  if(d)return d+"d"+(h?" "+h+"h":"");if(h)return h+"h"+(m?" "+m+"m":"");if(m)return m+"m";return sec+"s";}
function clockAt(ms){var d=new Date(ms),h=d.getHours(),m=d.getMinutes(),ap=h<12?"am":"pm",hh=h%12||12;return hh+(m?":"+(m<10?"0":"")+m:"")+ap;}
function dayAt(ms,startMs){var a=new Date(startMs),b=new Date(ms);a.setHours(0,0,0,0);b.setHours(0,0,0,0);return Math.round((b-a)/86400000);}
/* live rates of THIS setup: a 2-minute sample on a copy (once with Papa, once machines only) */
function measure(sim,seed){
  function copy(){var a=new S.Sim(seed);a.load(sim.saveStr());var n=0;a.s.pots=a.s.pots.filter(function(p){if(p.m==="pool"){n++;return false;}return true;});a.s.pile=Math.min(S.C.potTotal,a.s.pile+n);
    a.s.papa.hunger=85;a.s.papa.energy=90;a.s.want=null;a.s.wantT=1e9;a.s.objs.forEach(function(o){o.jam=0;});return a;}
  function run(a,secs){var s=a.s,e0=s.earned,p0=s.stats.peeled,m0=s.stats.machPeeled,sh0=s.shipped,c0=s.shippedClean,j0=s.stats.jams,dt=1/20,n=Math.round(secs/dt);
    for(var i=0;i<n;i++)a.step(dt);return {coin:(s.earned-e0)/secs,peel:(s.stats.peeled-p0)/secs,mpeel:(s.stats.machPeeled-m0)/secs,ship:(s.shipped-sh0)/secs,clean:(s.shippedClean-c0)/secs,jam:(s.stats.jams-j0)/secs};}
  /* warm the copy up for 40 s first so belts, the pool and the canal are already flowing when we measure */
  var T=150,fa=copy();for(var w=0;w<800;w++)fa.step(1/20);var full=run(fa,T),mach={coin:0,peel:0,mpeel:0,ship:0,clean:0,jam:0};
  var machs=sim.s.objs.filter(function(o){return S.isMach(o.id)&&o.on;});
  if(machs.length){var b=copy();b.decide=function(){this.s.papa.task={type:"idle",stage:"act",t:-1e9,target:null};this.s.papa.path=[];};b.s.papa.task=null;for(var w2=0;w2<800;w2++)b.step(1/20);mach=run(b,T);for(var kk in mach)if(kk!=="jam"&&full[kk]!==undefined)mach[kk]=Math.min(mach[kk],full[kk]);}
  /* coins per peeled potato: what the sample really paid, or what this route pays once it has warmed up */
  var bx=sim.s.box,k0=sim.key(),route=!k0||bx.deliver===0?(bx.wash>0&&sim.placed("sink")?3:2):((bx.scrub>0&&sim.objsOf("tub").length)||sim.placed("washer")?5:3),vpp=full.ship*T>=8?Math.max(route*0.6,full.coin/full.ship):route;
  [full,mach].forEach(function(r){var pe=r.peel+r.mpeel;if(pe*vpp>r.coin){r.coin=pe*vpp;r.ship=Math.max(r.ship,pe);if(vpp>=5)r.clean=Math.max(r.clean,pe);}});
  var pap={};for(var k in full)pap[k]=Math.max(0,full[k]-(k==="jam"?0:mach[k]));
  return {full:full,mach:mach,papa:pap,machs:machs,vpp:vpp};}
function run(sim,nowMs,savedAtMs,seed){
  var s=sim.s,rep={away:0,backward:false};
  if(!(savedAtMs>0)||!isFinite(nowMs))return null;
  var el=(nowMs-savedAtMs)/1000;if(!(el>0)){if(el<-1){rep.backward=true;rep.away=0;rep.timeline=[];rep.wants=[];rep.coins=0;s.lastAway=rep;return rep;}return null;}
  if(el<MIN_AWAY)return null;
  var rng=S.mkRng(((seed>>>0)^Math.floor(savedAtMs/1000))>>>0||1),M=measure(sim,(seed>>>0)||1),p=s.papa,b=s.box,key=sim.key();
  var B=Math.max(Math.min(300,el),el/20000),nB=Math.ceil(el/B);
  var hunger=p.hunger,energy=p.energy,food=s.food,wallet=0,saving=0,earned=0,spent=0,want=s.want,jammed=0,nm=M.machs.length,machNames=M.machs.map(function(o){return S.itemDef(o.id).name.toLowerCase();});
  var poolN=s.pots.filter(function(q){return q.m==="pool";}).length,pool0=poolN,poolPay=(b.scrub>0&&sim.objsOf("tub").length)?5:3;
  var poolCoin=0,acc={peel:0,mpeel:0,ship:0,clean:0,coin:0},tot={naps:0,meals:0,jams:0,fixed:0,bought:[]},act=null,actLeft=0,tl=[],wants=[],cur=null,wantPeel=0,wantNote=null;
  var has=function(id){return sim.placed(id);},spice=has("spiceRack")?65:55,baseMood=sim.moodCalc()+(p.hunger<25?15:0)+(p.energy<25?15:0);
  function label(k,d){var D=fmtDur(d);switch(k){case "nap":return "Napped "+D;case "eat":return "Had a snack";case "radio":return "Listened to the radio "+D;case "cat":return "Petted the cat "+D;case "tv":return "Watched TV in the armchair "+D;
    case "sit":return "Sat and hummed a tune "+D;case "wander":return "Wandered around the kitchen "+D;case "pool":return "Watched the potatoes bob in the pool "+D;case "work":return "Worked "+D;}return k+" "+D;}
  function push(t,txt){tl.push({t:t,txt:txt});}
  function close(t){if(!cur)return;var txt=label(cur.k,t-cur.t0);if(cur.k==="work"){var pe=Math.floor(acc.peel+acc.mpeel)-cur.p0,sh=Math.floor(acc.ship)-cur.s0;txt="Worked "+fmtDur(t-cur.t0)+": peeled "+pe+(sh>0?", shipped "+sh:"");}
    if(cur.k!=="eat")push(cur.t0,txt);if(wantNote&&!wantNote.next){wantNote.next=cur.k;}cur=null;}
  function begin(k,t){if(cur&&cur.k===k)return;close(t);cur={k:k,t0:t,p0:Math.floor(acc.peel+acc.mpeel),s0:Math.floor(acc.ship)};
    if(wantNote&&wantNote.wait&&k!=="work"&&k!=="eat"){wantNote.next=k;wantNote.wait=false;}}
  var thenWord={nap:"napped",radio:"listened to the radio",cat:"petted the cat",tv:"watched TV",sit:"sat back and hummed",wander:"wandered around",pool:"watched the pool",work:"kept working"};
  for(var bi=0;bi<nB;bi++){var t=bi*B,dt=Math.min(B,el-t);if(dt<=0)break;
    var mood=Math.max(0,Math.min(100,baseMood-(hunger<25?15:0)-(energy<25?15:0)));
    /* machines keep going (half speed) until something jams */
    if(nm&&jammed<nm){var run=1-jammed/nm;acc.mpeel+=EFF*M.mach.mpeel*dt*run;acc.ship+=EFF*M.mach.ship*dt*run;acc.clean+=EFF*M.mach.clean*dt*run;var mc=EFF*M.mach.coin*dt*run;acc.coin+=mc;
      var pj=1-Math.exp(-EFF*Math.max(M.full.jam,0.0006*nm)*dt*run);if(rng()<pj){jammed++;tot.jams++;push(t+rng()*dt,"The "+machNames[Math.floor(rng()*nm)]+" jammed");}}
    /* wants: food when hungry, or a little something he'd like */
    if(!want&&rng()<1-Math.exp(-dt/5400)){var w=sim.pickWant(rng);if(w){want=w;wantPeel=Math.floor(acc.peel+acc.mpeel);push(t,"Started wanting "+w.name.toLowerCase()+" ("+w.price+"c)");}}
    if(hunger<35&&food<=0&&(!want||want.kind!=="food")){want={id:"snack",kind:"food",name:"A SNACK",price:sim.foodPrice()};wantPeel=Math.floor(acc.peel+acc.mpeel);}
    /* coins he makes while he wants something go into his own savings for it; the rest is yours */
    var gain=acc.coin-earned;earned+=gain;if(want){saving+=gain;}else wallet+=gain;
    if(want&&saving>=want.price){saving-=want.price;wallet+=saving;saving=0;spent+=want.price;
      var pe2=Math.floor(acc.peel+acc.mpeel)-wantPeel;wantNote={txt:"Wanted "+want.name.toLowerCase()+(pe2>0?", peeled "+pe2:", had the coins saved")+", bought "+(want.kind==="food"?"a snack":"the "+want.name.toLowerCase()),wait:true};wants.push(wantNote);
      if(want.kind==="food")food++;else{s.owned[want.id]=(s.owned[want.id]|0)+1;sim.wear(want.id,true);tot.bought.push(want.name);}
      push(t,"Bought "+(want.kind==="food"?"a snack":"the "+want.name.toLowerCase())+" ("+want.price+"c)");want=null;baseMood=Math.min(100,baseMood+4);}
    /* eating comes first */
    if(hunger<35&&food>0){food--;tot.meals++;hunger=Math.min(100,hunger+spice);push(t,"Ate a can of food");}
    if(actLeft<=0||act==="nap"&&energy>=95){
      var pw=0.2+(want?0.5:0)+(mood-55)/250+(energy>55?0.05:-0.1)-(hunger<30?0.12:0)+(jammed&&b.fix>0?0.15:0)+(poolN>=Math.max(1,b.pool)&&key?0.08:0);pw=Math.max(0.02,Math.min(0.85,pw));
      if(energy<18){act="nap";actLeft=99;}
      else if(rng()<pw){act="work";actLeft=1+Math.floor(rng()*(want?5:3));}
      else{var opts=[["wander",1],["sit",1]];if(energy<65)opts.push(["nap",3]);if(has("radio"))opts.push(["radio",2.2]);if(has("catBed"))opts.push(["cat",2]);if(has("tvArmchair"))opts.push(["tv",2]);if(poolN>0&&key)opts.push(["pool",0.5]);
        var sw=0;opts.forEach(function(o){sw+=o[1];});var r=rng()*sw;act=opts[opts.length-1][0];for(var oi=0;oi<opts.length;oi++){r-=opts[oi][1];if(r<=0){act=opts[oi][0];break;}}actLeft=act==="nap"?99:1+Math.floor(rng()*3);}
      if(act==="nap")tot.naps++;}
    begin(act,t);actLeft--;
    if(act==="work"){if(jammed){tot.fixed+=jammed;push(t,"Fixed "+(jammed>1?jammed+" jammed machines":"the jam"));jammed=0;}
      var eff=Math.max(0.6,Math.min(1,0.55+mood/200))*(energy<25?0.6:1)*(hunger<25?0.6:1);
      acc.peel+=EFF*eff*M.papa.peel*dt;acc.ship+=EFF*eff*M.papa.ship*dt;acc.clean+=EFF*eff*M.papa.clean*dt;acc.coin+=EFF*eff*M.papa.coin*dt;
      if(poolN>0&&key){var dn=Math.min(poolN,Math.floor(EFF*eff*dt/20+rng()));poolN-=dn;acc.ship+=dn;acc.coin+=dn*poolPay;poolCoin+=dn*poolPay;if(poolPay===5)acc.clean+=dn;}
      hunger-=dt*100/(150*60)*1.5;energy-=dt*100/(4*3600)*2.5;}
    else if(act==="nap"){energy=Math.min(100,energy+dt*100/(50*60));hunger-=dt*100/(150*60)*0.4;if(energy>=95)actLeft=0;}
    else{hunger-=dt*100/(150*60);energy=Math.max(0,energy-dt*100/(8*3600)*(act==="tv"?-1.5:1));}
    hunger=Math.max(0,hunger);energy=Math.max(0,Math.min(100,energy));}
  close(el);
  var gainEnd=acc.coin-earned;earned+=gainEnd;wallet+=gainEnd+saving;
  wants.forEach(function(w){if(w.wait&&!w.next)w.next="kicked back";w.txt+=", then "+(thenWord[w.next]||w.next)+".";});
  if(want)wants.push({txt:"Still wants "+want.name.toLowerCase()+" ("+want.price+"c)."});
  /* apply to the real game */
  var coins=Math.max(0,Math.floor(wallet)),ship=Math.floor(acc.ship),clean=Math.min(ship,Math.floor(acc.clean)),pe=Math.floor(acc.peel),mpe=Math.floor(acc.mpeel);
  s.coins+=coins;s.earned+=Math.floor(earned);s.shipped+=ship;s.shippedClean+=clean;s.stats.peeled+=pe;s.stats.machPeeled+=mpe;s.stats.jams+=tot.jams;s.stats.fixed+=tot.fixed;s.stats.wantsMet+=wants.filter(function(w){return w.next;}).length;
  s.food=Math.min(sim.cooCap(),food);p.hunger=hunger;p.energy=energy;s.want=want?{id:want.id,kind:want.kind,name:want.name,price:want.price,t0:s.t}:null;
  var left=jammed;M.machs.forEach(function(o){if(left>0){o.jam=1;left--;s.lastJam=o.u;}});
  var drop=pool0-poolN;s.pots.filter(function(q){return q.m==="pool";}).slice(0,drop).forEach(function(q){sim.killPot(q);});
  p.task=null;p.path=[];p.order=null;
  var totals={};var lastT=0;
  /* timeline: wall-clock times; very long trips keep the first and last stretches plus totals */
  var pts=tl.sort(function(a,c){return a.t-c.t;}).map(function(e){var ms=savedAtMs+e.t*1000,dd=dayAt(ms,savedAtMs);return {at:(dd>0?"day "+(dd+1)+" ":"")+clockAt(ms),txt:e.txt};});
  var cut=0;if(pts.length>36){cut=pts.length-30;pts=pts.slice(0,15).concat([{at:"…",txt:cut+" more things over "+fmtDur(el)}]).concat(pts.slice(-15));}
  var live=M.full.coin*el,eff2=live>0?Math.max(0,Math.floor(earned)-poolCoin)/live:0;
  rep={away:el,awayTxt:fmtDur(el),from:clockAt(savedAtMs),to:clockAt(nowMs),coins:coins,earned:Math.floor(earned),spent:spent,peeled:pe+mpe,papaPeeled:pe,machPeeled:mpe,cleaned:clean,shipped:ship,
    naps:tot.naps,meals:tot.meals,jams:tot.jams,fixed:tot.fixed,jammedNow:jammed,bought:tot.bought,poolLeft:poolN,poolDone:drop,timeline:pts,wants:wants.map(function(w){return w.txt;}),eff:Math.round(eff2*1000)/1000,liveRate:M.full.coin,blocks:nB};
  s.t+=Math.min(el,1e7);s.lastAway=rep;sim.dirtyGrid=true;return rep;}
return {run:run,measure:measure,fmtDur:fmtDur,clockAt:clockAt,EFF:EFF,MIN_AWAY:MIN_AWAY};
})();
