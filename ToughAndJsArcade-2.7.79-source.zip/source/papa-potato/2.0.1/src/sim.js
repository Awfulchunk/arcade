/* ===== Papa Potato 2.0.1 — simulation (fresh rework, t1213/t1223). One continuous iso map: kitchen + wash room.
   Grid tiles (1 tile = 0.6 m). Papa, the potatoes and every machine are real objects on that grid.
   No Math.random / Date in here: everything runs off the seeded RNG so setSeed(n);step(k) is repeatable. ===== */
var PP2=(function(){
"use strict";
var VERSION="2.0.1",SAVE_KEY="papaPotato2.save.v1";
var W=26,H=24,DT=1/60,POT_CAP=360,PEEL_CAP=260;
var DIRS=[[1,0],[0,1],[-1,0],[0,-1]];
var DNAME=["EAST","SOUTH","WEST","NORTH"];
var KIT={x0:0,y0:0,x1:14,y1:24},WSH={x0:15,y0:0,x1:26,y1:16};
var DOOR=[{x:14,y:3},{x:14,y:4}];
var FIX={
  pile:{x:1,y:19,w:5,h:4},
  chute:{x:6,y:0,w:2,h:1},
  scanK:{x:12,y:14,w:2,h:2},
  scanW:{x:15,y:14,w:2,h:2},
  pool:{x:17,y:12,w:3,h:4},
  hole:{x:25,y:0},
  outlet:{wall:"W",y:8,x:0,range:4.5,cap:5}
};
var CANAL_TILES=[];(function(){var x,y;for(x=20;x<=25;x++)CANAL_TILES.push([x,15]);for(y=14;y>=0;y--)CANAL_TILES.push([25,y]);})();
var CANAL_PTS=[{x:20,y:15.5},{x:25.5,y:15.5},{x:25.5,y:0.05}];
var CANAL_LEN=5.5+15.45;
var PACE=["CHILL","EASY","STEADY","BRISK","GRIND"],SPD=[0.6,0.8,1.0,1.25,1.5],DRN=[0.55,0.75,1.0,1.45,2.0];
var STYLE=[{n:"NEAT",sp:0.8,peels:2},{n:"NORMAL",sp:1.0,peels:3},{n:"QUICK",sp:1.3,peels:5}];
var SPEED_NAME=["OFF","SLOW","STEADY","FAST"],SPEEDV=[0,0.6,1.0,1.5];
var DELIVER=["CHUTE","SCANNER","CARRY"];
var COMMANDS=[
  {id:"pace",name:"WORK PACE",min:0,max:4,step:1,def:2,fmt:"pace",what:"How fast he walks and works.",effect:"CHILL x0.6 speed (hunger and energy drain x0.55) up to GRIND x1.5 speed (drain x2.0)."},
  {id:"eat",name:"EAT WHEN HUNGER <",min:0,max:70,step:5,def:0,fmt:"pct",what:"He goes to the cooler to eat when hunger drops below the number.",effect:"1 can = +55 hunger. OFF = never. Hunger tops out at 100."},
  {id:"nap",name:"NAP WHEN ENERGY <",min:0,max:70,step:5,def:0,fmt:"pct",what:"He goes to bed when energy drops below the number.",effect:"He sets his sack down beside the bed first and picks it up after. OFF = he dozes on the floor when he runs out."},
  {id:"wake",name:"NAP UNTIL ENERGY >",min:50,max:100,step:10,def:100,fmt:"pct",what:"How rested he is when he gets up.",effect:"Lower = short naps. Needs NAP WHEN."},
  {id:"clean",name:"CLEAN WHEN PEELS >",min:0,max:90,step:5,def:0,fmt:"num",what:"He sweeps when the floor peel count goes over the number.",effect:"Peels slow him up to 30% at 90 peels. The broom + dustpan sweeps twice as fast as bare hands."},
  {id:"rinse",name:"RINSE WHEN HANDS <",min:0,max:70,step:5,def:30,fmt:"pct",what:"He rinses at the sink built into the peel table.",effect:"Under 25% clean hands, peeling is 15% slower."},
  {id:"style",name:"PEEL STYLE",min:0,max:2,step:1,def:1,fmt:"style",what:"How carefully he peels.",effect:"NEAT x0.8 speed, 2 peels. NORMAL x1.0, 3 peels. QUICK x1.3, 5 peels."},
  {id:"autob",name:"KEEP FOOD AT LEAST",min:0,max:9,step:1,def:0,fmt:"num",what:"Buys food cans for you whenever you have the coins.",effect:"OFF = buy food in the SHOP."},
  {id:"deliver",name:"SEND PEELED TO",min:0,max:2,step:1,def:0,fmt:"deliver",need:"roomKey",what:"Where he takes peeled potatoes.",effect:"CHUTE: kitchen chute, pays by dirt (dirty 2c). SCANNER: the X-ray drops them into the wash-room pool, where they wait for him (EMPTY POOL AT); they soak in the canal on the way to the ship hole. CARRY: he walks them through the door to the scrub tub and scrubs them himself (clean = 5c)."},
  {id:"pool",name:"EMPTY POOL AT",min:0,max:30,step:1,def:6,fmt:"num",need:"roomKey",what:"Peeled potatoes from the X-ray wait in the wash-room pool until he comes for them.",effect:"When the pool holds this many he walks over, scoops them out, scrubs them at the tub (SCRUB ON) and tosses them into the canal to ship. OFF = they stay in the pool (it holds 48)."},
  {id:"scrub",name:"SCRUB AT THE TUB",min:0,max:1,step:1,def:1,fmt:"onoff",need:"roomKey",what:"He scrubs dirty potatoes in the wash-room scrub tub.",effect:"ON = he scrubs what is in the tub and tosses clean ones into the canal. You can also brush them yourself with your finger."},
  {id:"fix",name:"FIX JAMS",min:0,max:1,step:1,def:1,fmt:"onoff",need:"machine",what:"He walks over and clears jammed machines.",effect:"ON = he drops his work (not eating or sleeping) to clear a jam. OFF = only when you tap the machine and press FIX."},
  {id:"belts",name:"BELT SPEED",min:0,max:3,step:1,def:2,fmt:"speed",need:"belt",what:"How fast every belt tile runs.",effect:"OFF stops all belts. Belts need power."},
  {id:"mspeed",name:"MACHINE SPEED",min:0,max:3,step:1,def:2,fmt:"speed",need:"machine",what:"How hard the hoppers, auto peelers and washers run.",effect:"FAST = more potatoes per minute but jams twice as often. SLOW = half the jams."},
  {id:"wash",name:"WASH BEFORE PEEL",min:0,max:1,step:1,def:0,fmt:"onoff",need:"sink",what:"He rinses raw potatoes in the kitchen sink first.",effect:"Peeled potatoes come out half as dirty."},
  {id:"water",name:"WATER WHEN DRY >",min:0,max:90,step:10,def:0,fmt:"num",need:"plant",what:"He waters the plant.",effect:"A watered plant: energy drains 10% slower in the kitchen."},
  {id:"tv",name:"TV",min:0,max:1,step:1,def:0,fmt:"onoff",need:"tvArmchair",what:"Turns the TV on.",effect:"Pair with WATCH WHEN."},
  {id:"watch",name:"WATCH WHEN ENERGY <",min:0,max:70,step:5,def:0,fmt:"pct",need:"tvArmchair",what:"He sits in the armchair and watches TV.",effect:"Slow energy back (slower than a nap). Needs the TV ON."},
  {id:"lamp",name:"LAMP",min:0,max:1,step:1,def:0,fmt:"onoff",need:"lamp",what:"The floor lamp.",effect:"ON: peeling 8% faster."},
  {id:"radio",name:"RADIO",min:0,max:1,step:1,def:0,fmt:"onoff",need:"radio",what:"The radio.",effect:"ON: energy drains 20% slower and he works 5% faster. Stations or your own songs (RADIO button)."}
];
var BOX={};COMMANDS.forEach(function(c){BOX[c.id]=c;});
var UPS=[
  {id:"peeler",name:"SHARP PEELER",max:3,prices:[40,110,260],fx:"His peeling takes 15% less time per level."},
  {id:"boots",name:"GOOD BOOTS",max:3,prices:[30,90,220],fx:"He walks 10% faster per level."},
  {id:"pantry",name:"BIGGER COOLER",max:2,prices:[25,80],fx:"The cooler holds 3 more food per level."},
  {id:"broom",name:"STIFF BROOM",max:3,prices:[30,90,200],fx:"Sweeping and mopping are 50% faster per level."},
  {id:"bed",name:"SOFT BED",max:2,prices:[30,90],fx:"Naps restore energy 35% faster per level."},
  {id:"bag",name:"BIGGER SACK",max:2,prices:[25,80],fx:"The carry sack holds 1 more potato per level."},
  {id:"belts",name:"BETTER BELTS",max:3,prices:[40,120,260],fx:"Belts run 15% faster per level.",lv:2},
  {id:"mach",name:"SERVICE KIT",max:3,prices:[50,140,300],fx:"Machines jam 30% less and he clears jams 30% faster per level.",lv:2},
  {id:"gen",name:"BIG GENERATOR",max:2,prices:[60,160],fx:"Every generator powers 8 more load and reaches 1.5 tiles farther per level.",lv:2},
  {id:"channel",name:"WIDER CHANNEL",max:2,prices:[70,180],fx:"The canal current gets faster and the pool pulls potatoes in quicker.",lv:2},
  {id:"brush",name:"STEEL BRUSH",max:2,prices:[40,120],fx:"Scrubbing (his and yours) is 40% stronger per level.",lv:2}
];
var UPI={};UPS.forEach(function(u){UPI[u.id]=u;});
/* item catalog. cat: mach | belt | floor | rug | wall | basin | tool | key | theme. w,d = footprint tiles at r=0. room: k / w / any. */
var ITEMS=[
  {id:"roomKey",name:"ROOM KEY",lv:1,price:40,cat:"key",fx:"Unlocks the metal door to the wash room. Then: SEND PEELED TO, SCRUB, the X-ray scanner pass-through and the ship hole (clean potatoes pay 5c)."},
  {id:"betterPeeler",name:"BETTER PEELER",lv:1,price:20,cat:"tool",fx:"Equip on Papa (INV). Peeling 10% faster. You see it in his hand."},
  {id:"carrySack",name:"CARRY SACK",lv:1,price:18,cat:"tool",fx:"Equip on Papa (INV). He carries 3 potatoes at a time in a sack on his back (more with BIGGER SACK). He sets it down beside the bed before he naps."},
  {id:"broomDustpan",name:"BROOM + DUSTPAN",lv:1,price:16,cat:"tool",fx:"Equip on Papa (INV). Sweeps twice as fast. It only ever moves in his hands; it rides on his back between jobs."},
  {id:"sink",name:"KITCHEN SINK",lv:1,price:25,cat:"floor",w:1,d:1,room:"k",fx:"WASH BEFORE PEEL: he rinses raw potatoes here first, so peeled ones come out half as dirty. Dripping tap."},
  {id:"smallCooler",name:"SMALL COOLER",lv:1,price:22,cat:"floor",w:1,d:1,room:"any",fx:"+2 food slots. Hums when stocked."},
  {id:"basicCot",name:"BASIC COT",lv:1,price:28,cat:"floor",w:1,d:3,room:"any",fx:"A second bed. He naps on whichever is closer."},
  {id:"kitchenMat",name:"KITCHEN MAT",lv:1,price:12,cat:"rug",w:2,d:1,room:"any",fx:"CARPET. Energy drains 30% slower while he stands on it. Best at the peel table."},
  {id:"clock",name:"WALL CLOCK",lv:1,price:10,cat:"wall",w:1,room:"k",fx:"WALL. Real ticking hands (shift time). Meals are 30% shorter."},
  {id:"coatHook",name:"COAT HOOK + APRON",lv:1,price:10,cat:"wall",w:1,room:"k",fx:"WALL. QUICK peeling drops 4 peels a potato, not 5. The apron sways."},
  {id:"calendar",name:"CALENDAR",lv:1,price:8,cat:"wall",w:1,room:"k",fx:"WALL. Each new shift day pays a 10c payday. The page flips."},
  {id:"spiceRack",name:"SPICE RACK",lv:1,price:12,cat:"wall",w:1,room:"k",fx:"WALL. Tastier meals: each can gives +65 hunger, not +55."},
  {id:"window",name:"WINDOW + CURTAINS",lv:1,price:14,cat:"wall",w:2,room:"k",fx:"WALL. Daylight (6 AM to 8 PM shift time): he works 4% faster. The sky follows the shift clock."},
  {id:"compost",name:"COMPOST BIN",lv:1,price:16,cat:"floor",w:1,d:1,room:"any",fx:"Sweeping is 25% faster and every 20 peels swept turn into 1c."},
  {id:"fruitBowl",name:"FRUIT BOWL STAND",lv:1,price:10,cat:"floor",w:1,d:1,room:"k",fx:"Hunger drains 10% slower in the kitchen."},
  {id:"wallpaper",name:"WALLPAPER BOOK",lv:1,price:15,cat:"theme",fx:"COSMETIC. Kitchen walls: CLASSIC, MINT STRIPE, ROSE TILE, NAVY PANEL (INV)."},
  {id:"belt",name:"BELT TILE",lv:2,price:6,cat:"belt",w:1,d:1,room:"any",stack:true,load:1,fx:"One belt tile. Place them one at a time; tap a belt to turn it. Potatoes really ride them into machines, the chute, the scanner, the table tray, the tub or the water. Needs power."},
  {id:"generator",name:"GENERATOR",lv:2,price:60,cat:"mach",w:2,d:2,room:"any",stack:true,fx:"Powers belts and machines inside its blue ring (radius 7) up to 12 load. Belt = 1, hopper = 2, auto peeler = 3, washer = 3. The wall outlet gives 5 load in a small ring for free."},
  {id:"hopper",name:"POTATO HOPPER",lv:2,price:55,cat:"mach",w:2,d:2,room:"any",stack:true,load:2,fx:"Place it touching the raw pile: it sucks raw potatoes up and drops them out of its spout (the arrow) onto a belt. It also takes raw potatoes from a belt at its back. Can jam."},
  {id:"plant",name:"PLANT",lv:2,price:15,cat:"floor",w:1,d:1,room:"any",fx:"Energy drains 10% slower in the kitchen while watered (WATER WHEN DRY). Leaves sway; it droops when dry."},
  {id:"lamp",name:"FLOOR LAMP",lv:2,price:14,cat:"floor",w:1,d:1,room:"any",fx:"LAMP ON: peeling 8% faster. Warm light pool."},
  {id:"runner",name:"RUNNER RUG",lv:2,price:20,cat:"rug",w:1,d:3,room:"any",fx:"CARPET. He walks 15% faster on it."},
  {id:"poster",name:"PAPA POSTER",lv:2,price:16,cat:"wall",w:1,room:"k",fx:"WALL. When he goes AUTO-LAZY he still works at 70% speed, not 50%. The corner flutters."},
  {id:"shelf",name:"PANTRY SHELF",lv:2,price:24,cat:"floor",w:2,d:1,room:"k",fx:"+2 food storage. The cans sit on the shelf."},
  {id:"potsPans",name:"HANGING POTS + PANS",lv:2,price:18,cat:"wall",w:2,room:"k",fx:"WALL. Food cans cost 1c less. They swing."},
  {id:"photos",name:"FRAMED POTATO PHOTOS",lv:2,price:14,cat:"wall",w:1,room:"k",fx:"WALL. He only goes AUTO-LAZY under 20%, not 25%."},
  {id:"sackPile",name:"POTATO SACK PILE",lv:2,price:18,cat:"floor",w:2,d:1,room:"k",fx:"Grabbing from the pile is 20% faster."},
  {id:"cookbook",name:"COOKBOOK STAND",lv:2,price:16,cat:"floor",w:1,d:1,room:"k",fx:"NEAT peeling works at 90% speed, not 80%. Pages turn."},
  {id:"towelRack",name:"TOWEL RACK",lv:2,price:14,cat:"wall",w:1,room:"w",fx:"WASH WALL. Energy drains 15% slower in the wash room."},
  {id:"soap",name:"SOAP DISPENSER",lv:2,price:12,cat:"wall",w:1,room:"w",fx:"WASH WALL. Soapy water: soaking cleans 15% faster."},
  {id:"mopBucket",name:"MOP BUCKET",lv:2,price:12,cat:"floor",w:1,d:1,room:"w",fx:"WASH FLOOR. He walks 10% faster in the wash room and sweeps peels 25% faster."},
  {id:"floorTiles",name:"FLOOR TILES",lv:2,price:20,cat:"theme",fx:"COSMETIC. Kitchen floor: CLASSIC, BLACK + WHITE, TERRACOTTA, OAK PLANK (INV)."},
  {id:"autoPeeler",name:"AUTO PEELER",lv:3,price:120,cat:"mach",w:3,d:2,room:"any",stack:true,load:3,fx:"Raw potatoes go in the back, peeled (dirty) ones come out the front spout onto a belt. Peels spray on the floor. Can JAM: the red light flashes and he comes to clear it."},
  {id:"radio",name:"RADIO",lv:3,price:22,cat:"floor",w:1,d:1,room:"any",fx:"RADIO ON: energy drains 20% slower and he works 5% faster. Two stations or your own songs."},
  {id:"rug",name:"RUG",lv:3,price:18,cat:"rug",w:2,d:2,room:"any",fx:"CARPET. Hunger drains 20% slower while he stands on it."},
  {id:"fan",name:"FLOOR FAN",lv:3,price:26,cat:"floor",w:1,d:1,room:"any",fx:"The peel mess slows him at most 15%, not 30%. Blades spin."},
  {id:"duck",name:"RUBBER DUCK",lv:3,price:12,cat:"basin",fx:"WASH POOL (INV). The pool pulls potatoes into the canal 25% faster. It bobs."},
  {id:"stringLights",name:"STRING LIGHTS",lv:3,price:22,cat:"wall",w:2,room:"k",fx:"WALL. Night shift (8 PM to 6 AM): he works 4% faster. They twinkle."},
  {id:"neonSign",name:"NEON OPEN SIGN",lv:3,price:30,cat:"wall",w:1,room:"k",fx:"WALL. Every 20th potato shipped gets a +1c tip. It buzzes and blinks."},
  {id:"bookshelf",name:"BOOKSHELF",lv:3,price:28,cat:"floor",w:2,d:1,room:"k",fx:"Buying the next LEVEL costs 10% less."},
  {id:"catBed",name:"CAT BED + CAT",lv:3,price:35,cat:"floor",w:1,d:1,room:"k",fx:"A cat wanders the kitchen and naps here. His naps restore 10% faster."},
  {id:"toyBoat",name:"TOY BOAT",lv:3,price:16,cat:"basin",fx:"WASH CANAL (INV). The current is 15% stronger. It sails the canal."},
  {id:"tvArmchair",name:"TV + ARMCHAIR",lv:4,price:90,cat:"floor",w:2,d:2,room:"k",fx:"TV ON + WATCH WHEN: he sits and gets energy back."},
  {id:"roundRug",name:"ROUND BRAID RUG",lv:4,price:30,cat:"rug",w:2,d:2,room:"any",fx:"CARPET. Grabbing, peeling and dropping are 8% faster on it."},
  {id:"washer",name:"WASHER DRUM",lv:4,price:220,cat:"mach",w:3,d:2,room:"any",stack:true,load:3,fx:"Dirty peeled potatoes go in the back and come out clean from the front. Can jam (soap clog)."},
  {id:"trophyShelf",name:"TROPHY SHELF",lv:4,price:40,cat:"wall",w:2,room:"k",fx:"WALL. A cup per level reached and a gold cup per 500 shipped: he works 1% faster per cup (max +3%)."},
  {id:"aquarium",name:"AQUARIUM",lv:4,price:45,cat:"floor",w:1,d:1,room:"any",fx:"Calm fish: hunger and energy drain 5% slower."},
  {id:"bubbles",name:"BUBBLE MAKER",lv:4,price:24,cat:"basin",fx:"WASH POOL (INV). Soaking cleans 50% faster."},
  {id:"partyHat",name:"PARTY HAT",lv:1,price:5,cat:"acc",slot:"hat",fx:"FOR PAPA (COSMETIC). A striped party cone with a pom-pom. Swaps with his chef hat (INV)."},
  {id:"beanie",name:"RED BEANIE",lv:1,price:6,cat:"acc",slot:"hat",fx:"FOR PAPA (COSMETIC). A knit beanie with a pom-pom. Swaps with his chef hat (INV)."},
  {id:"bowTie",name:"BOW TIE",lv:1,price:6,cat:"acc",slot:"bow",fx:"FOR PAPA (COSMETIC). A red bow tie at his collar."},
  {id:"sunglasses",name:"SUNGLASSES",lv:1,price:8,cat:"acc",slot:"glasses",fx:"FOR PAPA (COSMETIC). Cool shades over his screen face."},
  {id:"topHat",name:"TOP HAT",lv:2,price:14,cat:"acc",slot:"hat",fx:"FOR PAPA (COSMETIC). A tall black top hat with an orange band."},
  {id:"catToy",name:"CAT TOY",lv:3,price:7,cat:"acc",slot:"toy",fx:"FOR THE CAT (COSMETIC). A yarn ball by the cat bed; the cat bats it around. Needs the CAT BED."},
  {id:"statue",name:"PAPA STATUE",lv:5,price:60,cat:"floor",w:1,d:1,room:"any",fx:"A golden Papa. Pride: he works 5% faster."}
];
var ITEMI={};ITEMS.forEach(function(it){ITEMI[it.id]=it;});
var STARTERS={
  table:{name:"PEEL TABLE",w:3,d:2,room:"any",fx:"Butcher block with a sink built into one end. Raw potatoes that ride a belt into it land in its tray, so he peels without walking to the pile."},
  cooler:{name:"FOOD COOLER",w:1,d:1,room:"any",fx:"Holds the food cans (6, more with BIGGER COOLER)."},
  bed:{name:"BED",w:2,d:3,room:"any",fx:"Where he naps."},
  tub:{name:"SCRUB TUB",w:2,d:1,room:"w",fx:"Soapy tub in the wash room. Peeled potatoes go in (he carries them or a belt feeds it). Scrub them clean (he does with SCRUB ON, or brush them with your finger). If a belt sits at its front, clean ones roll out onto it."}
};
var THEMES={wall:["CLASSIC","MINT STRIPE","ROSE TILE","NAVY PANEL"],floor:["CLASSIC","BLACK + WHITE","TERRACOTTA","OAK PLANK"]};
var LEVEL_PRICE=[0,0,80,160,280,450];
var MACH={hopper:1,autoPeeler:1,washer:1};
var LOAD={belt:1,hopper:2,autoPeeler:3,washer:3};
var DECOR_MOOD=["clock","coatHook","calendar","spiceRack","window","compost","fruitBowl","plant","lamp","runner","poster","shelf","potsPans","photos","sackPile","cookbook","towelRack","soap","mopBucket","radio","rug","fan","stringLights","neonSign","bookshelf","catBed","tvArmchair","roundRug","trophyShelf","aquarium","statue","kitchenMat"];
var C={walk:3.0,grab:0.7,peel:6.0,drop:0.45,eat:3.0,meal:55,foodPrice:8,coolerBase:6,hungerDrain:0.30,hungerNap:0.10,energyDrain:0.42,napRegen:6.0,dozeRegen:4.0,tvRegen:2.2,
  lazyLow:25,lazySpeed:0.5,potTotal:80,poolCap:48,rinse:1.0,sweepRate:6,scrubRate:0.55,soakPool:0.012,soakCanal:0.013,jam:0.035,fixT:2.4};
function itemDef(id){return ITEMI[id]||STARTERS[id]||null;}
function isMach(id){return !!MACH[id];}
function fp(o){var d=itemDef(o.id)||{w:1,d:1},w=d.w||1,h=d.d||1;if(o.r&1){var t=w;w=h;h=t;}return {x:o.x,y:o.y,w:w,h:h};}
function roomOf(x,y){if(x>=KIT.x0&&x<KIT.x1&&y>=KIT.y0&&y<KIT.y1)return "k";if(x>=WSH.x0&&x<WSH.x1&&y>=WSH.y0&&y<WSH.y1)return "w";if(x===14&&(y===3||y===4))return "door";return null;}
function isCanal(x,y){for(var i=0;i<CANAL_TILES.length;i++)if(CANAL_TILES[i][0]===x&&CANAL_TILES[i][1]===y)return true;return false;}
function inRect(x,y,r){return x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h;}
function isPool(x,y){return inRect(x,y,FIX.pool);}
function isWater(x,y){return isPool(x,y)||isCanal(x,y);}
function fixedBlock(x,y){return inRect(x,y,FIX.pile)||inRect(x,y,FIX.chute)||inRect(x,y,FIX.scanK)||inRect(x,y,FIX.scanW)||isWater(x,y);}
function mkRng(seed){var a=(seed>>>0)||1;return function(){a=(a+0x6D2B79F5)|0;var t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296;};}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function num(v,d){v=+v;return isFinite(v)?v:d;}
function around(r){var o=[],x,y;for(x=r.x;x<r.x+r.w;x++){o.push([x,r.y-1]);o.push([x,r.y+r.h]);}for(y=r.y;y<r.y+r.h;y++){o.push([r.x-1,y]);o.push([r.x+r.w,y]);}return o;}
/* ======================================================= */
function Sim(seed){this.reset(seed);}
var P=Sim.prototype;
P.reset=function(seed){
  this.seed=(seed>>>0)||1;this.rng=mkRng(this.seed);
  var box={};COMMANDS.forEach(function(c){box[c.id]=c.def;});
  this.s={v:1,ver:VERSION,t:0,tick:0,uid:1,coins:0,level:1,food:1,shipped:0,earned:0,shippedClean:0,swept:0,compostAcc:0,lastPayDay:0,
    box:box,ups:{},inv:{},owned:{},equip:{betterPeeler:false,carrySack:false,broomDustpan:false},
    objs:[],pots:[],peels:[],
    papa:{x:6.5,y:13.5,dir:1,fx:0,fy:1,hunger:80,energy:90,hands:100,mood:60,hold:[],sack:{on:true,x:0,y:0},task:null,joy:0,wantFlash:0,path:[],lazy:false,order:null,walkT:0,moving:false,radioT:60,where:"k"},
    cat:{x:4.5,y:14.5,tx:4.5,ty:14.5,st:"sit",t:2,face:1,fx:0,fy:1},plant:{dry:0},basin:{duck:false,toyBoat:false,bubbles:false},
    decor:{wall:0,floor:0,radioSt:0,radioVol:6,radioNear:1},tips:0,msg:"Welcome to PAPA POTATO 2. He works on his own: set his COMMAND BOXES below.",msgT:0,lastJam:null,
    pile:C.potTotal,ret:[],acc:{hat:"chef",glasses:0,bow:0,toy:0},want:null,wantT:150,lastAway:null,
    stats:{peeled:0,machPeeled:0,scrubbed:0,brushed:0,jams:0,fixed:0,beltMoved:0,doorTrips:0,washed:0,drumWashed:0,sackDowns:0,poolRuns:0,wantsMet:0}};
  UPS.forEach(function(u){this.s.ups[u.id]=0;},this);
  this.addObj("table",5,9,0,true);this.addObj("cooler",11,5,0,true);this.addObj("bed",10,18,0,true);this.addObj("tub",19,4,0,true);
  this.dirtyGrid=true;this._grid=null;this.power=null;this.events=[];
};
P.addObj=function(id,x,y,r,starter){var o={u:this.s.uid++,id:id,x:x,y:y,r:r|0};if(starter)o.st=1;if(isMach(id)){o.on=1;o.q=[];o.t=0;o.jam=0;o.out=null;}
  if(id==="table")o.tray=[];if(id==="tub")o.q=[];this.s.objs.push(o);this.dirtyGrid=true;this.power=null;return o;};
P.obj=function(u){for(var i=0;i<this.s.objs.length;i++)if(this.s.objs[i].u===u)return this.s.objs[i];return null;};
P.objsOf=function(id){return this.s.objs.filter(function(o){return o.id===id;});};
P.placed=function(id){for(var i=0;i<this.s.objs.length;i++)if(this.s.objs[i].id===id)return true;return false;};
P.up=function(id){return this.s.ups[id]|0;};
P.key=function(){return (this.s.owned.roomKey|0)>0;};
P.say=function(m){this.s.msg=m;this.s.msgT=this.s.t;};
P.emit=function(e){if(this.events.length<80)this.events.push(e);};
P.pot=function(u){var a=this.s.pots;for(var i=0;i<a.length;i++)if(a[i].u===u)return a[i];return null;};
P.newPot=function(k,mode){if(this.s.pots.length>=POT_CAP)return null;var p={u:this.s.uid++,k:k,d:1,sl:0,m:mode,x:0,y:0};this.s.pots.push(p);return p;};
P.killPot=function(p){var s=this.s,a=s.pots,i=a.indexOf(p);if(i<0)return;a.splice(i,1);
  /* 0.4.11 loop: every potato that leaves comes back raw down the return pipe onto the pile (the total stays the same) */
  if(s.pile+s.ret.length+this.inPlayRaw()<C.potTotal){if(s.ret.length<40)s.ret.push(s.t+0.7+this.rng()*0.8);else s.pile++;}};
P.inPlayRaw=function(){var n=0,a=this.s.pots;for(var i=0;i<a.length;i++)n++;return n;};
P.takeRaw=function(mode){var s=this.s;if(s.pile<=0)return null;var q=this.newPot(0,mode);if(q)s.pile--;return q;};
P.poolCount=function(){var n=0,a=this.s.pots;for(var i=0;i<a.length;i++)if(a[i].m==="pool"||a[i].m==="scan")n++;return n;};
/* the basin heap (0.4.11 look): a rising cone of layers next to where the X-ray drops them. Slot i of n -> {x,y,lift,t,r,ang,shade,bob} */
var HEAP={x:18.0,y:14.2,rx:1.05,ry:1.05};
function heapSlots(n){var out=[],i,t,j;if(n<=0)return out;
  var nL=n<=2?1:n<=5?2:n<=11?3:n<=20?4:n<=32?5:n<=48?6:7,w=[],sw=0,caps=[],acc=0;for(i=0;i<nL;i++){w.push(Math.pow(0.6,i));sw+=w[i];}
  for(i=0;i<nL;i++){var c=i===nL-1?n-acc:Math.max(1,Math.round(n*w[i]/sw));if(acc+c>n)c=n-acc;if(c>0){caps.push(c);acc+=c;}if(acc>=n)break;}
  var base=0.30+0.52*Math.min(1,n/44);
  for(t=0;t<caps.length;t++){var sc=1-t*0.14;for(j=0;j<caps[t];j++){var ang=(j+0.37)*2.399963+t*0.55,u=Math.sqrt((j+0.5)/Math.max(caps[t],1)),r=u*sc*base*(0.52+0.48*Math.min(1,caps[t]/16));
    var sh=0.70+0.22*t/Math.max(1,caps.length-1)+0.16*(-Math.cos(ang)*0.35-Math.sin(ang)*0.65);
    out.push({x:HEAP.x+Math.cos(ang)*HEAP.rx*r*1.6,y:HEAP.y+Math.sin(ang)*HEAP.ry*r*1.6,lift:t*0.105+(1-u)*0.025,t:t,r:u,ang:ang,shade:Math.max(0.58,Math.min(1.18,sh)),bob:t===0&&u>0.62});}}
  return out;}
P.grid=function(){
  if(!this.dirtyGrid&&this._grid)return this._grid;
  var occ=new Array(W*H),walk=new Uint8Array(W*H),rug=new Array(W*H),belt=new Array(W*H),x,y,i,o,f,a,b,key=this.key();
  for(y=0;y<H;y++)for(x=0;x<W;x++){i=y*W+x;var r=roomOf(x,y);walk[i]=(r==="k"||r==="w"||(r==="door"&&key))&&!fixedBlock(x,y)?1:0;}
  for(i=0;i<this.s.objs.length;i++){o=this.s.objs[i];if(o.wall)continue;var cat=(itemDef(o.id)||{}).cat;f=fp(o);
    for(a=f.x;a<f.x+f.w;a++)for(b=f.y;b<f.y+f.h;b++){if(a<0||b<0||a>=W||b>=H)continue;var j=b*W+a;if(cat==="rug"){rug[j]=o;continue;}if(o.id==="belt"){belt[j]=o;continue;}occ[j]=o;walk[j]=0;}}
  this._grid={occ:occ,walk:walk,rug:rug,belt:belt};this.dirtyGrid=false;return this._grid;
};
P.walkable=function(x,y){if(x<0||y<0||x>=W||y>=H)return false;return this.grid().walk[y*W+x]===1;};
/* Dijkstra, 8 directions, no corner cutting */
P.field=function(sx,sy,walkOverride){
  var g=walkOverride||this.grid().walk,N=W*H,dist=new Float64Array(N),prev=new Int32Array(N),i,heap=[];
  for(i=0;i<N;i++){dist[i]=1e9;prev[i]=-1;}
  if(sx<0||sy<0||sx>=W||sy>=H)return {dist:dist,prev:prev};
  function push(e){heap.push(e);var k=heap.length-1;while(k>0){var p=(k-1)>>1;if(heap[p][0]<=heap[k][0])break;var t=heap[p];heap[p]=heap[k];heap[k]=t;k=p;}}
  function pop(){var top=heap[0],last=heap.pop();if(heap.length){heap[0]=last;var k=0;for(;;){var l=2*k+1,r=l+1,m=k;if(l<heap.length&&heap[l][0]<heap[m][0])m=l;if(r<heap.length&&heap[r][0]<heap[m][0])m=r;if(m===k)break;var t=heap[m];heap[m]=heap[k];heap[k]=t;k=m;}}return top;}
  var s0=sy*W+sx;dist[s0]=0;push([0,s0]);
  while(heap.length){var e=pop(),c=e[1];if(e[0]>dist[c])continue;var cx=c%W,cy=(c/W)|0;
    for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;var nx=cx+dx,ny=cy+dy;if(nx<0||ny<0||nx>=W||ny>=H)continue;var n=ny*W+nx;if(!g[n])continue;
      if(dx&&dy&&(!g[cy*W+nx]||!g[ny*W+cx]))continue;var nd=dist[c]+(dx&&dy?1.414:1);if(nd<dist[n]){dist[n]=nd;prev[n]=c;push([nd,n]);}}}
  return {dist:dist,prev:prev};
};
P.papaTile=function(){var p=this.s.papa,x=Math.floor(p.x),y=Math.floor(p.y);if(!this.walkable(x,y)){var best=null,bd=1e9;for(var dy=-3;dy<=3;dy++)for(var dx=-3;dx<=3;dx++){if(this.walkable(x+dx,y+dy)){var d=dx*dx+dy*dy;if(d<bd){bd=d;best=[x+dx,y+dy];}}}if(best)return best;}return [x,y];};
P.sinkTile=function(t){var f=fp(t);if(t.r===0)return [f.x+f.w-1,f.y];if(t.r===1)return [f.x,f.y+f.h-1];if(t.r===2)return [f.x,f.y+f.h-1];return [f.x+f.w-1,f.y+f.h-1];};
P.spotsFor=function(t,sinkOnly){
  var s=this,list=[];
  if(t==="pile")list=around(FIX.pile);
  else if(t==="chute")list=[[6,1],[7,1]];
  else if(t==="scanK")list=[[11,14],[11,15]];
  else if(t==="canal"){CANAL_TILES.forEach(function(c){list.push([c[0]-1,c[1]],[c[0],c[1]-1]);});}
  else if(t&&typeof t==="object"){if(sinkOnly&&t.id==="table"){var sk=s.sinkTile(t);list=around({x:sk[0],y:sk[1],w:1,h:1});}else list=around(fp(t));}
  return list.filter(function(p){return s.walkable(p[0],p[1]);});
};
P.route=function(targets){
  var st=this.papaTile(),F=this.field(st[0],st[1]),best=null,bd=1e9,i;
  for(i=0;i<targets.length;i++){var t=targets[i],d=F.dist[t[1]*W+t[0]];if(d<bd){bd=d;best=t;}}
  if(!best||bd>=1e9)return null;
  var path=[],c=best[1]*W+best[0],s0=st[1]*W+st[0];while(c>=0&&c!==s0){path.push([c%W+0.5,((c/W)|0)+0.5]);c=F.prev[c];}path.reverse();
  return {path:path,spot:best,cost:bd};
};
/* ---------- power: the free wall outlet + generators. Each belt/machine takes the nearest source in range that still has load left ---------- */
P.sources=function(){var o=[{u:0,x:0.6,y:FIX.outlet.y+0.5,range:FIX.outlet.range,cap:FIX.outlet.cap,id:"outlet"}],g=this.up("gen");
  this.s.objs.forEach(function(b){if(b.id==="generator"){var f=fp(b);o.push({u:b.u,x:f.x+f.w/2,y:f.y+f.h/2,range:7+1.5*g,cap:12+8*g,id:"generator"});}});return o;};
P.calcPower=function(){
  var src=this.sources(),cons=[],map={};src.forEach(function(s){s.used=0;});
  this.s.objs.forEach(function(o){if(LOAD[o.id]){var f=fp(o);cons.push({o:o,x:f.x+f.w/2,y:f.y+f.h/2,load:LOAD[o.id]});}});
  cons.forEach(function(c){var best=null,bd=1e9;src.forEach(function(s){var d=Math.hypot(c.x-s.x,c.y-s.y);if(d<=s.range&&s.used+c.load<=s.cap&&d<bd){bd=d;best=s;}});
    if(best){best.used+=c.load;map[c.o.u]=best.u;}else map[c.o.u]=-1;});
  this.power={src:src,map:map};return this.power;
};
P.powered=function(o){if(!this.power)this.calcPower();var v=this.power.map[o.u];return v!=null&&v>=0;};
P.machAt=function(x,y){if(x<0||y<0||x>=W||y>=H)return null;return this.grid().occ[y*W+x]||null;};
P.beltAt=function(x,y){if(x<0||y<0||x>=W||y>=H)return null;return this.grid().belt[y*W+x]||null;};
/* can a potato moving in dir d enter tile (x,y)? */
P.accepts=function(p,x,y,d){
  var key=this.key(),b=this.beltAt(x,y);
  if(b){if((b.r+2)%4===d)return null;var n=0,minp=9;for(var i=0;i<this.s.pots.length;i++){var q=this.s.pots[i];if(q.m==="belt"&&q.o===b.u){n++;if(q.p<minp)minp=q.p;}}if(n>=3||minp<0.32)return null;return {k:"belt",o:b};}
  if(inRect(x,y,FIX.chute)&&d===3)return {k:"chute"};
  if(inRect(x,y,FIX.scanK)&&d===0)return key&&this.poolCount()<C.poolCap?{k:"scan"}:null;
  if(isWater(x,y))return key?{k:"water",x:x,y:y}:null;
  var o=this.machAt(x,y);if(!o)return null;
  if(o.id==="table"){if(p.k===0&&o.tray.length<6)return {k:"tray",o:o};return null;}
  if(o.id==="tub"){if(p.k===1&&o.q.length<8)return {k:"tub",o:o};return null;}
  if(isMach(o.id)){if(d!==o.r)return null;var cap=o.id==="hopper"?3:2;if(o.q.length>=cap)return null;
    if(o.id==="hopper"&&p.k!==0)return null;if(o.id==="autoPeeler"&&p.k!==0)return null;if(o.id==="washer"&&(p.k!==1||p.d<=0.15))return null;return {k:"mach",o:o};}
  return null;
};
P.give=function(p,a,d){
  if(a.k==="belt"){p.m="belt";p.o=a.o.u;p.p=0;p.ed=d;this.s.stats.beltMoved++;return;}
  if(a.k==="chute"){this.ship(p,"chute");return;}
  if(a.k==="scan"){this.toScanner(p);return;}
  if(a.k==="water"){this.toWater(p,a.x+0.5,a.y+0.5);return;}
  if(a.k==="tray"){p.m="tray";p.o=a.o.u;a.o.tray.push(p.u);return;}
  if(a.k==="tub"){p.m="tub";p.o=a.o.u;a.o.q.push(p.u);return;}
  if(a.k==="mach"){p.m="mach";p.o=a.o.u;a.o.q.push(p.u);return;}
};
P.frontOut=function(o){var f=fp(o),d=DIRS[o.r],cx,cy;
  if(o.r===0){cx=f.x+f.w;cy=f.y+Math.floor((f.h-1)/2);}else if(o.r===2){cx=f.x-1;cy=f.y+Math.floor((f.h-1)/2);}
  else if(o.r===1){cx=f.x+Math.floor((f.w-1)/2);cy=f.y+f.h;}else{cx=f.x+Math.floor((f.w-1)/2);cy=f.y-1;}
  return [cx,cy,o.r];};
P.touchesPile=function(o){var f=fp(o),Q=FIX.pile;var ox=Math.max(0,Math.min(f.x+f.w,Q.x+Q.w)-Math.max(f.x,Q.x)),oy=Math.max(0,Math.min(f.y+f.h,Q.y+Q.h)-Math.max(f.y,Q.y));
  var adjX=(f.x+f.w===Q.x||Q.x+Q.w===f.x)&&oy>0,adjY=(f.y+f.h===Q.y||Q.y+Q.h===f.y)&&ox>0;return adjX||adjY;};
/* ---------- economy ---------- */
P.potValue=function(p,via){var v=p.k===0?1:(p.d<=0.15?4:p.d<=0.55?3:2);if(via==="hole"&&p.k===1&&p.d<=0.15)v=5;if(p.sl)v=Math.max(1,v-1);return v;};
P.ship=function(p,via){var v=this.potValue(p,via);this.s.shipped++;if(p.k===1&&p.d<=0.15)this.s.shippedClean++;
  if(this.placed("neonSign")&&this.s.shipped%20===0){v+=1;this.s.tips++;}
  this.s.coins+=v;this.s.earned+=v;this.emit({e:"coin",v:v,via:via,x:via==="hole"?25.5:via==="chute"?7:p.x,y:via==="hole"?0.4:via==="chute"?0.8:p.y});this.killPot(p);};
P.toScanner=function(p){p.m="scan";p.t=0;p.x=12.4;p.y=15;};
P.toWater=function(p,x,y){var tx=Math.floor(x),ty=Math.floor(y);if(isCanal(tx,ty)){p.m="canal";p.c=this.canalProj(x,y);var q=this.canalPos(p.c);p.x=q.x;p.y=q.y;}
  else{p.m="pool";p.x=clamp(x,17.2,19.8);p.y=clamp(y,12.2,15.8);p.vx=0;p.vy=0;p.pt=this.s.t;}};
P.canalProj=function(x,y){if(y>=15)return clamp(x-20,0,5.5);return 5.5+clamp(15.5-y,0,15.45);};
P.canalPos=function(c){if(c<=5.5)return {x:20+c,y:15.5};return {x:25.5,y:15.5-(c-5.5)};};
P.cooCap=function(){return C.coolerBase+3*this.up("pantry")+(this.placed("smallCooler")?2:0)+(this.placed("shelf")?2:0);};
P.foodPrice=function(){return C.foodPrice-(this.placed("potsPans")?1:0);};
P.levelPrice=function(){var n=this.s.level+1;if(n>5)return 0;return Math.round(LEVEL_PRICE[n]*(this.placed("bookshelf")?0.9:1));};
P.itemPrice=function(id){var it=ITEMI[id];if(!it)return 0;if(it.stack&&it.cat!=="belt"){var n=this.s.owned[id]|0;return Math.round(it.price*Math.pow(1.5,n));}return it.price;};
P.buyLevel=function(){var pr=this.levelPrice();if(!pr)return {ok:false,why:"Max level"};if(this.s.coins<pr)return {ok:false,why:"Need "+pr+"c"};this.s.coins-=pr;this.s.level++;this.say("LEVEL "+this.s.level+"! New items in the SHOP.");return {ok:true};};
P.buyFood=function(n){n=Math.max(1,Math.min(20,Math.round(num(n,1))||1));var ok=0;for(var i=0;i<n;i++){if(this.s.food>=this.cooCap()||this.s.coins<this.foodPrice())break;this.s.coins-=this.foodPrice();this.s.food++;ok++;}return {ok:ok>0,n:ok,why:ok?"":(this.s.food>=this.cooCap()?"Cooler full":"Need "+this.foodPrice()+"c")};};
P.buyUp=function(id){var u=UPI[id];if(!u)return {ok:false,why:"no such"};var l=this.up(id);if(l>=u.max)return {ok:false,why:"Maxed"};if((u.lv||1)>this.s.level)return {ok:false,why:"Needs LV "+u.lv};var pr=u.prices[l];if(this.s.coins<pr)return {ok:false,why:"Need "+pr+"c"};this.s.coins-=pr;this.s.ups[id]=l+1;this.power=null;return {ok:true};};
P.buyItem=function(id,qty){var it=ITEMI[id];if(!it)return {ok:false,why:"no such"};if(it.lv>this.s.level)return {ok:false,why:"Needs LV "+it.lv};
  if(!it.stack&&(this.s.owned[id]|0)>0)return {ok:false,why:"Owned"};qty=it.cat==="belt"?Math.max(1,Math.min(20,Math.round(num(qty,1))||1)):1;var pr=this.itemPrice(id)*qty;if(this.s.coins<pr)return {ok:false,why:"Need "+pr+"c"};
  this.s.coins-=pr;this.s.owned[id]=(this.s.owned[id]|0)+qty;
  if(it.cat==="key"){this.dirtyGrid=true;this.say("The metal door is unlocked. The wash room is yours.");}
  else if(it.cat==="tool"){this.s.equip[id]=true;this.say(it.name+" is on Papa now (INV to take it off).");}
  else if(it.cat==="theme"){}
  else if(it.cat==="acc"){this.wear(id,true);this.s.papa.joy=60;this.s.papa.wantFlash=2;this.say(it.name+" for Papa! (INV to swap)");}
  else if(it.cat==="basin"){this.s.basin[id]=this.key();}
  else this.s.inv[id]=(this.s.inv[id]|0)+qty;
  return {ok:true};};
/* ---------- placement (free, but never blocking his way to anything) ---------- */
P.wallSlots=function(room){var o=[],x,y;if(room==="k"){for(x=0;x<14;x++)if(x!==6&&x!==7)o.push({wall:"N",x:x,y:0});for(y=0;y<24;y++)if(y!==FIX.outlet.y)o.push({wall:"W",x:0,y:y});}
  else for(x=15;x<25;x++)o.push({wall:"N",x:x,y:0});return o;};
P.wallCells=function(o){var w=itemDef(o.id).w||1,me=[];for(var i=0;i<w;i++)me.push(o.wall==="N"?[o.x+i,0]:[0,o.y+i]);return me;};
P.wallFree=function(o,skipU){var it=itemDef(o.id),i,j,me=this.wallCells(o);
  var slots=this.wallSlots(it.room==="w"?"w":"k");
  for(i=0;i<me.length;i++){var okk=false;for(j=0;j<slots.length;j++)if(slots[j].wall===o.wall&&slots[j].x===me[i][0]&&slots[j].y===me[i][1]){okk=true;break;}if(!okk)return false;}
  if(it.room==="w"&&!this.key())return false;
  for(i=0;i<this.s.objs.length;i++){var q=this.s.objs[i];if(q.u===skipU||!q.wall||q.wall!==o.wall)continue;var qc=this.wallCells(q);for(j=0;j<qc.length;j++)for(var k=0;k<me.length;k++)if(qc[j][0]===me[k][0]&&qc[j][1]===me[k][1])return false;}
  return true;};
P.wallSpot=function(id,x,y){/* nearest free wall cell to a floor tile */var it=itemDef(id),slots=this.wallSlots(it.room==="w"?"w":"k"),best=null,bd=1e9,me=this;
  slots.forEach(function(s){var o={id:id,wall:s.wall,x:s.x,y:s.y};if(!me.wallFree(o))return;var cx=s.wall==="N"?s.x+0.5:0,cy=s.wall==="N"?0:s.y+0.5,d=Math.hypot(cx-x,cy-y);if(d<bd){bd=d;best=o;}});return best;};
P.canPlace=function(id,x,y,r,skipU){
  var it=itemDef(id);if(!it)return {ok:false,why:"Unknown item"};
  if(it.cat==="wall")return {ok:false,why:"Wall item"};
  x=Math.round(num(x,-99));y=Math.round(num(y,-99));r=((Math.round(num(r,0))%4)+4)%4;
  var f=fp({id:id,x:x,y:y,r:r}),a,b,room=null,key=this.key();
  for(a=f.x;a<f.x+f.w;a++)for(b=f.y;b<f.y+f.h;b++){var rr=roomOf(a,b);if(rr!=="k"&&rr!=="w")return {ok:false,why:rr==="door"?"Keep the doorway clear":"Off the floor"};
    if(rr==="w"&&!key)return {ok:false,why:"The wash room is locked (ROOM KEY)"};if(room&&rr!==room)return {ok:false,why:"It can't straddle the wall"};room=rr;
    if(fixedBlock(a,b))return {ok:false,why:"That spot is taken (pile, chute, scanner or water)"};
    if((a===13||a===15)&&(b===3||b===4)&&it.cat!=="rug")return {ok:false,why:"Keep the doorway clear"};}
  if(it.room==="w"&&room!=="w")return {ok:false,why:"Wash room only"};if(it.room==="k"&&room!=="k")return {ok:false,why:"Kitchen only"};
  for(var i=0;i<this.s.objs.length;i++){var o=this.s.objs[i];if(o.u===skipU||o.wall)continue;var oc=(itemDef(o.id)||{}).cat,g2=fp(o);
    var hit=!(g2.x>=f.x+f.w||g2.x+g2.w<=f.x||g2.y>=f.y+f.h||g2.y+g2.h<=f.y);if(!hit)continue;
    if(it.cat==="rug"&&oc!=="rug")continue;if(oc==="rug"&&it.cat!=="rug")continue;
    return {ok:false,why:"It overlaps the "+(itemDef(o.id).name||o.id).toLowerCase()};}
  if(it.cat!=="rug"&&it.cat!=="belt"){
    var G=this.grid(),walk=new Uint8Array(G.walk);
    if(skipU){var so=this.obj(skipU);if(so&&!so.wall){var sf=fp(so);for(a=sf.x;a<sf.x+sf.w;a++)for(b=sf.y;b<sf.y+sf.h;b++){var rr2=roomOf(a,b);if((rr2==="k"||rr2==="w")&&!fixedBlock(a,b)&&!this.otherOcc(a,b,skipU))walk[b*W+a]=1;}}}
    for(a=f.x;a<f.x+f.w;a++)for(b=f.y;b<f.y+f.h;b++)walk[b*W+a]=0;
    var bad=this.unreachable(walk,{id:id,x:x,y:y,r:r,u:skipU||-1});if(bad)return {ok:false,why:"That would block his way to the "+bad};}
  return {ok:true};
};
P.otherOcc=function(a,b,skipU){for(var i=0;i<this.s.objs.length;i++){var o=this.s.objs[i];if(o.u===skipU||o.wall)continue;var c=(itemDef(o.id)||{}).cat;if(c==="rug"||o.id==="belt")continue;if(inRect(a,b,fp(o)))return true;}return false;};
P.unreachable=function(walk,cand){
  var key=this.key(),st=null,F,i,j;
  var p=this.papaTile();if(walk[p[1]*W+p[0]])st=p;
  if(!st){for(j=0;j<W*H&&!st;j++)if(walk[j]&&roomOf(j%W,(j/W)|0)==="k")st=[j%W,(j/W)|0];}
  if(!st)return "floor";
  F=this.field(st[0],st[1],walk);
  function ok(list){for(var k=0;k<list.length;k++){var t=list[k];if(t[0]>=0&&t[1]>=0&&t[0]<W&&t[1]<H&&walk[t[1]*W+t[0]]&&F.dist[t[1]*W+t[0]]<1e9)return true;}return false;}
  if(!ok(around(FIX.pile)))return "potato pile";
  if(!ok([[6,1],[7,1]]))return "chute";
  if(!ok([[11,14],[11,15]]))return "scanner";
  if(key&&!ok([[13,3],[13,4]]))return "door";
  if(key&&!ok([[15,3],[15,4]]))return "wash room";
  if(key&&!ok(this.spotsForWalk("canal",walk)))return "canal";
  var objs=this.s.objs.filter(function(o){return o.u!==cand.u;}).concat([cand]);
  for(i=0;i<objs.length;i++){var o=objs[i];if(o.wall||o.id==="belt")continue;var c=(itemDef(o.id)||{}).cat;if(c==="rug")continue;
    if(roomOf(o.x,o.y)==="w"&&!key)continue;if(!ok(around(fp(o))))return (itemDef(o.id).name||o.id).toLowerCase();}
  /* every floor tile must stay reachable too, so nothing ends up stranded behind furniture */
  for(j=0;j<W*H;j++){if(walk[j]&&F.dist[j]>=1e9){var rx=roomOf(j%W,(j/W)|0);if(rx==="k"||(rx==="w"&&key))return "far corner";}}
  return null;
};
P.spotsForWalk=function(t,walk){var list=[];CANAL_TILES.forEach(function(c){list.push([c[0]-1,c[1]],[c[0],c[1]-1]);});return list.filter(function(p){return p[0]>=0&&p[1]>=0&&walk[p[1]*W+p[0]];});};
P.place=function(id,x,y,r){
  var it=itemDef(id);if(!it||!ITEMI[id])return {ok:false,why:"Unknown"};
  if((this.s.inv[id]|0)<=0)return {ok:false,why:"None in INV"};
  if(it.cat==="wall"){var w=this.wallSpot(id,num(x,0),num(y,0));if(!w)return {ok:false,why:"No room left on the walls"};var o=this.addObj(id,w.x,w.y,0);o.wall=w.wall;this.s.inv[id]--;return {ok:true,o:o};}
  if(["floor","rug","belt","mach"].indexOf(it.cat)<0)return {ok:false,why:"Not placeable"};
  x=Math.round(num(x,-99));y=Math.round(num(y,-99));r=((Math.round(num(r,0))%4)+4)%4;
  var c=this.canPlace(id,x,y,r);if(!c.ok)return c;var o2=this.addObj(id,x,y,r);this.s.inv[id]--;this.afterEdit();return {ok:true,o:o2};
};
P.move=function(u,x,y,r){var o=this.obj(u);if(!o)return {ok:false,why:"gone"};
  if(o.wall){var w0={id:o.id,wall:o.wall,x:o.x,y:o.y};var w=null;var me=this;var keep=o.wall;o.wall="X";w=this.wallSpot(o.id,num(x,0),num(y,0));o.wall=keep;if(!w)return {ok:false,why:"No room on the walls"};o.wall=w.wall;o.x=w.x;o.y=w.y;return {ok:true};}
  x=Math.round(num(x,-99));y=Math.round(num(y,-99));r=((Math.round(num(r,o.r))%4)+4)%4;
  var c=this.canPlace(o.id,x,y,r,u);if(!c.ok)return c;o.x=x;o.y=y;o.r=r;this.afterEdit(o);return {ok:true};};
P.rotate=function(u){var o=this.obj(u);if(!o||o.wall)return {ok:false,why:"Wall items don't turn"};if(o.id==="belt"){o.r=(o.r+1)%4;this.dirtyGrid=true;return {ok:true};}
  for(var k=1;k<4;k++){var r=(o.r+k)%4;var c=this.canPlace(o.id,o.x,o.y,r,u);if(c.ok){o.r=r;this.afterEdit(o);return {ok:true};}}return {ok:false,why:"No room to turn it here"};};
P.store=function(u){var o=this.obj(u);if(!o)return {ok:false,why:"gone"};if(o.st)return {ok:false,why:"He needs the "+itemDef(o.id).name.toLowerCase()+": move it instead"};
  var me=this;me.s.pots.slice().forEach(function(p){if(p.o===o.u&&(p.m==="belt"||p.m==="mach"))me.dropLoose(p);});
  if(o.id==="catBed"){}
  this.s.objs.splice(this.s.objs.indexOf(o),1);this.s.inv[o.id]=(this.s.inv[o.id]|0)+1;this.afterEdit();return {ok:true};};
P.dropLoose=function(p){if(p.k===0)this.killPot(p);else this.ship(p,"chute");};
P.afterEdit=function(o){this.dirtyGrid=true;this.power=null;var p=this.s.papa;
  if(!this.walkable(Math.floor(p.x),Math.floor(p.y))&&!(p.task&&(p.task.lying||p.task.sit))){var t=this.papaTile();p.x=t[0]+0.5;p.y=t[1]+0.5;}
  if(p.task&&p.task.stage==="walk"){p.task=null;p.path=[];}
  if(p.task&&p.task.target&&p.task.target.u&&!this.obj(p.task.target.u)){if(p.task.ox!=null){p.x=p.task.ox;p.y=p.task.oy;}p.task=null;p.path=[];}
  if(p.task&&(p.task.lying||p.task.sit)&&o&&p.task.target===o){p.x=p.task.ox;p.y=p.task.oy;p.task=null;var t2=this.papaTile();p.x=t2[0]+0.5;p.y=t2[1]+0.5;}
  if(p.sack&&!p.sack.on&&!this.walkable(Math.floor(p.sack.x),Math.floor(p.sack.y))){var a=this.ringSpots(p.sack.x,p.sack.y,1.5);if(a.length){p.sack.x=a[0][0]+0.5;p.sack.y=a[0][1]+0.5;}else p.sack.on=true;}
};
/* ---------- effects ---------- */
P.onRug=function(id){var p=this.s.papa,g=this.grid(),x=Math.floor(p.x),y=Math.floor(p.y);if(x<0||y<0||x>=W||y>=H)return false;var r=g.rug[y*W+x];return !!(r&&r.id===id);};
P.shiftMin=function(){return (this.s.t*2+8*60)%1440;};
P.isDay=function(){var m=this.shiftMin();return m>=360&&m<1200;};
P.cups=function(){return Math.min(3,(this.s.level-1)+Math.floor(this.s.shipped/500));};
P.moodCalc=function(){var s=this.s,p=s.papa,m=50,n=0,me=this;DECOR_MOOD.forEach(function(id){if(me.placed(id))n++;});m+=Math.min(30,n*2);
  if(s.box.radio>0&&this.placed("radio"))m+=8;if(this.placed("plant")&&s.plant.dry<60)m+=4;if(s.decor.wall||s.decor.floor)m+=3;
  if(p.hunger<25)m-=15;if(p.energy<25)m-=15;if(p.hands<25)m-=8;if(s.peels.length>45)m-=10;if(p.joy>0)m+=10;if(s.want&&s.want.kind==="acc"&&s.t-s.want.t0>400)m-=4;return clamp(m,0,100);};
P.messSlow=function(){return Math.min(1,this.s.peels.length/90)*(this.placed("fan")?0.15:0.30);};
P.workMul=function(){var s=this.s,p=s.papa,m=SPD[s.box.pace]||1;if(p.mood>=80)m*=1.06;else if(p.mood>=60)m*=1.03;
  if(s.box.radio>0&&this.placed("radio"))m*=1.05;if(this.placed("window")&&this.isDay())m*=1.04;if(this.placed("stringLights")&&!this.isDay())m*=1.04;
  if(this.placed("statue"))m*=1.05;if(this.placed("trophyShelf"))m*=1+0.01*this.cups();
  if(p.lazy)m*=this.placed("poster")?0.7:C.lazySpeed;m*=1-this.messSlow();return m;};
P.walkMul=function(){var s=this.s,p=s.papa,m=(SPD[s.box.pace]||1)*(1+0.1*this.up("boots"));if(this.onRug("runner"))m*=1.15;if(p.where==="w"&&this.placed("mopBucket"))m*=1.1;
  if(p.lazy)m*=0.7;var x=Math.floor(p.x),y=Math.floor(p.y);if(x>=0&&y>=0&&x<W&&y<H&&this.grid().belt[y*W+x])m*=0.85;
  return m;};
P.carryCap=function(){return this.s.equip.carrySack?3+this.up("bag"):1;};
P.peelTime=function(){var s=this.s,t=C.peel*Math.pow(0.85,this.up("peeler"));if(s.equip.betterPeeler)t/=1.1;var st=STYLE[s.box.style]||STYLE[1],sp=st.sp;if(s.box.style===0&&this.placed("cookbook"))sp=0.9;t/=sp;
  if(s.box.lamp>0&&this.placed("lamp"))t/=1.08;if(this.onRug("roundRug"))t/=1.08;if(s.papa.hands<25)t*=1.15;return t/this.workMul();};
/* ---------- Papa's brain ---------- */
P.jammed=function(){return this.s.objs.filter(function(m){return !!m.jam;});};
P.mkTask=function(type,target,extra){var t={type:type,target:target,stage:"walk",t:0};if(extra)for(var k in extra)t[k]=extra[k];return t;};
P.startTask=function(t,spots){var p=this.s.papa;if(!spots||!spots.length)return false;var r=this.route(spots);if(!r)return false;p.task=t;p.path=r.path;t.spot=r.spot;t.stage=r.path.length?"walk":"act";t.t=0;return true;};
P.ringSpots=function(x,y,r){var o=[],a,b;for(a=Math.floor(x-r-1);a<=Math.floor(x+r+1);a++)for(b=Math.floor(y-r-1);b<=Math.floor(y+r+1);b++)if(this.walkable(a,b)&&Math.hypot(a+0.5-x,b+0.5-y)<=r+1.2)o.push([a,b]);
  o.sort(function(A,B){return Math.hypot(A[0]+0.5-x,A[1]+0.5-y)-Math.hypot(B[0]+0.5-x,B[1]+0.5-y);});return o;};
P.peelCluster=function(){var s=this.s,best=null,bn=-1,i,j,stp=Math.max(1,(s.peels.length/24)|0);for(i=0;i<s.peels.length;i+=stp){var a=s.peels[i],n=0;for(j=0;j<s.peels.length;j++){var b=s.peels[j];if(Math.abs(a.x-b.x)<1.4&&Math.abs(a.y-b.y)<1.4)n++;}if(n>bn){bn=n;best=a;}}return best?{x:best.x,y:best.y}:{x:6,y:12};};
P.decide=function(){
  var s=this.s,p=s.papa,b=s.box,me=this,i;
  p.task=null;p.path=[];
  var lazyAt=this.placed("photos")?20:C.lazyLow;p.lazy=p.hunger<lazyAt||p.energy<lazyAt;
  var ord=p.order;p.order=null;
  /* sack left by the bed: pick it back up once he is rested */
  if(p.sack&&!p.sack.on&&p.energy>=30){var sx=Math.floor(p.sack.x),sy=Math.floor(p.sack.y);var sp0=[[sx,sy]].concat(around({x:sx,y:sy,w:1,h:1})).filter(function(t){return me.walkable(t[0],t[1]);});
    if(this.startTask(this.mkTask("pickSack"),sp0))return;p.sack.on=true;}
  if(!s.equip.carrySack)p.sack.on=true;
  var beds=s.objs.filter(function(o){return o.id==="bed"||o.id==="basicCot";});
  if(p.energy<=0.5&&ord!=="eat"&&ord!=="nap"){if(!(b.nap>0)||!beds.length){p.task=this.mkTask("doze",null);p.task.stage="act";return;}}
  if(ord==="eat"||(b.eat>0&&p.hunger<b.eat&&s.food>0)){if(s.food>0){var cos=this.objsOf("cooler");for(i=0;i<cos.length;i++)if(this.startTask(this.mkTask("eat",cos[i]),this.spotsFor(cos[i])))return;}else if(ord==="eat")this.say("No food. Buy cans in the SHOP.");}
  if(ord==="nap"||(b.nap>0&&p.energy<b.nap)||(p.energy<=0.5&&beds.length)){var bb=null,bd=1e9;for(i=0;i<beds.length;i++){var r=this.route(this.spotsFor(beds[i]));if(r&&r.cost<bd){bd=r.cost;bb=beds[i];}}if(bb&&this.startTask(this.mkTask("nap",bb),this.spotsFor(bb)))return;}
  var jams=this.jammed();if(jams.length&&(b.fix>0||ord==="fix")){for(i=0;i<jams.length;i++)if(this.startTask(this.mkTask("fix",jams[i]),this.spotsFor(jams[i])))return;}
  else if(ord==="fix")this.say("No jams right now.");
  if((b.clean>0&&s.peels.length>b.clean)||ord==="clean"){if(s.peels.length){var c=this.peelCluster();if(this.startTask(this.mkTask("sweep",null,{cx:c.x,cy:c.y}),this.ringSpots(c.x,c.y,0.8)))return;}else if(ord==="clean")this.say("The floor is already clean.");}
  var tb=this.objsOf("table")[0];
  if(b.rinse>0&&p.hands<b.rinse&&tb){if(this.startTask(this.mkTask("rinse",tb,{sink:1}),this.spotsFor(tb,true)))return;}
  if(b.water>0&&this.placed("plant")&&s.plant.dry>b.water){var pl=this.objsOf("plant")[0];if(this.startTask(this.mkTask("water",pl),this.spotsFor(pl)))return;}
  if(b.watch>0&&b.tv>0&&this.placed("tvArmchair")&&p.energy<b.watch){var tv=this.objsOf("tvArmchair")[0];if(this.startTask(this.mkTask("watch",tv),this.spotsFor(tv)))return;}
  if(b.radio>0&&this.placed("radio")&&p.radioT<=0){p.radioT=80+this.rng()*40;var ra=this.objsOf("radio")[0];if(this.startTask(this.mkTask("tune",ra),this.spotsFor(ra)))return;}
  var key=this.key(),tub=this.objsOf("tub")[0];
  if(p.hold.length){var h0=this.pot(p.hold[0]);
    if(h0&&h0.k===0){if(b.wash>0&&this.placed("sink")&&!h0.w){var sk=this.objsOf("sink")[0];if(this.startTask(this.mkTask("washRaw",sk),this.spotsFor(sk)))return;}
      if(tb&&this.startTask(this.mkTask("peel",tb),this.spotsFor(tb)))return;}
    else if(h0&&h0.d<=0.15&&p.where==="w"&&key){if(this.startTask(this.mkTask("toss",null),this.spotsFor("canal")))return;}
    else if(h0&&h0.pl&&key){if(b.scrub>0&&tub&&tub.q.length+p.hold.length<=8&&this.startTask(this.mkTask("toTub",tub),this.spotsFor(tub)))return;
      if(this.startTask(this.mkTask("toss",null),this.spotsFor("canal")))return;}
    else{var dv=key?b.deliver:0;
      if(dv===2&&tub&&tub.q.length+p.hold.length<=8){if(this.startTask(this.mkTask("toTub",tub),this.spotsFor(tub)))return;}
      if(dv>=1&&this.startTask(this.mkTask("drop",null,{via:"scan"}),this.spotsFor("scanK")))return;
      if(this.startTask(this.mkTask("drop",null,{via:"chute"}),this.spotsFor("chute")))return;}
  }
  if(key&&b.scrub>0&&tub&&tub.q.length&&!p.hold.length){var dirty=false,clean=false;for(i=0;i<tub.q.length;i++){var q=this.pot(tub.q[i]);if(q&&q.d>0.15)dirty=true;else clean=true;}
    if(dirty&&this.startTask(this.mkTask("scrub",tub),this.spotsFor(tub)))return;
    if(clean&&!this.tubBeltOut(tub)&&this.startTask(this.mkTask("tubTake",tub),this.spotsFor(tub)))return;}
  if(key&&!p.hold.length&&b.pool>0){var pn=0;s.pots.forEach(function(q){if(q.m==="pool")pn++;});if(pn===0)s.poolRun=0;if(pn>=b.pool||(s.poolRun&&pn>0)){s.poolRun=1;var poolSp=around(FIX.pool).filter(function(t){return me.walkable(t[0],t[1]);});if(this.startTask(this.mkTask("poolTake",null),poolSp))return;}}
  if(!p.hold.length&&tb&&tb.tray.length){if(this.startTask(this.mkTask("trayTake",tb),this.spotsFor(tb)))return;}
  if(!p.hold.length){if(this.startTask(this.mkTask("grab",null),this.spotsFor("pile")))return;}
  p.task=this.mkTask("idle",null);p.task.stage="act";
};
P.tubBeltOut=function(tub){var f=this.frontOut(tub);return !!this.beltAt(f[0],f[1]);};
P.facePt=function(x,y){var p=this.s.papa,dx=x-p.x,dy=y-p.y;if(Math.abs(dx)+Math.abs(dy)<0.01)return;p.fx=dx;p.fy=dy;p.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?0:2):(dy>0?1:3);};
P.tgtCenter=function(t){var o=t.target;if(t.sink&&o){var sk=this.sinkTile(o);return [sk[0]+0.5,sk[1]+0.5];}if(o&&o.x!=null){var f=fp(o);return [f.x+f.w/2,f.y+f.h/2];}
  if(t.type==="grab")return [3.5,21];if(t.type==="drop")return t.via==="chute"?[7,0.5]:[12.5,15];if(t.type==="sweep")return [t.cx,t.cy];
  if(t.type==="toss"&&t.spot){for(var k=0;k<4;k++){var a=t.spot[0]+DIRS[k][0],b=t.spot[1]+DIRS[k][1];if(isCanal(a,b))return [a+0.5,b+0.5];}}
  if(t.type==="pickSack")return [this.s.papa.sack.x,this.s.papa.sack.y];
  if(t.type==="poolTake")return [HEAP.x,HEAP.y];
  return [this.s.papa.x+this.s.papa.fx,this.s.papa.y+this.s.papa.fy];};
P.sackDown=function(){var p=this.s.papa;if(!this.s.equip.carrySack||!p.sack.on)return false;
  var t=this.papaTile(),best=null;var D8=[[1,0],[0,1],[-1,0],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];var g=this.grid(),bs=99,me=this;function occ(x,y){return x>=0&&y>=0&&x<W&&y<H&&!!g.occ[y*W+x];}
  /* a free tile beside him, preferring one nothing tall stands in front of, so you can see the sack */
  for(var k=0;k<8;k++){var a=t[0]+D8[k][0],b=t[1]+D8[k][1];if(this.walkable(a,b)&&roomOf(a,b)===roomOf(t[0],t[1])){var sc=(occ(a+1,b)?1:0)+(occ(a,b+1)?1:0)+(occ(a+1,b+1)?1:0);if(sc<bs){bs=sc;best=[a,b];}}}
  if(!best)best=t;p.sack.on=false;p.sack.x=best[0]+0.5;p.sack.y=best[1]+0.5;this.s.stats.sackDowns++;this.emit({e:"sackDown"});return true;};
P.addPeel=function(x,y){var s=this.s;if(s.peels.length>=PEEL_CAP)s.peels.shift();var tx=Math.floor(x),ty=Math.floor(y);
  if(!(roomOf(tx,ty)==="k"||roomOf(tx,ty)==="w")||fixedBlock(tx,ty)){var a=this.ringSpots(x,y,1);if(!a.length)return;x=a[0][0]+0.2+this.rng()*0.6;y=a[0][1]+0.2+this.rng()*0.6;}
  s.peels.push({x:Math.round(x*1000)/1000,y:Math.round(y*1000)/1000,a:Math.floor(this.rng()*6),c:Math.floor(this.rng()*3)});};
P.stepPapa=function(dt){
  var s=this.s,p=s.papa,b=s.box,me=this;
  var dr=DRN[b.pace]||1,t0=p.task,rest=t0&&t0.stage==="act"&&(t0.type==="nap"&&t0.lying||t0.type==="doze"||t0.type==="watch");
  var hd=C.hungerDrain*dr;if(rest)hd=C.hungerNap;if(this.onRug("rug"))hd*=0.8;if(this.placed("fruitBowl")&&p.where==="k")hd*=0.9;if(this.placed("aquarium"))hd*=0.95;
  var ed=C.energyDrain*dr;if(this.onRug("kitchenMat"))ed*=0.7;if(this.placed("plant")&&s.plant.dry<60&&p.where==="k")ed*=0.9;if(b.radio>0&&this.placed("radio"))ed*=p.where==="w"?0.9:0.8;if(p.where==="w"&&this.placed("towelRack"))ed*=0.85;if(this.placed("aquarium"))ed*=0.95;
  p.hunger=clamp(p.hunger-hd*dt,0,130);if(!rest)p.energy=clamp(p.energy-ed*dt,0,100);
  if(p.hunger>100)p.hunger=Math.max(100,p.hunger-3*dt);
  p.mood=this.moodCalc();p.radioT-=dt;
  var room=roomOf(Math.floor(p.x),Math.floor(p.y));if((room==="k"||room==="w")&&room!==p.where){if(room==="w")s.stats.doorTrips++;p.where=room;}
  if(!p.task)this.decide();
  var t=p.task;if(!t)return;
  if(t.stage==="walk"){
    if(!p.path.length){t.stage="act";t.t=0;}
    else{var n=p.path[0],dx=n[0]-p.x,dy=n[1]-p.y,d=Math.hypot(dx,dy),wm0=this.walkMul(),v=C.walk*wm0*dt;p.moving=true;p.walkT+=dt*wm0;
      if(!this.walkable(Math.floor(n[0]),Math.floor(n[1]))){p.task=null;p.path=[];p.moving=false;return;}
      if(d<=v){p.x=n[0];p.y=n[1];p.path.shift();}else{p.x+=dx/d*v;p.y+=dy/d*v;}
      this.facePt(n[0],n[1]);
      if(!p.path.length){t.stage="act";t.t=0;p.moving=false;var c=this.tgtCenter(t);this.facePt(c[0],c[1]);}
    }
    return;
  }
  p.moving=false;
  var c0=this.tgtCenter(t);if(["doze","idle","nap","watch"].indexOf(t.type)<0)this.facePt(c0[0],c0[1]);
  t.t+=dt;var wm=this.workMul(),rr=this.onRug("roundRug")?1.08:1;
  switch(t.type){
    case "idle":if(t.t>0.6)p.task=null;break;
    case "doze":if(!t.sd){t.sd=1;this.sackDown();}p.energy=clamp(p.energy+C.dozeRegen*dt,0,100);if(p.energy>=60)p.task=null;break;
    case "grab":{var cap=this.carryCap(),gt=C.grab*(this.placed("sackPile")?0.8:1)/wm/rr;
      if(t.t>=gt){t.t=0;if(s.pile<=0){if(!p.hold.length)this.say("The raw pile is empty: potatoes come back down the return pipe as you ship them.");p.task=null;break;}
        var q=this.takeRaw("held");if(!q){this.say("Too many potatoes in play: let the belts drain.");p.task=null;break;}p.hold.push(q.u);this.emit({e:"grab"});if(p.hold.length>=cap)p.task=null;}break;}
    case "trayTake":{var tb=t.target;if(t.t>=C.grab*0.6/wm){t.t=0;if(tb.tray.length&&p.hold.length<this.carryCap()){var u=tb.tray.shift(),q2=this.pot(u);if(q2){q2.m="held";p.hold.push(u);}}else p.task=null;}break;}
    case "washRaw":{if(t.t>=1.4/wm){p.hold.forEach(function(u){var q=me.pot(u);if(q&&q.k===0)q.w=1;});s.stats.washed++;this.emit({e:"splash",x:c0[0],y:c0[1]});p.task=null;}break;}
    case "peel":{var q3=null,qi=-1;for(var k1=0;k1<p.hold.length;k1++){var z0=this.pot(p.hold[k1]);if(z0&&z0.k===0){q3=z0;qi=k1;break;}}
      if(!q3){p.task=null;break;}t.cur=q3.u;t.prog=(t.prog||0)+dt/this.peelTime();
      var st=STYLE[b.style]||STYLE[1],np=st.peels;if(b.style===2&&this.placed("coatHook"))np=4;if(p.lazy)np+=1;
      var want=Math.min(np,Math.floor(t.prog*np));while((t.em|0)<want){t.em=(t.em|0)+1;this.addPeel(c0[0]+(p.x-c0[0])*0.9+(this.rng()-0.5)*1.4,c0[1]+(p.y-c0[1])*0.9+(this.rng()-0.5)*1.4);}
      if(t.prog>=1){q3.k=1;q3.d=q3.w?0.5:1;q3.sl=p.lazy?1:0;p.hands=clamp(p.hands-6,0,100);s.stats.peeled++;this.emit({e:"peeled",x:c0[0],y:c0[1]});t.prog=0;t.em=0;
        var more=p.hold.some(function(u){var z=me.pot(u);return z&&z.k===0;});if(!more||(b.rinse>0&&p.hands<b.rinse))p.task=null;}
      break;}
    case "drop":{if(t.t>=C.drop/wm/rr){t.t=0;var u3=p.hold.shift(),q4=this.pot(u3);if(q4){if(t.via==="scan"&&this.key()&&this.poolCount()<C.poolCap)this.toScanner(q4);else this.ship(q4,"chute");}if(!p.hold.length)p.task=null;}break;}
    case "toTub":{var tub=t.target;if(t.t>=C.drop/wm){t.t=0;var u4=p.hold[0],q5=this.pot(u4);if(q5&&tub.q.length<8){p.hold.shift();q5.m="tub";q5.o=tub.u;tub.q.push(u4);}else p.task=null;if(!p.hold.length)p.task=null;}break;}
    case "scrub":{var tub2=t.target,pr=null;for(var i2=0;i2<tub2.q.length;i2++){var z=this.pot(tub2.q[i2]);if(z&&z.d>0.15){pr=z;break;}}
      if(!pr){p.task=null;break;}t.cur=pr.u;pr.d=Math.max(0,pr.d-C.scrubRate*(1+0.4*this.up("brush"))*wm*dt);if(this.rng()<0.25)this.emit({e:"foam",x:pr.x,y:pr.y});if(pr.d<=0.15)s.stats.scrubbed++;break;}
    case "tubTake":{var tub3=t.target;if(t.t>=C.grab*0.6/wm){t.t=0;var idx=-1;for(var i3=0;i3<tub3.q.length;i3++){var z2=this.pot(tub3.q[i3]);if(z2&&z2.d<=0.15){idx=i3;break;}}
      if(idx>=0&&p.hold.length<this.carryCap()){var u5=tub3.q.splice(idx,1)[0],z3=this.pot(u5);if(z3){z3.m="held";p.hold.push(u5);}}else p.task=null;}break;}
    case "toss":{if(t.t>=C.drop/wm){t.t=0;var u6=p.hold.shift(),z4=this.pot(u6);if(z4){this.toWater(z4,c0[0],c0[1]);this.emit({e:"splash",x:c0[0],y:c0[1]});}if(!p.hold.length)p.task=null;}break;}
    case "eat":{var et=C.eat*(this.placed("clock")?0.7:1);if(t.t>=et){if(s.food>0){s.food--;p.hunger=Math.min(100,p.hunger+(this.placed("spiceRack")?65:55));this.emit({e:"eat"});}p.task=null;}break;}
    case "nap":{if(!t.lying){if(!t.sd){t.sd=1;if(this.sackDown()){t.t=0;}}if(t.t>=0.5){t.lying=1;var bf=fp(t.target);t.ox=p.x;t.oy=p.y;p.x=bf.x+bf.w/2;p.y=bf.y+bf.h/2;}break;}
      var rg=C.napRegen*Math.pow(1.35,this.up("bed"))*(this.placed("catBed")?1.1:1);p.energy=clamp(p.energy+rg*dt,0,100);
      var wk=b.nap>0?Math.max(b.wake,b.nap+5):100;if(p.energy>=Math.min(100,wk)-0.01){p.x=t.ox;p.y=t.oy;p.task=null;}break;}
    case "watch":{if(!t.sit){t.sit=1;t.ox=p.x;t.oy=p.y;var tf=fp(t.target);p.x=tf.x+tf.w*0.5;p.y=tf.y+tf.h*0.75;}
      p.energy=clamp(p.energy+C.tvRegen*dt,0,100);if(p.energy>=Math.min(100,(b.watch||0)+30)||b.tv<=0){p.x=t.ox;p.y=t.oy;p.task=null;}break;}
    case "rinse":{if(t.t>=C.rinse/wm){p.hands=100;this.emit({e:"splash",x:c0[0],y:c0[1]});p.task=null;}break;}
    case "water":{if(t.t>=1.5){s.plant.dry=0;p.task=null;}break;}
    case "tune":{if(t.t>=1.6)p.task=null;break;}
    case "fix":{var m=t.target;if(!m||!m.jam||!this.obj(m.u)){p.task=null;break;}if(t.t>=C.fixT*Math.pow(0.7,this.up("mach"))/Math.max(0.6,wm)){m.jam=0;m.t=0;s.stats.fixed++;this.emit({e:"fixed",x:c0[0],y:c0[1]});this.say("Jam cleared on the "+itemDef(m.id).name.toLowerCase()+".");p.task=null;}break;}
    case "sweep":{var rate=C.sweepRate*(s.equip.broomDustpan?1:0.5)*Math.pow(1.5,this.up("broom"))*(this.placed("compost")?1.25:1)*(this.placed("mopBucket")?1.25:1)*wm*dt;t.acc=(t.acc||0)+rate;
      while(t.acc>=1&&p.task){t.acc-=1;var bi=-1,bd2=9;for(var i4=0;i4<s.peels.length;i4++){var pe=s.peels[i4],dd=Math.hypot(pe.x-t.cx,pe.y-t.cy);if(dd<bd2){bd2=dd;bi=i4;}}
        if(bi<0||bd2>2.4){p.task=null;break;}s.peels.splice(bi,1);s.swept++;if(this.placed("compost")){s.compostAcc++;if(s.compostAcc>=20){s.compostAcc=0;s.coins++;s.earned++;}}}
      if(p.task&&(!s.peels.length||(b.clean>0&&s.peels.length<=Math.floor(b.clean*0.1))))p.task=null;
      if(p.task&&t.t>40)p.task=null;break;}
    case "poolTake":{if(t.t>=C.grab*0.6/wm){t.t=0;var best=null;for(var i5=0;i5<s.pots.length;i5++){var z5=s.pots[i5];if(z5.m==="pool"&&(!best||(z5.hl||0)>(best.hl||0)))best=z5;}
      if(best&&p.hold.length<this.carryCap()){best.m="held";best.pl=1;p.hold.push(best.u);this.emit({e:"splash",x:best.x,y:best.y});if(p.hold.length===1)s.stats.poolRuns++;}else p.task=null;if(p.task&&p.hold.length>=this.carryCap())p.task=null;}break;}
    case "pickSack":{if(t.t>=0.5){p.sack.on=true;p.task=null;}break;}
    default:p.task=null;
  }
};
/* ---------- machines, belts, water ---------- */
P.stepMachines=function(dt){
  var s=this.s,me=this,ms=SPEEDV[s.box.mspeed]||0,bs=(SPEEDV[s.box.belts]||0)*(1+0.15*this.up("belts"))*1.3;
  if(!this.power)this.calcPower();
  s.objs.forEach(function(o){
    if(!isMach(o.id))return;o.pw=me.powered(o)?1:0;
    if(o.out!=null&&!me.pot(o.out))o.out=null;
    if(!o.on||!o.pw||o.jam||ms<=0){o.run=0;return;}
    var jamP=C.jam*(s.box.mspeed===3?2:s.box.mspeed===1?0.5:1)*Math.pow(0.7,me.up("mach"));
    if(o.out!=null){var q=me.pot(o.out),f=me.frontOut(o),a=me.accepts(q,f[0],f[1],f[2]);if(a){me.give(q,a,f[2]);o.out=null;}else{o.run=0;o.blocked=1;return;}}
    o.blocked=0;
    if(o.id==="hopper"){o.t+=dt*ms;var need=1.6;o.run=1;
      if(o.t>=need){var srcP=null;if(o.q.length)srcP=me.pot(o.q.shift());else if(me.touchesPile(o))srcP=me.takeRaw("mach");
        if(srcP){o.t=0;srcP.m="mach";srcP.o=o.u;o.out=srcP.u;o.fed=(o.fed|0)+1;if(me.rng()<jamP){o.jam=1;s.stats.jams++;s.lastJam=o.u;me.say("JAM! The hopper is stuck. He'll come fix it (FIX JAMS).");}}else{o.t=need;o.run=0;}}
      return;}
    if(!o.q.length){o.t=0;o.run=0;return;}o.run=1;var prev=o.t;o.t+=dt*ms;var need2=o.id==="autoPeeler"?3.0:3.6;
    if(o.id==="autoPeeler"&&Math.floor(o.t*1.5)!==Math.floor(prev*1.5)){var f2=me.frontOut(o);me.addPeel(f2[0]+0.5+(me.rng()-0.5)*1.6,f2[1]+0.5+(me.rng()-0.5)*1.6);}
    if(o.t>=need2){o.t=0;var q2=me.pot(o.q.shift());if(q2){if(o.id==="autoPeeler"){q2.k=1;q2.d=1;s.stats.machPeeled++;}else{q2.d=0;s.stats.drumWashed++;}o.out=q2.u;o.done=(o.done|0)+1;
      if(me.rng()<jamP){o.jam=1;s.stats.jams++;s.lastJam=o.u;me.say("JAM! The "+itemDef(o.id).name.toLowerCase()+" is stuck. He'll come fix it (FIX JAMS).");}}}
  });
  s.objs.forEach(function(o){if(o.id!=="tub"||!o.q.length)return;var f=me.frontOut(o),bl=me.beltAt(f[0],f[1]);if(!bl)return;
    for(var i=0;i<o.q.length;i++){var q=me.pot(o.q[i]);if(q&&q.d<=0.15){var a=me.accepts(q,f[0],f[1],f[2]);if(a){o.q.splice(i,1);me.give(q,a,f[2]);}break;}}});
  var byBelt={};s.pots.forEach(function(p){if(p.m==="belt")(byBelt[p.o]||(byBelt[p.o]=[])).push(p);});
  s.objs.forEach(function(bl){if(bl.id!=="belt")return;bl.pw=me.powered(bl)?1:0;var L=byBelt[bl.u];if(!L||!bl.pw||bs<=0)return;L.sort(function(a,c){return c.p-a.p||a.u-c.u;});
    var ahead=9;for(var i=0;i<L.length;i++){var p=L[i],np=p.p+bs*dt;
      if(i===0&&np>=1){var nx=bl.x+DIRS[bl.r][0],ny=bl.y+DIRS[bl.r][1],a=me.accepts(p,nx,ny,bl.r);if(a){me.give(p,a,bl.r);continue;}np=1;}
      if(np>ahead-0.33)np=Math.max(p.p,ahead-0.33);p.p=np;ahead=p.p;}});
  /* the X-ray pass-through */
  s.pots.forEach(function(p){if(p.m==="scan"){p.t+=dt;if(p.t>=1.2){me.toWater(p,17.4,14.4+me.rng()*1.2);p.vx=0.15;me.emit({e:"splash",x:17.4,y:15});}}});
  var ch=this.up("channel"),pull=(0.35+0.5*ch)*(s.basin.duck?1.25:1),flow=([0.55,1.0,1.7][ch]||0.55)*(s.basin.toyBoat?1.15:1),soakM=(this.placed("soap")?1.15:1)*(s.basin.bubbles?1.5:1);
  var canal=s.pots.filter(function(p){return p.m==="canal";}).sort(function(a,c){return c.c-a.c||a.u-c.u;}),ahead2=99,canalTail=99;
  canal.forEach(function(p){var nc=p.c+flow*dt;if(nc>ahead2-0.3)nc=Math.max(p.c,ahead2-0.3);p.c=nc;ahead2=p.c;var pos=me.canalPos(p.c);p.x=pos.x;p.y=pos.y;
    if(p.k===1)p.d=Math.max(0,p.d-C.soakCanal*soakM*dt);
    if(p.c>=CANAL_LEN-0.05){me.ship(p,"hole");ahead2=99;}else canalTail=Math.min(canalTail,p.c);});
  /* the pool: peeled potatoes gather in a heap by the X-ray and wait there until Papa comes for them (EMPTY POOL AT) */
  if(canalTail<0)canalTail=0;
};
P.stepCat=function(dt){var s=this.s,c=s.cat;if(!this.placed("catBed"))return;var bed=this.objsOf("catBed")[0],bf=fp(bed);c.t-=dt;
  if(c.st==="walk"){var dx=c.tx-c.x,dy=c.ty-c.y,d=Math.hypot(dx,dy);if(d<0.05){var atBed=Math.hypot(c.x-bf.x-0.5,c.y-bf.y-0.5)<0.2;c.st=atBed?"nap":"sit";c.t=atBed?8+this.rng()*8:2+this.rng()*4;}
    else{var v=Math.min(d,1.3*dt);c.x+=dx/d*v;c.y+=dy/d*v;c.fx=dx;c.fy=dy;}}
  else if(c.t<=0){var tx,ty,tries=0;if(this.rng()<0.3){tx=bf.x+0.5;ty=bf.y+0.5;}else{do{tx=1+Math.floor(this.rng()*12)+0.5;ty=1+Math.floor(this.rng()*17)+0.5;tries++;}while(tries<12&&!this.walkable(Math.floor(tx),Math.floor(ty)));if(tries>=12){c.t=1;return;}}
    c.tx=tx;c.ty=ty;c.st="walk";}};
P.step=function(dt){
  var s=this.s;dt=dt||DT;s.t+=dt;s.tick++;
  if(s.box.autob>0)while(s.food<s.box.autob&&s.food<this.cooCap()&&s.coins>=this.foodPrice()){s.coins-=this.foodPrice();s.food++;}
  var day=Math.floor((s.t*2+8*60)/1440);if(this.placed("calendar")&&day>s.lastPayDay){s.coins+=10;s.earned+=10;this.say("PAYDAY +10c (calendar).");}s.lastPayDay=Math.max(s.lastPayDay,day);
  if(this.placed("plant"))s.plant.dry=Math.min(100,s.plant.dry+dt/6);
  if(s.ret.length){var n0=s.ret.length;s.ret=s.ret.filter(function(t){return t>s.t;});if(s.ret.length<n0){s.pile+=n0-s.ret.length;this.emit({e:"land",n:n0-s.ret.length});}}
  this.stepWant(dt);
  this.stepPapa(dt);this.stepMachines(dt);this.stepCat(dt);this.layout();
};
/* ---------- Papa's wants: food when he's hungry, and little things he'd like (hats, shades, a bow tie, a cat toy) ---------- */
var ACC_HAT={partyHat:"party",beanie:"beanie",topHat:"top"};
P.wantables=function(){var s=this.s,me=this;return ITEMS.filter(function(it){return it.cat==="acc"&&!(s.owned[it.id]|0)&&it.lv<=Math.max(s.level,2)&&(it.id!=="catToy"||me.placed("catBed"));});};
P.pickWant=function(rng){var s=this.s,p=s.papa;rng=rng||this.rng;
  if(p.hunger<45&&s.food<=1)return {id:"snack",kind:"food",name:"A SNACK",price:this.foodPrice(),t0:s.t};
  var L=this.wantables();if(!L.length||rng()<0.25)return p.hunger<70?{id:"snack",kind:"food",name:"A SNACK",price:this.foodPrice(),t0:s.t}:null;
  var it=L[Math.floor(rng()*L.length)];return {id:it.id,kind:"acc",name:it.name,price:it.price,t0:s.t};};
P.stepWant=function(dt){var s=this.s,p=s.papa;if(p.joy>0)p.joy=Math.max(0,p.joy-dt);if(p.wantFlash>0)p.wantFlash=Math.max(0,p.wantFlash-dt);
  var w=s.want;if(w&&w.kind==="food"&&(s.food>=2||p.hunger>85)){s.want=null;s.wantT=120+this.rng()*120;w=null;}
  if(w&&w.kind==="acc"&&(s.owned[w.id]|0)>0){s.want=null;s.wantT=200;w=null;}
  if(!w){s.wantT-=dt;if(s.wantT<=0){s.want=this.pickWant();s.wantT=s.want?0:240;}}};
/* you (or Papa himself, in AUTO MODE) get him what he wants */
P.giveWant=function(fromPapa){var s=this.s,w=s.want;if(!w)return {ok:false,why:"He doesn't want anything right now"};if(s.coins<w.price)return {ok:false,why:"Need "+w.price+"c"};
  if(w.kind==="food"){if(s.food>=this.cooCap())return {ok:false,why:"Cooler full"};s.coins-=w.price;s.food++;}
  else{s.coins-=w.price;s.owned[w.id]=(s.owned[w.id]|0)+1;this.wear(w.id,true);}
  s.papa.joy=90;s.papa.wantFlash=3;s.stats.wantsMet++;s.want=null;s.wantT=240+this.rng()*240;this.emit({e:"want",id:w.id});
  if(!fromPapa)this.say("Papa loves it: "+w.name.toLowerCase()+"! (mood up)");return {ok:true,w:w};};
P.wear=function(id,on){var it=ITEMI[id],a=this.s.acc;if(!it||it.cat!=="acc"||!(this.s.owned[id]|0))return false;
  if(it.slot==="hat")a.hat=on?ACC_HAT[id]:"chef";else if(it.slot==="glasses")a.glasses=on?1:0;else if(it.slot==="bow")a.bow=on?1:0;else if(it.slot==="toy")a.toy=on?1:0;return true;};
P.wearing=function(id){var it=ITEMI[id],a=this.s.acc;if(!it||it.cat!=="acc")return false;if(it.slot==="hat")return a.hat===ACC_HAT[id];return !!a[it.slot];};
/* the player's finger brushing potatoes in the wash room */
P.brush=function(x,y,str){var s=this.s,hit=0,r=0.5;x=num(x,-9);y=num(y,-9);str=clamp(num(str,0.2),0,1)*(1+0.4*this.up("brush"));
  this.layout();s.pots.forEach(function(p){if(p.k!==1||p.d<=0)return;if((p.m==="pool"||p.m==="canal"||p.m==="tub")&&Math.hypot(p.x-x,p.y-y)<r){var was=p.d;p.d=Math.max(0,p.d-str);if(was>0.15&&p.d<=0.15)s.stats.brushed++;hit++;}});
  if(hit)this.emit({e:"foam",x:x,y:y});return hit;};
/* world positions of potatoes that live inside things */
P.layout=function(){var me=this,s=this.s;
  s.objs.forEach(function(o){var f;if(o.id==="tub"){f=fp(o);o.q.forEach(function(u,i){var p=me.pot(u);if(!p)return;var col=i%4,row=(i/4)|0;
      if(f.w>=f.h){p.x=f.x+0.3+col*(f.w-0.6)/3;p.y=f.y+0.35+row*0.3;}else{p.x=f.x+0.35+row*0.3;p.y=f.y+0.3+col*(f.h-0.6)/3;}});}
    else if(o.id==="table"){f=fp(o);o.tray.forEach(function(u,i){var p=me.pot(u);if(p){p.x=f.x+0.35+(i%3)*0.28;p.y=f.y+0.3+((i/3)|0)*0.28;}});}});
  s.pots.forEach(function(p){if(p.m==="belt"){var bl=me.obj(p.o);if(!bl)return;var cx=bl.x+0.5,cy=bl.y+0.5,ed=DIRS[p.ed==null?bl.r:p.ed],xd=DIRS[bl.r];
      if(p.p<0.5){var k=p.p/0.5;p.x=cx-ed[0]*0.5*(1-k);p.y=cy-ed[1]*0.5*(1-k);}else{var k2=(p.p-0.5)/0.5;p.x=cx+xd[0]*0.5*k2;p.y=cy+xd[1]*0.5*k2;}}
    else if(p.m==="mach"){var m=me.obj(p.o);if(m){var f2=fp(m);p.x=f2.x+f2.w/2;p.y=f2.y+f2.h/2;}}
    else if(p.m==="held"){p.x=s.papa.x;p.y=s.papa.y;}});
  var pool=s.pots.filter(function(p){return p.m==="pool";});if(pool.length){var sl=heapSlots(pool.length);pool.sort(function(a,b){return (a.pt||0)-(b.pt||0)||a.u-b.u;});pool.forEach(function(p,i){p.x=sl[i].x;p.y=sl[i].y;p.hl=sl[i].lift;});}};
P.order=function(o){var p=this.s.papa;if(["eat","nap","clean","fix","work"].indexOf(o)<0)return false;
  if(p.task&&p.task.ox!=null&&(p.task.lying||p.task.sit)){p.x=p.task.ox;p.y=p.task.oy;}p.order=o==="work"?null:o;p.task=null;p.path=[];return true;};
P.setBox=function(id,v){var c=BOX[id];if(!c)return false;v=num(v,NaN);if(!isFinite(v))return false;v=Math.round(v/c.step)*c.step;this.s.box[id]=clamp(v,c.min,c.max);return true;};
P.equip=function(id,on){if(ITEMI[id]&&ITEMI[id].cat==="tool"&&(this.s.owned[id]|0)>0){this.s.equip[id]=!!on;var p=this.s.papa;
  if(id==="carrySack"&&!on){while(p.hold.length>1){var q=this.pot(p.hold.pop());if(q)this.dropLoose(q);}p.sack.on=true;}return true;}return false;};
P.setBasin=function(id,on){if(ITEMI[id]&&ITEMI[id].cat==="basin"&&(this.s.owned[id]|0)>0&&this.key()){this.s.basin[id]=!!on;return true;}return false;};
P.setTheme=function(k,v){v=Math.round(num(v,0));if(k==="wall"&&(this.s.owned.wallpaper|0)>0){this.s.decor.wall=clamp(v,0,3);return true;}if(k==="floor"&&(this.s.owned.floorTiles|0)>0){this.s.decor.floor=clamp(v,0,3);return true;}return false;};
P.machToggle=function(u){var o=this.obj(u);if(!o||!isMach(o.id))return false;o.on=o.on?0:1;return true;};
P.sendFix=function(u){var o=this.obj(u);if(!o||!o.jam)return false;var p=this.s.papa;
  if(p.task&&p.task.ox!=null&&(p.task.lying||p.task.sit)){p.x=p.task.ox;p.y=p.task.oy;}p.path=[];p.task=null;return this.startTask(this.mkTask("fix",o),this.spotsFor(o));};
/* save: potatoes in flight are paid out at save time, nothing is lost */
P.saveStr=function(){var s=this.s,me=this,pend=0;s.pots.forEach(function(p){if(p.k===1)pend+=me.potValue(p,"chute");});
  var pool=[];s.pots.forEach(function(p){if((p.m==="pool"||p.m==="scan")&&pool.length<C.poolCap)pool.push(Math.round(p.d*100)/100);});
  pend=0;s.pots.forEach(function(p){if(p.k===1&&p.m!=="pool"&&p.m!=="scan")pend+=me.potValue(p,"chute");});
  var o={v:1,ver:VERSION,t:s.t,coins:s.coins+pend,pile:s.pile+s.ret.length,pool:pool,acc:s.acc,want:s.want,wantT:s.wantT,savedAt:s.savedAt||0,lastAway:s.lastAway,level:s.level,food:s.food,shipped:s.shipped,earned:s.earned,shippedClean:s.shippedClean,swept:s.swept,compostAcc:s.compostAcc,lastPayDay:s.lastPayDay,tips:s.tips,
    box:s.box,ups:s.ups,inv:s.inv,owned:s.owned,equip:s.equip,basin:s.basin,decor:s.decor,plant:s.plant,stats:s.stats,papa:{hunger:s.papa.hunger,energy:s.papa.energy,hands:s.papa.hands},
    peels:s.peels.slice(-120),
    objs:s.objs.map(function(q){return {id:q.id,x:q.x,y:q.y,r:q.r,wall:q.wall,on:q.on};})};
  return JSON.stringify(o);};
P.load=function(str){var d;try{d=JSON.parse(str);}catch(e){return false;}if(!d||typeof d!=="object"||d.v!==1)return false;
  var me=this;this.reset(this.seed);var s=this.s,k;function okn(v,a,b){return typeof v==="number"&&isFinite(v)&&v>=a&&v<=b;}
  ["coins","shipped","earned","shippedClean","swept","compostAcc","tips","t","lastPayDay"].forEach(function(k){if(okn(d[k],0,1e12))s[k]=d[k];});
  if(okn(d.level,1,5))s.level=d.level|0;if(okn(d.food,0,60))s.food=d.food|0;
  if(d.box&&typeof d.box==="object")COMMANDS.forEach(function(c){if(okn(d.box[c.id],c.min,c.max))s.box[c.id]=d.box[c.id];});
  if(d.ups&&typeof d.ups==="object")UPS.forEach(function(u){if(okn(d.ups[u.id],0,u.max))s.ups[u.id]=d.ups[u.id]|0;});
  ["owned","inv"].forEach(function(n){if(d[n]&&typeof d[n]==="object")for(var k in d[n])if(ITEMI[k]&&okn(d[n][k],0,9999))s[n][k]=d[n][k]|0;});
  if(d.equip)for(k in s.equip)s.equip[k]=!!d.equip[k]&&(s.owned[k]|0)>0;
  if(d.basin)for(k in s.basin)s.basin[k]=!!d.basin[k]&&(s.owned[k]|0)>0;
  if(d.decor){if(okn(d.decor.wall,0,3))s.decor.wall=d.decor.wall|0;if(okn(d.decor.floor,0,3))s.decor.floor=d.decor.floor|0;if(okn(d.decor.radioSt,0,2))s.decor.radioSt=d.decor.radioSt|0;if(okn(d.decor.radioVol,0,10))s.decor.radioVol=d.decor.radioVol|0;s.decor.radioNear=d.decor.radioNear?1:0;}
  if(d.plant&&okn(d.plant.dry,0,100))s.plant.dry=d.plant.dry;
  if(d.stats)for(k in s.stats)if(okn(d.stats[k],0,1e12))s.stats[k]=d.stats[k];
  if(okn(d.pile,0,C.potTotal))s.pile=d.pile|0;
  if(Array.isArray(d.pool))d.pool.slice(0,C.poolCap).forEach(function(v){var q=me.newPot(1,"pool");if(q){q.d=okn(v,0,1)?v:1;q.pt=-1;}});
  if(Array.isArray(d.pool)){s.pile=Math.max(0,Math.min(s.pile,C.potTotal-s.pots.length));}
  if(d.acc&&typeof d.acc==="object"){var A=s.acc;if(["chef","party","beanie","top","none"].indexOf(d.acc.hat)>=0)A.hat=d.acc.hat;A.glasses=d.acc.glasses?1:0;A.bow=d.acc.bow?1:0;A.toy=d.acc.toy?1:0;
    ITEMS.forEach(function(it){if(it.cat==="acc"&&!(s.owned[it.id]|0)&&me.wearing(it.id)&&it.slot!=="hat")A[it.slot]=0;});if(A.hat!=="chef"){var hid=null;for(var hk in ACC_HAT)if(ACC_HAT[hk]===A.hat)hid=hk;if(!hid||!(s.owned[hid]|0))A.hat="chef";}}
  if(d.want&&typeof d.want==="object"&&(d.want.id==="snack"||(ITEMI[d.want.id]&&ITEMI[d.want.id].cat==="acc"))&&okn(d.want.price,0,999)){s.want={id:d.want.id,kind:d.want.id==="snack"?"food":"acc",name:d.want.id==="snack"?"A SNACK":ITEMI[d.want.id].name,price:d.want.price|0,t0:0};}
  if(okn(d.wantT,0,1e6))s.wantT=d.wantT;if(okn(d.savedAt,0,1e15))s.savedAt=d.savedAt;if(d.lastAway&&typeof d.lastAway==="object")s.lastAway=d.lastAway;
  var pa=d.papa||{};["hunger","energy","hands"].forEach(function(k){if(okn(pa[k],0,130))s.papa[k]=pa[k];});
  if(Array.isArray(d.peels))d.peels.slice(-PEEL_CAP).forEach(function(q){if(q&&okn(q.x,0,W)&&okn(q.y,0,H))s.peels.push({x:q.x,y:q.y,a:(q.a|0)%6,c:(q.c|0)%3});});
  /* objects go back in through the placement rules, so a bad save can't put anything inside a wall */
  var objs=Array.isArray(d.objs)?d.objs:[];var st={};objs.forEach(function(o){if(o&&STARTERS[o.id])st[o.id]=o;});
  s.objs=s.objs.filter(function(o){return false;});this.dirtyGrid=true;
  ["table","cooler","bed","tub"].forEach(function(id){var o=st[id],def={table:[5,9],cooler:[11,5],bed:[10,18],tub:[19,4]}[id],ok=false;
    if(o&&okn(o.x,0,W)&&okn(o.y,0,H)&&okn(o.r,0,3)){me.addObj(id,o.x|0,o.y|0,o.r|0,true);ok=true;}
    if(!ok)me.addObj(id,def[0],def[1],0,true);});
  objs.forEach(function(o){if(!o||!ITEMI[o.id]||STARTERS[o.id])return;var it=ITEMI[o.id];if(!okn(o.x,0,W)||!okn(o.y,0,H))return;
    if(it.cat==="wall"){var w={id:o.id,wall:o.wall==="W"?"W":"N",x:o.x|0,y:o.y|0};if(me.wallFree(w)){var n=me.addObj(o.id,w.x,w.y,0);n.wall=w.wall;}else s.inv[o.id]=(s.inv[o.id]|0)+1;return;}
    var c=me.canPlace(o.id,o.x|0,o.y|0,(o.r|0)%4);if(c.ok){var n2=me.addObj(o.id,o.x|0,o.y|0,(o.r|0)%4);if(n2.on!=null)n2.on=o.on===0?0:1;}else s.inv[o.id]=(s.inv[o.id]|0)+1;});
  var t=this.papaTile();s.papa.x=t[0]+0.5;s.papa.y=t[1]+0.5;this.dirtyGrid=true;this.power=null;return true;};
return {Sim:Sim,VERSION:VERSION,SAVE_KEY:SAVE_KEY,W:W,H:H,DT:DT,DIRS:DIRS,KIT:KIT,WSH:WSH,DOOR:DOOR,FIX:FIX,CANAL_TILES:CANAL_TILES,CANAL_PTS:CANAL_PTS,CANAL_LEN:CANAL_LEN,
  COMMANDS:COMMANDS,BOX:BOX,UPS:UPS,UPI:UPI,ITEMS:ITEMS,ITEMI:ITEMI,STARTERS:STARTERS,THEMES:THEMES,LEVEL_PRICE:LEVEL_PRICE,PACE:PACE,STYLE:STYLE,SPEED_NAME:SPEED_NAME,SPEEDV:SPEEDV,DELIVER:DELIVER,
  itemDef:itemDef,heapSlots:heapSlots,HEAP:HEAP,ACC_HAT:ACC_HAT,mkRng:mkRng,fp:fp,roomOf:roomOf,isCanal:isCanal,isPool:isPool,isWater:isWater,fixedBlock:fixedBlock,isMach:isMach,LOAD:LOAD,C:C,POT_CAP:POT_CAP,PEEL_CAP:PEEL_CAP,DNAME:DNAME,inRect:inRect,around:around};
})();
