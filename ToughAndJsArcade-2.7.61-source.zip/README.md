# Tough & J's Arcade 2.7.61 (versionCode 99) — source (GPL-3.0)

2.7.61 is cumulative over 2.7.59 (Papa Potato 0.3 stays playable as slot papa-potato:v03, 0.2 as v02, 0.1 as v01):
- NEW: Papa Potato 0.4 (latest) — source/papa-potato/ (game src including sprites04.js, frozen 0.1 + 0.2 + 0.3 html, assembler/tests, WebView-83 emulator scripts, README). Levels and shop, conveyor work line, decorations (TV sit pose, radio, plant, lamp, rug), carry bag capacity, zoom/pan in side rails outside the room, room editor. Saves migrate v3/v2/v1 into a new v4 key (old keys are never written).
- Unchanged from 2.7.59: Latch 2.1, FunMotion 0.2.5, Swarm 1.6.14, Needle, engine, Android wrapper (only AndroidManifest.xml version bump), old-WebView transforms: source/latch-ui, latch-manual, latch-build, funmotion-0.2.5, swarm-1.6.14, needle-ui, engine, android-app, old-webview.

Not included: signing keys. The Latch unlock value is replaced by REPLACE-WITH-UNLOCK-CODE in source/latch-ui/src/lib/bench/model.ts.
Licenses: licenses/ (GPL-3.0, third-party notices, OFL-1.1 for the manual fonts).
