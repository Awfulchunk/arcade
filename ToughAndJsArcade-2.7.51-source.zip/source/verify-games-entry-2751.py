# Outside GAME_SRC, the 2.7.50 and 2.7.51 bundles may differ ONLY inside the needle GAMES entry (versions only; tagline kept).
import json
def g(p):
    t=open(p).read();a=t.index('const GAME_SRC=');b=t.index('// END_PACKED_GAME_SRC');return t[:a]+t[b:]
A=g('/workspace/game/build-needle/package-2.7.50/tough-and-js-arcade.html');B=g('/workspace/game/build-needle/package-2.7.51/tough-and-js-arcade.html')
def ent(t):
    s=t.index('{"id":"needle","title":');o,n=json.JSONDecoder().raw_decode(t[s:]);return s,s+n,o
sa,ea,oa=ent(A);sb,eb,ob=ent(B)
same=A[:sa]==B[:sb] and A[ea:]==B[eb:]; keys=sorted(k for k in set(oa)|set(ob) if oa.get(k)!=ob.get(k))
print('outside needle entry identical:',same,'| changed keys:',keys); assert same and keys==['versions']
