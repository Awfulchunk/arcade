const fs=require('fs');const t=fs.readFileSync(process.argv[2],'utf8');
const a=t.indexOf('const GAME_SRC=');const b=t.indexOf('// END_PACKED_GAME_SRC');
const code=t.slice(a,b)+'\nmodule.exports=GAME_SRC;';
fs.writeFileSync('/tmp/gs.js',code);const G=require('/tmp/gs.js');
console.log(typeof G, Object.keys(G).length);
for(const k of Object.keys(G)) if(k.startsWith('needle')){fs.writeFileSync(k.replace(':','-')+'.html',G[k]);console.log(k,G[k].length)}
