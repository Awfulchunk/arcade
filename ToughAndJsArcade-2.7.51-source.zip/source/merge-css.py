"""Needle 2.7.50: keep the ORIGINAL shipped CSS byte-for-byte and only append utility rules the new pieces need."""
import re,sys
def top_blocks(css):
    out=[];i=0;n=len(css)
    while i<n:
        j=i;depth=0
        while j<n:
            c=css[j]
            if c=='{':depth+=1
            elif c=='}':
                depth-=1
                if depth==0: j+=1;break
            elif c==';' and depth==0: j+=1;break
            j+=1
        out.append(css[i:j]);i=j
    return [b for b in out if b.strip()]
def layer(css,name):
    out=[]  # every @layer <name>{...} block (2.7.51: the 2.7.50 CSS already has a second, appended utilities block)
    for b in top_blocks(css):
        if b.startswith('@layer '+name+'{'): out+=top_blocks(b[len('@layer '+name+'{'):-1])
    return out
def merged(orig,mine):
    ou=set(layer(orig,'utilities')); mu=layer(mine,'utilities')
    add=[r for r in mu if r not in ou]
    oprops=set(b for b in top_blocks(orig) if b.startswith('@property'))
    props=[b for b in top_blocks(mine) if b.startswith('@property') and b not in oprops]
    extra=('@layer utilities{'+''.join(add)+'}' if add else '')+''.join(props)
    return orig+extra, add, props
if __name__=='__main__':
    o=open(sys.argv[1]).read(); m=open(sys.argv[2]).read()
    css,add,props=merged(o,m); print(len(add),'rules',len(props),'props'); print('\n'.join(add))
