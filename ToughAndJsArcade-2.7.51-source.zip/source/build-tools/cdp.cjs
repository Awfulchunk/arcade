// Minimal raw CDP client for the emulator's old WebView (Chrome 83).
const WebSocket=require('ws');
module.exports=async function connect(port=9333){
  const list=await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  const pg=list.find(x=>x.type==='page'&&x.url.startsWith('file:'))||list[0];
  const ws=new WebSocket(pg.webSocketDebuggerUrl,{perMessageDeflate:false});
  await new Promise((r,j)=>{ws.on('open',r);ws.on('error',j);});
  let n=0;const wait={};const ctx=[];
  ws.on('message',m=>{const d=JSON.parse(m);if(d.id&&wait[d.id]){wait[d.id](d);delete wait[d.id];}if(d.method==='Runtime.executionContextCreated')ctx.push(d.params.context);});
  const send=(method,params={})=>new Promise(r=>{const id=++n;wait[id]=r;ws.send(JSON.stringify({id,method,params}));});
  const ev=async(expr,contextId)=>{const r=await send('Runtime.evaluate',{expression:expr,awaitPromise:true,returnByValue:true,...(contextId?{contextId}:{})});if(r.result&&r.result.exceptionDetails)throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0,400));return r.result&&r.result.result?r.result.result.value:r;};
  await send('Runtime.enable');
  return {send,ev,ctx,close:()=>ws.close()};
};
