#!/bin/bash
# usage: force-reader.sh "android_vr" | force-reader.sh ""   (emulator test hook; adb root)
ADB=/workspace/tools/sdk/platform-tools/adb
if [ -n "$1" ]; then $ADB shell "echo -n '$1' > /data/data/com.toughandj.arcade/files/needle-readers.txt && chmod 666 /data/data/com.toughandj.arcade/files/needle-readers.txt"
else $ADB shell rm -f /data/data/com.toughandj.arcade/files/needle-readers.txt; fi
$ADB shell am force-stop com.toughandj.arcade; $ADB shell am start -n com.toughandj.arcade/.MainActivity >/dev/null; sleep 45
S=$($ADB shell cat /proc/net/unix | grep -o 'webview_devtools_remote_[0-9]*' | tail -1); $ADB forward --remove-all; $ADB forward tcp:9333 localabstract:$S >/dev/null
cd /workspace/game/build-needle/gui && timeout 60 node q.cjs "TJNeedle.info()"
