// helpers for driving the Needle iframe on the emulator
const c=require('./cdp.cjs');const {execSync}=require('child_process');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const D=`(document.querySelector('iframe').contentDocument)`;const W=`(document.querySelector('iframe').contentWindow)`;
module.exports=async()=>{const s=await c();
 const ev=e=>s.ev(e);
 const click=async(sel,text)=>ev(`(()=>{const els=[...${D}.querySelectorAll(${JSON.stringify(sel)})].filter(e=>${text?`(e.innerText||e.getAttribute('aria-label')||'').trim().match(new RegExp(${JSON.stringify(text)}))`:'true'});if(!els.length)return 'NOTFOUND';els[0].scrollIntoView({block:'center'});els[0].click();return 'ok:'+(els[0].innerText||'').trim().slice(0,40)})()`);
 const type=async(sel,val)=>ev(`(()=>{const el=${D}.querySelector(${JSON.stringify(sel)});const p=Object.getPrototypeOf(el);Object.getOwnPropertyDescriptor(p,'value').set.call(el,${JSON.stringify(val)});el.dispatchEvent(new ${W}.Event('input',{bubbles:true}));return 'ok'})()`);
 const text=async()=>ev(`${D}.body.innerText`);
 const shot=name=>{execSync(`/workspace/tools/sdk/platform-tools/adb exec-out screencap -p > /workspace/game/build-needle/emu-out/${name}.png`);};
 return {s,ev,click,type,text,shot,sleep,close:()=>s.close()};};
