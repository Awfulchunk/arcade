const H=require('./ifr.cjs');(async()=>{const h=await H();const L=(...a)=>console.log(...a);
L(await h.click('a','Press'));await h.sleep(6000);h.shot('g3-press');
L(await h.click('button','^YouTube$'));L(await h.click('button','^Audio$'));L(await h.click('button','^mp3$'));
L(await h.type('textarea','https://youtu.be/jNQXAC9IVRw?si=gui'));await h.sleep(1500);
L(await h.click('button[type=submit]',''));
let t='';for(let k=0;k<60;k++){await h.sleep(3000);t=await h.text();if(/Pull this|bot|couldn|error/i.test(t))break;}
await h.sleep(1500);h.shot('g3-sheet');L('--- SHEET TEXT\n'+t.slice(t.indexOf('Me at')>=0?Math.max(0,t.lastIndexOf('Me at')-200):-1500));
L(await h.click('button','^192'));await h.sleep(800);
L(await h.click('button','Pull this'));
for(let k=0;k<120;k++){await h.sleep(4000);t=await h.text();if(k%5==0)h.shot('g3-progress');if(/Me at the zoo\.mp3/.test(t)&&!/mp3\s*\d+%/.test(t)&&/Crate/.test(t)&&!/Pulling|working/i.test(t))break;}
await h.sleep(3000);h.shot('g3-done');
L('--- AFTER\n'+t.slice(t.indexOf('Queue')));h.close();})().catch(e=>{console.error(e);process.exit(1)});
