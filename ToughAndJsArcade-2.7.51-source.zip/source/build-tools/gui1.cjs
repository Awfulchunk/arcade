const c=require('./cdp.cjs');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const s=await c();
const i=await s.ev(`ARCADE.GAMES.findIndex(g=>g.id==='needle')`);console.log('idx',i);
await s.ev(`ARCADE.launchCard(${i})`);await sleep(15000);
console.log(await s.ev(`(()=>{const f=[...document.querySelectorAll('iframe')];return JSON.stringify(f.map(x=>{try{return {loc:x.contentWindow.location.href,txt:x.contentDocument.body.innerText.slice(0,600)}}catch(e){return String(e)}}))})()`));
const sh=await s.send('Page.captureScreenshot',{format:'png'});require('fs').writeFileSync('/workspace/game/build-needle/emu-out/gui-1.png',Buffer.from(sh.result.data,'base64'));
s.close();})().catch(e=>{console.error(e);process.exit(1)});
