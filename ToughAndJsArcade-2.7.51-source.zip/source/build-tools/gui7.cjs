const H=require('./ifr.cjs');(async()=>{const h=await H();const L=(...a)=>console.log(...a);
await h.click('button','^Clear finished$');
L(await h.click('button','^YouTube$'));L(await h.click('button','^Audio$'));L(await h.click('button','^mp3$'));
L(await h.type('textarea','https://youtu.be/jNQXAC9IVRw?si=gui'));await h.sleep(1500);
L(await h.click('button[type=submit]',''));
let t='';for(let k=0;k<80;k++){await h.sleep(3000);t=await h.text();if(/Try again/.test(t)){h.shot('g3-error');L('probe error -> Try again');await h.click('button','^Try again$');continue;}if(/Pull this/.test(t)&&/kbps/.test(t))break;}
await h.sleep(1500);h.shot('g3-sheet');L('--- SHEET TEXT\n'+t.slice(t.indexOf('Me at')>=0?Math.max(0,t.lastIndexOf('Me at')-200):-1500));
L(await h.click('button','^192'));await h.sleep(800);
L(await h.click('button','Pull this'));
for(let k=0;k<120;k++){await h.sleep(4000);t=await h.text();if(k%5==0)h.shot('g3-progress');const q=t.slice(t.indexOf('Queue'),t.indexOf('Crate'));if(k%3==0)L('Q:',q.replace(/\n+/g,' | ').slice(0,160));if(/done|error|cancel/i.test(q.replace(/Clear finished/,''))&&!/\d%/.test(q))break;}
await h.sleep(3000);h.shot('g3-done');
L('--- AFTER\n'+t.slice(t.indexOf('Queue')));h.close();})().catch(e=>{console.error(e);process.exit(1)});
