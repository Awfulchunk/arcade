const puppeteer=require('puppeteer-core');const fs=require('fs');
const html=fs.readFileSync('/workspace/game/build-needle/needle-2.7.50.html','utf8');
const srv=require('http').createServer((q,r)=>{r.writeHead(200,{'content-type':'text/html'});r.end(html);}).listen(8772);
(async()=>{const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
for(const [w,h,mock] of [[360,800,true],[320,568,true],[360,800,false]]){const p=await b.newPage();await p.setViewport({width:w,height:h,deviceScaleFactor:2,isMobile:true,hasTouch:true});
 if(mock)await p.evaluateOnNewDocument(`window.TJNeedle={info:()=>JSON.stringify({ok:true,version:'1.0.0',extractor:'NewPipeExtractor v0.27.1',why:null}),probe(){return 'p'},status(){return '{}'},start(){return 'j'},cancel(){},release(){}}`);
 await p.goto('http://127.0.0.1:8772/',{waitUntil:'load'});await new Promise(r=>setTimeout(r,1200));
 await p.evaluate(()=>[...document.querySelectorAll('a')].find(a=>/Press/.test(a.innerText)).click());await new Promise(r=>setTimeout(r,1000));
 await p.evaluate(()=>document.querySelector('[aria-label="Press settings"]').click());await new Promise(r=>setTimeout(r,1000));
 const t=await p.evaluate(()=>document.body.innerText);const i=t.indexOf('Download engine');console.log(w+'x'+h,'mock='+mock,'|',t.slice(i,i+400).replace(/\n+/g,' | '));
 await p.evaluate(()=>{const e=[...document.querySelectorAll('*')].find(e=>e.children.length<3&&/Download engine/.test(e.textContent));e&&e.scrollIntoView({block:'start'})});await new Promise(r=>setTimeout(r,500));
 await p.screenshot({path:`desk/settings-${w}-${mock?'phone':'nobridge'}.png`});await p.close();}
await b.close();srv.close();})().catch(e=>{console.error(e);process.exit(1)});
