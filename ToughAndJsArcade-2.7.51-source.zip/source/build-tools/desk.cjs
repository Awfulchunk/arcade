// Desktop Chrome layout check of the built Needle cartridge with a MOCK TJNeedle (UI only; real engine tested on emulator).
const puppeteer=require('puppeteer-core');const fs=require('fs');
const html=fs.readFileSync('/workspace/game/build-needle/needle-2.7.50.html','utf8');
const mock=`window.TJNeedle={info:()=>JSON.stringify({ok:true,version:'1.0.0',extractor:'NewPipeExtractor v0.27.1',why:null}),
 _j:{},_n:0,
 probe(u){const id='p'+(++this._n);this._j[id]={type:'probe',state:'done',progress:100,probe:{title:'Me at the zoo',uploader:'jawed',durationSec:19,
  audio:[{id:'a251',label:'Opus 160 kbps',detail:'webm · Opus · best sound',ext:'webm',codec:'opus',kbps:160,bytes:260000},{id:'a140',label:'AAC 128 kbps',detail:'m4a · AAC',ext:'m4a',codec:'aac',kbps:128,bytes:309000},{id:'a139',label:'AAC 48 kbps',detail:'m4a · AAC · small',ext:'m4a',codec:'aac',kbps:48,bytes:116000}],
  video:[{id:'v299+a140',label:'1080p60',detail:'H.264 + AAC, joined on the phone',ext:'mp4',height:1080,bytes:9e7},{id:'v135+a140',label:'480p',detail:'H.264 + AAC, joined on the phone',ext:'mp4',height:480,bytes:2e7},{id:'m18',label:'360p (single file)',detail:'H.264 + AAC as YouTube sends it',ext:'mp4',height:360,bytes:1e7}]}};return id;},
 start(s){const id='j'+(++this._n);this._j[id]={type:'pull',state:'running',progress:1,phase:'sound',t:Date.now()};return id;},
 status(id){const j=this._j[id];if(j&&j.type==='pull'){j.progress=Math.min(100,(Date.now()-j.t)/80);if(j.progress>=100){j.state='done';j.name='Me at the zoo.mp3';j.mime='audio/mpeg';j.size=4096;}}return JSON.stringify(j||{state:'error',error:'gone'});},
 cancel(id){const j=this._j[id];if(j){j.state='cancelled';j.error='Cancelled.';}return true;},release(){return true;}};`;
const srv=require('http').createServer((q,r)=>{r.writeHead(200,{'content-type':'text/html'});r.end(html);}).listen(8771);
(async()=>{const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
for(const [w,h] of [[360,800],[320,568]]){const p=await b.newPage();await p.setViewport({width:w,height:h,deviceScaleFactor:2,isMobile:true,hasTouch:true});
 await p.evaluateOnNewDocument(mock);
 await p.setRequestInterception(true);p.on('request',r=>{if(r.url().startsWith('https://tj-needle.local/'))r.respond({status:200,contentType:'audio/mpeg',headers:{'Access-Control-Allow-Origin':'*'},body:Buffer.alloc(4096,7)});else r.continue();});
 await p.goto('http://127.0.0.1:8771/',{waitUntil:'load'});await new Promise(r=>setTimeout(r,1500));
 await p.evaluate(()=>{const a=[...document.querySelectorAll('a')].find(a=>/Press/.test(a.innerText));a&&a.click();});await new Promise(r=>setTimeout(r,1500));
 await p.screenshot({path:`desk/press-${w}.png`});
 const ta=await p.$('textarea');await ta.type('https://youtube.com/shorts/aqz-KE-bpKQ?si=abc');
 await p.evaluate(()=>document.querySelector('button[type=submit]').click());await new Promise(r=>setTimeout(r,1500));
 await p.screenshot({path:`desk/sheet-${w}.png`});
 const small=await p.evaluate(()=>[...document.querySelectorAll('[role=dialog] button')].map(b=>{const r=b.getBoundingClientRect();return {t:(b.innerText||b.getAttribute('aria-label')).trim(),w:Math.round(r.width),h:Math.round(r.height)}}).filter(x=>x.h<44||x.w<44));
 const over=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
 console.log(w+'x'+h,'small tap targets in sheet:',JSON.stringify(small),'horizontal overflow:',over);
 await p.evaluate(()=>[...document.querySelectorAll('[role=dialog] button')].find(b=>/Pull this/.test(b.innerText)).click());await new Promise(r=>setTimeout(r,3000));
 await p.screenshot({path:`desk/queue-${w}.png`,fullPage:false});
 await new Promise(r=>setTimeout(r,8000));const t=await p.evaluate(()=>document.body.innerText);console.log(' crate has file:',/Me at the zoo/.test(t.slice(t.indexOf('Crate'))));
 await p.screenshot({path:`desk/done-${w}.png`,fullPage:true});await p.close();}
await b.close();srv.close();})().catch(e=>{console.error(e);process.exit(1)});
