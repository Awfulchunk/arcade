"""List framework methods/fields referenced by a .dex that need a newer Android API than MIN (after D8's own backports)."""
import sys,struct
sys.argv=[sys.argv[0]]+sys.argv[1:]
MIN=int(sys.argv[1]); dexf=sys.argv[2]
import importlib.util
spec=importlib.util.spec_from_file_location('ac','/workspace/game/build-needle/tools/apicheck.py')
# reuse the api-versions loader without running its main
src=open('/workspace/game/build-needle/tools/apicheck.py').read().split('def refs(')[0].replace('MIN=int(sys.argv[1]); jars=sys.argv[2:]','')
g={};exec(src,g);C=g['C'];msince=g['msince']
d=open(dexf,'rb').read()
def u32(o):return struct.unpack('<I',d[o:o+4])[0]
def uleb(o):
    r=0;s=0
    while True:
        b=d[o];o+=1;r|=(b&0x7f)<<s;s+=7
        if b<0x80:return r,o
sids,soff=u32(0x38),u32(0x3c);tids,toff=u32(0x40),u32(0x44);pids,poff=u32(0x48),u32(0x4c);fids,foff=u32(0x50),u32(0x54);mids,moff=u32(0x58),u32(0x5c)
def s(i):
    o=u32(soff+4*i);_,o=uleb(o);e=d.index(b'\0',o);return d[o:e].decode('utf8','replace')
def t(i):return s(u32(toff+4*i))
def proto(i):
    o=poff+12*i;ret=t(u32(o+4));po=u32(o+8);ps=''
    if po:
        n=u32(po);ps=''.join(t(struct.unpack('<H',d[po+4+2*k:po+6+2*k])[0]) for k in range(n))
    return '('+ps+')'+ret
bad=[]
for i in range(mids):
    o=moff+8*i;ci,pi,ni=struct.unpack('<HHI',d[o:o+8]);cls=t(ci)[1:-1];name=s(ni)
    if not cls.startswith(('java/','javax/','android/')):continue
    if cls not in C: bad.append((99,cls,name+' <class missing>'));continue
    key=name+proto(pi);v=msince(cls,key)
    if v is None:
        if name in('<init>','clone','values','valueOf'):continue
        bad.append((99,cls,key+' <not found>'))
    elif v>MIN: bad.append((v,cls,key))
for i in range(fids):
    o=foff+8*i;ci,ti,ni=struct.unpack('<HHI',d[o:o+8]);cls=t(ci)[1:-1]
    if cls in C:
        v=C[cls][2].get(s(ni))
        if v and v>MIN: bad.append((v,cls,s(ni)+' (field)'))
for b in sorted(bad,reverse=True):print('API %2d %s.%s'%b)
print('TOTAL',len(bad))
