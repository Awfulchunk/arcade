const H=require('./ifr.cjs');(async()=>{const h=await H();
console.log(await h.click('a,button','^Press'));await h.sleep(5000);
const t=await h.text();console.log(t.slice(0,1500));h.shot('gui-press');h.close();})().catch(e=>{console.error(e);process.exit(1)});
