const H=require('./ifr.cjs');(async()=>{const h=await H();const L=(...a)=>console.log(new Date().toTimeString().slice(0,8),...a);
const cur=await h.ev(`!!document.querySelector('iframe')`);if(!cur){const i=await h.ev(`ARCADE.GAMES.findIndex(g=>g.id==='needle')`);await h.ev(`ARCADE.launchCard(${i})`);await h.sleep(15000);}
const ifr=await h.ev(`document.querySelector('iframe')?document.querySelector('iframe').contentDocument.body.innerText.slice(0,30):''`);
if(!/Press/.test(await h.text())||/Three desks/.test(await h.text())){L(await h.click('a','Press'));await h.sleep(5000);}
// close any open sheet
await h.click('[role=dialog] button','^Cancel$');await h.sleep(800);
const run=async(kindBtn,fmt,rate,tag)=>{
 L(await h.click('button','^Web$'));await h.sleep(300);L(await h.click('button',kindBtn));if(fmt)L(await h.click('button','^'+fmt+'$'));
 L(await h.type('textarea','https://download.samplelib.com/mp4/sample-5s.mp4'));await h.sleep(1200);
 L(await h.click('button[type=submit]',''));let t='';
 for(let k=0;k<40;k++){await h.sleep(2000);t=await h.text();if(/Original|Sound from|Try again/.test(t))break;}
 await h.sleep(1000);h.shot('g5-sheet-'+tag);L('SHEET:',t.slice(t.lastIndexOf('Nothing in the crate')>0?t.lastIndexOf('files'):t.length-600).replace(/\n+/g,' | ').slice(0,600));
 if(rate)L(await h.click('[role=dialog] button','^'+rate+'k$'));
 L(await h.click('[role=dialog] button','^Pull this$'));
 for(let k=0;k<150;k++){await h.sleep(3000);t=await h.text();const q=t.slice(t.indexOf('Queue'),t.indexOf('Crate'));if(k%4==0){L('Q:',q.replace(/\n+/g,' | ').slice(0,200));if(k==4)h.shot('g5-progress-'+tag);} if(/done|error|cancel/i.test(q.replace(/Clear finished/,""))&&!/\d%/.test(q))break;}
 await h.sleep(2000);h.shot('g5-done-'+tag);L('AFTER:',t.slice(t.indexOf('Queue')).replace(/\n+/g,' | ').slice(0,700));};
await h.click('button','^Clear finished$');
await run('^Audio$','mp3','256','mp3');
L('play:',await h.click('button','^Play'));await h.sleep(6000);
L('media:',await h.ev(`JSON.stringify([...document.querySelector('iframe').contentDocument.querySelectorAll('audio,video')].map(m=>({tag:m.tagName,src:(m.currentSrc||'').slice(0,30),t:m.currentTime,paused:m.paused,dur:m.duration,err:m.error&&m.error.code})))`));
h.shot('g5-playing');h.close();})().catch(e=>{console.error(e);process.exit(1)});
