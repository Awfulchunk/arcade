// Drives the REAL TJNeedle bridge inside the installed 2.7.50 app on the Android 11 emulator.
const connect=require('./cdp.cjs');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const s=await connect();
 const st=async id=>JSON.parse(await s.ev(`TJNeedle.status(${JSON.stringify(id)})`));
 const waitJob=async(id,ms)=>{const t0=Date.now();let last=-1;for(;;){const j=await st(id);if(j.progress!==last){last=j.progress;}if(!/running|queued/.test(j.state)||Date.now()-t0>ms)return j;await sleep(1500);}};
 const url=process.argv[2];
 let t=Date.now();const pid=await s.ev(`TJNeedle.probe(${JSON.stringify(url)})`);const ps=await waitJob(pid,300000);
 console.log('PROBE',url,ps.state,ps.error||'',((Date.now()-t)/1000).toFixed(1)+'s');
 if(ps.probe){console.log('  audio',ps.probe.audio.map(o=>o.id+':'+o.label).join(', '));console.log('  video',ps.probe.video.map(o=>o.id+':'+o.label).join(', '));}
 for(const sp of JSON.parse(process.argv[3]||'[]')){ sp.url=sp.url||url; t=Date.now(); const id=await s.ev(`TJNeedle.start(${JSON.stringify(JSON.stringify(sp))})`);
   const prog=[]; let j; const t0=Date.now(); for(;;){ j=await st(id); prog.push(Math.round(j.progress)+(j.phase?':'+j.phase:'')); if(!/running|queued/.test(j.state)||Date.now()-t0>1500000)break; if(sp.cancelAt && j.progress>=sp.cancelAt){ await s.ev(`TJNeedle.cancel(${JSON.stringify(id)})`); } await sleep(1500);}
   let f=null; if(j.state==='done'){ f=await s.ev(`(async()=>{const r=await fetch('https://tj-needle.local/out/${id}');const b=await r.blob();const u=new Uint8Array(await b.slice(0,12).arrayBuffer());return {status:r.status,type:r.headers.get('content-type'),size:b.size,head:Array.from(u).map(x=>x.toString(16).padStart(2,'0')).join('')};})()`); }
   console.log('JOB',JSON.stringify(sp),'=>',j.state,j.name||'',j.size||'',j.error||'',((Date.now()-t)/1000).toFixed(1)+'s');
   console.log('   progress',[...new Set(prog)].join(' '));console.log('   fetch',JSON.stringify(f),'job',id);
 }
 s.close();
})().catch(e=>{console.error('ERR',e.message);process.exit(1)});
