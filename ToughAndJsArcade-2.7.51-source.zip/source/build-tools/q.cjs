const c=require('./cdp.cjs');(async()=>{const s=await c();console.log(await s.ev(process.argv[2]));s.close();})().catch(e=>{console.error(e.message);process.exit(1)});
