const H=require('./ifr.cjs');(async()=>{const h=await H();const L=(...a)=>console.log(new Date().toTimeString().slice(0,8),...a);
await h.click('button','^Clear finished$');
L(await h.click('button','^YouTube$'));L(await h.click('button','^Video$'));
L(await h.type('textarea','https://youtube.com/shorts/aqz-KE-bpKQ?si=abc'));await h.sleep(1200);
L(await h.click('button[type=submit]',''));let t='';
for(let k=0;k<40;k++){await h.sleep(2000);t=await h.text();if(/Try again/.test(t)){await h.click('[role=dialog] button','^Try again$');continue;}if(/480p/.test(t))break;}
L('SHEET:',t.slice(t.indexOf('Video |')>0?0:t.length-500).replace(/\n+/g,' | ').slice(-500));
L(await h.click('[role=dialog] button','^480p'));L(await h.click('[role=dialog] button','^Pull this$'));
for(let k=0;k<60;k++){await h.sleep(2000);t=await h.text();const q=t.slice(t.indexOf('Queue'),t.indexOf('Crate'));if(/([5-9]|\d\d)%/.test(q)){L('Q:',q.replace(/\n+/g,' | ').slice(0,200));break;}}
L('cancel:',await h.click('button','^Cancel '));await h.sleep(5000);t=await h.text();
L('AFTER:',t.slice(t.indexOf('Queue'),t.indexOf('Crate')+200).replace(/\n+/g,' | '));h.close();})().catch(e=>{console.error(e);process.exit(1)});
