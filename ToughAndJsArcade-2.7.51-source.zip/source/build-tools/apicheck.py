"""Flag Java/Android platform calls in jars/classes that need a newer Android API than MIN (from the SDK's api-versions.xml)."""
import sys,struct,zipfile,os,xml.etree.ElementTree as ET
MIN=int(sys.argv[1]); jars=sys.argv[2:]
api=ET.parse('/workspace/tools/sdk/platforms/android-34/data/api-versions.xml').getroot()
C={}
for c in api.findall('class'):
    since=int(c.get('since','1')); meth={}; fields={}
    for m in c.findall('method'): meth[m.get('name')]=int(m.get('since',since))
    for f in c.findall('field'): fields[f.get('name')]=int(f.get('since',since))
    sup=[e.get('name') for e in c.findall('extends')]+[e.get('name') for e in c.findall('implements')]
    C[c.get('name')]=(since,meth,fields,sup)
def msince(cls,key,seen=None):
    seen=seen or set()
    if cls in seen or cls not in C: return None
    seen.add(cls); s,m,f,sup=C[cls]
    if key in m: return max(m[key],s)
    for x in sup:
        r=msince(x,key,seen)
        if r is not None: return r
    return None
def refs(data):
    i=8; n=struct.unpack('>H',data[i:i+2])[0]; i+=2; cp=[None]*n; k=1
    while k<n:
        t=data[i]; i+=1
        if t==1: l=struct.unpack('>H',data[i:i+2])[0]; cp[k]=('u',data[i+2:i+2+l].decode('utf8','replace')); i+=2+l
        elif t in (3,4): i+=4
        elif t in (5,6): i+=8; k+=1
        elif t==7: cp[k]=('c',struct.unpack('>H',data[i:i+2])[0]); i+=2
        elif t==8: i+=2
        elif t in (9,10,11): cp[k]=('r',t)+struct.unpack('>HH',data[i:i+4]); i+=4
        elif t==12: cp[k]=('nt',)+struct.unpack('>HH',data[i:i+4]); i+=4
        elif t==15: i+=3
        elif t==16: i+=2
        elif t in (17,18): i+=4
        elif t in (19,20): i+=2
        else: raise ValueError(t)
        k+=1
    out=[]
    for e in cp:
        if e and e[0]=='r':
            cls=cp[cp[e[2]][1]][1]; nt=cp[e[3]]; name=cp[nt[1]][1]; desc=cp[nt[2]][1]
            out.append((e[1],cls,name,desc))
    return out
bad={}
for j in jars:
    z=zipfile.ZipFile(j)
    for nm in z.namelist():
        if not nm.endswith('.class') or nm.startswith('META-INF/versions/'): continue
        for t,cls,name,desc in refs(z.read(nm)):
            if not (cls.startswith('java/') or cls.startswith('javax/') or cls.startswith('android/') or cls.startswith('org/json/')): continue
            if t==9:
                if cls in C:
                    s=C[cls][2].get(name)
                    if s and s>MIN: bad.setdefault((cls,name,s),set()).add(os.path.basename(j)+':'+nm)
                continue
            if cls not in C: bad.setdefault((cls,'<class missing>',99),set()).add(os.path.basename(j)+':'+nm); continue
            s=msince(cls,name+desc)
            if s is None:
                if name in('<init>','clone','values','valueOf'):continue
                bad.setdefault((cls,name+desc+' <not in android>',99),set()).add(os.path.basename(j)+':'+nm)
            elif s>MIN: bad.setdefault((cls,name+desc,s),set()).add(os.path.basename(j)+':'+nm)
for (cls,m,s),w in sorted(bad.items(),key=lambda x:-x[0][2]):
    print(f'API {s:>2} {cls}.{m}  <- {len(w)} e.g. {sorted(w)[0]}')
print('TOTAL',len(bad))
