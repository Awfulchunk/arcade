// Independent check: 2.7.51 vs 2.7.50 bundles + APK contents.
const fs=require('fs'),cr=require('crypto'),{execSync}=require('child_process');
const sha=b=>cr.createHash('sha256').update(b).digest('hex');
const load=(p,tag)=>{const t=fs.readFileSync(p,'utf8');const a=t.indexOf('const GAME_SRC=');const b=t.indexOf('// END_PACKED_GAME_SRC');
 const f=`/tmp/gs-${tag}.js`;fs.writeFileSync(f,t.slice(a,b)+'\nmodule.exports=GAME_SRC;');delete require.cache[f];return {t,a,b,G:require(f)};};
const A=load('/workspace/game/build-needle/package-2.7.50/tough-and-js-arcade.html','a');
const B=load('/workspace/game/build-needle/package-2.7.51/tough-and-js-arcade.html','b');
const r={ok:true,checks:[]};const ck=(n,v,extra)=>{r.checks.push({n,pass:!!v,...(extra||{})});if(!v)r.ok=false;};
const ka=Object.keys(A.G),kb=Object.keys(B.G);
ck('2.7.50 bundle hash',sha(A.t)==='ab8a8074f07ac316b6ef63abe0e0601d834ab8cdc9dff320894e1bce67aae85e');
ck('slot count 50->51',kb.length===ka.length+1,{a:ka.length,b:kb.length});
const changed=ka.filter(k=>A.G[k]!==B.G[k]);ck('only needle:latest payload changed',changed.length===1&&changed[0]==='needle:latest',{changed});
ck('only new slot is needle:v2750',JSON.stringify(kb.filter(k=>!ka.includes(k)))==='["needle:v2750"]');
ck('needle:v2750 == 2.7.50 needle:latest',B.G['needle:v2750']===A.G['needle:latest']);
ck('needle:latest == built needle-2.7.51.html',B.G['needle:latest']===fs.readFileSync('needle-2.7.51.html','utf8'));
// outside GAME_SRC: only the needle GAMES entry may differ
const outA=A.t.slice(0,A.a)+A.t.slice(A.b),outB=B.t.slice(0,B.a)+B.t.slice(B.b);
const ga=outA.indexOf('{"id":"needle","title":'),gb=outB.indexOf('{"id":"needle","title":');
let i=0;while(i<outA.length&&outA[i]===outB[i])i++;let j=0;while(j<outA.length-i&&outA[outA.length-1-j]===outB[outB.length-1-j])j++;
ck('non-GAME_SRC diff starts inside needle GAMES entry (full check: verify-games-entry.py)',i>=ga&&ga===gb,{diffStart:i,needleEntryAt:ga});
r.bundle51=sha(B.t);
const apk='/workspace/game/build-needle/package-2.7.51/out/ToughAndJsArcade-2.7.51.apk',old='/workspace/game/ToughAndJsArcade-2.7.50.apk';
const ent=f=>Object.fromEntries(execSync(`unzip -Z1 ${f}`).toString().trim().split('\n').filter(n=>!n.startsWith('META-INF/')&&!n.endsWith('/')).map(n=>[n,sha(execSync(`unzip -p ${f} '${n}'`,{maxBuffer:1<<28}))]));
const ea2=ent(old),eb=ent(apk);
ck('APK assets/index.html == 2.7.51 bundle',eb['assets/index.html']===r.bundle51);
const assetDiff=Object.keys({...ea2,...eb}).filter(n=>n.startsWith('assets/')&&ea2[n]!==eb[n]);
ck('only assets/index.html differs among assets',JSON.stringify(assetDiff)==='["assets/index.html"]',{assetDiff});
r.apkOtherDiffs=Object.keys({...ea2,...eb}).filter(n=>!n.startsWith('assets/')&&ea2[n]!==eb[n]);
console.log(JSON.stringify(r,null,1));fs.writeFileSync('package-2.7.51/verify-2751.json',JSON.stringify(r,null,1));process.exit(r.ok?0:1);
