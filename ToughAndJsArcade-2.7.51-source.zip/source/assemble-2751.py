"""Arcade 2.7.51: swap ONLY needle:latest (engine retry/fallback note text) on top of 2.7.50; the 2.7.50 Needle is kept as needle:v2750.
Every other cartridge payload stays byte-for-byte as in 2.7.50."""
from pathlib import Path
import json,re,hashlib,importlib.util
root=Path('/workspace/game'); base=root/'build-needle/package-2.7.50'; stage=root/'build-needle/package-2.7.51'
src=(base/'tough-and-js-arcade.html').read_text()
assert hashlib.sha256(src.encode()).hexdigest()=='ab8a8074f07ac316b6ef63abe0e0601d834ab8cdc9dff320894e1bce67aae85e','2.7.50 bundle changed?!'
spec=importlib.util.spec_from_file_location('mc',str(root/'build-needle/merge-css.py'));mc=importlib.util.module_from_spec(spec);spec.loader.exec_module(mc)
built=(root/'build-needle/needle-src/dist/index.html').read_text()
prev=(root/'build-needle/needle-2.7.50.html').read_text()
so=list(re.finditer(r'<style[^>]*>(.*?)</style>',prev,re.S)); sb=list(re.finditer(r'<style[^>]*>(.*?)</style>',built,re.S))
assert len(so)==2 and len(sb)==2 and so[0].group(1)==sb[0].group(1)
css,add,props=mc.merged(so[1].group(1),sb[1].group(1))
new=built[:sb[1].start(1)]+css+built[sb[1].end(1):]
(root/'build-needle/needle-2.7.51.html').write_text(new)
def slots(text):
    r={}
    for m in re.finditer(r'^"([^"\n]+)":\[',text,re.M):
        a=m.end()-1;b=text.index('].join("")',a)+len('].join("")');r[m[1]]=text[a:b]
    return r
before=slots(src); assert 'needle:latest' in before and 'needle:v2750' not in before
old=before['needle:latest']
a=src.index('"needle:latest":')+len('"needle:latest":');b=a+len(old)
expr=json.dumps([new],ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+'.join("")'
out=src[:a]+expr+',\n"needle:v2750":'+old+src[b:]
a=out.index('{"id":"needle","title":');obj,length=json.JSONDecoder().raw_decode(out[a:]);assert obj['id']=='needle'
prior=dict(next(v for v in obj['versions'] if v['id']=='latest'));prior.update(id='v2750',name='v5 – On-phone downloads (2.7.50)',desc='Needle as shipped in 2.7.50: downloads on the phone, one quick retry on a YouTube bot-check.',**{'def':False})
obj['versions'].insert(len(obj['versions'])-1,prior)
cur=next(v for v in obj['versions'] if v['id']=='latest');cur['name']='v6 – Latest (2.7.51: auto-retry + YouTube fallback)'
cur['desc']='2.7.51: when YouTube says "confirm you\'re not a bot" or refuses stream links, Needle waits and retries by itself (3 tries, about 12 s) and tries other real YouTube readers, remembering the one that works. Shows "YouTube busy, retrying (2/3)". Everything else as 2.7.50: YouTube, Shorts and direct links on the phone, MP3/M4A/WAV/OGG or MP4, real qualities, progress, cancel, crate + player, Home-PC mode in Settings.'
out=out[:a]+json.dumps(obj,ensure_ascii=False,separators=(',',':'))+out[a+length:]
after=slots(out)
changed=[k for k,v in before.items() if after.get(k)!=v]
assert changed==['needle:latest'],changed
assert after['needle:v2750']==old
(stage/'tough-and-js-arcade.html').write_text(out)
info={'arcadeVersion':'2.7.51','versionCode':89,'needleSHA256':hashlib.sha256(new.encode()).hexdigest(),'needleBytes':len(new.encode()),
 'bundleSHA256':hashlib.sha256(out.encode()).hexdigest(),'baseBundleSHA256 (2.7.50)':hashlib.sha256(src.encode()).hexdigest(),
 'cartridgeSlots':len(after),'unchangedSlots':len(before)-1,'newSlot':'needle:v2750 (= 2.7.50 needle:latest, byte-identical)','cssRulesAppended':[r.split('{')[0] for r in add]}
(stage/'assembly-verification.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))
