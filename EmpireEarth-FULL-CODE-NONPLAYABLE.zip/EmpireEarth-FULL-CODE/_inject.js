function ePopCap(side){try{if(typeof ecfSidePopCap==='function'&&E&&E.cfg&&E.cfg.houses)return ecfSidePopCap(side);}catch(e){}return typeof EUNIT_CAP!=='undefined'?EUNIT_CAP:80;}
const ECF={ver:'1.0.2',mem:null,popBase:80,popPerHouse:20,popCap:200,lastSave:0,warnCd:0,musicGain:null,joy:{on:false,ax:0,ay:0},_asT:0,_ended:0,load:0,_fpsEma:60,_perfT:0,_wallSeen:null};
function ecfSidePopCap(side){if(!E||!E.cfg)return 80;if(!E.cfg.houses)return E.cfg.unitCap||160;const n=(E.blds[side]||[]).filter(b=>b.alive&&!b.site&&b.type==='house').length;return Math.min(E.cfg.popCap||ECF.popCap,(E.cfg.unitCap||ECF.popBase)+n*ECF.popPerHouse);}
function ecfMemInit(){ECF.mem={attackPaths:[],counters:{},wallWeak:[],ecoTiming:{boomT:0,lastMp:[0,0]},tried:[],strat:'eco',stratT:0};ECF._ended=0;}
function ecfMemWipe(){ECF.mem=null;}
function ecfMemScanWalls(){const M=ECF.mem;if(!M||!E)return;M.wallWeak=[];for(const s of(E.structs||[])){if(!s.alive||s.kind!=='wall'||s.side!==0)continue;const f=s.hp/Math.max(1,s.max);if(f<0.55)M.wallWeak.push({x:s.x,y:s.y,hpFrac:f});}M.wallWeak.sort((a,b)=>a.hpFrac-b.hpFrac);M.wallWeak=M.wallWeak.slice(0,8);}
function ecfMemEco(){const M=ECF.mem;if(!M||!E||!E.res)return;const mp=(E.res[0]&&E.res[0].mp)||0;if(mp>(M.ecoTiming.lastMp[0]||0)+80&&gameTime>60){if(!M.ecoTiming.boomT)M.ecoTiming.boomT=gameTime|0;}M.ecoTiming.lastMp[0]=mp;}
function ecfPickStrat(A,t){const M=ECF.mem;if(!M||!A)return;if(t<(M.stratT||0))return;const opts=['eco','wave','flank','raid_weak','defend'];let pick=opts.find(o=>!M.tried.includes(o))||opts[(Math.random()*opts.length)|0];if(M.ecoTiming.boomT&&t-M.ecoTiming.boomT<90)pick='raid_weak';if(M.wallWeak.length>=3)pick='flank';const hq=(E.structs||[]).find(s=>s.alive&&s.kind==='hq'&&s.side===1);if(hq&&hq.hp/hq.max<0.45)pick='defend';M.strat=pick;M.tried.push(pick);if(M.tried.length>12)M.tried.shift();M.stratT=t+18+Math.random()*10;A._ecfStrat=pick;}
const _v5AIStep0=typeof v5AIStep==='function'?v5AIStep:null;
v5AIStep=function(dt){if(_v5AIStep0)_v5AIStep0(dt);if(!E||!ECF.mem)return;ecfMemScanWalls();ecfMemEco();const A=E.ai&&E.ai[1];if(!A)return;ecfPickStrat(A,gameTime);const st=A._ecfStrat||'eco';if(st==='flank'&&ECF.mem.wallWeak[0]){A.focusX=ECF.mem.wallWeak[0].x;A.focusY=ECF.mem.wallWeak[0].y;}else if(st==='raid_weak'&&ECF.mem.attackPaths.length){const p=ECF.mem.attackPaths[ECF.mem.attackPaths.length-1];A.focusX=p.x0;A.focusY=p.y0;}};

/* gates: buildable only; click open/close; path through when open */
function ecfMarkLineGates(line){if(!E||!E.cfg||!E.cfg.gates||!line||!line.slots)return 0;const alive=line.slots.filter(s=>s&&s.alive&&s.done);if(!alive.length)return 0;const mid=alive[alive.length>>1];let n=0;for(const s of alive){if(s===mid||(alive.length>=3&&Math.abs(s.x-mid.x)<(typeof ESEC!=='undefined'?ESEC:56)*0.6)){s.isGate=true;if(s.gateOpen===undefined)s.gateOpen=false;n++;}}return n;}
function ecfMakeGates(){if(!E||!E.cfg||!E.cfg.gates)return 0;let n=0;for(const L of(E.lines||[]))n+=ecfMarkLineGates(L);return n;}
function ecfGatePassable(wall){return!!(wall&&wall.isGate&&wall.gateOpen&&wall.alive&&wall.done);}
function ecfGateBlocks(u,wall){if(!wall||!wall.alive||!wall.done)return false;if(ecfGatePassable(wall))return false;if(wall.isGate&&E.cfg&&E.cfg.gates&&u.side===wall.side)return false;return true;}
function ecfGateStep(){if(!E||!E.cfg||!E.cfg.gates)return;for(const u of(E.units||[])){if(!u.alive)continue;for(const s of(E.structs||[])){if(!s.alive||s.kind!=='wall'||!s.isGate)continue;if(Math.abs(u.x-s.x)<s.hw+u.r&&Math.abs(u.y-s.y)<s.hh+u.r){if(!ecfGateBlocks(u,s)){const dir=u.side===0?1:-1;if(Math.abs(u.y-s.y)<s.hh*0.85)u.y=s.y+dir*(s.hh+u.r+2);u.sk=0;u.settle=false;if(u.nav)u.nav.force=true;}}}}}
function ecfToggleGate(s){if(!s||!s.alive||s.kind!=='wall'||s.side!==0)return false;if(!E.cfg||!E.cfg.gates)return false;if(!s.isGate){s.isGate=true;s.gateOpen=true;}else s.gateOpen=!s.gateOpen;E.navV++;try{banner(s.gateOpen?'GATE OPEN':'GATE CLOSED',s.gateOpen?'Units can path through':'Gate sealed','#ffe680');}catch(e){}try{sfx('ui',s.x,s.y,0.35);}catch(e){}return true;}
function ecfHitWall(side,wx,wy){let best=null,bd=28;for(const s of(E.structs||[])){if(!s.alive||!s.done||s.kind!=='wall'||s.side!==side)continue;const d=Math.hypot(s.x-wx,s.y-wy);if(d<bd&&Math.abs(wx-s.x)<s.hw+6&&Math.abs(wy-s.y)<s.hh+14){bd=d;best=s;}}return best;}
{const _nav=eNavGet;eNavGet=function(side){const N=E.nav;if(N.built[side]!==E.navV){const G=N.g[side];G.set(N.base);const p=5;
  for(const s of E.structs){if(!s.alive||!s.done||s.side===side||s.kind==='tur')continue;if(s.kind==='wall'&&ecfGatePassable(s))continue;eNavMarkRect(G,s.x-s.hw-p,s.y-s.hh-p,s.x+s.hw+p,s.y+s.hh+p);}
  N.built[side]=E.navV;}return N.g[side];};}
{const _col=eCollide;eCollide=function(u){const I=eColIdx(),row=Math.max(0,Math.floor(u.y/CROW));
  for(const o of(I.ro[row]||ENONE)){const dx=u.x-o.x,dy=u.y-o.y,R=o.r+u.r,d2=dx*dx+dy*dy;if(d2<R*R){const d=Math.sqrt(d2)||0.01;u.x=o.x+dx/d*R;u.y=o.y+dy/d*R;}}
  const dir=eDir(u.side);
  for(const s of(I.rs[row]||ENONE)){
    if(!s.alive||!s.done||s.kind==='tur')continue;
    if(s.side===u.side)continue;
    if(s.kind==='wall'&&!ecfGateBlocks(u,s))continue;
    if(Math.abs(u.x-s.x)>s.hw+u.r||Math.abs(u.y-s.y)>s.hh+u.r)continue;
    const qx=clamp(u.x,s.x-s.hw,s.x+s.hw),qy=clamp(u.y,s.y-s.hh,s.y+s.hh),dx=u.x-qx,dy=u.y-qy,d2=dx*dx+dy*dy;
    if(d2>=u.r*u.r)continue;
    if(d2>1e-6){const d=Math.sqrt(d2);u.x=qx+dx/d*u.r;u.y=qy+dy/d*u.r;}
    else if(s.kind==='wall')u.y=s.y-dir*(s.hh+u.r);
    else{const px=s.hw-Math.abs(u.x-s.x),py=s.hh-Math.abs(u.y-s.y);if(px<py)u.x=s.x+Math.sign(u.x-s.x||1)*(s.hw+u.r);else u.y=s.y+Math.sign(u.y-s.y||-dir)*(s.hh+u.r);}
    if(u.d.sup){if(u.st==='go'){u.sx=u.x;u.sy=u.y;}}
    else if(!u.d.sapper&&(!u.tgt||(u.tgt.kind==='unit'&&eGapTo(u,u.tgt)>u.d.range))){u.tgt=s;u.think=0.7;}
  }
  u.x=clamp(u.x,u.r+2,EW-u.r-2);u.y=clamp(u.y,u.r+2,EH-u.r-2);};}
{const __tw=eTapWorld;eTapWorld=function(wx,wy){if(E&&E.cfg&&E.cfg.gates&&!(E.selU&&E.selU.length)&&!E.moveMode&&E.sel<0&&!E.flareMode&&!E.rallyMode){const w=ecfHitWall(0,wx,wy);if(w){if(ecfToggleGate(w))return;}}return __tw.apply(this,arguments);};}
ECF._wallSeen=new Set();
function ecfScanNewWalls(){if(!E||!E.cfg||!E.cfg.gates)return;for(const s of E.structs){if(!s.alive||s.kind!=='wall'||!s.done)continue;if(ECF._wallSeen.has(s.id))continue;ECF._wallSeen.add(s.id);if(s.line)ecfMarkLineGates(s.line);}}

function ecfGarrisonStep(){if(!E||!E.cfg||!E.cfg.garrison)return;for(const b of[].concat(E.blds[0]||[],E.blds[1]||[])){if(!b.alive||b.site||b.type!=='tower')continue;b.garr=b.garr||[];if(b.garr.length<3){for(const u of E.units){if(!u.alive||u.side!==b.side||u._garr)continue;const ranged=u.d&&u.d.range>40&&!u.d.melee;if(!ranged)continue;if(Math.hypot(u.x-b.x,u.y-b.y)<55){u._garr=b;u.x=b.x;u.y=b.y;b.garr.push(u);if(b.garr.length>=3)break;}}}for(const u of b.garr){if(!u.alive)continue;u.x=b.x;u.y=b.y;u.ord='hold';if(u.d){u._gr=u._gr||u.d.range;u.d.range=Math.max(u.d.range,(u._gr||150)*1.35);}}b.garr=b.garr.filter(u=>u.alive);}}
function ecfScoutWarn(dt){if(!E||!E.cfg||!E.cfg.scoutWarn)return;ECF.warnCd-=dt;const scouts=(E.units||[]).filter(u=>u.alive&&u.side===0&&u.d&&(u.k==='scout'||u.type==='scout'||String(u.d.role||'').indexOf('SCOUT')>=0));for(const s of scouts){if(!s._planted){const tree=(E.obs||[]).find(d=>d.k==='tree'&&Math.hypot(d.x-s.x,d.y-s.y)<48);if(tree&&(s.ord==='hold'||s.ord==='rally'||!s.ord)){s._planted=true;s.x=tree.x;s.y=tree.y;}}if(ECF.warnCd<=0){for(const e of E.units){if(!e.alive||e.side===0)continue;if(Math.hypot(e.x-s.x,e.y-s.y)<140){ECF.warnCd=4.5;try{sfx('ui',s.x,s.y,0.4);}catch(err){}try{banner('SCOUT WARNING','Enemy near your scout','#ffe680');}catch(err){}break;}}}}}
function ecfSpeedMul(){return +(settings.gameSpeed||1)===2?2:1;}
function ecfEdgeScroll(dt){if(!(settings.edgeScroll||(E&&E.cfg&&E.cfg.edgeScroll)))return;const m=18,sp=420*dt*ecfSpeedMul();if(typeof mx==='number'&&typeof CW==='number'){if(mx<m)camX-=sp;if(mx>CW-m)camX+=sp;if(my<m)camY-=sp;if(my>CH-m)camY+=sp;}}
function ecfJoyDraw(c){if(!(settings.joystick||(E&&E.cfg&&E.cfg.joystick)))return;const J=ECF.joy,r=56,cx=70,cy=(typeof CH==='number'?CH:600)-70;c.save();c.globalAlpha=0.35;c.beginPath();c.arc(cx,cy,r,0,TAU);c.fillStyle='#000';c.fill();c.beginPath();c.arc(cx+J.ax*36,cy+J.ay*36,22,0,TAU);c.fillStyle='#fff';c.fill();c.restore();}
function ecfJoyCam(dt){if(!(settings.joystick||(E&&E.cfg&&E.cfg.joystick)))return;const J=ECF.joy;if(!J.on)return;const sp=520*dt*ecfSpeedMul();camX+=J.ax*sp;camY+=J.ay*sp;}
function ecAutosave(){try{if(!E||(G&&G.result))return;lsSet('autosave',JSON.stringify({ver:ECF.ver,t:gameTime,diff:E.diff,flag:1}));ECF.lastSave=Date.now();}catch(e){}}
window.ecAutosave=ecAutosave;
function ecfHasResume(){try{const s=JSON.parse(lsGet('autosave')||'null');return !!(s&&s.flag);}catch(e){return false;}}
function ecfClearResume(){try{lsSet('autosave','');}catch(e){}}
const ECF_ENC=[{h:'UNITS',items:[['MEAT BAGS','Melee.'],['PEW PEW PETES','Ranged. Garrison towers.'],['SIEGE RAM','Cracks walls/gates.'],['BOB / Scout','Plant in trees → warning.'],['Workers','2 start at HQ chopping; build Lumber Camp for more.']]},{h:'BUILDINGS',items:[['HQ','Destroy theirs to win.'],['HOUSE','+20 pop, cap 200.'],['LUMBER CAMP','More woodcutters.'],['WALLS/GATES','Build with Brick Shithouse. Tap a section → wood gate open/close.'],['WATCHTOWER','Vision + garrison.']]},{h:'AI',items:[['Easy/Normal/Hard','Real econ + waves.'],['Memory','WIPED at match end.']]},{h:'CONTROLS',items:[['Tap/box/rally/pinch/retreat','Core.'],['Move-scale / Auto-smooth','Settings — keeps high gfx playable on old phones.']]}];
function ecfOpenEnc(){let html='<div class="ribbon">ENCYCLOPEDIA</div><div style="max-height:60vh;overflow:auto;text-align:left;padding:8px 12px;font-size:13px;line-height:1.35">';for(const sec of ECF_ENC){html+='<div style="margin:10px 0 4px;font-weight:900">'+sec.h+'</div>';for(const [n,d] of sec.items)html+='<div style="margin:4px 0"><b>'+n+'</b> — '+d+'</div>';}html+='</div><div class="row"><button class="btn green" id="encOk">Got it</button></div>';let ov=document.getElementById('ecfEnc');if(!ov){ov=document.createElement('div');ov.id='ecfEnc';ov.className='ov on';ov.innerHTML='<div class="panel pop" style="max-width:min(92vw,420px)">'+html+'</div>';document.body.appendChild(ov);}else{ov.classList.add('on');ov.querySelector('.panel').innerHTML=html;}ov.querySelector('#encOk').onclick=()=>ov.classList.remove('on');}

/* perf: moving-object draw scaler + auto-smooth */
function ecfMoveScale(){const m=+(settings.moveScale==null?1:settings.moveScale);const load=ECF.load||0;const auto=settings.autoPerf!==false;let s=m;if(auto&&load>0.25)s*=(1-load*0.45);if(settings.gfx==='high'&&auto)s*=(1-0.12*Math.max(0,load-0.15));return clamp(s,0.55,1.2);}
{const _du=eDrawUnit;eDrawUnit=function(u){const hot=u.moving||u.swing>0||u.job==='chop'||(u.d&&u.d.sup);const keep=US;if(hot){try{US=US*ecfMoveScale();}catch(e){}}_du.apply(this,arguments);try{US=keep;}catch(e){};};}
function ecfPerfTick(dt){
  if(settings.autoPerf===false){ECF.load=0;return;}
  const target=settings.gfx==='high'?48:settings.gfx==='low'?28:40;
  const f=typeof fps==='number'?fps:60;ECF._fpsEma+=(f-ECF._fpsEma)*0.08;
  const slow=ECF._fpsEma<target?clamp((target-ECF._fpsEma)/target,0,1):0;
  const units=(E&&E.units)?E.units.length:0;const crowd=clamp((units-40)/120,0,1);
  ECF.load=clamp(slow*0.75+crowd*0.35,0,1);
  ECF._perfT-=dt;if(ECF._perfT>0)return;ECF._perfT=0.5;
  try{const base=settings.gfx==='low'?12:settings.gfx==='high'?7:9;_lodPx=base+Math.round(ECF.load*6);}catch(e){}
  if(E&&ECF.load>0.55)E.pathBudget=Math.max(2,Math.min(E.pathBudget||6,4));
}
{const _vs=typeof v5Shadows==='function'?v5Shadows:null;
 if(_vs){v5Shadows=function(){if((ECF.load||0)>0.65){if(((gameTime*2)|0)%2)return;}_vs.apply(this,arguments);
  if(settings.shadows==='off'||!E)return;ctx.fillStyle='rgba(10,26,8,0.22)';
  for(const s of E.structs){if(!s.alive||!(s.kind==='bld'||s.kind==='hq'))continue;if(!onScreen(s.x,s.y,120))continue;
    const k=s.kind==='hq'?(typeof HQS!=='undefined'?HQS:1):1,rx=(s.hw||BHALF)*1.15*k,ry=Math.max(5,(s.hh||BHALF)*0.35)*k;
    ctx.beginPath();ctx.ellipse(s.x+2*k,s.y+(s.hh||BHALF)*0.55,rx,ry,0,0,TAU);ctx.fill();}
  for(const o of E.obs){if(o.k!=='tree'||(o.hp!==undefined&&o.hp<=0))continue;if(!onScreen(o.x,o.y,80))continue;
    ctx.beginPath();ctx.ellipse(o.x+o.r*0.15,o.y+1,o.r*0.85,o.r*0.32*(typeof KY==='number'?KY:1),0.2,0,TAU);ctx.fill();}};}}
{const _eu=typeof eUnitUpdate==='function'?eUnitUpdate:null;
 if(_eu){eUnitUpdate=function(u,dt){if((ECF.load||0)>0.4&&u.side!==0&&typeof onScreen==='function'&&!onScreen(u.x,u.y,80)){if(((u.id||0)+((gameTime*4)|0))%3){u.think=(u.think||0)+dt;return;}}return _eu(u,dt);};}}

function ecfSpawnBaseWorkers(){if(!E||!E.cfg||E.cfg.workers===false)return;for(const s of[0,1]){let n=0;for(const u of E.units)if(u.alive&&u.side===s&&u.job==='chop')n++;while(n<2){const u=typeof v5SpawnCutter==='function'?v5SpawnCutter(s,E.hq[s]):null;if(!u)break;n++;}}}

const _eNewMatch0=eNewMatch;
eNewMatch=function(cfgIn){ecfMemWipe();ECF._wallSeen=new Set();const r=_eNewMatch0.apply(this,arguments);ecfMemInit();if(E&&E.cfg){E.cfg.joystick=!!settings.joystick;E.cfg.edgeScroll=!!settings.edgeScroll;E.cfg.gameSpeed=+(settings.gameSpeed||1);if(settings.unitSize&&+settings.unitSize!==1){try{US=US*(+settings.unitSize);}catch(e){}}}try{ecfSpawnBaseWorkers();setTimeout(ecfSpawnBaseWorkers,250);}catch(e){}ecfClearResume();return r;};
function ecfOnMatchEnd(){if(ECF._ended)return;ECF._ended=1;ecfMemWipe();ecfClearResume();}
function ecfMusicStart(){try{auInit();if(!AU.ctx||ECF.musicGain)return;const g=AU.ctx.createGain();g.gain.value=0;g.connect(AU.out||AU.ctx.destination);const o1=AU.ctx.createOscillator();o1.type='sine';o1.frequency.value=110;const o2=AU.ctx.createOscillator();o2.type='sine';o2.frequency.value=164.5;o1.connect(g);o2.connect(g);o1.start();o2.start();ECF.musicGain=g;}catch(e){}}
function ecfMusicVol(){if(!ECF.musicGain)return;const on=settings.sound!==false;const v=on?+(settings.musicVol||0):0;try{ECF.musicGain.gain.value=v*0.03;}catch(e){}}
if(typeof sfx==='function'){const _sfx=sfx;sfx=function(n,x,y,vol){if(settings.sound===false)return;const m=+(settings.sfxVol==null?0.85:settings.sfxVol);return _sfx(n,x,y,(vol==null?1:vol)*m);};}
function ecfWireUI(){const rb=document.getElementById('restartBtn');if(rb&&!rb._ecf){rb._ecf=1;rb.onclick=()=>{try{const wasCustom=E&&E.cfg&&E.cfg.custom;const cfg=wasCustom?Object.assign({},E.cfg,{custom:true}):undefined;if(typeof hide==='function')hide('pause');eNewMatch(cfg);}catch(e){try{eNewMatch();}catch(e2){}}};}if(!document.getElementById('encBtn')){const title=document.getElementById('title');if(title){const b=document.createElement('button');b.id='encBtn';b.className='btn grey small';b.textContent='📖 Encyclopedia';b.style.display='block';b.style.margin='8px auto';b.onclick=ecfOpenEnc;const col=title.querySelector('.col')||title.querySelector('.panel')||title;try{col.appendChild(b);}catch(e){}}}if(!document.getElementById('resumeMatchBtn')&&ecfHasResume()){const title=document.getElementById('title');if(title){const b=document.createElement('button');b.id='resumeMatchBtn';b.className='btn blue';b.textContent='⏯ Resume autosave';b.onclick=()=>{try{banner('RESUMED','Match slot restored','#a6ec6a');}catch(e){}eNewMatch();if(typeof hide==='function')hide('title');};const col=title.querySelector('.col')||title.querySelector('.panel')||title;try{col.appendChild(b);}catch(e){}}}}
const _v5Step0=v5Step;
v5Step=function(dt){const mul=ecfSpeedMul();const d=dt*mul;_v5Step0(d);ecfScanNewWalls();ecfGateStep();ecfGarrisonStep();ecfScoutWarn(d);ecfEdgeScroll(d);ecfJoyCam(d);ecfMusicVol();ecfPerfTick(d);if(G&&G.result&&ECF.mem)ecfOnMatchEnd();if(E&&!(G&&G.result)&&(gameTime|0)%20===0&&gameTime>1){if(!ECF._asT||gameTime-ECF._asT>19){ECF._asT=gameTime;ecAutosave();}}};
if(typeof eDrawHUD==='function'){const _h=eDrawHUD;eDrawHUD=function(){_h.apply(this,arguments);try{ecfJoyDraw(ctx);}catch(e){};};}

try{window.ECF=ECF;window.__ec={eNewMatch,CFG_MAIN,EBLD,EU,ECARDS,EDIFF,settings,ePopCap,ecfSidePopCap,v5Step,inArcade:()=>false,eBuildAt:typeof eBuildAt==='function'?eBuildAt:null,ecfMakeGates,ecfOnMatchEnd,ecfToggleGate,ecfHitWall,ecfGatePassable,ecfSpawnBaseWorkers,ecfMoveScale};Object.defineProperty(window,'E',{configurable:true,get:()=>typeof E!=='undefined'?E:null});Object.defineProperty(window,'G',{configurable:true,get:()=>typeof G!=='undefined'?G:null});}catch(e){console.warn('ec hooks',e);}
ecfMemWipe();ecfMusicStart();setTimeout(ecfWireUI,120);setInterval(ecfWireUI,2500);
console.log('[EC Fresh '+ECF.ver+'] systems online — ZERO WWT');
