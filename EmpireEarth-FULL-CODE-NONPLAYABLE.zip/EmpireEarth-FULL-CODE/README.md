# EMPIRE EARTH / EMPIRE CLASH — FULL CODE DUMP (NON-PLAYABLE ARCHIVE)
For Jay — Ms. Bitch export. NOT a playable APK. Source/code only.

## What this is
Complete HTML/JS source for Empire Clash as shipped in Tough & J's Arcade, plus standalone/build copies.

## Arcade card versions (from tough-and-js-arcade.html)
- `empire-latest.html` — empire:latest (428055 bytes)
- `empire-v1.html` — empire:v1 (158159 bytes)
- `empire-v2.html` — empire:v2 (226565 bytes)
- `empire-v3.html` — empire:v3 (303717 bytes)
- `empire-v4.html` — empire:v4 (306632 bytes)
- `empire-v41.html` — empire:v41 (326808 bytes)
- `empire-v5.html` — empire:v5 (404545 bytes)
- `empire-v51.html` — empire:v51 (439275 bytes)
- `standalone-empire-clash.html` — standalone-empire-clash.html (404545 bytes)
- `standalone-empire-clash.v5.html` — standalone-empire-clash.v5.html (404545 bytes)
- `build-empireclash-index-1.0.2.html` — build-empireclash-index-1.0.2.html (428055 bytes)
- `_inject.js` —  (16773 bytes)

## How arcade uses it
Main APK WebView loads tough-and-js-arcade.html. Empire Clash card picks a version id; the shell injects the matching `empire:*` HTML blob into an iframe/srcdoc.

## Latest (mock-match)
`empire-latest.html` = EC Fresh mock-match art 1.0.2 (tent HQ, etc.) as of arcade 2.7.16.

## DO NOT
Treat this zip as an installable game. No APK, no keystore. Code dump only.
